# Khởi tạo package strategies
