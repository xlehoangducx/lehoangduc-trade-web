import math
import pandas as pd
import numpy as np
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal
import ta

class TrapDetectorStrategy(BaseStrategy):
    """
    Chiến thuật VSA & Liquidity Sweep (Săn Cá Mập).
    Phát hiện các cú Bull Trap (Bẫy tăng giá) và Bear Trap (Bẫy giảm giá) bằng phân tích khối lượng và râu nến.
    """
    def __init__(self, name: str = "TrapDetector", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'volume_sma_period': 20,
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'atr_period': 14,
                    'atr_multiplier_sl': 1.0,
                    'atr_multiplier_tp': 2.5,
                    'vol_dry_ratio': 0.60
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        bb_p = int(self.params.get('bb_period', 20))
        vol_p = int(self.params.get('volume_sma_period', 20))
        bb_s = float(self.params.get('bb_std', 2.0))
        atr_p = int(self.params.get('atr_period', 14))

        if df is None or len(df) < max(bb_p, vol_p, 50):
            return df
            
        df = df.copy()
        
        # Bollinger Bands for detecting extremes
        bb = ta.volatility.BollingerBands(df['close'], window=bb_p, window_dev=bb_s)
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_upper'] = bb.bollinger_hband()
        
        # Volume SMA ([BOM #125C FIX]: shift(1) loại trừ chính nến đột biến khỏi mẫu số để tránh tụt 31% RVol!)
        df['vol_sma'] = df['volume'].shift(1).rolling(window=vol_p, min_periods=1).mean()
        
        # ATR
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=atr_p).average_true_range()
        
        # Trend EMAs for fake pullback / dead cat bounce traps
        df['ema20'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
        df['ema50'] = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        df = self.get_indicators(df)
        
        if (
            df is None
            or df.empty
            or len(df) < 50
            or 'atr' not in df.columns
            or 'vol_sma' not in df.columns
            or 'ema20' not in df.columns
            or 'ema50' not in df.columns
            or pd.isna(df['atr'].iloc[-2])
            or pd.isna(df['vol_sma'].iloc[-2])
            or pd.isna(df['ema20'].iloc[-2])
            or pd.isna(df['ema50'].iloc[-2])
        ):
            return None
            
        # Chúng ta phân tích nến đóng cửa gần nhất (iloc[-2])
        current = df.iloc[-2]
        price = float(df.iloc[-1]['close']) # Giá hiện tại của nến đang chạy
        atr = float(current['atr'])
        bb_lo_val = current.get('bb_lower')
        bb_hi_val = current.get('bb_upper')
        if (
            (not math.isfinite(atr)) or atr <= 0
            or pd.isna(price) or (not math.isfinite(price)) or price <= 0
            or bb_lo_val is None or pd.isna(bb_lo_val) or (not math.isfinite(float(bb_lo_val))) or float(bb_lo_val) <= 0
            or bb_hi_val is None or pd.isna(bb_hi_val) or (not math.isfinite(float(bb_hi_val))) or float(bb_hi_val) <= 0
        ):
            return None
        
        # Tính toán hình thái nến (Candlestick Anatomy)
        total_candle_range = max(1e-8, current['high'] - current['low'])
        body = abs(current['open'] - current['close'])
        upper_wick = current['high'] - max(current['open'], current['close'])
        lower_wick = min(current['open'], current['close']) - current['low']
        
        # [BẤT BIẾN 17, 22 & BOM #92 FIX]: Chuẩn hóa sàn RVol & sóng Climax theo đúng 3 lớp tài sản (TradFi 0.85x / Major 1.00x / Altcoin 1.10x)
        from core.scanner import MarketScanner
        is_tradfi = False
        is_major = False
        if symbol:
            try:
                is_tradfi = MarketScanner.is_tradfi_symbol(symbol)
                _base_t = MarketScanner._clean_base(symbol)
                is_major = (not is_tradfi) and (_base_t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
            except Exception:
                is_tradfi = False
        min_climax_hard_pct = 0.005 if is_tradfi else 0.007
        min_climax_ext_pct = 0.018 if (is_tradfi or is_major) else 0.035
        min_trap_rvol = 0.85 if is_tradfi else (1.00 if is_major else 1.10)
        bb_high_vol_mult = 0.95 if is_tradfi else (1.15 if is_major else 1.25)

        # TRAP CONDITIONS
        vol_ratio = float(current['volume'] / current['vol_sma']) if current['vol_sma'] > 0 else 0.0
        is_high_volume = vol_ratio >= bb_high_vol_mult
        
        # Đà giá 3 nến đóng trước nến current để nhận diện nhịp pump/dump dốc
        recent_3 = df.iloc[-5:-2] if len(df) >= 6 else df.iloc[:-2]
        r3_low = float(recent_3['low'].min()) if not recent_3.empty else float(current['low'])
        r3_high = float(recent_3['high'].max()) if not recent_3.empty else float(current['high'])
        # [BOM #120H FIX]: Đo biên độ pump/dump tới đỉnh/đáy nến current (high/low) để không bỏ sót nến Climax rút chân sạch!
        recent_pump_pct = max(0.0, float((current['high'] - r3_low) / max(1e-8, r3_low)))
        recent_dump_pct = max(0.0, float((r3_high - current['low']) / max(1e-8, r3_high)))
        
        # 1. BB WICK SWEEPS & STRUCTURAL CLIMAX (Kiệt sức mua/bán & Quét thanh khoản cá mập)
        # [BOM #137 FIX]: Bắt buộc BB Wick Sweep cũng phải đạt sàn sóng KB10 (min_climax_hard_pct = 0.5% TradFi / 0.7% Altcoin)
        # để không phát bẫy giả trên nến đi ngang lờ đờ biên độ < 0.5%!
        is_bb_bear_wick = (
            recent_dump_pct >= min_climax_hard_pct and
            current['low'] < current['bb_lower'] and
            current['close'] >= current['bb_lower'] * 0.998 and
            lower_wick >= 0.45 * total_candle_range and
            lower_wick > upper_wick * 1.3 and
            (current['close'] >= current['open'] or body <= 0.45 * total_candle_range) and
            is_high_volume
        )
        is_selling_climax = (
            (
                recent_dump_pct >= min_climax_hard_pct and
                lower_wick >= 0.45 * total_candle_range and
                lower_wick > upper_wick * 1.4 and
                vol_ratio >= min_trap_rvol and
                (current['close'] >= current['open'] - 0.35 * total_candle_range)
            ) or (
                recent_dump_pct >= min_climax_ext_pct and
                lower_wick >= 0.40 * total_candle_range and
                lower_wick > upper_wick * 1.3 and
                body <= 0.55 * total_candle_range and
                vol_ratio >= min_trap_rvol
            )
        )
        is_bear_trap_wick = is_bb_bear_wick or is_selling_climax
        
        # BULL TRAP WICK: Đâm thủng BB trên bị đập xuống HOẶC Kiệt sức mua (Buying Climax) xả hàng phân phối đỉnh
        is_bb_bull_wick = (
            recent_pump_pct >= min_climax_hard_pct and
            current['high'] > current['bb_upper'] and
            current['close'] <= current['bb_upper'] * 1.002 and
            upper_wick >= 0.45 * total_candle_range and
            upper_wick > lower_wick * 1.3 and
            (current['close'] <= current['open'] or body <= 0.45 * total_candle_range) and
            is_high_volume
        )
        is_buying_climax = (
            (
                recent_pump_pct >= min_climax_hard_pct and
                upper_wick >= 0.45 * total_candle_range and
                upper_wick > lower_wick * 1.4 and
                vol_ratio >= min_trap_rvol and
                (current['close'] <= current['open'] + 0.35 * total_candle_range)
            ) or (
                recent_pump_pct >= min_climax_ext_pct and
                upper_wick >= 0.40 * total_candle_range and
                upper_wick > lower_wick * 1.3 and
                body <= 0.55 * total_candle_range and
                vol_ratio >= min_trap_rvol
            )
        )
        is_bull_trap_wick = is_bb_bull_wick or is_buying_climax
        
        # [SSOT PURGE]: XÓA SỔ VĨNH VIỄN BULL_TRAP_BOUNCE VÀ BEAR_TRAP_DIP
        # Chỉ công nhận bẫy thật khi có RÂU NẾN VẬT LÝ quét thanh khoản (BULL_TRAP_WICK / BEAR_TRAP_WICK / BUYING_CLIMAX / SELLING_CLIMAX).
        is_bear_trap = is_bear_trap_wick and (price >= float(current['low']))
        is_bull_trap = is_bull_trap_wick and (price <= float(current['high']))

        if is_bear_trap:
            # Cá mập gom hàng rút chân BB / Selling Climax. Đi theo cá mập -> MUA
            sl_mult = self.params.get('atr_multiplier_sl', 1.0)
            trap_type = 'SELLING_CLIMAX' if is_selling_climax else 'BEAR_TRAP_WICK'
            calc_confidence = round(min(0.84, max(0.68, 0.62 + 0.06 * min(3.5, vol_ratio))), 2)
            struct_dist = max(0.0, price - current['low'])
                
            sl_dist = max(atr * sl_mult, struct_dist + 0.2 * atr)
            stop_loss = max(price * 0.01, price - sl_dist)
            tp_dist = max(atr * self.params.get('atr_multiplier_tp', 2.5), sl_dist * 1.5)
            take_profit = price + tp_dist
            
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={
                    'vol': float(current['volume']),
                    'vol_sma': float(current['vol_sma']),
                    'c_vol_ratio': float(vol_ratio),
                    'c_upper_wick_pct': float(upper_wick / total_candle_range),
                    'c_lower_wick_pct': float(lower_wick / total_candle_range),
                    'type': trap_type,
                    'timeframe': getattr(self, 'timeframe', '15m')
                }
            )
            
        elif is_bull_trap:
            # Cá mập xả hàng rút râu BB / Buying Climax. Bán theo cá mập -> BÁN
            sl_mult = self.params.get('atr_multiplier_sl', 1.0)
            trap_type = 'BUYING_CLIMAX' if is_buying_climax else 'BULL_TRAP_WICK'
            calc_confidence = round(min(0.84, max(0.68, 0.62 + 0.06 * min(3.5, vol_ratio))), 2)
            struct_dist = max(0.0, current['high'] - price)
                
            sl_dist = max(atr * sl_mult, struct_dist + 0.2 * atr)
            stop_loss = price + sl_dist
            tp_dist = max(atr * self.params.get('atr_multiplier_tp', 2.5), sl_dist * 1.5)
            take_profit = max(price * 0.01, price - tp_dist)
            
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={
                    'vol': float(current['volume']),
                    'vol_sma': float(current['vol_sma']),
                    'c_vol_ratio': float(vol_ratio),
                    'c_upper_wick_pct': float(upper_wick / total_candle_range),
                    'c_lower_wick_pct': float(lower_wick / total_candle_range),
                    'type': trap_type,
                    'timeframe': getattr(self, 'timeframe', '15m')
                }
            )
        return None

