import math
import pandas as pd
import numpy as np
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal
import ta

class TrapDetectorStrategy(BaseStrategy):
    """
    Chiến thuật VSA & Liquidity Sweep (Săn Cá Mập).
    Phát hiện các cú Bull Trap (Bẫy tăng giá) và Bear Trap (Bẫy giảm giá) bằng phân tích khối lượng và râu nến.
    """
    def __init__(self, name: str = "TrapDetector", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'volume_sma_period': 20,
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'atr_period': 14,
                    'atr_multiplier_sl': 1.0,
                    'atr_multiplier_tp': 2.5,
                    'vol_dry_ratio': 0.60
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        bb_p = int(self.params.get('bb_period', 20))
        vol_p = int(self.params.get('volume_sma_period', 20))
        bb_s = float(self.params.get('bb_std', 2.0))
        atr_p = int(self.params.get('atr_period', 14))

        if df is None or len(df) < max(bb_p, vol_p, 50):
            return df
            
        df = df.copy()
        
        # Bollinger Bands for detecting extremes
        bb = ta.volatility.BollingerBands(df['close'], window=bb_p, window_dev=bb_s)
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_upper'] = bb.bollinger_hband()
        
        # Volume SMA
        df['vol_sma'] = df['volume'].rolling(window=vol_p).mean()
        
        # ATR
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=atr_p).average_true_range()
        
        # Trend EMAs for fake pullback / dead cat bounce traps
        df['ema20'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
        df['ema50'] = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        df = self.get_indicators(df)
        
        if (
            df is None
            or df.empty
            or len(df) < 50
            or 'atr' not in df.columns
            or 'vol_sma' not in df.columns
            or 'ema20' not in df.columns
            or 'ema50' not in df.columns
            or pd.isna(df['atr'].iloc[-2])
            or pd.isna(df['vol_sma'].iloc[-2])
            or pd.isna(df['ema20'].iloc[-2])
            or pd.isna(df['ema50'].iloc[-2])
        ):
            return None
            
        # Chúng ta phân tích nến đóng cửa gần nhất (iloc[-2])
        current = df.iloc[-2]
        price = df.iloc[-1]['close'] # Giá hiện tại của nến đang chạy
        atr = float(current['atr'])
        if not math.isfinite(atr) or atr <= 0:
            return None
        
        # Tính toán hình thái nến (Candlestick Anatomy)
        total_candle_range = max(1e-8, current['high'] - current['low'])
        body = abs(current['open'] - current['close'])
        upper_wick = current['high'] - max(current['open'], current['close'])
        lower_wick = min(current['open'], current['close']) - current['low']
        
        # TRAP CONDITIONS
        is_high_volume = current['volume'] > current['vol_sma'] * 1.3  # Volume đột biến > 30% trung bình
        vol_ratio = float(current['volume'] / current['vol_sma']) if current['vol_sma'] > 0 else 1.0
        vol_dry_ratio = float(self.params.get('vol_dry_ratio', 0.60))
        
        # Đà giá 3 nến đóng trước nến current để nhận diện nhịp pump/dump dốc
        recent_3 = df.iloc[-5:-2] if len(df) >= 6 else df.iloc[:-2]
        r3_low = float(recent_3['low'].min()) if not recent_3.empty else float(current['low'])
        r3_high = float(recent_3['high'].max()) if not recent_3.empty else float(current['high'])
        recent_pump_pct = float((current['close'] - r3_low) / max(1e-8, r3_low))
        recent_dump_pct = float((r3_high - current['close']) / max(1e-8, r3_high))
        
        # 1. BB WICK SWEEPS & STRUCTURAL CLIMAX (Kiệt sức mua/bán & Quét thanh khoản cá mập)
        # BEAR TRAP WICK: Đâm thủng BB dưới rút chân HOẶC Kiệt sức bán (Selling Climax) rút chân gom hàng
        is_bb_bear_wick = (
            current['low'] < current['bb_lower'] and
            current['close'] >= current['bb_lower'] * 0.998 and
            lower_wick >= 0.45 * total_candle_range and
            lower_wick > upper_wick * 1.3 and
            (current['close'] >= current['open'] or body <= 0.45 * total_candle_range) and
            is_high_volume
        )
        is_selling_climax = (
            (
                lower_wick >= 0.45 * total_candle_range and
                lower_wick > upper_wick * 1.4 and
                vol_ratio >= 1.25 and
                (current['close'] >= current['open'] - 0.35 * total_candle_range)
            ) or (
                recent_dump_pct >= 0.035 and
                lower_wick >= 0.40 * total_candle_range and
                lower_wick > upper_wick * 1.3 and
                vol_ratio >= 1.20
            )
        )
        is_bear_trap_wick = is_bb_bear_wick or is_selling_climax
        
        # BULL TRAP WICK: Đâm thủng BB trên bị đập xuống HOẶC Kiệt sức mua (Buying Climax) xả hàng phân phối đỉnh
        is_bb_bull_wick = (
            current['high'] > current['bb_upper'] and
            current['close'] <= current['bb_upper'] * 1.002 and
            upper_wick >= 0.45 * total_candle_range and
            upper_wick > lower_wick * 1.3 and
            (current['close'] <= current['open'] or body <= 0.45 * total_candle_range) and
            is_high_volume
        )
        is_buying_climax = (
            (
                upper_wick >= 0.45 * total_candle_range and
                upper_wick > lower_wick * 1.4 and
                vol_ratio >= 1.25 and
                (current['close'] <= current['open'] + 0.35 * total_candle_range)
            ) or (
                recent_pump_pct >= 0.035 and
                upper_wick >= 0.40 * total_candle_range and
                upper_wick > lower_wick * 1.3 and
                vol_ratio >= 1.20
            )
        )
        is_bull_trap_wick = is_bb_bull_wick or is_buying_climax
        
        # 2. VSA PULLBACK / RETRACEMENT TRAPS (Bẫy hồi giả Dead Cat Bounce & Bẫy chỉnh cạn cung)
        # Kiểm tra 12 nến đóng cửa trước nến current
        recent_window = df.iloc[-14:-2] if len(df) >= 15 else df.iloc[:-2]
        dumps = recent_window[
            (recent_window['close'] < recent_window['open']) & 
            (recent_window['volume'] > recent_window['vol_sma'] * 1.25) &
            ((recent_window['open'] - recent_window['close']) >= recent_window['atr'] * 0.6)
        ]
        pumps = recent_window[
            (recent_window['close'] > recent_window['open']) & 
            (recent_window['volume'] > recent_window['vol_sma'] * 1.25) &
            ((recent_window['close'] - recent_window['open']) >= recent_window['atr'] * 0.6)
        ]
        
        last_dump_idx = dumps.index[-1] if not dumps.empty else None
        last_pump_idx = pumps.index[-1] if not pumps.empty else None
        
        # BULL TRAP BOUNCE (Dead Cat Bounce / Hồi không thanh khoản chạm cản EMA) -> Bán/Short
        is_bull_trap_bounce = False
        max_dump_vol = 0.0
        if last_dump_idx is not None and (last_pump_idx is None or last_dump_idx > last_pump_idx):
            max_dump_vol = float(dumps['volume'].max())
            # Cấu trúc: Xu hướng giảm (EMA20 <= EMA50 hoặc giá dưới EMA50)
            is_downtrend = (current['ema20'] <= current['ema50'] * 1.002) or (current['close'] < current['ema50'])
            # Nến hồi: nến xanh hoặc thân nến nhỏ (không có lực đẩy)
            is_weak_bounce = (current['close'] > current['open']) or (body <= 0.35 * total_candle_range)
            # Volume hồi cạn kiệt so với cây xả (< vol_dry_ratio cây dump, mặc định 60%)
            vol_dry = (current['volume'] <= max_dump_vol * vol_dry_ratio)
            # Chạm hoặc tiếp cận EMA20 trong phạm vi biến động ATR nhưng không vượt qua được
            tested_resistance = (current['high'] >= current['ema20'] - atr * 0.5) and (current['close'] <= current['ema20'] + atr * 0.25)
            # Có râu trên từ chối hoặc nến đỏ quay đầu
            has_rejection = (upper_wick >= 0.15 * total_candle_range) or (current['close'] <= current['open'])
            
            if is_downtrend and is_weak_bounce and vol_dry and tested_resistance and has_rejection:
                is_bull_trap_bounce = True
                
        # BEAR TRAP DIP (Fake Dip / Chỉnh cạn cung giữ vững hỗ trợ EMA) -> Mua/Long
        is_bear_trap_dip = False
        max_pump_vol = 0.0
        if last_pump_idx is not None and (last_dump_idx is None or last_pump_idx > last_dump_idx):
            max_pump_vol = float(pumps['volume'].max())
            # Cấu trúc: Xu hướng tăng (EMA20 >= EMA50 hoặc giá trên EMA50)
            is_uptrend = (current['ema20'] >= current['ema50'] * 0.998) or (current['close'] > current['ema50'])
            # Nến chỉnh: nến đỏ hoặc thân nhỏ (không có lực bán tháo)
            is_weak_dip = (current['close'] < current['open']) or (body <= 0.35 * total_candle_range)
            # Volume điều chỉnh cạn kiệt (< vol_dry_ratio cây bơm, mặc định 60%)
            vol_dry = (current['volume'] <= max_pump_vol * vol_dry_ratio)
            # Chạm hoặc tiếp cận EMA20 trong phạm vi biến động ATR nhưng được đỡ
            tested_support = (current['low'] <= current['ema20'] + atr * 0.5) and (current['close'] >= current['ema20'] - atr * 0.25)
            # Có râu dưới đỡ giá hoặc nến xanh bật lên
            has_support = (lower_wick >= 0.15 * total_candle_range) or (current['close'] >= current['open'])
            
            if is_uptrend and is_weak_dip and vol_dry and tested_support and has_support:
                is_bear_trap_dip = True
                
        is_bear_trap = is_bear_trap_wick or is_bear_trap_dip
        is_bull_trap = is_bull_trap_wick or is_bull_trap_bounce

        if is_bear_trap:
            # Cá mập gom hàng (rút chân BB hoặc cạn cung tại hỗ trợ EMA). Đi theo cá mập -> MUA
            sl_mult = self.params.get('atr_multiplier_sl', 1.0)
            if is_bear_trap_wick:
                trap_type = 'BEAR_TRAP_WICK'
                calc_confidence = round(min(0.82, max(0.60, 0.58 + 0.06 * min(3.5, vol_ratio))), 2)
                struct_dist = max(0.0, price - current['low'])
            else:
                trap_type = 'BEAR_TRAP_DIP'
                dry_ratio = current['volume'] / max_pump_vol if max_pump_vol > 0 else 0.5
                calc_confidence = round(min(0.78, max(0.62, 0.60 + 0.14 * (1.0 - min(1.0, dry_ratio)))), 2)
                struct_dist = max(0.0, price - min(current['low'], current['ema20']))
                
            sl_dist = max(atr * sl_mult, struct_dist + 0.2 * atr)
            stop_loss = price - sl_dist
            take_profit = price + atr * self.params.get('atr_multiplier_tp', 2.5)
            
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={
                    'vol': float(current['volume']),
                    'vol_sma': float(current['vol_sma']),
                    'type': trap_type,
                    'timeframe': getattr(self, 'timeframe', '15m')
                }
            )
            
        elif is_bull_trap:
            # Cá mập xả hàng (rút râu BB hoặc hồi ảo cạn cầu tại kháng cự EMA). Bán theo cá mập -> BÁN
            sl_mult = self.params.get('atr_multiplier_sl', 1.0)
            if is_bull_trap_wick:
                trap_type = 'BULL_TRAP_WICK'
                calc_confidence = round(min(0.82, max(0.60, 0.58 + 0.06 * min(3.5, vol_ratio))), 2)
                struct_dist = max(0.0, current['high'] - price)
            else:
                trap_type = 'BULL_TRAP_BOUNCE'
                dry_ratio = current['volume'] / max_dump_vol if max_dump_vol > 0 else 0.5
                calc_confidence = round(min(0.78, max(0.62, 0.60 + 0.14 * (1.0 - min(1.0, dry_ratio)))), 2)
                struct_dist = max(0.0, max(current['high'], current['ema20']) - price)
                
            sl_dist = max(atr * sl_mult, struct_dist + 0.2 * atr)
            stop_loss = price + sl_dist
            take_profit = price - atr * self.params.get('atr_multiplier_tp', 2.5)
            
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={
                    'vol': float(current['volume']),
                    'vol_sma': float(current['vol_sma']),
                    'type': trap_type,
                    'timeframe': getattr(self, 'timeframe', '15m')
                }
            )
        return None

