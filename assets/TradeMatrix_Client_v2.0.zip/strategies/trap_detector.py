import math
import pandas as pd
import numpy as np
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal
import ta

class TrapDetectorStrategy(BaseStrategy):
    """
    Chiến thuật VSA & Liquidity Sweep (Săn Cá Mập).
    Phát hiện các cú Bull Trap (Bẫy tăng giá) và Bear Trap (Bẫy giảm giá) bằng phân tích khối lượng và râu nến.
    """
    def __init__(self, name: str = "TrapDetector", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'volume_sma_period': 20,
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'atr_period': 14,
                    'atr_multiplier_sl': 1.0,
                    'atr_multiplier_tp': 2.5,
                    'vol_dry_ratio': 0.60
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        bb_p = int(self.params.get('bb_period', 20))
        vol_p = int(self.params.get('volume_sma_period', 20))
        bb_s = float(self.params.get('bb_std', 2.0))
        atr_p = int(self.params.get('atr_period', 14))

        if df is None or len(df) < max(bb_p, vol_p, 50):
            return df
            
        df = df.copy()
        
        # Bollinger Bands for detecting extremes
        bb = ta.volatility.BollingerBands(df['close'], window=bb_p, window_dev=bb_s)
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_upper'] = bb.bollinger_hband()
        
        # Volume SMA
        df['vol_sma'] = df['volume'].rolling(window=vol_p).mean()
        
        # ATR
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=atr_p).average_true_range()
        
        # Trend EMAs for fake pullback / dead cat bounce traps
        df['ema20'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
        df['ema50'] = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        df = self.get_indicators(df)
        
        if (
            df is None
            or df.empty
            or len(df) < 50
            or 'atr' not in df.columns
            or 'vol_sma' not in df.columns
            or 'ema20' not in df.columns
            or 'ema50' not in df.columns
            or pd.isna(df['atr'].iloc[-2])
            or pd.isna(df['vol_sma'].iloc[-2])
            or pd.isna(df['ema20'].iloc[-2])
            or pd.isna(df['ema50'].iloc[-2])
        ):
            return None
            
        # Chúng ta phân tích nến đóng cửa gần nhất (iloc[-2])
        current = df.iloc[-2]
        price = df.iloc[-1]['close'] # Giá hiện tại của nến đang chạy
        atr = float(current['atr'])
        if not math.isfinite(atr) or atr <= 0:
            return None
        
        # Tính toán hình thái nến (Candlestick Anatomy)
        total_candle_range = max(1e-8, current['high'] - current['low'])
        body = abs(current['open'] - current['close'])
        upper_wick = current['high'] - max(current['open'], current['close'])
        lower_wick = min(current['open'], current['close']) - current['low']
        
        # TRAP CONDITIONS
        is_high_volume = current['volume'] > current['vol_sma'] * 1.3  # Volume đột biến > 30% trung bình
        vol_ratio = float(current['volume'] / current['vol_sma']) if current['vol_sma'] > 0 else 1.0
        vol_dry_ratio = float(self.params.get('vol_dry_ratio', 0.60))
        
        # Đà giá 3 nến đóng trước nến current để nhận diện nhịp pump/dump dốc
        recent_3 = df.iloc[-5:-2] if len(df) >= 6 else df.iloc[:-2]
        r3_low = float(recent_3['low'].min()) if not recent_3.empty else float(current['low'])
        r3_high = float(recent_3['high'].max()) if not recent_3.empty else float(current['high'])
        recent_pump_pct = max(0.0, float((current['close'] - r3_low) / max(1e-8, r3_low)))
        recent_dump_pct = max(0.0, float((r3_high - current['close']) / max(1e-8, r3_high)))
        
        # [BẤT BIẾN 17 & KỊCH BẢN 10 SSOT]: Chuẩn hóa sàn sóng thích ứng theo lớp tài sản
        # TradFi biên độ nến 15m trung bình 0.22% -> sàn 0.5% (0.005); Altcoin trung bình 0.55% -> sàn 0.7% (0.007).
        from core.scanner import MarketScanner
        is_tradfi = False
        if symbol:
            try:
                is_tradfi = MarketScanner.is_tradfi_symbol(symbol)
            except Exception:
                is_tradfi = False
        min_climax_hard_pct = 0.005 if is_tradfi else 0.007
        
        # 1. BB WICK SWEEPS & STRUCTURAL CLIMAX (Kiệt sức mua/bán & Quét thanh khoản cá mập)
        # BEAR TRAP WICK: Đâm thủng BB dưới rút chân HOẶC Kiệt sức bán (Selling Climax) rút chân gom hàng
        is_bb_bear_wick = (
            current['low'] < current['bb_lower'] and
            current['close'] >= current['bb_lower'] * 0.998 and
            lower_wick >= 0.45 * total_candle_range and
            lower_wick > upper_wick * 1.3 and
            (current['close'] >= current['open'] or body <= 0.45 * total_candle_range) and
            is_high_volume
        )
        is_selling_climax = (
            (
                recent_dump_pct >= min_climax_hard_pct and
                lower_wick >= 0.45 * total_candle_range and
                lower_wick > upper_wick * 1.4 and
                vol_ratio >= 1.25 and
                (current['close'] >= current['open'] - 0.35 * total_candle_range)
            ) or (
                recent_dump_pct >= 0.035 and
                lower_wick >= 0.40 * total_candle_range and
                lower_wick > upper_wick * 1.3 and
                vol_ratio >= 1.20
            )
        )
        is_bear_trap_wick = is_bb_bear_wick or is_selling_climax
        
        # BULL TRAP WICK: Đâm thủng BB trên bị đập xuống HOẶC Kiệt sức mua (Buying Climax) xả hàng phân phối đỉnh
        is_bb_bull_wick = (
            current['high'] > current['bb_upper'] and
            current['close'] <= current['bb_upper'] * 1.002 and
            upper_wick >= 0.45 * total_candle_range and
            upper_wick > lower_wick * 1.3 and
            (current['close'] <= current['open'] or body <= 0.45 * total_candle_range) and
            is_high_volume
        )
        is_buying_climax = (
            (
                recent_pump_pct >= min_climax_hard_pct and
                upper_wick >= 0.45 * total_candle_range and
                upper_wick > lower_wick * 1.4 and
                vol_ratio >= 1.25 and
                (current['close'] <= current['open'] + 0.35 * total_candle_range)
            ) or (
                recent_pump_pct >= 0.035 and
                upper_wick >= 0.40 * total_candle_range and
                upper_wick > lower_wick * 1.3 and
                vol_ratio >= 1.20
            )
        )
        is_bull_trap_wick = is_bb_bull_wick or is_buying_climax
        
        # [SSOT PURGE]: XÓA SỔ VĨNH VIỄN BULL_TRAP_BOUNCE VÀ BEAR_TRAP_DIP
        # Chỉ công nhận bẫy thật khi có RÂU NẾN VẬT LÝ quét thanh khoản (BULL_TRAP_WICK / BEAR_TRAP_WICK).
        is_bear_trap = is_bear_trap_wick
        is_bull_trap = is_bull_trap_wick

        if is_bear_trap:
            # Cá mập gom hàng rút chân BB. Đi theo cá mập -> MUA
            sl_mult = self.params.get('atr_multiplier_sl', 1.0)
            trap_type = 'BEAR_TRAP_WICK'
            calc_confidence = round(min(0.82, max(0.60, 0.58 + 0.06 * min(3.5, vol_ratio))), 2)
            struct_dist = max(0.0, price - current['low'])
                
            sl_dist = max(atr * sl_mult, struct_dist + 0.2 * atr)
            stop_loss = price - sl_dist
            take_profit = price + atr * self.params.get('atr_multiplier_tp', 2.5)
            
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={
                    'vol': float(current['volume']),
                    'vol_sma': float(current['vol_sma']),
                    'type': trap_type,
                    'timeframe': getattr(self, 'timeframe', '15m')
                }
            )
            
        elif is_bull_trap:
            # Cá mập xả hàng rút râu BB. Bán theo cá mập -> BÁN
            sl_mult = self.params.get('atr_multiplier_sl', 1.0)
            trap_type = 'BULL_TRAP_WICK'
            calc_confidence = round(min(0.82, max(0.60, 0.58 + 0.06 * min(3.5, vol_ratio))), 2)
            struct_dist = max(0.0, current['high'] - price)
                
            sl_dist = max(atr * sl_mult, struct_dist + 0.2 * atr)
            stop_loss = price + sl_dist
            take_profit = price - atr * self.params.get('atr_multiplier_tp', 2.5)
            
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={
                    'vol': float(current['volume']),
                    'vol_sma': float(current['vol_sma']),
                    'type': trap_type,
                    'timeframe': getattr(self, 'timeframe', '15m')
                }
            )
        return None

