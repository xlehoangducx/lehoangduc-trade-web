"""
Cloud Sync Service - Đồng bộ hai chiều giữa Bot PC và Nền tảng Web Cloudflare / Firebase
- Bắn dữ liệu telemetry thời gian thực (số dư, PnL, vị thế mở, tỷ lệ thắng) lên Firebase Firestore
- Tiếp nhận và thực thi các lệnh điều khiển từ xa (Bật, Dừng, Đổi đòn bẩy, Đóng lệnh khẩn cấp) gửi từ Web
"""

import time
import json
import logging
from datetime import datetime
from pathlib import Path
import requests
import yaml

logger = logging.getLogger("cloud_sync")

def to_firestore_value(val):
    if isinstance(val, bool):
        return {"booleanValue": val}
    elif isinstance(val, int):
        return {"integerValue": str(val)}
    elif isinstance(val, float):
        return {"doubleValue": float(val)}
    elif isinstance(val, str):
        return {"stringValue": val}
    elif isinstance(val, list):
        return {"arrayValue": {"values": [to_firestore_value(x) for x in val]}}
    elif isinstance(val, dict):
        return {"mapValue": {"fields": {k: to_firestore_value(v) for k, v in val.items()}}}
    elif val is None:
        return {"nullValue": None}
    else:
        return {"stringValue": str(val)}

def to_firestore_doc(data_dict):
    return {"fields": {k: to_firestore_value(v) for k, v in data_dict.items()}}

def from_firestore_value(val):
    if not isinstance(val, dict):
        return None
    if "stringValue" in val:
        return val["stringValue"]
    elif "integerValue" in val:
        return int(val["integerValue"])
    elif "doubleValue" in val:
        return float(val["doubleValue"])
    elif "booleanValue" in val:
        return bool(val["booleanValue"])
    elif "mapValue" in val:
        return {k: from_firestore_value(v) for k, v in val["mapValue"].get("fields", {}).items()}
    elif "arrayValue" in val:
        return [from_firestore_value(x) for x in val["arrayValue"].get("values", [])]
    elif "nullValue" in val:
        return None
    return None

def from_firestore_doc(doc):
    fields = doc.get("fields", {})
    return {k: from_firestore_value(v) for k, v in fields.items()}


class CloudSyncWorker:
    def __init__(self, root_dir=None, api_port=5000):
        self.root_dir = Path(root_dir) if root_dir else Path(__file__).parent
        self.api_port = api_port
        self.api_base = f"http://127.0.0.1:{api_port}/api"
        self.settings = self._load_settings()
        
        cloud_cfg = self.settings.get("cloud", {})
        self.enabled = cloud_cfg.get("enabled", True)
        self.user_token = cloud_cfg.get("user_token", "").strip()
        self.project_id = cloud_cfg.get("project_id", "trade-bot-platform")
        self.sync_interval = cloud_cfg.get("sync_interval_seconds", 5)
        
        self.base_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents"
        self.last_command_id = None

    def _load_settings(self):
        settings_path = self.root_dir / "config" / "settings.yaml"
        if settings_path.exists():
            try:
                with open(settings_path, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
            except Exception as e:
                logger.error(f"Lỗi đọc settings.yaml: {e}")
        return {}

    def push_telemetry(self):
        """Gửi số dư, PnL, vị thế mở lên Firestore bots_telemetry/{user_token}"""
        if not self.user_token:
            return False

        try:
            # 1. Lấy dữ liệu từ local bot Flask API
            r_status = requests.get(f"{self.api_base}/status", timeout=3)
            if r_status.status_code != 200:
                return False
            status = r_status.json()

            perf = {}
            try:
                r_perf = requests.get(f"{self.api_base}/performance", timeout=3)
                if r_perf.status_code == 200:
                    perf = r_perf.json()
            except Exception:
                pass

            positions = []
            try:
                r_pos = requests.get(f"{self.api_base}/positions", timeout=3)
                if r_pos.status_code == 200:
                    positions = r_pos.json()
            except Exception:
                pass

            balance = float(status.get("balance", status.get("available_balance", 0.0)))
            daily_pnl = float(perf.get("today_pnl", 0.0))
            total_pnl = float(perf.get("total_pnl", 0.0))
            win_rate = float(perf.get("win_rate", 0.0) or 0.0)
            is_running = bool(status.get("is_running", False))
            max_open_trades = int(status.get("ai_recommended_max_positions", 2) or 2)

            telemetry_data = {
                "user_token": self.user_token,
                "balance": balance,
                "daily_pnl": daily_pnl,
                "total_pnl": total_pnl,
                "win_rate": round(win_rate, 1),
                "open_positions_count": len(positions),
                "max_open_trades": max_open_trades,
                "is_running": is_running,
                "exchange_connected": bool(status.get("exchange_connected", False)),
                "updated_at": datetime.now().strftime("%H:%M:%S %d/%m"),
                "positions": [
                    {
                        "symbol": str(p.get("symbol", "")),
                        "side": str(p.get("side", "")),
                        "leverage": int(p.get("leverage", 1)),
                        "entry_price": float(p.get("entry_price", 0.0)),
                        "mark_price": float(p.get("mark_price", 0.0)),
                        "margin": float(p.get("margin", 0.0)),
                        "unrealized_pnl": float(p.get("unrealized_pnl", 0.0))
                    }
                    for p in positions
                ]
            }

            # 2. Gửi PATCH lên Firestore bots_telemetry/{user_token}
            patch_url = f"{self.base_url}/bots_telemetry/{self.user_token}"
            doc_body = to_firestore_doc(telemetry_data)
            res = requests.patch(patch_url, json=doc_body, timeout=5)

            if res.status_code == 200:
                # Cập nhật thêm vào bảng thành viên users/{user_token} để Super Admin quan sát
                try:
                    user_url = f"{self.base_url}/users/{self.user_token}?updateMask.fieldPaths=livePnl&updateMask.fieldPaths=totalPnl&updateMask.fieldPaths=assignedBalance"
                    user_body = to_firestore_doc({
                        "livePnl": daily_pnl,
                        "totalPnl": total_pnl,
                        "assignedBalance": balance
                    })
                    requests.patch(user_url, json=user_body, timeout=4)
                except Exception:
                    pass
                return True
            else:
                logger.debug(f"Firestore telemetry patch returned: {res.status_code}")
                return False

        except Exception as e:
            logger.debug(f"Lỗi push telemetry: {e}")
            return False

    def verify_license(self):
        """Kiểm tra bản quyền từ xa của Super Admin Lê Hoàng Đức:
        - Nếu status != 'approved' (ví dụ: 'pending', 'revoked', 'blocked'):
          Tự động ra lệnh dừng Bot ngay lập tức và ngăn không cho chạy tiếp.
        """
        if not self.user_token:
            self._enforce_stop_if_running("Chưa cấu hình User Token bản quyền TradeMatrix!")
            return False, "Chưa cấu hình token"

        try:
            user_url = f"{self.base_url}/users/{self.user_token}"
            res = requests.get(user_url, timeout=4)
            if res.status_code == 404:
                self._enforce_stop_if_running("Token không tồn tại trên hệ thống TradeMatrix!")
                return False, "Token không tồn tại"
            elif res.status_code != 200:
                return True, "Không thể kết nối cloud kiểm tra bản quyền"

            user_doc = from_firestore_doc(res.json())
            status = str(user_doc.get("status", "pending")).lower()
            role = str(user_doc.get("role", "user")).lower()

            if role == "admin":
                return True, "Admin"

            if status != "approved":
                msg = f"Tài khoản chưa được Super Admin phê duyệt hoặc đã bị thu hồi/khóa (Trạng thái: {status.upper()})"
                self._enforce_stop_if_running(msg)
                return False, msg

            return True, "Đã cấp quyền"
        except Exception as e:
            logger.debug(f"Lỗi kiểm tra bản quyền: {e}")
            return True, "Lỗi mạng"

    def _enforce_stop_if_running(self, reason):
        try:
            r_status = requests.get(f"{self.api_base}/status", timeout=2)
            if r_status.status_code == 200 and r_status.json().get("is_running"):
                logger.warning(f"⛔ [KHÓA BẢN QUYỀN]: {reason}. Tiến hành dừng bot!")
                requests.post(f"{self.api_base}/stop", json={}, timeout=3)
        except Exception:
            pass

    def poll_and_execute_commands(self):
        """Lắng nghe lệnh điều khiển từ xa từ Firestore bot_commands/{user_token}"""
        if not self.user_token:
            return

        try:
            cmd_url = f"{self.base_url}/bot_commands/{self.user_token}"
            res = requests.get(cmd_url, timeout=4)
            if res.status_code != 200:
                return

            cmd_doc = from_firestore_doc(res.json())
            command = cmd_doc.get("command")
            status = cmd_doc.get("status")
            license_status = str(cmd_doc.get("license_status", "")).lower()

            if license_status in ("revoked", "blocked"):
                self._enforce_stop_if_running("Quyền sử dụng bot đã bị Admin thu hồi/khóa từ xa!")

            if status != "pending" or not command:
                return

            logger.info(f"⚡ Nhận lệnh từ xa: [{command.upper()}] (License: {license_status or 'N/A'})")

            success = False
            msg = ""

            if command == "status_update":
                success = True
                msg = f"Đã cập nhật trạng thái bản quyền: {license_status.upper()}"

            elif command == "start":
                # Kiểm tra bản quyền trước khi cho start
                if license_status in ("revoked", "blocked"):
                    success = False
                    msg = "Từ chối khởi động: Tài khoản đã bị khóa bởi Admin."
                else:
                    licensed, reason = self.verify_license()
                    if not licensed:
                        success = False
                        msg = f"Từ chối khởi động: {reason}"
                    else:
                        r = requests.post(f"{self.api_base}/start", json={}, timeout=5)
                        success = r.status_code == 200
                        msg = r.text

            elif command == "stop":
                r = requests.post(f"{self.api_base}/stop", json={}, timeout=5)
                success = r.status_code == 200
                msg = r.text

            elif command == "run_cycle":
                licensed, reason = self.verify_license()
                if not licensed:
                    success = False
                    msg = f"Từ chối thực thi: {reason}"
                else:
                    r = requests.post(f"{self.api_base}/run_cycle", json={}, timeout=5)
                    success = r.status_code == 200
                    msg = r.text

            elif command == "update_config":
                if "max_leverage" in cmd_doc:
                    requests.post(f"{self.api_base}/leverage", json={"max_leverage": cmd_doc["max_leverage"]}, timeout=5)
                if "max_open_trades" in cmd_doc:
                    requests.post(f"{self.api_base}/positions_limit", json={"max_open_trades": cmd_doc["max_open_trades"]}, timeout=5)
                success = True
                msg = "Đã cập nhật cấu hình đòn bẩy và số lệnh tối đa"

            elif command == "emergency_close":
                # Đóng toàn bộ các lệnh đang mở
                try:
                    r_pos = requests.get(f"{self.api_base}/positions", timeout=3)
                    if r_pos.status_code == 200:
                        positions = r_pos.json()
                        for p in positions:
                            requests.post(f"{self.api_base}/positions/close", json={"symbol": p.get("symbol")}, timeout=5)
                    success = True
                    msg = "Đã gửi lệnh đóng toàn bộ vị thế"
                except Exception as ce:
                    msg = str(ce)

            # Xác nhận hoàn tất lệnh
            ack_body = to_firestore_doc({
                "command": command,
                "status": "completed" if success else "failed",
                "result_message": str(msg),
                "executed_at": datetime.now().strftime("%H:%M:%S %d/%m")
            })
            requests.patch(cmd_url, json=ack_body, timeout=4)
            logger.info(f"✅ Hoàn tất thi hành lệnh [{command.upper()}]")

        except Exception as e:
            logger.debug(f"Lỗi kiểm tra lệnh từ xa: {e}")

    def run_loop(self):
        """Vòng lặp chạy nền độc lập."""
        logger.info(f"🌐 Cloud Sync Service khởi động. User Token: {self.user_token}")
        while True:
            # Tự động nạp lại config nếu user đổi token trên giao diện web local
            self.settings = self._load_settings()
            cloud_cfg = self.settings.get("cloud", {})
            self.user_token = cloud_cfg.get("user_token", "").strip()

            if self.user_token:
                licensed, reason = self.verify_license()
                if licensed:
                    self.push_telemetry()
                    self.poll_and_execute_commands()
            else:
                self.verify_license()
            time.sleep(self.sync_interval)

def start_cloud_sync_thread(root_dir=None, api_port=5000):
    import threading
    worker = CloudSyncWorker(root_dir=root_dir, api_port=api_port)
    t = threading.Thread(target=worker.run_loop, daemon=True, name="CloudSyncWorker")
    t.start()
    return worker

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    worker = CloudSyncWorker()
    worker.run_loop()

