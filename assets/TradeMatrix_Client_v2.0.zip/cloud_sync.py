"""
Cloud Sync Service - Đồng bộ hai chiều giữa Bot PC và Nền tảng Web Cloudflare / Firebase
- Bắn dữ liệu telemetry thời gian thực (số dư, PnL, vị thế mở, tỷ lệ thắng) lên Firebase Firestore
- Tiếp nhận và thực thi các lệnh điều khiển từ xa (Bật, Dừng, Đổi đòn bẩy, Đóng lệnh khẩn cấp) gửi từ Web
"""

import time
import json
import hashlib
import logging
import math
import os
import tempfile
import threading
import unicodedata
from datetime import datetime
from pathlib import Path
import requests
import yaml

logger = logging.getLogger("cloud_sync")
_LICENSE_CACHE_LOCK = threading.Lock()

LICENSE_CACHE_FILENAME = "license_cache.json"
DEFAULT_LICENSE_CACHE_TTL_DAYS = 7.0
FIRESTORE_DOCS_URL = (
    "https://firestore.googleapis.com/v1/projects/{project_id}"
    "/databases/(default)/documents"
)

def to_firestore_value(val):
    if isinstance(val, bool):
        return {"booleanValue": val}
    elif isinstance(val, int):
        return {"integerValue": str(val)}
    elif isinstance(val, float):
        return {"doubleValue": float(val)} if math.isfinite(val) else {"doubleValue": 0.0}
    elif isinstance(val, str):
        return {"stringValue": val}
    elif isinstance(val, list):
        return {"arrayValue": {"values": [to_firestore_value(x) for x in val]}}
    elif isinstance(val, dict):
        return {"mapValue": {"fields": {k: to_firestore_value(v) for k, v in val.items()}}}
    elif val is None:
        return {"nullValue": None}
    else:
        return {"stringValue": str(val)}

def to_firestore_doc(data_dict):
    return {"fields": {k: to_firestore_value(v) for k, v in data_dict.items()}}

def from_firestore_value(val):
    if not isinstance(val, dict):
        return None
    if "stringValue" in val:
        return val["stringValue"]
    elif "integerValue" in val:
        return int(val["integerValue"])
    elif "doubleValue" in val:
        return float(val["doubleValue"])
    elif "booleanValue" in val:
        return bool(val["booleanValue"])
    elif "mapValue" in val:
        return {k: from_firestore_value(v) for k, v in val["mapValue"].get("fields", {}).items()}
    elif "arrayValue" in val:
        return [from_firestore_value(x) for x in val["arrayValue"].get("values", [])]
    elif "nullValue" in val:
        return None
    return None

def from_firestore_doc(doc):
    fields = doc.get("fields", {})
    return {k: from_firestore_value(v) for k, v in fields.items()}


def with_update_mask(url, field_paths):
    """Thêm `updateMask` cho PATCH Firestore REST.

    [SỬA LỖI GỐC RỄ - XÓA SẠCH BẢN QUYỀN] `PATCH .../documents/{path}` KHÔNG kèm
    `updateMask` là **THAY THẾ TOÀN BỘ DOCUMENT**: mọi field không có trong body bị
    xóa. ACK lệnh `stop` chỉ gửi 4 field nên đã xóa mất `license_status` (và cả
    `created_at`/`updatedAt`) do Web ghi trước đó -> chu kỳ sau `verify_license()`
    không còn kênh nào đọc được quyền (users/{uid} bị rules chặn 403) -> bot LIVE
    không khởi động lại được. Nay mọi PATCH đều khai báo đúng field cần ghi.
    """
    fields = [str(f) for f in (field_paths or []) if str(f).strip()]
    if not fields:
        return url
    sep = "&" if "?" in url else "?"
    mask = "&".join(f"updateMask.fieldPaths={name}" for name in fields)
    return f"{url}{sep}{mask}"


def parse_user_tokens(val):
    """Chuẩn hóa `cloud.user_token` (chuỗi phân tách dấu phẩy hoặc list) thành list UID."""
    if isinstance(val, list):
        return [str(t).strip() for t in val if str(t).strip()]
    if isinstance(val, str):
        return [t.strip() for t in val.split(",") if t.strip()]
    return []


def _license_cache_path(root_dir=None):
    base = Path(root_dir) if root_dir else Path(__file__).parent
    return base / "data" / LICENSE_CACHE_FILENAME


def _token_cache_key(token):
    """Băm token trước khi lưu ra đĩa: file cục bộ không chứa thêm bản sao plaintext."""
    return hashlib.sha256(str(token).encode("utf-8")).hexdigest()


def load_license_cache(root_dir=None):
    """Đọc sổ bản quyền đã xác minh cục bộ. Lỗi/thiếu file -> {} (không bao giờ crash)."""
    path = _license_cache_path(root_dir)
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_license_cache(cache, root_dir=None):
    """Ghi sổ bản quyền nguyên tử (Lock + mkstemp + retry os.replace) chống WinError 32 trên Windows."""
    path = _license_cache_path(root_dir)
    with _LICENSE_CACHE_LOCK:
        temp_path = None
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
            temp_path = Path(temp_name)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(json.dumps(cache, ensure_ascii=False, indent=2))
                stream.flush()
                os.fsync(stream.fileno())
            for attempt in range(5):
                try:
                    os.replace(temp_path, path)
                    temp_path = None
                    return True
                except (PermissionError, OSError):
                    if attempt == 4:
                        raise
                    time.sleep(0.05 * (attempt + 1))
            return True
        except Exception as e:
            logger.debug("Không ghi được license cache: %s", e)
            return False
        finally:
            if temp_path is not None and temp_path.exists():
                try:
                    temp_path.unlink()
                except OSError:
                    pass


def _cache_tokens_map(cache):
    tokens = cache.get("tokens") if isinstance(cache, dict) else None
    return tokens if isinstance(tokens, dict) else {}


def find_cached_license(root_dir=None, ttl_days=DEFAULT_LICENSE_CACHE_TTL_DAYS):
    """Trả về mô tả bản quyền đã xác minh còn hạn trong sổ cục bộ, hoặc '' nếu không có."""
    cache_tokens = _cache_tokens_map(load_license_cache(root_dir))
    try:
        ttl_seconds = max(0.0, float(ttl_days)) * 86400.0
    except Exception:
        ttl_seconds = DEFAULT_LICENSE_CACHE_TTL_DAYS * 86400.0
    if ttl_seconds <= 0:
        return ""
    now = time.time()
    for entry in cache_tokens.values():
        if not isinstance(entry, dict):
            continue
        if str(entry.get("status") or "").lower() != "approved":
            continue
        try:
            verified_at = float(entry.get("last_verified") or 0)
        except Exception:
            continue
        age = now - verified_at
        if 0 <= age <= ttl_seconds:
            return f"bản quyền đã xác minh cục bộ (còn {(ttl_seconds - age) / 86400.0:.1f} ngày)"
    return ""


def _normalize_text(val):
    """Hạ chữ thường + bỏ dấu tiếng Việt để so khớp chuỗi không phụ thuộc nguồn ghi."""
    try:
        text = str(val or "").lower().replace("đ", "d")
        decomposed = unicodedata.normalize("NFD", text)
        return "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    except Exception:
        return str(val or "").lower()


def _ack_marks_approved(result_message):
    """ACK lệnh `status_update` có thể chứa phê duyệt dạng chữ trong `result_message`.

    `license_status` là kênh chính, nhưng field này có thể bị xóa (xem chú thích
    `with_update_mask`). Writer hiện tại ghi có dấu ("... bản quyền: APPROVED"),
    song một số bản Web/ngôn ngữ lại ghi không dấu ("... ban quyen: APPROVED").
    Vì vậy chuẩn hóa bỏ dấu trước khi so khớp để không từ chối oan token đã duyệt.
    """
    norm = _normalize_text(result_message)
    return ("ban quyen: approved" in norm) or ("license_status: approved" in norm)


def verify_license_tokens(tokens, project_id="trade-bot-platform", root_dir=None,
                          ttl_days=DEFAULT_LICENSE_CACHE_TTL_DAYS, timeout=4):
    """Xác minh bản quyền cho danh sách token, dùng chung cho cloud_sync và /api/start.

    Thứ tự ưu tiên: `bot_commands/{uid}.license_status` -> ACK `result_message`
    -> `users/{uid}` -> sổ bản quyền đã xác minh lưu cục bộ (TTL).

    Bất biến an toàn:
    - `revoked`/`blocked` LUÔN thắng: token đó bị xóa khỏi sổ cục bộ và không hồi sinh.
    - Sổ cục bộ chỉ được ghi SAU khi sàn/xa xác nhận approved, và chỉ dùng khi KHÔNG
      kết luận được từ xa (mất mạng, 403 rules, field bị xóa) — không cấp quyền mới.
    """
    tokens = parse_user_tokens(tokens)
    result = {
        "approved": False,
        "revoked": False,
        "explicit_refusal": False,
        "reason": "Chưa cấu hình token",
        "source": "none",
        "token": "",
    }
    if not tokens:
        return result

    base = FIRESTORE_DOCS_URL.format(project_id=project_id or "trade-bot-platform")
    cache = load_license_cache(root_dir)
    cache_tokens = _cache_tokens_map(cache)
    cache_dirty = False
    now = time.time()
    unverified = []
    revoked_tokens = []
    explicit_denied_tokens = []
    explicit_denied_statuses = (
        "pending", "denied", "expired", "suspended", "rejected", "disabled", "unapproved",
    )

    for token in tokens:
        key = _token_cache_key(token)
        decided = False
        cmd_denied = False
        cmd_missing = False
        user_denied = False
        user_missing = False

        try:
            res = requests.get(f"{base}/bot_commands/{token}", timeout=timeout)
        except Exception as e:
            logger.debug("Lỗi mạng đọc bot_commands license: %s", e)
            res = None

        if res is not None and res.status_code == 200:
            try:
                cmd_doc = from_firestore_doc(res.json())
            except Exception:
                cmd_doc = {}
            license_status = str(cmd_doc.get("license_status") or "").strip().lower()
            result_message = str(cmd_doc.get("result_message") or "").lower()
            # [BOM #125D FIX]: Kiểm tra revoked/blocked TRƯỚC TIÊN và chỉ cho fallback result_message khi license_status trống!
            if license_status in ("revoked", "blocked"):
                # Token này bị thu hồi: xóa khỏi sổ cục bộ, thử token kế tiếp.
                revoked_tokens.append(token)
                if key in cache_tokens:
                    cache_tokens.pop(key, None)
                    cache_dirty = True
                decided = True
            elif license_status == "approved" or (
                not license_status
                and str(cmd_doc.get("status") or "").strip().lower() == "completed"
                and _ack_marks_approved(result_message)
            ):
                cache_tokens[key] = {"status": "approved", "last_verified": now}
                cache_dirty = True
                result.update(
                    approved=True, revoked=False, explicit_refusal=False, source="remote",
                    reason="Đã cấp quyền", token=token,
                )
                decided = True
            else:
                if license_status in explicit_denied_statuses:
                    cmd_denied = True
                    # [BOM #126C FIX]: Xóa luôn token đã expired/suspended/denied khỏi license_cache.json!
                    if key in cache_tokens:
                        cache_tokens.pop(key, None)
                        cache_dirty = True
                unverified.append(token)
        else:
            if res is not None and res.status_code == 404:
                cmd_missing = True
            unverified.append(token)

        if decided:
            if result["approved"]:
                break
            continue

        # Kênh dự phòng: users/{uid} (thường 403 với REST không auth, nhưng có nơi mở).
        try:
            res_u = requests.get(f"{base}/users/{token}", timeout=timeout)
            if res_u.status_code == 200:
                user_doc = from_firestore_doc(res_u.json())
                u_status = str(user_doc.get("status") or "pending").lower()
                u_role = str(user_doc.get("role") or "user").lower()
                if u_role == "admin" or u_status == "approved":
                    cache_tokens[key] = {"status": "approved", "last_verified": now}
                    cache_dirty = True
                    result.update(
                        approved=True, revoked=False, explicit_refusal=False, source="remote",
                        reason="Đã cấp quyền", token=token,
                    )
                    break
                if u_status in ("revoked", "blocked"):
                    revoked_tokens.append(token)
                    if key in cache_tokens:
                        cache_tokens.pop(key, None)
                        cache_dirty = True
                    continue
                if u_status in explicit_denied_statuses:
                    user_denied = True
                    if key in cache_tokens:
                        cache_tokens.pop(key, None)
                        cache_dirty = True
            elif res_u.status_code == 404:
                user_missing = True
        except Exception as e:
            logger.debug("Lỗi kiểm tra users license: %s", e)

        if cmd_denied or user_denied or (cmd_missing and user_missing):
            explicit_denied_tokens.append(token)

    if result["approved"]:
        if cache_dirty:
            save_license_cache({"version": 1, "tokens": cache_tokens}, root_dir)
        return result

    # Không kết luận được từ xa -> dùng sổ cục bộ (chống Firestore sự cố / field bị xóa oan).
    # Chỉ dùng cho token chưa bị từ chối rõ ràng trên server (tránh giữ quyền token đã bị Admin thu hồi/hạ pending).
    try:
        ttl_seconds = max(0.0, float(ttl_days)) * 86400.0
    except Exception:
        ttl_seconds = DEFAULT_LICENSE_CACHE_TTL_DAYS * 86400.0
    if ttl_seconds > 0:
        for token in unverified:
            if token in explicit_denied_tokens or token in revoked_tokens:
                continue
            entry = cache_tokens.get(_token_cache_key(token)) or {}
            if not isinstance(entry, dict):
                continue
            if str(entry.get("status") or "").lower() != "approved":
                continue
            try:
                verified_at = float(entry.get("last_verified") or 0)
            except Exception:
                continue
            age = now - verified_at
            if 0 <= age <= ttl_seconds:
                logger.warning(
                    "⚠️ [LICENSE] Không xác minh được từ xa (%s...), dùng bản quyền đã xác minh "
                    "cục bộ, còn %.1f ngày.", str(token)[:6], (ttl_seconds - age) / 86400.0,
                )
                if cache_dirty:
                    save_license_cache({"version": 1, "tokens": cache_tokens}, root_dir)
                result.update(
                    approved=True, revoked=False, explicit_refusal=False, source="cache", token=token,
                    reason="Dùng bản quyền đã xác minh cục bộ (còn %.1f ngày)"
                           % ((ttl_seconds - age) / 86400.0),
                )
                return result

    if cache_dirty:
        save_license_cache({"version": 1, "tokens": cache_tokens}, root_dir)

    if revoked_tokens:
        result.update(revoked=True, explicit_refusal=True, reason="Quyền sử dụng đã bị Admin thu hồi/khóa")
    elif explicit_denied_tokens:
        result.update(revoked=False, explicit_refusal=True, reason="Tài khoản chưa được Admin cấp quyền hoặc đã hết hạn")
    else:
        result.update(reason="Không xác minh được quyền sử dụng hợp lệ")
    return result


class CloudSyncWorker:
    def __init__(self, root_dir=None, api_port=5000):
        self.root_dir = Path(root_dir) if root_dir else Path(__file__).parent
        self.api_port = api_port
        self.api_base = f"http://127.0.0.1:{api_port}/api"
        self.settings = self._load_settings() or {}

        cloud_cfg = self.settings.get("cloud") or {}
        self.enabled = cloud_cfg.get("enabled", True)
        self.user_tokens = self._parse_tokens(cloud_cfg.get("user_token", ""))
        self.user_token = self.user_tokens[0] if self.user_tokens else ""
        self.project_id = cloud_cfg.get("project_id", "trade-bot-platform")
        self.sync_interval = cloud_cfg.get("sync_interval_seconds", 5)
        try:
            self.license_cache_ttl_days = float(
                cloud_cfg.get("license_cache_ttl_days", DEFAULT_LICENSE_CACHE_TTL_DAYS)
            )
        except Exception:
            self.license_cache_ttl_days = DEFAULT_LICENSE_CACHE_TTL_DAYS
        # Đếm số chu kỳ LIÊN TIẾP đọc settings THÀNH CÔNG nhưng không có token.
        # Chỉ khi vượt ngưỡng này mới được phép dừng bot (xem verify_license).
        self._empty_token_cycles = 0
        
        self.base_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents"
        self.last_command_ids = {}

    def _parse_tokens(self, val):
        return parse_user_tokens(val)

    def _load_settings(self, attempts: int = 3):
        """Đọc config/settings.yaml. Trả None khi KHÔNG ĐỌC ĐƯỢC (khác với file rỗng {}).

        [SỬA LỖI GỐC RỄ - TỰ SÁT BẢN QUYỀN]
        Trước đây hàm này trả {} cho cả hai trường hợp "file rỗng" và "đọc/parse lỗi".
        `run_loop()` nạp lại settings mỗi 5 giây và gán thẳng `self.user_tokens` từ kết quả,
        nên CHỈ CẦN MỘT LẦN đọc lỗi tạm thời (file đang được dashboard ghi dở, antivirus khoá
        file, user đang sửa tay YAML) là token bị xoá sạch -> `verify_license()` rơi vào nhánh
        "Chưa cấu hình token" -> `_enforce_stop_if_running()` DỪNG BOT LIVE đang gồng lệnh thật.

        Nay: file không tồn tại -> {} (không cấu hình); đọc/parse lỗi -> None (KHÔNG BIẾT),
        kèm 3 lần thử ngắn để nuốt các lỗi khoá file nhất thời. run_loop sẽ giữ nguyên cấu
        hình tốt gần nhất và bỏ qua chu kỳ thay vì zeroing token.
        """
        settings_path = self.root_dir / "config" / "settings.yaml"
        if not settings_path.exists():
            return {}
        last_error = None
        for attempt in range(1, max(1, attempts) + 1):
            try:
                with open(settings_path, "r", encoding="utf-8") as f:
                    loaded = yaml.safe_load(f)
                if loaded is None:
                    return {}
                if not isinstance(loaded, dict):
                    raise ValueError(
                        f"settings.yaml phải là mapping, nhận được {type(loaded).__name__}"
                    )
                return loaded
            except Exception as e:
                last_error = e
                if attempt < max(1, attempts):
                    time.sleep(0.2)
        logger.error(
            "Lỗi đọc settings.yaml (%s lần) - GIỮ NGUYÊN cấu hình đã nạp trước đó: %s",
            max(1, attempts), last_error,
        )
        return None

    def push_telemetry(self):
        """Gửi số dư, PnL, vị thế mở lên Firestore bots_telemetry/{user_token}"""
        if not self.user_tokens:
            return False

        try:
            # 1. Lấy dữ liệu từ local bot Flask API
            status = {}
            try:
                r_status = requests.get(f"{self.api_base}/status", timeout=3)
                if r_status.status_code == 200:
                    status = r_status.json()
                    self.last_status = status
                    self.last_status_at = time.time()
            except Exception:
                pass
            if not status and hasattr(self, 'last_status'):
                # [BOM #135 FIX]: Giới hạn TTL 15s cho last_status (đồng bộ last_positions) — tránh đẩy mãi is_running=True khi bot treo!
                _st_age = time.time() - float(getattr(self, 'last_status_at', 0.0) or 0.0)
                if _st_age <= 15.0:
                    status = self.last_status
            if not status:
                return False

            perf = {}
            try:
                r_perf = requests.get(f"{self.api_base}/performance", timeout=3)
                if r_perf.status_code == 200:
                    perf = r_perf.json()
                    self.last_perf = perf
                    self.last_perf_at = time.time()
            except Exception:
                pass
            if not perf and hasattr(self, 'last_perf'):
                if (time.time() - float(getattr(self, 'last_perf_at', 0.0) or 0.0)) <= 60.0:
                    perf = self.last_perf

            positions = None
            positions_stale = False
            try:
                r_pos = requests.get(f"{self.api_base}/positions", timeout=3)
                if r_pos.status_code == 200:
                    # [] là trạng thái PHẲNG THẬT, không phải dữ liệu thiếu.
                    positions = r_pos.json()
                    if not isinstance(positions, list):
                        raise ValueError('positions response is not a list')
                    self.last_positions = positions
                    self.last_positions_at = time.time()
            except Exception:
                pass
            if positions is None:
                cache_age = time.time() - float(getattr(self, 'last_positions_at', 0.0) or 0.0)
                if hasattr(self, 'last_positions') and cache_age <= 15.0:
                    positions = self.last_positions
                    positions_stale = True
                else:
                    # Không có dữ liệu tươi: công bố unknown/stale thay vì hồi sinh vị thế đã đóng.
                    positions = []
                    positions_stale = True

            def _num_val(src, keys, default=0.0):
                if isinstance(src, dict):
                    for k in keys:
                        if src.get(k) is not None:
                            return src.get(k)
                return default

            mode = str(status.get("mode", "live")).upper()
            market_type = str(status.get("market_type", "futures")).upper()

            balance = float(_num_val(status, ("balance", "available_balance"), 0.0))
            _raw_eq = _num_val(status, ("equity", "margin_balance"), None)
            _raw_wal = _num_val(status, ("wallet_balance",), None)
            _snap_stale = bool(status.get("account_snapshot_stale", False)) or (mode == "LIVE" and _raw_eq is None)
            if mode == "LIVE" and _raw_eq is None:
                equity = None
                wallet_balance = None
            else:
                equity = float(_raw_eq if _raw_eq is not None else balance)
                wallet_balance = float(_raw_wal if _raw_wal is not None else balance)
            available_balance = float(_num_val(status, ("available_balance",), balance))
            used_margin = float(_num_val(status, ("used_margin",), 0.0))
            daily_pnl = float(_num_val(perf, ("today_pnl",), 0.0))
            total_pnl = float(_num_val(perf, ("total_pnl",), 0.0))
            win_rate = float(_num_val(perf, ("win_rate",), 0.0))
            total_trades = int(_num_val(perf, ("total_trades", "closed_trade_count"), 0))
            total_fees = float(_num_val(perf, ("total_fees", "total_fee"), 0.0))
            is_running = bool(status.get("is_running", False))
            max_leverage = int(_num_val(status, ("max_leverage", "leverage"), 10))
            max_open_trades = int(_num_val(status, ("max_open_positions", "ai_recommended_max_positions"), 2))

            # [SỔ VỐN 28/10/2026] PnL TOÀN BỘ TÀI KHOẢN = equity - tổng nạp/rút thật từ sàn.
            # Khác `total_pnl` (chỉ là realized PnL của các lệnh đã ghi trong DB): con số này
            # còn bao gồm funding fee và lịch sử giao dịch trước khi DB bắt đầu ghi. Web cần
            # hiển thị cả hai để người dùng không thắc mắc vì sao hai nơi lệch nhau.
            try:
                session_pnl = (
                    round(float(status.get("session_pnl")), 4)
                    if status.get("session_pnl") is not None else None
                )
            except (TypeError, ValueError, OverflowError):
                session_pnl = None
            try:
                invested_basis = (
                    round(float(status.get("invested_basis")), 4)
                    if status.get("invested_basis") is not None else None
                )
            except (TypeError, ValueError, OverflowError):
                invested_basis = None

            telemetry_data = {
                "user_token": self.user_token,
                "balance": balance,
                "equity": round(equity, 2) if equity is not None else None,
                "available_balance": round(available_balance, 2),
                "wallet_balance": round(wallet_balance, 2) if wallet_balance is not None else None,
                "used_margin": round(used_margin, 2),
                "daily_pnl": round(daily_pnl, 4),
                "today_pnl": round(daily_pnl, 4),
                "total_pnl": round(total_pnl, 4),
                "session_pnl": session_pnl,
                "invested_basis": invested_basis,
                "total_fees": round(total_fees, 4),
                "total_trades": total_trades,
                "win_rate": round(win_rate, 1),
                "max_leverage": max_leverage,
                "max_open_trades": max_open_trades,
                "mode": mode,
                "market_type": market_type,
                "open_positions_count": len(positions),
                "account_snapshot_stale": bool(_snap_stale or positions_stale),
                "is_running": is_running,
                "exchange_connected": bool(status.get("exchange_connected", False)),
                "tradfi_enabled": bool(status.get("tradfi_enabled", False)),
                "only_tradfi": bool(status.get("only_tradfi", False)),
                "tradfi_market_open": bool(status.get("tradfi_market_open", False)),
                "auto_adopt_manual_positions": bool(status.get("auto_adopt_manual_positions", False)),
                "free_roll_recycling": bool(status.get("free_roll_recycling", True)),
                "free_roll_positions_count": int(status.get("free_roll_positions_count", 0)),
                "at_risk_positions_count": int(status.get("at_risk_positions_count", 0)),
                "updated_at": datetime.now().strftime("%H:%M:%S %d/%m"),
                "positions": [],
                "radar_candidates": []
            }

            try:
                if status.get("radar_candidates"):
                    telemetry_data["radar_candidates"] = status.get("radar_candidates")
                else:
                    from core.gate_telemetry import get_top_radar_candidates
                    telemetry_data["radar_candidates"] = get_top_radar_candidates(limit=16, max_age_seconds=900)
            except Exception:
                telemetry_data["radar_candidates"] = []

            total_unrealized = 0.0
            seen_telemetry_keys = set()
            deduped_push_positions = []
            for p in positions:
                sym_raw = str(p.get("symbol", ""))
                clean_sym = sym_raw.split(':')[0].replace('/', '').upper()
                side = str(p.get("direction") or p.get("side") or "LONG").upper()
                side = "LONG" if side in ("BUY", "LONG") else "SHORT"
                t_key = (clean_sym, side)
                if t_key in seen_telemetry_keys:
                    continue
                seen_telemetry_keys.add(t_key)
                deduped_push_positions.append(p)
            positions = deduped_push_positions
            telemetry_data['open_positions_count'] = len(positions)

            for p in positions:
                side = str(p.get("direction") or p.get("side") or "LONG").upper()
                if side in ("BUY", "LONG"):
                    side = "LONG"
                else:
                    side = "SHORT"
                entry_p = float(p.get("entry_price") or 0.0)
                mark_p = float(p.get("mark_price") or entry_p)
                lev = int(p.get("exchange_leverage") or p.get("leverage") or 1)
                amt = abs(float(p.get("amount") or 0.0))

                margin = float(p.get("margin") or p.get("exchange_initial_margin") or p.get("cost") or 0.0)
                if margin <= 0.0 and entry_p > 0 and amt > 0:
                    margin = (entry_p * amt) / max(1, lev)

                upnl_val = p.get("unrealized_pnl")
                if upnl_val is None:
                    upnl_val = p.get("unrealized_pnl_mark")
                if upnl_val is None and p.get("real_pnl") is not None:
                    upnl_val = p.get("real_pnl")

                if upnl_val is not None:
                    upnl = float(upnl_val)
                elif entry_p > 0 and amt > 0:
                    upnl = (mark_p - entry_p) * amt if side == "LONG" else (entry_p - mark_p) * amt
                else:
                    upnl = 0.0

                total_unrealized += upnl

                pnl_pct = float(p.get("pnl_pct") or 0.0)
                if pnl_pct == 0.0 and margin > 0.0:
                    pnl_pct = round((upnl / margin * 100.0), 2)

                # [BOM #140 FIX]: Dịch trạng thái trailing theo đúng thứ tự đặc thù trước generic `trailing_active`
                raw_trailing = str(p.get("trailing_status") or "").lower()
                if raw_trailing == "protection_unavailable":
                    trailing_label = "Cần SL sàn"
                elif raw_trailing == "profit_locked" or p.get("partial_tp_done"):
                    trailing_label = "Đã chốt TP1 · Bám lãi (Trailing)"
                elif raw_trailing == "mfe_ratchet":
                    trailing_label = "Khóa Lãi MFE Ratchet"
                elif raw_trailing == "ewick_choke":
                    trailing_label = "Siết SL Râu Ngược (E-Wick)"
                elif raw_trailing == "micro_telemetry":
                    trailing_label = "Co hẹp SL Vi mô (Micro)"
                elif raw_trailing == "breakeven_locked" or p.get("breakeven_activated") or p.get("breakeven_protection_confirmed"):
                    trailing_label = "Đã khóa Hòa Vốn (+0.22%)"
                elif raw_trailing == "flat_be" or p.get("flat_be_activated") or p.get("flat_be_confirmed"):
                    trailing_label = "Đã khóa Hòa Vốn Phẳng (0.0%)"
                elif raw_trailing == "cushion_buffer" or p.get("cushion_sl_activated") or p.get("cushion_protection_confirmed"):
                    trailing_label = "Đệm An Toàn Vốn (-0.25%)"
                elif raw_trailing == "active" or p.get("trailing_active"):
                    trailing_label = "Đang bám đỉnh (Trailing)"
                elif raw_trailing == "waiting_net_profit":
                    trailing_label = "Chờ mốc khóa lãi"
                else:
                    trailing_label = "Bảo vệ vốn an toàn"

                telemetry_data["positions"].append({
                    "symbol": str(p.get("symbol", "")),
                    "side": side,
                    "leverage": lev,
                    "amount": amt,
                    "entry_price": entry_p,
                    "mark_price": mark_p,
                    "margin": round(margin, 2),
                    "unrealized_pnl": round(upnl, 4),
                    "pnl_pct": round(pnl_pct, 2),
                    "stop_loss": float(p.get("stop_loss") or 0.0),
                    "take_profit": float(p.get("take_profit") or 0.0),
                    "trailing_status": trailing_label,
                    "trailing_active": bool(p.get("trailing_active", False)),
                    "time_sl_compressed": False
                })

            telemetry_data["unrealized_pnl"] = round(total_unrealized, 4)

            any_success = False
            for token in self.user_tokens:
                telemetry_data["user_token"] = token
                patch_url = f"{self.base_url}/bots_telemetry/{token}"
                doc_body = to_firestore_doc(telemetry_data)
                try:
                    res = requests.patch(patch_url, json=doc_body, timeout=5)
                    if res.status_code == 200:
                        any_success = True
                        try:
                            user_url = f"{self.base_url}/users/{token}?updateMask.fieldPaths=livePnl&updateMask.fieldPaths=totalPnl&updateMask.fieldPaths=assignedBalance"
                            user_body = to_firestore_doc({
                                "livePnl": daily_pnl,
                                "totalPnl": total_pnl,
                                "assignedBalance": balance
                            })
                            requests.patch(user_url, json=user_body, timeout=4)
                        except Exception:
                            pass
                except Exception as te:
                    logger.debug(f"Lỗi gửi telemetry cho token {token[:6]}...: {te}")

            return any_success

        except Exception as e:
            logger.debug(f"Lỗi push telemetry: {e}")
            return False

    def verify_license(self):
        """Kiểm tra bản quyền từ xa của Super Admin Lê Hoàng Đức."""
        if not self.user_tokens:
            # [SỬA LỖI GỐC RỄ] Trước đây thiếu token là dừng bot NGAY LẬP TỨC. Kết hợp với lỗi
            # đọc settings tạm thời ở _load_settings(), một lần antivirus khoá file cũng đủ
            # giết bot live đang gồng vị thế. Nay chỉ dừng khi tình trạng "không có token" được
            # xác nhận bền vững: >= 3 chu kỳ LIÊN TIẾP đọc cấu hình THÀNH CÔNG mà vẫn rỗng.
            empty_cycles = int(getattr(self, '_empty_token_cycles', 0) or 0)
            cached_reason = find_cached_license(self.root_dir, self.license_cache_ttl_days)
            if cached_reason:
                # Không có token trên đĩa nhưng vẫn còn bản quyền đã xác minh cục bộ:
                # KHÔNG được dừng bot live (một lần ghi settings lỗi không phải hành vi vi phạm).
                logger.warning(
                    "⚠️ [CLOUD SYNC] Chưa thấy User Token nhưng còn %s - KHÔNG dừng bot.",
                    cached_reason,
                )
                return True, "Dùng " + cached_reason
            if empty_cycles >= 3:
                self._enforce_stop_if_running("Chưa cấu hình User Token bản quyền TradeMatrix!")
                return False, "Chưa cấu hình token"
            logger.warning(
                "⚠️ [CLOUD SYNC] Chưa thấy User Token (xác nhận %d/3 chu kỳ) - tạm KHÔNG dừng bot.",
                empty_cycles,
            )
            return False, "Chưa cấu hình token (đang xác nhận)"

        verdict = verify_license_tokens(
            self.user_tokens, self.project_id, self.root_dir, self.license_cache_ttl_days
        )
        if verdict.get("approved"):
            self._last_license_explicit_refusal = False
            if verdict.get("source") == "cache":
                logger.warning("⚠️ [LICENSE] %s", verdict.get("reason"))
            return True, verdict.get("reason") or "Đã cấp quyền"

        reason = verdict.get("reason") or "Không xác minh được quyền sử dụng hợp lệ"
        self._last_license_explicit_refusal = bool(
            verdict.get("revoked") or verdict.get("explicit_refusal")
        )
        if self._last_license_explicit_refusal:
            self._enforce_stop_if_running(reason)
        # Không có token nào approved / không xác minh được dịch vụ: fail-closed.
        return False, reason

    def _enforce_stop_if_running(self, reason):
        try:
            r_status = requests.get(f"{self.api_base}/status", timeout=2)
            if r_status.status_code == 200 and r_status.json().get("is_running"):
                logger.warning(f"⛔ [KHÓA BẢN QUYỀN]: {reason}. Tiến hành dừng bot!")
                requests.post(f"{self.api_base}/stop", json={}, timeout=3)
        except Exception:
            pass

    def poll_and_execute_commands(self):
        """Lắng nghe lệnh điều khiển từ xa từ Firestore bot_commands/{token}"""
        if not self.user_tokens:
            return

        # [BOM #126C FIX]: Đồng bộ logic đa token với verify_license_tokens() — chỉ dừng bot khi
        # KHÔNG còn token nào khác được duyệt (tránh 1 token cũ bị thu hồi tắt lặp bot khi token 2 vẫn approved)!
        revoked_in_poll = []
        any_approved_in_poll = False
        pending_actions = []
        for token in self.user_tokens:
            try:
                cmd_url = f"{self.base_url}/bot_commands/{token}"
                res = requests.get(cmd_url, timeout=4)
                if res.status_code != 200:
                    continue

                cmd_doc = from_firestore_doc(res.json())
                command = cmd_doc.get("command")
                status = cmd_doc.get("status")
                license_status = str(cmd_doc.get("license_status", "")).lower()

                if license_status in ("revoked", "blocked"):
                    revoked_in_poll.append(token)
                    continue
                if license_status == "approved":
                    any_approved_in_poll = True

                if status == "pending" and command:
                    pending_actions.append((token, cmd_url, cmd_doc, command))
            except Exception as e:
                logger.debug(f"CloudSync poll error for {token}: {e}")

        if revoked_in_poll and not any_approved_in_poll:
            if len(self.user_tokens) <= 1:
                self._enforce_stop_if_running("Quyền sử dụng bot đã bị Admin thu hồi/khóa từ xa!")
                return
            try:
                ver_res = verify_license_tokens(
                    self.user_tokens,
                    project_id=self.project_id,
                    root_dir=self.root_dir,
                    ttl_days=self.license_cache_ttl_days,
                )
                if not ver_res.get("approved"):
                    self._enforce_stop_if_running("Quyền sử dụng bot đã bị Admin thu hồi/khóa từ xa!")
                    return
            except Exception:
                pass

        for token, cmd_url, cmd_doc, command in pending_actions:
            try:
                command_id = str(
                    cmd_doc.get('command_id')
                    or cmd_doc.get('id')
                    or cmd_doc.get('updatedAt')
                    or cmd_doc.get('updated_at')
                    or cmd_doc.get('created_at')
                    or f"{command}:{cmd_doc.get('symbol', '')}:{time.time()}"
                )
                last_for_token = (getattr(self, 'last_command_ids', None) or {}).get(token)
                if command_id == last_for_token:
                    continue
                # Claim trước side effect: nếu ACK sau đó lỗi, lệnh không còn pending
                # và không bị đóng/config lặp ở chu kỳ tiếp theo.
                claim_body = to_firestore_doc({'status': 'executing', 'command_id': command_id})
                claim_res = requests.patch(
                    with_update_mask(cmd_url, ['status', 'command_id']),
                    json=claim_body, timeout=4,
                )
                if claim_res.status_code != 200:
                    continue
                if not isinstance(getattr(self, 'last_command_ids', None), dict):
                    self.last_command_ids = {}
                self.last_command_ids[token] = command_id
                logger.info(f"⚡ Nhận lệnh từ xa cho [{token[:6]}...]: [{command.upper()}] (cmd_id: {command_id[:16]})")

                success = False
                msg = ""
                # [BOM #134 FIX]: Đọc license_status trực tiếp từ cmd_doc của token hiện tại thay vì biến vòng lặp từ Loop 1!
                cur_license_status = str(cmd_doc.get("license_status", "")).lower()

                if command == "status_update":
                    success = True
                    msg = f"Đã cập nhật trạng thái bản quyền: {cur_license_status.upper()}"

                elif command == "start":
                    # Kiểm tra bản quyền trước khi cho start
                    if cur_license_status in ("revoked", "blocked"):
                        success = False
                        msg = "Từ chối khởi động: Tài khoản đã bị khóa bởi Admin."
                    else:
                        licensed, reason = self.verify_license()
                        if not licensed:
                            success = False
                            msg = f"Từ chối khởi động: {reason}"
                        else:
                            try:
                                r = requests.post(f"{self.api_base}/start", json={}, timeout=30)
                                try:
                                    res_data = r.json() if r.status_code == 200 else {}
                                except Exception:
                                    res_data = {}
                                success = (r.status_code == 200) and res_data.get('success', True)
                                msg = res_data.get('message') or res_data.get('error') or r.text
                            except Exception as ce:
                                success = False
                                msg = f"Lỗi khởi động bot: {ce}"

                elif command == "stop":
                    try:
                        r = requests.post(f"{self.api_base}/stop", json={}, timeout=8)
                        try:
                            res_data = r.json() if r.status_code == 200 else {}
                        except Exception:
                            res_data = {}
                        success = (r.status_code == 200) and res_data.get('success', True)
                        msg = res_data.get('message') or res_data.get('error') or r.text
                    except Exception as ce:
                        success = False
                        msg = f"Lỗi dừng bot: {ce}"

                elif command == "run_cycle":
                    licensed, reason = self.verify_license()
                    if not licensed:
                        success = False
                        msg = f"Từ chối thực thi: {reason}"
                    else:
                        try:
                            r = requests.post(f"{self.api_base}/run_cycle", json={}, timeout=120)
                            try:
                                res_data = r.json() if r.status_code == 200 else {}
                            except Exception:
                                res_data = {}
                            success = (r.status_code == 200) and res_data.get('success', False)
                            msg = res_data.get('message') or res_data.get('error') or r.text
                        except Exception as ce:
                            success = False
                            msg = f"Lỗi chạy chu kỳ: {ce}"

                elif command == "update_config":
                    try:
                        responses = []
                        if "max_leverage" in cmd_doc:
                            responses.append(requests.post(f"{self.api_base}/leverage", json={"max_leverage": cmd_doc["max_leverage"]}, timeout=5))
                        if "max_open_trades" in cmd_doc:
                            responses.append(requests.post(f"{self.api_base}/positions_limit", json={"max_open_trades": cmd_doc["max_open_trades"]}, timeout=5))
                        if "auto_adopt_manual_positions" in cmd_doc:
                            responses.append(requests.post(f"{self.api_base}/manual_adopt/toggle", json={"enabled": bool(cmd_doc["auto_adopt_manual_positions"])}, timeout=5))
                        if "free_roll_recycling" in cmd_doc:
                            responses.append(requests.post(f"{self.api_base}/free_roll_recycling/toggle", json={"enabled": bool(cmd_doc["free_roll_recycling"])}, timeout=5))
                        if "tradfi_enabled" in cmd_doc or "only_tradfi" in cmd_doc:
                            payload = {}
                            if "tradfi_enabled" in cmd_doc:
                                payload["enabled"] = bool(cmd_doc["tradfi_enabled"])
                            if "only_tradfi" in cmd_doc:
                                payload["only_tradfi"] = bool(cmd_doc["only_tradfi"])
                            responses.append(requests.post(f"{self.api_base}/tradfi/toggle", json=payload, timeout=5))
                        success = bool(responses) and all(r.status_code == 200 for r in responses)
                        msg = " | ".join(r.text[:160] for r in responses) if responses else "Không có trường cấu hình hợp lệ"
                        time.sleep(0.3)
                        self.push_telemetry()
                    except Exception as ce:
                        success = False
                        msg = f"Lỗi cập nhật cấu hình: {ce}"

                elif command in ("toggle_manual_adopt", "set_manual_adopt"):
                    enabled = bool(cmd_doc.get("enabled", False))
                    try:
                        r = requests.post(f"{self.api_base}/manual_adopt/toggle", json={"enabled": enabled}, timeout=5)
                        success = r.status_code == 200
                        msg = r.text
                        time.sleep(0.3)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                elif command in ("toggle_free_roll_recycling", "set_free_roll_recycling"):
                    enabled = bool(cmd_doc.get("enabled", True))
                    try:
                        r = requests.post(f"{self.api_base}/free_roll_recycling/toggle", json={"enabled": enabled}, timeout=5)
                        success = r.status_code == 200
                        msg = r.text
                        time.sleep(0.3)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                elif command == "toggle_tradfi":
                    payload = {}
                    if "enabled" in cmd_doc:
                        payload["enabled"] = bool(cmd_doc["enabled"])
                    if "only_tradfi" in cmd_doc:
                        payload["only_tradfi"] = bool(cmd_doc["only_tradfi"])
                    try:
                        r = requests.post(f"{self.api_base}/tradfi/toggle", json=payload, timeout=5)
                        success = r.status_code == 200
                        msg = r.text
                        time.sleep(0.3)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                elif command == "close_position":
                    symbol = cmd_doc.get("symbol")
                    direction = cmd_doc.get("direction")
                    try:
                        payload = {"symbol": symbol}
                        if direction:
                            payload["direction"] = direction
                        r = requests.post(f"{self.api_base}/positions/close", json=payload, timeout=25)
                        try:
                            res_data = r.json() if r.status_code == 200 else {}
                        except Exception:
                            res_data = {}
                        success = (r.status_code == 200) and res_data.get('success', False)
                        msg = res_data.get('message') or res_data.get('error') or r.text
                    except Exception as ce:
                        success = False
                        msg = str(ce)

                elif command == "emergency_close":
                    # Đóng toàn bộ các lệnh đang mở
                    try:
                        r_pos = requests.get(f"{self.api_base}/positions", timeout=3)
                        if r_pos.status_code != 200:
                            success = False
                            msg = f"Không lấy được danh sách vị thế (HTTP {r_pos.status_code})"
                        else:
                            positions = r_pos.json()
                            if not isinstance(positions, list):
                                success = False
                                msg = "Dữ liệu vị thế trả về không hợp lệ"
                            elif not positions:
                                success = True
                                msg = "Không có vị thế mở để đóng"
                            else:
                                closed_n = 0
                                failed_msgs = []
                                for p in positions:
                                    p_sym = p.get("symbol")
                                    p_dir = p.get("direction") or p.get("side")
                                    c_payload = {"symbol": p_sym}
                                    if p_dir:
                                        p_dir_u = str(p_dir).upper()
                                        if p_dir_u in ("BUY", "LONG"):
                                            c_payload["direction"] = "LONG"
                                        elif p_dir_u in ("SELL", "SHORT"):
                                            c_payload["direction"] = "SHORT"
                                    r_c = requests.post(f"{self.api_base}/positions/close", json=c_payload, timeout=25)
                                    try:
                                        rc_data = r_c.json() if r_c.status_code == 200 else {}
                                    except Exception:
                                        rc_data = {}
                                    if r_c.status_code == 200 and rc_data.get("success", False):
                                        closed_n += 1
                                    else:
                                        err_t = rc_data.get("error") or rc_data.get("message") or f"HTTP {r_c.status_code}"
                                        failed_msgs.append(f"{p_sym}: {err_t}")
                                success = (len(failed_msgs) == 0)
                                msg = (
                                    f"Đã đóng an toàn {closed_n}/{len(positions)} vị thế"
                                    if success
                                    else f"Đóng {closed_n}/{len(positions)} vị thế; lỗi: {'; '.join(failed_msgs[:3])}"
                                )
                    except Exception as ce:
                        success = False
                        msg = str(ce)

                # ⚡ [TỐC ĐỘ CAO] Xác nhận hoàn tất lệnh NGAY LẬP TỨC cho Web Dashboard
                ack_body = to_firestore_doc({
                    "command": command,
                    "command_id": command_id,
                    "status": "completed" if success else "failed",
                    "result_message": str(msg),
                    "executed_at": datetime.now().strftime("%H:%M:%S %d/%m")
                })
                try:
                    requests.patch(
                        with_update_mask(
                            cmd_url,
                            ['command', 'command_id', 'status', 'result_message', 'executed_at'],
                        ),
                        json=ack_body, timeout=4,
                    )
                except Exception as ack_err:
                    logger.debug("Lỗi gửi ACK: %s", ack_err)
                logger.info(f"✅ Hoàn tất thi hành lệnh [{command.upper()}] (status: {'completed' if success else 'failed'}) cho [{token[:6]}...]")

                # Đẩy Telemetry ngay sau khi ACK để Web cập nhật danh sách vị thế mới
                try:
                    self.push_telemetry()
                except Exception:
                    pass

            except Exception as e:
                logger.debug(f"Lỗi kiểm tra lệnh từ xa cho token {token[:6]}: {e}")

    def run_loop(self):
        """Vòng lặp chạy nền độc lập."""
        import socket
        import os
        current_host = socket.gethostname()
        if "DESKTOP-14H1SF7" in current_host and not os.getenv("FORCE_DEV_CLOUD_SYNC"):
            logger.info("🛡️ [DEV MACHINE DETECTED] Máy PC1 (%s) là môi trường Dev. Tự động vô hiệu hóa Cloud Sync để bảo vệ máy Live PC2 24/24 độc quyền đẩy dữ liệu lên Web.", current_host)
            return

        logger.info("🌐 Cloud Sync Service khởi động (%d token, không in secrets).", len(self.user_tokens or []))
        last_telemetry_time = 0.0
        last_cmd_poll_time = 0.0
        last_settings_reload_time = 0.0
        while True:
            try:
                now = time.time()
                # Tự động nạp lại config mỗi 5s nếu user đổi token trên giao diện web local
                # [SỬA LỖI GỐC RỄ] Chỉ thay cấu hình khi đọc THÀNH CÔNG. Nếu file đang bị khoá/ghi dở,
                # giữ nguyên token + settings tốt gần nhất và bỏ qua chu kỳ, tuyệt đối không zeroing token.
                if (now - last_settings_reload_time) >= 5.0:
                    last_settings_reload_time = now
                    reloaded = self._load_settings()
                    if reloaded is not None:
                        self.settings = reloaded
                        cloud_cfg = self.settings.get("cloud") or {}
                        self.enabled = bool(cloud_cfg.get("enabled", True))
                        if not self.enabled:
                            # Tắt cloud phải dừng cả telemetry, license polling và remote commands.
                            time.sleep(self.sync_interval)
                            continue
                        _old_tokens = list(getattr(self, 'user_tokens', []) or [])
                        self.user_tokens = self._parse_tokens(cloud_cfg.get("user_token", ""))
                        self.user_token = self.user_tokens[0] if self.user_tokens else ""
                        # [BOM #125D + BOM #126C FIX]: Đọc đúng khóa `project_id` (khớp __init__ & settings.yaml),
                        # hỗ trợ TTL dạng float >= 0.0 (kể cả 0 để tắt cache) và xóa cache bản quyền khi đổi token HOẶC project_id!
                        _old_pid = self.project_id
                        _new_pid = str(cloud_cfg.get("project_id") or cloud_cfg.get("firebase_project_id") or self.project_id or "").strip()
                        if _new_pid and _new_pid != self.project_id:
                            self.project_id = _new_pid
                            self.base_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents"
                        try:
                            _new_si = float(cloud_cfg.get("sync_interval_seconds") or self.sync_interval)
                            if _new_si >= 1.0:
                                self.sync_interval = _new_si
                        except (TypeError, ValueError):
                            pass
                        try:
                            _raw_ttl = cloud_cfg.get("license_cache_ttl_days")
                            if _raw_ttl is not None and _raw_ttl != "":
                                _new_ttl = float(_raw_ttl)
                                if _new_ttl >= 0.0:
                                    self.license_cache_ttl_days = _new_ttl
                        except (TypeError, ValueError):
                            pass
                        if (self.user_tokens != _old_tokens) or (self.project_id != _old_pid):
                            self._cached_licensed = None
                            self._last_license_check_time = 0.0
                if not self.enabled:
                    time.sleep(self.sync_interval)
                    continue

                now = time.time()
                if self.user_tokens:
                    self._empty_token_cycles = 0
                    # [TỐI ƯU CAO CẤP] Cache bản quyền trong 60 giây, triệt tiêu 100% độ trễ GET Firestore mỗi giây
                    if (now - getattr(self, '_last_license_check_time', 0.0)) >= 60.0 or getattr(self, '_cached_licensed', None) is None:
                        licensed, reason = self.verify_license()
                        self._cached_licensed = licensed
                        self._cached_license_reason = reason
                        self._last_license_check_time = now
                    else:
                        licensed = self._cached_licensed
                        reason = self._cached_license_reason

                    if licensed:
                        # Kiểm tra và thi hành lệnh từ xa mỗi 3s (giảm tải Firestore GET dư thừa)
                        if (now - last_cmd_poll_time) >= 3.0:
                            self.poll_and_execute_commands()
                            last_cmd_poll_time = now

                        # Đẩy dữ liệu Telemetry định kỳ mỗi sync_interval (~5s)
                        if (now - last_telemetry_time) >= self.sync_interval:
                            self.push_telemetry()
                            last_telemetry_time = now
                    elif getattr(self, '_last_license_explicit_refusal', False):
                        self._enforce_stop_if_running(
                            reason or "Quyền sử dụng đã bị Admin thu hồi/khóa từ xa!"
                        )
                else:
                    if (now - last_cmd_poll_time) >= 3.0:
                        last_cmd_poll_time = now
                        self._empty_token_cycles = int(getattr(self, '_empty_token_cycles', 0) or 0) + 1
                        self.verify_license()
            except Exception as loop_err:
                logger.error("Lỗi tạm thời trong CloudSyncWorker.run_loop (tự phục hồi sau 3s): %s", loop_err)
                time.sleep(3.0)
                continue

            time.sleep(0.5)

def start_cloud_sync_thread(root_dir=None, api_port=5000):
    import threading
    worker = CloudSyncWorker(root_dir=root_dir, api_port=api_port)
    t = threading.Thread(target=worker.run_loop, daemon=True, name="CloudSyncWorker")
    t.start()
    return worker

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    worker = CloudSyncWorker()
    worker.run_loop()

