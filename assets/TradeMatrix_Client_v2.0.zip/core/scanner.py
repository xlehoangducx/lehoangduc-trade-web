import logging
import threading
import time as _time
from typing import List, Dict, Optional, Set

logger = logging.getLogger(__name__)

class MarketScanner:
    """
    Quét toàn bộ thị trường để tìm ra các cặp giao dịch tiềm năng nhất.
    Quy trình: Tìm kiếm -> So sánh -> Chọn lọc danh sách ngắn.
    Hỗ trợ cơ chế kép (Dual-Engine): Crypto & TradFi Stock Perps (Biệt lập hoàn toàn).
    Hỗ trợ 3 chế độ:
    - Thuần Crypto (enabled=False, only_tradfi=False)
    - Cả Hai song song (enabled=True, only_tradfi=False)
    - Chỉ Cổ phiếu Mỹ (only_tradfi=True)
    """
    _insufficient_data_cooldowns: Dict[str, float] = {}
    _insufficient_data_lock = threading.Lock()

    @classmethod
    def mark_insufficient_data(cls, symbol: str, cooldown_seconds: float = 3600.0):
        """Cách ly tạm thời các hợp đồng mới lên sàn/thiếu nến lịch sử (như PREDICT/USDT) để không chiếm slot Top 50."""
        if not symbol:
            return
        clean = str(symbol).split(':')[0].replace('/', '').strip().upper()
        with cls._insufficient_data_lock:
            cls._insufficient_data_cooldowns[clean] = _time.time() + cooldown_seconds

    @classmethod
    def is_insufficient_data_cooled(cls, symbol: str) -> bool:
        if not symbol:
            return False
        clean = str(symbol).split(':')[0].replace('/', '').strip().upper()
        with cls._insufficient_data_lock:
            exp = cls._insufficient_data_cooldowns.get(clean, 0.0)
            if exp > 0 and _time.time() < exp:
                return True
            if exp > 0:
                cls._insufficient_data_cooldowns.pop(clean, None)
        return False
    # Danh mục 10 Phân Lớp Toàn Diện 100% Mã TradFi Trên Binance (SSOT Exhaustive 247/247 Mã - Zero Ellipsis)
    SECTOR_MAP = {
        'SEMICONDUCTOR': {
            'NVDA', 'NVDL', 'NVDD', 'AMD', 'AVGO', 'ASML', 'AMAT', 'MU', 'MUU', 'INTC', 'MRVL', 'MVLL', 'TSM', 'QCOM', 'LRCX',
            'ARM', 'SMCI', 'STM', 'TER', 'TXN', 'WDC', 'KLAC', 'ALAB', 'APLD', 'AXTI', 'COHR', 'CRDO', 'GIGADEV',
            'MP', 'ONDS', 'SNDK', 'SNPS', 'SNXX', 'SKHYNIX', 'SKHY', 'SKUU', 'SKDD', 'SAMSUNG', 'SAMSUNGEM',
            'CSOPSAMSUNG2L', 'CSOPSKHYNIX2L', 'HANMI', 'DRAM', 'CXMT', 'SECZ', 'AAOI', 'ZHONGJI', 'GLW', 'CIEN',
            'FLEX', 'AGPU', 'SMH', 'SOXL', 'SOXS'
        },
        'NASDAQ_TECH': {
            'QQQ', 'TQQQ', 'SQQQ', 'AAPL', 'MSFT', 'AMZN', 'GOOGL', 'META', 'NFLX', 'PLTR', 'CRM', 'ORCL', 'ADBE',
            'PANW', 'CRWD', 'SNOW', 'DDOG', 'CSCO', 'IBM', 'NOW', 'TEAM', 'PATH', 'MDB', 'NET', 'ZS', 'ZM', 'SHOP',
            'UBER', 'RDDT', 'OPENAI', 'ANTHROPIC', 'MINIMAX', 'MOONSHOT', 'ZHIPU', 'ANET', 'AKAM', 'GTLB', 'TTWO',
            'CYPH', 'APP', 'MELI', 'EBAY', 'PYPL', 'PAYP', 'TWST', 'CRWV', 'CRML', 'RAM', 'SHAZ', 'ACN', 'INTW',
            'TEM', 'IONQ', 'RUM'
        },
        'ASIAN_TECH': {
            'BABA', 'PDD', 'MEITUAN', 'TENCENT', 'KUAISHOU', 'HK0700', 'HK1810', 'HK0992', 'HK0625', 'NAVER',
            'LGELECTRONICS', 'SONY', 'KSTR'
        },
        'AI_INFRA_ENERGY': {
            'VST', 'CEG', 'OKLO', 'SMR', 'VRT', 'BE', 'FLNC', 'URNM'
        },
        'CRYPTO_PROXY': {
            'MSTR', 'MSTU', 'MSTX', 'MSTZ', 'COIN', 'CONL', 'BITO', 'MARA', 'IREN', 'HUT', 'BMNR', 'CBRS', 'CRCL'
        },
        'EV_AEROSPACE': {
            'TSLA', 'TSLL', 'TSLS', 'RIVN', 'BYD', 'NIO', 'HYUNDAI', 'UNITREE', 'RKLB', 'ASTS', 'RDW'
        },
        'COMMODITY_METALS': {
            'XAU', 'GOLD', 'PAXG', 'XAG', 'SILVER', 'PLAT', 'XPT', 'PLATINUM', 'PALL', 'XPD', 'PALLADIUM',
            'COPPER', 'CPR', 'HG', 'GDX', 'GLD', 'SLV', 'NUGT', 'DUST', 'ALUMINIUM', 'NICKEL', 'NI', 'ZINC', 'ZN', 'LEAD', 'PB',
            'TIN', 'SN', 'URANIUM', 'URA'
        },
        'COMMODITY_ENERGY': {
            'CL', 'CRUDE', 'OIL', 'WTI', 'USO', 'BZ', 'BRENT', 'NATGAS', 'NG', 'GAS_US', 'BOIL', 'KOLD',
            'XOM', 'OXY', 'XLE', 'EQT',
            'WHEAT', 'CORN', 'SOYBEAN', 'SOY', 'SUGAR', 'COFFEE', 'COTTON', 'COCOA'
        },
        'BROAD_INDEX': {
            'UPRO', 'SPXU', 'SPCX', 'UDOW', 'SDOW', 'IWM', 'TNA', 'TZA', 'UVXY', 'SPY', 'TBT', 'TMF',
            'TECL', 'TECS', 'YINN', 'YANG', 'FAS', 'FAZ', 'LABU', 'LABD', 'USDEX', 'USDBRL', 'ALL',
            'EWJ', 'EWT', 'EWY', 'EWZ', 'EWZS', 'EIDO', 'KORU', 'KODEX200', 'STXX', 'PREDICT'
        },
        'TRADITIONAL_VALUE': {
            'LLY', 'NVO', 'PFE', 'ABBV', 'AMGN', 'MRNA', 'VKTX', 'HIMS', 'MDT', 'XBI', 'UNH', 'MRK',
            'JPM', 'GS', 'BAC', 'V', 'HOOD', 'IBKR', 'BX', 'BRKB', 'SOFI', 'CAT', 'GEV', 'DELL', 'HPE',
            'WMT', 'COST', 'KO', 'MCD', 'DIS', 'NKE', 'LITE', 'POPMART', 'DJT', 'AMC', 'GME', 'WEN',
            'HD', 'CVNA', 'DKNG', 'GPRO', 'NOK', 'BBX', 'BNC', 'BSP', 'BWET', 'FWDI', 'LYTE', 'NBIS',
            'OURA', 'QNTX', 'STRC', 'USAR', 'ZCSH'
        }
    }

    # Cặp đối nghịch 1-1 trực tiếp (Direct Inverse Bear/Bull pairs) — [BOM #126B + #147 FIX]: đồng bộ đủ & đối xứng!
    DIRECT_INVERSES = {
        'SOXL': 'SOXS', 'SOXS': 'SOXL',
        'TQQQ': 'SQQQ', 'SQQQ': 'TQQQ',
        'UPRO': 'SPXU', 'SPXU': 'UPRO', 'SPCX': 'UPRO',
        'UDOW': 'SDOW', 'SDOW': 'UDOW',
        'IWM': 'TZA', 'TNA': 'TZA', 'TZA': 'IWM',
        'YINN': 'YANG', 'YANG': 'YINN',
        'TECL': 'TECS', 'TECS': 'TECL',
        'LABU': 'LABD', 'LABD': 'LABU',
        'FAS': 'FAZ', 'FAZ': 'FAS',
        'BOIL': 'KOLD', 'KOLD': 'BOIL',
        'NUGT': 'DUST', 'DUST': 'NUGT',
        'TMF': 'TBT', 'TBT': 'TMF',
        'NVDL': 'NVDD', 'NVDD': 'NVDL',
        'TSLL': 'TSLS', 'TSLS': 'TSLL',
        'MSTU': 'MSTZ', 'MSTX': 'MSTZ', 'MSTZ': 'MSTU',
        'SKUU': 'SKDD', 'SKDD': 'SKUU',
    }

    # Cặp cổ phiếu cơ sở và ETF đòn bẩy đơn cùng gốc (Leveraged vs Underlying pairs)
    LEVERAGED_PAIRS = {
        'NVDL': 'NVDA',
        'NVDD': 'NVDA',
        'TSLL': 'TSLA',
        'TSLS': 'TSLA',
        'MSTU': 'MSTR',
        'MSTX': 'MSTR',
        'MSTZ': 'MSTR',
        'CONL': 'COIN',
        'MUU': 'MU',
        'MVLL': 'MRVL',
        'SNXX': 'SNDK',
        'SKUU': 'SKHY',
        'SKDD': 'SKHY',
        'SOXLB': 'SOXL',
        'CSOPSAMSUNG2L': 'SAMSUNG',
        'CSOPSKHYNIX2L': 'SKHYNIX'
    }
    SAME_UNDERLYING_ASSETS = LEVERAGED_PAIRS

    # Benchmark dẫn dắt theo ngành (Sector Leader Benchmarks)
    BENCHMARK_LEADERS = {
        'SEMICONDUCTOR': 'SOXL',
        'NASDAQ_TECH': 'QQQ',
        'BROAD_INDEX': 'SPY',
        'CRYPTO_PROXY': 'BTC',
        'EV_AEROSPACE': 'TSLA',
        'COMMODITY_METALS': 'XAU',
        'COMMODITY_ENERGY': 'CL',
        'AI_INFRA_ENERGY': 'QQQ',
        'ASIAN_TECH': 'QQQ',
        'TRADITIONAL_VALUE': 'SPY'
    }

    # [BOM #150 P1 FIX]: Nhóm tài sản không tương quan với SPY/CL/XAU -> tự thẩm định trên 4H/1H của chính mình (self-benchmark = None)
    UNCORRELATED_SELF_BENCHMARK_BASES = frozenset({
        'TMF', 'TLT', 'BOIL', 'UNG', 'NATGAS', 'NG', 'GAS_US',
        'YINN', 'FXI', 'EEM', 'EWJ', 'EWT', 'EWY', 'EWZ', 'EWZS', 'EIDO', 'KORU', 'KODEX200', 'STXX',
        'USDEX', 'USDBRL', 'WHEAT', 'CORN', 'SOYBEAN', 'SOY', 'SUGAR', 'COFFEE', 'COTTON', 'COCOA',
        'COPPER', 'CPR', 'HG', 'URANIUM', 'URA', 'ALUMINIUM', 'NICKEL', 'NI', 'ZINC', 'ZN', 'LEAD', 'PB', 'TIN', 'SN',
    })

    # Danh mục cơ sở TradFi Toàn diện (Tổng hợp 10 Phân Lớp - 247 mã đầy đủ)
    KNOWN_TRADFI_BASES = {base for members in SECTOR_MAP.values() for base in members}

    # Danh mục cơ sở Hàng hóa Toàn diện (Precious Metals, Energy, Industrial Metals, Agriculture)
    KNOWN_COMMODITY_BASES = {
        # Kim loại quý (Precious Metals)
        'XAU', 'GOLD', 'PAXG',
        'XAG', 'SILVER',
        'XPT', 'PLATINUM', 'PLAT',
        'XPD', 'PALLADIUM', 'PALL',
        # Năng lượng & Dầu khí (Energy & Petroleum)
        'CL', 'CRUDE', 'OIL', 'WTI',
        'BZ', 'BRENT',
        'NATGAS', 'NG', 'GAS_US',
        # Kim loại công nghiệp (Industrial Metals) — [BOM #145/#148]: thêm HG (Copper Futures), bỏ ALU/ALI (trùng Crypto)
        'COPPER', 'CPR', 'HG',
        'ALUMINIUM',
        'NICKEL', 'NI',
        'ZINC', 'ZN',
        'LEAD', 'PB',
        'TIN', 'SN',
        'URANIUM', 'URA',
        # Nông sản & Hàng hóa mềm (Agriculture / Soft Commodities)
        'WHEAT', 'CORN', 'SOYBEAN', 'SOY',
        'SUGAR', 'COFFEE', 'COTTON', 'COCOA'
    }

    # [BOM #124B + #140 FIX]: Ngoai le Crypto trung ticker Co phieu/Hang hoa TradFi (ON, BOT, PENG, ALU, ALI)
    CRYPTO_TICKER_EXCLUSIONS = {'ON', 'BOT', 'PENG', 'ALU', 'ALI'}

    _default_exchange = None
    _last_markets_reload_ts = 0.0
    _markets_reload_lock = threading.Lock()

    @classmethod
    def _find_market_entry(cls, symbol: str, clean: str, base: str, exchange=None) -> Optional[Dict]:
        """Tra cứu metadata thị trường Binance có khóa Lock đa luồng khi reload (BOM #115F)."""
        eff_exchange = exchange or getattr(cls, '_default_exchange', None)
        if not (eff_exchange and hasattr(eff_exchange, 'exchange')):
            return None
        ex = eff_exchange.exchange
        raw_id = clean.replace('/', '').replace(':', '')
        ccxt_sym = symbol if ':' in symbol else (f"{clean}:{clean.split('/')[1]}" if '/' in clean else f"{base}/USDT:USDT")

        def _pick():
            mkts = getattr(ex, 'markets', {}) or {}
            mkts_id = getattr(ex, 'markets_by_id', {}) or {}
            found = (
                mkts.get(ccxt_sym)
                or mkts.get(clean)
                or mkts.get(f"{base}/USDT:USDT")
                or mkts.get(f"{base}/USDT")
                or mkts_id.get(raw_id)
            )
            return found[0] if (isinstance(found, list) and found) else found

        m = _pick()
        if not m and hasattr(ex, 'load_markets'):
            with cls._markets_reload_lock:
                m = _pick()
                now_ts = _time.time()
                if not m and now_ts - cls._last_markets_reload_ts > 300.0:
                    from core.exchange import get_ip_ban_remaining_seconds, _extract_and_activate_ip_ban
                    if get_ip_ban_remaining_seconds() <= 0:
                        cls._last_markets_reload_ts = now_ts
                        try:
                            ex.load_markets(reload=True)
                            m = _pick()
                        except Exception as _e_lm:
                            _extract_and_activate_ip_ban(_e_lm)
        return m

    def __init__(self, exchange_connector):
        self.exchange = exchange_connector
        MarketScanner._default_exchange = exchange_connector

    @classmethod
    def _clean_base(cls, symbol: str) -> str:
        if not symbol:
            return ''
        clean = symbol.split(':')[0].upper()
        base = clean.split('/')[0] if '/' in clean else clean
        if '/' not in clean:
            for q in ('USDT', 'USDC', 'BUSD', 'USD'):
                if base.endswith(q) and len(base) > len(q):
                    base = base[:-len(q)]
                    break
        return base

    @classmethod
    def _canonical_tradfi_base(cls, symbol: str) -> str:
        """[BOM #89 FIX]: Chuan hoa ma TradFi co duoi *B (NVDAB->NVDA, TSLAB->TSLA, AAPLB->AAPL, SOXLB->SOXL)
        de SECTOR_MAP / DIRECT_INVERSES / LEVERAGED_PAIRS / UNMAPPED TRADFI GUARD khop 100%."""
        base = cls._clean_base(symbol)
        if base and base not in cls.KNOWN_TRADFI_BASES and base.endswith('B') and base[:-1] in cls.KNOWN_TRADFI_BASES:
            return base[:-1]
        return base

    @classmethod
    def get_tradfi_sector(cls, symbol: str) -> Optional[str]:
        """Xác định phân lớp ngành TradFi (10 Phân lớp SSOT Exhaustive)."""
        base = cls._canonical_tradfi_base(symbol)
        # [BOM #145 FIX]: Luôn chặn CRYPTO_TICKER_EXCLUSIONS kể cả khi _default_exchange is None (offline/simulator)
        if not base or base in cls.CRYPTO_TICKER_EXCLUSIONS:
            return None
        if getattr(cls, '_default_exchange', None) is not None and not cls.is_tradfi_symbol(symbol):
            return None
        for sector, members in cls.SECTOR_MAP.items():
            if base in members:
                return sector
        return None

    @classmethod
    def get_tradfi_inverse_pair(cls, symbol: str) -> Optional[str]:
        """Lấy cặp nghịch đảo 1-1 trực tiếp (SOXL <-> SOXS, TQQQ <-> SQQQ, UPRO <-> SPXU)."""
        base = cls._canonical_tradfi_base(symbol)
        inv = cls.DIRECT_INVERSES.get(base)
        return f"{inv}/USDT" if inv else None

    @classmethod
    def get_tradfi_inverse_pairs(cls, symbol: str) -> List[str]:
        """[BOM #149 P2 FIX]: Trả về TẤT CẢ các mã nghịch đảo trực tiếp đối xứng 2 chiều (vd TZA -> [IWM/USDT, TNA/USDT], MSTZ -> [MSTU/USDT, MSTX/USDT], UPRO -> [SPXU/USDT, SPCX/USDT])."""
        base = cls._canonical_tradfi_base(symbol)
        if not base:
            return []
        found = []
        primary = cls.DIRECT_INVERSES.get(base)
        if primary:
            found.append(f"{primary}/USDT")
        for k, v in cls.DIRECT_INVERSES.items():
            if v == base and k != base:
                pair_s = f"{k}/USDT"
                if pair_s not in found:
                    found.append(pair_s)
        return found

    @classmethod
    def get_same_underlying_asset(cls, symbol: str) -> Optional[str]:
        """Lấy cổ phiếu gốc của ETF đòn bẩy đơn (NVDL -> NVDA, TSLL -> TSLA, MSTU -> MSTR, SOXLB -> SOXL)."""
        raw_base = cls._clean_base(symbol)
        underlying = cls.LEVERAGED_PAIRS.get(raw_base)
        if not underlying:
            base = cls._canonical_tradfi_base(symbol)
            underlying = cls.LEVERAGED_PAIRS.get(base)
        return f"{underlying}/USDT" if underlying else None

    @classmethod
    def get_lead_asset(cls, symbol: str) -> Optional[str]:
        """
        Xác định Con Đầu Đàn / Benchmark dẫn dắt:
        - ETF đòn bẩy đơn -> Mã cơ sở (NVDL -> NVDA, TSLL -> TSLA, MSTU -> MSTR)
        - Bear ETF -> Bull Benchmark (SOXS -> SOXL, SQQQ -> TQQQ, SPXU -> UPRO, TZA -> IWM)
        - Cổ phiếu thành viên -> Sector Benchmark (AMD -> SOXL, AAPL -> QQQ, MSTR -> BTC)
        - Bull Benchmark (SOXL, QQQ, SPY, BTC) -> None (chính nó là con đầu đàn, tự thẩm định trend)
        """
        base = cls._canonical_tradfi_base(symbol)
        if base in cls.LEVERAGED_PAIRS:
            return f"{cls.LEVERAGED_PAIRS[base]}/USDT"
        # CHỈ Bear Inverse ETF mới lấy mã Bull làm lead_asset (SOXS -> SOXL)
        # TUYỆT ĐỐI KHÔNG để Bull ETF trỏ ngược về Bear ETF (SOXL -> SOXS) gây nghịch đảo phán đoán!
        if cls.is_bear_inverse_etf(symbol):
            if base in cls.DIRECT_INVERSES:
                return f"{cls.DIRECT_INVERSES[base]}/USDT"
        # [BOM #150 P1 FIX]: Không ép các ETF/hàng hóa độc lập (TMF/BOIL/YINN/NATGAS/Nông sản/Kim loại CN) mượn benchmark SPY/CL/XAU không tương quan!
        if base in cls.UNCORRELATED_SELF_BENCHMARK_BASES:
            return None
        sector = cls.get_tradfi_sector(symbol)
        if sector and sector in cls.BENCHMARK_LEADERS:
            bm = cls.BENCHMARK_LEADERS[sector]
            if bm != base:
                return f"{bm}/USDT"
        return None

    @classmethod
    def get_inverse_pair(cls, symbol: str):
        """Alias an toan cho get_tradfi_inverse_pair."""
        return cls.get_tradfi_inverse_pair(symbol)

    @classmethod
    def get_same_underlying_pairs(cls, symbol: str):
        """Alias an toan cho get_same_underlying_asset (tra ve list)."""
        asset = cls.get_same_underlying_asset(symbol)
        return [asset] if asset else []

    @classmethod
    def is_tradfi_symbol(cls, symbol: str, exchange=None) -> bool:
        """Kiem tra xem co phai la Stock hoac Commodity TradFi khong."""
        return cls.is_tradfi_stock(symbol, exchange) or (hasattr(cls, 'is_tradfi_commodity') and cls.is_tradfi_commodity(symbol, exchange))

    @classmethod
    def is_bear_inverse_etf(cls, symbol: str) -> bool:
        """Kiểm tra xem có phải là ETF nghịch đảo / Bear ETF (SOXS, SQQQ, SPXU, SPCX, TZA, SKDD, TBT, NVDD, TSLS, MSTZ)."""
        base = cls._canonical_tradfi_base(symbol)
        return base in ('SOXS', 'SQQQ', 'SPXU', 'SPCX', 'TZA', 'UVXY', 'SDOW', 'YANG', 'KOLD', 'DUST', 'FAZ', 'TECS', 'LABD', 'SKDD', 'TBT', 'NVDD', 'TSLS', 'MSTZ')

    @classmethod
    def get_etf_leverage_tier(cls, symbol: str) -> int:
        """[BOM #145 SSOT]: Trả về bậc đòn bẩy ETF chuẩn duy nhất toàn hệ thống (3 = 3x, 2 = 2x, 1 = 1x/thường)."""
        base = cls._canonical_tradfi_base(symbol)
        if not base or base in cls.CRYPTO_TICKER_EXCLUSIONS:
            return 1
        if base in (
            'SOXL', 'SOXLB', 'SOXS', 'TQQQ', 'SQQQ', 'UPRO', 'SPXU', 'SPCX',
            'UDOW', 'SDOW', 'TNA', 'TZA', 'YINN', 'YANG', 'TECL', 'TECS',
            'LABU', 'LABD', 'FAS', 'FAZ', 'KORU', 'TMF',
        ):
            return 3
        if base in cls.LEVERAGED_PAIRS or base in (
            'NVDL', 'NVDD', 'TSLL', 'TSLS', 'MSTU', 'MSTX', 'MSTZ', 'CONL',
            'MUU', 'MVLL', 'SNXX', 'SKUU', 'SKDD', 'UVXY', 'BOIL', 'KOLD', 'NUGT', 'DUST', 'TBT',
            'CSOPSAMSUNG2L', 'CSOPSKHYNIX2L',
        ):
            return 2
        return 1

    @classmethod
    def is_leveraged_etf(cls, symbol: str) -> bool:
        """[BOM #28 + #145 SSOT] Kiểm tra ETF đòn bẩy 2x/3x (cả Bull & Bear ETF) đồng bộ 100% toàn hệ thống."""
        return cls.get_etf_leverage_tier(symbol) >= 2 or cls.is_bear_inverse_etf(symbol)

    @classmethod
    def is_tradfi_stock(cls, symbol: str, exchange=None) -> bool:
        """
        Kiểm tra xem cặp giao dịch có phải là Hợp đồng Cổ phiếu Mỹ / Chỉ số / ETF (TradFi Stock Perp) hay không.
        Tách biệt hoàn toàn với Hàng hóa TradFi (XAU, XAG, CL...) để Hàng hóa giao dịch 24/5 không bị khóa bởi phiên Wall Street.
        """
        if not symbol:
            return False
        clean = symbol.split(':')[0].upper()
        base = clean.split('/')[0] if '/' in clean else clean
        if '/' not in clean:
            for q in ('USDT', 'USDC', 'BUSD', 'USD'):
                if base.endswith(q) and len(base) > len(q):
                    base = base[:-len(q)]
                    break

        # 1. Loại trừ ngay lập tức Hàng hóa TradFi (XAU/XAG/CL/BZ) & Chỉ số Crypto 24/7 (BTCDOM/DEFI) TRƯỚC check TRADIFI_PERPETUAL!
        if base in cls.KNOWN_COMMODITY_BASES or base in ('BTCDOM', 'DEFI'):
            return False

        # 2. ƯU TIÊN KIỂM TRA ĐỘNG TỪ METADATA BINANCE FUTURES (tránh Crypto trùng ticker như ON/USDT)
        m = cls._find_market_entry(symbol, clean, base, exchange=exchange)
        if m:
            info = m.get('info', {})
            underlying = str(info.get('underlyingType') or '').upper()
            contract = str(info.get('contractType') or '').upper()
            subtypes = [str(s).upper() for s in (info.get('underlyingSubType') or [])]
            if underlying == 'COMMODITY' or 'COMMODITY' in subtypes:
                return False
            if underlying == 'COIN' and 'TRADFI' not in subtypes and contract != 'TRADIFI_PERPETUAL':
                return False
            if contract != 'TRADIFI_PERPETUAL' and underlying in ('INDEX', 'PREMARKET', '') and 'TRADFI' not in subtypes:
                return False
            # Nhận diện Cổ phiếu Mỹ/HK/KR/CN/FX — loại trừ INDEX/PREMARKET Crypto 24/7
            if underlying in ('EQUITY', 'HK_EQUITY', 'KR_EQUITY', 'CN_EQUITY', 'FX') or 'TRADFI' in subtypes or contract == 'TRADIFI_PERPETUAL':
                return True

        # 3. Khớp từ danh mục mã TradFi niêm yết trên Binance nếu không có exchange metadata
        if base in cls.KNOWN_TRADFI_BASES and base not in cls.KNOWN_COMMODITY_BASES and base not in cls.CRYPTO_TICKER_EXCLUSIONS:
            return True
        if base.endswith('B') and base[:-1] in cls.KNOWN_TRADFI_BASES and base[:-1] not in cls.KNOWN_COMMODITY_BASES and base[:-1] not in cls.CRYPTO_TICKER_EXCLUSIONS:
            return True
            
        return False

    @classmethod
    def is_tradfi_commodity(cls, symbol: str, exchange=None) -> bool:
        """Kiểm tra xem có phải là hàng hóa TradFi (Vàng XAU, Dầu CL/BZ, Bạc XAG, Đồng COPPER, Gas NATGAS) hay không."""
        if not symbol:
            return False
        clean = symbol.split(':')[0].upper()
        base = clean.split('/')[0] if '/' in clean else clean
        if '/' not in clean:
            for q in ('USDT', 'USDC', 'BUSD', 'USD'):
                if base.endswith(q) and len(base) > len(q):
                    base = base[:-len(q)]
                    break
        m = cls._find_market_entry(symbol, clean, base, exchange=exchange)
        if m:
            info = m.get('info', {})
            underlying = str(info.get('underlyingType') or '').upper()
            subtypes = [str(s).upper() for s in (info.get('underlyingSubType') or [])]
            if underlying == 'COMMODITY' or 'COMMODITY' in subtypes:
                return True
            if underlying == 'COIN' and base != 'PAXG' and 'COMMODITY' not in subtypes:
                return False
        if base in cls.KNOWN_COMMODITY_BASES and base not in cls.CRYPTO_TICKER_EXCLUSIONS:
            return True
        return False

    @staticmethod
    def _now_ny():
        """[BOM #135 FIX]: Lấy datetime hiện tại theo giờ New York, hỗ trợ fallback DST Mỹ khi Windows thiếu tzdata."""
        from datetime import datetime, timezone, timedelta
        utc_now = datetime.now(timezone.utc)
        try:
            import zoneinfo
            return utc_now.astimezone(zoneinfo.ZoneInfo("America/New_York"))
        except Exception:
            try:
                from ai.market_regime import MarketRegimeDetector
                return utc_now.astimezone(MarketRegimeDetector._get_ny_tz(utc_now))
            except Exception:
                # Fallback inline US DST (2nd Sun Mar -> 1st Sun Nov = UTC-4, else UTC-5)
                y = utc_now.year
                from datetime import datetime as _dt
                mar1 = _dt(y, 3, 1, tzinfo=timezone.utc)
                dst_start = mar1 + timedelta(days=((6 - mar1.weekday()) % 7) + 7, hours=7)
                nov1 = _dt(y, 11, 1, tzinfo=timezone.utc)
                dst_end = nov1 + timedelta(days=((6 - nov1.weekday()) % 7), hours=6)
                offset = -4 if (dst_start <= utc_now < dst_end) else -5
                return utc_now.astimezone(timezone(timedelta(hours=offset)))

    @staticmethod
    def is_us_market_open() -> bool:
        """
        Kiểm tra xem thị trường chứng khoán Mỹ (NYSE/NASDAQ) có đang mở cửa không.
        Giờ giao dịch chính thức: Thứ Hai đến Thứ Sáu, từ 09:30 đến 16:00 EST (New York).
        (Tương ứng ~20:30 đến 03:00 sáng hôm sau giờ Việt Nam).
        """
        try:
            from datetime import time
            now_ny = MarketScanner._now_ny()
            
            # 0 = Thứ Hai, ..., 4 = Thứ Sáu, 5 = Thứ Bảy, 6 = Chủ Nhật
            if now_ny.weekday() >= 5:
                return False
                
            market_open = time(9, 30)
            market_close = time(16, 0)
            current_time = now_ny.time()
            
            return market_open <= current_time < market_close
        except Exception as e:
            logger.warning("Không thể kiểm tra phiên thị trường Mỹ: %s", e)
            return False

    @staticmethod
    def is_us_weekend() -> bool:
        """
        Kiểm tra xem hiện tại có phải 2 ngày cuối tuần theo giờ New York (Thứ Bảy & Chủ Nhật) không.
        Dùng để chặn quét và mở vị thế Cổ phiếu mới vào cuối tuần do thanh khoản mỏng.
        """
        try:
            now_ny = MarketScanner._now_ny()
            return now_ny.weekday() >= 5
        except Exception as e:
            logger.warning("Không thể kiểm tra ngày cuối tuần Mỹ: %s", e)
            return False

    @staticmethod
    def is_weekend_gap_risk_window(symbol: str = None, exchange = None) -> bool:
        """
        Kiểm tra xem có đang trong khung giờ rủi ro gap giá cuối tuần không:
        - Với Hàng hóa TradFi (XAU, XAG, CL... - giao dịch 24/5 trên CME Globex):
          Chỉ đóng cửa từ 16:00 EST chiều Thứ Sáu đến 18:00 EST tối Chủ Nhật (05:00 sáng Thứ Hai VN).
          Sau 18:00 EST Chủ Nhật, CME Globex đã mở cửa bình thường -> Trả về False!
        - Với Cổ phiếu Mỹ (NVDA, TSLA, AAPL...):
          Từ 15:45 EST chiều Thứ Sáu cho đến 09:30 EST sáng Thứ Hai tuần kế tiếp.
        - Nếu bật weekend_close: Bot tự động chốt vị thế trước giờ đóng cửa.
        - Nếu bật weekend_shield (Hybrid): Bot kích hoạt bảo hiểm hòa vốn (Net Breakeven) cho lệnh đang có lãi.
        """
        try:
            from datetime import time
            now_ny = MarketScanner._now_ny()
            weekday = now_ny.weekday()
            current_time = now_ny.time()

            is_commodity = False
            if symbol:
                clean_sym = str(symbol).split(':')[0].strip().upper()
                is_commodity = MarketScanner.is_tradfi_commodity(clean_sym, exchange)
                if not is_commodity and not MarketScanner.is_tradfi_stock(clean_sym, exchange):
                    return False  # [BOM #140 FIX]: Crypto 24/7 không có cửa sổ đóng cửa cuối tuần!

            if is_commodity:
                # Thị trường hàng hóa (CME Globex): Nghỉ từ Thứ 6 16:00 EST đến Chủ Nhật 18:00 EST
                if weekday == 4 and current_time >= time(16, 0):
                    return True
                if weekday == 5: # Thứ 7 đóng cửa cả ngày
                    return True
                if weekday == 6 and current_time < time(18, 0): # Chủ Nhật trước 18:00 EST
                    return True
                return False

            # Cổ phiếu & ETF Mỹ (NYSE / NASDAQ): Nghỉ từ Thứ 6 15:45 EST đến Thứ 2 09:30 EST
            # Thứ Bảy (5) hoặc Chủ Nhật (6)
            if weekday in (5, 6):
                return True
            # Thứ Sáu sau 15:45 EST (sắp đóng cửa sàn Mỹ)
            if weekday == 4 and current_time >= time(15, 45):
                return True
            # Thứ Hai trước 09:30 EST (chưa mở cửa)
            if weekday == 0 and current_time < time(9, 30):
                return True
                
            return False
        except Exception as e:
            logger.error("🚨 [WEEKEND GAP CHECK FAILED - FAIL-SAFE]: %s", e)
            return True

    def get_potential_pairs(self, limit: int = 10, min_volume: float = 3000000) -> List[str]:
        """
        Quét tất cả các cặp giao dịch, lọc và sắp xếp theo tiềm năng.
        Tiềm năng = Độ biến động (Volatility) + Volume lớn.
        Hỗ trợ phân loại:
        - only_tradfi=True -> Chỉ lấy Cổ phiếu Mỹ, bỏ qua 100% Crypto
        - enabled=True -> Lấy cả Crypto và Cổ phiếu Mỹ song song
        - enabled=False -> Thuần Crypto
        """
        try:
            logger.info("🔍 Đang quét toàn bộ thị trường để tìm cơ hội...")
            market_type = getattr(self.exchange, 'market_type', 'spot')
            tradfi_cfg = getattr(self.exchange, 'config', {}).get('tradfi', {})
            tradfi_enabled = bool(tradfi_cfg.get('enabled', False))
            only_tradfi = bool(tradfi_cfg.get('only_tradfi', False))
            session_filter = bool(tradfi_cfg.get('session_filter', True))
            tradfi_min_vol = float(tradfi_cfg.get('min_volume', 3000000))
            us_market_active = self.is_us_market_open()
            
            # [V6.1 BOM #71 FIX]: Nối Cầu Dao IP Ban trước khi gọi fetch_tickers() trực tiếp qua CCXT!
            try:
                from core.exchange import get_ip_ban_remaining_seconds, _extract_and_activate_ip_ban
                if get_ip_ban_remaining_seconds() > 0:
                    return []
            except Exception:
                _extract_and_activate_ip_ban = None

            try:
                tickers = self.exchange.exchange.fetch_tickers()
            except Exception as e:
                if _extract_and_activate_ip_ban is not None and _extract_and_activate_ip_ban(e) > 0:
                    return []
                if 'does not support' in str(e) or 'fetchTickers' in str(e):
                    if self.exchange.exchange_id == 'binance' and market_type == 'futures':
                        # Gọi raw API của Binance Futures (có nối Cầu Dao IP Ban BOM #140)
                        try:
                            raw = self.exchange.exchange.fapiPublicGetTicker24hr()
                        except Exception as _e_raw:
                            if _extract_and_activate_ip_ban is not None and _extract_and_activate_ip_ban(_e_raw) > 0:
                                return []
                            raise _e_raw
                        tickers = {}
                        for t in raw:
                            base_curr = self.exchange.config.get('trading', {}).get('base_currency', 'USDT')
                            if t['symbol'].endswith(base_curr):
                                s = t['symbol'][:-len(base_curr)] + f'/{base_curr}:{base_curr}'
                                tickers[s] = {
                                    'quoteVolume': float(t['quoteVolume']),
                                    'percentage': float(t['priceChangePercent']),
                                    'last': float(t.get('lastPrice') or 0.0),
                                }
                    else:
                        raise e
                else:
                    raise e

            # [V6.1 BOM #69 + #121J FIX]: Lọc bỏ hợp đồng kỳ hạn delivery futures (-YYMMDD) TRƯỚC khi lưu giá tức thời!
            base_curr = self.exchange.config.get('trading', {}).get('base_currency', 'USDT')
            _all_px_map = {}
            _all_vol_map = {}
            for _tsym, _td in (tickers or {}).items():
                try:
                    if market_type == 'futures':
                        if (':' not in _tsym) or (not _tsym.endswith(f':{base_curr}')) or ('-' in _tsym.split(':')[-1]):
                            continue
                    _px_v = float((_td or {}).get('last') or (_td or {}).get('close') or 0.0)
                    _qv_v = float((_td or {}).get('quoteVolume') or 0.0)
                    _ck = str(_tsym).split(':')[0].strip().upper().replace('/', '')
                    if _px_v > 0:
                        _all_px_map[_ck] = _px_v
                    if _qv_v > 0:
                        _all_vol_map[_ck] = _qv_v
                except Exception:
                    pass
            self.last_all_ticker_prices = _all_px_map
            self.last_all_ticker_volumes = _all_vol_map
            
            potential_pairs = []
            
            for symbol, ticker in tickers.items():
                # Lọc cặp USDT
                if f'/{base_curr}' not in symbol:
                    continue
                # Nếu là futures, ccxt format chuẩn cho Perpetual là XXX/USDT:USDT
                if market_type == 'futures':
                    if ':' not in symbol:
                        continue
                    # Bỏ qua các hợp đồng kỳ hạn delivery futures có ngày đáo hạn (vd: BTC/USDT:USDT-261225)
                    # Chỉ nhận hợp đồng vĩnh cửu perpetual kết thúc bằng ':<base_curr>' (vd: ':USDT')
                    if not symbol.endswith(f':{base_curr}'):
                        continue
                    
                # Bỏ qua stable coins & tokens rác & các mã đang bị cách ly do mới niêm yết chưa đủ nến lịch sử
                base_coin = symbol.split('/')[0]
                # Bo qua token co ky tu phi Latinh (tranh loi hien thi console Windows cp1252 / ??/USDT)
                if not base_coin.isascii():
                    continue
                if base_coin in ['USDC', 'TUSD', 'BUSD', 'FDUSD', 'EUR', 'USDP']:
                    continue
                # [BOM #140 FIX]: Spot leveraged tokens (BTCUP/BTCDOWN) chỉ tồn tại trên Spot, không loại oan coin Futures như SYRUP/USDT!
                if market_type != 'futures' and base_coin not in self.KNOWN_TRADFI_BASES:
                    if (base_coin.endswith(('UP', 'DOWN', 'BEAR', 'BULL')) and len(base_coin) >= 5) or ('DOWN' in base_coin and len(base_coin) >= 6):
                        continue
                if self.is_insufficient_data_cooled(symbol):
                    continue

                # Phân lập TradFi Cổ Phiếu vs Crypto
                is_commodity = self.is_tradfi_commodity(symbol, self.exchange)
                is_stock_pure = self.is_tradfi_stock(symbol, self.exchange) and not is_commodity
                is_stock = is_stock_pure or is_commodity
                
                # 1. Chế độ CHỈ CỔ PHIẾU MỸ (ONLY TRADFI):
                if only_tradfi:
                    if not is_stock:
                        # Bỏ qua 100% Crypto
                        continue
                    if self.is_weekend_gap_risk_window(symbol, self.exchange):
                        # Chặn theo lịch riêng của từng tài sản: CME cho hàng hóa, NYSE/NASDAQ cho cổ phiếu.
                        continue
                    # Chỉ áp dụng lọc phiên Wall Street cho Cổ phiếu Mỹ; Hàng hóa giao dịch 24/5 liên tục:
                    if is_stock_pure and session_filter and not us_market_active:
                        # Ngoài giờ Wall Street -> Bỏ qua cổ phiếu
                        continue
                    vol_threshold = tradfi_min_vol

                # 2. Chế độ BẬT CẢ HAI (DUAL) hoặc CHỈ CRYPTO:
                else:
                    if is_stock:
                        if not tradfi_enabled:
                            # Nút TradFi đang TẮT -> Bỏ qua 100% cổ phiếu để đảm bảo bot thuần crypto
                            continue
                        if self.is_weekend_gap_risk_window(symbol, self.exchange):
                            # Lịch gap theo tài sản; hàng hóa được phép quét lại sau khi CME mở cửa.
                            continue
                        # Chỉ áp dụng lọc phiên Wall Street cho Cổ phiếu Mỹ; Hàng hóa giao dịch 24/5 liên tục:
                        if is_stock_pure and session_filter and not us_market_active:
                            # Thị trường Mỹ đang đóng cửa -> Bỏ qua cổ phiếu
                            continue
                        vol_threshold = tradfi_min_vol
                    else:
                        vol_threshold = min_volume

                vol = ticker.get('quoteVolume', 0)
                if vol is None or vol < vol_threshold:
                    continue

                if is_stock:
                    max_change_pct = float(self.exchange.config.get('risk', {}).get('max_24h_change_pct', 12.0))
                else:
                    max_change_pct = float(self.exchange.config.get('risk', {}).get('max_crypto_24h_change_pct', 12.0))
                raw_pct = ticker.get('percentage', 0) or 0
                change_pct = abs(float(raw_pct))

                # [QUY TẮC 0.1 MỤC 6 - BÃO VOLUME CÁ MẬP MIỄN TRỪ FAST-SKIP & SCANNER FILTER]:
                # Nếu coin có Volume bão (Whale Pump Storm / Waterfall Dump: vol >= vol_threshold * 2.5),
                # tuyệt đối KHÔNG loại bỏ sớm mà nới trần max_change_pct lên 35.0% (Crypto) và 20.0% (TradFi)
                # để chuyển sang Pha 1/Pha 2 đánh giá nến vi cấu trúc (Momentum Ride hoặc Exhaustion Fading Short).
                is_whale_volume_surge = (vol >= vol_threshold * 2.5) if vol_threshold > 0 else False
                if is_whale_volume_surge:
                    max_change_pct = 35.0 if not is_stock else 20.0

                if change_pct > max_change_pct:
                    continue

                # Whitelist filtering: Phân lập rạch ròi giữa TradFi và Crypto để không bao giờ bóp nghẹt thị trường còn lại
                if is_stock:
                    tradfi_allowed = getattr(self.exchange, 'config', {}).get('tradfi', {}).get('allowed_tickers')
                    if tradfi_allowed and isinstance(tradfi_allowed, (list, set, tuple)):
                        allowed_set = {str(t).upper().split(':')[0] for t in tradfi_allowed}
                        clean_sym = symbol.split(':')[0].upper()
                        clean_base = clean_sym.split('/')[0]
                        if clean_sym not in allowed_set and clean_base not in allowed_set and f"{clean_base}/USDT" not in allowed_set:
                            continue
                else:
                    crypto_allowed = getattr(self.exchange, 'config', {}).get('trading', {}).get('allowed_tickers')
                    if crypto_allowed and isinstance(crypto_allowed, (list, set, tuple)):
                        allowed_set = {str(t).upper().split(':')[0] for t in crypto_allowed}
                        clean_sym = symbol.split(':')[0].upper()
                        clean_base = clean_sym.split('/')[0]
                        if clean_sym not in allowed_set and clean_base not in allowed_set and f"{clean_base}/USDT" not in allowed_set:
                            continue

                # [RÀO CHẮN UNMAPPED TRADFI GUARD]: Khóa tuyệt đối nếu mã TradFi chưa map ma trận ngành
                if is_stock:
                    tradfi_sec = self.get_tradfi_sector(symbol)
                    if not tradfi_sec:
                        logger.warning(
                            f"🔔 [UNMAPPED TRADFI GUARD] Mã {symbol} chưa được xác nhận trong MA TRẬN 10 PHÂN LỚP NGÀNH! "
                            f"Tạm dừng mở lệnh tự động để bảo vệ vốn."
                        )
                        continue

                potential_pairs.append({
                    'symbol': symbol,
                    'change': change_pct,
                    'volume': vol
                })
            
            # Sắp xếp theo độ biến động và volume
            potential_pairs.sort(key=lambda x: (x['volume'] / 100000000 * 0.6) + (min(x['change'], 8.0) * 0.4), reverse=True)
            
            # Lấy top N
            top_pairs = potential_pairs[:limit]
            
            # Đổi lại format chuẩn (bỏ :USDT) để truyền vào data_collector
            final_symbols = []
            for p in top_pairs:
                sym = p['symbol']
                if ':' in sym:
                    sym = sym.split(':')[0]
                final_symbols.append(sym)
            final_symbols = list(dict.fromkeys(final_symbols))
                
            if only_tradfi:
                logger.info(f"✅ [CHẾ ĐỘ CHỈ CỔ PHIẾU] Đã chọn Top {len(final_symbols)} mã tiềm năng: {', '.join(final_symbols)}")
            elif tradfi_enabled:
                logger.info(f"✅ [CƠ CHẾ KÉP CRYPTO + CỔ PHIẾU] Đã chọn Top {len(final_symbols)} mã tiềm năng: {', '.join(final_symbols)}")
            else:
                logger.info(f"✅ [CHẾ ĐỘ THUẦN CRYPTO] Đã chọn Top {len(final_symbols)} coin tiềm năng: {', '.join(final_symbols)}")

            return final_symbols
            
        except Exception as e:
            logger.error(f"Lỗi khi quét thị trường: {e}")
            return []
