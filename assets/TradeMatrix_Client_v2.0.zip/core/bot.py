"""
TRADE BOT - Bot Engine Chính
Điều phối tất cả các components: thu thập dữ liệu, phân tích chiến lược,
tổng hợp tín hiệu, quản lý rủi ro, và thực thi lệnh.
"""

import logging
import time
import yaml
import os
import sys
import math
import warnings
warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass
import re
import threading
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path

# Thêm root directory vào path
ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))

from dotenv import load_dotenv
load_dotenv(ROOT_DIR / ".env", override=False)

from core.exchange import ExchangeConnector
from core.data_collector import DataCollector
from core.order_manager import OrderManager
from core.telegram_notifier import send_telegram_message
from database.db_manager import DatabaseManager
from strategies.base_strategy import TradeSignal, Signal
from strategies.trend_following import TrendFollowingStrategy
from strategies.mean_reversion import MeanReversionStrategy
from strategies.smart_dca import SmartDCAStrategy
from strategies.hft_scalping import HFTScalpingStrategy
from strategies.trap_detector import TrapDetectorStrategy
from strategies.momentum_breakout import MomentumBreakoutStrategy
from ai.feature_engine import FeatureEngine
from ai.ml_model import MLPredictor
from ai.signal_aggregator import SignalAggregator
from ai.quantum_path_simulator import QuantumPathSimulator
from core.scanner import MarketScanner
from risk.risk_manager import RiskManager
from risk.position_sizer import PositionSizer

logger = logging.getLogger(__name__)


class TradeBot:
    """
    Bot giao dịch crypto AI chính.
    Hỗ trợ chế độ demo (paper trading) và live trading.
    """

    def __init__(self, config_path: str = None):
        """Khởi tạo bot với cấu hình từ file YAML."""
        self.root_dir = ROOT_DIR
        self.config_path = config_path or str(self.root_dir / "config" / "settings.yaml")
        self.config = self._load_config(self.config_path)
        self.strategy_config = self._load_config(str(self.root_dir / "config" / "strategies.yaml"))
        
        # Trạng thái bot
        self.is_running = False
        self.exchange_connected = False
        import threading
        self._position_lock = threading.RLock()
        self._history_sync_lock = threading.Lock()
        self._position_monitor_stop = threading.Event()
        self._history_market_discovery_done = False
        self._telegram_warning_logged = False
        self._manual_exit_cooldowns = {}
        self._symbol_cooldowns = {}
        self._symbol_loss_streaks = {}
        self._global_loss_cooldown_until = 0.0
        self.mode = self.config['bot']['mode']  # 'demo' hoặc 'live'
        trading_config = self.config['trading']
        try:
            self._live_initial_capital = float(trading_config.get('live_initial_capital', trading_config['initial_capital']))
            if not math.isfinite(self._live_initial_capital) or self._live_initial_capital <= 0:
                raise ValueError('invalid live initial capital')
        except (TypeError, ValueError, OverflowError):
            self._live_initial_capital = 1000.0
        try:
            self._demo_initial_capital = float(trading_config.get('demo_initial_capital', 1000.0))
            if not math.isfinite(self._demo_initial_capital) or self._demo_initial_capital <= 0:
                raise ValueError('invalid demo initial capital')
        except (TypeError, ValueError, OverflowError):
            self._demo_initial_capital = 1000.0
        if self.mode == 'demo':
            trading_config['initial_capital'] = self._demo_initial_capital
        else:
            trading_config['initial_capital'] = self._live_initial_capital
        self.live_balance_synced = self.mode != 'live'
        self.balance = trading_config['initial_capital']
        self.peak_balance = self.balance
        self.open_positions: List[Dict] = []
        self.pending_stalking_orders: Dict[str, Dict] = {}
        self._futures_account_snapshot: Optional[Dict] = None
        self._futures_account_snapshot_time: Optional[datetime] = None
        self._futures_account_snapshot_monotonic: Optional[float] = None
        self._futures_positions_snapshot: List[Dict] = []
        self._futures_positions_snapshot_time: Optional[datetime] = None
        self.pending_protection_cleanup: List[Dict] = []
        self.unreconciled_exchange_positions = False
        self.trade_count = 0
        self.start_time = None
        self._skip_dynamic_exit_cycle = False
        self.last_optimized = 0
        self._trailing_market_cache = {}
        self._position_monitor_thread = None
        self._runner_thread = None
        self._background_threads = []
        self.last_dynamic_leverage = 1
        self.last_leverage_symbol = None
        self.last_pair_max_leverage = None
        self.last_leverage_limit_verified = None
        self.last_leverage_limit_source = None
        self.ai_recommended_max_positions = 1
        self.last_dynamic_position_limit = None
        self.last_position_signal_quality = None
        self.last_position_available_margin = None
        self.last_position_open_risk = None
        self.last_position_risk_budget = None
        
        # Khởi tạo components
        self._init_components()
        
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        logger.info(f"🤖 TRADE BOT v{self.config['bot']['version']} khởi tạo thành công!")
        logger.info(f"📊 Chế độ: {'DEMO (Paper Trading)' if self.mode == 'demo' else '⚠️ LIVE TRADING'}")
        if self.mode == 'demo':
            logger.info(f"💰 Vốn ban đầu (Demo): {self.balance} {quote}")
        else:
            logger.info(f"💰 Vốn ban đầu: Đang kết nối API sàn để lấy số dư thực tế...")

    def _load_config(self, path: str) -> dict:
        """Đọc file cấu hình YAML."""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            logger.error(f"Không tìm thấy file cấu hình: {path}")
            raise
        except yaml.YAMLError as e:
            logger.error(f"Lỗi đọc file YAML: {e}")
            raise

    def _init_components(self):
        """Khởi tạo tất cả các thành phần của bot."""
        # Database
        db_path = str(self.root_dir / self.config['database']['path'])
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db = DatabaseManager(db_path)
        self.db.init_db()
        
        # Exchange connector
        self.exchange = ExchangeConnector(self.config)
        
        # Market Scanner (Quét thị trường)
        self.scanner = MarketScanner(self.exchange)
        
        # Setup futures if in futures mode
        if self.config['trading'].get('market_type', 'spot') == 'futures':
            self.market_type = 'futures'
            self.leverage = self.config['trading'].get('leverage', 5)
        else:
            self.market_type = 'spot'
            self.leverage = 1
        
        # Data collector
        self.data_collector = DataCollector(self.exchange, str(self.root_dir / "data" / "historical"))
        
        # Strategies
        self.strategies = []
        strat_configs = self.strategy_config.get('strategies', {})
        
        if strat_configs.get('trend_following', {}).get('enabled', False):
            self.strategies.append(
                TrendFollowingStrategy("trend_following", strat_configs['trend_following'])
            )
        
        if strat_configs.get('mean_reversion', {}).get('enabled', False):
            self.strategies.append(
                MeanReversionStrategy("mean_reversion", strat_configs['mean_reversion'])
            )
        
        if strat_configs.get('smart_dca', {}).get('enabled', False):
            self.strategies.append(
                SmartDCAStrategy("smart_dca", strat_configs['smart_dca'])
            )
            
        if strat_configs.get('hft_scalping', {}).get('enabled', False):
            self.strategies.append(
                HFTScalpingStrategy("hft_scalping", strat_configs['hft_scalping'])
            )

        if strat_configs.get('trap_detector', {}).get('enabled', False):
            self.strategies.append(
                TrapDetectorStrategy("trap_detector", strat_configs['trap_detector'])
            )
            
        if strat_configs.get('momentum_breakout', {}).get('enabled', False):
            self.strategies.append(
                MomentumBreakoutStrategy("momentum_breakout", strat_configs.get('momentum_breakout', {}))
            )

        # AI components
        self.feature_engine = FeatureEngine()
        self.ml_predictor = MLPredictor()
        aggregator_config = dict(self.config)
        aggregator_config['strategies'] = strat_configs
        self.signal_aggregator = SignalAggregator(aggregator_config)
        q_cfg = self.config.get('quantum_gate', {}) if isinstance(self.config.get('quantum_gate'), dict) else {}
        self.quantum_simulator = QuantumPathSimulator(
            n_paths=int(q_cfg.get('n_paths', 2500)),
            n_steps=int(q_cfg.get('n_steps', 40)),
            min_win_prob=float(q_cfg.get('min_win_prob', 0.52)),
            max_doa_prob=float(q_cfg.get('max_doa_prob', 0.40)),
        )
        
        try:
            from ai.jev_agent import JevAgent
            self.jev_agent = JevAgent(model_name=self.config.get('ai', {}).get('ollama_model', 'qwen2.5:7b'))
        except ImportError:
            self.jev_agent = None
        
        # Risk management
        self.risk_manager = RiskManager(self.config)
        self.position_sizer = PositionSizer()
        self.cycle_count = 0
        
        # Order manager
        self.order_manager = OrderManager(self.exchange, self.db, self.mode)
        self.scanner.exchange = self.exchange
        self.data_collector.exchange = self.exchange
        
        # Khôi phục trạng thái nếu có
        if self.mode == 'live':
            try:
                # Load public market metadata so a LIVE session can reconcile and
                # display existing positions while the trading loop stays stopped.
                self.exchange_connected = bool(self.exchange.connect())
                if not self.exchange_connected:
                    logger.error("Không kết nối được Binance lúc mở dashboard LIVE; bot vẫn giữ trạng thái dừng.")
            except Exception as e:
                self.exchange_connected = False
                logger.error("Không thể khởi tạo kết nối LIVE lúc mở dashboard: %s", e)
        self._restore_state()
        active_cds = {
            self._clean_symbol(symbol): expires_at
            for symbol, expires_at in self.db.get_symbol_cooldowns(self.mode).items()
        }
        self._manual_exit_cooldowns = dict(active_cds)
        self._symbol_cooldowns = dict(active_cds)
        self.sync_live_positions_with_exchange()
        
        logger.info(f"✅ Đã khởi tạo {len(self.strategies)} chiến lược giao dịch")

    def _restore_state(self):
        """Khôi phục trạng thái bot từ database (cho trường hợp restart)."""
        try:
            state = self.db.get_bot_state(self.mode)
            if state:
                if state.get('initial_capital') is not None:
                    self.config['trading']['initial_capital'] = state['initial_capital']
                    if self.mode == 'demo':
                        self._demo_initial_capital = float(state['initial_capital'])
                    else:
                        self._live_initial_capital = float(state['initial_capital'])
                    
                if self.mode == 'demo':
                    self.balance = state.get('balance', self.balance)
                loaded_peak = float(state.get('peak_balance', self.peak_balance) or self.peak_balance)
                if self.mode == 'live' and loaded_peak == 1000.0 and self.balance < 500:
                    loaded_peak = self.balance # Ignore leaked demo peak
                self.peak_balance = max(self.balance, loaded_peak)
                self.trade_count = int(state.get('trade_count', self.trade_count) or 0)
                pending_cleanup = state.get('pending_protection_cleanup', []) or []
                self.pending_protection_cleanup = (
                    [item for item in pending_cleanup if isinstance(item, dict)]
                    if isinstance(pending_cleanup, list) else []
                )
                
                # Trong LIVE mode, self.balance đã được đồng bộ chính xác từ sàn qua switch_mode
                # nên không ghi đè từ DB cũ lên nữa.
                
                self.open_positions = state.get('open_positions', [])
                # Khôi phục các lệnh bắn tỉa rình mồi M1 đang chờ
                self.pending_stalking_orders = {}
                try:
                    stalking_file = Path(ROOT_DIR) / "data" / f"pending_stalking_orders_{self.mode}.json"
                    if stalking_file.exists():
                        raw_stk = stalking_file.read_text(encoding="utf-8").strip()
                        loaded_stk = json.loads(raw_stk) if raw_stk else {}
                        now_ts = time.time()
                        if isinstance(loaded_stk, dict):
                            for s_sym, s_data in loaded_stk.items():
                                if now_ts - float(s_data.get('created_at', 0)) < float(s_data.get('timeout_seconds', 900)):
                                    self.pending_stalking_orders[s_sym] = s_data
                except Exception as e_stk:
                    logger.debug(f"Không thể đọc file stalking orders: {e_stk}")
                quote = self.config.get('trading', {}).get('base_currency', 'USDT')
                
                # Parse last_check to track daily drawdown resets
                last_check_str = state.get('last_check')
                if last_check_str:
                    try:
                        self.last_reset_date = datetime.fromisoformat(last_check_str).date()
                    except Exception:
                        self.last_reset_date = datetime.now().date()
                else:
                    self.last_reset_date = datetime.now().date()
                    
                if self.mode == 'live' and not self.live_balance_synced:
                    logger.info(f"🔄 Khôi phục trạng thái: Chế độ LIVE TRADING (chuẩn bị kết nối sàn Binance), "
                              f"Open positions={len(self.open_positions)}")
                else:
                    logger.info(f"🔄 Khôi phục trạng thái: Balance={self.balance:.2f} {quote}, "
                              f"Open positions={len(self.open_positions)}")
            else:
                self.open_positions = []
                self.last_reset_date = datetime.now().date()
                logger.info(f' Không tìm thấy trạng thái cũ cho {self.mode}, bắt đầu mới.')
        except Exception as e:
            logger.warning(f"Không thể khôi phục trạng thái: {e}")

    def _save_state(self):
        """Lưu trạng thái hiện tại vào database."""
        try:
            state = {
                'mode': self.mode,
                'balance': self.balance,
                'initial_capital': self.config['trading']['initial_capital'],
                'open_positions': self.open_positions,
                'pending_protection_cleanup': self.pending_protection_cleanup,
                'peak_balance': self.peak_balance,
                'trade_count': self.trade_count,
                'last_check': datetime.now().isoformat()
            }
            self.db.save_bot_state(state)
            # Lưu trạng thái các lệnh rình mồi M1 vào file JSON
            try:
                stalking_file = Path(ROOT_DIR) / "data" / f"pending_stalking_orders_{self.mode}.json"
                with open(stalking_file, "w", encoding="utf-8") as sf:
                    json.dump(getattr(self, 'pending_stalking_orders', {}), sf, indent=2, ensure_ascii=False)
            except Exception as e_stk:
                logger.debug(f"Không thể ghi file stalking orders: {e_stk}")
        except Exception as e:
            logger.error(f"Lỗi lưu trạng thái: {e}")

    def connect(self) -> bool:
        """Kết nối tới sàn giao dịch."""
        try:
            connected = self.exchange.connect()
            self.exchange_connected = bool(connected)
            if connected:
                logger.info("✅ Kết nối sàn giao dịch thành công!")
                
                if self.mode == 'live':
                    self._detect_base_currency()
                    base_currency = self.config['trading'].get('base_currency', 'USDT')
                    if getattr(self, 'market_type', 'spot') == 'futures':
                        bal = self.exchange.get_futures_balance()
                        curr_balance = float(bal.get('free', 0))
                    else:
                        bal = self.exchange.get_balance()
                        curr_balance = bal.get(base_currency, {}).get('free', 0)
                        
                    self.balance = curr_balance  # Cập nhật số dư thực tế
                    self.live_balance_synced = True
                    logger.info(f"💰 Số dư tài khoản thực tế từ Binance: {curr_balance} {base_currency}")
                    self._auto_adjust_capital()
                else:
                    curr_balance = self.balance
                    base_currency = self.config['trading'].get('base_currency', 'USDT')

                current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                start_msg = (
                    f"🤖 **TRADE BOT ĐÃ KHỞI ĐỘNG**\n"
                    f"🕒 **Thời gian:** {current_time}\n"
                    f"🔹 **Trạng thái:** Đã kết nối sàn thành công! Đang chờ tín hiệu...\n"
                    f"🛡️ **Cơ chế an toàn:** Đang chạy Chu kỳ #1 Warm-up (Nạp nóng AI VRAM & đồng bộ nến). Lệnh mới sẵn sàng kích hoạt từ Chu kỳ #2!"
                )
                self._notify_telegram(start_msg)
                
                return True
            else:
                logger.error("❌ Không thể kết nối sàn giao dịch!")
                return False
        except Exception as e:
            self.exchange_connected = False
            logger.error(f"❌ Lỗi kết nối: {e}")
            return False

    def _analyze_market(self, symbol: str, fast_mode: bool = False) -> List:
        """
        Phân tích thị trường cho một cặp giao dịch.
        Thu thập dữ liệu, chạy tất cả strategies, trả về danh sách signals.
        Nếu fast_mode=True, bỏ qua các model AI chậm (JEV, LLM).
        """
        signals = []
        market_analysis = None
        timeframes = self.config['trading'].get('timeframes', [])
        primary_timeframe = timeframes[0] if timeframes else None
        
        dfs = {}
        # Tải nến song song các khung thời gian để giảm 60% độ trễ mạng
        if len(timeframes) > 1:
            import concurrent.futures
            def _fetch_tf(tf):
                try:
                    res_df = self.data_collector.fetch_data(symbol, tf, limit=500)
                    return tf, res_df
                except Exception as e:
                    logger.warning(f"Lỗi tải nến {symbol} {tf}: {e}")
                    return tf, None

            with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(timeframes))) as tf_executor:
                fetched = list(tf_executor.map(_fetch_tf, timeframes))
            for tf, df_res in fetched:
                if df_res is not None and len(df_res) >= 100:
                    dfs[tf] = df_res
                else:
                    logger.warning(f"Không đủ dữ liệu cho {symbol} {tf}")
        else:
            for timeframe in timeframes:
                try:
                    df = self.data_collector.fetch_data(symbol, timeframe, limit=500)
                    if df is not None and len(df) >= 100:
                        dfs[timeframe] = df
                    else:
                        logger.warning(f"Không đủ dữ liệu cho {symbol} {timeframe}")
                except Exception as e:
                    logger.warning(f"Lỗi tải nến {symbol} {timeframe}: {e}")

        for timeframe in timeframes:
            try:
                df = dfs.get(timeframe)
                if df is None or len(df) < 100:
                    continue

                if timeframe == primary_timeframe:
                    try:
                        from ai.market_regime import MarketRegimeDetector
                        regime_info = MarketRegimeDetector().detect_regime(df)
                        regime = regime_info.get('regime')
                        market_analysis = {
                            'regime': getattr(regime, 'value', regime),
                            'confidence': float(regime_info.get('confidence', 0.0)),
                            'adx': float(regime_info.get('adx', 0.0)),
                            'di_plus': float(regime_info.get('di_plus', 0.0)),
                            'di_minus': float(regime_info.get('di_minus', 0.0)),
                            'atr_pct': float(regime_info.get('atr_pct', 0.0)),
                            'rsi': float(regime_info.get('rsi', 50.0)),
                            'ema_alignment': regime_info.get('ema_alignment', 'mixed'),
                        }
                    except Exception as e:
                        logger.debug("Không có market regime cho %s %s: %s", symbol, timeframe, e)
                        market_analysis = None
                elif timeframe == '15m' and isinstance(market_analysis, dict):
                    try:
                        import ta
                        rsi_15m_s = ta.momentum.RSIIndicator(df['close'].iloc[:-1], window=14).rsi().dropna()
                        if not rsi_15m_s.empty:
                            market_analysis['tactical_rsi'] = float(rsi_15m_s.iloc[-1])
                    except Exception:
                        pass
                
                # Chạy từng strategy
                for strategy in self.strategies:
                    try:
                        strat_name_l = str(getattr(strategy, 'name', '')).lower()
                        # Khung 4h (240 phút) chỉ dùng TrendFollowing để định hướng vĩ mô;
                        # cấm chạy MomentumBreakout/MeanReversion/TrapDetector trên nến 4h để tránh bẫy trễ pha (như INTC, DUSK #0)
                        if timeframe == '4h' and strat_name_l in (
                            'momentumbreakout', 'momentum_breakout',
                            'meanreversion', 'mean_reversion',
                            'trapdetector', 'trap_detector',
                        ):
                            continue
                        signal = strategy.analyze(df, symbol)
                        if signal:
                            if isinstance(getattr(signal, 'metadata', None), dict):
                                signal.metadata['timeframe'] = timeframe
                            signals.append(signal)
                            if signal.signal.value != 'hold':
                                logger.info(
                                    f"📊 [{strategy.name}] {symbol} {timeframe}: "
                                    f"{signal.signal.value.upper()} "
                                    f"(confidence: {signal.confidence:.2%})"
                                )
                    except Exception as e:
                        logger.error(f"Lỗi strategy {strategy.name}: {e}")
                        
            except Exception as e:
                logger.error(f"Lỗi phân tích {symbol} {timeframe}: {e}")

        # AI Analysis với đầy đủ bối cảnh Đa Khung Thời Gian (Multi-Timeframe)
        if not fast_mode and bool(dfs):
            # 1. AI Ensemble Analysis (sử dụng khung chính kèm market analysis)
            primary_df = dfs.get(primary_timeframe)
            if primary_df is None or (hasattr(primary_df, 'empty') and primary_df.empty):
                primary_df = list(dfs.values())[0] if dfs else None
            try:
                ai_signal = self._ai_analysis(primary_df, symbol, market_analysis)
                if ai_signal:
                    signals.append(ai_signal)
                    if ai_signal.signal.value != 'hold':
                        logger.info(
                            f"🧠 [AI Ensemble] {symbol}: "
                            f"{ai_signal.signal.value.upper()} "
                            f"(confidence: {ai_signal.confidence:.2%})"
                        )
            except Exception as e:
                logger.error(f"Lỗi AI Ensemble analysis: {e}")

            # 2. JEV Agent Analysis (Tích hợp chuẩn Multi-Timeframe: 15M tác chiến + 1H sóng + 4H xu hướng lớn)
            if hasattr(self, 'jev_agent') and self.jev_agent:
                try:
                    df_tactical = dfs.get('15m')
                    if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                        df_tactical = dfs.get('5m')
                    if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                        df_tactical = primary_df
                    df_1h = dfs.get('1h')
                    df_4h = dfs.get('4h')
                    jev_resp = self.jev_agent.analyze_klines(
                        df=df_tactical,
                        symbol=symbol,
                        df_1h=df_1h,
                        df_4h=df_4h
                    )
                    if jev_resp:
                        from strategies.base_strategy import TradeSignal, Signal
                        
                        jev_sig_val = Signal.HOLD
                        if jev_resp['decision'] == 'BUY': jev_sig_val = Signal.BUY
                        elif jev_resp['decision'] == 'SELL': jev_sig_val = Signal.SELL
                        
                        jev_signal = TradeSignal(
                            signal=jev_sig_val,
                            symbol=symbol,
                            confidence=jev_resp['confidence'],
                            strategy="jev_agent",
                            price=float(df_tactical['close'].iloc[-1]),
                            metadata={
                                'reason': jev_resp['reason'],
                                'risk_factors': jev_resp.get('risk_factors', 'none')
                            }
                        )
                        signals.append(jev_signal)
                        if jev_signal.signal.value != 'hold':
                            logger.info(
                                f"⚡ [JEV Agent MTF] {symbol}: "
                                f"{jev_signal.signal.value.upper()} "
                                f"(confidence: {jev_signal.confidence:.2%})"
                            )
                except Exception as e:
                    logger.error(f"Lỗi JEV Agent MTF analysis: {e}")
        
        if market_analysis:
            for signal in signals:
                signal.metadata.setdefault('market_analysis', market_analysis)
        for signal in signals:
            signal.metadata['dfs'] = dfs
        return signals

    def _ai_analysis(self, df, symbol: str, market_analysis: dict = None):
        """Phân tích bằng AI/ML model."""
        from strategies.base_strategy import TradeSignal, Signal
        
        try:
            # Tạo features
            features_df = self.feature_engine.generate_features(df)
            
            if features_df is None or len(features_df) < 50:
                return None
            
            # Kiểm tra model đã train chưa
            model_path = str(self.root_dir / "data" / "models" / f"model_{symbol.replace('/', '_')}.pkl")
            # --- SMART AUTO-RETRAIN LOGIC ---
            if os.path.exists(model_path):
                file_age_days = (time.time() - os.path.getmtime(model_path)) / (24 * 3600)
                retrain_days = self.config.get('ai', {}).get('model_retrain_days', 7.0)
                if file_age_days > retrain_days:
                    logger.info(f"\u26a0\ufe0f N\u00e3o b\u1ed9 c\u1ee7a {symbol} \u0111\u00e3 c\u0169 ({file_age_days:.1f} ng\u00e0y). T\u1ef1 \u0111\u1ed9ng t\u1ea9y n\u00e3o \u0111\u1ec3 h\u1ecdc l\u1ea1i c\u1ea5u tr\u00fac m\u1edbi!")
                    try:
                        os.remove(model_path)
                    except Exception as e:
                        logger.error(f"L\u1ed7i khi x\u00f3a model c\u0169 {symbol}: {e}")
            # --------------------------------
            
            just_trained = False
            if os.path.exists(model_path):
                self.ml_predictor.load_model(model_path)
            else:
                # Train model mới
                logger.info(f"🔄 Training AI model cho {symbol}...")
                self.ml_predictor.train(features_df)
                os.makedirs(os.path.dirname(model_path), exist_ok=True)
                self.ml_predictor.save_model(model_path)
                logger.info(f"✅ AI model trained và saved!")
                just_trained = True
            
            current_price = float(df['close'].iloc[-1])

            # COLD-START GUARD: Nếu vừa train model cấp tốc trên coin mới,
            # Bắt buộc Warm-up (tạm thời HOLD) để kiểm chứng nến tiếp theo, cấm BUY đu đỉnh ngay trên chính cây nến vừa train.
            if just_trained:
                logger.info(f"⏳ [Cold-start Warmup] Model {symbol} vừa train xong. Tạm thời HOLD 1 chu kỳ để kiểm chứng out-of-sample trước khi cấp lệnh.")
                return TradeSignal(
                    signal=Signal.HOLD,
                    symbol=symbol,
                    confidence=0.50,
                    strategy="ai_ensemble",
                    price=current_price,
                    metadata={'status': 'cold_start_warmup'}
                )

            # Predict
            latest_features = features_df.iloc[[-1]]
            prediction, confidence = self.ml_predictor.predict(latest_features)
            
            # Tính toán ngưỡng tự tin động (Dynamic Threshold) dựa vào cấu trúc thị trường
            base_threshold = self.config['ai'].get('confidence_threshold', 0.60)
            dynamic_threshold = base_threshold
            
            regime_info = market_analysis or {}
            try:
                from ai.market_regime import MarketRegimeDetector, MarketRegime
                if not regime_info:
                    regime_info = MarketRegimeDetector().detect_regime(df)
                regime = regime_info.get('regime')
                if isinstance(regime, str):
                    regime = MarketRegime(regime)
                
                # Điều chỉnh ngưỡng tự tin tùy theo sức mạnh xu hướng
                if regime in [MarketRegime.STRONG_UPTREND, MarketRegime.STRONG_DOWNTREND]:
                    dynamic_threshold = max(0.40, base_threshold - 0.15)  # Xu hướng mạnh -> Dễ dãi hơn
                elif regime in [MarketRegime.UPTREND, MarketRegime.DOWNTREND]:
                    dynamic_threshold = max(0.50, base_threshold - 0.05)
                elif regime == MarketRegime.HIGH_VOLATILITY:
                    dynamic_threshold = min(0.85, base_threshold + 0.15)  # Biến động mạnh -> Khắt khe hơn

                # Ngưỡng sàn cơ sở của AI Ensemble: Tối thiểu 50% để chuyển cho SignalAggregator thẩm định vi mô
                dynamic_threshold = max(0.50, dynamic_threshold)
            except Exception as e:
                pass
            
            if prediction == 1 and confidence >= dynamic_threshold:
                return TradeSignal(
                    signal=Signal.BUY,
                    symbol=symbol,
                    confidence=confidence,
                    strategy="ai_ensemble",
                    price=current_price,
                    metadata={
                        'prediction': 'up', 'model_confidence': confidence,
                        'threshold': dynamic_threshold, 'market_analysis': market_analysis or {},
                    }
                )
            elif prediction == 0 and confidence >= dynamic_threshold:
                return TradeSignal(
                    signal=Signal.SELL,
                    symbol=symbol,
                    confidence=confidence,
                    strategy="ai_ensemble",
                    price=current_price,
                    metadata={
                        'prediction': 'down', 'model_confidence': confidence,
                        'threshold': dynamic_threshold, 'market_analysis': market_analysis or {},
                    }
                )
            
            return None
            
        except Exception as e:
            logger.error(f"Lỗi AI analysis: {e}")
            return None

    
    def _notify_telegram(self, msg: str):
        # Credentials belong in environment variables, with fallback to config.
        token = (
            os.getenv('TELEGRAM_BOT_TOKEN', '')
            or self.config.get('notifications', {}).get('telegram_token', '')
        )
        chat_id = (
            os.getenv('TELEGRAM_CHAT_ID', '')
            or self.config.get('notifications', {}).get('telegram_chat_id', '')
        )
        if token and chat_id:
            self._telegram_warning_logged = False
            if not send_telegram_message(token, chat_id, msg):
                logger.warning("Telegram chưa xác nhận tin nhắn; xem phản hồi API và kiểm tra lại token/chat ID.")
        elif not self._telegram_warning_logged:
            logger.warning("Telegram chưa được cấu hình: thêm TELEGRAM_BOT_TOKEN và TELEGRAM_CHAT_ID trong .env hoặc giao diện Telegram.")
            self._telegram_warning_logged = True

    def _configured_max_leverage(self) -> int:
        try:
            value = float(self.config.get('trading', {}).get('max_leverage', 5))
            if not math.isfinite(value):
                return 1
            return min(150, max(1, int(value)))
        except (TypeError, ValueError, OverflowError):
            return 1

    def _configured_min_open_positions(self) -> int:
        """Return the minimum floor for dynamic position coordination."""
        val = self.config.get('trading', {}).get('min_open_trades', 1)
        try:
            return max(1, min(20, int(val)))
        except (TypeError, ValueError, OverflowError):
            return 1

    def _configured_max_open_positions(self) -> int:
        """Return the configurable safety ceiling, dynamically scaling with equity."""
        trading_limit = self.config.get('trading', {}).get('max_open_trades', None)
        risk_limit = self.config.get('risk', {}).get('max_open_positions', 10)
        
        # Tự động co giãn số slot vị thế theo nấc vốn thực tế (Kiến trúc B+C Hybrid):
        # Dưới 200$: 2 vị thế (tập trung hỏa lực 2 lệnh chất lượng cao, an toàn tuyệt đối)
        # 200$ - 500$: 3 vị thế
        # 500$ - 2,000$: 4 vị thế
        # 2,000$ - 10,000$: 6 vị thế
        # 10,000$ - 50,000$: 8 vị thế
        # Trên 50,000$: 10 vị thế
        equity = 40.0
        try:
            portfolio_equity, _, _ = self._portfolio_capacity_snapshot()
            if portfolio_equity and portfolio_equity > 0:
                equity = float(portfolio_equity)
            else:
                equity = float(getattr(self, 'balance', 40.0) or 40.0)
        except Exception:
            equity = float(getattr(self, 'balance', 40.0) or 40.0)

        if equity < 200.0:
            equity_slots = 2
        elif equity < 500.0:
            equity_slots = 3
        elif equity < 2000.0:
            equity_slots = 4
        elif equity < 10000.0:
            equity_slots = 6
        elif equity < 50000.0:
            equity_slots = 8
        else:
            equity_slots = 10

        # Nếu người dùng đã tùy chỉnh trên Web UI (trading_limit), ưu tiên tuyệt đối thiết lập của người dùng
        configured_cap = equity_slots
        if trading_limit is not None:
            try:
                base_cfg = max(1, min(20, int(trading_limit)))
                configured_cap = base_cfg
            except (TypeError, ValueError, OverflowError):
                pass
        
        try:
            risk_cap = max(1, min(100, int(risk_limit)))
            return min(risk_cap, configured_cap)
        except Exception:
            return configured_cap

    def _max_margin_utilization(self) -> float:
        """Read the configured equity fraction reserved for futures margin."""
        try:
            value = float(self.config.get('risk', {}).get('max_margin_utilization_pct', 0.50))
            if value > 1:
                value /= 100.0
        except (TypeError, ValueError, OverflowError):
            value = 0.50
        if not math.isfinite(value) or not 0.05 <= value <= 0.90:
            return 0.50
        return value

    def _max_total_open_risk(self) -> float:
        """Read the portfolio stop-loss risk ceiling as a fraction of equity."""
        try:
            value = float(self.config.get('risk', {}).get('max_total_open_risk_pct', 0.08))
            if value > 1:
                value /= 100.0
        except (TypeError, ValueError, OverflowError):
            value = 0.08
        if not math.isfinite(value) or not 0.01 <= value <= 0.25:
            return 0.08
        return value

    def _portfolio_capacity_snapshot(self):
        """Return (equity, used margin, free margin) from the freshest safe source."""
        positions = list(getattr(self, 'open_positions', []) or [])
        local_used_margin = 0.0
        local_unrealized = 0.0
        for position in positions:
            try:
                local_used_margin += max(0.0, float(
                    position.get('exchange_initial_margin') or position.get('cost') or 0.0
                ))
                local_unrealized += float(
                    position.get('unrealized_pnl_mark', position.get('real_pnl', 0.0)) or 0.0
                )
            except (TypeError, ValueError, OverflowError):
                continue

        snapshot = getattr(self, '_futures_account_snapshot', None)
        snapshot_age = None
        snapshot_clock = getattr(self, '_futures_account_snapshot_monotonic', None)
        if snapshot_clock is not None:
            try:
                import time as _time
                snapshot_age = _time.monotonic() - snapshot_clock
            except (TypeError, ValueError, OverflowError):
                snapshot_age = None
        if (
            getattr(self, 'mode', 'demo') == 'live'
            and getattr(self, 'market_type', 'spot') == 'futures'
            and snapshot
            and snapshot_age is not None
            and 0 <= snapshot_age <= 30
        ):
            try:
                equity = float(snapshot.get('margin_balance'))
                used_margin = float(snapshot.get('initial_margin') or local_used_margin)
                free_balance = float(snapshot.get('available_balance', self.balance))
                if all(math.isfinite(value) for value in (equity, used_margin, free_balance)) and equity > 0:
                    used_margin = max(0.0, used_margin)
                    free_margin = max(
                        0.0,
                        min(free_balance, equity * self._max_margin_utilization() - used_margin),
                    )
                    return equity, used_margin, free_margin
            except (TypeError, ValueError, OverflowError):
                pass

        try:
            free_balance = max(0.0, float(self.balance))
        except (TypeError, ValueError, OverflowError):
            free_balance = 0.0
        equity = max(0.0, free_balance + local_used_margin + local_unrealized)
        free_margin = max(
            0.0,
            min(free_balance, equity * self._max_margin_utilization() - local_used_margin),
        )
        return equity, local_used_margin, free_margin

    def _current_open_stop_risk(self) -> float:
        """Estimate the combined loss at current protective stops for open positions."""
        try:
            fallback_stop_pct = float(self.config.get('risk', {}).get('stop_loss_pct', 0.04))
        except (TypeError, ValueError, OverflowError):
            fallback_stop_pct = 0.04
        if not math.isfinite(fallback_stop_pct) or not 0 < fallback_stop_pct < 1:
            fallback_stop_pct = 0.04

        total_risk = 0.0
        for position in getattr(self, 'open_positions', []) or []:
            try:
                entry = float(position.get('entry_price') or 0.0)
                amount = abs(float(position.get('amount') or 0.0))
                stop = float(position.get('stop_loss') or 0.0)
                direction = str(position.get('direction', 'LONG')).upper()
                if entry <= 0 or amount <= 0:
                    continue
                if stop > 0:
                    # Nếu Stop Loss đã dịch vào vùng có lãi hoặc hòa vốn (Trailing SL bảo vệ):
                    # Rủi ro vốn thực tế = 0 (không tính lãi bảo vệ thành rủi ro)
                    if direction == 'SHORT':
                        distance = max(0.0, stop - entry)
                    else:
                        distance = max(0.0, entry - stop)
                else:
                    distance = entry * fallback_stop_pct
                if math.isfinite(distance):
                    total_risk += amount * distance
            except (TypeError, ValueError, OverflowError):
                continue
        return max(0.0, total_risk)

    def _dynamic_open_position_limit(self, signal) -> int:
        """Estimate an open-position cap from analysis, equity, margin and stop risk."""
        hard_cap = self._configured_max_open_positions()
        current_count = len(getattr(self, 'open_positions', []) or [])
        self.last_dynamic_position_limit = max(current_count, hard_cap)
        if hard_cap <= 0:
            self.last_dynamic_position_limit = current_count
            self.last_position_signal_quality = None
            return current_count

        metadata = getattr(signal, 'metadata', {}) or {}
        metadata = metadata if isinstance(metadata, dict) else {}
        market = metadata.get('market_analysis') or {}
        market = market if isinstance(market, dict) else {}
        try:
            confidence = float(signal.confidence)
            agreement = float(metadata.get('agreement_ratio', 0.0))
            adx = float(market.get('adx', 0.0))
            di_plus = float(market.get('di_plus', 0.0))
            di_minus = float(market.get('di_minus', 0.0))
            atr_pct = float(market.get('atr_pct', 0.0))
            metrics = (confidence, agreement, adx, di_plus, di_minus, atr_pct)
            if not all(math.isfinite(value) for value in metrics):
                raise ValueError('non-finite signal metrics')
        except (TypeError, ValueError, OverflowError):
            confidence, agreement, adx, di_plus, di_minus, atr_pct = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0

        confidence = min(1.0, max(0.0, confidence))
        agreement = min(1.0, max(0.0, agreement))
        try:
            threshold = float(self.config.get('ai', {}).get('confidence_threshold', 0.65))
            if not math.isfinite(threshold):
                threshold = 0.65
        except (TypeError, ValueError, OverflowError):
            threshold = 0.65
        threshold = min(0.95, max(0.0, threshold))

        regime = str(market.get('regime', 'unknown')).lower()
        direction = str(getattr(getattr(signal, 'signal', None), 'value', '')).lower()
        bullish = direction == 'buy'
        ema_alignment = str(market.get('ema_alignment', '')).lower()
        trend_aligned = (
            (bullish and (ema_alignment == 'bullish' or di_plus > di_minus))
            or (not bullish and (ema_alignment == 'bearish' or di_minus > di_plus))
        )
        strong_trend = (
            'strong_uptrend' in regime or 'strong_downtrend' in regime
            or regime in ('uptrend', 'downtrend') or adx >= 25
        )
        ai_bias = str(metadata.get('ai_bias', 'NEUTRAL')).upper()
        bias_aligned = (
            ai_bias == 'NEUTRAL'
            or (ai_bias == 'BULLISH' and bullish)
            or (ai_bias == 'BEARISH' and not bullish)
        )

        confidence_quality = min(
            1.0,
            max(0.0, (confidence - threshold) / max(0.05, 1.0 - threshold)),
        )
        trend_quality = 1.0 if trend_aligned and strong_trend else (0.2 if not trend_aligned else 0.5)
        volatility_quality = min(1.0, max(0.1, 1.0 - atr_pct / 5.0)) if atr_pct > 0 else 0.3
        quality = 0.45 * confidence_quality + 0.35 * agreement + 0.15 * trend_quality + 0.05 * volatility_quality
        if regime == 'high_volatility' or (adx >= 25 and not trend_aligned):
            quality *= 0.65
        self.last_position_signal_quality = round(quality, 3)

        min_cap = self._configured_min_open_positions()
        hard_cap = max(min_cap, hard_cap)
        try:
            ai_recommendation = int(self.ai_recommended_max_positions)
        except (TypeError, ValueError, OverflowError):
            ai_recommendation = min_cap
        ai_recommendation = min(hard_cap, max(min_cap, ai_recommendation))

        # AI's suggested count is advisory. The technical/quant score can grow
        # the target smoothly; margin and aggregate stop risk still cap it.
        spread = max(0, hard_cap - min_cap)
        quality_cap = min(
            hard_cap,
            max(min_cap, min_cap + round(quality * spread)),
        )
        ai_quality_cap = min(
            hard_cap,
            max(min_cap, min_cap + round(quality * max(0, min(hard_cap, ai_recommendation) - min_cap))),
        )
        analysis_cap = min(hard_cap, max(quality_cap, ai_quality_cap))

        equity, used_margin, free_margin = self._portfolio_capacity_snapshot()
        risk_cfg = self.config.get('risk', {})
        try:
            risk_pct = float(risk_cfg.get('max_risk_per_trade', 0.02))
        except (TypeError, ValueError, OverflowError):
            risk_pct = 0.02
        if not math.isfinite(risk_pct) or not 0 < risk_pct <= 0.05:
            risk_pct = 0.02
        current_stop_risk = self._current_open_stop_risk()
        remaining_total_risk = max(0.0, equity * self._max_total_open_risk() - current_stop_risk)

        try:
            price = float(signal.price)
            stop = float(getattr(signal, 'stop_loss', None) or 0.0)
        except (TypeError, ValueError, OverflowError):
            price, stop = 0.0, 0.0
        if price > 0 and stop > 0:
            stop_distance_pct = abs(price - stop) / price
        else:
            try:
                stop_distance_pct = float(risk_cfg.get('stop_loss_pct', 0.04))
            except (TypeError, ValueError, OverflowError):
                stop_distance_pct = 0.04
        if not math.isfinite(stop_distance_pct) or not 0 < stop_distance_pct < 1:
            stop_distance_pct = 0.04

        candidate_risk = min(
            max(0.0, float(getattr(self, 'balance', 0.0))) * risk_pct,
            max(0.0, equity) * risk_pct,
            remaining_total_risk,
        )
        margin_slots = 0
        risk_slots = 0
        candidate_margin = 0.0
        candidate_notional = 0.0
        candidate_leverage = 1
        leverage_verified = True
        if candidate_risk > 0 and stop_distance_pct > 0:
            candidate_notional = candidate_risk / stop_distance_pct
            candidate_leverage = self._select_dynamic_leverage(signal)
            if getattr(self, 'market_type', 'spot') == 'futures':
                resolved_leverage, leverage_limit = self._resolve_pair_leverage(
                    signal.symbol, candidate_leverage, candidate_notional, free_margin,
                )
                leverage_verified = bool(leverage_limit.get('verified'))
                self.last_leverage_symbol = signal.symbol
                self.last_pair_max_leverage = leverage_limit.get('max_leverage')
                self.last_leverage_limit_verified = leverage_verified
                self.last_leverage_limit_source = leverage_limit.get('source')
                if resolved_leverage is None:
                    candidate_leverage = 0
                else:
                    candidate_leverage = max(1, int(resolved_leverage))
            if candidate_leverage > 0 and candidate_notional > 0:
                candidate_margin = candidate_notional / candidate_leverage
                if candidate_margin > 0 and free_margin > 0:
                    margin_slots = max(0, int((free_margin + 1e-9) / candidate_margin))
                    if margin_slots == 0:
                        # _execute_signal_locked caps the actual order size to
                        # available_margin. Allow that one reduced-size position
                        # through the slot gate; its stop risk stays at or below
                        # the candidate risk budget, and exchange min-notional
                        # checks can still reject it later.
                        margin_slots = 1
                        logger.info(
                            "Allow one reduced-size slot for %s: candidate margin %.2f exceeds "
                            "available margin %.2f; execution will cap size to available margin.",
                            signal.symbol, candidate_margin, free_margin,
                        )
                if candidate_risk > 0:
                    risk_slots = max(0, int((remaining_total_risk + 1e-9) / candidate_risk))

        account_cap = current_count + margin_slots
        risk_cap = current_count + risk_slots
        allowed = min(hard_cap, analysis_cap, account_cap, risk_cap)
        if getattr(self, 'mode', 'demo') == 'live' and not leverage_verified:
            # Never allocate new LIVE capacity from an unverified symbol tier.
            allowed = current_count
        allowed = max(current_count, allowed)
        self.last_dynamic_position_limit = allowed
        self.last_position_available_margin = round(free_margin, 6)
        self.last_position_open_risk = round(current_stop_risk, 6)
        self.last_position_risk_budget = round(remaining_total_risk, 6)
        logger.info(
            "Adaptive open-position cap for %s: %d/%d (analysis=%d, AI suggestion=%d, "
            "equity=%.2f, free margin=%.2f, candidate margin=%.2f at %dx, "
            "open stop risk=%.2f/%.2f, quality=%.2f, regime=%s, ADX=%.1f, ATR=%.2f%%).",
            signal.symbol, allowed, hard_cap, analysis_cap, ai_recommendation,
            equity, free_margin, candidate_margin, candidate_leverage,
            current_stop_risk, equity * self._max_total_open_risk(), quality,
            regime, adx, atr_pct,
        )
        return allowed

    def _resolve_pair_leverage(self, symbol, requested_leverage, target_notional, available_margin):
        """Clamp the strategy-selected leverage to the exchange tier for this pair."""
        get_max_leverage = getattr(self.exchange, 'get_max_leverage', None)
        if not callable(get_max_leverage):
            return (None if self.mode == 'live' else requested_leverage), {
                'max_leverage': None, 'verified': False, 'source': 'unavailable',
                'error': 'Exchange connector cannot read leverage limits',
            }

        initial = get_max_leverage(symbol, target_notional)
        if not initial.get('verified'):
            # Paper mode may still simulate the user's selected cap, but make the
            # missing exchange verification visible. LIVE fails closed below.
            return (None if self.mode == 'live' else requested_leverage), initial

        target_notional = max(0.0, float(target_notional))
        available_margin = max(0.0, float(available_margin))
        for candidate in range(int(requested_leverage), 0, -1):
            expected_notional = min(target_notional, available_margin * candidate)
            limit = get_max_leverage(symbol, expected_notional)
            if limit.get('verified') and candidate <= int(limit.get('max_leverage') or 1):
                return candidate, limit

        # The first bracket always permits at least 1x; retain a hard-safe floor
        # if an exchange returns malformed or incomplete tiers.
        return 1, initial

    def _select_dynamic_leverage(self, signal) -> int:
        """Select an integer futures leverage from 1x up to the user's cap."""
        if getattr(self, 'market_type', 'spot') != 'futures':
            self.last_dynamic_leverage = 1
            return 1

        max_leverage = self._configured_max_leverage()

        metadata = getattr(signal, 'metadata', {}) or {}
        metadata = metadata if isinstance(metadata, dict) else {}
        try:
            confidence = float(signal.confidence)
            if not math.isfinite(confidence):
                confidence = 0.0
        except (TypeError, ValueError, OverflowError):
            confidence = 0.0
        confidence = min(1.0, max(0.0, confidence))
        try:
            confidence_threshold = float(self.config.get('ai', {}).get('confidence_threshold', 0.65))
            if not math.isfinite(confidence_threshold):
                confidence_threshold = 0.65
        except (TypeError, ValueError, OverflowError):
            confidence_threshold = 0.65
        confidence_threshold = min(0.95, max(0.0, confidence_threshold))
        confidence_quality = min(
            1.0,
            max(0.0, (confidence - confidence_threshold) / max(0.05, 1.0 - confidence_threshold)),
        )

        try:
            agreement = float(metadata.get('agreement_ratio', 0.5))
            if not math.isfinite(agreement):
                agreement = 0.5
        except (TypeError, ValueError, OverflowError):
            agreement = 0.5
        agreement = min(1.0, max(0.0, agreement))

        market = metadata.get('market_analysis') or {}
        market = market if isinstance(market, dict) else {}
        regime = str(market.get('regime', 'ranging')).lower()
        direction = getattr(getattr(signal, 'signal', None), 'value', '')
        bullish_signal = direction == 'buy'
        bullish_market = str(market.get('ema_alignment', '')).lower() == 'bullish'
        bearish_market = str(market.get('ema_alignment', '')).lower() == 'bearish'
        try:
            adx = float(market.get('adx', 0.0))
            di_plus = float(market.get('di_plus', 0.0))
            di_minus = float(market.get('di_minus', 0.0))
            atr_pct = float(market.get('atr_pct', 0.0))
            if not all(math.isfinite(v) for v in (adx, di_plus, di_minus, atr_pct)):
                raise ValueError('invalid market metrics')
        except (TypeError, ValueError, OverflowError):
            adx, di_plus, di_minus, atr_pct = 0.0, 0.0, 0.0, 0.0

        market_trend_aligned = (
            (bullish_signal and (bullish_market or di_plus > di_minus))
            or (not bullish_signal and (bearish_market or di_minus > di_plus))
        )
        if regime == 'high_volatility':
            trend_quality = 0.15
        elif 'strong_uptrend' in regime or 'strong_downtrend' in regime:
            trend_quality = 1.0 if market_trend_aligned else 0.10
        elif regime in ('uptrend', 'downtrend'):
            trend_quality = 0.80 if market_trend_aligned else 0.20
        elif adx >= 25:
            trend_quality = 0.75 if market_trend_aligned else 0.20
        elif regime == 'ranging':
            trend_quality = 0.40
        else:
            trend_quality = 0.50

        # MarketRegimeDetector reports ATR as percent units (e.g. 2.0 means 2%).
        volatility_quality = min(1.0, max(0.10, 1.0 - atr_pct / 5.0)) if atr_pct > 0 else 0.50
        ai_bias = str(metadata.get('ai_bias', 'NEUTRAL')).upper()
        aligned_bias = (ai_bias == 'BULLISH' and bullish_signal) or (ai_bias == 'BEARISH' and not bullish_signal)
        opposite_bias = (ai_bias == 'BEARISH' and bullish_signal) or (ai_bias == 'BULLISH' and not bullish_signal)
        bias_quality = 1.0 if aligned_bias else (0.15 if opposite_bias else 0.50)

        quality = (
            0.35 * confidence_quality
            + 0.30 * agreement
            + 0.20 * trend_quality
            + 0.10 * volatility_quality
            + 0.05 * bias_quality
        )
        if regime == 'high_volatility' or (adx >= 25 and not market_trend_aligned):
            quality *= 0.65
        leverage_quality = min(1.0, max(0.0, (quality - 0.40) / 0.60))
        leverage = min(
            max_leverage,
            max(1, math.floor(1 + leverage_quality * (max_leverage - 1) + 0.5)),
        )
        self.last_dynamic_leverage = leverage
        self.last_signal_quality = quality
        if isinstance(getattr(signal, 'metadata', None), dict):
            signal.metadata['signal_quality'] = quality
        logger.info(
            "Dynamic leverage %s: %dx (cap=%dx, quality=%.2f, confidence=%.2f, "
            "consensus=%.2f, regime=%s, ADX=%.1f, ATR=%.2f%%, AI=%s)",
            signal.symbol, leverage, max_leverage, quality, confidence, agreement,
            regime, adx, atr_pct, ai_bias,
        )
        return leverage

    def _pre_trade_safety_gate(self, signal) -> tuple:
        """
        Bộ lọc an toàn trước khi vào lệnh (Pre-Trade Safety Gate):
        1. Volume Exhaustion Filter (AIStock & QuantDinger): Chặn bẫy suy kiệt khối lượng / mua đỉnh xả.
        2. Derivatives Gate (Funding Rate & OI): Tránh bẫy thanh khoản cá mập (Long/Short squeeze).
        3. Order Book Depth Gate: Tránh lao đầu vào tường cản lớn (Order Book Imbalance).
        """
        from strategies.base_strategy import Signal
        symbol = signal.symbol
        sig_val = getattr(signal.signal, 'value', str(signal.signal)).upper()
        side = 'BUY' if sig_val in ('BUY', 'SIGNAL.BUY') else 'SELL'
        
        # 1. BỘ LỌC SUY KIỆT VOLUME (VOLUME EXHAUSTION)
        try:
            dfs = signal.metadata.get('dfs') or {}
            df_tactical = dfs.get('15m')
            if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                df_tactical = dfs.get('5m')
            if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                df_tactical = self.data_collector.fetch_data(symbol, '15m', limit=30)
                
            # 0. CHỐT CHẶN ĐỒNG PHA NẾN 15M TÁC CHIẾN (15M TACTICAL ALIGNMENT GATE)
            # Triệt tiêu tình trạng chỉ báo khung lớn 4H trễ pha lôi bot vào lệnh khi nến 15M đang rơi tự do
            if df_tactical is not None and len(df_tactical) >= 20:
                try:
                    tactical_close = float(df_tactical['close'].iloc[-2])
                    ema20_tactical = float(df_tactical['close'].ewm(span=20, adjust=False).mean().iloc[-2])
                    import ta
                    rsi_tactical_s = ta.momentum.RSIIndicator(df_tactical['close'].iloc[:-1], window=14).rsi().dropna()
                    rsi_tactical = float(rsi_tactical_s.iloc[-1]) if not rsi_tactical_s.empty else 50.0
                    
                    strat_name_chk = str(getattr(signal, 'strategy', '')).lower()
                    _md = getattr(signal, 'metadata', None)
                    _contrib = [str(x).lower() for x in (_md.get('contributing_strategies', []) if isinstance(_md, dict) else [])]
                    is_mr_trade = ('mean_reversion' in strat_name_chk) or ('mean_reversion' in _contrib)
                    clean_sym_chk = symbol.split(':')[0].strip().upper()
                    clean_base_chk = clean_sym_chk.split('/')[0] if '/' in clean_sym_chk else clean_sym_chk
                    is_major_pair = any(clean_base_chk == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
                    
                    # Chỉ áp dụng cho các chiến thuật xu hướng và trên Altcoin; Miễn trừ cho Mean Reversion (chuyên bắt đáy RSI < 30) và Cổ phiếu / Hàng hóa TradFi
                    is_tradfi_pre = MarketScanner.is_tradfi_stock(symbol, self.exchange) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol, self.exchange))
                    if not is_mr_trade and not is_major_pair and not is_tradfi_pre:
                        if side == 'BUY':
                            if tactical_close < ema20_tactical * 0.995 and rsi_tactical < 45.0:
                                return False, (
                                    f"Nến 15M lệch pha đà giảm (15M Alignment Gate): Giá ({tactical_close:.4f}) < EMA20 ({ema20_tactical:.4f}) "
                                    f"& RSI ({rsi_tactical:.1f}) < 45. Cấm mở BUY khi nến tác chiến 15M đang rơi tự do!"
                                )
                        elif side == 'SELL':
                            if tactical_close > ema20_tactical * 1.005 and rsi_tactical > 55.0:
                                return False, (
                                    f"Nến 15M lệch pha đà tăng (15M Alignment Gate): Giá ({tactical_close:.4f}) > EMA20 ({ema20_tactical:.4f}) "
                                    f"& RSI ({rsi_tactical:.1f}) > 55. Cấm mở SHORT khi nến tác chiến 15M đang tăng vọt!"
                                )
                except Exception as e:
                    logger.debug(f"Bỏ qua kiểm tra 15M Alignment cho {symbol}: {e}")

            # Lưu ý chuẩn định lượng: Toàn bộ chiến thuật (Trend, Trap, Reversion) đều tạo tín hiệu dựa trên nến vừa đóng cửa (iloc[-2]).
            # Nến iloc[-1] trên Binance là nến ĐANG CHẠY (chưa đóng cửa), chỉ mới chạy được vài phút nên volume rất nhỏ.
            # Do đó, kiểm tra Volume và Exhaustion BẮT BUỘC phải xét nến hoàn chỉnh vừa đóng (iloc[-2]) so với lịch sử các nến đóng trước đó!
            if df_tactical is not None and len(df_tactical) >= 10:
                vol_history = df_tactical['volume'].iloc[:-2].tail(20)
                sma_vol_20 = float(vol_history.mean()) if not vol_history.empty else 0.0
                curr_vol_chk = float(df_tactical['volume'].iloc[-2])
                rvol_thresh = float(self.config.get('risk', {}).get('rvol_filter_threshold', 0.45))
                if sma_vol_20 > 0 and math.isfinite(sma_vol_20) and math.isfinite(curr_vol_chk):
                    rvol = curr_vol_chk / sma_vol_20
                    if rvol < rvol_thresh:
                        return False, (
                            f"Thanh khoản cạn kiệt (RVol Gate): Volume nến tín hiệu ({curr_vol_chk:.0f}) "
                            f"chỉ đạt {rvol*100:.1f}% mức trung bình 20 kỳ ({sma_vol_20:.0f} < sàn {rvol_thresh*100:.0f}%). "
                            f"Cấm vào lệnh trong vùng thanh khoản kiệt quệ / Sideway bẫy!"
                        )

            if df_tactical is not None and len(df_tactical) >= 8:
                prev_candles = df_tactical.iloc[-6:-2]
                curr_candle = df_tactical.iloc[-2]
                
                max_prev_vol = float(prev_candles['volume'].max())
                curr_vol = float(curr_candle['volume'])
                # Nâng cấp ngưỡng suy kiệt volume từ 0.50 lên 0.65 theo kết quả thực nghiệm đối soát lịch sử
                exhaustion_threshold = float(self.config.get('risk', {}).get('volume_exhaustion_ratio', 0.50))
                
                if max_prev_vol > 0:
                    vol_ratio = curr_vol / max_prev_vol
                    if side == 'BUY':
                        prev_highest = float(prev_candles['high'].max())
                        curr_close = float(curr_candle['close'])
                        curr_open = float(curr_candle['open'])
                        upper_shadow = float(curr_candle['high'] - max(curr_close, curr_open))
                        body = abs(curr_close - curr_open)
                        
                        if vol_ratio < exhaustion_threshold and curr_close < prev_highest:
                            if (curr_close < curr_open) or (upper_shadow > body):
                                return False, (
                                    f"Suy kiệt Volume phe Mua: Volume nến tín hiệu ({curr_vol:.0f}) "
                                    f"sụt giảm {(1-vol_ratio)*100:.1f}% so với đỉnh volume trước ({max_prev_vol:.0f}), "
                                    f"giá ({curr_close:.5f}) không bứt phá được đỉnh ({prev_highest:.5f}) kèm râu xả!"
                                )
                    elif side == 'SELL':
                        prev_lowest = float(prev_candles['low'].min())
                        curr_close = float(curr_candle['close'])
                        curr_open = float(curr_candle['open'])
                        lower_shadow = float(min(curr_close, curr_open) - curr_candle['low'])
                        body = abs(curr_close - curr_open)
                        
                        if vol_ratio < exhaustion_threshold and curr_close > prev_lowest:
                            if (curr_close > curr_open) or (lower_shadow > body):
                                return False, (
                                    f"Suy kiệt Volume phe Bán: Volume nến tín hiệu ({curr_vol:.0f}) "
                                    f"sụt giảm {(1-vol_ratio)*100:.1f}% so với đáy xả ({max_prev_vol:.0f}), "
                                    f"giá ({curr_close:.5f}) hồi phục trên đáy ({prev_lowest:.5f}) kèm rút chân!"
                                )
        except Exception as e:
            logger.debug(f"Bỏ qua kiểm tra Volume Exhaustion cho {symbol}: {e}")

        # 2. BỘ LỌC PHÁI SINH: FUNDING RATE & OPEN INTEREST
        if getattr(self, 'market_type', 'spot') == 'futures':
            try:
                funding_info = self.exchange.get_funding_rate(symbol)
                if funding_info and funding_info.get('fundingRate') is not None:
                    fr = float(funding_info['fundingRate'])
                    if isinstance(getattr(signal, 'metadata', None), dict):
                        signal.metadata['funding_rate'] = fr
                    fr_threshold = float(self.config.get('risk', {}).get('funding_extreme_threshold', 0.0003))
                    
                    if side == 'BUY' and fr > fr_threshold:
                        return False, (
                            f"Funding Rate quá cao ({fr*100:+.4f}% > +{fr_threshold*100:.2f}%): "
                            f"Phe Long quá đông, nguy cơ Long Squeeze quét thanh khoản rất cao"
                        )
                    elif side == 'SELL' and fr < -fr_threshold:
                        return False, (
                            f"Funding Rate quá âm ({fr*100:+.4f}% < -{fr_threshold*100:.2f}%): "
                            f"Phe Short quá đông, nguy cơ Short Squeeze ép bứt phá rất cao"
                        )
            except Exception as e:
                logger.debug(f"Bỏ qua kiểm tra Funding Rate cho {symbol}: {e}")

        # 3. BỘ LỌC ĐỘ SÂU SỔ LỆNH & CHÊNH LỆCH GIÁ (ORDER BOOK DEPTH & SPREAD GATE)
        try:
            ob = self.exchange.get_order_book(symbol, limit=20)
            if ob and ob.get('bids') and ob.get('asks'):
                # Kiểm tra Spread (chênh lệch Bid/Ask) chống trượt giá Market
                if len(ob['bids']) > 0 and len(ob['asks']) > 0:
                    best_bid = float(ob['bids'][0][0])
                    best_ask = float(ob['asks'][0][0])
                    if best_bid > 0 and best_ask >= best_bid:
                        spread_pct = (best_ask - best_bid) / best_bid
                        is_tradfi_pair = MarketScanner.is_tradfi_stock(symbol, self.exchange) or MarketScanner.is_tradfi_commodity(symbol, self.exchange)
                        max_allowed_spread = 0.0030 if is_tradfi_pair else 0.0018
                        if spread_pct > max_allowed_spread:
                            return False, (
                                f"Chênh lệch giá (Spread) quá giãn ({spread_pct*100:.2f}% > {max_allowed_spread*100:.2f}%): "
                                f"Nguy cơ trượt giá cao khi vào lệnh Market, từ chối mở vị thế!"
                            )

                bids_vol = sum(float(b[1]) for b in ob['bids'][:10] if len(b) > 1)
                asks_vol = sum(float(a[1]) for a in ob['asks'][:10] if len(a) > 1)
                imbalance_threshold = float(self.config.get('risk', {}).get('max_order_book_imbalance', 3.0))
                
                if side == 'BUY' and bids_vol > 0 and (asks_vol / bids_vol >= imbalance_threshold):
                    return False, (
                        f"Áp lực cản sổ lệnh quá lớn: Tường bán ({asks_vol:.1f}) dày gấp "
                        f"{asks_vol/bids_vol:.1f}x tường mua ({bids_vol:.1f}) trong 10 bước giá"
                    )
                elif side == 'SELL' and asks_vol > 0 and (bids_vol / asks_vol >= imbalance_threshold):
                    return False, (
                        f"Áp lực đỡ sổ lệnh quá lớn: Tường mua ({bids_vol:.1f}) dày gấp "
                        f"{bids_vol/asks_vol:.1f}x tường bán ({asks_vol:.1f}) trong 10 bước giá"
                    )
        except Exception as e:
            logger.debug(f"Bỏ qua kiểm tra Order Book Depth cho {symbol}: {e}")

        return True, "Passed all pre-trade safety gates"

    def _execute_signal(self, signal) -> Optional[Dict]:
        """Serialize order-entry decisions with manual exits and position checks."""
        with self._position_lock:
            return self._execute_signal_locked(signal)

    def _execute_signal_locked(self, signal) -> Optional[Dict]:
        """
        Thực thi tín hiệu giao dịch sau khi kiểm tra rủi ro.
        """
        if not self.is_running:
            logger.info("Bỏ qua tín hiệu %s vì bot đã được yêu cầu dừng.", signal.symbol)
            return None
        from strategies.base_strategy import Signal
        
        # Kiểm tra rủi ro
        estimated_equity, existing_margin, _ = self._portfolio_capacity_snapshot()
        can_trade, reason = self.risk_manager.can_trade(
            signal, self.balance, self.open_positions, account_equity=estimated_equity,
        )
        
        if not can_trade:
            logger.info(f"⚠️ Không giao dịch: {reason}")
            return None

        # Kiểm tra Pre-Trade Safety Gate (Volume Exhaustion, Funding Rate, Order Book Depth)
        passes_gate, gate_reason = self._pre_trade_safety_gate(signal)
        if not passes_gate:
            logger.warning(f"🛡️ [PRE-TRADE GATE CHẶN] {signal.symbol} ({signal.signal.value.upper()}): {gate_reason}")
            try:
                from core.gate_telemetry import record_gate_event, record_radar_candidate
                gate_name = ('15M_ALIGNMENT' if '15M Alignment' in gate_reason else
                             'VOLUME_EXHAUSTION' if 'Suy kiệt Volume' in gate_reason else
                             'RVOL' if 'RVol Gate' in gate_reason else 'PRE_TRADE_GATE')
                record_gate_event(gate_name, signal.symbol, side=signal.signal.value.upper(), reason=gate_reason)

                readiness = 85.0 if 'RVol Gate' in gate_reason else (78.0 if '15M Alignment' in gate_reason else 72.0)
                meta_s = getattr(signal, 'metadata', {}) or {}
                contrib = meta_s.get('contributing_strategies', [])
                strat_str = f"{len(contrib)}/{self.config.get('ai',{}).get('min_agreeing_strategies',2)} chiến lược" if contrib else str(getattr(signal, 'strategy', ''))
                lev_calc = int(meta_s.get('dynamic_leverage', 5) or 5)

                record_radar_candidate(
                    symbol=signal.symbol,
                    side=signal.signal.value.upper(),
                    confidence=signal.confidence,
                    score=float(meta_s.get('weighted_score', 0.0) or 0.0),
                    strategies_agreed=strat_str,
                    dynamic_leverage=lev_calc,
                    bottleneck_gate=gate_name,
                    bottleneck_reason=gate_reason,
                    readiness_pct=readiness
                )
            except Exception:
                pass
            return None
        
        # position_size is quote-currency margin. Convert the risk budget and
        # actual stop distance to notional, then apply leverage and margin caps.
        if signal.price <= 0:
            logger.warning("Giá tín hiệu không hợp lệ, bỏ qua")
            return None

        # Kiểm tra nếu cặp tiền này đang có lệnh rình mồi M1 chờ khớp
        if signal.symbol in getattr(self, 'pending_stalking_orders', {}):
            stk = self.pending_stalking_orders[signal.symbol]
            current_stalking_dir = stk.get('direction', 'LONG')
            signal_dir = 'LONG' if signal.signal == Signal.BUY else 'SHORT'
            if current_stalking_dir == signal_dir:
                logger.info(f"⏳ Cặp {signal.symbol} đang có lệnh bắn tỉa M1 cùng chiều {signal_dir} chờ khớp; bỏ qua tín hiệu mới.")
                return None
            else:
                logger.info(f"🔄 Cặp {signal.symbol} đảo chiều từ {current_stalking_dir} -> {signal_dir}. Hủy lệnh rình mồi cũ để chuẩn bị theo chiều mới.")
                oid = stk.get('order_id')
                if self.mode == 'live' and oid:
                    try:
                        self.exchange.cancel_order(oid, signal.symbol)
                    except Exception as ce:
                        logger.error(f"Lỗi hủy lệnh rình mồi cũ {signal.symbol}: {ce}")
                self.pending_stalking_orders.pop(signal.symbol, None)
                self._save_state()

        # Khóa phòng thủ: Nếu là cổ phiếu TradFi nhưng tính năng TradFi đang TẮT, từ chối mở lệnh
        is_stock_pre = MarketScanner.is_tradfi_stock(signal.symbol)
        tradfi_active_pre = bool(self.config.get('tradfi', {}).get('enabled', False))
        if is_stock_pre and not tradfi_active_pre:
            logger.warning(
                f"🛡️ [TRADFI KHÓA] Bỏ qua lệnh {signal.symbol}: Cổ phiếu TradFi nhưng tradfi.enabled đang TẮT!"
            )
            return None

        # Chuẩn hóa khoảng cách Stop-Loss và Take-Profit theo ATR & Tỷ lệ R:R chuẩn
        meta = signal.metadata or {}
        market_analysis_meta = meta.get('market_analysis') if isinstance(meta.get('market_analysis'), dict) else {}
        atr_val = float(meta.get('atr') or 0)
        raw_meta_atr_pct = float(meta.get('atr_pct') or 0)
        if raw_meta_atr_pct <= 0 and market_analysis_meta.get('atr_pct'):
            try:
                ma_atr = float(market_analysis_meta.get('atr_pct') or 0)
                raw_meta_atr_pct = ma_atr / 100.0 if ma_atr > 0.25 else ma_atr
            except (TypeError, ValueError):
                raw_meta_atr_pct = 0.0
        atr_pct = (atr_val / signal.price) if (signal.price > 0 and atr_val > 0) else (raw_meta_atr_pct if raw_meta_atr_pct > 0 else 0.015)
        if atr_pct <= 0 or not math.isfinite(atr_pct):
            atr_pct = 0.015

        # Ngưỡng sàn tối thiểu để không bị nhiễu nến 15m quét: 1.5%
        min_sl_dist = 0.015
        # Ngưỡng trần tối đa tuyệt đối để khống chế rủi ro đuôi: 3.5%
        max_sl_dist = 0.035

        stop_loss = signal.stop_loss
        if stop_loss is None or not math.isfinite(float(stop_loss)) or float(stop_loss) <= 0:
            current_sl_dist = max(min_sl_dist, 1.2 * atr_pct)
        else:
            current_sl_dist = abs(signal.price - stop_loss) / signal.price

        # Kẹp cứng khoảng cách SL vào vùng an toàn [1.5%, 3.5%], tuyệt đối không vượt quá trần 3.5%
        clamped_sl_dist = min(max_sl_dist, max(min_sl_dist, current_sl_dist))
        
        if signal.signal == Signal.BUY:
            stop_loss = signal.price * (1.0 - clamped_sl_dist)
        else:
            stop_loss = signal.price * (1.0 + clamped_sl_dist)
            
        signal.stop_loss = stop_loss
        stop_distance_pct = clamped_sl_dist

        # Chuẩn hóa Take-Profit với tỷ lệ tối thiểu >= 1.8R
        target_rr = 2.0
        expected_tp_dist = clamped_sl_dist * target_rr

        if signal.take_profit and math.isfinite(float(signal.take_profit)):
            raw_tp_dist = abs(signal.take_profit - signal.price) / signal.price
            if raw_tp_dist < clamped_sl_dist * 1.5:
                clamped_tp_dist = expected_tp_dist
            elif raw_tp_dist > clamped_sl_dist * 3.5:
                clamped_tp_dist = clamped_sl_dist * 2.5
            else:
                clamped_tp_dist = raw_tp_dist
        else:
            clamped_tp_dist = expected_tp_dist
        clamped_tp_dist = max(0.015, clamped_tp_dist)

        if signal.signal == Signal.BUY:
            take_profit = signal.price * (1.0 + clamped_tp_dist)
        else:
            take_profit = signal.price * (1.0 - clamped_tp_dist)
            
        signal.take_profit = take_profit
        try:
            risk_pct = float(self.config['risk'].get('max_risk_per_trade', 0.02))
        except (TypeError, ValueError, OverflowError):
            risk_pct = 0.02
        if not math.isfinite(risk_pct) or not 0 < risk_pct <= 0.05:
            logger.warning("max_risk_per_trade cấu hình không hợp lệ, bỏ qua")
            return None
        leverage = self._select_dynamic_leverage(signal)
        sig_quality = getattr(self, 'last_signal_quality', 1.0)
        if getattr(self, 'market_type', 'spot') == 'futures' and (leverage < 3 or sig_quality < 0.45):
            logger.warning(
                f"🛡️ [LỌC TÍN HIỆU YẾU] Bỏ qua vào lệnh {signal.symbol}: "
                f"Đòn bẩy tính toán {leverage}x < 3x (Chỉ số chất lượng: {sig_quality:.2f} < 0.45). "
                f"Hệ thống từ chối mở lệnh rủi ro cao ở đòn bẩy thấp để bảo vệ an toàn vốn!"
            )
            return None

        # --- CỔNG THẨM ĐỊNH LƯỢNG TỬ KÉP (DUAL-ENGINE QUANTUM GATE v2.0) ---
        if not getattr(self, 'quantum_simulator', None):
            try:
                q_cfg = self.config.get('quantum_gate', {}) if isinstance(self.config.get('quantum_gate'), dict) else {}
                self.quantum_simulator = QuantumPathSimulator(
                    n_paths=int(q_cfg.get('n_paths', 2500)),
                    n_steps=int(q_cfg.get('n_steps', 40)),
                    min_win_prob=float(q_cfg.get('min_win_prob', 0.52)),
                    max_doa_prob=float(q_cfg.get('max_doa_prob', 0.40)),
                )
            except Exception:
                self.quantum_simulator = None
        if hasattr(self, 'quantum_simulator') and self.quantum_simulator is not None:
            try:
                q_atr_pct = float(market_analysis_meta.get('atr_pct') or (atr_pct * 100.0))
                if q_atr_pct <= 0 or not math.isfinite(q_atr_pct):
                    q_atr_pct = 2.5
                q_adx = float(market_analysis_meta.get('adx') or 30.0)
                if q_adx <= 0 or not math.isfinite(q_adx):
                    q_adx = 30.0
                q_regime = str(market_analysis_meta.get('regime') or meta.get('market_regime') or 'uptrend')
                q_btc_bias = str(meta.get('ai_bias') or 'NEUTRAL')
                q_funding = float(meta.get('funding_rate') or 0.0)

                q_res = self.quantum_simulator.simulate(
                    symbol=signal.symbol,
                    side=signal.signal.value.upper(),
                    entry_price=float(signal.price),
                    stop_loss=float(signal.stop_loss),
                    take_profit=float(signal.take_profit),
                    atr_pct=q_atr_pct,
                    adx=q_adx,
                    score=float(signal.confidence),
                    regime=q_regime,
                    btc_bias=q_btc_bias,
                    funding_rate=q_funding,
                )
                if not q_res.get('pass_gate', True):
                    logger.warning(
                        "🛡️ [QUANTUM GATE v2.0 VETO] Chặn lệnh %s %s (%s): P(Win)=%.1f%%, P(Loss)=%.1f%%, P(DOA)=%.1f%%, EV=%+.2f%%, R:R=%.2f | Lý do: %s (%.1fms)",
                        signal.signal.value.upper(),
                        signal.symbol,
                        q_res.get('asset_class', 'UNKNOWN'),
                        q_res.get('p_win', 0.0) * 100.0,
                        q_res.get('p_loss', 0.0) * 100.0,
                        q_res.get('p_doa', 0.0) * 100.0,
                        q_res.get('expected_ev_pct', 0.0),
                        q_res.get('reward_risk_ratio', 0.0),
                        ", ".join(q_res.get('veto_reasons', [])),
                        q_res.get('time_taken_ms', 0.0),
                    )
                    return None

                q_mult = float(q_res.get('leverage_multiplier', 1.0))
                if getattr(self, 'market_type', 'spot') == 'futures' and q_mult > 0 and q_mult != 1.0:
                    max_lev = self._configured_max_leverage()
                    adjusted_lev = max(3, min(max_lev, int(round(leverage * q_mult))))
                    if adjusted_lev != leverage:
                        logger.info(
                            "⚛️ [QUANTUM LEVERAGE SCALE] Điều chỉnh đòn bẩy %s từ %dx -> %dx theo hạng %s (P_Win=%.1f%%, Mult=%.2fx).",
                            signal.symbol,
                            leverage,
                            adjusted_lev,
                            q_res.get('confidence_tier', 'CONFIRMED'),
                            q_res.get('p_win', 0.0) * 100.0,
                            q_mult,
                        )
                        leverage = adjusted_lev
                        self.last_dynamic_leverage = leverage

                logger.info(
                    "⚛️ [QUANTUM GATE v2.0 PASS] Duyệt lệnh %s %s (%s): Tier=%s, P(Win)=%.1f%%, P(DOA)=%.1f%%, EV=%+.2f%%, R:R=%.2f, Leverage=%dx (%.1fms)",
                    signal.signal.value.upper(),
                    signal.symbol,
                    q_res.get('asset_class', 'UNKNOWN'),
                    q_res.get('confidence_tier', 'CONFIRMED'),
                    q_res.get('p_win', 0.0) * 100.0,
                    q_res.get('p_doa', 0.0) * 100.0,
                    q_res.get('expected_ev_pct', 0.0),
                    q_res.get('reward_risk_ratio', 0.0),
                    leverage,
                    q_res.get('time_taken_ms', 0.0),
                )
                if isinstance(getattr(signal, 'metadata', None), dict):
                    signal.metadata['quantum_validation'] = q_res
            except Exception as qe:
                logger.error(f"Lỗi thực thi Cổng Lượng Tử cho {signal.symbol}: {qe}")
        # Thực thi lệnh
        try:
            # Tìm vị thế ngược chiều để đóng
            matching_positions = [
                p for p in self.open_positions 
                if p['symbol'] == signal.symbol
            ]
            
            for pos in matching_positions:
                if (signal.signal == Signal.SELL and pos.get('direction', 'LONG') == 'LONG') or \
                   (signal.signal == Signal.BUY and pos.get('direction', 'LONG') == 'SHORT'):
                    pnl = self._close_position(pos, signal.price)
                    if pnl is not None:
                        logger.info(
                            f"{'✅' if pnl >= 0 else '❌'} ĐÓNG {pos.get('direction', 'LONG')} {signal.symbol}: "
                            f"Giá={signal.price:.6g}, "
                            f"PnL={pnl:+.4f} {self.config.get('trading', {}).get('base_currency', 'USDT')}"
                        )
            
            # Kiểm tra xem có nên mở vị thế mới không
            has_position = any(p['symbol'] == signal.symbol for p in self.open_positions)
            is_open_signal = False
            side = 'buy'
            direction = 'LONG'
            
            if signal.signal == Signal.BUY and not has_position:
                is_open_signal = True
                side = 'buy'
                direction = 'LONG'
            elif signal.signal == Signal.SELL and not has_position and getattr(self, 'market_type', 'spot') == 'futures':
                is_open_signal = True
                side = 'sell'
                direction = 'SHORT'
                
            if is_open_signal:
                dynamic_limit = self._dynamic_open_position_limit(signal)
                occupied_slots = len(self.open_positions) + len(getattr(self, 'pending_stalking_orders', {}))
                if occupied_slots >= dynamic_limit:
                    logger.info(
                        "Bỏ qua lệnh mới %s: số vị thế & lệnh rình mồi hiện tại %d đã chạm giới hạn động %d/%d.",
                        signal.symbol, occupied_slots, dynamic_limit,
                        self._configured_max_open_positions(),
                    )
                    return None

                portfolio_equity, already_used, available_margin = self._portfolio_capacity_snapshot()
                remaining_risk = max(
                    0.0,
                    portfolio_equity * self._max_total_open_risk() - self._current_open_stop_risk(),
                )
                # QUẢN TRỊ RỦI RO & PHÂN BỔ VỐN ĐỊNH LƯỢNG CO GIÃN ĐA QUY MÔ (SCALE-INVARIANT RISK PARITY SIZING):
                # 1. Ngân sách rủi ro cố định 0.60% Equity (chuẩn institutional Risk Parity, tự động co giãn từ 100$ đến 100,000$+)
                configured_slots = self._configured_max_open_positions()
                fixed_risk_pct = float(self.config.get('risk', {}).get('max_risk_per_trade', 0.0060))
                if fixed_risk_pct > 0.010:
                    fixed_risk_pct = 0.0060 # Khống chế cứng không quá 0.60%
                max_dollar_risk = max(0.35, portfolio_equity * fixed_risk_pct)
                risk_budget = min(
                    remaining_risk,
                    max_dollar_risk,
                )
                if risk_budget <= 0:
                    logger.info(
                        "Bỏ qua lệnh mới %s: đã dùng hết ngân sách rủi ro tổng (%.2f%% equity).",
                        signal.symbol, self._max_total_open_risk() * 100,
                    )
                    return None
                notional = risk_budget / stop_distance_pct
                
                # BẢO VỆ DANH MỤC: KHỐNG CHẾ TRẦN NOTIONAL CO GIÃN ĐỘNG THEO PHÂN KHÚC & SCALE-INVARIANT FRACTIONS
                clean_sym = self._clean_symbol(signal.symbol)
                base_coin_cap = signal.symbol.split('/')[0].split(':')[0].strip().upper()
                is_tier1 = base_coin_cap in ('BTC', 'ETH')
                is_stock = MarketScanner.is_tradfi_stock(signal.symbol, self.exchange)
                is_commodity = MarketScanner.is_tradfi_commodity(signal.symbol, self.exchange)
                is_major = base_coin_cap in ('SOL', 'XRP', 'BNB')
                
                if is_tier1:
                    max_notional_cap = max(10.0, portfolio_equity * 0.35)  # Tier 1 (BTC/ETH) tối đa 35% equity
                elif is_major:
                    max_notional_cap = max(8.0, portfolio_equity * 0.25)   # Tier 2 (Top Major Crypto) tối đa 25% equity
                elif is_stock or is_commodity:
                    max_notional_cap = max(6.0, portfolio_equity * 0.20)   # TradFi Equity / Commodity (spread dày) tối đa 20% equity
                else:
                    # Tier 3 (Altcoins): Trần chuẩn 20% equity.
                    # GHI CHÚ KIỂM CHỨNG THỰC TẾ:
                    # Với vốn nhỏ (portfolio_equity trong khoảng 40 - 70 USDT), áp dụng sàn tối thiểu 10.60 USDT
                    # để sau khi làm tròn bước số nguyên (lot step) của Altcoin, vị thế thực tế luôn đạt >= 10.20 USDT,
                    # đảm bảo khi cắt lỗ 50%, mỗi nửa đều >= 5.10 USDT > 5.00 USDT của Binance, tránh lỗi -4164.
                    min_small_cap_floor = 10.60 if portfolio_equity >= 40.0 else 6.0
                    max_notional_cap = max(min_small_cap_floor, portfolio_equity * 0.20)
                
                if notional > max_notional_cap:
                    logger.info(
                        "🛡️ [NOTIONAL CAP] Giới hạn vị thế %s từ %.2f USDT xuống trần %.2f USDT (Phân khúc: %s, Equity: %.2f USDT, Slot: %d).",
                        signal.symbol, notional, max_notional_cap,
                        'Tier 1 (BTC/ETH)' if is_tier1 else ('Tier 2 (TradFi)' if (is_stock or is_commodity) else ('Tier 2 (Major Crypto)' if is_major else 'Tier 3 (Altcoin)')),
                        portfolio_equity, configured_slots
                    )
                    notional = max_notional_cap
                
                # Luôn đảm bảo đạt ngưỡng Min Notional an toàn của Binance (>= 6.0 USDT)
                notional = max(6.0, notional)

                # Ép đòn bẩy TradFi xuống tối đa 4x để tránh trượt giá
                if (is_stock or is_commodity) and leverage > 4:
                    leverage = 4

                requested_leverage = int(leverage)
                if getattr(self, 'market_type', 'spot') == 'futures':
                    leverage, leverage_limit = self._resolve_pair_leverage(
                        signal.symbol, requested_leverage, notional, available_margin,
                    )
                else:
                    leverage = 1
                    leverage_limit = {
                        'max_leverage': 1, 'verified': True, 'source': 'spot',
                        'notional': notional, 'error': None,
                    }
                self.last_leverage_symbol = signal.symbol
                self.last_pair_max_leverage = leverage_limit.get('max_leverage')
                self.last_leverage_limit_verified = bool(leverage_limit.get('verified'))
                self.last_leverage_limit_source = leverage_limit.get('source')
                if leverage is None:
                    logger.error(
                        "Bỏ qua lệnh LIVE %s: chưa xác minh được trần leverage theo cặp/notional (%s).",
                        signal.symbol, leverage_limit.get('error') or 'không có dữ liệu bracket',
                    )
                    return None
                leverage = int(leverage)
                self.last_dynamic_leverage = leverage
                position_size = min(notional / leverage, available_margin)
                base_coin_chk = signal.symbol.split('/')[0].split(':')[0].strip().upper()
                is_major_coin = base_coin_chk in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
                is_stock_chk = MarketScanner.is_tradfi_stock(signal.symbol, self.exchange)
                is_commodity_chk = MarketScanner.is_tradfi_commodity(signal.symbol, self.exchange)
                if not is_major_coin and not is_stock_chk and not is_commodity_chk:
                    max_alt_margin = max(6.0, (portfolio_equity / max(1, configured_slots)) * 0.25)
                    if position_size > max_alt_margin:
                        logger.info(
                            "🛡️ [ALTCOIN MARGIN CAP] Giới hạn ký quỹ %s từ %.2f USDT xuống trần %.2f USDT (Đòn bẩy: %dx) để tránh phình vốn.",
                            signal.symbol, position_size, max_alt_margin, leverage
                        )
                        position_size = max_alt_margin
                if position_size <= 0:
                    logger.info("⚠️ Không còn ký quỹ khả dụng cho %s sau khi tính giới hạn cặp", signal.symbol)
                    return None
                if leverage < requested_leverage:
                    logger.info(
                        "Giảm leverage %s từ %dx xuống %dx theo trần cặp %sx tại notional %.2f.",
                        signal.symbol, requested_leverage, leverage,
                        leverage_limit.get('max_leverage'), leverage_limit.get('notional', 0),
                    )
                if not leverage_limit.get('verified'):
                    logger.warning(
                        "DEMO %s dùng %dx nhưng trần leverage cặp chưa xác minh; dữ liệu bracket không khả dụng.",
                        signal.symbol, leverage,
                    )
                
                # Cập nhật đòn bẩy trên sàn thật nếu là futures và live
                if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                    try:
                        leverage_ready = self.exchange.setup_futures_pair(signal.symbol, leverage)
                        if not leverage_ready:
                            logger.error(
                                "Bỏ qua %s vì không xác nhận được margin mode/leverage %dx trên sàn.",
                                signal.symbol, leverage,
                            )
                            return None
                    except Exception as e:
                        logger.error(f"Lỗi cập nhật đòn bẩy {leverage}x cho {signal.symbol}: {e}")
                        return None
                        
                effective_size = position_size * leverage
                amount = effective_size / signal.price
                
                # Kiểm tra và điều chỉnh theo giới hạn tối thiểu của sàn (Min Notional / Min Amount)
                try:
                    ccxt_symbol = self.exchange._get_ccxt_symbol(signal.symbol)
                    markets = self.exchange.exchange.markets
                    if markets and ccxt_symbol in markets:
                        market = markets[ccxt_symbol]
                        min_amount = market.get('limits', {}).get('amount', {}).get('min', 0)
                        min_cost = market.get('limits', {}).get('cost', {}).get('min', 0)
                        
                        # Điều chỉnh theo min_amount
                        if amount < min_amount:
                            amount = min_amount * 1.05
                            
                        # Làm tròn lot-step trước khi kiểm tra min notional để tránh lỗi Binance -4164
                        ccxt_symbol = signal.symbol
                        try:
                            if hasattr(self.exchange, 'exchange') and hasattr(self.exchange.exchange, 'amount_to_precision'):
                                for _ in range(5):
                                    fmt_amt = float(self.exchange.exchange.amount_to_precision(ccxt_symbol, amount))
                                    if min_cost <= 0 or (fmt_amt > 0 and fmt_amt * signal.price >= min_cost * 1.02):
                                        amount = fmt_amt
                                        break
                                    amount *= 1.03
                        except Exception:
                            pass

                        # Điều chỉnh theo min_cost (Notional)
                        if min_cost and (amount * signal.price) < min_cost:
                            amount = (min_cost * 1.05) / signal.price
                            
                        # Tính lại số tiền Ký quỹ thực tế sau khi điều chỉnh
                        required_margin = (amount * signal.price) / leverage
                        # Bổ sung Margin Precision Tolerance (Dung sai làm tròn bước sàn: tối đa 8% hoặc 0.08 USDT)
                        # Ngăn chặn việc hủy oan các lệnh xác suất thắng cao (như IOTX) chỉ vì lệch 0.002 USDT do lot size
                        margin_tolerance = max(0.08, position_size * 0.08)
                        if required_margin > (position_size + margin_tolerance):
                            logger.warning(
                                f"Bỏ qua {signal.symbol}: margin tối thiểu của sàn "
                                f"({required_margin:.2f}) vượt ngân sách rủi ro ({position_size:.2f} + đệm {margin_tolerance:.2f})."
                            )
                            return None
                        elif required_margin > position_size:
                            if required_margin <= available_margin:
                                logger.info(
                                    f"🛡️ [MARGIN PRECISION TOLERANCE] {signal.symbol}: Điều chỉnh ký quỹ từ {position_size:.2f} lên {required_margin:.2f} USDT để thỏa mãn bước sàn (Đệm: +{required_margin - position_size:.3f} USDT <= {margin_tolerance:.2f})."
                                )
                                position_size = required_margin
                            else:
                                logger.warning(
                                    f"Bỏ qua {signal.symbol}: Ký quỹ yêu cầu ({required_margin:.2f}) vượt số dư khả dụng ({available_margin:.2f})."
                                )
                                return None
                except Exception as e:
                    logger.error(f"Lỗi kiểm tra giới hạn sàn: {e}")
                    pass
                
                # Kiểm tra bảo vệ trượt giá trước khi đặt lệnh (Pre-Order Slippage Shield):
                # Tránh trường hợp sau 20-30s phân tích AI/JEV, giá thị trường đã chạy quá xa so với giá tín hiệu
                try:
                    live_ticker = self.exchange.get_ticker(signal.symbol)
                    if live_ticker and signal.price > 0:
                        if side == 'buy':
                            exec_check_price = float(live_ticker.get('ask') or live_ticker.get('last') or signal.price)
                            slip_pct = (exec_check_price - signal.price) / signal.price
                            if slip_pct > 0.006:  # Giá đã tăng vọt > 0.6% so với lúc phân tích
                                logger.warning(
                                    f"🛡️ [CHẶN ĐUA LỆNH ĐỈNH] Bỏ qua vào BUY {signal.symbol}: Giá Ask thị trường ({exec_check_price:.6g}) "
                                    f"đã chạy vọt +{slip_pct*100:.2f}% so với giá tín hiệu ({signal.price:.6g}) trong thời gian AI phân tích! "
                                    f"Hủy lệnh để tránh đu đỉnh râu nến."
                                )
                                return None
                        else:
                            exec_check_price = float(live_ticker.get('bid') or live_ticker.get('last') or signal.price)
                            slip_pct = (signal.price - exec_check_price) / signal.price
                            if slip_pct > 0.006:  # Giá đã sập > 0.6% so với lúc phân tích
                                logger.warning(
                                    f"🛡️ [CHẶN BÁN THÁO ĐÁY] Bỏ qua vào SELL {signal.symbol}: Giá Bid thị trường ({exec_check_price:.6g}) "
                                    f"đã sập -{slip_pct*100:.2f}% so với giá tín hiệu ({signal.price:.6g}) trong thời gian AI phân tích! "
                                    f"Hủy lệnh để tránh bán tháo đáy."
                                )
                                return None
                except Exception as se:
                    logger.debug(f"Không thể kiểm tra slippage trước lệnh: {se}")

                trading_cfg = self.config.get('trading', {})
                sniper_m1_active = bool(trading_cfg.get('sniper_retest_enabled', True))
                pullback_pct = float(trading_cfg.get('sniper_pullback_pct', 0.0035))
                max_plunge_pct = float(trading_cfg.get('sniper_max_plunge_pct', 0.0080))
                sniper_timeout = int(trading_cfg.get('sniper_timeout_seconds', 900))

                # PHÂN LỚP TÀI SẢN (ADAPTIVE ASSET EXECUTION - KIỂM CHỨNG TRÊN 3111 TÍN HIỆU LOGS):
                # - TRADFI STOCKS (Cổ phiếu Mỹ: MU, TSLA, NVDA...): Chạy độc lập theo phiên Wall Street,
                #   không bị râu quét như crypto nên kích hoạt vào lệnh trực tiếp (Runner Entry) để bắt trọn sóng bứt phá!
                # - CRYPTO (Altcoins & Majors): Bắt buộc dùng M1 Sniper Retest (-0.35% Limit Maker) để phòng thủ bẫy xả đỉnh!
                is_tradfi_pair = MarketScanner.is_tradfi_stock(signal.symbol, self.exchange) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(signal.symbol, self.exchange))

                if sniper_m1_active and not is_tradfi_pair:
                    # THUẬT TOÁN BẮN TỈA M1 CHO CRYPTO: ĐÓN LÕNG TẠI ĐÁY NHỊP RETEST THÍCH ỨNG THEO ATR (ATR-ADAPTIVE)
                    # Đã kiểm chứng tối ưu trên 244 lệnh lịch sử (Net PnL +1.93$, PF 2.34):
                    # - Coin biến động thấp / nhịp chạy dứt khoát: Rình ở 0.18% - 0.22% để khớp ngay không lỡ nhịp
                    # - Coin giật mạnh / Meme: Rình ở 0.30% - 0.35% để tránh bẫy râu xả đỉnh
                    calculated_pullback = pullback_pct
                    try:
                        dfs = getattr(signal, 'metadata', {}).get('dfs') or {}
                        df_15m = dfs.get('15m')
                        if df_15m is None or (hasattr(df_15m, 'empty') and df_15m.empty) or len(df_15m) < 15:
                            if hasattr(self, 'data_collector'):
                                df_15m = self.data_collector.fetch_data(signal.symbol, '15m', limit=20)
                        if df_15m is not None and len(df_15m) >= 15:
                            highs = df_15m['high'].iloc[-15:]
                            lows = df_15m['low'].iloc[-15:]
                            closes = df_15m['close'].iloc[-16:-1]
                            tr = pd.concat([highs - lows, (highs - closes).abs(), (lows - closes).abs()], axis=1).max(axis=1)
                            atr_val = float(tr.tail(14).mean())
                            if signal.price > 0 and atr_val > 0:
                                atr_pct = atr_val / signal.price
                                calculated_pullback = max(0.0018, min(0.0035, atr_pct * 0.30))
                    except Exception as atre:
                        logger.debug("Không tính được ATR adaptive pullback cho %s: %s", signal.symbol, atre)

                    if side == 'buy':
                        retest_target_price = signal.price * (1.0 - calculated_pullback)
                        plunge_invalid_price = signal.price * (1.0 - max_plunge_pct)
                    else:
                        retest_target_price = signal.price * (1.0 + calculated_pullback)
                        plunge_invalid_price = signal.price * (1.0 + max_plunge_pct)

                    if hasattr(self.exchange, 'exchange') and hasattr(self.exchange.exchange, 'price_to_precision'):
                        try:
                            retest_target_price = float(self.exchange.exchange.price_to_precision(signal.symbol, retest_target_price))
                        except Exception:
                            pass

                    # Điều chỉnh khoảng cách SL/TP theo giá retest tối ưu
                    if direction == 'LONG':
                        sl_price = retest_target_price * (1.0 - clamped_sl_dist)
                        tp_price = retest_target_price * (1.0 + clamped_sl_dist * 2.0)
                    else:
                        sl_price = retest_target_price * (1.0 + clamped_sl_dist)
                        tp_price = retest_target_price * (1.0 - clamped_sl_dist * 2.0)

                    if self.mode == 'demo':
                        order = {'id': f"demo_sniper_{int(time.time()*1000)}", 'status': 'open', 'price': retest_target_price, 'amount': amount}
                    else:
                        try:
                            order = self.exchange.create_futures_order(
                                signal.symbol, side, amount, retest_target_price,
                                order_type='limit', post_only=True
                            )
                        except Exception as pe:
                            order = None
                        if not order or not order.get('id'):
                            order = self.exchange.create_futures_order(
                                signal.symbol, side, amount, retest_target_price,
                                order_type='limit', post_only=False
                            )

                    if not order or not order.get('id'):
                        logger.error("Không đặt được lệnh Limit Maker rình mồi cho %s", signal.symbol)
                        return None

                    # Đưa vào hàng đợi rình mồi M1
                    self.pending_stalking_orders[signal.symbol] = {
                        'order_id': str(order.get('id')),
                        'symbol': signal.symbol,
                        'side': side,
                        'direction': direction,
                        'signal_price': signal.price,
                        'target_price': retest_target_price,
                        'invalid_price': plunge_invalid_price,
                        'created_at': time.time(),
                        'timeout_seconds': sniper_timeout,
                        'amount': amount,
                        'position_size': position_size,
                        'leverage': leverage,
                        'sl_price': sl_price,
                        'tp_price': tp_price,
                        'clamped_sl_dist': clamped_sl_dist,
                        'clamped_tp_dist': clamped_sl_dist * 2.0,
                        'strategy': getattr(signal, 'strategy', 'sniper_m1'),
                        'confidence': float(getattr(signal, 'confidence', 0.8)),
                        'exchange_leverage_limit': leverage_limit.get('max_leverage'),
                        'leverage_limit_verified': bool(leverage_limit.get('verified')),
                        'leverage_limit_source': leverage_limit.get('source'),
                        'market_type': getattr(self, 'market_type', 'spot'),
                    }
                    self._save_state()
                    try:
                        from core.gate_telemetry import record_radar_candidate
                        record_radar_candidate(
                            symbol=signal.symbol,
                            side=direction,
                            confidence=float(getattr(signal, 'confidence', 0.8)),
                            score=float(getattr(signal, 'score', 0.0) or 0.0),
                            strategies_agreed=str(getattr(signal, 'strategy', 'M1 Sniper Retest')),
                            dynamic_leverage=leverage,
                            bottleneck_gate='M1_SNIPER_STALKING',
                            bottleneck_reason=f"Đang rình khớp Limit Maker tại {retest_target_price:.6g} (-{calculated_pullback*100:.2f}%)",
                            readiness_pct=98.0
                        )
                    except Exception:
                        pass
                    logger.info(
                        f"🎯 [BẮN TỈA M1 ATR-ADAPTIVE] {signal.symbol} ({side.upper()}): Đặt lệnh Limit Maker tại {retest_target_price:.6g} "
                        f"(-{calculated_pullback*100:.2f}% chiết khấu ATR so với đỉnh {signal.price:.6g})! Hạn chờ {sniper_timeout//60}m, hủy nếu xả thủng {plunge_invalid_price:.6g}."
                    )
                    return order
                elif self.mode == 'demo':
                    if is_tradfi_pair:
                        logger.info(
                            f"🏛️ [TRADFI RUNNER DEMO] {signal.symbol} ({side.upper()}): "
                            f"Cổ phiếu / Hàng hóa Mỹ TradFi vào lệnh trực tiếp để bắt trọn sóng bứt phá (không rình lùi)!"
                        )
                    # Demo mode - giả lập lệnh
                    order = self._demo_order(signal, amount, side=side)
                else:
                    # Live mode
                    if is_tradfi_pair:
                        logger.info(
                            f"🏛️ [TRADFI ADAPTIVE RUNNER ENTRY] {signal.symbol} ({side.upper()}): "
                            f"Là Cổ phiếu / Hàng hóa TradFi, kích hoạt vào lệnh trực tiếp để bắt trọn sóng bứt phá tổ chức!"
                        )
                    order_type_cfg = self.config['trading'].get('order_type', 'market')
                    if getattr(self, 'market_type', 'spot') == 'futures':
                        if order_type_cfg in ('maker', 'post_only'):
                            # Thực thi Post-Only Maker: Lấy giá tốt nhất từ sổ lệnh
                            ticker = self.exchange.get_ticker(signal.symbol)
                            exec_price = signal.price
                            if ticker:
                                if side == 'buy' and ticker.get('bid'):
                                    exec_price = float(ticker['bid'])
                                elif side == 'sell' and ticker.get('ask'):
                                    exec_price = float(ticker['ask'])
                            order = self.exchange.create_futures_order(
                                signal.symbol, side, amount, exec_price,
                                order_type='limit', post_only=True
                            )
                        else:
                            order = self.exchange.create_futures_order(
                                signal.symbol, side, amount, signal.price,
                                order_type_cfg
                            )
                    else:
                        order = self.exchange.create_buy_order(
                            signal.symbol, amount, signal.price,
                            order_type_cfg
                        )

                if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                    if not order:
                        logger.error("Binance không trả xác nhận cho lệnh mở %s; đối soát vị thế trước khi thử lại.", signal.symbol)
                        self.sync_live_positions_with_exchange()
                        return None
                    order = dict(order)
                    order_type_cfg = self.config['trading'].get('order_type', 'market')
                    max_checks = 60 if order_type_cfg in ('maker', 'post_only') else 12
                    if order.get('id'):
                        for _ in range(max_checks):
                            order_status = str(order.get('status') or '').lower()
                            if order_status in ('closed', 'filled', 'canceled', 'cancelled', 'rejected', 'expired'):
                                break
                            latest = self.exchange.get_order_status(order['id'], signal.symbol)
                            if latest:
                                order = latest
                            else:
                                time.sleep(0.25)
                    status = str(order.get('status') or '').lower()
                    filled_amount = float(order.get('filled') or 0)
                    if filled_amount <= 0 and status in ('closed', 'filled'):
                        filled_amount = float(order.get('amount') or amount)
                    if status not in ('closed', 'filled') and order_type_cfg in ('maker', 'post_only'):
                        logger.warning("Lệnh Maker %s chưa khớp sau thời gian chờ; hủy lệnh để tránh rủi ro trượt giá.", signal.symbol)
                        try:
                            self.exchange.cancel_order(order['id'], signal.symbol)
                        except Exception as ce:
                            logger.error(f"Lỗi hủy lệnh Maker {signal.symbol}: {ce}")
                        return None
                    if status in ('rejected', 'expired') or filled_amount <= 0:
                        logger.error("Không xác nhận được khối lượng khớp lệnh mở %s; đối soát Binance.", signal.symbol)
                        self.sync_live_positions_with_exchange()
                        return None
                    amount = filled_amount
                
                if order:
                    raw_avg = order.get('average') or (order.get('info') or {}).get('avgPrice')
                    if raw_avg and float(raw_avg) > 0:
                        real_entry_price = float(raw_avg)
                    elif order.get('price') and float(order.get('price')) > 0:
                        real_entry_price = float(order.get('price'))
                    else:
                        real_entry_price = float(signal.price)
                    entry_price = real_entry_price if self.mode == 'live' else float(signal.price)
                    if self.mode == 'live':
                        position_size = amount * entry_price / max(1.0, leverage)
                    fee_rate = max(0.0, float(self.config.get('trading', {}).get('fee_rate', 0.001)))
                    slippage_rate = max(0.0, float(self.config.get('trading', {}).get('slippage_rate', 0.0005)))
                    if self.mode == 'demo':
                        # Paper execution uses a conservative market fill and both-side fees.
                        entry_price *= (1 + slippage_rate) if direction == 'LONG' else (1 - slippage_rate)
                    entry_fee = amount * entry_price * fee_rate

                    if direction == 'LONG':
                        sl_price = entry_price * (1.0 - clamped_sl_dist)
                        tp_price = entry_price * (1.0 + clamped_tp_dist)
                    else:
                        sl_price = entry_price * (1.0 + clamped_sl_dist)
                        tp_price = entry_price * (1.0 - clamped_tp_dist)

                    sl_order_id = None
                    tp_order_id = None
                    if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                        close_side = 'sell' if direction == 'LONG' else 'buy'
                        try:
                            sls = self.exchange.create_stop_market_order(signal.symbol, close_side, amount, sl_price)
                            sl_order_id = sls.get('id') if sls else None
                        except Exception as e:
                            logger.error(f"Lỗi tạo lệnh SL cho {signal.symbol}: {e}")
                            
                        try:
                            tps = self.exchange.create_take_profit_market_order(signal.symbol, close_side, amount, tp_price)
                            tp_order_id = tps.get('id') if tps else None
                        except Exception as e:
                            logger.error(f"Lỗi tạo lệnh TP cho {signal.symbol}: {e}")

                    protection_status = 'exchange_stop'
                    if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures' and not sl_order_id:
                        protection_status = 'bot_poll_only'
                        logger.critical(
                            "Không đặt được stop-loss phía sàn cho %s; đang thử đóng vị thế ngay.",
                            signal.symbol,
                        )
                        self._notify_telegram(
                            f"🚨 KHẨN CẤP: Binance không nhận stop-loss cho {signal.symbol}. "
                            "Bot đang thử đóng vị thế để tránh giữ lệnh không được bảo vệ."
                        )
                        try:
                            emergency_close = self.exchange.close_futures_position(
                                signal.symbol, direction, amount,
                            )
                            logger.error("Đã gửi lệnh đóng khẩn cấp cho %s; đang xác nhận vị thế trên Binance.", signal.symbol)
                        except Exception as e:
                            logger.critical("Đóng khẩn cấp %s cũng thất bại: %s", signal.symbol, e)

                        try:
                            remaining = self._matching_exchange_positions(signal.symbol, direction)
                            remaining_amount = sum(
                                abs(float(pos.get('contracts') or (pos.get('info') or {}).get('positionAmt') or 0))
                                for pos in remaining
                            )
                            if remaining_amount <= 0:
                                if tp_order_id:
                                    try:
                                        self.exchange.cancel_order(
                                            tp_order_id, signal.symbol,
                                            trigger=True, strict=True,
                                        )
                                    except Exception as e:
                                        logger.error(
                                            "Không hủy được TP điều kiện %s sau khi đóng khẩn cấp %s: %s",
                                            tp_order_id, signal.symbol, e,
                                        )
                                self.sync_live_positions_with_exchange()
                                logger.warning("Đã xác nhận vị thế %s đóng sau khi Binance từ chối stop-loss.", signal.symbol)
                                return None
                            amount = remaining_amount
                            remote_entry = remaining[0].get('entryPrice') or (remaining[0].get('info') or {}).get('entryPrice')
                            if remote_entry:
                                entry_price = float(remote_entry)
                            position_size = amount * entry_price / max(1.0, leverage)
                            logger.critical("Vị thế %s vẫn mở nhưng chưa có SL sàn; sẽ được theo dõi trong dashboard.", signal.symbol)
                            self._notify_telegram(
                                f"🚨 Vị thế LIVE {direction} {signal.symbol} vẫn còn mở nhưng Binance từ chối stop-loss. "
                                "Tool sẽ giữ vị thế trong dashboard; hãy đóng thủ công hoặc kiểm tra ngay SL/TP trên Binance."
                            )
                        except Exception as e:
                            logger.critical("Không đối soát được vị thế %s sau lỗi đặt SL: %s; giữ trạng thái để xử lý.", signal.symbol, e)
                            self._notify_telegram(
                                f"🚨 Không xác nhận được trạng thái vị thế LIVE {signal.symbol} sau lỗi đặt stop-loss. "
                                "Hãy kiểm tra Binance ngay; tool sẽ giữ trạng thái để đối soát."
                            )

                    position = {
                        'symbol': signal.symbol,
                        'side': side,
                        'direction': direction,
                        'entry_price': entry_price,
                        'amount': amount,
                        'cost': position_size,
                        'entry_fee': entry_fee,
                        'leverage': leverage,
                        'exchange_leverage_limit': leverage_limit.get('max_leverage'),
                        'leverage_limit_verified': bool(leverage_limit.get('verified')),
                        'leverage_limit_source': leverage_limit.get('source'),
                        'market_type': getattr(self, 'market_type', 'spot'),
                        'stop_loss': sl_price,
                        'take_profit': tp_price,
                        'strategy': signal.strategy,
                        'trap_type': getattr(signal, 'metadata', {}).get('type') if isinstance(getattr(signal, 'metadata', None), dict) else None,
                        'signal_quality': getattr(self, 'last_signal_quality', 1.0),
                        'timestamp': datetime.now().isoformat(),
                        'order_id': order.get('id', f"demo_{int(time.time())}"),
                        'sl_order_id': sl_order_id,
                        'tp_order_id': tp_order_id,
                        'protection_status': protection_status,
                        'trailing_stop': None,
                        'trailing_best_price': entry_price,
                        'trailing_active': False,
                        'trailing_status': 'waiting_net_profit',
                        'trailing_distance_pct': None,
                        'trailing_atr_pct': None,
                        'trailing_adx': None,
                        'trailing_regime': 'not_calculated',
                        'trailing_net_breakeven': None,
                    }
                    self.open_positions.append(position)
                    try:
                        from core.gate_telemetry import clear_radar_candidate
                        clear_radar_candidate(position.get('symbol', ''))
                    except Exception:
                        pass
                    self.balance -= position_size
                    if self.mode == 'demo':
                        self.balance -= entry_fee
                    self.trade_count += 1
                    
                    entry_profile = self._get_asset_adaptive_trailing_profile(signal.symbol)
                    breakeven_trigger_pct = float(entry_profile.get('breakeven_trigger') or self.config.get('risk', {}).get('breakeven_trigger_pct', 0.0065))
                    mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
                    direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
                    quote = self.config.get('trading', {}).get('base_currency', 'USDT')
                    risk_factor_str = signal.metadata.get('risk_factors', 'Đã thẩm định: cấu trúc an toàn, không có bẫy thanh khoản')
                    ai_reason_str = signal.metadata.get('reason', 'Đồng thuận tín hiệu kỹ thuật & AI')
                    breakeven_target = entry_price * (1 + breakeven_trigger_pct) if direction == 'LONG' else entry_price * (1 - breakeven_trigger_pct)
                    order_type_tag = "[MAKER 0.02% FEE]" if self.config.get('trading', {}).get('order_type') in ('maker', 'post_only') else "[MARKET TAKER]"
                    msg = (
                        f"🚀 **[{mode_str}] MỞ LỆNH {direction_str}** {order_type_tag}\n\n"
                        f"📊 **Cặp giao dịch:** {signal.symbol} ({leverage}x)\n"
                        f"🎯 **Giá vào (Entry):** {entry_price:.6f}\n"
                        f"🔒 **Khóa Hòa Vốn (BE):** {breakeven_target:.6f} (+{breakeven_trigger_pct*100:.1f}%)\n"
                        f"🛑 **Cắt lỗ (SL):** {sl_price:.6f} ({abs(sl_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
                        f"🎯 **Chốt lời (TP):** {tp_price:.6f} ({abs(tp_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
                        f"🧠 **AI & Chiến lược:** {signal.strategy} (Độ tin cậy: {signal.confidence:.1%})\n"
                        f"💬 **Luận điểm kỹ thuật:** {ai_reason_str}\n"
                        f"🛡️ **Devil's Advocate:** {risk_factor_str}\n"
                        f"💰 **Ký quỹ:** {position_size:.2f} {quote} | **Khả dụng:** {self.balance:.2f} {quote}" + (f" | **Tổng vốn:** {float(self._futures_account_snapshot.get('wallet_balance')):.2f} {quote}" if self.mode == 'live' and getattr(self, '_futures_account_snapshot', None) and self._futures_account_snapshot.get('wallet_balance') is not None else "")
                    )
                    self._notify_telegram(msg)
                    
                    # Lưu vào database
                    self.db.save_trade({
                        'symbol': signal.symbol,
                        'side': side,
                        'type': self.config['trading']['order_type'],
                        'price': entry_price,
                        'amount': amount,
                        'cost': position_size,
                        'fee': entry_fee,
                        'pnl': 0,
                        'strategy': signal.strategy,
                        'status': 'open',
                        'order_id': position['order_id'],
                        'timestamp': int(time.time() * 1000),
                        'mode': self.mode
                    })
                    
                    logger.info(
                        f"✅ MỞ {direction} {signal.symbol}: "
                        f"Giá={entry_price:.6g}, "
                        f"Số lượng={amount:.6f}, "
                        f"Margin={position_size:.2f} {quote}, "
                        f"Đòn bẩy={leverage}x, "
                        f"SL={position['stop_loss']:.6g}, "
                        f"TP={position['take_profit']:.6g}"
                    )
                    
                    return position
                    
        except Exception as e:
            logger.error(f"Lỗi thực thi lệnh: {e}")
        
        return None

    def _demo_order(self, signal, amount: float, side: str = 'buy') -> dict:
        """Giả lập lệnh mua/bán trong chế độ demo."""
        return {
            'id': f"demo_{int(time.time() * 1000)}",
            'symbol': signal.symbol,
            'type': 'limit',
            'side': str(side or 'buy').lower(),
            'price': signal.price,
            'amount': amount,
            'cost': signal.price * amount,
            'status': 'closed',
            'timestamp': int(time.time() * 1000)
        }

    def _demo_buy(self, signal, amount: float) -> dict:
        """Backward compatibility wrapper."""
        return self._demo_order(signal, amount, side='buy')

    def _exchange_position_direction(self, exchange_position: dict) -> Optional[str]:
        """Normalize a CCXT/Binance position direction."""
        side = str(exchange_position.get('side') or '').lower()
        if side in ('long', 'buy'):
            return 'LONG'
        if side in ('short', 'sell'):
            return 'SHORT'

        info = exchange_position.get('info') or {}
        position_side = str(info.get('positionSide') or '').upper()
        if position_side in ('LONG', 'SHORT'):
            return position_side
        try:
            signed_amount = float(info.get('positionAmt') or 0)
            if signed_amount > 0:
                return 'LONG'
            if signed_amount < 0:
                return 'SHORT'
        except (TypeError, ValueError):
            pass
        return None

    @staticmethod
    def _clean_symbol(symbol: str) -> str:
        return str(symbol or '').split(':')[0].replace('/', '').upper()

    def _matching_exchange_positions(self, symbol: str, direction: str) -> List[Dict]:
        clean_symbol = self._clean_symbol(symbol)
        return [
            p for p in self.exchange.get_futures_positions(symbol)
            if self._clean_symbol(p.get('symbol')) == clean_symbol
            and self._exchange_position_direction(p) == direction
        ]

    def _verify_live_position_protection(self, positions: List[dict]) -> bool:
        """Confirm saved futures stop IDs still exist among Binance trigger orders.

        This is read-only. If Binance cannot confirm the snapshot, or a saved
        stop is absent, mark the position for review and block new entries; do
        not invent a replacement order or close the position automatically.
        """
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures' or not positions:
            return False

        try:
            # Binance/CCXT rejects fetchOpenOrders() without a symbol by default
            # and charges a much higher request weight for an account-wide query.
            # Only fetch conditional orders for symbols whose positions need
            # protection verification.
            symbols_by_key = {}
            for position in positions:
                symbol = str(position.get('symbol') or '').strip()
                symbol_key = self._clean_symbol(symbol)
                if not symbol or not symbol_key:
                    raise RuntimeError('Vị thế thiếu mã symbol để xác minh lệnh bảo vệ')
                symbols_by_key.setdefault(symbol_key, symbol)

            open_order_keys = set()
            for symbol in symbols_by_key.values():
                orders = self.exchange.get_open_orders(symbol, trigger=True, strict=True)
                if not isinstance(orders, list):
                    raise RuntimeError(f'Binance trả danh sách lệnh điều kiện không hợp lệ cho {symbol}')
                open_order_keys.update(
                    (self._clean_symbol(order.get('symbol') or symbol), self._conditional_order_id(order))
                    for order in orders
                    if isinstance(order, dict) and self._conditional_order_id(order)
                )
        except Exception as e:
            for position in positions:
                position['protection_review_required'] = True
                position['protection_review_reason'] = 'open_orders_unavailable'
                position['take_profit_order_unverified'] = True
            logger.critical(
                'Không xác minh được SL/TP điều kiện trên Binance; khóa lệnh mới và giữ nguyên vị thế: %s', e,
            )
            return True

        needs_review = False
        for position in positions:
            key = (self._clean_symbol(position.get('symbol')), str(position.get('sl_order_id') or ''))
            stop_verified = bool(key[1] and key in open_order_keys)
            if stop_verified:
                position.pop('protection_review_required', None)
                position.pop('protection_review_reason', None)
                position['protection_status'] = 'exchange_stop_verified'
            else:
                position['protection_review_required'] = True
                position['protection_review_reason'] = 'stop_order_missing_or_unverified'
                position['protection_status'] = 'stop_unverified'
                needs_review = True
                logger.critical(
                    'Không xác nhận được SL đang mở trên Binance cho %s %s (SL ID=%s); '
                    'giữ vị thế, khóa lệnh mới và bỏ qua quản lý bằng mức SL cục bộ.',
                    position.get('direction', 'LONG'), position.get('symbol'), key[1] or '<missing>',
                )

            take_profit_id = str(position.get('tp_order_id') or '')
            take_profit_verified = bool(
                take_profit_id
                and (self._clean_symbol(position.get('symbol')), take_profit_id) in open_order_keys
            )
            if take_profit_verified:
                position.pop('take_profit_order_unverified', None)
                position.pop('take_profit_review_alerted', None)
            else:
                position['take_profit_order_unverified'] = True
                if not position.get('take_profit_review_alerted'):
                    logger.warning(
                        'Không xác nhận được TP điều kiện trên Binance cho %s (TP ID=%s). '
                        'Mức chốt lời cục bộ chỉ được theo dõi khi bot đang chạy.',
                        position.get('symbol'), take_profit_id or '<missing>',
                    )
                    position['take_profit_review_alerted'] = True
        return needs_review

    def _cancel_position_protection_orders(self, position: dict, direction: str) -> List[str]:
        """Cancel and verify conditional reduce-only exits for a flat position."""
        symbol = position['symbol']
        known_ids = {
            str(position[key]) for key in ('sl_order_id', 'tp_order_id')
            if position.get(key)
        }
        warnings = []

        # Binance Futures conditional orders use the trigger/algo endpoints in
        # current CCXT. Try that endpoint and fall back to the legacy endpoint.
        for order_id in known_ids:
            for trigger in (True, False):
                try:
                    self.exchange.cancel_order(
                        order_id, symbol, trigger=trigger, strict=True
                    )
                    break
                except Exception:
                    continue

        expected_side = 'sell' if direction == 'LONG' else 'buy'

        def is_protective(order: dict) -> bool:
            info = order.get('info') or {}
            order_id = str(order.get('id') or info.get('algoId') or info.get('orderId') or '')
            if order_id and order_id in known_ids:
                return True
            side = str(order.get('side') or info.get('side') or '').lower()
            position_side = str(info.get('positionSide') or '').upper()
            reduce_only = order.get('reduceOnly') is True or str(info.get('reduceOnly', '')).lower() == 'true'
            close_position = order.get('closePosition') is True or str(info.get('closePosition', '')).lower() == 'true'
            matching_side = not side or side == expected_side
            matching_position = not position_side or position_side in ('BOTH', direction)
            return matching_side and matching_position and (reduce_only or close_position)

        try:
            regular_orders = self.exchange.get_open_orders(symbol, strict=True)
            trigger_orders = self.exchange.get_open_orders(symbol, trigger=True, strict=True)
        except Exception as e:
            return [f'cannot verify protection orders: {e}']

        for orders, is_trigger in ((regular_orders, False), (trigger_orders, True)):
            for order in orders:
                if not is_protective(order):
                    continue
                info = order.get('info') or {}
                order_id = str(order.get('id') or info.get('algoId') or info.get('orderId') or '')
                if not order_id:
                    warnings.append('protective order has no readable ID')
                    continue
                try:
                    self.exchange.cancel_order(
                        order_id, symbol, trigger=is_trigger, strict=True
                    )
                except Exception as e:
                    warnings.append(order_id)
                    logger.error("Could not cancel protective order %s for %s: %s", order_id, symbol, e)

        try:
            remaining_orders = (
                self.exchange.get_open_orders(symbol, strict=True)
                + self.exchange.get_open_orders(symbol, trigger=True, strict=True)
            )
            for order in remaining_orders:
                if is_protective(order):
                    info = order.get('info') or {}
                    warnings.append(str(order.get('id') or info.get('algoId') or 'unknown'))
        except Exception as e:
            warnings.append(f'cannot verify cancellation: {e}')

        return list(dict.fromkeys(warnings))

    def _close_position(self, position: dict, current_price: float, close_reason: str = "Đảo chiều tín hiệu") -> Optional[float]:
        """Close only after the exchange confirms the position is flat."""
        with self._position_lock:
            if not self.is_running and not str(close_reason).startswith('Đóng thủ công'):
                logger.info("Bỏ qua tự động đóng %s vì bot đã dừng.", position.get('symbol'))
                return None
            return self._close_position_locked(position, current_price, close_reason)

    def close_position_manually(self, symbol: str, direction: Optional[str] = None) -> Dict[str, Any]:
        """Close a position from the dashboard and suppress immediate re-entry."""
        symbol = str(symbol or '').strip()
        if not symbol:
            return {'success': False, 'error': 'Thiếu mã giao dịch.'}
        if direction is not None:
            direction = str(direction).upper().strip()
            if direction not in ('LONG', 'SHORT'):
                return {'success': False, 'error': 'Chiều vị thế không hợp lệ.'}

        with self._position_lock:
            if self.mode == 'live' and not self.exchange_connected:
                self._notify_telegram(
                    f"⚠️ Yêu cầu đóng thủ công {symbol} chưa gửi được: Binance đang mất kết nối. "
                    "Hãy kiểm tra và đóng vị thế trực tiếp trên Binance nếu cần."
                )
                return {'success': False, 'error': 'Binance đang mất kết nối; không thể xác nhận lệnh đóng.'}

            if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                if not self.sync_live_positions_with_exchange():
                    self._notify_telegram(
                        f"⚠️ Yêu cầu đóng thủ công {symbol} chưa thực hiện được: "
                        "không đồng bộ được vị thế với Binance. Hãy kiểm tra trực tiếp trên sàn."
                    )
                    return {'success': False, 'error': 'Không đồng bộ được vị thế Binance; chưa gửi lệnh đóng.'}

            matches = [
                p for p in self.open_positions
                if self._clean_symbol(p.get('symbol')) == self._clean_symbol(symbol)
                and (direction is None or p.get('direction', 'LONG') == direction)
            ]
            if not matches:
                self._notify_telegram(
                    f"⚠️ Dashboard nhận yêu cầu đóng {symbol} nhưng tool không còn vị thế tương ứng; "
                    "hãy kiểm tra trạng thái trực tiếp trên Binance."
                )
                return {'success': False, 'error': f'Không tìm thấy vị thế {symbol} đang mở trong tool.'}
            if len(matches) > 1:
                return {'success': False, 'error': f'{symbol} có nhiều vị thế; cần chỉ rõ LONG hoặc SHORT.'}
            position = matches[0]
            symbol = position['symbol']

            ticker = self.exchange.get_ticker(symbol)
            current_price = (ticker or {}).get('last')
            if current_price is None or float(current_price) <= 0:
                self._notify_telegram(
                    f"⚠️ Yêu cầu đóng thủ công {symbol} chưa gửi được: không lấy được giá mới nhất."
                )
                return {'success': False, 'error': f'Không lấy được giá mới nhất của {symbol}; chưa gửi lệnh đóng.'}

            direction = position.get('direction', 'LONG')
            pnl = self._close_position(
                position,
                float(current_price),
                close_reason='Đóng thủ công từ dashboard',
            )
            if pnl is None or position in self.open_positions:
                self._notify_telegram(
                    f"🚨 Tool chưa xác nhận đóng xong vị thế {direction} {symbol}. "
                    "Vị thế được giữ để tiếp tục đối soát; hãy kiểm tra trạng thái và lệnh SL/TP trên Binance."
                )
                return {
                    'success': False,
                    'error': f'Chưa xác nhận đóng hết {symbol}. Hãy kiểm tra Binance trước khi bấm lại.',
                }

            cooldown_minutes = max(
                0, int(self.config.get('trading', {}).get('manual_exit_cooldown_minutes', 30))
            )
            if cooldown_minutes:
                expires_at = time.time() + cooldown_minutes * 60
                cooldown_symbol = self._clean_symbol(symbol)
                self._manual_exit_cooldowns[cooldown_symbol] = expires_at
                self._symbol_cooldowns[cooldown_symbol] = expires_at
                self.db.set_symbol_cooldown(
                    self.mode, cooldown_symbol, expires_at, 'manual_exit'
                )
            self._save_state()
            quote = self.config.get('trading', {}).get('base_currency', 'USDT')
            warning = position.get('_close_warning')
            message = f'Đã xác nhận đóng {direction} {symbol}; PnL ước tính {pnl:+.4f} {quote}.'
            if warning:
                message += ' Cảnh báo: ' + warning + '. Kiểm tra lệnh chờ trên Binance.'
            return {
                'success': True,
                'message': message,
                'symbol': symbol,
                'direction': direction,
                'estimated_pnl': pnl,
                'warning': warning,
            }

    def _close_position_locked(self, position: dict, current_price: float, close_reason: str) -> Optional[float]:
        entry_price = position['entry_price']
        amount = float(position['amount'])
        direction = position.get('direction', 'LONG')
        close_order = {}
        exit_price = float(current_price)
        cleanup_warnings = []

        if self.mode == 'live':
            try:
                is_futures = (
                    position.get('market_type') == 'futures'
                    or getattr(self, 'market_type', 'spot') == 'futures'
                )
                if is_futures:
                    # Never trust a stale local quantity when closing a live position.
                    exchange_positions = self._matching_exchange_positions(
                        position['symbol'], direction
                    )
                    live_amounts = []
                    for live_pos in exchange_positions:
                        raw_amount = abs(float(live_pos.get('contracts') or 0))
                        if raw_amount <= 0:
                            raw_amount = abs(float((live_pos.get('info') or {}).get('positionAmt') or 0))
                        live_amounts.append(abs(float(raw_amount or 0)))
                    live_amount = sum(live_amounts)
                    if live_amount <= 0:
                        logger.warning(
                            "Không gửi lệnh đóng %s: Binance không còn vị thế %s; cần đồng bộ trạng thái.",
                            position['symbol'], direction,
                        )
                        self.sync_live_positions_with_exchange()
                        return None
                    # A full exit must use the exchange's current position size;
                    # a stale smaller local size would leave residual exposure.
                    amount = live_amount
                    close_order = self.exchange.close_futures_position(position['symbol'], direction, amount)
                else:
                    if direction == 'SHORT':
                        raise RuntimeError('Không thể đóng vị thế SHORT trên thị trường spot.')
                    close_order = self.exchange.create_sell_order(
                        position['symbol'], amount, current_price, 'market'
                    )

                # Market order responses may initially be acknowledgements. Poll
                # briefly for a terminal status before changing local state.
                if close_order and close_order.get('id'):
                    for _ in range(12):
                        status = str(close_order.get('status') or '').lower()
                        if status in ('closed', 'filled', 'canceled', 'cancelled', 'rejected', 'expired'):
                            break
                        latest = self.exchange.get_order_status(
                            close_order['id'], position['symbol']
                        )
                        if latest:
                            close_order = latest
                        else:
                            time.sleep(0.25)

                if is_futures:
                    remaining = self._matching_exchange_positions(position['symbol'], direction)
                    remaining_amount = 0.0
                    for live_pos in remaining:
                        raw_amount = abs(float(live_pos.get('contracts') or 0))
                        if raw_amount <= 0:
                            raw_amount = abs(float((live_pos.get('info') or {}).get('positionAmt') or 0))
                        remaining_amount += abs(float(raw_amount or 0))
                    if remaining_amount > 0:
                        position['amount'] = remaining_amount
                        self._save_state()
                        logger.error(
                            "Lệnh đóng %s chưa làm vị thế về 0 (còn %.8f); giữ vị thế và lệnh bảo vệ.",
                            position['symbol'], remaining_amount,
                        )
                        return None
                else:
                    status = str((close_order or {}).get('status') or '').lower()
                    filled = float((close_order or {}).get('filled') or 0)
                    if not close_order or (status not in ('closed', 'filled') and filled < amount * 0.999999):
                        logger.error("Lệnh đóng spot %s chưa được xác nhận khớp đủ.", position['symbol'])
                        return None

                if close_order:
                    status = str(close_order.get('status') or '').lower()
                    filled = close_order.get('filled')
                    if filled is None and status in ('closed', 'filled'):
                        filled = amount
                    if status in ('canceled', 'cancelled', 'rejected', 'expired') and not is_futures:
                        logger.error("Lệnh đóng %s kết thúc với trạng thái %s.", position['symbol'], status)
                        return None
                    if filled is not None and float(filled) > 0 and float(filled) < amount * 0.999999:
                        if not is_futures:
                            logger.warning(
                                "Binance báo khớp một phần lệnh đóng %s: %.8f/%.8f; cần đối soát.",
                                position['symbol'], float(filled), amount,
                            )
                            return None
                        logger.warning(
                            "Lệnh đóng futures %s báo khớp một phần, nhưng vị thế đã được xác nhận về 0; "
                            "ghi PnL ước tính và đối soát fill sau.",
                            position['symbol'],
                        )

                    average = close_order.get('average') or close_order.get('price')
                    if average:
                        exit_price = float(average)

                # Cancel protections only after confirming flat, without bulk-
                # cancelling unrelated entries on the same market.
                if is_futures:
                    cleanup_warnings.extend(
                        self._cancel_position_protection_orders(position, direction)
                    )
                else:
                    for key in ('sl_order_id', 'tp_order_id'):
                        order_id = position.get(key)
                        if not order_id:
                            continue
                        try:
                            canceled = self.exchange.cancel_order(order_id, position['symbol'])
                            if not canceled:
                                cleanup_warnings.append(str(order_id))
                        except Exception as e:
                            cleanup_warnings.append(str(order_id))
                            logger.error("Không xác nhận được hủy lệnh bảo vệ %s của %s: %s", order_id, position['symbol'], e)
                if cleanup_warnings:
                    position['_close_warning'] = 'Chưa xác nhận hủy lệnh SL/TP: ' + ', '.join(cleanup_warnings)
                    logger.critical(
                        "Đã đóng vị thế %s nhưng chưa xác nhận hủy hết SL/TP: %s",
                        position['symbol'], ', '.join(cleanup_warnings),
                    )
            except Exception as e:
                logger.error(
                    "Không xác nhận được lệnh đóng %s; giữ trạng thái để đối soát: %s",
                    position.get('symbol'), e,
                )
                return None

        if self.mode == 'demo':
            slippage_rate = max(0.0, float(self.config.get('trading', {}).get('slippage_rate', 0.0005)))
            exit_price *= (1 - slippage_rate) if direction == 'LONG' else (1 + slippage_rate)

        # Tính PnL
        if direction == 'LONG':
            pnl = (exit_price - entry_price) * amount
        else:
            pnl = (entry_price - exit_price) * amount
             
        fee_rate = max(0.0, float(self.config.get('trading', {}).get('fee_rate', 0.001)))
        exchange_fee = (close_order or {}).get('fee') or {}
        close_fee = float(exchange_fee.get('cost') or 0) if isinstance(exchange_fee, dict) else 0.0
        if self.mode == 'live' and close_fee <= 0:
            close_fee = exit_price * amount * fee_rate
        entry_fee = float(position.get('entry_fee', 0) or 0)
        fee = close_fee
        net_pnl = pnl - close_fee - entry_fee

        # Binance owns live margin accounting; paper mode updates its local cash.
        if self.mode == 'demo':
            self.balance += position['cost'] + net_pnl
        else:
            if getattr(self, 'market_type', 'spot') == 'futures':
                live_balance = self.exchange.get_futures_balance()
                free_balance = (live_balance or {}).get('free')
            else:
                base_currency = self.config.get('trading', {}).get('base_currency', 'USDT')
                live_balance = self.exchange.get_balance()
                free_balance = (live_balance.get(base_currency) or {}).get('free') if live_balance else None
            if free_balance is not None:
                self.balance = float(free_balance)
        
        # Cập nhật peak balance
        if self.balance > self.peak_balance:
            self.peak_balance = self.balance
        
        # Xóa khỏi open positions
        if position in self.open_positions:
            self.open_positions.remove(position)
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
        win_loss = "🏆 CHỐT LỜI (WIN)" if net_pnl > 0 else "🛑 CẮT LỖ (LOSS)" if net_pnl < 0 else "⚪ HÒA VỐN"
        roi = (net_pnl / position['cost']) * 100 if position['cost'] > 0 else 0
        init_cost = float(position.get('initial_cost') or position.get('cost', 1) or 1)
        
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        part_pnl_str = ""
        part_tp_val = float(position.get('partial_tp_pnl', 0.0) or 0.0)
        part_sl_val = float(position.get('partial_sl_pnl', 0.0) or 0.0)
        total_trade_net_pnl = net_pnl + part_tp_val + part_sl_val
        total_roi = (total_trade_net_pnl / init_cost) * 100 if init_cost > 0 else roi
        has_partial = bool(position.get('partial_tp_done') or position.get('partial_sl_done'))
        if position.get('partial_tp_done'):
            part_pnl_str += f"🔹 **Lãi chốt 50% trước đó:** `+{part_tp_val:.4f} {quote}`\n"
        if position.get('partial_sl_done'):
            part_pnl_str += f"🔹 **Cắt giảm tải trước đó:** `{part_sl_val:.4f} {quote}`\n"
        if has_partial:
            part_pnl_str += f"🔹 **Tổng Net PnL toàn lệnh:** `{total_trade_net_pnl:+.4f} {quote}` ({total_roi:+.2f}% vốn lệnh)\n" 

        last_pnl_label = f"Lợi nhuận phần đóng cuối ({amount:.6g} coin)" if has_partial else "Lợi nhuận ước tính (PnL)"
        last_roi_str = f" ({roi:+.2f}%)" if not has_partial else ""

        msg = (
            f"{win_loss}\n**[{mode_str}] ĐÓNG LỆNH {direction_str}**\n\n"
            f"🔹 **Cặp giao dịch:** {position['symbol']}\n"
            f"🔹 **Giá vào (Entry):** {entry_price:.6f}\n"
            f"🔹 **Giá chốt (Exit):** {exit_price:.6f}\n"
            f"🔹 **{last_pnl_label}:** {net_pnl:+.4f} {quote}{last_roi_str}\n"
            f"{part_pnl_str}"
            f"🔹 **Lý do đóng:** {close_reason}\n"
            f"🔹 **Số dư khả dụng:** {self.balance:.2f} {quote}" + (f" | **Tổng vốn (Equity):** {float(self._futures_account_snapshot.get('wallet_balance')):.2f} {quote}" if self.mode == 'live' and getattr(self, '_futures_account_snapshot', None) and self._futures_account_snapshot.get('wallet_balance') is not None else "")
        )
        if self.mode == 'live':
            msg += "\nℹ️ PnL ước tính từ giá khớp; số quyết toán cuối cùng lấy theo lịch sử fill Binance."
        if cleanup_warnings:
            msg += "\n⚠️ Chưa xác nhận hủy hết lệnh SL/TP: " + ', '.join(cleanup_warnings)
        self._notify_telegram(msg)
            
        # --- Ghi Log Hoạt động Cỗ Máy cho AI Khác Đọc ---
        try:
            log_path = Path(__file__).parent.parent / "ai_knowledge_base.md"
            with open(log_path, "a", encoding="utf-8") as f:
                win_loss = "WIN 🟢" if net_pnl > 0 else ("LOSS 🔴" if net_pnl < 0 else "BREAK-EVEN ⚪")
                f.write(f"### Trade {win_loss} lúc {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"- **Chế độ chạy**: {self.mode.upper()}\n")
                f.write(f"- **Tài sản**: {position['symbol']} (Chiều đánh: {direction})\n")
                f.write(f"- **Đòn bẩy (Leverage)**: {position.get('leverage', 1)}x\n")
                f.write(f"- **Giá vào (Entry)**: {entry_price:.6f}\n")
                f.write(f"- **Giá đóng (Exit)**: {exit_price:.6f}\n")
                f.write(f"- **Tiền lãi/lỗ ước tính (Net PnL)**: {net_pnl:+.4f} {quote}\n")
                f.write(f"- **Chiến thuật áp dụng**: {position.get('strategy', 'N/A')}\n")
                f.write(f"- **Lý do đóng lệnh**: {close_reason}\n")
                f.write(f"- **Vốn sau lệnh này**: {self.balance:.4f} {quote}\n\n")
        except Exception as e:
            logger.error(f"Lỗi ghi log AI: {e}")
        
        # Lưu vào database
        self.db.save_trade({
            'symbol': position['symbol'],
            'side': ('buy' if direction == 'SHORT' else 'sell'),
            'type': ('market' if self.mode == 'live' else 'limit'),
            'price': exit_price,
            'amount': amount,
            'cost': exit_price * amount,
            'fee': fee,
            'pnl': total_trade_net_pnl,
            'strategy': position.get('strategy', 'unknown'),
            'status': 'closed',
            'order_id': (close_order or {}).get('id') or f"local-close-{int(time.time() * 1000)}",
            'timestamp': int(time.time() * 1000),
            'mode': self.mode
        })
        if position.get('order_id'):
            self.db.update_trade_status(str(position['order_id']), 'closed')
        
        # Quyết định reinvest hay take profit
        total_pnl = self.balance - self.config['trading']['initial_capital']
        action = self.risk_manager.should_take_profit_or_reinvest(
            total_pnl, self.balance
        )
        if total_pnl > 0:
            logger.info(f"💡 Quản lý lợi nhuận: {action} (Tổng PnL: {total_pnl:+.4f} {quote})")
        
        # Cooldown quản trị rủi ro sau khi đóng lệnh (Phân biệt Lệnh Thắng vs Lệnh Thua & Chặn Lỗ Lặp Trên Cùng 1 Mã)
        cooldown_sym = self._clean_symbol(position['symbol'])
        total_trade_net_pnl = net_pnl + float(position.get('partial_tp_pnl', 0.0) or 0.0)
        if total_trade_net_pnl < 0:
            streak = getattr(self, '_symbol_loss_streaks', {}).get(cooldown_sym, 0) + 1
            self._symbol_loss_streaks[cooldown_sym] = streak
            base_loss_cd = int(
                self.config.get('risk', {}).get('loss_symbol_cooldown_minutes')
                or self.config.get('trading', {}).get('loss_symbol_cooldown_minutes')
                or 180
            )
            eff_cooldown = max(360, base_loss_cd * 2) if streak >= 2 else max(180, base_loss_cd)
            expires = time.time() + (eff_cooldown * 60)
            self._symbol_cooldowns[cooldown_sym] = expires
            self._manual_exit_cooldowns[cooldown_sym] = expires
            self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason=f"loss_streak_{streak}")
            logger.warning(
                f"🛑 [CHẶN VÀO LẠI MÃ ĐANG SUY YẾU] {cooldown_sym} vừa đóng lỗ ({total_trade_net_pnl:+.4f} {quote}, chuỗi lỗ={streak}). "
                f"Khóa giao dịch mã {cooldown_sym} trong {eff_cooldown} phút!"
            )
            loss_cooldown = int(self.config.get('risk', {}).get('post_loss_cooldown_minutes', 0))
            if loss_cooldown > 0:
                self._global_loss_cooldown_until = time.time() + (loss_cooldown * 60)
                logger.warning(f"🛑 [BẢO VỆ TÂM LÝ & TÀI KHOẢN] Vừa cắt lỗ ({net_pnl:+.4f} {quote}). Kích hoạt Global Cooldown {loss_cooldown} phút, bot tạm dừng mở lệnh mới.")
        else:
            self._symbol_loss_streaks[cooldown_sym] = 0
            sym_cooldown = int(self.config.get('risk', {}).get('symbol_cooldown_minutes') or self.config.get('trading', {}).get('symbol_cooldown_minutes', 45))
            if sym_cooldown > 0:
                expires = time.time() + (sym_cooldown * 60)
                self._symbol_cooldowns[cooldown_sym] = expires
                self._manual_exit_cooldowns[cooldown_sym] = expires
                self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason="post_win_cooldown")
                logger.info(f"⏳ Bật symbol cooldown {sym_cooldown} phút cho {cooldown_sym} sau lệnh thắng (tránh FOMO đu đỉnh nhịp cuối).")

        self._save_state()
        return net_pnl



    def _handle_externally_closed_position(self, position: dict):
        """Xử lý khi vị thế bị đóng trên Binance (khớp SL/TP hoặc đóng tay) mà bot chưa biết."""
        symbol = position.get('symbol')
        direction = position.get('direction', 'LONG')
        entry_price = float(position.get('entry_price', 0))
        amount = float(position.get('amount', 0))
        entry_time = position.get('timestamp', 0)
        
        # Parse ISO string to milliseconds if necessary
        if isinstance(entry_time, str):
            try:
                from datetime import datetime
                entry_time = int(datetime.fromisoformat(entry_time).timestamp() * 1000)
            except Exception:
                entry_time = int(time.time() * 1000) - 86400000 # Fallback 24h
        else:
            entry_time = int(entry_time or (time.time() * 1000 - 86400000))
        
        # 1. Thử lấy giá đóng và PnL từ lịch sử Binance
        exit_price = entry_price
        net_pnl = 0.0
        close_reason = "Đóng ngoài bot (Binance khớp SL/TP/Tay)"
        real_order_id = None
        real_trade_id = None
        
        try:
            ccxt_symbol = self.exchange._get_ccxt_symbol(symbol)
            # Lấy trades từ lúc vào lệnh tới nay
            recent_trades = self.exchange.exchange.fetch_my_trades(ccxt_symbol, since=entry_time, limit=50)
            if recent_trades:
                # Lọc các trade ngược chiều (để đóng)
                close_side = 'sell' if direction == 'LONG' else 'buy'
                close_trades = [t for t in recent_trades if (t.get('side') or '').lower() == close_side]
                if close_trades:
                    # Lấy trade cuối cùng
                    last_trade = close_trades[-1]
                    info = last_trade.get('info', {})
                    real_order_id = last_trade.get('order') or info.get('orderId')
                    real_trade_id = last_trade.get('id') or info.get('id')

                    if real_order_id:
                        order_trades = [t for t in close_trades if (t.get('order') or t.get('info', {}).get('orderId')) == real_order_id]
                    else:
                        order_trades = [last_trade]
    
                    total_amt = sum(float(t.get('amount') or 0) for t in order_trades)
                    if total_amt > 0:
                        exit_price = sum(float(t.get('price') or t.get('info', {}).get('price') or 0) * float(t.get('amount') or 0) for t in order_trades) / total_amt
                    else:
                        exit_price = float(last_trade.get('price') or info.get('price') or entry_price)
    
                    realized = sum(float(t.get('info', {}).get('realizedPnl', t.get('realizedPnl', 0)) or 0) for t in order_trades)
                    fee = sum(float((t.get('fee') or {}).get('cost', t.get('info', {}).get('commission', 0)) or 0) for t in order_trades)
                    # Net PnL must be computed BEFORE classifying the close reason.
                    net_pnl = realized - fee
                    tp_oid = str(position.get('tp_order_id') or '')
                    sl_oid = str(position.get('sl_order_id') or '')
                    stale_sl_oids = [str(x) for x in position.get('stale_sl_order_ids', []) if x]
                    target_tp = float(position.get('take_profit') or 0)
                    target_sl = float(position.get('stop_loss') or 0)
                    
                    is_tp_order = bool(real_order_id and str(real_order_id) == tp_oid)
                    is_sl_order = bool(real_order_id and (str(real_order_id) == sl_oid or str(real_order_id) in stale_sl_oids))
                    
                    if is_tp_order:
                        close_reason = "🎯 Binance khớp Take Profit (Đạt mục tiêu chốt lời)"
                    elif is_sl_order:
                        if net_pnl > 0:
                            close_reason = "🛡️ Binance khớp Trailing Stop-Loss (Bảo toàn vốn & Khóa lãi)"
                        else:
                            close_reason = "🛑 Binance khớp Stop Loss (Cắt lỗ bảo vệ vốn)"
                    elif target_tp > 0 and abs(exit_price - target_tp) / target_tp < 0.003:
                        close_reason = "🎯 Binance khớp Take Profit (Đạt mục tiêu chốt lời)"
                    elif target_sl > 0 and abs(exit_price - target_sl) / target_sl < 0.003:
                        if net_pnl > 0:
                            close_reason = "🛡️ Binance khớp Trailing Stop-Loss (Bảo toàn vốn & Khóa lãi)"
                        else:
                            close_reason = "🛑 Binance khớp Stop Loss (Cắt lỗ bảo vệ vốn)"
                    elif net_pnl > 0:
                        close_reason = "🛡️ Binance khớp Trailing Stop-Loss (Bảo toàn vốn & Khóa lãi)"
                    else:
                        close_reason = "🛑 Binance khớp Stop Loss (Cắt lỗ bảo vệ vốn)"
        except Exception as e:
            logger.warning(f"Không thể lấy lịch sử trade để tính PnL cho {symbol}: {e}")
            # Fallback tính theo SL nếu đang lỗ
            if position.get('real_pnl', 0) < 0:
                net_pnl = float(position.get('real_pnl', 0))
                close_reason = "Binance khớp Stop Loss (Fallback)"
            
        # 2. Bật cooldown thông minh (Phân biệt Lệnh Thắng vs Lệnh Thua)
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        cooldown_sym = self._clean_symbol(symbol)
        part_tp_val = float(position.get('partial_tp_pnl', 0.0) or 0.0)
        part_sl_val = float(position.get('partial_sl_pnl', 0.0) or 0.0)
        total_trade_net_pnl = net_pnl + part_tp_val + part_sl_val
        if total_trade_net_pnl < 0:
            streak = getattr(self, '_symbol_loss_streaks', {}).get(cooldown_sym, 0) + 1
            self._symbol_loss_streaks[cooldown_sym] = streak
            base_loss_cd = int(
                self.config.get('risk', {}).get('loss_symbol_cooldown_minutes')
                or self.config.get('trading', {}).get('loss_symbol_cooldown_minutes')
                or self.config.get('trading', {}).get('manual_exit_cooldown_minutes')
                or 180
            )
            eff_cooldown = max(360, base_loss_cd * 2) if streak >= 2 else max(180, base_loss_cd)
            expires = time.time() + (eff_cooldown * 60)
            self._symbol_cooldowns[cooldown_sym] = expires
            self._manual_exit_cooldowns[cooldown_sym] = expires
            self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason=f"loss_streak_{streak}")
            logger.warning(
                f"🛑 [CHẶN VÀO LẠI MÃ ĐANG SUY YẾU] {cooldown_sym} đóng lỗ trên Binance ({total_trade_net_pnl:+.4f} {quote}, chuỗi lỗ={streak}). "
                f"Khóa giao dịch mã {cooldown_sym} trong {eff_cooldown} phút!"
            )
            loss_cooldown = int(self.config.get('risk', {}).get('post_loss_cooldown_minutes', 0))
            if loss_cooldown > 0:
                self._global_loss_cooldown_until = time.time() + (loss_cooldown * 60)
                logger.warning(f"🛑 [BẢO VỆ TÂM LÝ & TÀI KHOẢN] Vừa cắt lỗ trên Binance ({net_pnl:+.4f} {quote}). Kích hoạt Global Cooldown {loss_cooldown} phút, bot tạm dừng mở lệnh mới.")
        else:
            self._symbol_loss_streaks[cooldown_sym] = 0
            sym_cooldown = int(self.config.get('risk', {}).get('symbol_cooldown_minutes') or self.config.get('trading', {}).get('symbol_cooldown_minutes', 45))
            if sym_cooldown > 0:
                expires = time.time() + (sym_cooldown * 60)
                self._symbol_cooldowns[cooldown_sym] = expires
                self._manual_exit_cooldowns[cooldown_sym] = expires
                self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason="post_win_cooldown")
                logger.info(f"⏳ Bật symbol cooldown {sym_cooldown} phút cho {cooldown_sym} sau khi chốt lời trên Binance.")
        
        # 3. Gửi Telegram
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
        win_loss = "🏆 CHỐT LỜI (WIN)" if net_pnl > 0 else "🛑 CẮT LỖ (LOSS)" if net_pnl < 0 else "⚪ HÒA VỐN"
        roi = (net_pnl / position.get('cost', 1)) * 100 if position.get('cost', 1) > 0 else 0
        init_cost = float(position.get('initial_cost') or position.get('cost', 1) or 1)
        total_roi = (total_trade_net_pnl / init_cost) * 100 if init_cost > 0 else roi
        has_partial = bool(position.get('partial_tp_done') or position.get('partial_sl_done'))
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        part_pnl_str = ""
        if position.get('partial_tp_done'):
            part_pnl_str += f"🔹 **Lãi chốt 50% trước đó:** `+{part_tp_val:.4f} {quote}`\n"
        if position.get('partial_sl_done'):
            part_pnl_str += f"🔹 **Cắt giảm tải trước đó:** `{part_sl_val:.4f} {quote}`\n"
        if has_partial:
            part_pnl_str += f"🔹 **Tổng Net PnL toàn lệnh:** `{total_trade_net_pnl:+.4f} {quote}` ({total_roi:+.2f}% vốn lệnh)\n" 
        
        last_pnl_label = f"Lợi nhuận phần đóng cuối ({amount:.6g} coin)" if has_partial else "Lợi nhuận ước tính (PnL)"
        last_roi_str = f" ({roi:+.2f}%)" if not has_partial else ""

        msg = (
            f"{win_loss}\n**[{mode_str}] ĐÓNG LỆNH {direction_str} (SYNC)**\n\n"
            f"🔹 **Cặp giao dịch:** {symbol}\n"
            f"🔹 **Giá vào (Entry):** {entry_price:.6f}\n"
            f"🔹 **Giá chốt (Exit):** {exit_price:.6f}\n"
            f"🔹 **{last_pnl_label}:** {net_pnl:+.4f} {quote}{last_roi_str}\n"
            f"{part_pnl_str}"
            f"🔹 **Lý do đóng:** {close_reason}"
        )
        self._notify_telegram(msg)
        
        # 4. Ghi DB
        self.db.save_trade({
            'symbol': symbol,
            'side': ('buy' if direction == 'SHORT' else 'sell'),
            'type': 'market',
            'price': exit_price,
            'amount': amount,
            'cost': exit_price * amount,
            'fee': 0,
            'pnl': total_trade_net_pnl,
            'strategy': position.get('strategy', 'unknown'),
            'status': 'closed',
            'order_id': real_order_id or f"binance-sync-{int(time.time() * 1000)}",
            'exchange_trade_id': None,
            'timestamp': int(time.time() * 1000),
            'mode': self.mode,
            'raw': last_trade if 'last_trade' in locals() else {}
        })
        if position.get('order_id'):
            self.db.update_trade_status(str(position['order_id']), 'closed')

    def _check_open_positions(self):
        with self._position_lock:
            return self._check_open_positions_locked()

    def _position_management_loop(self):
        """Manage exchange protection independently from slow market scans/AI."""
        risk = self.config.get('risk', {})
        try:
            interval = int(risk.get('position_monitor_interval_seconds', 10))
        except (TypeError, ValueError, OverflowError):
            interval = 10
        interval = min(60, max(3, interval))

        while self.is_running and not self._position_monitor_stop.is_set():
            try:
                with self._position_lock:
                    has_positions = bool(self.open_positions)
                    has_stalking = bool(getattr(self, 'pending_stalking_orders', None))
                if has_positions or has_stalking:
                    if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                        if not self.sync_live_positions_with_exchange():
                            self._position_monitor_stop.wait(interval)
                            continue
                    self._check_open_positions()
            except Exception as e:
                logger.error("Lỗi luồng quản lý vị thế nhanh: %s", e)
            self._position_monitor_stop.wait(interval)

    def _get_asset_adaptive_trailing_profile(self, symbol: str) -> dict:
        """
        Xác định cấu hình chốt lời & Choke Trailing Stop thích ứng theo từng phân khúc tài sản
        dựa trên kết quả mô phỏng dữ liệu lịch sử chuẩn:
        1. TRADFI_STOCK (Cổ phiếu Mỹ: NVDA, TSLA, AAPL, MSTR, MU...):
           - Sóng nén trong ngày 1.0% - 2.5%, chốt 50% ở +0.70%, Choke ở +1.00%, Gap 1.0%.
        2. TRADFI_LEVERAGED_ETF (ETF Đòn bẩy 3x: SOXL, SOXS, TQQQ...):
           - Sóng gia tốc mạnh 4.0% - 8.0%, cho không gian gồng rộng (+1.20% chốt 50%, Choke ở +2.00%, Gap 1.6%).
        3. CRYPTO_MAJOR (Coin Top: BTC, ETH, SOL):
           - Thanh khoản dày, sóng nén đêm 1.1% - 1.5%, chốt 50% ở +0.75%, Choke ở +1.10%, Gap 1.0%.
        4. CRYPTO_PERPETUAL (Altcoins: SUI, NEAR, DOGE, TIA...):
           - Biến động trung bình cao, chốt 50% ở +0.90%, Choke ở +1.50%, Gap 1.3%.
        """
        asset_class = "CRYPTO_PERPETUAL"
        try:
            from ai.quantum_path_simulator import QuantumPathSimulator
            asset_class = QuantumPathSimulator.classify_asset(symbol, getattr(self, 'exchange', None))
        except Exception:
            clean = str(symbol).split(':')[0].upper().replace('/', '')
            if any(clean.startswith(e) for e in ('SOXL', 'SOXS', 'NVDL', 'TSLL', 'TQQQ', 'SQQQ', 'KORU')):
                asset_class = "TRADFI_LEVERAGED_ETF"
            elif any(clean.startswith(s) for s in ('NVDA', 'TSLA', 'AAPL', 'MSFT', 'MSTR', 'MU', 'AMD', 'INTC', 'SNDK', 'ON', 'SNXX', 'PLTR', 'COIN', 'AMZN', 'GOOG', 'META', 'NFLX', 'BABA')):
                asset_class = "TRADFI_STOCK"
            elif any(clean.startswith(m) for m in ('BTC', 'ETH', 'SOL')):
                asset_class = "CRYPTO_MAJOR"
            else:
                asset_class = "CRYPTO_PERPETUAL"

        # =========================================================================
        # BẢNG THAM SỐ SÀN LỢI NHUẬN BÙ PHÍ SÀN (FEE-COMPENSATED PAYOFF FLOOR)
        # KẾT QUẢ ĐÃ ĐƯỢC MÔ PHỎNG & ĐO LƯỜNG TỐI ƯU TRÊN 274 LỆNH LỊCH SỬ & 8 KỊCH BẢN THỰC NGHIỆM:
        # -------------------------------------------------------------------------
        # [LÝ DO BẮT BUỘC KHÔNG ĐƯỢC PHÉP THAY ĐỔI THAM SỐ NÀY]:
        # Phí Taker Binance Futures 2 đầu là 0.10% (0.05% mở + 0.05% đóng).
        # - Khảo sát thực tế 274 lệnh cũ cho thấy trung vị lệnh thắng chỉ đạt +0.42% (lãi ròng +0.32%),
        #   trong khi trung vị lệnh thua là -1.02% (lỗ ròng -1.12%) -> Payoff chỉ đạt 0.285 (cần Win Rate > 78% mới hòa).
        # - Mô phỏng nến 15m (MFE) chỉ ra: 72.5% lệnh đạt đỉnh >= +1.00%, và 58.9% chạm >= +1.35%.
        # - Kịch bản tối ưu nhất thực tế là TP1 = +1.20% ~ +1.35% và Trailing kích hoạt tại +0.95%:
        #   Profit Factor đạt ĐỈNH CỰC ĐẠI: 2.61, Win Rate giữ vững 65.6%, Payoff nhảy vọt lên 1.37!
        # - CẢNH BÁO: KHÔNG ĐƯỢC nâng TP1 >= 1.75% vì thực nghiệm chứng minh Win Rate sẽ rớt từ 65.6% xuống 57.8%!
        #   KHÔNG ĐƯỢC hạ TP1 <= 0.85% vì phí sàn sẽ bào mòn lợi nhuận và PF chỉ đạt 2.32!
        # =========================================================================
        if asset_class == "TRADFI_STOCK":
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0075,
                "partial_tp_trigger": 0.0110,
                "partial_tp_min": 0.0090,
                "partial_tp_max": 0.0140,
                "choke_trigger": 0.0140,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0080,
                "min_distance_pct": 0.008,
            }
        elif asset_class == "TRADFI_LEVERAGED_ETF":
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0085,
                "partial_tp_trigger": 0.0140,
                "partial_tp_min": 0.0110,
                "partial_tp_max": 0.0170,
                "choke_trigger": 0.0200,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0120,
                "min_distance_pct": 0.012,
            }
        elif asset_class == "CRYPTO_MAJOR":
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0075,
                "partial_tp_trigger": 0.0095,
                "partial_tp_min": 0.0085,
                "partial_tp_max": 0.0115,
                "choke_trigger": 0.0120,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0075,
                "min_distance_pct": 0.007,
            }
        else: # CRYPTO_PERPETUAL (Altcoins) - VÙNG GIAO THOA VÀNG ĐẠT PF 2.61
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0080,
                "partial_tp_trigger": 0.0125,
                "partial_tp_min": 0.0110,
                "partial_tp_max": 0.0150,
                "choke_trigger": 0.0180,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0090,
                "min_distance_pct": 0.009,
            }

    def _adaptive_trailing_metrics(self, position: dict, current_price: float) -> dict:
        """Build a bounded ATR/ADX trailing distance from closed candles."""
        symbol = str(position.get('symbol') or '')
        profile = self._get_asset_adaptive_trailing_profile(symbol)
        risk = self.config.get('risk', {})
        try:
            period = int(risk.get('trailing_atr_period', 14))
        except (TypeError, ValueError, OverflowError):
            period = 14
        period = min(50, max(5, period))
        timeframe = str(risk.get('trailing_atr_timeframe', '15m'))
        try:
            cache_ttl = float(risk.get('trailing_atr_refresh_seconds', 60))
        except (TypeError, ValueError, OverflowError):
            cache_ttl = 60.0
        cache_ttl = min(600.0, max(5.0, cache_ttl))

        try:
            min_pct = float(profile.get('min_distance_pct', risk.get('trailing_min_distance_pct', 0.005)))
            max_pct = float(risk.get('trailing_max_distance_pct', 0.04))
            base_fallback_pct = float(profile.get('trailing_gap', risk.get('trailing_stop_pct', 0.015)))
            base_multiplier = float(risk.get('trailing_atr_multiplier', 2.0))
            trend_threshold = float(risk.get('trailing_trend_adx_threshold', 25.0))
            favorable_multiplier = float(risk.get('trailing_favorable_trend_multiplier', 1.15))
            adverse_multiplier = float(risk.get('trailing_adverse_trend_multiplier', 0.85))
            min_step_pct = float(risk.get('trailing_min_step_pct', 0.001))
        except (TypeError, ValueError, OverflowError):
            min_pct = profile.get('min_distance_pct', 0.005)
            max_pct = 0.04
            base_fallback_pct = profile.get('trailing_gap', 0.015)
            base_multiplier, trend_threshold = 2.0, 25.0
            favorable_multiplier, adverse_multiplier = 1.15, 0.85
            min_step_pct = 0.001

        min_pct = min(0.20, max(0.001, min_pct))
        max_pct = min(0.20, max(min_pct, max_pct))
        base_fallback_pct = min(max_pct, max(min_pct, base_fallback_pct))
        base_multiplier = min(5.0, max(0.25, base_multiplier))
        favorable_multiplier = min(2.0, max(1.0, favorable_multiplier))
        adverse_multiplier = min(1.0, max(0.5, adverse_multiplier))
        min_step_pct = min(0.05, max(0.0, min_step_pct))

        cache = self._trailing_market_cache.get(symbol)
        now = time.monotonic()
        if cache and cache.get('error') and now - cache.get('time', 0.0) < cache_ttl:
            previous = position.get('trailing_distance_pct')
            try:
                fallback = float(previous) if previous is not None else base_fallback_pct
            except (TypeError, ValueError, OverflowError):
                fallback = base_fallback_pct
            return {
                'distance_pct': min(max_pct, max(min_pct, fallback)),
                'atr_pct': None,
                'adx': None,
                'regime': 'fallback',
                'min_step_pct': min_step_pct,
                'ema20': None,
                'profile': profile,
            }
        if not cache or now - cache.get('time', 0.0) >= cache_ttl:
            try:
                import ta
                candles = self.exchange.get_ohlcv(
                    symbol, timeframe, limit=max(60, period * 3 + 2)
                )
                if candles is None or len(candles) < period * 2 + 2:
                    raise ValueError("Không đủ nến đóng để tính ATR/ADX")

                # Ignore the still-forming candle so the volatility estimate does
                # not jump around while its OHLC values are incomplete.
                closed = candles.iloc[:-1]
                atr_values = ta.volatility.AverageTrueRange(
                    closed['high'], closed['low'], closed['close'], window=period
                ).average_true_range()
                adx_indicator = ta.trend.ADXIndicator(
                    closed['high'], closed['low'], closed['close'], window=period
                )
                adx_values = adx_indicator.adx()
                plus_values = adx_indicator.adx_pos()
                minus_values = adx_indicator.adx_neg()
                ema20_indicator = ta.trend.EMAIndicator(closed['close'], window=20)
                ema20_values = ema20_indicator.ema_indicator()

                atr_value = float(atr_values.iloc[-1])
                adx_value = float(adx_values.iloc[-1])
                plus_value = float(plus_values.iloc[-1])
                minus_value = float(minus_values.iloc[-1])
                ema20_value = float(ema20_values.iloc[-1]) if not ema20_values.empty else None
                avg_vol_20 = float(closed['volume'].tail(20).mean()) if ('volume' in closed.columns and len(closed) >= 20) else 1.0
                latest_vol = float(closed['volume'].iloc[-1]) if ('volume' in closed.columns and not closed.empty) else 1.0
                rvol_value = float(latest_vol / avg_vol_20) if avg_vol_20 > 0 else 1.0
                if not all(math.isfinite(v) for v in (atr_value, adx_value, plus_value, minus_value)) or atr_value <= 0:
                    raise ValueError("ATR/ADX không hợp lệ")

                cache = {
                    'time': now,
                    'atr': atr_value,
                    'adx': adx_value,
                    'di_plus': plus_value,
                    'di_minus': minus_value,
                    'ema20': ema20_value,
                    'rvol': rvol_value,
                }
                self._trailing_market_cache[symbol] = cache
            except Exception as e:
                self._trailing_market_cache[symbol] = {'time': now, 'error': str(e)}
                logger.warning(
                    "Không tính được ATR/ADX cho trailing %s; dùng khoảng dự phòng: %s",
                    symbol, e,
                )
                previous = position.get('trailing_distance_pct')
                try:
                    fallback = float(previous) if previous is not None else base_fallback_pct
                except (TypeError, ValueError, OverflowError):
                    fallback = base_fallback_pct
                fallback = min(max_pct, max(min_pct, fallback))
                return {
                    'distance_pct': fallback,
                    'atr_pct': None,
                    'adx': None,
                    'regime': 'fallback',
                    'min_step_pct': min_step_pct,
                    'ema20': None,
                    'rvol': 1.0,
                    'profile': profile,
                }

        price = float(current_price)
        if not math.isfinite(price) or price <= 0:
            return {
                'distance_pct': base_fallback_pct,
                'atr_pct': None,
                'adx': None,
                'regime': 'fallback',
                'min_step_pct': min_step_pct,
                'ema20': None,
                'rvol': 1.0,
                'profile': profile,
            }

        direction = position.get('direction', 'LONG')
        favorable = (
            cache['di_plus'] > cache['di_minus']
            if direction == 'LONG'
            else cache['di_minus'] > cache['di_plus']
        )
        adverse = not favorable
        multiplier = base_multiplier
        regime = 'ranging'
        if cache['adx'] >= trend_threshold and favorable:
            multiplier *= favorable_multiplier
            regime = 'trend_favorable'
        elif cache['adx'] >= trend_threshold and adverse:
            multiplier *= adverse_multiplier
            regime = 'trend_adverse'

        atr_pct = cache['atr'] / price
        distance_pct = min(max_pct, max(min_pct, atr_pct * multiplier))
        return {
            'distance_pct': distance_pct,
            'atr_pct': atr_pct,
            'adx': cache['adx'],
            'regime': regime,
            'min_step_pct': min_step_pct,
            'ema20': cache.get('ema20'),
            'rvol': cache.get('rvol', 1.0),
            'profile': profile,
        }

    def _trailing_net_breakeven(self, position: dict) -> float:
        """Estimate a fee-aware exit price, with a configurable cost reserve."""
        risk = self.config.get('risk', {})
        trading = self.config.get('trading', {})
        entry = float(position.get('entry_price') or 0)
        amount = abs(float(position.get('amount') or 0))
        if entry <= 0 or amount <= 0:
            return entry

        try:
            configured_fee = float(trading.get('fee_rate', 0.001))
            extra_cost = float(risk.get('trailing_cost_buffer_pct', 0.001))
        except (TypeError, ValueError, OverflowError):
            configured_fee, extra_cost = 0.001, 0.001
        configured_fee = min(0.05, max(0.0, configured_fee))
        extra_cost = min(0.05, max(0.0, extra_cost))

        entry_fee = max(0.0, float(position.get('entry_fee') or 0))
        observed_entry_fee_rate = entry_fee / (entry * amount)
        entry_fee_rate = observed_entry_fee_rate if observed_entry_fee_rate > 0 else configured_fee
        exit_cost_rate = min(0.20, configured_fee + extra_cost)

        if position.get('direction', 'LONG') == 'LONG':
            denominator = max(0.50, 1.0 - exit_cost_rate)
            return entry * (1.0 + entry_fee_rate) / denominator
        return entry * (1.0 - entry_fee_rate) / (1.0 + exit_cost_rate)

    def _calc_adaptive_stages(self, position: dict, current_price: float) -> int:
        """
        DYNAMIC ADAPTIVE STAGING ENGINE:
        Tự động xác định số nấc tối ưu (1 đến 5 nấc) cho vị thế dựa trên Notional,
        đảm bảo 100% không bao giờ gặp lỗi sàn Binance MIN_NOTIONAL (-4164).
        """
        init_amt = float(position.get('initial_amount') or position.get('amount') or 0)
        entry_p = float(position.get('entry_price') or current_price or 0)
        base_p = entry_p if entry_p > 0 else current_price
        pos_notional = init_amt * base_p
        chunk_floor = 5.50
        # ĐO LƯỜNG TỐI ƯU SÀN BINANCE:
        # Với vốn nhỏ quanh 50 USDT, trần Notional 20% là ~10.15 USDT.
        # Do bước làm tròn lot_step của Altcoin hoặc biến động nhẹ 1-2%, giá trị thực tế có thể dao động 9.80 - 10.15 USDT.
        # Sử dụng base_p cố định theo entry_price để vị thế không bị tụt nấc bảo vệ khi nến 15M điều chỉnh âm nhẹ.
        raw_k = int(pos_notional // chunk_floor)
        if raw_k < 2 and pos_notional >= 9.80:
            half_notional = (init_amt / 2.0) * base_p
            if half_notional >= 4.90:
                raw_k = 2
        return max(1, min(5, raw_k))

    @staticmethod
    def _conditional_order_id(order: dict) -> str:
        info = order.get('info') or {}
        order_id = order.get('id') or info.get('algoId') or info.get('orderId')
        return str(order_id or '')

    def _retry_pending_protection_cleanup(self, position: dict, direction: str) -> List[str]:
        """Cancel and verify only this flat position's saved protective exits."""
        symbol = position.get('symbol')
        if not symbol:
            return ['missing symbol']

        known_ids = {
            str(position[key]) for key in ('sl_order_id', 'tp_order_id')
            if position.get(key)
        }
        known_ids.update(
            str(order_id) for order_id in position.get('stale_sl_order_ids', [])
            if order_id
        )

        if not known_ids:
            # Legacy/recovered positions may lack saved order IDs. The existing
            # matcher is restricted to reduce-only/close-position exits on the
            # same symbol and direction; never bulk-cancel entries.
            return self._cancel_position_protection_orders(position, direction)

        try:
            regular = self.exchange.get_open_orders(symbol, strict=True)
            trigger = self.exchange.get_open_orders(symbol, trigger=True, strict=True)
        except Exception as e:
            return [f'cannot verify open orders: {e}']

        for orders, is_trigger in ((regular, False), (trigger, True)):
            for order in orders:
                order_id = self._conditional_order_id(order)
                if order_id not in known_ids:
                    continue
                try:
                    self.exchange.cancel_order(
                        order_id, symbol, trigger=is_trigger, strict=True
                    )
                except Exception:
                    # The order may have triggered/canceled between reads.
                    # Verify below before deciding whether cleanup is pending.
                    pass

        try:
            remaining = (
                self.exchange.get_open_orders(symbol, strict=True)
                + self.exchange.get_open_orders(symbol, trigger=True, strict=True)
            )
        except Exception as e:
            return [f'cannot verify cancellation: {e}']

        remaining_ids = {
            self._conditional_order_id(order) for order in remaining
        }
        return sorted(known_ids & remaining_ids)

    def _retry_stale_trailing_stop_cancellations(self, position: dict) -> None:
        """Retry cleanup of old conditional stops without losing the active stop."""
        pending_ids = list(dict.fromkeys(
            str(order_id) for order_id in position.get('stale_sl_order_ids', [])
            if order_id
        ))
        if not pending_ids:
            return

        symbol = position['symbol']
        try:
            open_orders = self.exchange.get_open_orders(
                symbol, trigger=True, strict=True
            )
        except Exception as e:
            logger.error(
                "Không xác minh được các trailing stop cũ của %s; giữ nguyên danh sách để thử lại: %s",
                symbol, e,
            )
            return

        open_ids = {self._conditional_order_id(order) for order in open_orders}
        for order_id in pending_ids:
            if order_id not in open_ids:
                continue
            try:
                self.exchange.cancel_order(
                    order_id, symbol, trigger=True, strict=True
                )
            except Exception as e:
                logger.warning(
                    "Chưa hủy được trailing stop cũ %s của %s; sẽ thử lại chu kỳ sau: %s",
                    order_id, symbol, e,
                )

        try:
            remaining_orders = self.exchange.get_open_orders(
                symbol, trigger=True, strict=True
            )
            remaining_ids = {
                self._conditional_order_id(order) for order in remaining_orders
            }
            position['stale_sl_order_ids'] = [
                order_id for order_id in pending_ids if order_id in remaining_ids
            ]
        except Exception as e:
            # Keep every ID pending unless Binance confirms it is no longer open.
            position['stale_sl_order_ids'] = pending_ids
            logger.error(
                "Không xác minh được kết quả dọn trailing stop của %s; sẽ thử lại: %s",
                symbol, e,
            )


    def _check_pending_stalking_orders_locked(self):
        """
        Kiểm tra và quản lý các lệnh bắn tỉa rình mồi M1 (Sniper Retest Stalking).
        1. Nếu sàn báo lệnh Limit đã khớp: kích hoạt vị thế mở, đặt Stop-Loss và Take-Profit trên Binance.
        2. Nếu giá xả gãy thủng ngưỡng an toàn (> -0.80%): HỦY LỆNH NGAY để bảo vệ 100% vốn trước cú sập bẫy.
        3. Nếu quá thời gian chờ (15 phút) hoặc giá phóng vọt bay thẳng (> +1.50%): Hủy lệnh an toàn.
        """
        if not self.is_running or not getattr(self, 'pending_stalking_orders', None):
            return

        now = time.time()
        for symbol, stalking in list(self.pending_stalking_orders.items()):
            order_id = str(stalking.get('order_id') or '')
            side = stalking.get('side', 'buy')
            direction = stalking.get('direction', 'LONG')
            signal_price = float(stalking.get('signal_price') or 0.0)
            target_price = float(stalking.get('target_price') or 0.0)
            invalid_price = float(stalking.get('invalid_price') or 0.0)
            created_at = float(stalking.get('created_at') or now)
            timeout_sec = float(stalking.get('timeout_seconds') or 900.0)

            # Lấy giá thị trường hiện tại
            current_price = signal_price
            try:
                ticker = self.exchange.get_ticker(symbol)
                if ticker:
                    current_price = float(ticker.get('last') or ticker.get('close') or signal_price)
            except Exception:
                pass

            is_filled = False
            is_cancelled = False

            if self.mode == 'live' and order_id and getattr(self, 'market_type', 'spot') == 'futures':
                try:
                    order_status_info = self.exchange.get_order_status(order_id, symbol)
                    order_status = str((order_status_info or {}).get('status') or '').lower()
                    filled_qty = float((order_status_info or {}).get('filled') or 0.0)
                    if order_status in ('closed', 'filled'):
                        is_filled = True
                        target_price = float(order_status_info.get('average') or order_status_info.get('price') or target_price)
                        if filled_qty > 0:
                            stalking['amount'] = filled_qty
                    elif order_status in ('canceled', 'cancelled', 'rejected', 'expired'):
                        if filled_qty > 0:
                            is_filled = True
                            target_price = float(order_status_info.get('average') or order_status_info.get('price') or target_price)
                            stalking['amount'] = filled_qty
                        else:
                            is_cancelled = True
                except Exception as e:
                    logger.debug(f"Chưa lấy được trạng thái lệnh rình mồi {symbol}: {e}")
            elif self.mode == 'demo':
                if direction == 'LONG':
                    if current_price <= target_price and current_price > invalid_price:
                        is_filled = True
                    elif current_price <= invalid_price:
                        is_cancelled = True
                else:
                    if current_price >= target_price and current_price < invalid_price:
                        is_filled = True
                    elif current_price >= invalid_price:
                        is_cancelled = True

            # Kịch bản 1: LỆNH ĐÃ KHỚP ĐÁY RETEST THÀNH CÔNG!
            if is_filled:
                logger.info(f"🎯 [BẮN TỈA M1 KHỚP ĐÁY RETEST] {symbol} ({direction}): Đã khớp lệnh tại {target_price:.6g}! Đang kích hoạt vị thế...")
                self._activate_stalking_position(stalking, target_price)
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                continue

            if is_cancelled:
                logger.info(f"Lệnh rình mồi M1 của {symbol} đã bị hủy trên sàn.")
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                try:
                    from core.gate_telemetry import clear_radar_candidate
                    clear_radar_candidate(symbol)
                except Exception:
                    pass
                continue

            # Kịch bản 2: BẢO VỆ XẢ GÃY THỦNG NGƯỠNG AN TOÀN (> -0.80%)
            is_dumping = False
            if direction == 'LONG' and current_price <= invalid_price:
                is_dumping = True
            elif direction == 'SHORT' and current_price >= invalid_price:
                is_dumping = True

            if is_dumping:
                logger.warning(
                    f"🛡️ [M1 BẢO VỆ XẢ GÃY - HỦY LỆNH ĐÓN LÕNG] {symbol} ({direction}): "
                    f"Giá thị trường ({current_price:.6g}) đã xả gãy thủng ngưỡng an toàn ({invalid_price:.6g})! "
                    f"HỦY LỆNH CHỜ NGAY LẬP TỨC ĐỂ BẢO VỆ 100% VỐN!"
                )
                if self.mode == 'live' and order_id:
                    try:
                        self.exchange.cancel_order(order_id, symbol)
                    except Exception as ce:
                        logger.error(f"Lỗi hủy lệnh limit rình mồi {symbol}: {ce}", exc_info=True)
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                try:
                    from core.gate_telemetry import clear_radar_candidate
                    clear_radar_candidate(symbol)
                except Exception:
                    pass
                self._notify_telegram(
                    f"🛡️ **[M1 BẢO VỆ XẢ GÃY - ĐÃ HỦY LỆNH]**\n"
                    f"Cặp: **{symbol}** ({direction})\n"
                    f"Giá đã xả thủng ngưỡng -0.80% (Giá: `{current_price:.6g}` < Ngưỡng: `{invalid_price:.6g}`).\n"
                    f"🚪 **Đã hủy lệnh Limit đón lõng, bảo toàn 100% vốn trước cú sập bẫy!**"
                )
                continue

            # Kịch bản 3: GIÁ BAY THẲNG HOẶC HẾT HẠN CHỜ (TIMEOUT 15M)
            is_runner_away = False
            if direction == 'LONG' and current_price >= signal_price * 1.015:
                is_runner_away = True
            elif direction == 'SHORT' and current_price <= signal_price * 0.985:
                is_runner_away = True

            is_timeout = (now - created_at) >= timeout_sec

            if is_runner_away or is_timeout:
                reason_str = "Giá bay thẳng > +1.5% không hồi" if is_runner_away else f"Hết thời gian chờ {timeout_sec/60:.0f} phút"
                logger.info(f"⏱️ [M1 HỦY LỆNH RÌNH MỒI] {symbol}: {reason_str}. Hủy lệnh chờ an toàn.")
                if self.mode == 'live' and order_id:
                    try:
                        self.exchange.cancel_order(order_id, symbol)
                    except Exception as ce:
                        logger.error(f"Lỗi hủy lệnh limit rình mồi {symbol}: {ce}", exc_info=True)
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                try:
                    from core.gate_telemetry import clear_radar_candidate
                    clear_radar_candidate(symbol)
                except Exception:
                    pass
                continue

    def _activate_stalking_position(self, stalking: dict, fill_price: float):
        """Kích hoạt vị thế chính thức sau khi lệnh bắn tỉa M1 khớp đáy retest thành công."""
        symbol = stalking['symbol']
        side = stalking['side']
        direction = stalking['direction']
        amount = stalking['amount']
        position_size = stalking['position_size']
        leverage = stalking['leverage']
        order_id = stalking['order_id']
        entry_price = fill_price
        clamped_sl_dist = float(stalking.get('clamped_sl_dist') or 0.02)
        clamped_tp_dist = float(stalking.get('clamped_tp_dist') or 0.04)

        if direction == 'LONG':
            sl_price = entry_price * (1.0 - clamped_sl_dist)
            tp_price = entry_price * (1.0 + clamped_tp_dist)
        else:
            sl_price = entry_price * (1.0 + clamped_sl_dist)
            tp_price = entry_price * (1.0 - clamped_tp_dist)

        if hasattr(self.exchange, 'exchange') and hasattr(self.exchange.exchange, 'price_to_precision'):
            try:
                sl_price = float(self.exchange.exchange.price_to_precision(symbol, sl_price))
                tp_price = float(self.exchange.exchange.price_to_precision(symbol, tp_price))
            except Exception:
                pass

        if self.mode == 'live':
            position_size = amount * entry_price / max(1.0, leverage)

        # Đặt Stop-Loss và Take-Profit ngay lập tức trên Binance Futures
        sl_order_id = None
        tp_order_id = None
        protection_status = 'exchange_stop' if self.mode == 'demo' else 'pending_placement'
        close_side = 'sell' if side == 'buy' else 'buy'

        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            try:
                sl_order = self.exchange.create_stop_market_order(symbol, close_side, amount, sl_price)
                sl_info = (sl_order or {}).get('info') or {}
                sl_order_id = str((sl_order or {}).get('id') or sl_info.get('algoId') or sl_info.get('orderId') or '')
                if sl_order_id:
                    protection_status = 'exchange_stop'
                    logger.info(f"✅ Đã đặt Stop-Loss bảo vệ M1 cho {symbol} tại {sl_price:.6g} (Order ID: {sl_order_id})")
                else:
                    protection_status = 'bot_poll_only'
                    logger.warning(f"Binance chưa trả về ID cho Stop-Loss {symbol}")
            except Exception as e:
                protection_status = 'bot_poll_only'
                logger.error(f"Lỗi đặt Stop-Loss bảo vệ M1 cho {symbol}: {e}", exc_info=True)

            try:
                tp_order = self.exchange.create_take_profit_market_order(symbol, close_side, amount, tp_price)
                tp_info = (tp_order or {}).get('info') or {}
                tp_order_id = str((tp_order or {}).get('id') or tp_info.get('algoId') or tp_info.get('orderId') or '')
                if tp_order_id:
                    logger.info(f"✅ Đã đặt Take-Profit bảo vệ M1 cho {symbol} tại {tp_price:.6g} (Order ID: {tp_order_id})")
            except Exception as e:
                logger.error(f"Lỗi đặt Take-Profit bảo vệ M1 cho {symbol}: {e}", exc_info=True)

        # Tính phí sàn (Maker 0.02% thay vì Taker 0.05%)
        entry_fee = (amount * entry_price) * 0.0002
        strategy_name = stalking.get('strategy', 'sniper_m1')
        confidence = float(stalking.get('confidence', 0.8))

        position = {
            'symbol': symbol,
            'side': side,
            'direction': direction,
            'entry_price': entry_price,
            'amount': amount,
            'cost': position_size,
            'entry_fee': entry_fee,
            'leverage': leverage,
            'exchange_leverage_limit': stalking.get('exchange_leverage_limit'),
            'leverage_limit_verified': stalking.get('leverage_limit_verified', True),
            'leverage_limit_source': stalking.get('leverage_limit_source', 'bracket'),
            'market_type': stalking.get('market_type', getattr(self, 'market_type', 'spot')),
            'stop_loss': sl_price,
            'take_profit': tp_price,
            'strategy': strategy_name,
            'trap_type': None,
            'signal_quality': getattr(self, 'last_signal_quality', 1.0),
            'timestamp': datetime.now().isoformat(),
            'order_id': order_id,
            'sl_order_id': sl_order_id,
            'tp_order_id': tp_order_id,
            'protection_status': protection_status,
            'trailing_stop': None,
            'trailing_best_price': entry_price,
            'trailing_active': False,
            'trailing_status': 'waiting_net_profit',
            'trailing_distance_pct': None,
            'trailing_atr_pct': None,
            'trailing_adx': None,
            'trailing_regime': 'not_calculated',
            'trailing_net_breakeven': None,
        }
        self.open_positions.append(position)
        try:
            from core.gate_telemetry import clear_radar_candidate
            clear_radar_candidate(position.get('symbol', ''))
        except Exception:
            pass
        if self.mode != 'live':
            self.balance -= position_size
            self.balance -= entry_fee
        self.trade_count += 1

        # Gửi Telegram thông báo khớp lệnh M1
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        msg = (
            f"🎯 **[{mode_str}] BẮN TỈA M1 KHỚP ĐÁY RETEST: {direction_str}** [MAKER 0.02% FEE]\n\n"
            f"📊 **Cặp giao dịch:** {symbol} ({leverage}x)\n"
            f"🎯 **Giá khớp đáy (Entry):** `{entry_price:.6f}` (Rẻ hơn 0.35% so với đỉnh!)\n"
            f"🛑 **Cắt lỗ (SL):** `{sl_price:.6f}` ({abs(sl_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
            f"🎯 **Chốt lời (TP):** `{tp_price:.6f}` ({abs(tp_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
            f"🧠 **AI & Chiến lược:** {strategy_name} (Sniper Retest Execution)\n"
            f"💰 **Ký quỹ:** {position_size:.2f} {quote} | **Khả dụng:** {self.balance:.2f} {quote}" + (f" | **Tổng vốn:** {float(self._futures_account_snapshot.get('wallet_balance')):.2f} {quote}" if self.mode == 'live' and getattr(self, '_futures_account_snapshot', None) and self._futures_account_snapshot.get('wallet_balance') is not None else "")
        )
        self._notify_telegram(msg)

        # Lưu lịch sử trade
        self.db.save_trade({
            'symbol': symbol,
            'side': side,
            'type': 'limit_maker',
            'price': entry_price,
            'amount': amount,
            'cost': position_size,
            'fee': entry_fee,
            'pnl': 0,
            'strategy': position['strategy'],
            'status': 'open',
            'order_id': order_id,
            'timestamp': int(time.time() * 1000),
            'mode': self.mode
        })

    def _check_open_positions_locked(self):
        """Kiểm tra stop-loss và take-profit cho các positions đang mở."""
        if not self.is_running:
            return
        # Giám sát và xử lý các lệnh bắn tỉa rình mồi M1 (Sniper Retest Stalking)
        self._check_pending_stalking_orders_locked()
        for position in self.open_positions[:]:  # Copy list to avoid mutation issues
            try:
                if (
                    self.mode == 'live'
                    and getattr(self, 'market_type', 'spot') == 'futures'
                    and position.get('protection_review_required')
                ):
                    # Never close using synthesized/local prices if exchange
                    # protection could not be verified; leave the user-visible
                    # review flag in place until a fresh exchange snapshot.
                    continue
                self._retry_stale_trailing_stop_cancellations(position)
                ticker = self.exchange.get_ticker(position['symbol'])
                if not ticker:
                    continue
                    
                raw_ticker_price = ticker.get('last') or ticker.get('close')
                if raw_ticker_price is None:
                    continue
                try:
                    current_price = float(raw_ticker_price)
                    if not math.isfinite(current_price) or current_price <= 0:
                        continue
                except (TypeError, ValueError):
                    continue
                direction = position.get('direction', 'LONG')
                
                # 0. BẢO VỆ CUỐI TUẦN CHO CỔ PHIẾU MỸ (TRADFI WEEKEND SHIELD & AUTO-CLOSE):
                if MarketScanner.is_tradfi_stock(position.get('symbol', '')):
                    tradfi_cfg = self.config.get('tradfi', {})
                    is_gap_window = MarketScanner.is_weekend_gap_risk_window()
                    
                    if not is_gap_window:
                        if position.get('weekend_shield_applied') or position.get('weekend_shield_loss_logged'):
                            position.pop('weekend_shield_applied', None)
                            position.pop('weekend_shield_loss_logged', None)
                    else:
                        # Phương án A: Tùy chọn đóng cưỡng bức (Forced Weekend Close) nếu cấu hình weekend_close: true
                        if tradfi_cfg.get('weekend_close', False):
                            logger.warning(
                                f"🛡️ [CHỐT LỆNH CUỐI TUẦN] {position['symbol']} @ {current_price:.6g}! "
                                f"Tự động đóng vị thế trước kỳ nghỉ cuối tuần của sàn chứng khoán Mỹ theo cấu hình weekend_close."
                            )
                            self._close_position(position, current_price, close_reason="🛡️ Tự động chốt lệnh trước kỳ nghỉ cuối tuần (Tránh Gap giá)")
                            continue

                        # Phương án B: BẢO HIỂM THÔNG MINH CUỐI TUẦN (SMART WEEKEND SHIELD - HYBRID MẶC ĐỊNH)
                        # Giữ nguyên lệnh 24/7 trên Binance, NHƯNG nếu có lãi (PnL > 0) -> kéo ngay SL về Hòa Vốn (Net Breakeven)
                        # để trở thành vị thế Risk-Free 100%, săn Take Profit xuyên suốt Thứ 7 & Chủ Nhật mà không sợ rủi ro mở phiên Thứ 2!
                        if tradfi_cfg.get('weekend_shield', True):
                            try:
                                entry_p = float(position.get('entry_price') or 0)
                                current_sl = float(position.get('stop_loss') or 0)
                                net_be = self._trailing_net_breakeven(position)
                                
                                is_in_profit = False
                                if direction == 'LONG' and current_price > entry_p:
                                    is_in_profit = True
                                elif direction == 'SHORT' and current_price < entry_p:
                                    is_in_profit = True

                                if is_in_profit:
                                    proposed_shield_sl = net_be
                                    improves = False
                                    if direction == 'LONG' and proposed_shield_sl > current_sl:
                                        improves = True
                                    elif direction == 'SHORT' and proposed_shield_sl < current_sl:
                                        improves = True

                                    if improves:
                                        is_live_fut = (
                                            self.mode == 'live'
                                            and getattr(self, 'market_type', 'spot') == 'futures'
                                        )
                                        old_sl_id = str(position.get('sl_order_id') or '')
                                        close_side = 'sell' if direction == 'LONG' else 'buy'
                                        shield_success = True
                                        new_shield_sl_id = old_sl_id

                                        if is_live_fut:
                                            new_order = self.exchange.create_stop_market_order(
                                                position['symbol'], close_side,
                                                position['amount'], proposed_shield_sl,
                                            )
                                            new_info = (new_order or {}).get('info') or {}
                                            new_shield_sl_id = str(
                                                (new_order or {}).get('id')
                                                or new_info.get('algoId')
                                                or new_info.get('orderId')
                                                or ''
                                            )
                                            shield_success = bool(new_shield_sl_id)
                                            if not shield_success:
                                                logger.error(
                                                    f"Binance chưa xác nhận SL bảo hiểm cuối tuần cho {position['symbol']}; giữ nguyên SL cũ tại {current_sl:.6g}"
                                                )

                                        if shield_success:
                                            position['stop_loss'] = proposed_shield_sl
                                            position['sl_order_id'] = new_shield_sl_id
                                            position['weekend_shield_applied'] = True

                                            if is_live_fut and old_sl_id and old_sl_id != new_shield_sl_id:
                                                pending_ids = list(dict.fromkeys(
                                                    str(oid) for oid in position.get('stale_sl_order_ids', []) if oid
                                                ))
                                                pending_ids.append(old_sl_id)
                                                position['stale_sl_order_ids'] = list(dict.fromkeys(pending_ids))
                                                try:
                                                    self.exchange.cancel_order(
                                                        old_sl_id, position['symbol'],
                                                        trigger=True, strict=True,
                                                    )
                                                except Exception as ce:
                                                    logger.warning("Chưa hủy ngay được SL cũ %s của %s: %s", old_sl_id, position['symbol'], ce)

                                            self._save_state()
                                            logger.info(
                                                f"🛡️ [BẢO HIỂM CUỐI TUẦN - RISK FREE] Đã kéo SL cho {position['symbol']} "
                                                f"từ {current_sl:.6g} lên mức Hòa Vốn an toàn {proposed_shield_sl:.6g} (Entry: {entry_p:.6g})!"
                                            )
                                            self._notify_telegram(
                                                f"🛡️ **[BẢO HIỂM CUỐI TUẦN - 100% RISK-FREE]**\n"
                                                f"Cổ phiếu: **{position['symbol']}** ({direction})\n"
                                                f"Thị trường New York bước vào kỳ nghỉ cuối tuần. Để bảo toàn lợi nhuận và diệt trừ rủi ro Gap giá:\n"
                                                f"🔹 **Entry:** `{entry_p:.6g}` | **Giá hiện tại:** `{current_price:.6g}`\n"
                                                f"🛡️ **Stop-Loss đã kéo về Hòa Vốn:** `{current_sl:.6g}` ➡️ `{proposed_shield_sl:.6g}`\n"
                                                f"💎 **Trạng thái:** Vị thế miễn nhiễm rủi ro (Risk-Free)! Bot tiếp tục giữ lệnh 24/7 trên Binance để săn Take Profit qua Thứ Bảy & Chủ Nhật."
                                            )
                                    elif not position.get('weekend_shield_applied'):
                                        position['weekend_shield_applied'] = True
                                        logger.info(
                                            f"🛡️ [BẢO HIỂM CUỐI TUẦN] {position['symbol']} đã được bảo vệ có lãi từ trước (SL: {current_sl:.6g} >= BE: {net_be:.6g}). Tiếp tục gồng lệnh 24/7."
                                        )
                                        self._save_state()
                                else:
                                    # Lệnh chưa có lãi (đang hòa hoặc âm nhẹ trong phạm vi SL cho phép)
                                    if not position.get('weekend_shield_loss_logged'):
                                        logger.info(
                                            f"🛡️ [BẢO HIỂM CUỐI TUẦN] {position['symbol']} chưa đạt điểm chốt lời/hòa vốn (Giá: {current_price:.6g}, Entry: {entry_p:.6g}). "
                                            f"Giữ nguyên SL sàn {current_sl:.6g}, không cắt lỗ non, tiếp tục khớp lệnh 24/7 trên Binance."
                                        )
                                        position['weekend_shield_loss_logged'] = True
                                        self._save_state()
                            except Exception as wse:
                                logger.error(f"Lỗi xử lý Weekend Shield cho {position.get('symbol')}: {wse}")

                # 1. Kiểm tra Stop-Loss theo kế hoạch (SL đặt trên sàn)
                is_sl_hit = False
                if direction == 'LONG' and current_price <= position['stop_loss']:
                    is_sl_hit = True
                elif direction == 'SHORT' and current_price >= position['stop_loss']:
                    is_sl_hit = True

                if is_sl_hit or self.risk_manager.check_stop_loss(position, current_price):
                    logger.warning(
                        f"🛑 STOP-LOSS hit! {position['symbol']} "
                        f"@ {current_price:.6g} (SL: {position['stop_loss']:.6g})"
                    )
                    self._close_position(position, current_price, close_reason="Chạm Stop Loss theo kế hoạch")
                    continue
                    
                # 2. Cầu dao bảo vệ thảm họa khẩn cấp (Emergency Circuit Breaker):
                # Chỉ kích hoạt khi giá sập/bơm thủng sâu quá mức Stop-Loss cho phép (Flash crash / Trượt giá nghiêm trọng)
                entry_price_val = float(position.get('entry_price') or 0)
                fast_pnl_pct = 0.0
                if entry_price_val > 0:
                    fast_pnl_pct = (current_price - entry_price_val) / entry_price_val if direction == 'LONG' else (entry_price_val - current_price) / entry_price_val
                    
                max_allowed_loss = -max(0.045, abs(float(self.config.get('risk', {}).get('stop_loss_pct', 0.04))) * 1.25)
                if fast_pnl_pct <= max_allowed_loss:
                    logger.critical(
                        f"🚨 [CẦU DAO CẮT LỖ THẢM HỌA] {position['symbol']} rơi tự do chạm {fast_pnl_pct*100:.2f}% "
                        f"(vượt ngưỡng trần rủi ro {max_allowed_loss*100:.2f}%)! Đóng vị thế khẩn cấp bảo vệ tài khoản."
                    )
                    self._close_position(position, current_price, close_reason=f"Cầu dao cắt lỗ thảm họa ({fast_pnl_pct*100:.2f}%)")
                    continue
                
                # Kiểm tra take-profit
                # --- DYNAMIC TAKE PROFIT VẬT LÝ TRÊN SÀN (GỒNG SIÊU SÓNG KÈM KHÓA SL BẢO HIỂM 100%) ---
                if self.config.get('risk', {}).get('enable_dynamic_tp', False):
                    try:
                        metrics = self._adaptive_trailing_metrics(position, current_price)
                        adx = float(metrics.get('adx') or 0)
                        atr_pct = float(metrics.get('atr_pct') or 0.01)
                        entry_price = float(position.get('entry_price') or 0)
                        current_tp = float(position.get('take_profit') or 0)
                        current_sl = float(position.get('stop_loss') or 0)
                        
                        last_tp_extend = float(position.get('last_tp_extend_time', 0))
                        now_ts = time.time()
                        
                        if entry_price > 0 and current_tp > 0 and (now_ts - last_tp_extend >= 60.0):
                            tp_dist_pct = abs(current_tp - current_price) / current_price
                            
                            new_tp = None
                            locked_sl = None
                            
                            if direction == 'LONG':
                                # Giá tiến sát TP (< 1.2*ATR) và đà tăng đang rất mạnh (ADX > 30)
                                if tp_dist_pct < atr_pct * 1.2 and adx > 30 and current_price > entry_price:
                                    new_tp = current_tp * (1 + atr_pct * 2.0)
                                    # KHÓA SL BẢO HIỂM: Kéo SL lên ngay mức TP cũ (đảm bảo không vượt quá giá hiện tại)
                                    proposed_locked_sl = min(current_tp * 0.998, current_price * 0.997)
                                    if proposed_locked_sl > current_sl:
                                        locked_sl = proposed_locked_sl
                            else:
                                if tp_dist_pct < atr_pct * 1.2 and adx > 30 and current_price < entry_price:
                                    new_tp = current_tp * (1 - atr_pct * 2.0)
                                    proposed_locked_sl = max(current_tp * 1.002, current_price * 1.003)
                                    if proposed_locked_sl < current_sl:
                                        locked_sl = proposed_locked_sl
                            
                            if new_tp:
                                old_tp_id = str(position.get('tp_order_id') or '')
                                old_sl_id = str(position.get('sl_order_id') or '')
                                close_side = 'sell' if direction == 'LONG' else 'buy'
                                
                                is_live = getattr(self, 'mode', 'demo') == 'live'
                                tp_success = True
                                
                                if is_live:
                                    new_tp_order = self.exchange.create_take_profit_market_order(
                                        position['symbol'], close_side,
                                        position['amount'], new_tp,
                                    )
                                    tp_success = bool(new_tp_order and (new_tp_order.get('id') or (new_tp_order.get('info') or {}).get('orderId')))
                                    new_tp_id = str((new_tp_order or {}).get('id') or (new_tp_order.get('info') or {}).get('orderId') or '')
                                else:
                                    new_tp_id = f"demo-tp-{int(now_ts*1000)}"

                                if tp_success:
                                    # Cập nhật Stop-Loss bảo hiểm trên sàn
                                    new_sl_id = old_sl_id
                                    if locked_sl and is_live:
                                        try:
                                            new_sl_order = self.exchange.create_stop_market_order(
                                                position['symbol'], close_side,
                                                position['amount'], locked_sl,
                                            )
                                            if new_sl_order:
                                                new_sl_id = str((new_sl_order or {}).get('id') or (new_sl_order.get('info') or {}).get('orderId') or '')
                                                if old_sl_id and new_sl_id != old_sl_id:
                                                    try:
                                                        self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                                    except Exception as e:
                                                        logger.error(f"Lỗi hủy SL cũ khi dời TP: {e}")
                                                        stale = position.setdefault('stale_sl_order_ids', [])
                                                        stale.append(old_sl_id)
                                        except Exception as e:
                                            logger.error(f"Lỗi đặt SL bảo hiểm khi dời TP: {e}")
                                    
                                    # Hủy TP cũ
                                    if old_tp_id and is_live:
                                        try:
                                            self.exchange.cancel_order(
                                                old_tp_id, position['symbol'],
                                                trigger=True, strict=True
                                            )
                                        except Exception as e:
                                            logger.error(f"Lỗi hủy TP cũ {old_tp_id}: {e}")
                                            stale = position.setdefault('stale_sl_order_ids', [])
                                            stale.append(old_tp_id)
                                            
                                    position['take_profit'] = new_tp
                                    position['tp_order_id'] = new_tp_id
                                    if locked_sl:
                                        position['stop_loss'] = locked_sl
                                        position['sl_order_id'] = new_sl_id
                                    position['last_tp_extend_time'] = now_ts
                                    self._save_state()

                                    est_tp_pnl = (new_tp - entry_price) * position['amount'] if direction == 'LONG' else (entry_price - new_tp) * position['amount']
                                    locked_pnl = ((locked_sl or current_sl) - entry_price) * position['amount'] if direction == 'LONG' else (entry_price - (locked_sl or current_sl)) * position['amount']
                                    quote_curr = self.config.get('trading', {}).get('base_currency', 'USDT')
                                    dir_txt = "tăng" if direction == "LONG" else "giảm"
                                    move_txt = "LÊN" if direction == "LONG" else "XUỐNG"
                                    
                                    logger.info(f"🚀 GỒNG SIÊU SÓNG THÀNH CÔNG: {position['symbol']} dời TP từ {current_tp:.6g} {move_txt} {new_tp:.6g}, khóa SL bảo hiểm ở {(locked_sl or current_sl):.6g}")
                                    self._notify_telegram(
                                        f"🚀 **[GỒNG SIÊU SÓNG - KHÓA BẢO HIỂM 100%]**\n"
                                        f"Đà {dir_txt} của {position['symbol']} đang rất mạnh (ADX={adx:.1f})!\n"
                                        f"🔹 **Dời Take-Profit {move_txt}:** {current_tp:.6g} ➡️ {new_tp:.6g} (Ước tính lãi chạm TP: {est_tp_pnl:+.4f} {quote_curr})\n"
                                        f"🛡️ **ĐỒNG THỜI KÉO STOP-LOSS:** {current_sl:.6g} ➡️ {(locked_sl or current_sl):.6g}\n"
                                        f"💎 **Khóa chặt lợi nhuận tối thiểu:** {locked_pnl:+.4f} {quote_curr}\n"
                                        f"👉 Nếu giá đảo chiều: Tự động chốt lời bảo vệ tiền ở {(locked_sl or current_sl):.6g}.\n"
                                        f"👉 Nếu tiếp tục bứt phá: Ăn trọn mục tiêu mới {new_tp:.6g}!"
                                    )
                    except Exception as e:
                        logger.error(f"Lỗi dời TP vật lý cho {position.get('symbol')}: {e}")
                
                is_tp_hit = False
                if direction == 'LONG' and current_price >= position['take_profit']:
                    is_tp_hit = True
                elif direction == 'SHORT' and current_price <= position['take_profit']:
                    is_tp_hit = True
                    
                if is_tp_hit or self.risk_manager.check_take_profit(position, current_price):
                    logger.info(
                        f"🎯 TAKE-PROFIT hit! {position['symbol']} "
                        f"@ {current_price:.6g} (TP: {position['take_profit']:.6g})"
                    )
                    self._close_position(position, current_price, close_reason="Chạm Take Profit")
                    continue

                # =========================================================================
                # BẢO VỆ ĐA TẦNG THEO THỜI GIAN & ĐỘNG LƯỢNG (MULTI-STAGE TIME RISK CASCADE V3.0)
                # Chống giam vốn & cấm tuyệt đối ôm lệnh lỗ chờ chết khi giá không bứt phá,
                # đồng thời phân biệt rõ Lệnh Chết Yểu (DOA: peak < +0.30%) và Lệnh Đang Có Sóng!
                # =========================================================================
                entry_price_chk = float(position.get('entry_price') or position.get('price', 0))
                pnl_pct_chk = 0.0
                if entry_price_chk > 0 and current_price > 0:
                    pnl_pct_chk = (current_price - entry_price_chk) / entry_price_chk if direction == 'LONG' else (entry_price_chk - current_price) / entry_price_chk

                # Tính toán đỉnh lợi nhuận (Peak Profit / MFE) đã đạt được từ lúc mở lệnh
                old_best_chk = position.get('trailing_best_price')
                try:
                    old_best_chk = float(old_best_chk) if old_best_chk is not None else None
                except (TypeError, ValueError, OverflowError):
                    old_best_chk = None
                if direction == 'LONG':
                    best_price_chk = max(entry_price_chk, current_price, old_best_chk or 0.0)
                    peak_profit_pct = (best_price_chk - entry_price_chk) / entry_price_chk if entry_price_chk > 0 else 0.0
                else:
                    valid_bests = [v for v in (entry_price_chk, current_price, old_best_chk) if v is not None and v > 0]
                    best_price_chk = min(valid_bests) if valid_bests else entry_price_chk
                    peak_profit_pct = (entry_price_chk - best_price_chk) / entry_price_chk if entry_price_chk > 0 else 0.0
                position['trailing_best_price'] = best_price_chk

                held_minutes_chk = 0.0
                raw_ts_chk = position.get('timestamp')
                if raw_ts_chk:
                    try:
                        if isinstance(raw_ts_chk, str):
                            pos_dt_chk = datetime.fromisoformat(raw_ts_chk)
                            held_minutes_chk = (datetime.now() - pos_dt_chk).total_seconds() / 60.0
                        elif isinstance(raw_ts_chk, (int, float)):
                            pos_secs_chk = raw_ts_chk / 1000.0 if raw_ts_chk > 1e11 else float(raw_ts_chk)
                            held_minutes_chk = (time.time() - pos_secs_chk) / 60.0
                    except Exception:
                        held_minutes_chk = 0.0

                risk_metrics = self._adaptive_trailing_metrics(position, current_price)
                ema20_lvl = risk_metrics.get('ema20')
                is_adverse_ema = True
                if ema20_lvl is not None and math.isfinite(ema20_lvl):
                    is_adverse_ema = (current_price < ema20_lvl) if direction == 'LONG' else (current_price > ema20_lvl)

                is_live_fut = (self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures')
                pos_amount = float(position.get('amount') or 0)
                curr_sl_val = float(position.get('stop_loss') or 0)
                close_side = 'sell' if direction == 'LONG' else 'buy'

                # --- 1. THỜI GIAN THỞ (15 PHÚT) VÀ CẮT LỖ SỚM TRÁNH ÔM BOM (DEAD-ON-ARRIVAL) ---
                if held_minutes_chk >= 15.0 and pnl_pct_chk <= -0.012 and peak_profit_pct < 0.0030 and not position.get('partial_tp_done'):
                    logger.warning(
                        f"🛑 [CẮT LỖ SỚM - 15 PHÚT DOA] {position['symbol']} ({direction}) "
                        f"ngâm 15m nến đóng âm sâu ({pnl_pct_chk*100:+.2f}% <= -1.2%) không có đỉnh sóng (Peak={peak_profit_pct*100:+.2f}% < +0.30%)! Đóng Market ngay bảo toàn vốn."
                    )
                    self._notify_telegram(
                        f"🛑 **[CẮT LỖ SỚM - 15 PHÚT HẾT HẠN THỞ]**\n"
                        f"Cặp: **{position['symbol']}** ({direction})\n"
                        f"Vị thế sau 15 phút không sinh lời mà lỗ sâu (`{pnl_pct_chk*100:+.2f}%`).\n"
                        f"🚪 **Chủ động cắt lỗ sớm** tránh ôm bom rủi ro lớn hơn."
                    )
                    self._close_position(position, current_price, close_reason=f"Cắt lỗ sớm 15m DOA (PnL: {pnl_pct_chk*100:+.2f}%)")
                    continue

                # --- 2. CO HẸP STOP LOSS GIAI ĐOẠN 1 (15 PHÚT): SIẾT TRẦN SL TỪ -3.5% VỀ -1.8% CHO LỆNH ĐI NGANG ---
                if held_minutes_chk >= 15.0 and not position.get('time_sl_compressed_15m'):
                    position['time_sl_compressed_15m'] = True
                    proposed_sl_15m = entry_price_chk * (1.0 - 0.018) if direction == 'LONG' else entry_price_chk * (1.0 + 0.018)
                    improves_15m = (proposed_sl_15m > curr_sl_val) if direction == 'LONG' else (proposed_sl_15m < curr_sl_val)
                    if improves_15m and pos_amount > 0:
                        is_breached_15m = (current_price <= proposed_sl_15m) if direction == 'LONG' else (current_price >= proposed_sl_15m)
                        if is_breached_15m:
                            logger.warning(f"🛡️ [CO HẸP SL 15M] Giá đã chạm ngưỡng siết -1.8% ({proposed_sl_15m:.6g}). Đóng Market!")
                            self._close_position(position, current_price, close_reason="🛡️ Co hẹp SL 15m chạm giá")
                            continue
                        old_sl_id = str(position.get('sl_order_id') or '')
                        sl_confirmed = not is_live_fut
                        if is_live_fut:
                            try:
                                new_sl_order = self.exchange.create_stop_market_order(position['symbol'], close_side, pos_amount, proposed_sl_15m)
                                new_info = (new_sl_order or {}).get('info') or {}
                                new_sl_id = str((new_sl_order or {}).get('id') or new_info.get('algoId') or new_info.get('orderId') or '')
                                if new_sl_id:
                                    sl_confirmed = True
                                    if old_sl_id and old_sl_id != new_sl_id:
                                        try:
                                            self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                        except Exception:
                                            position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                    position['sl_order_id'] = new_sl_id
                                else:
                                    logger.error(f"Binance chưa xác nhận SL 15m mới cho {position['symbol']}; giữ SL cũ.")
                            except Exception as e:
                                logger.error(f"Lỗi siết SL 15m cho {position['symbol']}: {e}")
                        if sl_confirmed:
                            position['stop_loss'] = proposed_sl_15m
                            curr_sl_val = proposed_sl_15m
                            self._save_state()
                            logger.info(f"🛡️ [CO HẸP SL 15M] {position['symbol']} ({direction}) đi ngang 15m, siết SL về -1.8% ({proposed_sl_15m:.6g}) cắt giảm 50% rủi ro.")

                # --- 3. CO HẸP STOP LOSS GIAI ĐOẠN 2 & CẮT Ứ ĐỘNG DOA (25 PHÚT): ---
                # Nếu lệnh chưa từng đạt được +0.30% (Peak < +0.30% -> 100% lệnh DOA không có sóng) và đang âm <= -0.60% kèm xu hướng nghịch EMA20 -> Cắt sớm!
                # Nếu lệnh đã từng có sóng (Peak >= +0.30%, ví dụ BR/USDT đạt +0.60% rồi chỉnh nhẹ) -> Chỉ siết SL về -1.00% để gồng tiếp!
                if held_minutes_chk >= 25.0:
                    if pnl_pct_chk <= -0.006 and peak_profit_pct < 0.0030 and is_adverse_ema and not position.get('partial_tp_done'):
                        logger.warning(
                            f"🛑 [CẮT LỖ SỚM - 25 PHÚT Ứ ĐỘNG DOA] {position['symbol']} ({direction}) "
                            f"ngâm 25m không có lực bứt phá (Peak={peak_profit_pct*100:+.2f}% < +0.30%, PnL: {pnl_pct_chk*100:+.2f}% <= -0.6%, Adverse EMA)! Đóng Market giải phóng vốn."
                        )
                        self._notify_telegram(
                            f"🛑 **[CẮT LỖ SỚM - 25 PHÚT Ứ ĐỘNG]**\n"
                            f"Cặp: **{position['symbol']}** ({direction})\n"
                            f"Vị thế đi ngang 25 phút không có dòng tiền đẩy (Đỉnh: `{peak_profit_pct*100:+.2f}%`, Hiện tại: `{pnl_pct_chk*100:+.2f}%`).\n"
                            f"🚪 **Chủ động đóng Market giải phóng vốn.**"
                        )
                        self._close_position(position, current_price, close_reason=f"Cắt lỗ sớm 25m ứ đọng (PnL: {pnl_pct_chk*100:+.2f}%)")
                        continue
                    elif not position.get('time_sl_compressed_25m'):
                        position['time_sl_compressed_25m'] = True
                        proposed_sl_25m = entry_price_chk * (1.0 - 0.010) if direction == 'LONG' else entry_price_chk * (1.0 + 0.010)
                        improves_25m = (proposed_sl_25m > curr_sl_val) if direction == 'LONG' else (proposed_sl_25m < curr_sl_val)
                        if improves_25m and pos_amount > 0:
                            is_breached_25m = (current_price <= proposed_sl_25m) if direction == 'LONG' else (current_price >= proposed_sl_25m)
                            if is_breached_25m:
                                logger.warning(f"🛡️ [CO HẸP SL 25M] Giá đã chạm ngưỡng siết -1.0% ({proposed_sl_25m:.6g}). Đóng Market!")
                                self._close_position(position, current_price, close_reason="🛡️ Co hẹp SL 25m chạm giá")
                                continue
                            old_sl_id = str(position.get('sl_order_id') or '')
                            sl_confirmed = not is_live_fut
                            if is_live_fut:
                                try:
                                    new_sl_order = self.exchange.create_stop_market_order(position['symbol'], close_side, pos_amount, proposed_sl_25m)
                                    new_info = (new_sl_order or {}).get('info') or {}
                                    new_sl_id = str((new_sl_order or {}).get('id') or new_info.get('algoId') or new_info.get('orderId') or '')
                                    if new_sl_id:
                                        sl_confirmed = True
                                        if old_sl_id and old_sl_id != new_sl_id:
                                            try:
                                                self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                            except Exception:
                                                position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                        position['sl_order_id'] = new_sl_id
                                    else:
                                        logger.error(f"Binance chưa xác nhận SL 25m mới cho {position['symbol']}; giữ SL cũ.")
                                except Exception as e:
                                    logger.error(f"Lỗi siết SL 25m cho {position['symbol']}: {e}")
                            if sl_confirmed:
                                position['stop_loss'] = proposed_sl_25m
                                curr_sl_val = proposed_sl_25m
                                self._save_state()
                                logger.info(f"🛡️ [CO HẸP SL 25M] {position['symbol']} ({direction}) đi ngang 25m, siết SL về -1.0% ({proposed_sl_25m:.6g}).")

                # --- 4. HẠN CHÓT THỜI GIAN (35 PHÚT): CẤM NGÂM VỐN LỆNH CHẾT YỂU (DOA) HOẶC SIẾT SL VỀ -0.55% ---
                if held_minutes_chk >= 35.0 and pnl_pct_chk <= 0.0 and not position.get('partial_tp_done'):
                    if peak_profit_pct < 0.0035 and is_adverse_ema:
                        logger.warning(
                            f"🛑 [THOÁT LỆNH QUÁ HẠN 35 PHÚT DOA] {position['symbol']} ({direction}) "
                            f"đã ngâm {held_minutes_chk:.0f} phút mà không sinh lời (Peak={peak_profit_pct*100:+.2f}% < +0.35%, PnL: {pnl_pct_chk*100:+.2f}%)! Đóng Market dứt khoát."
                        )
                        self._notify_telegram(
                            f"🛑 **[THOÁT LỆNH QUÁ HẠN 35 PHÚT]**\n"
                            f"Cặp: **{position['symbol']}** ({direction})\n"
                            f"Vị thế đã ngâm **{held_minutes_chk:.0f} phút** nhưng không có sóng (Đỉnh: `{peak_profit_pct*100:+.2f}%`, Hiện tại: `{pnl_pct_chk*100:+.2f}%`).\n"
                            f"🚪 **Chủ động đóng Market giải phóng vốn và slot lệnh!**"
                        )
                        self._close_position(position, current_price, close_reason=f"Thoát quá hạn 35m không lãi (PnL {pnl_pct_chk*100:+.2f}%)")
                        continue
                    elif not position.get('time_sl_compressed_35m'):
                        position['time_sl_compressed_35m'] = True
                        proposed_sl_35m = entry_price_chk * (1.0 - 0.0055) if direction == 'LONG' else entry_price_chk * (1.0 + 0.0055)
                        improves_35m = (proposed_sl_35m > curr_sl_val) if direction == 'LONG' else (proposed_sl_35m < curr_sl_val)
                        if improves_35m and pos_amount > 0:
                            is_breached_35m = (current_price <= proposed_sl_35m) if direction == 'LONG' else (current_price >= proposed_sl_35m)
                            if is_breached_35m:
                                logger.warning(f"🛡️ [CO HẸP SL 35M] Giá đã chạm ngưỡng siết -0.55% ({proposed_sl_35m:.6g}). Đóng Market!")
                                self._close_position(position, current_price, close_reason="🛡️ Co hẹp SL 35m chạm giá")
                                continue
                            old_sl_id = str(position.get('sl_order_id') or '')
                            sl_confirmed = not is_live_fut
                            if is_live_fut:
                                try:
                                    new_sl_order = self.exchange.create_stop_market_order(position['symbol'], close_side, pos_amount, proposed_sl_35m)
                                    new_info = (new_sl_order or {}).get('info') or {}
                                    new_sl_id = str((new_sl_order or {}).get('id') or new_info.get('algoId') or new_info.get('orderId') or '')
                                    if new_sl_id:
                                        sl_confirmed = True
                                        if old_sl_id and old_sl_id != new_sl_id:
                                            try:
                                                self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                            except Exception:
                                                position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                        position['sl_order_id'] = new_sl_id
                                    else:
                                        logger.error(f"Binance chưa xác nhận SL 35m mới cho {position['symbol']}; giữ SL cũ.")
                                except Exception as e:
                                    logger.error(f"Lỗi siết SL 35m cho {position['symbol']}: {e}")
                            if sl_confirmed:
                                position['stop_loss'] = proposed_sl_35m
                                curr_sl_val = proposed_sl_35m
                                self._save_state()
                                logger.info(f"🛡️ [CO HẸP SL 35M] {position['symbol']} ({direction}) ngâm 35m, siết SL về -0.55% ({proposed_sl_35m:.6g}).")

                # --- 5. HẠN CHÓT 60 PHÚT (4 NẾN 15M): NẾU ĐANG CÓ LÃI > 0 BẮT BUỘC KHÓA HÒA VỐN ---
                if held_minutes_chk >= 60.0 and not position.get('time_be_locked_60m'):
                    position['time_be_locked_60m'] = True
                    if pnl_pct_chk > 0.0005:
                        proposed_sl_60m = entry_price_chk * 1.0012 if direction == 'LONG' else entry_price_chk * 0.9988
                        improves_60m = (proposed_sl_60m > curr_sl_val) if direction == 'LONG' else (proposed_sl_60m < curr_sl_val)
                        if improves_60m and pos_amount > 0:
                            old_sl_id = str(position.get('sl_order_id') or '')
                            if is_live_fut:
                                try:
                                    new_sl_order = self.exchange.create_stop_market_order(position['symbol'], close_side, pos_amount, proposed_sl_60m)
                                    new_info = (new_sl_order or {}).get('info') or {}
                                    new_sl_id = str((new_sl_order or {}).get('id') or new_info.get('algoId') or new_info.get('orderId') or '')
                                    if new_sl_id and old_sl_id and old_sl_id != new_sl_id:
                                        try:
                                            self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                        except Exception:
                                            pass
                                    if new_sl_id:
                                        position['sl_order_id'] = new_sl_id
                                except Exception as e:
                                    logger.error(f"Lỗi khóa BE 60m cho {position['symbol']}: {e}")
                            position['stop_loss'] = proposed_sl_60m
                            curr_sl_val = proposed_sl_60m
                            self._save_state()
                            logger.info(f"🛡️ [KHÓA HÒA VỐN 60M] {position['symbol']} ({direction}) ngâm 60m có lãi (+{pnl_pct_chk*100:.2f}%), khóa SL bảo vệ ở Entry ({proposed_sl_60m:.6g}).")

                # --- 6. HẠN CHÓT 120 PHÚT (8 NẾN 15M): THOÁT LỆNH ĐỌNG VỐN NẾU THỊ TRƯỜNG ĐI NGANG RU NGỦ ---
                if held_minutes_chk >= 120.0 and not position.get('partial_tp_done'):
                    logger.warning(
                        f"🛑 [THOÁT LỆNH ĐỌNG VỐN 120 PHÚT] {position['symbol']} ({direction}) "
                        f"đã ngâm 120 phút (8 nến 15m) mà không tới TP (PnL: {pnl_pct_chk*100:+.2f}%)! Đóng Market dứt khoát giải phóng slot."
                    )
                    self._notify_telegram(
                        f"🛑 **[THOÁT LỆNH ĐỌNG VỐN 120 PHÚT]**\n"
                        f"Cặp: **{position['symbol']}** ({direction})\n"
                        f"Vị thế đã ngâm **{held_minutes_chk:.0f} phút** (8 nến 15m) không có xung lực phá cản (PnL: `{pnl_pct_chk*100:+.2f}%`).\n"
                        f"🚪 **Chủ động đóng Market giải phóng vốn và hạn mức lệnh!**"
                    )
                    self._close_position(position, current_price, close_reason=f"Thoát đọng vốn 120m giải phóng slot (PnL: {pnl_pct_chk*100:+.2f}%)")
                    continue

                # Adaptive trailing: ATR sets the breathing room, ADX adjusts it
                # to the symbol's trend regime, and the stop activates only after
                # it can protect estimated net profit after costs.
                if self.config.get('risk', {}).get('use_trailing_stop', False):
                    try:
                        metrics = self._adaptive_trailing_metrics(position, current_price)
                        trail_pct = float(metrics['distance_pct'])
                        entry_price = float(position.get('entry_price') or 0)
                        current_sl = float(position.get('stop_loss') or 0)
                        if entry_price <= 0 or current_sl <= 0:
                            continue

                        old_best = position.get('trailing_best_price')
                        try:
                            old_best = float(old_best) if old_best is not None else None
                        except (TypeError, ValueError, OverflowError):
                            old_best = None
                        if direction == 'LONG':
                            best_price = max(entry_price, current_price, old_best or 0)
                        else:
                            best_price = min(
                                value for value in (entry_price, current_price, old_best)
                                if value is not None and value > 0
                            )
                        best_changed = old_best is None or abs(best_price - old_best) > max(entry_price * 1e-8, 1e-12)

                        position['trailing_best_price'] = best_price
                        position['trailing_distance_pct'] = trail_pct
                        position['trailing_atr_pct'] = metrics.get('atr_pct')
                        position['trailing_adx'] = metrics.get('adx')
                        position['trailing_regime'] = metrics.get('regime', 'fallback')
                        profile = metrics.get('profile') or self._get_asset_adaptive_trailing_profile(position.get('symbol', ''))
                        net_breakeven = self._trailing_net_breakeven(position)
                        try:
                            lock_profit_pct = float(
                                self.config.get('risk', {}).get('trailing_min_lock_profit_pct', 0.001)
                            )
                        except (TypeError, ValueError, OverflowError):
                            lock_profit_pct = 0.001
                        lock_profit_pct = min(0.05, max(0.0, lock_profit_pct))
                        # CÔNG THỨC TOÁN HỌC KHÓA HÒA VỐN THÍCH ỨNG ATR (ATR-ADAPTIVE BREAKEVEN TRIGGER):
                        # Tự động co giãn theo 0.75 * ATR (khoảng 0.22% đến 0.45%), đủ bù 2 đầu phí sàn + buffer
                        raw_atr_be = metrics.get('atr_pct')
                        atr_pct_be = float(raw_atr_be) if (raw_atr_be is not None and math.isfinite(float(raw_atr_be)) and float(raw_atr_be) > 0) else 0.012
                        breakeven_trigger_pct = min(0.0045, max(0.0022, 0.75 * atr_pct_be))
                        position['trailing_net_breakeven'] = net_breakeven

                        initial_sl = float(position.get('initial_sl', position.get('stop_loss', 0)))
                        if initial_sl == 0: initial_sl = current_sl
                        
                        r_dist = abs(entry_price - initial_sl)
                        if r_dist <= 0: r_dist = entry_price * 0.01

                        current_profit_pct = (current_price - entry_price) / entry_price if direction == 'LONG' else (entry_price - current_price) / entry_price
                        old_sustained = float(position.get('max_sustained_profit_pct') or 0.0)
                        max_sustained_profit_pct = max(old_sustained, current_profit_pct)
                        # CÔNG THỨC TOÁN HỌC VI MÔ THÍCH ỨNG CHO CHỐT LỜI 50% TIỀN TƯƠI (MICROSCOPIC ADAPTIVE PARTIAL TP)
                        profile = metrics.get('profile') or self._get_asset_adaptive_trailing_profile(position.get('symbol', ''))
                        if self.config.get('risk', {}).get('enable_micro_adaptive_partial_tp', True):
                            raw_atr = metrics.get('atr_pct')
                            atr_pct_val = float(raw_atr) if (raw_atr is not None and math.isfinite(float(raw_atr)) and float(raw_atr) > 0) else 0.01
                            regime_val = metrics.get('regime', 'ranging')
                            regime_mult = 1.15 if regime_val == 'trend_favorable' else (0.85 if regime_val == 'trend_adverse' else 1.00)
                            micro_k = float(self.config.get('risk', {}).get('partial_tp_atr_multiplier', 0.88))
                            min_ptp = float(profile.get('partial_tp_min', self.config.get('risk', {}).get('partial_tp_min_pct', 0.0075)))
                            max_ptp = float(profile.get('partial_tp_max', self.config.get('risk', {}).get('partial_tp_max_pct', 0.0135)))
                            partial_tp_trigger = min(max_ptp, max(min_ptp, atr_pct_val * micro_k * regime_mult))
                        else:
                            partial_tp_trigger = float(profile.get('partial_tp_trigger', self.config.get('risk', {}).get('partial_tp_trigger_pct', 0.0105)))
                        position['dynamic_partial_tp_trigger'] = partial_tp_trigger

                        held_minutes = 0.0
                        pos_timestamp_str = position.get('timestamp')
                        try:
                            if pos_timestamp_str:
                                pos_dt = datetime.fromisoformat(pos_timestamp_str)
                                held_minutes = (datetime.now() - pos_dt).total_seconds() / 60.0
                        except Exception:
                            pass

                        # =========================================================================
                        # DYNAMIC ADAPTIVE STAGING ENGINE: CẮT LỖ GIẢM TẢI ĐA NẤC TỰ ĐỘNG THÍCH ỨNG
                        # (DYNAMIC ADAPTIVE DE-RISKING SCALE-OUT)
                        # =========================================================================
                        atr_val_pct_loss = float(metrics.get('atr_pct') or 0.012)
                        staged_sl_trigger = min(0.0130, max(0.0080, 0.65 * atr_val_pct_loss))
                        current_loss_pct = (entry_price - current_price) / entry_price if direction == 'LONG' else (current_price - entry_price) / entry_price
                        
                        total_sl_stages = self._calc_adaptive_stages(position, current_price)
                        position['sl_stages_total'] = total_sl_stages
                        sl_stage_completed = int(position.get('sl_stage_completed') or 0)
                        
                        # Bảng hệ số khoảng cách nấc kích hoạt theo từng cấp
                        stage_mult_table = {
                            1: [],
                            2: [1.0],
                            3: [1.0, 1.8],
                            4: [1.0, 1.7, 2.4],
                            5: [0.9, 1.5, 2.1, 2.7]
                        }
                        stage_mults = stage_mult_table.get(total_sl_stages, [1.0])
                        
                        if total_sl_stages > 1 and not position.get('partial_sl_done') and not position.get('partial_tp_done'):
                            next_stage = sl_stage_completed + 1
                            if next_stage <= len(stage_mults):
                                target_threshold = stage_mults[next_stage - 1] * staged_sl_trigger
                                if current_loss_pct >= (target_threshold - 1e-6) and held_minutes >= 1.0:
                                    # =========================================================================
                                    # TELEMETRY GATE ENGINE: ĐO LƯỜNG VOLUME XẢ & TỐC ĐỘ RƠI TẠI NẤC 1
                                    # =========================================================================
                                    rvol = float(metrics.get('rvol') or 1.0)
                                    is_whale_dump = (rvol >= 1.6 or held_minutes <= 15.0)

                                    if next_stage == 1 and is_whale_dump:
                                        logger.warning(
                                            f"🚨 [TELEMETRY GATE: DUMP KHẨN CẤP] {position['symbol']} ({direction}) chạm Nấc 1 (-{current_loss_pct*100:.2f}%) "
                                            f"với RVol={rvol:.2f} >= 1.6x hoặc gãy nhanh ({held_minutes:.1f}m <= 15m). "
                                            f"Đóng 100% vị thế khẩn cấp để ngăn chặn rơi sâu 1.5 ATR!"
                                        )
                                        self._notify_telegram(
                                            f"🚨 **[TELEMETRY GATE: DUMP KHẨN CẤP]**\n"
                                            f"• Cặp: `{position['symbol']}` ({direction})\n"
                                            f"• Lỗ hiện tại: `-{current_loss_pct*100:.2f}%` (Chạm Nấc 1: 0.65 ATR)\n"
                                            f"• Tín hiệu: Volume xả `{rvol:.2f}x` trung bình / Thời gian giữ `{held_minutes:.1f} phút`\n"
                                            f"• Quyết định: **ĐÓNG HẲN 100% VỊ THẾ** bảo vệ an toàn tài khoản!"
                                        )
                                        self._close_position_locked(position, current_price, 'telemetry_emergency_dump')
                                        continue

                                    if 'initial_amount' not in position:
                                        position['initial_amount'] = float(position.get('amount') or 0)
                                    init_amt = float(position['initial_amount'])
                                    curr_amt = float(position.get('amount') or 0)
                                    chunk_amt = init_amt / float(total_sl_stages)
                                    chunk_amt = min(curr_amt, chunk_amt)
                                    
                                    est_chunk_notional = chunk_amt * current_price
                                    rem_after_cut = max(0.0, curr_amt - chunk_amt)
                                    est_rem_notional = rem_after_cut * current_price
                                    is_live_fut = (self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures')
                                    
                                    # Kiểm tra an toàn sàn Binance: chunk và phần còn lại (nếu chưa phải nấc chót) phải >= 5.00 USDT
                                    if is_live_fut and (est_chunk_notional < 5.00 or (next_stage < total_sl_stages and est_rem_notional < 5.00)):
                                        logger.info(
                                            f"Vị thế {position['symbol']} nấc {next_stage}/{total_sl_stages} "
                                            f"có notional ({est_chunk_notional:.2f} USDT) hoặc phần còn lại ({est_rem_notional:.2f} USDT) < 5 USDT sàn; "
                                            f"dừng cắt từng phần và giữ SL cứng bảo vệ."
                                        )
                                        position['partial_sl_done'] = True
                                    else:
                                        partial_sl_ok = False
                                        filled_amt = chunk_amt
                                        if is_live_fut:
                                            try:
                                                p_order = self.exchange.close_futures_position(position['symbol'], direction, chunk_amt)
                                                if p_order and (p_order.get('id') or (p_order.get('info') or {}).get('orderId')):
                                                    filled_amt = float(p_order.get('filled') or p_order.get('amount') or chunk_amt)
                                                    partial_sl_ok = True
                                                else:
                                                    logger.warning(f"Lệnh cắt giảm tải nấc {next_stage}/{total_sl_stages} cho {position['symbol']} không trả về ID: {p_order}")
                                            except Exception as pe:
                                                logger.error(f"Lỗi gửi lệnh cắt giảm tải nấc {next_stage}/{total_sl_stages} cho {position['symbol']}: {pe}")
                                        else:
                                            partial_sl_ok = True
                                            
                                        if partial_sl_ok:
                                            if 'initial_cost' not in position:
                                                position['initial_cost'] = float(position.get('cost') or 0)
                                            rem_amt = max(0.0, curr_amt - filled_amt)
                                            position['amount'] = rem_amt
                                            init_amt_val = float(position.get('initial_amount') or curr_amt)
                                            if init_amt_val > 0:
                                                position['cost'] = float(position['initial_cost']) * (rem_amt / init_amt_val)
                                            position['sl_stage_completed'] = next_stage
                                            if next_stage >= total_sl_stages - 1 or rem_amt <= 0:
                                                position['partial_sl_done'] = True
                                            position['partial_sl_price'] = current_price
                                            part_loss = (current_price - entry_price) * filled_amt if direction == 'LONG' else (entry_price - current_price) * filled_amt
                                            position['partial_sl_pnl'] = float(position.get('partial_sl_pnl', 0.0)) + part_loss

                                            # CHOKE SL: Siết Hard SL của khối lượng còn lại từ 1.5 ATR về 1.0 ATR để đón nhịp rút râu hòa vốn
                                            choke_sl_dist = 1.00 * atr_val_pct_loss * entry_price
                                            if direction == 'LONG':
                                                choke_sl_price = entry_price - choke_sl_dist
                                                if choke_sl_price > float(position.get('stop_loss') or 0):
                                                    position['stop_loss'] = choke_sl_price
                                            else:
                                                choke_sl_price = entry_price + choke_sl_dist
                                                if float(position.get('stop_loss') or 999999) > choke_sl_price:
                                                    position['stop_loss'] = choke_sl_price
                                            
                                            # Cập nhật lại Hard SL trên Binance cho khối lượng còn lại
                                            old_sl_id = str(position.get('sl_order_id') or '')
                                            if is_live_fut and position.get('stop_loss') and rem_amt > 0:
                                                try:
                                                    close_side = 'sell' if direction == 'LONG' else 'buy'
                                                    new_sl = self.exchange.create_stop_market_order(
                                                        position['symbol'], close_side, rem_amt, float(position['stop_loss'])
                                                    )
                                                    new_sl_id = str((new_sl or {}).get('id') or ((new_sl or {}).get('info') or {}).get('orderId') or '')
                                                    if new_sl_id:
                                                        position['sl_order_id'] = new_sl_id
                                                        if old_sl_id and old_sl_id != new_sl_id:
                                                            try:
                                                                self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=False)
                                                            except Exception:
                                                                pass
                                                    else:
                                                        logger.warning(f"Binance chưa xác nhận SL mới cho phần còn lại của {position['symbol']}; giữ SL cũ {old_sl_id}.")
                                                except Exception as e:
                                                    logger.error(f"Lỗi cập nhật lại SL cho phần còn lại của {position['symbol']}: {e}")
                                            
                                            self._save_state()
                                            logger.warning(
                                                f"🛡️ [CẮT LỖ GIẢM TẢI NẤC {next_stage}/{total_sl_stages}] {position['symbol']} ({direction}) đi ngược -{current_loss_pct*100:.2f}%, "
                                                f"đã cắt {filled_amt:.6g} coin để bảo vệ vốn! Thiệt hại nấc này: {part_loss:.4f} USDT. Còn lại {rem_amt:.6g} coin."
                                            )
                                            self._notify_telegram(
                                                f"🛡️ **[CẮT LỖ GIẢM TẢI NẤC {next_stage}/{total_sl_stages}]**\n"
                                                f"Cặp: **{position['symbol']}** ({direction})\n"
                                                f"Vị thế đi ngược hướng -{current_loss_pct*100:.2f}% (ngưỡng kích hoạt: `{(target_threshold*100):.2f}%`).\n"
                                                f"✂️ **Đã chủ động cắt nấc {next_stage}/{total_sl_stages}:** `{filled_amt:.6g}` coin tại giá `{current_price:.6g}`.\n"
                                                f"📉 **Thiệt hại nấc này:** `{part_loss:.4f} USDT`\n"
                                                f"🛡️ **Khối lượng còn lại ({rem_amt:.6g} coin):** Đã siết Hard SL về 1.0 ATR (`{position['stop_loss']:.6g}`), sẵn sàng đón 44.3% nhịp rút râu hồi phục về Hòa Vốn!"
                                            )

                        # CẤP 2 NÂNG CẤP V3.0: CHỐT LỜI TIỀN TƯƠI 50% (TRUE PARTIAL TAKE PROFIT) KHI LÃI THỰC TẾ >= +1.10%
                        if current_profit_pct >= (partial_tp_trigger - 1e-6) and not position.get('partial_tp_done'):
                            full_amt = float(position.get('amount') or 0)
                            half_amt = full_amt * 0.5
                            est_notional = half_amt * current_price
                            is_live_fut = (self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures')

                            if is_live_fut and est_notional < 5.0:
                                logger.info(
                                    f"Vị thế {position['symbol']} có 50% notional ({est_notional:.2f} USDT) < 5 USDT tối thiểu sàn; "
                                    f"bỏ qua lệnh đóng 50% và chuyển sang nâng SL bảo vệ lãi."
                                )
                                position['partial_tp_done'] = True
                            else:
                                partial_ok = False
                                filled_amt = half_amt
                                if is_live_fut:
                                    try:
                                        p_order = self.exchange.close_futures_position(position['symbol'], direction, half_amt)
                                        if p_order and (p_order.get('id') or (p_order.get('info') or {}).get('orderId')):
                                            filled_amt = float(p_order.get('filled') or p_order.get('amount') or half_amt)
                                            partial_ok = True
                                        else:
                                            logger.warning(f"Lệnh chốt lời 50% cho {position['symbol']} không trả về ID: {p_order}")
                                    except Exception as pe:
                                        logger.error(f"Lỗi gửi lệnh chốt lời 50% cho {position['symbol']}: {pe}")
                                else:
                                    partial_ok = True

                                if partial_ok:
                                    if 'initial_amount' not in position:
                                        position['initial_amount'] = full_amt
                                    if 'initial_cost' not in position:
                                        position['initial_cost'] = float(position.get('cost') or 0)
                                    rem_amt = max(0.0, full_amt - filled_amt)
                                    position['amount'] = rem_amt
                                    init_amt_val = float(position.get('initial_amount') or full_amt)
                                    if init_amt_val > 0:
                                        position['cost'] = float(position['initial_cost']) * (rem_amt / init_amt_val)
                                    position['partial_tp_done'] = True
                                    position['partial_tp_price'] = current_price
                                    part_pnl = (current_price - entry_price) * filled_amt if direction == 'LONG' else (entry_price - current_price) * filled_amt
                                    position['partial_tp_pnl'] = part_pnl
                                    position['_force_sl_update'] = True

                                    if self.mode != 'live':
                                        self.balance += part_pnl

                                    old_tp_id = str(position.get('tp_order_id') or '')
                                    if is_live_fut and old_tp_id:
                                        try:
                                            self.exchange.cancel_order(old_tp_id, position['symbol'], trigger=True, strict=False)
                                            if position.get('take_profit'):
                                                close_side = 'sell' if direction == 'LONG' else 'buy'
                                                new_tp = self.exchange.create_take_profit_market_order(
                                                    position['symbol'], close_side, rem_amt, float(position['take_profit'])
                                                )
                                                position['tp_order_id'] = str((new_tp or {}).get('id') or ((new_tp or {}).get('info') or {}).get('orderId') or '')
                                        except Exception as tpe:
                                            logger.warning(f"Không thể đặt lại TP sàn cho phần còn lại của {position['symbol']}: {tpe}")

                                    self._save_state()
                                    logger.info(
                                        f"🎯 [CHỐT LỜI 50% TIỀN TƯƠI] {position['symbol']} ({direction}) tại {current_price:.6g} (+{current_profit_pct*100:.2f}%), "
                                        f"bỏ túi ví +{part_pnl:.4f} USDT! Còn lại {rem_amt:.6g} tiếp tục Trailing gồng sóng."
                                    )
                                    self._notify_telegram(
                                        f"🎯 **[CHỐT LỜI 50% TIỀN TƯƠI]**\n"
                                        f"Cặp: **{position['symbol']}** ({direction})\n"
                                        f"Đã chốt 50% khối lượng (`{filled_amt:.6g}` coin) tại giá `{current_price:.6g}` (+`{current_profit_pct*100:.2f}%`).\n"
                                        f"💰 **Lợi nhuận bỏ túi ví:** `+{part_pnl:.4f} USDT`\n"
                                        f"🛡️ **50% còn lại ({rem_amt:.6g} coin):** Đang kích hoạt Trailing Stop bám sát đỉnh để gồng trọn siêu sóng x2, x3!"
                                    )

                        choke_enabled = self.config.get('risk', {}).get('choke_trailing_enabled', True)
                        choke_trigger = float(profile.get('choke_trigger', self.config.get('risk', {}).get('choke_trailing_trigger_pct', 0.018)))
                        choke_ratio = float(profile.get('choke_ratio', self.config.get('risk', {}).get('choke_trailing_lock_ratio', 0.70)))

                        if direction == 'LONG':
                            net_be_floor = net_breakeven * (1 + lock_profit_pct)
                            profit_r = (best_price - entry_price) / r_dist
                            profit_pct = (best_price - entry_price) / entry_price if entry_price > 0 else 0
                            atr_val_pct = float(metrics.get('atr_pct') or 0.012)
                            partial_done = bool(position.get('partial_tp_done', False))
                            is_super_wave = (profit_pct >= 0.025) or (max_sustained_profit_pct >= 0.0185)
                            
                            # 3 CẤP ĐỘ BẢO VỆ VỐN & KHÓA LÃI THÔNG MINH V3.0:
                            is_breakeven_ready = (
                                (current_profit_pct >= (breakeven_trigger_pct - 1e-6))
                                or (profit_pct >= breakeven_trigger_pct)
                                or partial_done
                            )
                            if partial_done and held_minutes < 15.0 and not is_super_wave:
                                # Trong 15p đầu sau khi đã chốt 50% tiền tươi (+1.10%), đặt sàn bảo vệ Runner có đệm bù phí sàn (+0.12%)
                                breakeven_sl = entry_price * 1.0012
                            elif is_breakeven_ready:
                                breakeven_sl = net_be_floor
                            else:
                                breakeven_sl = 0
                            
                            # Cấp 2: KHÓA LÃI TỪNG PHẦN (Partial Profit Lock) & RUNNER BREATHING FLOOR
                            partial_lock_sl = 0
                            if partial_done:
                                if is_super_wave:
                                    partial_lock_sl = entry_price * 1.0110
                                elif profit_pct >= 0.018 and held_minutes >= 15.0:
                                    partial_lock_sl = entry_price * 1.0068
                                elif held_minutes >= 15.0:
                                    partial_lock_sl = max(net_be_floor, entry_price * 1.0035)
                                else:
                                    partial_lock_sl = entry_price * 1.0012
                            elif is_super_wave:
                                partial_lock_sl = entry_price * 1.0110
                            
                            # Cấp 3: KHÓA LÃI ĐẬM & TRAILING THEO ĐỈNH (High Profit Trailing)
                            is_trailing_ready = is_super_wave and ((profit_pct >= 0.025) or (profit_r >= 1.5))
                            trailing_lock_sl = entry_price * 1.012 if is_trailing_ready else 0
                            dynamic_r_sl = net_be_floor + (profit_r - 0.7) * r_dist if (is_super_wave and profit_r > 1.5) else 0
                            
                            # CHOKE TRAILING STOP V3.0 (Khóa chặt 70% của đỉnh lãi cao nhất khi vượt ngưỡng choke_trigger thích ứng)
                            choke_sl = 0
                            if choke_enabled and profit_pct >= (choke_trigger - 1e-6):
                                choke_lock_pct = profit_pct * choke_ratio
                                choke_sl = entry_price * (1.0 + choke_lock_pct)

                            # Trailing stop candidate:
                            if partial_done and is_super_wave:
                                runner_trail_pct = max(0.0070, min(0.0110, 0.90 * atr_val_pct))
                                candidate_sl = best_price * (1 - runner_trail_pct)
                            elif is_breakeven_ready and (held_minutes >= 15.0 or not partial_done):
                                fast_trail_pct = trail_pct * 0.75 if is_trailing_ready else trail_pct
                                candidate_sl = best_price * (1 - fast_trail_pct)
                            else:
                                candidate_sl = 0
                            
                            proposed_sl = max(current_sl, candidate_sl, breakeven_sl, partial_lock_sl, trailing_lock_sl, dynamic_r_sl, choke_sl)
                            # BẮT BUỘC GIỮ KHOẢNG ĐỆM THỞ TỐI THIỂU 0.22% DƯỚI GIÁ HIỆN TẠI (CHẶN LỖI ĐẶT SL SÁT GIÁ 0.0005% GÂY QUÉT 4 GIÂY)
                            min_buffer_dist = current_price * 0.0022
                            if proposed_sl > current_price - min_buffer_dist:
                                proposed_sl = max(current_sl, current_price - min_buffer_dist)
                            if proposed_sl >= current_price:
                                proposed_sl = current_price * 0.9978
                                
                            new_sl = proposed_sl
                            min_valid_floor = entry_price * 1.0012 if (partial_done and held_minutes < 15.0) else net_be_floor
                            can_lock_net_profit = new_sl >= min_valid_floor
                            step_pct = float(metrics.get('min_step_pct', 0.001))
                            improves_stop = new_sl > current_sl * (1 + step_pct)
                        else:
                            net_be_floor = net_breakeven * (1 - lock_profit_pct)
                            profit_r = (entry_price - best_price) / r_dist
                            profit_pct = (entry_price - best_price) / entry_price if entry_price > 0 else 0
                            atr_val_pct = float(metrics.get('atr_pct') or 0.012)
                            partial_done = bool(position.get('partial_tp_done', False))
                            is_super_wave = (profit_pct >= 0.025) or (max_sustained_profit_pct >= 0.0185)
                            
                            is_breakeven_ready = (
                                (current_profit_pct >= (breakeven_trigger_pct - 1e-6))
                                or (profit_pct >= breakeven_trigger_pct)
                                or partial_done
                            )
                            if partial_done and held_minutes < 15.0 and not is_super_wave:
                                breakeven_sl = entry_price * 0.9988
                            elif is_breakeven_ready:
                                breakeven_sl = net_be_floor
                            else:
                                breakeven_sl = float('inf')
                            
                            # Cấp 2: KHÓA LÃI TỪNG PHẦN (Partial Profit Lock) & RUNNER BREATHING FLOOR
                            partial_lock_sl = float('inf')
                            if partial_done:
                                if is_super_wave:
                                    partial_lock_sl = entry_price * 0.9890
                                elif profit_pct >= 0.018 and held_minutes >= 15.0:
                                    partial_lock_sl = entry_price * 0.9932
                                elif held_minutes >= 15.0:
                                    partial_lock_sl = min(net_be_floor, entry_price * 0.9965)
                                else:
                                    partial_lock_sl = entry_price * 0.9988
                            elif is_super_wave:
                                partial_lock_sl = entry_price * 0.9890
                            
                            # Cấp 3: KHÓA LÃI ĐẬM & TRAILING THEO ĐỈNH (High Profit Trailing)
                            is_trailing_ready = is_super_wave and ((profit_pct >= 0.025) or (profit_r >= 1.5))
                            trailing_lock_sl = entry_price * 0.988 if is_trailing_ready else float('inf')
                            dynamic_r_sl = net_be_floor - (profit_r - 0.7) * r_dist if (is_super_wave and profit_r > 1.5) else float('inf')
                            
                            # CHOKE TRAILING STOP V3.0 (Khóa chặt 70% của đỉnh lãi cao nhất khi vượt ngưỡng choke_trigger thích ứng)
                            choke_sl = float('inf')
                            if choke_enabled and profit_pct >= (choke_trigger - 1e-6):
                                choke_lock_pct = profit_pct * choke_ratio
                                choke_sl = entry_price * (1.0 - choke_lock_pct)

                            # Trailing stop candidate: Runner Micro-Trailing Stop
                            if partial_done and is_super_wave:
                                runner_trail_pct = max(0.0070, min(0.0110, 0.90 * atr_val_pct))
                                candidate_sl = best_price * (1 + runner_trail_pct)
                            elif is_breakeven_ready and (held_minutes >= 15.0 or not partial_done):
                                fast_trail_pct = trail_pct * 0.75 if is_trailing_ready else trail_pct
                                candidate_sl = best_price * (1 + fast_trail_pct)
                            else:
                                candidate_sl = float('inf')
                            
                            proposed_sl = min(current_sl, candidate_sl, breakeven_sl, partial_lock_sl, trailing_lock_sl, dynamic_r_sl, choke_sl)
                            # BẮT BUỘC GIỮ KHOẢNG ĐỆM THỞ TỐI THIỂU 0.22% TRÊN GIÁ HIỆN TẠI (CHẶN LỖI ĐẶT SL SÁT GIÁ 0.0005% GÂY QUÉT 4 GIÂY)
                            min_buffer_dist = current_price * 0.0022
                            if proposed_sl < current_price + min_buffer_dist:
                                proposed_sl = min(current_sl, current_price + min_buffer_dist)
                            if proposed_sl <= current_price:
                                proposed_sl = current_price * 1.0022
                                
                            new_sl = proposed_sl
                            max_valid_floor = entry_price * 0.9988 if (partial_done and held_minutes < 15.0) else net_be_floor
                            can_lock_net_profit = new_sl <= max_valid_floor
                            step_pct = float(metrics.get('min_step_pct', 0.001))
                            improves_stop = new_sl < current_sl * (1 - step_pct)

                        position['trailing_active'] = bool(can_lock_net_profit)
                        position['trailing_status'] = (
                            'active' if position['trailing_active'] else 'waiting_net_profit'
                        )
                        # Save initial_sl if not exist
                        if 'initial_sl' not in position:
                            position['initial_sl'] = initial_sl
                        if best_changed:
                            # Persist the favorable excursion so a restart cannot
                            # forget a previously observed peak/trough.
                            self._save_state()

                        if not can_lock_net_profit:
                            continue

                        pass # already_crossed handled safely above

                        if not improves_stop and not position.pop('_force_sl_update', False):
                            continue

                        is_live_futures = (
                            self.mode == 'live'
                            and getattr(self, 'market_type', 'spot') == 'futures'
                        )
                        if not is_live_futures:
                            position['stop_loss'] = new_sl
                            position['trailing_active'] = True
                            position['trailing_status'] = 'active'
                            self._save_state()
                            logger.info(
                                "ADAPTIVE TRAILING UPDATED: %s SL=%.8f gap=%.3f%% ATR=%.3f%% regime=%s netBE=%.8f",
                                position['symbol'], new_sl, trail_pct * 100,
                                (metrics.get('atr_pct') or 0) * 100,
                                position['trailing_regime'], net_breakeven,
                            )
                        elif not position.get('sl_order_id'):
                            position['trailing_active'] = False
                            position['trailing_status'] = 'protection_unavailable'
                            logger.critical(
                                "Không cập nhật adaptive trailing cho %s vì chưa có SL được xác nhận trên Binance.",
                                position['symbol'],
                            )
                            if not position.get('trailing_sl_missing_alerted'):
                                self._notify_telegram(
                                    f"🚨 Vị thế LIVE {position['symbol']} chưa có SL được xác nhận trên Binance; "
                                    "adaptive trailing chưa thể sửa lệnh bảo vệ. Hãy kiểm tra trực tiếp trên sàn."
                                )
                                position['trailing_sl_missing_alerted'] = True
                        else:
                            old_order_id = str(position['sl_order_id'])
                            close_side = 'sell' if direction == 'LONG' else 'buy'
                            try:
                                # Place and acknowledge the replacement first; the
                                # existing exchange stop remains live if this fails.
                                new_order = self.exchange.create_stop_market_order(
                                    position['symbol'], close_side,
                                    position['amount'], new_sl,
                                )
                                new_info = (new_order or {}).get('info') or {}
                                new_order_id = str(
                                    (new_order or {}).get('id')
                                    or new_info.get('algoId')
                                    or new_info.get('orderId')
                                    or ''
                                )
                                if not new_order_id:
                                    logger.error(
                                        "Binance chưa xác nhận SL adaptive mới cho %s; giữ nguyên SL %s tại %.8f.",
                                        position['symbol'], old_order_id, current_sl,
                                    )
                                else:
                                    position['stop_loss'] = new_sl
                                    position['sl_order_id'] = new_order_id
                                    position['trailing_active'] = True
                                    position['trailing_status'] = 'active'
                                    pending_ids = list(dict.fromkeys(
                                        str(order_id)
                                        for order_id in position.get('stale_sl_order_ids', [])
                                        if order_id
                                    ))
                                    if old_order_id != new_order_id:
                                        pending_ids.append(old_order_id)
                                    position['stale_sl_order_ids'] = list(dict.fromkeys(pending_ids))
                                    # Save the acknowledged new stop before canceling
                                    # the old one, preserving recoverability.
                                    self._save_state()
                                    if old_order_id != new_order_id:
                                        try:
                                            self.exchange.cancel_order(
                                                old_order_id, position['symbol'],
                                                trigger=True, strict=True,
                                            )
                                            remaining = self.exchange.get_open_orders(
                                                position['symbol'], trigger=True, strict=True
                                            )
                                            remaining_ids = {
                                                self._conditional_order_id(order)
                                                for order in remaining
                                            }
                                            if old_order_id not in remaining_ids:
                                                pending_ids = [
                                                    order_id for order_id in pending_ids
                                                    if order_id != old_order_id
                                                ]
                                            else:
                                                logger.error(
                                                    "SL trailing cũ %s vẫn mở trên Binance; sẽ thử dọn lại.",
                                                    old_order_id,
                                                )
                                        except Exception as e:
                                            logger.error(
                                                "Đã đặt SL adaptive %s nhưng chưa xác minh hủy SL cũ %s: %s",
                                                new_order_id, old_order_id, e,
                                            )
                                            alerted_ids = position.setdefault(
                                                'trailing_sl_cancel_alerted_ids', []
                                            )
                                            if old_order_id not in alerted_ids:
                                                self._notify_telegram(
                                                    f"⚠️ {position['symbol']}: SL adaptive mới đã đặt; "
                                                    f"chưa xác minh hủy SL cũ {old_order_id}. Tool sẽ thử dọn lại."
                                                )
                                                alerted_ids.append(old_order_id)
                                    position['stale_sl_order_ids'] = list(dict.fromkeys(pending_ids))
                                    self._save_state()
                                    logger.info(
                                        "ADAPTIVE TRAILING UPDATED: %s SL=%.8f gap=%.3f%% ATR=%.3f%% regime=%s netBE=%.8f order=%s",
                                        position['symbol'], new_sl, trail_pct * 100,
                                        (metrics.get('atr_pct') or 0) * 100,
                                        position['trailing_regime'], net_breakeven,
                                        new_order_id,
                                    )
                                    # TELEGRAM NOTIFICATIONS
                                    try:
                                        quote_curr = self.config.get('trading', {}).get('base_currency', 'USDT')
                                        last_notified = position.get('last_notified_sl_price', initial_sl)
                                        sl_step_ratio = abs(new_sl - last_notified) / entry_price if entry_price > 0 else 0
                                        est_sl_pnl = (new_sl - entry_price) * position['amount'] if direction == 'LONG' else (entry_price - new_sl) * position['amount']
                                        
                                        if choke_enabled and profit_pct >= (choke_trigger - 1e-6) and not position.get('notified_choke'):
                                            self._notify_telegram(
                                                f"🚀 **[CHOKE TRAILING - SIẾT ĐỈNH GIA TỐC]**\n"
                                                f"Cặp: **{position['symbol']}** ({direction})\n"
                                                f"Phân khúc: `{profile.get('asset_class', 'STANDARD')}` | Đỉnh lãi: `+{profit_pct*100:.2f}%`\n"
                                                f"🔒 **Dời SL siết chặt {int(choke_ratio*100)}% đỉnh:** `{current_sl:.6g}` ➡️ `{new_sl:.6g}`\n"
                                                f"💎 **Lợi nhuận bảo hiểm tối thiểu:** `+{est_sl_pnl:.4f} {quote_curr}`\n"
                                                f"🚀 Bất chấp râu nến giật ngược, {int(choke_ratio*100)}% khoản lãi to đã nằm chắc trong ví!"
                                            )
                                            position['notified_choke'] = True
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                        elif profit_r >= 2.0 and not position.get('notified_lock2'):
                                            self._notify_telegram(
                                                f"🔥 **[KHÓA LÃI GỒNG VÔ CỰC]**\n"
                                                f"Sóng {position['symbol']} đang bứt phá rất mạnh (>2R)!\n"
                                                f"🔹 **Dời Stop-Loss bảo hiểm:** {current_sl:.6g} ➡️ {new_sl:.6g}\n"
                                                f"💎 **Khóa chặt lợi nhuận tối thiểu:** {est_sl_pnl:+.4f} {quote_curr}\n"
                                                f"🎯 **Mục tiêu TP vẫn giữ nguyên:** {position.get('take_profit', 0):.6g}"
                                            )
                                            position['notified_lock2'] = True
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                        elif not position.get('notified_be') and can_lock_net_profit:
                                            self._notify_telegram(
                                                f"🛡️ **[BẢO TOÀN VỐN - HÒA VỐN]**\n"
                                                f"Giá {position['symbol']} đã đạt lợi nhuận an toàn (>1R)!\n"
                                                f"🔹 **Kéo Stop-loss về điểm HÒA VỐN:** {new_sl:.6g}\n"
                                                f"💸 **Ước tính lợi nhuận nếu chạm SL:** {est_sl_pnl:+.4f} {quote_curr}\n"
                                                f"🎯 **Tiếp tục gồng lời về đích TP:** {position.get('take_profit', 0):.6g}"
                                            )
                                            position['notified_be'] = True
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                        elif can_lock_net_profit and est_sl_pnl > 0 and sl_step_ratio >= 0.003:
                                            self._notify_telegram(
                                                f"📈 **[NÂNG MỨC BẢO HIỂM LÃI]**\n"
                                                f"Cặp {position['symbol']} tiếp tục mở rộng đà lãi!\n"
                                                f"🔹 **Nâng Trailing SL:** {current_sl:.6g} ➡️ {new_sl:.6g}\n"
                                                f"💎 **Lợi nhuận được khóa thêm:** {est_sl_pnl:+.4f} {quote_curr}\n"
                                                f"🎯 **Mục tiêu TP:** {position.get('take_profit', 0):.6g}"
                                            )
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                    except Exception as te:
                                        logger.debug(f"Lỗi thông báo Telegram trailing: {te}")
                            except Exception as e:
                                logger.error(
                                    "Lỗi đặt adaptive trailing cho %s; giữ nguyên SL hiện tại: %s",
                                    position['symbol'], e,
                                )
                    except Exception as e:
                        logger.error(
                            "Lỗi tính adaptive trailing cho %s: %s",
                            position.get('symbol'), e,
                        )
            except Exception as e:
                logger.error(f"Lỗi kiểm tra position {position.get('symbol')}: {e}")

    def _check_drawdown(self, equity: float):
        """Kiểm tra drawdown và pause nếu vượt ngưỡng. Cập nhật mốc Đỉnh tài khoản qua ngày."""
        try:
            equity = float(equity)
        except (TypeError, ValueError, OverflowError):
            logger.critical("Equity không hợp lệ; khóa mở lệnh mới để bảo vệ tài khoản.")
            return True
        if not math.isfinite(equity) or equity <= 0:
            logger.critical("Equity không hữu hạn hoặc không dương; khóa mở lệnh mới.")
            return True
            
        current_date = datetime.now().date()
        if not hasattr(self, 'last_reset_date'):
            self.last_reset_date = current_date
            
        if current_date > self.last_reset_date:
            logger.info("🌅 Qua ngày mới! Đặt lại mốc Đỉnh Tài Khoản để bắt đầu lại đánh giá Drawdown.")
            self.peak_balance = equity
            self.last_reset_date = current_date
            self._save_state()

        if equity > self.peak_balance:
            self.peak_balance = equity
            self._save_state()

        logger.info(f"DEBUG DRAWDOWN: equity={equity}, peak_balance={self.peak_balance}")
        is_exceeded, drawdown = self.risk_manager.check_drawdown(
            equity, self.peak_balance
        )
        if is_exceeded:
            # Tu dong phat hien chenh lech do rut tien ngoai san khi khong co vi the mo
            if len(self.open_positions) == 0:
                logger.info(
                    f"🔄 [TỰ ĐỘNG HIỆU CHỈNH ĐỈNH VỐN] Không có vị thế mở nhưng drawdown đo được {drawdown:.2%} "
                    f"(do rút tiền hoặc mốc đỉnh cũ {self.peak_balance:.2f} > {equity:.2f}). Đặt lại Đỉnh Vốn = {equity:.2f} USDT."
                )
                self.peak_balance = equity
                self._save_state()
                return False
                
            logger.warning(
                f"⚠️ DRAWDOWN EXCEEDED! ({drawdown:.2%}). "
                f"Bot tạm dừng giao dịch mới."
            )
            return True
        return False

    def _check_fomo(self, symbol: str) -> bool:
        """Chống mua đuổi: Kiểm tra nến 15m xem giá có đang đi quá xa EMA20 hay nến vừa đóng quá dài (FOMO) không."""
        try:
            df = self.data_collector.fetch_data(symbol, '15m', limit=30)
            if df is None or len(df) < 25:
                return False
            import ta
            
            # Tính EMA20 và ATR
            ema20 = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
            atr = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=14).average_true_range()
            
            # Bỏ qua nến đang chạy (iloc[-1]), xét nến vừa đóng hoàn toàn (iloc[-2]) theo chuẩn Bài học số 4
            prev_open = df['open'].iloc[-2]
            prev_close = df['close'].iloc[-2]
            prev_ema = ema20.iloc[-2]
            prev_atr = atr.iloc[-2]
            candle_body = abs(prev_close - prev_open)
            
            # 1. Khoảng cách tới EMA20 không vượt quá 2.5 lần ATR
            dist_to_ema = abs(prev_close - prev_ema)
            if dist_to_ema > prev_atr * 2.5:
                logger.info(f"🚫 [Anti-FOMO] {symbol} đang cách xa EMA20 (Dist: {dist_to_ema:.4f}, ATR: {prev_atr:.4f}).")
                return True
                
            # 2. Thân nến vừa đóng không dài quá 2 lần ATR (Spike bất thường)
            if candle_body > prev_atr * 2.0:
                logger.info(f"🚫 [Anti-FOMO] {symbol} vừa có nến bứt phá quá mạnh (Body: {candle_body:.4f}, ATR: {prev_atr:.4f}). Đợi hồi.")
                return True
                
            return False
        except Exception as e:
            logger.warning(f"Lỗi kiểm tra FOMO cho {symbol}: {e}")
            return False

    def _detect_base_currency(self):
        """Tu dong nhan dien USDC hoac USDT dua tren so du (neu khong co lenh mo)."""
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures' or self.open_positions:
            return
            
        try:
            bal = self.exchange.exchange.fetch_balance({'type': 'future'}) if getattr(self.exchange, 'exchange', None) else {}
            if isinstance(bal, dict):
                usdt_data = bal.get('USDT') or {}
                usdc_data = bal.get('USDC') or {}
                
                usdt_total = float(usdt_data.get('total', 0) if isinstance(usdt_data, dict) else bal.get('total', {}).get('USDT', 0) if isinstance(bal.get('total'), dict) else 0)
                usdc_total = float(usdc_data.get('total', 0) if isinstance(usdc_data, dict) else bal.get('total', {}).get('USDC', 0) if isinstance(bal.get('total'), dict) else 0)
                
                detected = None
                if usdt_total > usdc_total and usdt_total > 1.0:
                    detected = 'USDT'
                elif usdc_total > usdt_total and usdc_total > 1.0:
                    detected = 'USDC'
                    
                if detected:
                    old_base = self.config.get('trading', {}).get('base_currency')
                    if old_base != detected:
                        logger.info(f"🔄 Tự động chuyển đổi Base Currency: {old_base} -> {detected} (do số dư {detected} lớn hơn)")
                        if 'trading' not in self.config:
                            self.config['trading'] = {}
                        self.config['trading']['base_currency'] = detected
                        
                        # Lưu thẳng vào settings.yaml để lần sau khởi động không bị quên (nhất là khi có lệnh mở)
                        try:
                            import yaml, os
                            settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
                            with open(settings_path, 'r', encoding='utf-8') as sf:
                                st = yaml.safe_load(sf) or {}
                            if 'trading' not in st: st['trading'] = {}
                            st['trading']['base_currency'] = detected
                            with open(settings_path, 'w', encoding='utf-8') as sf:
                                yaml.dump(st, sf, default_flow_style=False, allow_unicode=True)
                        except Exception as e:
                            logger.error(f"Lỗi lưu base_currency vào settings.yaml: {e}")
                        
                        new_bal = bal.get(detected) or {}
                        self.balance = float(new_bal.get('free', bal.get('free', {}).get(detected, 0)) if isinstance(new_bal, dict) else 0)
        except Exception as e:
            logger.debug(f"Lỗi nhận diện base currency: {e}")

    def _sweep_orphan_protection_orders(self) -> int:
        """Quét và hủy các lệnh dừng lỗ / chốt lời mồ côi (reduceOnly / trigger) trên Binance khi không còn vị thế mở."""
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures':
            return 0
        try:
            live = set()
            for p in (self.exchange.get_futures_positions() or []):
                amt = abs(float(p.get('contracts') or (p.get('info') or {}).get('positionAmt') or 0))
                if amt > 0:
                    live.add(str(p.get('symbol') or '').split(':')[0])
            orders = self.exchange.get_open_orders(None, trigger=True, strict=True) or []
        except Exception as e:
            logger.warning("Orphan sweep bỏ qua do lỗi truy vấn: %s", e)
            return 0
        cancelled = 0
        now_ms = time.time() * 1000
        for o in orders:
            sym = str(o.get('symbol') or '').split(':')[0]
            if sym in live:
                continue
            if not (o.get('reduceOnly') or (o.get('info') or {}).get('reduceOnly')):
                continue
            ts = o.get('timestamp')
            if ts and (now_ms - float(ts)) < 60000:  # Tránh race condition với lệnh vừa đặt dưới 60s
                continue
            try:
                self.exchange.cancel_order(str(o['id']), sym, trigger=True, strict=True)
                cancelled += 1
                logger.warning(f"🧹 Đã hủy lệnh bảo vệ mồ côi {o.get('id')} của {sym} (không còn vị thế mở trên Binance).")
            except Exception as e:
                logger.error(f"Không hủy được lệnh mồ côi {o.get('id')} {sym}: {e}")
        return cancelled

    def run_cycle(self):
        # Quét dọn lệnh mồ côi định kỳ mỗi 5 phút
        now_sweep = time.time()
        if (now_sweep - getattr(self, '_last_orphan_sweep_time', 0.0)) >= 300.0:
            self._last_orphan_sweep_time = now_sweep
            self._sweep_orphan_protection_orders()

        """Chạy một chu kỳ phân tích và giao dịch."""
        self._detect_base_currency()
        logger.info(f"\n{'='*60}")
        logger.info(f"🔄 Chu kỳ mới - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        logger.info(f"💰 Balance: {self.balance:.4f} {quote} | "
                    f"Open: {len(self.open_positions)} positions")
        logger.info(f"{'='*60}")
        
        # Reconcile exchange state before evaluating any saved local stop/target.
        if not self.sync_live_positions_with_exchange():
            logger.error("Không đồng bộ được vị thế với Binance; bỏ qua chu kỳ để tránh mở lệnh theo dữ liệu cũ.")
            return
        if self.unreconciled_exchange_positions:
            logger.critical("Có vị thế hoặc lệnh bảo vệ Binance chưa thể đối soát an toàn; tạm khóa lệnh mới.")
            return

        # A dedicated position monitor manages stops independently while this
        # slower cycle analyzes symbols and runs external AI calls.
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures' and not self.live_balance_synced:
            logger.error("Không lấy được số dư Futures mới nhất; tạm khóa lệnh mới nhưng vẫn cho phép thao tác đóng vị thế.")
            return
        
        # Tính equity hiện tại
        status = self.get_status()
        if 'equity' in status and status['equity'] is not None:
            current_equity = status['equity']
        else:
            current_equity = status.get('balance', self.balance) + sum(pos.get('cost', 0) for pos in self.open_positions)
            if 'pnl' in status:
                current_equity = self.config['trading']['initial_capital'] + status['pnl']
        
        # Kiểm tra drawdown
        if self._check_drawdown(current_equity):
            self._save_state()
            return

        daily_limit = float(self.config.get('risk', {}).get('max_daily_loss_pct', 0.05))
        if daily_limit > 0:
            now = datetime.now()
            day_start_ms = int(now.replace(hour=0, minute=0, second=0, microsecond=0).timestamp() * 1000)
            base_currency = self.config.get('trading', {}).get('base_currency', 'USDT')
            daily_net_pnl = self.db.get_daily_net_pnl(self.mode, day_start_ms, base_currency)
            if current_equity > 0 and daily_net_pnl <= -(current_equity * daily_limit):
                logger.error(
                    f"Giới hạn lỗ trong ngày đã chạm: {daily_net_pnl:.4f} "
                    f"({daily_net_pnl/current_equity:.2%}); tạm ngưng lệnh mới đến ngày kế tiếp."
                )
                self._save_state()
                return
        
        # KIỂM TRA AI BIAS VÀ DYNAMIC CONFIG TRƯỚC KHI VÀO LỆNH MỚI
        ai_target = 'ALL'
        bias = 'HIGH_RISK'
        self.ai_max_positions = self._configured_max_open_positions()
        self.ai_recommended_max_positions = self.ai_max_positions
        try:
            import yaml
            from pathlib import Path
            
            # Reload dynamic confidence threshold from settings.yaml
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            with open(settings_path, 'r', encoding='utf-8') as sf:
                settings = yaml.safe_load(sf)
                if not isinstance(settings, dict):
                    raise ValueError('settings.yaml không phải mapping hợp lệ')
                ai_settings = settings.get('ai', {})
                if not isinstance(ai_settings, dict):
                    raise ValueError('mục ai trong settings.yaml không hợp lệ')
                new_threshold = float(ai_settings.get('confidence_threshold', 0.12))
                if not math.isfinite(new_threshold) or not 0 <= new_threshold <= 1:
                    raise ValueError('ai.confidence_threshold phải nằm trong [0, 1]')
                if hasattr(self, 'signal_aggregator'):
                    self.signal_aggregator.confidence_threshold = new_threshold

            strat_path = Path(__file__).parent.parent / 'config' / 'strategies.yaml'
            with open(strat_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f)
                if not isinstance(strat, dict):
                    raise ValueError('strategies.yaml không phải mapping hợp lệ')
                ai_bias = strat.get('ai_bias', {})
                if not isinstance(ai_bias, dict):
                    raise ValueError('mục ai_bias trong strategies.yaml không hợp lệ')
                raw_bias = ai_bias.get('direction', 'NONE')
                ai_target = ai_bias.get('target_coin', 'ALL')
                
                # Logic xác nhận bias (chỉ đổi khi giống nhau 2 lần liên tiếp)
                if not hasattr(self, 'last_raw_bias'):
                    self.last_raw_bias = raw_bias
                if not hasattr(self, 'confirmed_bias'):
                    self.confirmed_bias = raw_bias
                    
                if raw_bias == self.last_raw_bias:
                    self.confirmed_bias = raw_bias
                else:
                    logger.info(f"AI Bias đang thay đổi ({self.last_raw_bias} -> {raw_bias}), chờ xác nhận vòng sau.")
                    self.last_raw_bias = raw_bias
                    
                bias = self.confirmed_bias
                self.ai_recommended_max_positions = ai_bias.get(
                    'suggested_max_positions', self.ai_max_positions,
                )
                if not isinstance(ai_target, str) or not ai_target:
                    raise ValueError('ai_bias.target_coin phải là chuỗi không rỗng')
                # AI's slot count is a recommendation. The risk/trading settings
                # remain the hard cap; strong confirmed setups may earn another slot.
                self.ai_max_positions = self._configured_max_open_positions()
                if bias not in ('BULLISH', 'BEARISH', 'NEUTRAL', 'HIGH_RISK', 'NONE'):
                    logger.error("AI bias không hợp lệ (%r); khóa lệnh mới.", bias)
                    bias = 'HIGH_RISK'
                
                if bias == 'NONE':
                    logger.info(" Đang chờ AI Ollama phân tích... Chưa thể vào lệnh mới.")
                    self._save_state()
                    return
                elif bias == 'HIGH_RISK':
                    logger.warning(
                        "[WARNING] AI báo RỦI RO CAO; tạm ngưng mở lệnh mới. "
                        "Bot vẫn tiếp tục quản lý vị thế đang mở."
                    )
                    self._save_state()
                    return

        except Exception as e:
            # If trading policy cannot be read, fail closed for this cycle.
            # The position monitor remains independent and keeps managing any
            # already-open position; this only prevents new entry decisions.
            logger.error(
                "Không đọc được cấu hình AI/bias; khóa lệnh mới trong chu kỳ này: %s",
                e,
            )
            self._save_state()
            return
        
        # 1. TÌM KIẾM & SO SÁNH: Quét toàn bộ thị trường tìm coin tiềm năng
        skip_dynamic_exit_this_cycle = bool(self._skip_dynamic_exit_cycle)
        self._skip_dynamic_exit_cycle = False
        if self.config['trading'].get('dynamic_scanning', True):
            scan_limit = self.config['trading'].get('max_scan_pairs', 5)
            target_pairs = self.scanner.get_potential_pairs(limit=scan_limit)
        else:
            target_pairs = list(self.config['trading']['pairs'])
            
        # Lọc danh sách cặp theo 3 chế độ (Chỉ Cổ phiếu / Cả Hai / Chỉ Crypto)
        tradfi_cfg = self.config.get('tradfi', {})
        tradfi_enabled = bool(tradfi_cfg.get('enabled', False))
        only_tradfi = bool(tradfi_cfg.get('only_tradfi', False))

        if only_tradfi:
            # Chế độ CHỈ CỔ PHIẾU: Loại bỏ 100% Crypto
            target_pairs = [p for p in target_pairs if MarketScanner.is_tradfi_stock(p)]
        elif not tradfi_enabled:
            # Chế độ THUẦN CRYPTO: Loại bỏ 100% Cổ phiếu
            target_pairs = [p for p in target_pairs if not MarketScanner.is_tradfi_stock(p)]

        # Luôn đưa các đồng coin/mã đang mở vị thế vào đầu danh sách quét để không bao giờ bị bỏ sót
        open_symbols = [p.get('symbol') for p in self.open_positions if p.get('symbol')]
        for s in open_symbols:
            clean_s = self._clean_symbol(s)
            matching = [p for p in target_pairs if self._clean_symbol(p) == clean_s]
            if not matching:
                target_pairs.insert(0, s)
        
        # 2.1 PHA 1: QUÉT NHANH BẰNG ĐA LUỒNG (MULTI-THREADING)
        candidates = []
        import concurrent.futures
        
        is_global_loss_cooling = time.time() < self._global_loss_cooldown_until
        if is_global_loss_cooling:
            rem_min = (self._global_loss_cooldown_until - time.time()) / 60.0
            logger.info(f"⏸️ Global Cooldown sau khi cắt lỗ đang kích hoạt (còn {rem_min:.1f} phút). Chỉ theo dõi vị thế mở, tạm dừng mở vị thế mới.")

        def process_pair(pair):
            if not self.is_running:
                return None
            clean_pair = self._clean_symbol(pair)
            pair_base = clean_pair.split('/')[0] if '/' in clean_pair else clean_pair
            if ai_target != 'ALL' and ai_target.upper() != pair_base:
                return None

            # Kiểm tra trạng thái phân loại Crypto vs Cổ phiếu
            is_stock = MarketScanner.is_tradfi_stock(pair)
            if only_tradfi:
                if not is_stock:
                    return None
                if tradfi_cfg.get('session_filter', True) and not MarketScanner.is_us_market_open():
                    return None
            elif not tradfi_enabled:
                if is_stock:
                    return None
            elif is_stock and tradfi_cfg.get('session_filter', True) and not MarketScanner.is_us_market_open():
                return None

            try:
                active_pos = [
                    p for p in self.open_positions
                    if self._clean_symbol(p.get('symbol')) == self._clean_symbol(pair)
                ]
                has_open_pos = len(active_pos) > 0
                
                if has_open_pos:
                    return {'pair': pair, 'score': 100.0, 'is_open': True, 'active_pos': active_pos}

                if is_global_loss_cooling:
                    return None

                cooldown_symbol = self._clean_symbol(pair)
                cooldown_until = max(
                    self._manual_exit_cooldowns.get(cooldown_symbol, 0),
                    self._symbol_cooldowns.get(cooldown_symbol, 0)
                )
                if time.time() < cooldown_until:
                    return None
                
                configured_max = self._configured_max_open_positions()
                if len(self.open_positions) >= configured_max:
                    return None
                    
                signals = self._analyze_market(pair, fast_mode=True)
                
                if not signals:
                    return None
                    
                best_signal = None
                try:
                    best_signal = self.signal_aggregator.aggregate(signals)
                except Exception:
                    best_signal = None

                threshold = getattr(self.signal_aggregator, 'confidence_threshold', 0.55)
                if best_signal and getattr(best_signal, 'confidence', 0.0) >= threshold:
                    if self._check_fomo(pair):
                        return None
                    return {'pair': pair, 'score': float(best_signal.confidence), 'is_open': False, 'active_pos': []}
                elif not best_signal:
                    # Trong Pha 1 (fast_mode=True chưa chạy AI/JEV), nếu có ít nhất 1 chiến thuật kỹ thuật
                    # độc lập, cho phép ứng cử vào Pha 2 với điểm chiết khấu (để Pha 2 chạy AI/JEV đánh giá sâu trước khi veto)
                    votes_p1 = self.signal_aggregator._strategy_votes(signals, apply_entry_vetoes=False)
                    if votes_p1:
                        raw_p1_score = abs(self.signal_aggregator.calculate_weighted_score(signals, votes=votes_p1, apply_entry_vetoes=False))
                        discounted_score = min(0.58, raw_p1_score * 0.72)
                        if discounted_score >= threshold * 0.90 and not self._check_fomo(pair):
                            return {'pair': pair, 'score': float(discounted_score), 'is_open': False, 'active_pos': []}
            except Exception as e:
                import traceback
                logger.error(f"Lỗi phân tích đa luồng Pha 1 cho {pair}: {e}")
            return None

        # Chạy đa luồng với 15 workers để tối đa hóa tốc độ tải dữ liệu
        logger.info(f"\n🔍 [MULTI-THREADING] Đang quét {len(target_pairs)} đồng coin cùng lúc...")
        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
            results = list(executor.map(process_pair, target_pairs))
            
        for r in results:
            if r is not None:
                candidates.append(r)
                
        # Sắp xếp ứng viên theo điểm số giảm dần
        candidates.sort(key=lambda x: x['score'], reverse=True)
        top_candidates = candidates[:3]
        
        # 2.2 PHA 2: Đánh giá sâu và Ra quyết định
        for cand in top_candidates:
            pair = cand['pair']
            has_open_pos = cand['is_open']
            active_pos = cand['active_pos']
            
            if not self.is_running:
                break
                
            try:
                # Kiểm tra lại slot (đề phòng vòng lặp trước đã mở lệnh)
                configured_max = self._configured_max_open_positions()
                if not has_open_pos and len(self.open_positions) >= configured_max:
                    logger.info("⏸️ Bỏ qua đánh giá sâu %s: số vị thế đã chạm trần cấu hình %d.", pair, configured_max)
                    continue

                logger.info(f"\n🧠 Phân tích sâu (Pha 2): {pair}...")
                signals = self._analyze_market(pair, fast_mode=False)
                
                if has_open_pos:
                    pos = active_pos[0]
                    current_dir = pos.get('direction', 'LONG')
                    raw_score = self.signal_aggregator.calculate_weighted_score(signals, apply_entry_vetoes=False) if signals else 0.0

                    ticker = self.exchange.get_ticker(pair)
                    raw_ticker_last = (ticker.get('last') or ticker.get('close')) if ticker else None
                    if raw_ticker_last is not None:
                        try:
                            current_price = float(raw_ticker_last) if (math.isfinite(float(raw_ticker_last)) and float(raw_ticker_last) > 0) else float(pos.get('entry_price', 0))
                        except (TypeError, ValueError):
                            current_price = float(pos.get('entry_price', 0))
                    else:
                        current_price = float(pos.get('entry_price', 0))
                    entry_price = float(pos.get('entry_price') or pos.get('price', 0))
                    
                    pnl_pct = 0.0
                    if entry_price > 0 and current_price > 0:
                        if current_dir == 'LONG':
                            pnl_pct = (current_price - entry_price) / entry_price
                        else:
                            pnl_pct = (entry_price - current_price) / entry_price

                    old_best_p2 = pos.get('trailing_best_price')
                    try:
                        old_best_p2 = float(old_best_p2) if old_best_p2 is not None else None
                    except (TypeError, ValueError, OverflowError):
                        old_best_p2 = None
                    if current_dir == 'LONG':
                        best_p2 = max(entry_price, current_price, old_best_p2 or 0.0)
                        peak_profit_p2 = (best_p2 - entry_price) / entry_price if entry_price > 0 else 0.0
                    else:
                        valid_b2 = [v for v in (entry_price, current_price, old_best_p2) if v is not None and v > 0]
                        best_p2 = min(valid_b2) if valid_b2 else entry_price
                        peak_profit_p2 = (entry_price - best_p2) / entry_price if entry_price > 0 else 0.0
                    pos['trailing_best_price'] = best_p2
                    
                    held_minutes = 0.0
                    pos_timestamp_str = pos.get('timestamp')
                    try:
                        if pos_timestamp_str:
                            pos_dt = datetime.fromisoformat(pos_timestamp_str)
                            held_minutes = (datetime.now() - pos_dt).total_seconds() / 60.0
                    except Exception:
                        pass
                    
                    # 2. Điều kiện đảo chiều từ AI & Chỉ báo kỹ thuật:
                    # Thời gian thở tối thiểu (Grace Period): 15 phút đầu không kích hoạt thoát sớm đảo chiều thông thường,
                    # NHƯNG nếu AI Ensemble phát tín hiệu đảo chiều khẩn cấp (conf >= 0.72) kèm vị thế đang lỗ <= -0.55%
                    # (ví dụ TIA/USDT vừa hết Cold-start báo SELL 76.2%), cho phép phá khóa Grace Period thoát hiểm ngay!
                    in_grace_period = held_minutes < 15.0
                    has_safe_profit = pnl_pct >= 0.0085 or bool(pos.get('trailing_active'))
                    
                    # Đếm số lượng chiến thuật báo đảo chiều mạnh (conf >= 0.65) và kiểm tra AI Ensemble / Trap khẩn cấp
                    opposing_count = 0
                    ai_emergency_opposing = False
                    trap_emergency_opposing = False
                    if signals and not has_safe_profit:
                        for s in signals:
                            s_dir = getattr(getattr(s, 'signal', None), 'value', str(getattr(s, 'signal', ''))).lower()
                            s_conf = float(getattr(s, 'confidence', 0.0) or 0.0)
                            s_strat = str(getattr(s, 'strategy', '')).lower()
                            if current_dir == 'LONG' and s_dir == 'sell':
                                if s_conf >= 0.65:
                                    opposing_count += 1
                                if s_strat == 'ai_ensemble' and s_conf >= 0.72:
                                    ai_emergency_opposing = True
                                if s_strat in ('trap_detector', 'trapdetector') and s_conf >= 0.65:
                                    trap_emergency_opposing = True
                            elif current_dir == 'SHORT' and s_dir == 'buy':
                                if s_conf >= 0.65:
                                    opposing_count += 1
                                if s_strat == 'ai_ensemble' and s_conf >= 0.72:
                                    ai_emergency_opposing = True
                                if s_strat in ('trap_detector', 'trapdetector') and s_conf >= 0.65:
                                    trap_emergency_opposing = True

                    pos_trap_type = str(pos.get('trap_type') or '')
                    is_trap_trade = ('BULL_TRAP' in pos_trap_type) or ('BEAR_TRAP' in pos_trap_type)
                    reversal_score_threshold = 0.50 if is_trap_trade else 0.35

                    is_emergency_ai_reversal = (
                        in_grace_period
                        and held_minutes >= 3.0
                        and pnl_pct <= -0.0055
                        and ai_emergency_opposing
                        and (
                            (current_dir == 'LONG' and raw_score <= -0.40)
                            or (current_dir == 'SHORT' and raw_score >= 0.40)
                        )
                    )

                    is_emergency_trap_reversal = (
                        in_grace_period
                        and held_minutes >= 2.0
                        and pnl_pct <= -0.0035
                        and trap_emergency_opposing
                    )

                    is_reversed = (not has_safe_profit) and (
                        is_emergency_ai_reversal
                        or is_emergency_trap_reversal
                        or (
                            not in_grace_period and (
                                (opposing_count >= 2 and (
                                    (current_dir == 'LONG' and raw_score <= -reversal_score_threshold) or 
                                    (current_dir == 'SHORT' and raw_score >= reversal_score_threshold)
                                )) or
                                (current_dir == 'LONG' and raw_score <= -0.55) or
                                (current_dir == 'SHORT' and raw_score >= 0.55)
                            )
                        )
                    )
                    
                    # Thoát lệnh theo thời gian (Time Decay & Early Invalidation) được quản lý tập trung và an toàn
                    # trong _check_open_positions_locked (có kiểm tra lock, sàn stop-loss và xu hướng EMA).
                    if is_emergency_ai_reversal:
                        logger.warning(
                            f"🚨 [PHÁ KHÓA GRACE PERIOD - CỨU HỘ KHẨN CẤP] AI Ensemble phát hiện đảo chiều mạnh ngược lệnh {pair} ({current_dir}) "
                            f"(Điểm AI: {raw_score:+.4f}, PnL: {pnl_pct*100:+.2f}%, Đã giữ: {held_minutes:.1f}m)! Thoát hiểm ngay lập tức!"
                        )
                        self._close_position(pos, current_price, close_reason=f"🚨 AI Ensemble cứu hộ khẩn cấp trong Grace Period (Điểm: {raw_score:+.4f})")
                    elif is_emergency_trap_reversal:
                        logger.warning(
                            f"🚨 [PHÁ KHÓA GRACE PERIOD - THOÁT BẪY RÂU KHẨN CẤP] TrapDetector phát hiện Bẫy Râu đảo chiều ngược lệnh {pair} ({current_dir}) "
                            f"(PnL: {pnl_pct*100:+.2f}%, Đã giữ: {held_minutes:.1f}m)! Thoát hiểm bảo toàn vốn ngay lập tức!"
                        )
                        self._close_position(pos, current_price, close_reason=f"🚨 TrapDetector xác nhận Bẫy Râu đảo chiều trong Grace Period (PnL: {pnl_pct*100:+.2f}%)")
                    elif in_grace_period and not has_safe_profit:
                        logger.info(f"   [Thời gian thở Grace Period] Vị thế {pair} ({current_dir}): Đã giữ {held_minutes:.1f}/15.0m, PnL: {pnl_pct*100:+.2f}%, Điểm AI: {raw_score:+.4f}. Đang bảo vệ lệnh khỏi nhiễu nến 1m!")
                    elif is_reversed and skip_dynamic_exit_this_cycle:
                        logger.info("Giữ vị thế %s trong chu kỳ đầu; Điểm AI %+.4f, PnL: %+.2f%%.", pair, raw_score, pnl_pct * 100)
                    elif is_reversed:
                        logger.warning(f"🛑 [THOÁT SỚM THÔNG MINH] AI báo động đảo chiều (Điểm: {raw_score:+.4f}, Đối kháng: {opposing_count}/chiến thuật, Đã giữ: {held_minutes:.1f}m)! Đóng khẩn cấp lệnh {pair} ({current_dir}).")
                        self._close_position(pos, current_price, close_reason=f"AI phát hiện đảo chiều, Thoát sớm bảo toàn vốn (Điểm: {raw_score:+.4f})")
                    else:
                        logger.info(f"   [Giám sát lệnh] Vị thế {pair} ({current_dir}): PnL: {pnl_pct*100:+.2f}%, Điểm AI: {raw_score:+.4f}, Đã giữ: {held_minutes:.0f}m. Tiếp tục theo dõi!")
                    
                    continue

                if not signals:
                    logger.info(f"  ➡️ Không có tín hiệu cho {pair}")
                    continue

                final_signal = self.signal_aggregator.aggregate(signals)

                if final_signal:
                    final_signal.metadata['ai_bias'] = bias
                    logger.info(
                        f" TIN HIEU CUOI: {final_signal.signal.value.upper()} "
                        f"{final_signal.symbol} "
                        f"(confidence: {final_signal.confidence:.2%})"
                    )

                    is_stock_gate = MarketScanner.is_tradfi_stock(final_signal.symbol) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(final_signal.symbol))
                    base_coin_gate = final_signal.symbol.split('/')[0].split(':')[0].strip().upper()
                    is_major_gate = base_coin_gate in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')

                    if not is_stock_gate:
                        # VỚI CRYPTO (MAJOR & ALTCOIN): TUÂN THỦ NGHIÊM NGẶT AI BIAS VĨ MÔ
                        if bias == 'BEARISH' and final_signal.signal.value.upper() == 'BUY':
                            has_trap_wick = isinstance(getattr(final_signal, 'metadata', None), dict) and final_signal.metadata.get('type') == 'BEAR_TRAP_WICK'
                            if not (has_trap_wick and final_signal.confidence >= 0.80):
                                logger.warning(f"🛡️ VETO AI BIAS: Chặn hoàn toàn lệnh BUY {final_signal.symbol} vì ngược hướng AI bias BEARISH toàn thị trường (Conf: {final_signal.confidence:.2%})! Cấm bắt dao rơi.")
                                try:
                                    from core.gate_telemetry import record_radar_candidate
                                    record_radar_candidate(
                                        symbol=final_signal.symbol,
                                        side='BUY',
                                        confidence=final_signal.confidence,
                                        score=float((final_signal.metadata or {}).get('weighted_score', 0.0) or 0.0),
                                        strategies_agreed=str(final_signal.strategy),
                                        dynamic_leverage=5,
                                        bottleneck_gate='AI_BIAS_VETO',
                                        bottleneck_reason="Ngược hướng AI Bias BEARISH toàn sàn. Cấm bắt dao rơi",
                                        readiness_pct=72.0
                                    )
                                except Exception:
                                    pass
                                continue
                            else:
                                logger.info(f"⚡ VƯỢT RÀO AI BIAS CÓ KIỂM SOÁT: Cho phép BUY {final_signal.symbol} do phát hiện bẫy gấu rút chân gom hàng (BEAR_TRAP_WICK, Conf: {final_signal.confidence:.2%})!")
                        elif bias == 'BULLISH' and final_signal.signal.value.upper() == 'SELL':
                            has_trap_wick = isinstance(getattr(final_signal, 'metadata', None), dict) and final_signal.metadata.get('type') == 'BULL_TRAP_WICK'
                            
                            if is_major_gate:
                                # Với Coin Top (BTC, ETH, SOL, BNB, XRP): Tuyệt đối không SHORT khi AI Bias toàn sàn là BULLISH
                                if not (has_trap_wick and final_signal.confidence >= 0.80):
                                    logger.warning(f"🛡️ VETO AI BIAS: Chặn lệnh SELL Coin Top {final_signal.symbol} vì ngược hướng AI bias BULLISH toàn thị trường (Conf: {final_signal.confidence:.2%})!")
                                    continue
                                else:
                                    logger.info(f"⚡ VƯỢT RÀO AI BIAS CÓ KIỂM SOÁT: Cho phép SELL {final_signal.symbol} do phát hiện bẫy tăng xả hàng (BULL_TRAP_WICK, Conf: {final_signal.confidence:.2%})!")
                            else:
                                # Với Altcoin lẻ: Cho phép SHORT nếu có tín hiệu xả mạnh (>= 75%) hoặc Bull Trap
                                is_strong_alt_sell = final_signal.confidence >= 0.75 or has_trap_wick
                                if not is_strong_alt_sell:
                                    logger.warning(f"🛡️ VETO AI BIAS: Chặn lệnh SELL Altcoin {final_signal.symbol} vì tín hiệu chưa đủ mạnh để ngược AI bias BULLISH (Conf: {final_signal.confidence:.2%} < 75%)!")
                                    continue
                                else:
                                    logger.info(f"🎯 CHO PHÉP SHORT ALTCOIN: {final_signal.symbol} có tín hiệu xả mạnh (Conf: {final_signal.confidence:.2%}), cho phép SHORT đón sóng giảm dù BTC đang hồi nhẹ!")
                    else:
                        logger.info(f"🏛️ TRADFI INDEPENDENT GATE: {final_signal.symbol} là Cổ phiếu / Hàng hóa, vận hành độc lập theo phiên Wall Street, không bị ràng buộc bởi Crypto AI Bias ({bias}).")
                        
                    dynamic_position_limit = self._dynamic_open_position_limit(final_signal)
                    if len(self.open_positions) >= dynamic_position_limit:
                        logger.info("⏸️ Chưa đủ chất lượng để thêm vị thế %s: đang có %d, giới hạn động %d/%d.", pair, len(self.open_positions), dynamic_position_limit, configured_max)
                        try:
                            from core.gate_telemetry import record_radar_candidate
                            record_radar_candidate(
                                symbol=final_signal.symbol,
                                side=final_signal.signal.value.upper(),
                                confidence=final_signal.confidence,
                                score=float((final_signal.metadata or {}).get('weighted_score', 0.0) or 0.0),
                                strategies_agreed=str(final_signal.strategy),
                                dynamic_leverage=5,
                                bottleneck_gate='SLOT_CAPACITY',
                                bottleneck_reason=f"Đã đạt giới hạn vị thế ({len(self.open_positions)}/{dynamic_position_limit}). Đang chờ slot trống",
                                readiness_pct=92.0
                            )
                        except Exception:
                            pass
                        continue

                    is_warmup_cycle = (getattr(self, 'cycle_count', 0) <= 1)
                    if is_warmup_cycle and not has_open_pos:
                        logger.info(
                            "🛡️ [LUẬT NGẦM WARM-UP - CHU KỲ #1] %s đạt tín hiệu %s (Độ tin cậy: %.2f%%) nhưng bot đang chạy Chu kỳ #1 Warm-up. "
                            "Tạm khóa mở lệnh mới trong 60s đầu để nạp nóng AI VRAM và đồng bộ nến (Sẵn sàng mở lệnh từ Chu kỳ #2)!",
                            final_signal.symbol, final_signal.signal.value.upper(), final_signal.confidence * 100
                        )
                        continue
                        
                    result = self._execute_signal(final_signal)
                    if result:
                        logger.info(f"✅ Lệnh được thực thi thành công!")
                else:
                    logger.info(f"  ⏳ Chưa đủ điều kiện giao dịch cho {pair}")

                    # PHƯƠNG ÁN A+: HỦY LỆNH RÌNH MỒI NẾU PHÁT HIỆN BẪY RÂU / ĐẢO CHIỀU ĐỐI KHÁNG
                    if pair in getattr(self, 'pending_stalking_orders', {}):
                        stk_chk = self.pending_stalking_orders[pair]
                        stk_dir = stk_chk.get('direction', 'LONG')
                        opp_dir = 'SELL' if stk_dir == 'LONG' else 'BUY'
                        has_opp_trap = any(
                            str(getattr(s, 'strategy', '')).lower() in ('trap_detector', 'trapdetector')
                            and getattr(getattr(s, 'signal', None), 'value', str(getattr(s, 'signal', ''))).upper() == opp_dir
                            and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.60
                            for s in (signals or [])
                        )
                        if has_opp_trap:
                            logger.warning(
                                f"🛡️ [BẪY RÂU ĐẢO CHIỀU - HỦY LỆNH MAKER] {pair}: TrapDetector phát hiện {opp_dir} đối kháng "
                                f"trong khi đang treo lệnh đón lõng {stk_dir}! HỦY LỆNH MAKER NGAY LẬP TỨC ĐỂ BẢO VỆ VỐN!"
                            )
                            oid = stk_chk.get('order_id')
                            if self.mode == 'live' and oid:
                                try:
                                    self.exchange.cancel_order(oid, pair)
                                except Exception as ce:
                                    logger.error(f"Lỗi hủy lệnh rình mồi {pair}: {ce}")
                            self.pending_stalking_orders.pop(pair, None)
                            self._save_state()
                            try:
                                from core.gate_telemetry import clear_radar_candidate
                                clear_radar_candidate(pair)
                            except Exception:
                                pass
                            self._notify_telegram(
                                f"🛡️ **[HỦY LỆNH MAKER - PHÁT HIỆN BẪY RÂU]**\n"
                                f"Cặp: **{pair}** ({stk_dir})\n"
                                f"Phát hiện TrapDetector cảnh báo `{opp_dir}` đối kháng.\n"
                                f"🚪 **Đã chủ động hủy lệnh Limit Maker trước khi bị khớp, triệt tiêu nguy cơ đu đỉnh/đáy!**"
                            )
                    if signals:
                        try:
                            from core.gate_telemetry import record_radar_candidate
                            best_s = max(signals, key=lambda s: getattr(s, 'confidence', 0.0), default=None)
                            if best_s:
                                s_side = getattr(getattr(best_s, 'signal', None), 'value', str(getattr(best_s, 'signal', 'BUY'))).upper()
                                min_strats = int(self.config.get('ai', {}).get('min_agreeing_strategies', 2))
                                agreeing_strats = [
                                    str(getattr(s, 'strategy', 'unknown'))
                                    for s in signals
                                    if getattr(getattr(s, 'signal', None), 'value', str(getattr(s, 'signal', ''))).upper() == s_side
                                ]
                                num_agree = len(agreeing_strats)
                                strats_summary = ", ".join(agreeing_strats[:2]) if agreeing_strats else str(best_s.strategy)

                                # Chỉ đưa vào Ra-đa rình mồi nếu thực sự có chất lượng và tiềm năng khớp lệnh
                                if num_agree >= min_strats:
                                    # Đã đồng thuận đủ số chiến lược nhưng điểm tổng hợp hoặc bộ lọc phụ chưa kích hoạt
                                    readiness = 78.0
                                    gate_reason = f"Đạt {num_agree}/{min_strats} chiến lược ({strats_summary}). Đang tích lũy xung lực"
                                    record_radar_candidate(
                                        symbol=pair,
                                        side=s_side,
                                        confidence=best_s.confidence,
                                        score=float(getattr(best_s, 'score', 0.0) or 0.0),
                                        strategies_agreed=f"{num_agree}/{min_strats} ({strats_summary})",
                                        dynamic_leverage=5,
                                        bottleneck_gate='CONSENSUS_WAIT',
                                        bottleneck_reason=gate_reason,
                                        readiness_pct=readiness
                                    )
                                elif getattr(best_s, 'confidence', 0.0) >= 0.76:
                                    # Chỉ có 1 chiến lược nhưng độ tin cậy rất cao (>= 76%)
                                    readiness = 55.0
                                    gate_reason = f"Mới đạt 1/{min_strats} chiến lược ({best_s.strategy}). Chờ xác nhận chiến lược thứ 2"
                                    record_radar_candidate(
                                        symbol=pair,
                                        side=s_side,
                                        confidence=best_s.confidence,
                                        score=0.0,
                                        strategies_agreed=f"1/{min_strats} ({best_s.strategy})",
                                        dynamic_leverage=5,
                                        bottleneck_gate='CONSENSUS_WAIT',
                                        bottleneck_reason=gate_reason,
                                        readiness_pct=readiness
                                    )
                        except Exception:
                            pass
                    
            except Exception as e:
                logger.error(f"Lỗi trong chu kỳ Pha 2 cho {pair}: {e}", exc_info=True)
                
        # Lưu trạng thái
        self._save_state()
        
        # Log performance
        self._log_performance()

    def _log_performance(self):
        """Log hiệu suất hiện tại."""
        initial = self.config['trading']['initial_capital']
        status = self.get_status()
        equity = status.get('equity')
        pnl = status.get('pnl')
        if equity is None or pnl is None:
            logger.warning("Bỏ qua ghi hiệu suất: chưa lấy được equity chính xác từ tài khoản.")
            return
        equity = float(equity)
        pnl = float(pnl)
        available = status.get('available_balance')
        if available is None:
            available = self.balance
        quote = self.config['trading'].get('base_currency', 'USDT')
        session_net = (equity - initial)
        session_pct = (session_net / initial) * 100 if initial > 0 else 0
        logger.info(f"\n📊 HIỆU SUẤT TÀI KHOẢN:")
        logger.info(f"  💰 Khả dụng: {float(available):.4f} {quote}")
        logger.info(f"  🧾 Equity tài khoản: {equity:.4f} {quote}")
        logger.info(f"  📈 PnL Phiên Hiện Tại: {session_net:+.4f} {quote} ({session_pct:+.2f}%)")
        logger.info(f"  🏛️ PnL Lịch Sử Tích Lũy: {pnl:+.4f} {quote}")
        logger.info(f"  📊 Tổng giao dịch: {self.trade_count}")
        logger.info(f"  📂 Open positions: {len(self.open_positions)}")
        
        # Lưu performance vào database
        try:
            perf = self.db.get_performance_summary()
            self.db.save_performance({
                'date': datetime.now().strftime('%Y-%m-%d'),
                'total_trades': self.trade_count,
                'winning_trades': perf.get('winning_trades', 0),
                'losing_trades': perf.get('losing_trades', 0),
                'total_pnl': pnl,
                'win_rate': perf.get('win_rate', 0),
                'max_drawdown': (self.peak_balance - equity) / self.peak_balance if self.peak_balance > 0 else 0,
                'balance': equity
            })
        except Exception as e:
            logger.debug(f"Lỗi lưu performance: {e}")

    def prepare_to_start(self) -> Optional[str]:
        """Connect and reconcile before allowing the trading loop to start."""
        if not self.exchange_connected and not self.connect():
            return 'Không kết nối được Binance; bot chưa chạy.'
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            if not self.sync_live_positions_with_exchange():
                return 'Không đối soát được vị thế Binance; bot chưa chạy.'
            if self.unreconciled_exchange_positions:
                if self.pending_protection_cleanup:
                    return 'Còn lệnh SL/TP của vị thế đã đóng chưa xác minh hủy; bot chưa chạy và đã khóa lệnh mới. Hãy kiểm tra Binance.'
                return 'Có vị thế Binance chưa đối soát hoặc thiếu xác nhận stop-loss; bot chưa chạy. Hãy kiểm tra Binance hoặc đóng vị thế trên dashboard.'
            if not self.live_balance_synced:
                logger.warning(
                    "Không lấy được số dư LIVE mới nhất; bot sẽ chỉ quản lý vị thế hiện có và khóa lệnh mới."
                )
        return None


    def _auto_adjust_capital(self):
        """Tu dong phat hien nap/rut tien va dieu chinh initial_capital de giu PnL chinh xac."""
        if self.mode != 'live':
            return
            
        try:
            bal = self.exchange.get_futures_balance()
            if not bal or 'margin_balance' not in bal: return
            live_equity = float(bal['margin_balance'])
                
            # Lay PnL tu database de biet loi/lo thuc te
            quote = self.config.get('trading', {}).get('base_currency', 'USDT')
            trades = self.db.get_trades(mode='live', limit=5000, offset=0)
            total_pnl = 0.0
            for trade in trades:
                fee = float(trade.get('fee') or 0) if (trade.get('commission_asset') or quote) == quote else 0.0
                if trade.get('realized_pnl') is not None:
                    row_pnl = float(trade['realized_pnl']) - fee
                elif trade.get('status') == 'open':
                    row_pnl = -fee
                else:
                    row_pnl = float(trade.get('pnl') or 0)
                total_pnl += row_pnl
                
            current_initial = self.config['trading']['initial_capital']
            expected_equity = current_initial + total_pnl
            
            diff = live_equity - expected_equity
            if abs(diff) > 2.0: # Chenh lech tren 2$ duoc coi la nap/rut hoac doi tai khoan
                logger.info(f"🔄 Phat hien Nap/Rut tien (hoac doi API). Chenh lech: {diff:+.2f} {quote}. Dang tu dong cap nhat Von Goc...")
                new_initial = current_initial + diff
                
                # Cap nhat vao in-memory
                self.config['trading']['initial_capital'] = new_initial
                self._live_initial_capital = new_initial
                if diff > 0:
                    self.peak_balance = max(self.peak_balance, live_equity)
                else:
                    self.peak_balance = min(self.peak_balance, live_equity)
                
                # Luu vao settings.yaml
                try:
                    import yaml, os
                    settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
                    with open(settings_path, 'r', encoding='utf-8') as sf:
                        st = yaml.safe_load(sf) or {}
                    if 'trading' not in st: st['trading'] = {}
                    st['trading']['initial_capital'] = new_initial
                    st['trading']['live_initial_capital'] = new_initial
                    with open(settings_path, 'w', encoding='utf-8') as sf:
                        yaml.dump(st, sf, default_flow_style=False, allow_unicode=True)
                    logger.info(f"✅ Da cap nhat Von Goc moi ({new_initial:.2f}) vao settings.yaml de duy tri PnL chinh xac.")
                except Exception as e:
                    logger.error(f"Loi luu initial_capital vao settings.yaml: {e}")
                    
                self._save_state()
        except Exception as e:
            logger.debug(f"Loi tu dong dieu chinh von: {e}")

    def start(self, interval_seconds: int = 300, preflight_done: bool = False):
        """
        Khởi chạy bot liên tục.
        
        Args:
            interval_seconds: Thời gian giữa các chu kỳ (mặc định 5 phút)
        """
        import threading
        start_error = None if preflight_done else self.prepare_to_start()
        if start_error:
            logger.error("Không khởi chạy bot: %s", start_error)
            raise RuntimeError(start_error)
        # Tu dong dieu chinh von neu co nap/rut
        if not preflight_done and self.mode == 'live':
            self._auto_adjust_capital()

        with self._position_lock:
            if self.is_running:
                raise RuntimeError('Bot đã chạy.')
            self.is_running = True
            self._runner_thread = threading.current_thread()
            self._background_threads = []
            # Restored positions get one analysis cycle before discretionary AI
            # reversal exits can act; their stop-loss/take-profit checks still run.
            self._skip_dynamic_exit_cycle = True
        try:
            self.db.cleanup_old_data(30)
        except Exception:
            pass
        self.start_time = datetime.now()
        try:
            import yaml, os
            # Reload settings.yaml
            settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
            with open(settings_path, 'r', encoding='utf-8') as f:
                new_settings = yaml.safe_load(f)
            active_initial_capital = self.config['trading']['initial_capital']
            self.config.update(new_settings)
            # initial_capital is mode-specific in memory and persisted per mode
            # in bot_state; do not replace it with the shared YAML default.
            self.config['trading']['initial_capital'] = active_initial_capital
                
            # Update aggregator threshold dynamically
            if hasattr(self, 'signal_aggregator'):
                self.signal_aggregator.confidence_threshold = self.config.get('ai', {}).get('confidence_threshold', 0.25)
                logger.info(f"🔄 Đã cập nhật AI Confidence Threshold: {self.signal_aggregator.confidence_threshold}")
                
            strat_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'strategies.yaml')
            with open(strat_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f)
            if 'ai_bias' in strat:
                # Keep entry scanning available while background AI refreshes.
                # The deterministic signal, consensus, and risk checks still gate
                # every order; AI can still veto with HIGH_RISK when it returns.
                strat['ai_bias']['direction'] = 'NEUTRAL'
            with open(strat_path, 'w', encoding='utf-8') as f:
                yaml.dump(strat, f, default_flow_style=False, allow_unicode=True)
        except Exception as e:
            logger.error(f"Loi load config/AI Bias: {e}")
        
        logger.info(f"\n{'🚀'*20}")
        logger.info(f"🤖 TRADE BOT BẮT ĐẦU CHẠY!")
        logger.info(f"📊 Chế độ: {'DEMO' if self.mode == 'demo' else 'LIVE'}")
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        logger.info(f"💰 Vốn: {self.balance} {quote}")
        logger.info(f"⏰ Interval: {interval_seconds}s")
        logger.info(f"📋 Pairs: {', '.join(self.config['trading']['pairs'])}")
        logger.info(f"{'🚀'*20}\n")

        if self.mode == 'live':
            resumed_count = len(self.open_positions)
            start_msg = (
                f"▶️ Bot LIVE đã chạy lại và đối soát xong {resumed_count} vị thế đang mở. "
                "Khởi động lại không tự đóng các vị thế này."
            )
            if any(p.get('protection_review_required') or not p.get('sl_order_id') for p in self.open_positions):
                start_msg += " Có vị thế chưa xác nhận SL sàn; hãy kiểm tra Binance trực tiếp."
            self._notify_telegram(start_msg)
         
        # --- BẬT LUỒNG AI CHẠY NGẦM LIÊN TỤC 24/7 ---
        def ai_background_loop():
            import sys, time
            from pathlib import Path
            root_dir = Path(__file__).parent.parent
            if str(root_dir) not in sys.path: sys.path.insert(0, str(root_dir))
            from ai.ollama_agent import OllamaManagerAgent
            
            try:
                llm_agent = OllamaManagerAgent(str(root_dir))
                logger.info("🧠 AI Alpha Generator (Background) đã kích hoạt! Sẽ tự động phân tích và theo dõi tài khoản mỗi 5 phút.")
                while self.is_running:
                    try:
                        llm_agent.analyze_and_tune(bot=self)
                    except Exception as e:
                        logger.error(f"[AI Background] Lỗi khi chạy: {e}")
                    
                    # Cứ 5 phút (300s) AI sẽ theo dõi trạng thái tài khoản và thị trường 1 lần
                    for _ in range(300):
                        if not self.is_running: break
                        time.sleep(1)
            except Exception as e:
                logger.error(f"Lỗi khởi tạo AI Loop: {e}")

        def optimizer_loop():
            import time, os
            if not self.config.get('optimizer', {}).get('enabled', False):
                logger.info("Auto-optimizer đang tắt; chỉ chạy khi được bật rõ ràng trong cấu hình.")
                return
            from core.optimizer import StrategyOptimizer
            config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
            optimizer = StrategyOptimizer(config_path)
            while self.is_running:
                try:
                    now_ts = time.time()
                    if now_ts - self.last_optimized >= 86400: # 24 hours
                        logger.info("⚙️ Đang chạy Bộ Tối ưu hóa Thuật Toán (Auto-Tuning) cho ngày mới...")
                        optimizer.run_optimization()
                        self.last_optimized = now_ts
                        logger.info("✅ Đã cập nhật thông số chiến lược mới nhất!")
                except Exception as e:
                    logger.error(f"[Optimizer] Lỗi: {e}")
                
                for _ in range(3600): # check every hour
                    if not self.is_running: break
                    time.sleep(1)

        import threading
        self._position_monitor_stop.clear()
        monitor_thread = threading.Thread(
            target=self._position_management_loop,
            name='position-management-monitor',
            daemon=True,
        )
        self._position_monitor_thread = monitor_thread
        monitor_thread.start()
        logger.info(
            "🛡️ Luồng quản lý vị thế độc lập đang chạy mỗi %ss; không phụ thuộc chu kỳ quét/AI.",
            self.config.get('risk', {}).get('position_monitor_interval_seconds', 10),
        )
        ai_thread = threading.Thread(target=ai_background_loop, daemon=True)
        ai_thread.start()
        opt_thread = threading.Thread(target=optimizer_loop, daemon=True)
        opt_thread.start()
        self._background_threads = [monitor_thread, ai_thread, opt_thread]
        # ---------------------------------------------
        
        cycle_count = 0
        self.cycle_count = 0
        last_history_sync = 0.0

        # Nạp nóng (Pre-warm) model AI Ollama vào GPU VRAM ngay khi mở bot để triệt tiêu độ trễ
        def _prewarm_ollama():
            try:
                import requests
                ollama_url = getattr(self, 'jev_agent', None) and getattr(self.jev_agent, 'endpoint', 'http://localhost:11434/api/generate') or 'http://localhost:11434/api/generate'
                model_name = self.config.get('ai', {}).get('ollama_model', 'qwen2.5:7b')
                requests.post(ollama_url, json={"model": model_name, "prompt": "hi", "stream": False}, timeout=15)
                logger.info("⚡ [PRE-WARM] Đã nạp nóng model AI %s vào GPU VRAM sẵn sàng!", model_name)
            except Exception:
                pass
        threading.Thread(target=_prewarm_ollama, name='ollama-prewarm', daemon=True).start()
        
        while self.is_running:
            try:
                if not self.exchange.check_connection():
                    self.exchange_connected = False
                    if not self.connect():
                        logger.error("Binance vẫn mất kết nối; thử lại sau 60 giây, không phân tích/lệnh mới.")
                        time.sleep(60)
                        continue
                else:
                    self.exchange_connected = True

                if self.mode == 'live' and time.monotonic() - last_history_sync >= 900:
                    history_thread = threading.Thread(
                        target=self.sync_live_trades_from_exchange,
                        name='live-trade-history-sync', daemon=True,
                    )
                    self._background_threads.append(history_thread)
                    history_thread.start()
                    last_history_sync = time.monotonic()
                cycle_count += 1
                self.cycle_count = cycle_count
                logger.info(f"\n🔄 === Chu kỳ #{cycle_count} ===")
                if cycle_count == 1:
                    logger.info("🛡️ [LUẬT NGẦM WARM-UP] Kích hoạt Chu kỳ #1: Đang nạp nóng bộ nhớ AI, đồng bộ nến 50 cặp coin và đối soát vị thế...")
                
                self.run_cycle()
                
                # Chờ đến chu kỳ tiếp theo
                logger.info(f"\n⏳ Chờ {interval_seconds}s đến chu kỳ tiếp theo...")
                
                # Sleep có thể bị interrupt
                for i in range(interval_seconds):
                    if not self.is_running:
                        break
                    time.sleep(1)
                    
            except KeyboardInterrupt:
                logger.info("\n⛔ Bot dừng bởi người dùng (Ctrl+C)")
                self.stop()
                break
            except Exception as e:
                logger.error(f"Lỗi trong chu kỳ #{cycle_count}: {e}")
                logger.info("⏳ Chờ 60s trước khi thử lại...")
                time.sleep(60)

        self._runner_thread = None

    def stop(self):
        """Dừng bot an toàn."""
        with self._position_lock:
            self.is_running = False
            self._position_monitor_stop.set()
            # Hủy các lệnh rình mồi Limit Maker còn chờ trên Binance để tránh khớp không người giám sát
            if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                for sym, stk in list(getattr(self, 'pending_stalking_orders', {}).items()):
                    oid = stk.get('order_id')
                    if oid:
                        try:
                            self.exchange.cancel_order(oid, sym)
                            logger.info(f"Đã hủy lệnh rình mồi {sym} khi dừng bot.")
                        except Exception as ce:
                            logger.error(f"Lỗi hủy lệnh rình mồi {sym} khi dừng bot: {ce}")
            if hasattr(self, 'pending_stalking_orders'):
                self.pending_stalking_orders.clear()
            self._save_state()
            positions_at_stop = [dict(position) for position in self.open_positions]
        
        logger.info(f"\n{'⛔'*20}")
        logger.info(f"🤖 TRADE BOT ĐÃ DỪNG")
        if self.start_time:
            runtime = datetime.now() - self.start_time
            logger.info(f"⏱️ Thời gian chạy: {runtime}")
        initial = self.config['trading']['initial_capital']
        status = self.get_status()
        equity = status.get('equity')
        pnl = status.get('pnl')
        available = status.get('available_balance')
        if available is None:
            available = self.balance
        quote = self.config['trading'].get('base_currency', 'USDT')
        equity_text = f"{float(equity):.4f}" if equity is not None else "chưa lấy được"
        pnl_text = f"{float(pnl):+.4f} {quote} ({(float(pnl)/initial)*100:+.2f}%)" if pnl is not None and initial > 0 else "chưa lấy được"
        logger.info(f"💰 Khả dụng cuối: {float(available):.4f} {quote}")
        logger.info(f"🧾 Equity Futures cuối: {equity_text} {quote}")
        logger.info(f"📈 PnL so với vốn gốc: {pnl_text}")
        logger.info(f"📊 Tổng giao dịch: {self.trade_count}")
        logger.info(f"{'⛔'*20}\n")
        
        # Gửi thông báo Telegram khi bot dừng
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        stop_msg = (
            f"⛔ **TRADE BOT ĐÃ DỪNG**\n"
            f"🕒 **Thời gian tắt:** {current_time}\n"
            f"🔹 **Chế độ:** {mode_str}\n"
            f"🔹 **Thời gian chạy:** {runtime if self.start_time else 'Không rõ'}\n"
            f"🔹 **Khả dụng cuối:** {float(available):.4f} {quote}\n"
            f"🔹 **Equity Futures:** {equity_text} {quote}\n"
            f"🔹 **PnL so với vốn gốc:** {pnl_text}\n"
            f"🔹 **Vị thế còn mở:** {len(positions_at_stop)} (nút Dừng không tự đóng vị thế)\n"
            f"🔹 **Trạng thái:** Bot đã dừng; vị thế và lệnh bảo vệ trên Binance được giữ nguyên."
        )
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            missing_stop = [
                f"{p.get('direction', 'LONG')} {p.get('symbol')}"
                for p in positions_at_stop if not p.get('sl_order_id')
            ]
            if missing_stop:
                stop_msg += "\n⚠️ Chưa xác nhận SL sàn cho: " + ', '.join(missing_stop) + ". Kiểm tra Binance trực tiếp."
        self._notify_telegram(stop_msg)

    def switch_mode(self, mode: str, api_key: str = None, api_secret: str = None):
        """
        Chuyển đổi giữa chế độ demo và live.
        """
        import threading
        if mode not in ('demo', 'live'):
            raise ValueError("Chế độ chỉ có thể là 'demo' hoặc 'live'.")
        if self.is_running:
            raise RuntimeError("Hãy dừng bot trước khi đổi chế độ để tránh đổi sàn giữa một chu kỳ.")
        current_thread = threading.current_thread()
        active_threads = [
            thread for thread in [self._runner_thread, *self._background_threads]
            if thread is not None and thread is not current_thread and thread.is_alive()
        ]
        if active_threads:
            raise RuntimeError("Các luồng bot cũ vẫn đang kết thúc; hãy đợi chúng dừng hẳn rồi đổi chế độ.")
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            if not self.sync_live_positions_with_exchange():
                raise RuntimeError("Không đối soát được vị thế Binance; không thể đổi chế độ an toàn.")
            if self.unreconciled_exchange_positions:
                raise RuntimeError("Còn vị thế hoặc lệnh bảo vệ LIVE chưa đối soát; không thể đổi chế độ.")
        if self.open_positions:
            raise RuntimeError("Không thể đổi chế độ khi còn vị thế được tool theo dõi; hãy đóng hoặc đối soát trước.")

        live_equity = None
        if mode == 'live':
            import os
            from pathlib import Path
            from dotenv import load_dotenv
            try:
                _env_f = Path(__file__).resolve().parent.parent / '.env'
                if _env_f.exists():
                    load_dotenv(_env_f)
            except Exception:
                pass
            
            current_key = self.config['exchange'].get('api_key', '') or os.getenv('BINANCE_API_KEY', '')
            current_secret = self.config['exchange'].get('api_secret', '') or os.getenv('BINANCE_API_SECRET', '')
            
            use_key = api_key if api_key else current_key
            use_secret = api_secret if api_secret else current_secret
            
            if not use_key or not use_secret:
                raise ValueError("Cần API key và secret để chuyển sang chế độ live!")
                
            self.config['exchange']['api_key'] = use_key
            self.config['exchange']['api_secret'] = use_secret
            
            logger.warning("⚠️ CẢNH BÁO: Đã chuyển sang LIVE TRADING! Sẽ sử dụng tiền thật.")
            
            self.config['exchange']['api_key'] = use_key
            self.config['exchange']['api_secret'] = use_secret
            # Luôn dùng testnet = false để lấy data thật
            self.config['exchange']['testnet'] = False
        else:
            logger.info("🔄 Đã chuyển sang DEMO (Paper Trading).")
            # Vẫn giữ testnet = False để demo trên dữ liệu thật
            self.config['exchange']['testnet'] = False
        
        mode_initial_capital = (
            self._demo_initial_capital if mode == 'demo' else self._live_initial_capital
        )
        self.config['trading']['initial_capital'] = mode_initial_capital
        if mode == 'demo':
            self.balance = mode_initial_capital
            demo_state = self.db.get_bot_state('demo') if hasattr(self, 'db') and hasattr(self.db, 'get_bot_state') else None
            self.peak_balance = max(float(demo_state.get('peak_balance', 0)) if demo_state else 0, mode_initial_capital)

        self.mode = mode
        active_cds = {
            self._clean_symbol(symbol): expires_at
            for symbol, expires_at in self.db.get_symbol_cooldowns(mode).items()
        }
        self._manual_exit_cooldowns = dict(active_cds)
        self._symbol_cooldowns = dict(active_cds)
        self.config['bot']['mode'] = mode
        
        # Reinitialize exchange (luôn lưu config mới)
        self.exchange = ExchangeConnector(self.config)
        self.order_manager = OrderManager(self.exchange, self.db, self.mode)
        self.scanner.exchange = self.exchange
        self.data_collector.exchange = self.exchange

        self.exchange_connected = self.exchange.connect()
        if not self.exchange_connected:
            raise RuntimeError("Không kết nối được Binance sau khi đổi chế độ.")
        
        # Đồng bộ số dư nếu là live
        if mode == 'live':
            self.live_balance_synced = False
            self._detect_base_currency()
            base_currency = self.config['trading'].get('base_currency', 'USDT')
            try:
                if getattr(self, 'market_type', 'spot') == 'futures':
                    bal = self.exchange.get_futures_balance()
                    free_bal = bal.get(base_currency, {}).get('free', 0) if isinstance(bal.get(base_currency), dict) else bal.get('free', 0)
                    total_bal = bal.get(base_currency, {}).get('total', 0) if isinstance(bal.get(base_currency), dict) else bal.get('total', 0)
                else:
                    bal = self.exchange.get_balance()
                    free_bal = bal.get(base_currency, {}).get('free', 0)
                    total_bal = bal.get(base_currency, {}).get('total', 0)

                free_bal = float(free_bal)
                total_bal = float(total_bal)
                if not math.isfinite(free_bal) or free_bal < 0 or not math.isfinite(total_bal) or total_bal <= 0:
                    raise ValueError("Binance trả số dư không hợp lệ; giữ nguyên vốn đã lưu.")
                
                # self.balance luôn là số dư khả dụng (Free Margin)
                self.balance = free_bal
                self.peak_balance = free_bal
                live_equity = total_bal
                self.live_balance_synced = True
                quote = self.config['trading'].get('base_currency', 'USDT')
                logger.info(f"💰 Đã đồng bộ số dư Live thật: {self.balance} {quote}")
            except Exception as e:
                logger.error(f"Lỗi đồng bộ số dư live: {e}")

        if mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            if not self.sync_live_positions_with_exchange():
                raise RuntimeError("Không đối soát được vị thế futures Binance; chưa thể chuyển sang live an toàn.")
        
        logger.info(f"✅ Đã cấu hình xong chế độ: {mode.upper()}")
        
        # Gửi thông báo chuyển đổi chế độ
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        switch_msg = (
            f"🔄 **CHUYỂN ĐỔI CHẾ ĐỘ THÀNH CÔNG**\n"
            f"🔹 **Chế độ mới:** {mode_str}\n"
            f"🔹 **Thị trường:** {getattr(self, 'market_type', 'spot').upper()}\n"
            f"🔹 **Đòn bẩy:** {getattr(self, 'leverage', 1)}x\n"
            f"🔹 **Số dư khả dụng:** {self.balance:.2f} {self.config['trading'].get('base_currency', 'USDT')}"
        )
        self._notify_telegram(switch_msg)

        self._restore_state()
        if not self.sync_live_positions_with_exchange():
            raise RuntimeError("Không đối soát được vị thế sau khi đổi chế độ; bot vẫn phải giữ trạng thái dừng.")
            
        self._auto_adjust_capital()

        if mode == 'live' and live_equity is not None:
            # Load peak_balance from DB for live mode instead of using demo mode's peak
            live_state = self.db.get_bot_state('live') if hasattr(self.db, 'get_bot_state') else None
            db_peak = float(live_state.get('peak_balance', 0)) if live_state else 0
            if db_peak == 1000.0 and live_equity < 500:
                db_peak = live_equity # Ignore leaked demo peak
            self.peak_balance = max(db_peak, live_equity)
            self._save_state()

        # Persist the selected mode, but never persist API credentials or start state.
        try:
            import re
            config_path = Path(self.config_path)
            lines = config_path.read_text(encoding='utf-8').splitlines(keepends=True)
            bot_index = next(
                (i for i, line in enumerate(lines)
                 if line.split('#', 1)[0].strip() == 'bot:'
                 and not line[:len(line) - len(line.lstrip(' \t'))]),
                None,
            )
            if bot_index is None:
                if lines and not lines[-1].endswith(('\n', '\r')):
                    lines[-1] += '\n'
                lines.extend(['bot:\n', f'  mode: {mode}\n'])
            else:
                bot_indent = len(lines[bot_index]) - len(lines[bot_index].lstrip(' \t'))
                section_end = len(lines)
                mode_index = None
                for i in range(bot_index + 1, len(lines)):
                    line = lines[i]
                    stripped = line.strip()
                    if not stripped or stripped.startswith('#'):
                        continue
                    indent = len(line) - len(line.lstrip(' \t'))
                    if indent <= bot_indent:
                        section_end = i
                        break
                    if re.match(r'^[ \t]+mode\s*:', line):
                        mode_index = i
                        break

                if mode_index is not None:
                    line = lines[mode_index]
                    match = re.match(r'^([ \t]+mode\s*:\s*)([^#\r\n]*?)(\s+#.*)?(\r?\n)?$', line)
                    if not match:
                        raise ValueError('Không thể cập nhật bot.mode mà vẫn giữ nguyên định dạng YAML.')
                    lines[mode_index] = f'{match.group(1)}{mode}{match.group(3) or ""}{match.group(4) or ""}'
                else:
                    lines.insert(section_end, f'{" " * (bot_indent + 2)}mode: {mode}\n')

            config_path.write_text(''.join(lines), encoding='utf-8')
        except Exception as e:
            logger.error("Không lưu được chế độ %s cho lần mở tool sau: %s", mode.upper(), e)

        if mode == 'live':
            import threading
            threading.Thread(
                target=self.sync_live_trades_from_exchange,
                name='live-trade-history-sync', daemon=True,
            ).start()

    def sync_live_trades_from_exchange(self):
        if self.mode != 'live' or not self._history_sync_lock.acquire(blocking=False):
            return 0
        try:
            return self._sync_live_trades_from_exchange()
        finally:
            self._history_sync_lock.release()

    def _sync_exchange_trade_history(self):
        return self.sync_live_trades_from_exchange()

    def _sync_live_trades_from_exchange(self):
        """Incrementally sync Binance fills for configured and dynamically traded symbols."""
        if self.mode != 'live':
            return 0
        logger.info("Đang lấy lịch sử giao dịch từ sàn (Live)...")
        base = self.config.get('trading', {}).get('base_currency', 'USDT')
        symbols = set(self.config.get('trading', {}).get('pairs', []))
        symbols.update(self.db.get_trade_symbols('live'))
        symbols.update(p.get('symbol') for p in self.open_positions if p.get('symbol'))

        # Binance's USD-M user-trades endpoint requires a symbol. Include every
        # market this bot has traded, including dynamic-scanner symbols.
        canonical_symbols = set()
        for symbol in symbols:
            clean = str(symbol).split(':')[0]
            parts = clean.split('/')
            if len(parts) > 2 and parts[-1] == base:
                clean = '/'.join(parts[:-1])
                parts = clean.split('/')
            if len(parts) == 1 and clean.endswith(base):
                clean = clean[:-len(base)] + '/' + base
            if len(clean.split('/')) == 2:
                canonical_symbols.add(clean)

        now_ms = int(time.time() * 1000)
        earliest_ms = now_ms - 89 * 24 * 60 * 60 * 1000
        synced = 0
        failures = 0

        # Binance Futures user-trades endpoint requires a symbol.
        # Use Binance's native high-speed income ledger (fapiPrivateGetIncome) to discover
        # 100% of symbols traded on this account across the full 89-day window in 0.5s!
        if getattr(self, 'market_type', 'spot') == 'futures' and not self._history_market_discovery_done:
            discovered = 0
            try:
                income_data = self.exchange.exchange.fapiPrivateGetIncome({'limit': 1000})
                income_symbols = {r.get('symbol') for r in income_data if r.get('symbol')}
                for isym in income_symbols:
                    if isym.endswith(base):
                        clean_pair = isym[:-len(base)] + '/' + base
                        canonical_symbols.add(clean_pair)
                        discovered += 1
                logger.info(f"⚡ [SMART SYNC] Dò tìm tức thì từ sổ cái Binance: tìm thấy {discovered} symbol có lịch sử giao dịch.")
                self._history_market_discovery_done = True
            except Exception as e:
                logger.warning(f"Không thể dò symbol qua fapiPrivateGetIncome: {e}; dùng danh sách symbol hiện có.")
                self._history_market_discovery_done = True

        for symbol in sorted(canonical_symbols):
            ccxt_symbol = self.exchange._get_ccxt_symbol(symbol)
            last_saved = self.db.get_latest_exchange_trade_timestamp('live', symbol)
            cursor_ms = max(earliest_ms, (last_saved - 60_000) if last_saved else earliest_ms)
            try:
                while cursor_ms < now_ms:
                    end_ms = min(cursor_ms + 7 * 24 * 60 * 60 * 1000 - 1, now_ms)
                    next_id = None
                    while True:
                        if next_id is None:
                            page = self.exchange.exchange.fetch_my_trades(
                                ccxt_symbol, since=cursor_ms, limit=1000,
                                params={'endTime': end_ms},
                            )
                        else:
                            page = self.exchange.exchange.fetch_my_trades(
                                ccxt_symbol, limit=1000, params={'fromId': next_id},
                            )
                        if not page:
                            break
                        page.sort(key=lambda t: (t.get('timestamp') or 0, str(t.get('id') or '')))
                        for trade in page:
                            info = trade.get('info') or {}
                            timestamp = trade.get('timestamp') or info.get('time') or info.get('T') or now_ms
                            if int(timestamp) > end_ms:
                                continue
                            fee_info = trade.get('fee') or {}
                            realized = info.get('realizedPnl', trade.get('realizedPnl', 0)) or 0
                            try:
                                realized = float(realized)
                            except (TypeError, ValueError):
                                realized = 0.0
                            self.db.save_trade({
                                'timestamp': int(timestamp),
                                'symbol': (trade.get('symbol') or symbol).split(':')[0],
                                'side': (trade.get('side') or ('buy' if info.get('buyer') else 'sell')).upper(),
                                'type': trade.get('type') or info.get('type') or 'market',
                                'price': trade.get('price') or info.get('price'),
                                'amount': trade.get('amount') or info.get('qty'),
                                'cost': trade.get('cost') or info.get('quoteQty'),
                                'fee': fee_info.get('cost', info.get('commission')),
                                'commission_asset': fee_info.get('currency') or info.get('commissionAsset'),
                                'pnl': realized,
                                'realized_pnl': realized,
                                'strategy': 'Binance Fill',
                                'status': 'closed',
                                'order_id': trade.get('order') or info.get('orderId'),
                                'exchange_trade_id': trade.get('id') or info.get('id'),
                                'client_order_id': info.get('clientOrderId'),
                                'position_side': info.get('positionSide'),
                                'maker': trade.get('takerOrMaker') == 'maker' if trade.get('takerOrMaker') else info.get('maker'),
                                'raw': info,
                                'mode': 'live',
                            })
                            synced += 1
                        if len(page) < 1000 or (page[-1].get('timestamp') or 0) > end_ms:
                            break
                        last_id = page[-1].get('id') or (page[-1].get('info') or {}).get('id')
                        try:
                            next_id = int(last_id) + 1
                        except (TypeError, ValueError):
                            logger.error(f"Không thể phân trang trade ID của {symbol}; cần đồng bộ lại thủ công.")
                            break
                    cursor_ms = end_ms + 1
            except Exception as e:
                failures += 1
                logger.warning(f"Không thể đồng bộ lịch sử {symbol}: {e}")

        logger.info(
            f"✅ Đồng bộ {synced} fills LIVE (tối đa 89 ngày, có khử trùng lặp); "
            f"lỗi {failures}/{len(canonical_symbols)} cặp."
        )
        return synced


    def sync_live_positions_with_exchange(self) -> bool:
        with self._position_lock:
            return self._sync_live_positions_with_exchange_locked()

    def _sync_live_positions_with_exchange_locked(self) -> bool:
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures':
            return True
            
        try:
            exchange_positions = self.exchange.get_futures_positions()
            active_exchange_pos = {}
            unresolved_exchange_position = False
            for p in exchange_positions:
                sym = p.get('symbol', '')
                direction = self._exchange_position_direction(p)
                if sym and direction:
                    active_exchange_pos[(self._clean_symbol(sym), direction)] = p
                else:
                    unresolved_exchange_position = True
                    logger.critical("Không xác định được mã/chiều vị thế Binance %s; khóa lệnh mới.", sym or '<unknown>')

            pending_before = list(self.pending_protection_cleanup)
            pending_remaining = []
            cleanup_blocked = False
            for pending_position in pending_before:
                pending_symbol = pending_position.get('symbol')
                pending_direction = pending_position.get('direction', 'LONG')
                pending_key = (self._clean_symbol(pending_symbol), pending_direction)
                if pending_key in active_exchange_pos:
                    # A same-direction position reappeared before the old order
                    # cleanup was verified. Do not cancel protection under it;
                    # require review before allowing another bot entry.
                    pending_remaining.append(pending_position)
                    cleanup_blocked = True
                    logger.critical(
                        "Còn lệnh bảo vệ chờ dọn cho %s trong khi vị thế cùng chiều đã xuất hiện; khóa lệnh mới.",
                        pending_symbol,
                    )
                    continue
                warnings = self._retry_pending_protection_cleanup(
                    pending_position, pending_direction
                )
                if warnings:
                    pending_remaining.append(pending_position)
                    cleanup_blocked = True
                    logger.critical(
                        "Chưa xác minh dọn hết lệnh SL/TP cũ của %s: %s; khóa lệnh mới và sẽ thử lại.",
                        pending_symbol, ', '.join(warnings),
                    )
                else:
                    logger.info(
                        "Đã xác minh hủy hết lệnh bảo vệ còn lại của vị thế %s đã đóng.",
                        pending_symbol,
                    )

            pending_keys = {
                (self._clean_symbol(item.get('symbol')), item.get('direction', 'LONG'))
                for item in pending_remaining
            }
            cleanup_state_changed = pending_remaining != pending_before
                 
            # 1. KHỬ TRÙNG LẶP NỘI BỘ TRƯỚC KHI ĐỐI SOÁT (INTERNAL DEDUPLICATION):
            # Nếu có nhiều bản ghi cùng một cặp và cùng chiều (do race condition khi M1 vừa khớp),
            # ưu tiên giữ lại vị thế có sl_order_id hợp lệ và không phải là 'exchange_reconciled'
            deduped_raw = []
            seen_raw_keys = set()
            sorted_raw = sorted(
                self.open_positions,
                key=lambda item: (
                    1 if item.get('sl_order_id') else 0,
                    0 if str(item.get('strategy', '')) == 'exchange_reconciled' or str(item.get('symbol', '')).endswith(':USDT') else 1
                ),
                reverse=True
            )
            for item in sorted_raw:
                k = (self._clean_symbol(item.get('symbol')), item.get('direction', 'LONG'))
                if k not in seen_raw_keys:
                    seen_raw_keys.add(k)
                    deduped_raw.append(item)
                else:
                    removed = True
                    logger.info("🧹 [DEDUPLICATE] Đã xóa vị thế bóng ma trùng lặp %s (%s, strategy=%s) khỏi bộ nhớ!", item.get('symbol'), item.get('direction'), item.get('strategy'))
            self.open_positions = deduped_raw

            positions_to_keep = []
            removed = False
            matched_exchange_positions = set()
            for p in self.open_positions:
                position_key = (
                    self._clean_symbol(p['symbol']),
                    p.get('direction', 'LONG'),
                )
                if position_key in active_exchange_pos:
                    # Cập nhật số liệu thực tế từ sàn (Entry, PnL, Margin)
                    real_pos = active_exchange_pos[position_key]
                    matched_exchange_positions.add(position_key)
                    if real_pos.get('entryPrice'):
                        p['entry_price'] = float(real_pos['entryPrice'])
                    
                    # Update real amount, pnl and cost if CCXT provides it
                    contracts = real_pos.get('contracts') or real_pos.get('info', {}).get('positionAmt')
                    if contracts:
                        p['amount'] = abs(float(contracts))
                        
                    upnl = real_pos.get('unrealizedPnl') or real_pos.get('info', {}).get('unRealizedProfit')
                    if upnl is not None:
                        p['real_pnl'] = float(upnl)
                        
                    margin = real_pos.get('initialMargin') or real_pos.get('info', {}).get('initialMargin')
                    if margin is not None:
                        p['cost'] = float(margin)
                    
                    positions_to_keep.append(p)
                else:
                    logger.warning(f"Vị thế {p['symbol']} không còn tồn tại trên Binance (Đã đóng thủ công hoặc hit SL/TP). Tiến hành xóa khỏi bộ nhớ Bot.")
                    self._handle_externally_closed_position(p)
                    removed = True
                    if position_key not in pending_keys:
                        warnings = self._retry_pending_protection_cleanup(
                            p, p.get('direction', 'LONG')
                        )
                        if warnings:
                            pending_remaining.append(dict(p))
                            pending_keys.add(position_key)
                            cleanup_blocked = True
                            cleanup_state_changed = True
                            logger.critical(
                                "Vị thế %s đã đóng nhưng lệnh bảo vệ chưa dọn xác minh: %s; khóa lệnh mới.",
                                p['symbol'], ', '.join(warnings),
                            )
                        else:
                            logger.info(
                                "Đã xác minh dọn các lệnh SL/TP còn lại của %s sau khi vị thế đóng.",
                                p['symbol'],
                            )
                    else:
                        cleanup_blocked = True

            self.pending_protection_cleanup = pending_remaining
            self.unreconciled_exchange_positions = unresolved_exchange_position or cleanup_blocked
            for position_key, real_pos in active_exchange_pos.items():
                if position_key in matched_exchange_positions:
                    continue

                # KIỂM TRA M1 SNIPER ĐANG RÌNH (PENDING STALKING GUARDIAN):
                clean_sym_ex = position_key[0]
                is_in_stalking = any(
                    self._clean_symbol(stalk_sym) == clean_sym_ex
                    for stalk_sym in getattr(self, 'pending_stalking_orders', {})
                )
                if is_in_stalking:
                    logger.info(
                        "⏳ Vị thế %s vừa khớp trên sàn đang chờ M1 Sniper hoàn tất đặt lệnh Stop-Loss. Tạm hoãn nhận diện reconciled.",
                        real_pos.get('symbol')
                    )
                    continue

                symbol = str(real_pos.get('symbol') or '')
                direction = position_key[1]
                info = real_pos.get('info') or {}
                amount = abs(float(real_pos.get('contracts') or info.get('positionAmt') or 0))
                entry_price = float(real_pos.get('entryPrice') or info.get('entryPrice') or 0)
                if not symbol or amount <= 0 or entry_price <= 0:
                    self.unreconciled_exchange_positions = True
                    logger.critical("Không đủ dữ liệu để nhận diện vị thế Binance %s; khóa lệnh mới.", position_key)
                    continue

                try:
                    stop_pct = float(self.config.get('risk', {}).get('stop_loss_pct', 0.04))
                    if not math.isfinite(stop_pct) or not 0 < stop_pct < 1:
                        stop_pct = 0.04
                    take_pct = float(self.config.get('risk', {}).get('take_profit_pct', 0.08))
                    if not math.isfinite(take_pct) or not 0 < take_pct < 1:
                        take_pct = 0.08
                    leverage = max(
                        1.0,
                        float(real_pos.get('leverage') or info.get('leverage') or getattr(
                            self, 'leverage', self.config.get('trading', {}).get('leverage', 1)
                        )),
                    )
                    margin = real_pos.get('initialMargin') or info.get('initialMargin')
                    cost = float(margin) if margin not in (None, '') else 0.0
                    if cost <= 0:
                        cost = amount * entry_price / leverage

                    is_adopted = False
                    adopted_sl_id = None
                    sl_price = entry_price * (1 - stop_pct if direction == 'LONG' else 1 + stop_pct)
                    
                    if self.auto_adopt_manual_positions:
                        # 1. Tra cứu xem trên Binance đã có sẵn lệnh Stop-Loss của cặp này chưa
                        found_sl_id = None
                        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                            try:
                                orders = self.exchange.get_open_orders(symbol, trigger=True, strict=False)
                                for o in orders:
                                    o_info = o.get('info') or {}
                                    o_type = str(o.get('type') or o_info.get('type') or o_info.get('origType') or '').upper()
                                    o_side = str(o.get('side') or o_info.get('side') or '').lower()
                                    target_close_side = 'sell' if direction == 'LONG' else 'buy'
                                    if ('STOP' in o_type) and (o_side == target_close_side):
                                        found_sl_id = str(o.get('id') or o_info.get('orderId') or o_info.get('algoId') or '')
                                        stop_trigger_p = float(o.get('stopPrice') or o_info.get('stopPrice') or 0)
                                        if stop_trigger_p > 0:
                                            sl_price = stop_trigger_p
                                        break
                            except Exception as oe:
                                logger.warning(f"Không thể tra cứu lệnh điều kiện sẵn có của {symbol}: {oe}")
                        
                        # 2. Nếu chưa có SL trên sàn, tự động gửi lệnh STOP_MARKET lên Binance bảo hiểm vốn
                        if not found_sl_id and self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                            try:
                                close_side = 'sell' if direction == 'LONG' else 'buy'
                                new_sl_order = self.exchange.create_stop_market_order(symbol, close_side, amount, sl_price)
                                sl_info = (new_sl_order or {}).get('info') or {}
                                found_sl_id = str((new_sl_order or {}).get('id') or sl_info.get('algoId') or sl_info.get('orderId') or '')
                            except Exception as se:
                                logger.error(f"Lỗi đặt Stop-Loss tự động bảo hiểm cho lệnh tay {symbol}: {se}")
                                
                        if found_sl_id:
                            is_adopted = True
                            adopted_sl_id = found_sl_id

                    tracked = {
                        'symbol': symbol,
                        'direction': direction,
                        'entry_price': entry_price,
                        'amount': amount,
                        'cost': cost,
                        'leverage': leverage,
                        'stop_loss': sl_price,
                        'take_profit': entry_price * (1 + take_pct if direction == 'LONG' else 1 - take_pct),
                        'order_id': f"manual-adopted-{int(time.time() * 1000)}" if is_adopted else f"exchange-reconciled-{int(time.time() * 1000)}",
                        'strategy': 'manual_adopted' if is_adopted else 'exchange_reconciled',
                        'market_type': 'futures',
                        'entry_fee': 0.0,
                        'sl_order_id': adopted_sl_id,
                        'tp_order_id': None,
                        'trailing_stop': None,
                        'trailing_best_price': entry_price,
                        'trailing_active': False,
                        'trailing_status': 'exchange_stop' if is_adopted else 'protection_unavailable',
                        'trailing_distance_pct': None,
                        'trailing_atr_pct': None,
                        'trailing_adx': None,
                        'trailing_regime': 'not_calculated',
                        'trailing_net_breakeven': None,
                        'reconciled_from_exchange': not is_adopted,
                    }
                    if is_adopted:
                        tracked['protection_status'] = 'exchange_stop_verified'

                    positions_to_keep.append(tracked)
                    matched_exchange_positions.add(position_key)
                    removed = True
                    
                    if is_adopted:
                        self._notify_telegram(
                            f"🛡️ **[TỰ ĐỘNG BẢO HỘ & QUẢN LÝ LỆNH TAY]**\n"
                            f"Cặp: **{symbol}** ({direction})\n"
                            f"Khối lượng: `{amount:g}` coin | Giá vào: `{entry_price:.6g}`\n"
                            f"🛡️ **Đã đặt Stop-Loss bảo hiểm sàn tại:** `{sl_price:.6g}` (Order ID: `{adopted_sl_id}`)\n"
                            f"🚀 **Đã kích hoạt:** Trailing Stop bám đỉnh, Chốt lời 50% tiền tươi (+1.10%) và Cắt giảm tải 0.65 ATR!"
                        )
                        logger.info(
                            "🎯 Đã tiếp quản và kích hoạt bảo hộ tự động cho lệnh tay: %s %s (SL ID: %s)",
                            direction, symbol, adopted_sl_id
                        )
                    else:
                        self._notify_telegram(
                            f"⚠️ Đã phát hiện vị thế LIVE chưa có trong trạng thái tool: {direction} {symbol}, "
                            f"số lượng {amount:g}. Tool đã đưa vị thế vào dashboard để tránh vào trùng; "
                            "hãy kiểm tra lệnh bảo vệ SL/TP trực tiếp trên Binance."
                        )
                        logger.critical(
                            "Nhận diện vị thế Binance chưa được tool theo dõi: %s %s; cần kiểm tra SL/TP trên sàn.",
                            direction, symbol,
                        )
                except (TypeError, ValueError, OverflowError) as e:
                    self.unreconciled_exchange_positions = True
                    logger.critical("Không thể nhập vị thế Binance %s vào trạng thái tool: %s", position_key, e)
             
            self.open_positions = positions_to_keep

            # A recovered position without its saved stop ID has unknown
            # protection. Do not use synthesized local levels to close it or
            # permit new entries until the position is manually reviewed.
            protection_review = False
            if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                protection_review = self._verify_live_position_protection(positions_to_keep)
                self.unreconciled_exchange_positions = (
                    self.unreconciled_exchange_positions or protection_review
                )
                if protection_review:
                    logger.critical(
                        "Có vị thế LIVE thiếu ID stop-loss đã xác minh; khóa bot cho tới khi đóng hoặc xử lý thủ công."
                    )

            # Luôn cập nhật số dư thực tế từ sàn
            base_currency = self.config['trading'].get('base_currency', 'USDT')
            bal = self.exchange.get_futures_balance()
            balance_ok = isinstance(bal, dict) and 'free' in bal
            self.live_balance_synced = balance_ok
            if balance_ok:
                if 'total' in bal and not isinstance(bal['total'], dict):
                    # Đã được parse bởi ExchangeConnector
                    self.balance = float(bal.get('free', 0))
                else:
                    # CCXT raw dict
                    asset_bal = bal.get(base_currency, {})
                    if isinstance(asset_bal, dict):
                        self.balance = float(asset_bal.get('free', 0))
                    else:
                        self.balance = float(bal.get('free', 0))
                        
            if removed or cleanup_state_changed:
                self._save_state()
            return True
        except Exception as e:
            logger.error(f"Lỗi đồng bộ open positions từ sàn: {e}")
            return False

    @property
    def auto_adopt_manual_positions(self) -> bool:
        return bool(self.config.get('trading', {}).get('auto_adopt_manual_positions', False))

    @auto_adopt_manual_positions.setter
    def auto_adopt_manual_positions(self, value: bool):
        if 'trading' not in self.config:
            self.config['trading'] = {}
        self.config['trading']['auto_adopt_manual_positions'] = bool(value)

    def get_status(self) -> dict:
        """Lấy trạng thái bot và equity Futures từ cùng nguồn Binance."""
        initial = self.config['trading']['initial_capital']
        live_futures = self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures'
        with self._position_lock:
            local_positions = [dict(position) for position in self.open_positions]
            unreconciled = self.unreconciled_exchange_positions
            pending_cleanup_count = len(self.pending_protection_cleanup)
        position_count = len(local_positions)
        account_snapshot_stale = False
        wallet_balance = None
        available_balance = self.balance
        margin_balance = None
        unrealized_pnl = 0.0
        account_snapshot_time = None
        used_margin = sum(float(pos.get('cost', 0) or 0) for pos in local_positions)

        if live_futures:
            now_monotonic = time.monotonic()
            snapshot_age = (
                now_monotonic - self._futures_account_snapshot_monotonic
                if self._futures_account_snapshot_monotonic is not None else None
            )
            if self._futures_account_snapshot is None or snapshot_age is None or snapshot_age >= 5.0:
                try:
                    account = self.exchange.get_futures_balance()
                    if account and account.get('margin_balance') is not None:
                        self._futures_account_snapshot = {
                            key: account.get(key) for key in (
                                'wallet_balance', 'margin_balance', 'unrealized_pnl',
                                'available_balance', 'initial_margin',
                                'position_initial_margin', 'open_order_initial_margin', 'update_time',
                            )
                        }
                        self._futures_account_snapshot_time = datetime.now()
                        self._futures_account_snapshot_monotonic = time.monotonic()
                        if account.get('available_balance') is not None:
                            self.balance = float(account['available_balance'])
                    try:
                        self._futures_positions_snapshot = self.exchange.get_futures_positions()
                        self._futures_positions_snapshot_time = datetime.now()
                    except Exception as e:
                        logger.warning('Không lấy được PnL Mark từng vị thế Binance: %s', e)
                except Exception as e:
                    logger.warning('Không lấy được snapshot Futures Binance cho dashboard: %s', e)

            snapshot = self._futures_account_snapshot
            if snapshot and snapshot.get('margin_balance') is not None:
                snapshot_age = (
                    now_monotonic - self._futures_account_snapshot_monotonic
                    if self._futures_account_snapshot_monotonic is not None else None
                )
                account_snapshot_stale = snapshot_age is None or snapshot_age >= 10.0
                wallet_balance = snapshot.get('wallet_balance')
                available_balance = snapshot.get('available_balance', self.balance)
                margin_balance = float(snapshot['margin_balance'])
                unrealized_pnl = float(snapshot.get('unrealized_pnl') or 0.0)
                used_margin = float(snapshot.get('initial_margin') or 0.0)
                account_snapshot_time = (
                    self._futures_account_snapshot_time.isoformat()
                    if self._futures_account_snapshot_time else None
                )
                # Binance marginBalance already equals walletBalance + unrealized PnL.
                # Do not add local position cost or PnL to this authoritative equity.
                equity = margin_balance
                quote_currency = self.config.get('trading', {}).get('base_currency', 'USDT')
                total_realized = self.db.get_total_net_pnl(self.mode, quote_currency) if getattr(self, 'db', None) else 0.0
                pnl = total_realized + unrealized_pnl
            else:
                # If exchange balance data is unavailable, do not present a local
                # reconstruction as an authoritative LIVE account value.
                equity = None
                pnl = None
                account_snapshot_stale = True
        else:
            try:
                for pos in local_positions:
                    ticker = self.exchange.get_ticker(pos['symbol'])
                    if ticker:
                        current_price = ticker['last']
                        if pos['direction'] == 'LONG':
                            unrealized_pnl += (current_price - pos['entry_price']) * pos['amount']
                        else:
                            unrealized_pnl += (pos['entry_price'] - current_price) * pos['amount']
            except Exception:
                pass
            equity = self.balance + used_margin + unrealized_pnl
            pnl = equity - initial

        return {
            'mode': self.mode,
            'market_type': getattr(self, 'market_type', 'spot'),
            'exchange_connected': self.exchange_connected,
            'leverage': getattr(self, 'leverage', 1),
            'max_leverage': self._configured_max_leverage(),
            'last_dynamic_leverage': int(getattr(self, 'last_dynamic_leverage', 1)),
            'last_leverage_symbol': getattr(self, 'last_leverage_symbol', None),
            'last_pair_max_leverage': getattr(self, 'last_pair_max_leverage', None),
            'last_leverage_limit_verified': getattr(self, 'last_leverage_limit_verified', None),
            'last_leverage_limit_source': getattr(self, 'last_leverage_limit_source', None),
            'max_open_positions': self._configured_max_open_positions(),
            'min_open_positions': self._configured_min_open_positions(),
            'last_dynamic_position_limit': getattr(self, 'last_dynamic_position_limit', None),
            'last_position_signal_quality': getattr(self, 'last_position_signal_quality', None),
            'last_position_available_margin': getattr(self, 'last_position_available_margin', None),
            'last_position_open_risk': getattr(self, 'last_position_open_risk', None),
            'last_position_risk_budget': getattr(self, 'last_position_risk_budget', None),
            'max_margin_utilization_pct': self._max_margin_utilization(),
            'max_total_open_risk_pct': self._max_total_open_risk(),
            'ai_recommended_max_positions': getattr(self, 'ai_recommended_max_positions', None),
            'is_running': self.is_running,
            'balance': self.balance,
            'available_balance': available_balance,
            'wallet_balance': wallet_balance,
            'margin_balance': margin_balance,
            'equity': equity,
            'used_margin': used_margin,
            'unrealized_pnl': unrealized_pnl,
            'account_snapshot_time': account_snapshot_time,
            'account_snapshot_stale': account_snapshot_stale,
            'unreconciled_exchange_positions': unreconciled,
            'pending_protection_cleanup_count': pending_cleanup_count,
            'initial_capital': initial,
            'pnl': pnl,
            'pnl_pct': (pnl / initial) * 100 if initial > 0 and pnl is not None else None,
            'peak_balance': self.peak_balance,
            'drawdown': (self.peak_balance - equity) / self.peak_balance
                if self.peak_balance > 0 and equity is not None else None,
            'open_positions': position_count,
            'pending_stalking_count': len(getattr(self, 'pending_stalking_orders', {})),
            'pending_stalking_orders': list(getattr(self, 'pending_stalking_orders', {}).values()),
            'trade_count': self.trade_count,
            'strategies': [s.name for s in self.strategies],
            'pairs': self.config['trading']['pairs'],
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'tradfi_enabled': bool(self.config.get('tradfi', {}).get('enabled', False)),
            'auto_adopt_manual_positions': self.auto_adopt_manual_positions,
            'only_tradfi': bool(self.config.get('tradfi', {}).get('only_tradfi', False)),
            'tradfi_market_open': MarketScanner.is_us_market_open(),
        }

    def get_dashboard_positions(self) -> List[Dict]:
        """Return local position controls with the latest exchange Mark PnL overlay."""
        with self._position_lock:
            # Khử trùng lặp tại nguồn dashboard để không bao giờ hiển thị 2 dòng cho cùng 1 cặp
            deduped_local = []
            seen_k = set()
            sorted_local = sorted(
                self.open_positions,
                key=lambda item: (
                    1 if item.get('sl_order_id') else 0,
                    0 if str(item.get('strategy', '')) == 'exchange_reconciled' or str(item.get('symbol', '')).endswith(':USDT') else 1
                ),
                reverse=True
            )
            for item in sorted_local:
                k = (self._clean_symbol(item.get('symbol')), item.get('direction', 'LONG'))
                if k not in seen_k:
                    seen_k.add(k)
                    deduped_local.append(dict(item))
            positions = deduped_local

        exchange_by_symbol = {}
        for exchange_position in self._futures_positions_snapshot or []:
            exchange_symbol = str(exchange_position.get('symbol') or '').split(':', 1)[0]
            key = exchange_symbol.replace('/', '').upper()
            if key:
                exchange_by_symbol[key] = exchange_position

        for position in positions:
            local_symbol = str(position.get('symbol') or '').split(':', 1)[0]
            key = local_symbol.replace('/', '').upper()
            exchange_position = exchange_by_symbol.get(key)
            if exchange_position:
                for local_key, exchange_key in (
                    ('mark_price', 'markPrice'),
                    ('unrealized_pnl_mark', 'unrealizedPnl'),
                    ('exchange_initial_margin', 'initialMargin'),
                    ('exchange_leverage', 'leverage'),
                ):
                    value = exchange_position.get(exchange_key)
                    if value is not None:
                        position[local_key] = value

            # Normalization of keys for Dashboard and Cloud Sync
            entry_price = float(position.get('entry_price') or 0.0)
            amount = abs(float(position.get('amount') or 0.0))
            leverage = int(position.get('exchange_leverage') or position.get('leverage') or 1)
            direction = str(position.get('direction') or position.get('side') or 'LONG').upper()
            if direction in ('BUY', 'LONG'):
                direction = 'LONG'
            else:
                direction = 'SHORT'
            mark_price = float(position.get('mark_price') or entry_price)

            margin = float(position.get('exchange_initial_margin') or position.get('margin') or position.get('cost') or 0.0)
            if margin <= 0.0 and entry_price > 0 and amount > 0:
                margin = (entry_price * amount) / max(1, leverage)

            upnl_val = position.get('unrealized_pnl_mark')
            if upnl_val is not None:
                upnl = float(upnl_val)
            elif position.get('real_pnl') is not None:
                upnl = float(position['real_pnl'])
            elif entry_price > 0 and amount > 0:
                upnl = (mark_price - entry_price) * amount if direction == 'LONG' else (entry_price - mark_price) * amount
            else:
                upnl = 0.0

            pnl_pct = (upnl / margin * 100.0) if margin > 0.0 else 0.0

            position['margin'] = round(margin, 2)
            position['unrealized_pnl'] = round(upnl, 4)
            position['unrealized_pnl_mark'] = round(upnl, 4)
            position['pnl_pct'] = round(pnl_pct, 2)
            position['leverage'] = leverage
            position['side'] = direction
            position['mark_price'] = mark_price

        return positions

