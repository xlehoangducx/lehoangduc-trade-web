"""
TRADEMATRIX MASTER - BỘ CHỈ HUY KHO 8 VŨ KHÍ TIẾNG VIỆT & CƠ THỂ SỐNG TỰ THÍCH ỨNG
====================================================================================
Single Source of Truth (SSOT) bằng Tiếng Việt kết nối tuần hoàn:
1. Phân loại 8 Vũ Khí Chuẩn (VK1 -> VK8) kèm Cây 28 Ô Điều Kiện Tỏa Nhánh qua 6 Tầng (đặc biệt là Tầng 5 Xạ Thủ M1).
2. Cơ chế Sinh Vật Sống Tự Thích Ứng (Living Adaptive Engine):
   - Khi mới bật tool (Cold-Start): Cho phép cả 8 Vũ Khí hoạt động bình thường ngay khi có cơ hội.
   - Khi có mẫu Shadow Pathfinder & Lịch sử Live: Tự động nâng cấp vũ khí đang ăn TP1 thành
     [🔥 CHỦ LỰC ƯU TIÊN] và hạ nhiệt vũ khí đang bị thị trường bẻ gãy thành [🛡️ HẠ NHIỆT PHÒNG THỦ].
3. Đo Nhịp Đập Đầu Tàu (BTC/ETH Leader Pulse -> Altcoin Cùng Pha/Lệch Pha & TradFi Độc Lập).
4. Điều phối Slot Thích Ứng Theo Vốn & Khóa Hòa Vốn Gối Đầu (Ratchet Slot Expansion).
5. Phát sóng Sơ Đồ Động Thời Gian Thực 6 Tầng có Hạt Tín Hiệu Di Chuyển & Bấm Mở Từng Ô Điều Kiện.
"""

import json
import os
import sqlite3
import threading
import time
from collections import deque
from typing import Dict, Any, List, Optional, Tuple

_ARSENAL_LOCK = threading.RLock()
_PIPELINE_TRACE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    'data',
    'live_pipeline_trace.json'
)
_RECENT_TRACES = deque(maxlen=120)

# ==============================================================================
# 1. DANH MỤC KHO 8 VŨ KHÍ TIẾNG VIỆT & CÂY ĐIỀU KIỆN 6 TẦNG (28 Ô ĐIỀU KIỆN / VŨ KHÍ)
# ==============================================================================
WEAPON_ARSENAL_CATALOG: Dict[str, Dict[str, Any]] = {
    "VK1_LONG_THUAN_SONG_CA_MAP": {
        "id": "VK1_LONG_THUAN_SONG_CA_MAP",
        "code": "VK1",
        "name_vi": "Vũ Khí 1: Mua Thuận Sóng Bơm Cá Mập",
        "short_name": "VK1 · Mua Thuận Sóng Cá Mập",
        "side": "LONG",
        "icon": "🚀",
        "color": "#00ff88",
        "group_vi": "PHE MUA (THUẬN ĐÀ BƠM PHA 1)",
        "target_goal_vi": "Ăn trọn nhịp đẩy TP1 (+1.2% -> +1.8%) khi cá mập bơm tiền phá cản",
        "when_to_use_vi": [
            "Nến 15M xanh đặc (Râu xả trên < 30%), Bội số Vol (RVol) >= 1.8x",
            "Khiên Xu Hướng Lớn 4H (JEV 4H) đồng thuận MUA hoặc không cản tàu",
            "Đầu tàu BTC/ETH đang cùng pha tăng hoặc đi ngang ổn định (không sập gắt)"
        ],
        "when_forbidden_vi": [
            "CẤM DÙNG khi nến đã có râu xả trên dài >= 35% (bẫy xả đỉnh)",
            "CẤM DÙNG khi RSI 15M đã quá nóng > 78 mà khối lượng bắt đầu suy yếu",
            "CẤM DÙNG trên Altcoin khi BTC đang xả thác đổ (Dump 15M >= 1.2%)"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Bội số Vol (RVol) nổ mạnh >= 1.80x (Miễn trừ lọc nhanh Fast-Skip)",
                "ĐK 1.2: Biên độ co giãn ATR 15M nằm trong vùng an toàn (0.40% -> 6.8%)",
                "ĐK 1.3: Đầu tàu BTC/ETH đang Cùng Pha Tăng hoặc Ổn Định (không sập bão)",
                "ĐK 1.4: Sức mạnh xu hướng ADX >= 20 (Có xung lực dòng tiền thật)"
            ],
            "T2": [
                "ĐK 2.1: Nến 15M xanh đặc tăng mạnh (Pump >= 0.7% Altcoin, >= 0.5% TradFi)",
                "ĐK 2.2: Râu nến trên (U_Wick) < 30% (Không có lực xả đè đỉnh)",
                "ĐK 2.3: Thân nến đặc chiếm >= 60% toàn bộ chiều dài cây nến",
                "ĐK 2.4: Giá đóng cửa nằm trên đường trung bình EMA20 khung 15M",
                "ĐK 2.5: Không bị Máy dò bẫy (Trap Detector) gắn cờ Bẫy Tăng Giá (Bull Trap)"
            ],
            "T3": [
                "ĐK 3.1: Kích hoạt Smart Momentum Ride Buy (Xóa bỏ các phiếu Bán cản tàu trễ pha)",
                "ĐK 3.2: Khiên Xu Hướng 4H (JEV 4H) không phản đối (JEV SELL < 70%)",
                "ĐK 3.3: Trọng tài AI Ensemble hoặc Chiến thuật Phá Cản (Breakout) đồng thuận MUA",
                "ĐK 3.4: Không có xung đột ngược chiều gay gắt giữa khung 1H và 15M",
                "ĐK 3.5: Nhiệt kế Shadow Pathfinder cho phép mở Vũ Khí Thuận Đà"
            ],
            "T4": [
                "ĐK 4.1: Kiểm tra Gối Đầu Hòa Vốn (Lệnh Mua trước đã khóa BE hoặc còn hạn mức Slot)",
                "ĐK 4.2: Rào chắn không trùng mã / không vi phạm khóa chéo ngành TradFi",
                "ĐK 4.3: Ký quỹ lệnh nằm trong hạn mức Thang Vốn (Đệm tiền mặt >= 50% NAV)",
                "ĐK 4.4: Khoảng cách SL/TP đạt sàn nén tối thiểu 50% ATR 1H"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK1]: Chiết khấu nông 0.12% - 0.22% ATR để bắt kịp tàu sóng bơm",
                "ĐK 5.2 [M1 RIÊNG VK1]: Đặt lệnh Limit Maker Post-Only (Phí 0.02%, cấm mua đuổi đỉnh)",
                "ĐK 5.3 [M1 RIÊNG VK1]: Kiểm tra sổ lệnh Taker Sell không xả áp đảo >= 75% ở cận giá <= 0.35%",
                "ĐK 5.4 [M1 RIÊNG VK1]: Tự hủy nếu giá bay vọt bỏ xa điểm rình > 1.5x ATR (Không FOMO)",
                "ĐK 5.5 [M1 RIÊNG VK1]: Tự hủy nếu nến M1 sập gãy cấu trúc hỗ trợ với RVol M1 >= 2.0x"
            ],
            "T6": [
                "ĐK 6.1: Khóa bảo vệ nến M1 đầu tiên (closed_m1 == 0) & Đối chiếu Best Bid chống lỗi -2021",
                "ĐK 6.2: Cài Hard Stop-Loss (1.2x - 1.5x ATR) và Take-Profit TP1 trực tiếp trên sàn Binance",
                "ĐK 6.3: Vòng 1 - Thoát hiểm nếu có >= 2 nến M1 đóng cửa xả ngược RVol >= 2.5x",
                "ĐK 6.4: Vòng 2 - Lãi chạm +0.85% -> Dời SL lên Khóa Hòa Vốn Thép (+0.22% · Rủi ro = 0$)",
                "ĐK 6.5: Vòng 3 - Chạm Đích TP1 hoặc Khóa lãi cấu trúc ChoCH -> Thu tiền tươi & Mở Slot mới"
            ]
        }
    },
    "VK2_LONG_LAT_NGUOC_SONG_PARABOL": {
        "id": "VK2_LONG_LAT_NGUOC_SONG_PARABOL",
        "code": "VK2",
        "name_vi": "Vũ Khí 2: Mua Lật Ngược Sóng Dựng Đứng (3C-KB10)",
        "short_name": "VK2 · Mua Lật Ngược Parabol (3C-KB10)",
        "side": "LONG",
        "icon": "🔄",
        "color": "#00e5ff",
        "is_experimental": True,
        "experimental_badge_vi": "🧪 THỬ NGHIỆM",
        "group_vi": "PHE MUA (LẬT NGƯỢC THẾ CỜ SLOT B2 · 🧪 THỬ NGHIỆM)",
        "target_goal_vi": "Lật ngược lệnh BÁN cản tàu thành MUA đón đáy rũ để ăn sóng Parabol TP1",
        "when_to_use_vi": [
            "Chỉ báo kỹ thuật báo BÁN (do thấy tăng cao) nhưng Khiên 4H đang TĂNG MẠNH (JEV BUY >= 75%)",
            "Bội số Vol (RVol) bùng nổ >= 1.8x, xung lực ADX mạnh, giá chỉ rũ nhẹ để gom thêm",
            "Xạ thủ M1 bắt buộc đặt lệnh Limit Maker đón ở đáy rũ chiết khấu (-0.25% đến -0.40%)"
        ],
        "when_forbidden_vi": [
            "CẤM DÙNG trên coin rác biến động điên loạn (Co giãn ATR 15M >= 7.0%)",
            "CẤM DÙNG khi giá đã gãy thủng cấu trúc hỗ trợ M15 với nến đỏ đặc dài",
            "CẤM MUA ĐUỔI giá Market trên đỉnh râu nến"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Bội số Vol (RVol) >= 1.60x - 1.80x (Dòng tiền cá mập đang cuộn sóng)",
                "ĐK 1.2: Cổng Chặn Coin Rác: Co giãn ATR 15M BẮT BUỘC < 7.0% (Như MMT 7.21% bị chặn an toàn!)",
                "ĐK 1.3: Trạng thái thị trường là Strong Uptrend / Parabolic với ADX >= 25",
                "ĐK 1.4: Đầu tàu BTC/ETH không ở trạng thái sập tháo cống"
            ],
            "T2": [
                "ĐK 2.1: Máy dò bẫy (Trap Detector) báo SELL (do thấy nến tăng cao có râu chốt lời ngắn hạn)",
                "ĐK 2.2: Biên độ Tăng nến (Pump 15M) mạnh >= 1.5%, lực xả thực tế (Dump) ~ 0.0%",
                "ĐK 2.3: Cấu trúc đáy sau cao hơn đáy trước trên khung 15M và 5M vẫn giữ vững",
                "ĐK 2.4: Không phải mô hình 2 đỉnh phân phối gãy cổ (Double Top Breakdown)",
                "ĐK 2.5: Râu dưới hoặc thân nến cho thấy phe Mua vẫn hấp thụ toàn bộ lực chốt lời"
            ],
            "T3": [
                "ĐK 3.1 [SLOT B2]: Khiên Xu Hướng 4H (JEV 4H) báo MUA MẠNH >= 75% - 85% bảo hộ cấu trúc",
                "ĐK 3.2 [SLOT B2]: Kích hoạt Lật Ngược Thế Cờ (Chuyển toàn bộ phiếu SELL cản tàu thành LONG)",
                "ĐK 3.3 [SLOT B2]: Đồng bộ điểm hội đồng (weighted_score >= +0.85 & agreement_ratio >= 0.65)",
                "ĐK 3.4 [SLOT B2]: Tính lại toàn bộ SL/TP theo chiều LONG và ATR chuẩn của Lớp Tài Sản",
                "ĐK 3.5 [SLOT B2]: Gắn cờ bảo hộ `is_parabolic_long_inversion = True` xuyên suốt xuống Tầng 5 & 6"
            ],
            "T4": [
                "ĐK 4.1: Miễn trừ Phương Án A+ tự hủy lệnh khi thấy phiếu kỹ thuật gốc là SELL",
                "ĐK 4.2: Kiểm tra hạn mức Slot Vốn & Khóa Hòa Vốn Gối Đầu",
                "ĐK 4.3: Kiểm tra giới hạn đòn bẩy sàn và Min Notional >= 6.0 USDT",
                "ĐK 4.4: Xác nhận thanh khoản sổ lệnh đủ sâu, spread không giãn bất thường"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK2]: Bắt buộc chiết khấu sâu 0.25% - 0.42% đón đúng đáy nhịp rũ (Như CTR khớp 0.016669!)",
                "ĐK 5.2 [M1 RIÊNG VK2]: Đặt Limit Maker Post-Only đón rũ, tuyệt đối không mua đuổi trên đỉnh sóng",
                "ĐK 5.3 [M1 RIÊNG VK2]: Giữ lệnh rình mồi kiên nhẫn, không bị phiếu AI SELL chưa lật ngược hủy oan",
                "ĐK 5.4 [M1 RIÊNG VK2]: Chỉ rút lệnh nếu Taker Sell xả trực diện >= 75% khi giá đã áp sát <= 0.35%",
                "ĐK 5.5 [M1 RIÊNG VK2]: Hủy rình mồi nếu giá bay luôn > 1.5x ATR mà không quay lại đón"
            ],
            "T6": [
                "ĐK 6.1 [BẢO HỘ VK2]: CẤM nhánh `has_open_pos` dùng phiếu AI SELL thô cắt non vị thế (Đã vá TB7!)",
                "ĐK 6.2 [BẢO HỘ VK2]: CẤM nhận diện nhầm cây nến đang Pump +3% thành thác đổ cá mập (Đã vá TB10!)",
                "ĐK 6.3: Giữ nguyên khoảng thở ATR chuẩn (1.5% - 2.5%) qua nhịp nhúng rũ vi mô ban đầu",
                "ĐK 6.4: Khi sóng Parabol phóng lên >= +0.85% -> Kích hoạt Khóa Hòa Vốn Thép (+0.22% Net BE)",
                "ĐK 6.5: Gồng trọn nhịp bứt phá ăn Đích TP1 (+1.50% -> +3.50%)"
            ]
        }
    },
    "VK3_LONG_SAN_RU_GOM_DAY": {
        "id": "VK3_LONG_SAN_RU_GOM_DAY",
        "code": "VK3",
        "name_vi": "Vũ Khí 3: Mua Bắt Đáy Rút Chân Cá Mập Gom",
        "short_name": "VK3 · Mua Bắt Bẫy Rút Chân (Bear Trap)",
        "side": "LONG",
        "icon": "💎",
        "color": "#38bdf8",
        "group_vi": "PHE MUA (BẮT BẪY GIẢM GIÁ)",
        "target_goal_vi": "Bắt đáy nhịp quét thanh khoản (Bear Trap) có cá mập đỡ giá ăn nhịp hồi TP1",
        "when_to_use_vi": [
            "Giá nhúng xuống quét đáy nhưng rút chân mạnh tạo Râu dưới (L_Wick) >= 40%",
            "Có khối lượng cá mập hấp thụ (RVol Altcoin >= 1.10x, Major >= 1.00x, TradFi >= 0.85x)",
            "Trọng tài AI hoặc Xu hướng 4H xác nhận vùng hỗ trợ cứng"
        ],
        "when_forbidden_vi": [
            "CẤM DÙNG khi cá mập đang xả thác đổ thật (Nến đỏ đặc không có râu dưới)",
            "CẤM DÙNG khi khối lượng cạn kiệt (RVol < 0.85x - bẫy rút chân giả thiếu tiền thật)",
            "CẤM DÙNG khi Xu hướng 4H đang gãy sập mạnh (JEV 4H SELL >= 70%)"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Bội số Vol (RVol) đạt chuẩn 3 Lớp Tài Sản (Altcoin >= 1.10x, Major >= 1.00x, TradFi >= 0.85x)",
                "ĐK 1.2: Biên độ ATR 15M đủ rộng (>= 0.45%) để nhịp hồi đủ biên độ chạm TP1",
                "ĐK 1.3: Đầu tàu BTC/ETH không đang trong pha sập tháo cống tự do",
                "ĐK 1.4: Mã giao dịch không nằm trong danh sách Cooldown thua liên tiếp"
            ],
            "T2": [
                "ĐK 2.1: Máy dò bẫy xác nhận Bear Trap / Selling Climax với Râu dưới (L_Wick) >= 40%",
                "ĐK 2.2: Giá đóng cửa nến 15M rút lên nằm ở nửa trên của cây nến (Lực cầu thắng thế)",
                "ĐK 2.3: Không phải nến đỏ đặc thác đổ (Waterfall Dump bị chặn 100%)",
                "ĐK 2.4: Chỉ số RSI 15M nằm ở vùng hỗ trợ (< 55), không bị quá mua",
                "ĐK 2.5: Không bị xung lực Phá Vỡ Cản Giảm (Strong Bearish Breakout) phủ quyết"
            ],
            "T3": [
                "ĐK 3.1: Kích hoạt Bear Trap Long (+0.85) trong Hội đồng chấm điểm",
                "ĐK 3.2: Khiên Xu Hướng 4H (JEV 4H) không báo sập mạnh (JEV SELL < 70%)",
                "ĐK 3.3: Trọng tài AI Ensemble hoặc Đảo chiều trung bình (Mean Reversion) đồng thuận MUA",
                "ĐK 3.4: Vượt qua cổng kiểm tra Bẫy Giả Vol Thấp (Low-Vol Fake Trap Veto)",
                "ĐK 3.5: Điểm tổng hợp Hội đồng đạt ngưỡng phê duyệt (>= +0.80)"
            ],
            "T4": [
                "ĐK 4.1: Kiểm tra hạn mức Slot Vốn & Quy tắc Gối Đầu Hòa Vốn",
                "ĐK 4.2: Neo điểm Cắt Lỗ Cấu Trúc (Structural SL Anchor) ngay dưới chân râu Bear Trap",
                "ĐK 4.3: Kiểm tra không trùng vị thế cùng gốc hoặc nghịch đảo",
                "ĐK 4.4: Đảm bảo tỷ lệ Lợi nhuận TP1 / Rủi ro SL >= 1.5x"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK3]: Chiết khấu 0.12% - 0.35% (0.22×ATR · BOM #111B kiểm chứng nến 1m thật) đón nhịp test lại phần râu dưới M1",
                "ĐK 5.2 [M1 RIÊNG VK3]: Đặt Limit Maker Post-Only, chờ giá nhúng nhẹ kiểm tra cầu lần 2",
                "ĐK 5.3 [M1 RIÊNG VK3]: Kiểm tra nến M1 Live không đâm thủng đáy thấp nhất của râu Bear Trap",
                "ĐK 5.4 [M1 RIÊNG VK3]: Rút lệnh nếu xuất hiện bão xả Taker Sell >= 75% áp sát <= 0.35% giá chờ",
                "ĐK 5.5 [M1 RIÊNG VK3]: Hủy lệnh nếu giá bật tăng thẳng > 1.5x ATR bỏ qua nhịp test đáy"
            ],
            "T6": [
                "ĐK 6.1: Đặt Hard SL dưới chân râu cấu trúc (tối đa trong khung 1.0% - 3.5% ATR)",
                "ĐK 6.2: Bảo vệ nến M1 đầu tiên (closed_m1 == 0) không bị nhiễu sổ lệnh cắt oan",
                "ĐK 6.3: Vòng 1 - Thoát hiểm sớm nếu đáy rút chân bị phá thủng bởi >= 2 nến M1 đỏ đặc RVol >= 2.5x",
                "ĐK 6.4: Vòng 2 - Lãi chạm +0.85% -> Dời SL lên Khóa Hòa Vốn Thép (+0.22% Net BE)",
                "ĐK 6.5: Vòng 3 - Chốt lời tại Đích TP1 khi nhịp hồi hoàn tất"
            ]
        }
    },
    "VK4_LONG_BAT_NAY_QUA_BAN": {
        "id": "VK4_LONG_BAT_NAY_QUA_BAN",
        "code": "VK4",
        "name_vi": "Vũ Khí 4: Mua Bật Nảy Đáy Hoảng Loạn",
        "short_name": "VK4 · Mua Bật Nảy Quá Bán",
        "side": "LONG",
        "icon": "⚡",
        "color": "#a78bfa",
        "group_vi": "PHE MUA (ĐẢO CHIỀU QUÁ BÁN)",
        "target_goal_vi": "Ăn nhịp bật lò xo TP1 khi đám đông bán tháo hoảng loạn cạn kiệt",
        "when_to_use_vi": [
            "Chỉ số RSI 15M rơi sâu vào vùng quá bán (< 30) kèm nến chững đà giảm",
            "Xuất hiện phân kỳ dương hoặc nến M1/M5 đóng cửa xanh vượt đỉnh nến trước",
            "Ưu tiên cao trên Major Crypto (BTC/ETH) và Cổ phiếu/ETF TradFi chất lượng"
        ],
        "when_forbidden_vi": [
            "CẤM BẮT DAO RƠI khi nến 15M vẫn đang mở rộng biên độ sập và chưa rút chân",
            "CẤM DÙNG khi mã giao dịch đang dính tin tức sập cấu trúc hoặc thủng đáy lịch sử"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Chỉ số RSI 15M rơi sâu vào vùng quá bán cực hạn (RSI <= 30.0)",
                "ĐK 1.2: Bội số Vol (RVol) cao đột biến báo hiệu điểm cao trào bán tháo (Selling Climax)",
                "ĐK 1.3: Ưu tiên tài sản có giá trị nội tại (Major Crypto BTC/ETH/SOL & Cổ phiếu TradFi)",
                "ĐK 1.4: Biên độ ATR đủ lớn để nhịp bật lò xo tạo lợi nhuận >= +1.0%"
            ],
            "T2": [
                "ĐK 2.1: Đà giảm đã chững lại, xuất hiện râu dưới hấp thụ >= 30%",
                "ĐK 2.2: Giá chạm hoặc vượt ra ngoài dải Bollinger Band dưới rồi co vào trong",
                "ĐK 2.3: Chiến thuật Mean Reversion & Trap Detector cùng phát tín hiệu hồi phục",
                "ĐK 2.4: Trên khung 5M xuất hiện cây nến xanh đầu tiên chặn đứng chuỗi nến đỏ",
                "ĐK 2.5: Không còn áp lực mở rộng biên độ sập trên nến hiện tại"
            ],
            "T3": [
                "ĐK 3.1: Dòng lệnh (Order Flow) xác nhận kịch bản `BULLISH_ABSORPTION_BOUNCE`",
                "ĐK 3.2: Trọng tài AI Ensemble xác nhận xác suất bật nảy >= 70%",
                "ĐK 3.3: Khiên 4H không ở trạng thái sập cấu trúc dài hạn trên Altcoin yếu",
                "ĐK 3.4: Gắn cờ `is_oversold_bounce = True` để áp dụng chế độ săn đáy lò xo",
                "ĐK 3.5: Điểm tổng hợp Hội đồng vượt ngưỡng an toàn"
            ],
            "T4": [
                "ĐK 4.1: Kiểm tra hạn mức Slot Vốn & Quy tắc Gối Đầu Hòa Vốn",
                "ĐK 4.2: Giới hạn đòn bẩy an toàn (không dùng đòn bẩy cao khi bắt nhịp bật quá bán)",
                "ĐK 4.3: Kiểm tra tương quan danh mục không quá tải vị thế bắt đáy cùng lúc",
                "ĐK 4.4: Tính toán SL chặt dưới đáy hoảng loạn vừa tạo"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK4]: Chiết khấu 0.12% - 0.35% (0.22×ATR · BOM #111B kiểm chứng nến 1m thật) đón cú nhúng vét thanh khoản cuối cùng",
                "ĐK 5.2 [M1 RIÊNG VK4]: Bắt buộc nến M1 phải có dấu hiệu chững đà rơi & nến 15M đã rút chân L_Wick >= 35%, U_Wick < 25%, ADX >= 18",
                "ĐK 5.3 [M1 RIÊNG VK4]: Đặt Limit Maker Post-Only, tiết kiệm phí sàn 0.02%",
                "ĐK 5.4 [M1 RIÊNG VK4]: Rút lệnh nếu Taker Sell tiếp tục xả lũ >= 75% ở cận giá <= 0.35%",
                "ĐK 5.5 [M1 RIÊNG VK4]: Hủy lệnh nếu giá thủng mốc vô hiệu đáy (plunge_invalid_price)"
            ],
            "T6": [
                "ĐK 6.1: Bảo vệ nến M1 đầu tiên & Kiểm tra chéo sổ lệnh Best Bid/Ask",
                "ĐK 6.2: Vòng 1 - Thoát hiểm tức thì nếu đáy quá bán bị đâm thủng kèm RVol M1 >= 2.5x",
                "ĐK 6.3: Khóa lãi sớm (ChoCH Early Profit Lock) nếu nhịp bật yếu và gãy cấu trúc M1 ở +0.40% -> +0.80%",
                "ĐK 6.4: Vòng 2 - Lãi chạm +0.85% -> Dời SL lên Khóa Hòa Vốn Thép (+0.22% Net BE)",
                "ĐK 6.5: Vòng 3 - Chốt lời nhanh tại Đích TP1 (Ăn trọn cú bật lò xo rồi rút quân)"
            ]
        }
    },
    "VK5_SHORT_THAC_DO_CA_MAP_XA": {
        "id": "VK5_SHORT_THAC_DO_CA_MAP_XA",
        "code": "VK5",
        "name_vi": "Vũ Khí 5: Bán Thuận Thác Đổ Cá Mập Xả",
        "short_name": "VK5 · Bán Thuận Thác Đổ Cá Mập",
        "side": "SHORT",
        "icon": "🌊",
        "color": "#ff4444",
        "group_vi": "PHE BÁN (THUẬN ĐÀ XẢ HÀNG)",
        "target_goal_vi": "Đi cùng phe cá mập bán tháo để ăn trọn nhịp sập dây chuyền tới TP1",
        "when_to_use_vi": [
            "Nến 15M đỏ đặc xả mạnh (Giảm nến >= 1.2%, Râu dưới < 25%), Bội số Vol >= 1.5x",
            "Số đông chiến thuật kỹ thuật & Trọng tài AI đồng thuận BÁN",
            "Khiên Xu Hướng 4H không bảo vệ chiều Mua (JEV 4H BUY < 70%)"
        ],
        "when_forbidden_vi": [
            "CẤM BÁN ĐUỔI khi RSI 15M đã chạm sàn quá bán (< 39.5) mà xung lực xả đã cạn",
            "CẤM DÙNG khi nến có râu dưới gom hàng dài >= 25% (cá mập đang đỡ đáy)",
            "CẤM DÙNG trên ETF Nghịch đảo (SOXS/SQQQ) khi chỉ số gốc Mỹ đang Uptrend mạnh"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Bội số Vol (RVol) xả hàng >= 1.50x (Cá mập bán tháo chủ động)",
                "ĐK 1.2: Biên độ Giảm nến (Dump 15M) >= 1.2% và lớn hơn biên độ Tăng >= 1.3 lần",
                "ĐK 1.3: Đầu tàu BTC/ETH đang cùng pha giảm hoặc mã đang bị xả độc lập",
                "ĐK 1.4: Sức mạnh xu hướng ADX >= 20 xác nhận đà rơi có xung lượng"
            ],
            "T2": [
                "ĐK 2.1: Nến 15M đỏ đặc (Râu dưới L_Wick < 25% -> Không có lực bắt đáy đỡ giá)",
                "ĐK 2.2: Rào chắn Chống Bán Đuổi Đáy (TB5): RSI 15M BẮT BUỘC > 39.5 (hoặc Dump cực đại >= 1.3% & RVol >= 1.9x)",
                "ĐK 2.3: Giá đóng cửa nằm dưới EMA20 và phá vỡ đáy hỗ trợ gần nhất",
                "ĐK 2.4: Không có tín hiệu Bear Trap rút chân gom hàng",
                "ĐK 2.5: Khung 5M đồng thuận cấu trúc đỉnh sau thấp hơn đỉnh trước"
            ],
            "T3": [
                "ĐK 3.1: Khiên Xu Hướng 4H (JEV 4H) KHÔNG bảo hộ chiều Mua (JEV BUY < 70% -> Cấm bán ngược 4H Uptrend!)",
                "ĐK 3.2: Kích hoạt Smart Waterfall Breakdown Short (Loại bỏ các phiếu bắt đáy sớm)",
                "ĐK 3.3: Trọng tài AI Ensemble & Chiến thuật Xu hướng / Phá cản đồng thuận BÁN",
                "ĐK 3.4: Gắn cờ `is_waterfall_short = True` truyền xuống Tầng 5 & Tầng 6",
                "ĐK 3.5: Điểm hội đồng đạt chuẩn >= -0.80 về phe BÁN"
            ],
            "T4": [
                "ĐK 4.1: Quy tắc Gối Đầu Hòa Vốn: Lệnh BÁN trước đó phải đã Khóa Hòa Vốn Thép mới mở thêm lệnh BÁN mới!",
                "ĐK 4.2: Rào chắn TradFi: Cấm mở vị thế Bear/Short khi Benchmark ngành đang Uptrend mạnh (ADX >= 25)",
                "ĐK 4.3: Kiểm tra hạn mức ký quỹ & đòn bẩy theo Thang Vốn",
                "ĐK 4.4: Đảm bảo khoảng thở SL không bị nén dưới 50% ATR 1H"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK5]: Chiết khấu đón nhịp nảy hồi nhẹ +0.15% đến +0.25% ATR trên khung M1",
                "ĐK 5.2 [M1 RIÊNG VK5]: Đặt Limit Maker Post-Only chờ phe bắt đáy yếu ớt đẩy nhẹ lên là khớp BÁN",
                "ĐK 5.3 [M1 RIÊNG VK5]: Rút lệnh nếu xuất hiện dòng tiền cá mập mua gom ngược Taker Buy >= 75% ở cận giá <= 0.35%",
                "ĐK 5.4 [M1 RIÊNG VK5]: Tự hủy nếu giá sập luôn > 1.5x ATR mà không hồi lên đón (Không bán đuổi ở đáy!)",
                "ĐK 5.5 [M1 RIÊNG VK5]: Tự hủy nếu nến M1 đóng cửa xanh đặc phá vỡ đỉnh kháng cự với RVol >= 2.0x"
            ],
            "T6": [
                "ĐK 6.1: Khóa bảo vệ nến M1 đầu tiên & Đối chiếu Best Ask thực tế trên sổ lệnh chống lỗi -2021",
                "ĐK 6.2: Giữ nguyên khoảng thở ATR (Đã xóa sổ nhánh cắt non -1.0% cố định của DODOX!)",
                "ĐK 6.3: Vòng 1 - Thoát hiểm nếu cá mập bơm dựng cột xanh ngược chiều RVol M1 >= 2.5x sau >= 2 nến M1",
                "ĐK 6.4: Vòng 2 - Giá sập đạt lãi +0.85% -> Dời SL xuống Khóa Hòa Vốn Thép (+0.22% Net BE · Rủi ro = 0$)",
                "ĐK 6.5: Vòng 3 - Ăn trọn thác đổ tới Đích TP1 & Mở khóa Slot cho lệnh tiếp theo"
            ]
        }
    },
    "VK6_SHORT_BAT_DINH_KIET_SUC": {
        "id": "VK6_SHORT_BAT_DINH_KIET_SUC",
        "code": "VK6",
        "name_vi": "Vũ Khí 6: Bán Bắt Đỉnh Sóng Bơm Kiệt Sức",
        "short_name": "VK6 · Bán Đỉnh Sóng Bơm Kiệt Sức",
        "side": "SHORT",
        "icon": "☄️",
        "color": "#f97316",
        "group_vi": "PHE BÁN (BẮT ĐỈNH PHA 2)",
        "target_goal_vi": "Đón đầu nhịp sập trả điểm TP1 ngay sau khi cá mập bơm xong và xả đỉnh",
        "when_to_use_vi": [
            "Giá vừa có nhịp bơm nóng (Tăng nến >= 1.0%, RSI cao) nhưng xuất hiện Râu xả trên >= 35%",
            "Trọng tài AI xác nhận lực mua đã kiệt sức hoặc đảo chiều BÁN",
            "Xạ thủ M1 xác nhận giá không còn vượt qua được đỉnh râu Climax"
        ],
        "when_forbidden_vi": [
            "CẤM BÁN CẢN TÀU khi Khiên Xu Hướng 4H đang TĂNG MẠNH (JEV 4H BUY >= 70%)",
            "CẤM DÙNG khi Trọng tài AI vẫn báo MUA >= 70% trong vùng đi ngang hoặc có râu dưới >= 22%",
            "CẤM DÙNG khi RSI 15M < 52 trong xu hướng tăng kép (đó là đáy nhịp chỉnh, không phải đỉnh!)"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Bội số Vol (RVol) đạt ngưỡng cao trào >= 1.55x (Hoặc râu xả cực đại >= 58%)",
                "ĐK 1.2: Sóng bơm trước đó phải đủ lớn: Tăng nến (Pump 15M) >= 1.0% (Chặn sóng vi mô < 1% như lệnh XRP!)",
                "ĐK 1.3: Biên độ ATR nằm trong khung kiểm soát, không phải coin rác giật 2 đầu",
                "ĐK 1.4: Kiểm tra trạng thái ADX tổng thể và Tactical ADX 15M"
            ],
            "T2": [
                "ĐK 2.1: Xuất hiện Râu xả trên dài (U_Wick >= 45% · BOM #101B) báo hiệu cá mập chốt lời đè giá",
                "ĐK 2.2: Khiên RSI [40.0..68.0] & ADX >= 18 (BOM #101B — Chặn sạch Short đáy quá bán như BEAT RSI=30.3 / ZIL RSI=34.9 / AIOT RSI=19.4!)",
                "ĐK 2.3: Rào chắn Chống Râu 2 Đầu (TB4C + BOM #101B): Râu dưới (L_Wick) < 25% (Chặn lỗi TLM/TAC/ASTER!)",
                "ĐK 2.4: Cây nến không còn giữ được mức đóng cửa ở đỉnh cao nhất",
                "ĐK 2.5: Máy dò bẫy xác nhận tín hiệu `BUYING_CLIMAX` (Cao trào mua kiệt sức)"
            ],
            "T3": [
                "ĐK 3.1: Khiên Xu Hướng 4H (JEV 4H) KHÔNG ở trạng thái bơm mạnh >= 70% (Bảo vệ tuyệt đối cấu trúc 4H)",
                "ĐK 3.2: Rào chắn Tôn Trọng AI (TB3A): CẤM mở Short nếu Trọng tài AI vẫn báo MUA >= 70% trong vùng đi ngang/rút chân (Chặn lỗi SOPH & CL!)",
                "ĐK 3.3: Trọng tài AI Ensemble đồng thuận BÁN hoặc xác nhận suy yếu xung lượng",
                "ĐK 3.4: Gắn cờ `is_fading_short = True` và tính điểm SL neo phía trên đỉnh râu Climax",
                "ĐK 3.5: Điểm hội đồng đạt ngưỡng đồng thuận >= 2 chiến thuật"
            ],
            "T4": [
                "ĐK 4.1: Quy tắc Gối Đầu Hòa Vốn: Không mở chồng 2 lệnh BÁN cùng chịu rủi ro âm",
                "ĐK 4.2: Neo Structural SL Anchor ngay phía trên đỉnh râu xả Climax",
                "ĐK 4.3: Kiểm tra hạn mức vốn & đòn bẩy an toàn",
                "ĐK 4.4: Xác nhận tỷ lệ Lợi nhuận trả điểm TP1 / Rủi ro SL đạt chuẩn"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK6]: Chiết khấu +0.12% đến +0.35% (0.22×ATR · BOM #111B kiểm chứng nến 1m thật) đón cú nảy test đỉnh (Dead-Cat Bounce) trên M1",
                "ĐK 5.2 [M1 RIÊNG VK6]: Rào chắn Đỉnh Climax (TB2): Hủy ngay nếu nến M1 Live đâm thủng vượt đỉnh râu Climax!",
                "ĐK 5.3 [M1 RIÊNG VK6]: Đặt Limit Maker Post-Only, tuyệt đối không bán đuổi khi giá đã rơi xa đỉnh",
                "ĐK 5.4 [M1 RIÊNG VK6]: Rút lệnh nếu Taker Buy bất ngờ bơm thốc >= 75% ở cận giá <= 0.35%",
                "ĐK 5.5 [M1 RIÊNG VK6]: Hủy rình mồi nếu giá sập luôn > 1.5x ATR trước khi khớp"
            ],
            "T6": [
                "ĐK 6.1: Khóa bảo vệ nến M1 đầu tiên & Đối chiếu Best Ask sổ lệnh",
                "ĐK 6.2: Cấm xả Market âm khi Peak MFE chưa chạm mốc Khóa Hòa Vốn Thép (Bất biến 24)",
                "ĐK 6.3: Vòng 1 - Thoát hiểm nếu sóng bơm tái kích hoạt với >= 2 nến M1 xanh đặc RVol >= 2.5x vượt đỉnh",
                "ĐK 6.4: Vòng 2 - Lãi trả điểm chạm +0.85% -> Dời SL xuống Khóa Hòa Vốn Thép (+0.22% Net BE)",
                "ĐK 6.5: Vòng 3 - Chốt lời tại Đích TP1 ngay khi nhịp trả điểm hoàn tất"
            ]
        }
    },
    "VK7_SHORT_BAY_TANG_GIA_RAU_XA": {
        "id": "VK7_SHORT_BAY_TANG_GIA_RAU_XA",
        "code": "VK7",
        "name_vi": "Vũ Khí 7: Bán Bẫy Tăng Giá Râu Xả Đỉnh",
        "short_name": "VK7 · Bán Bẫy Tăng Giá (Bull Trap)",
        "side": "SHORT",
        "icon": "🎯",
        "color": "#fbbf24",
        "group_vi": "PHE BÁN (BẮT BẪY TĂNG GIÁ)",
        "target_goal_vi": "Bán khi cá mập kéo giả vượt đỉnh dụ nhỏ lẻ mua đuổi rồi đạp ngược về TP1",
        "when_to_use_vi": [
            "Máy dò bẫy (Trap Detector) phát hiện Bull Trap / Râu trên quét đỉnh >= 40%",
            "Khối lượng đạt chuẩn xác nhận bẫy thật (RVol >= 1.10x với Altcoin, >= 0.85x với TradFi)",
            "Không bị xung lực Phá Vỡ Cản (Breakout) mạnh phản đối"
        ],
        "when_forbidden_vi": [
            "CẤM DÙNG khi nến biến động giật râu cả 2 đầu (Râu dưới >= 24% trong High Volatility)",
            "CẤM DÙNG khi sóng tăng quá nhỏ (Tăng nến < 1.0%, RVol < 1.55x - râu nhiễu)",
            "CẤM DÙNG khi cá mập đang bơm bão Pha 1 (Nến xanh đặc không râu)"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Bội số Vol (RVol) đạt chuẩn Bất biến 22 (Altcoin >= 1.10x, Major >= 1.00x, TradFi >= 0.85x)",
                "ĐK 1.2: Biên độ ATR 15M đủ lớn để nhịp đạp từ đỉnh bẫy xuống đáy đạt TP1",
                "ĐK 1.3: Thị trường không nằm trong pha Bão Bơm Cá Mập Pha 1 (Whale Pump Storm)",
                "ĐK 1.4: Kiểm tra tính thanh khoản và spread ổn định"
            ],
            "T2": [
                "ĐK 2.1: Giá nhúng vượt đỉnh kháng cự cũ nhưng bị đạp tụt xuống tạo Râu trên (U_Wick) >= 40%",
                "ĐK 2.2: Giá đóng cửa nến 15M nằm dưới mức kháng cự (Xác nhận Phá Vỡ Giả - False Breakout)",
                "ĐK 2.3: Râu dưới (L_Wick) nhỏ (< 24%), chứng tỏ phe Mua không còn đỡ giá",
                "ĐK 2.4: Không bị chiến thuật Momentum Breakout báo MUA mạnh (>= 72%) phản đối",
                "ĐK 2.5: Cấu trúc nến 5M xác nhận gãy đáy vi mô sau khi tạo râu đỉnh"
            ],
            "T3": [
                "ĐK 3.1: Khiên Xu Hướng 4H (JEV 4H) bảo vệ: Cấm xóa phiếu JEV 4H BUY nếu JEV >= 70%!",
                "ĐK 3.2: Kích hoạt Bull Trap Short (-0.85) khi không vi phạm Khiên 4H",
                "ĐK 3.3: Trọng tài AI Ensemble hoặc Chiến thuật kỹ thuật thứ 2 đồng thuận BÁN",
                "ĐK 3.4: Vượt qua bộ lọc Chống Bẫy Đơn Lẻ Trong Vùng Nén (Lone Trap in Chop Veto)",
                "ĐK 3.5: Điểm tổng hợp Hội đồng đạt chuẩn phê duyệt"
            ],
            "T4": [
                "ĐK 4.1: Quy tắc Gối Đầu Hòa Vốn: Kiểm tra số lệnh BÁN đang chịu rủi ro trong danh mục",
                "ĐK 4.2: Neo điểm Cắt Lỗ Cấu Trúc (Structural SL) ngay trên đỉnh râu Bull Trap",
                "ĐK 4.3: Kiểm tra không vi phạm khóa chéo ngành TradFi",
                "ĐK 4.4: Xác nhận quy mô vốn & ký quỹ an toàn"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK7]: Chiết khấu +0.12% đến +0.35% (0.22×ATR · BOM #111B kiểm chứng nến 1m thật) đón nhịp kéo rướn test lại vùng bẫy trên M1",
                "ĐK 5.2 [M1 RIÊNG VK7]: Kiểm tra nến M1 Live không phá thủng đỉnh râu Bull Trap",
                "ĐK 5.3 [M1 RIÊNG VK7]: Đặt Limit Maker Post-Only (Phí 0.02%), không bán đuổi khi giá đã sập sâu",
                "ĐK 5.4 [M1 RIÊNG VK7]: Rút lệnh nếu Taker Buy mua thốc >= 75% ở cận giá <= 0.35%",
                "ĐK 5.5 [M1 RIÊNG VK7]: Hủy rình mồi nếu giá rơi thẳng > 1.5x ATR không quay lại đón"
            ],
            "T6": [
                "ĐK 6.1: Đặt Hard SL trên đỉnh râu bẫy & Bảo vệ nến M1 đầu tiên (closed_m1 == 0)",
                "ĐK 6.2: Cấm cắt Market âm khi chưa đạt mốc Khóa Hòa Vốn Thép",
                "ĐK 6.3: Vòng 1 - Thoát hiểm nếu bẫy bị bẻ gãy bởi >= 2 nến M1 xanh đặc RVol >= 2.5x",
                "ĐK 6.4: Vòng 2 - Lãi chạm +0.85% -> Dời SL xuống Khóa Hòa Vốn Thép (+0.22% Net BE)",
                "ĐK 6.5: Vòng 3 - Chốt lời tại Đích TP1 khi giá sập về vùng thanh khoản bên dưới"
            ]
        }
    },
    "VK8_THUAN_XU_HUONG_DA_KHUNG": {
        "id": "VK8_THUAN_XU_HUONG_DA_KHUNG",
        "code": "VK8",
        "name_vi": "Vũ Khí 8: Đánh Thuận Xu Hướng Chuẩn Đa Khung",
        "short_name": "VK8 · Thuận Xu Hướng Đa Khung (4H+1H+15M)",
        "side": "BOTH",
        "icon": "🧭",
        "color": "#c084fc",
        "group_vi": "ĐA NĂNG (THUẬN DÒNG CHẢY LỚN)",
        "target_goal_vi": "Bám theo xu hướng chuẩn khi cả 3 khung 4H, 1H, 15M và AI đồng thuận 1 chiều",
        "when_to_use_vi": [
            "Ít nhất 2 chiến thuật độc lập + Trọng tài AI + Xu hướng 4H cùng chỉ về 1 hướng",
            "Sức mạnh xu hướng ADX >= 22 (thị trường có sóng rõ ràng, không đi ngang)",
            "Xạ thủ M1 đặt lệnh Limit Maker đón nhịp hồi nhẹ để tối ưu điểm vào"
        ],
        "when_forbidden_vi": [
            "CẤM DÙNG khi thị trường chung đang đóng băng thanh khoản (ADX < 18, ATR < 0.35%)",
            "CẤM DÙNG khi khung 1H và 15M đang tự mâu thuẫn đánh nhau (HTF Conflict)",
            "CẤM DÙNG khi đã chạm điểm quá mua/quá bán cực hạn mà chưa có nhịp nghỉ"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Sức mạnh xu hướng ADX >= 22.0 và Co giãn ATR >= 0.40% (Không đi ngang Dead Chop)",
                "ĐK 1.2: Bội số Vol (RVol) duy trì trên ngưỡng thanh khoản hoạt động (Alt >= 0.85x, TradFi >= 0.60x)",
                "ĐK 1.3: Đầu tàu BTC/ETH không nằm trong trạng thái Chop Shield (Nén biên độ)",
                "ĐK 1.4: Qua được cổng lọc nhanh Pre-LLM (Có ít nhất 1 trụ cột kỹ thuật >= 72%)"
            ],
            "T2": [
                "ĐK 2.1: Chiến thuật Trend Following (SuperTrend + EMA20/EMA50) xác nhận xu hướng rõ ràng",
                "ĐK 2.2: Rào chắn Chống Đuổi Đáy/Đỉnh (TB5): Cấm SELL khi RSI 15M < 39.5; Cấm BUY khi RSI 15M >= 70.0",
                "ĐK 2.3: Cấu trúc khung 1H và 15M đồng pha 100% (Không bị HTF Conflict Veto)",
                "ĐK 2.4: Không có râu nến kháng cự/hỗ trợ ngược chiều quá lớn chặn trước mặt",
                "ĐK 2.5: Giá không đi quá xa đường EMA20 (Tránh vào lệnh ở cuối con sóng)"
            ],
            "T3": [
                "ĐK 3.1: Cần tối thiểu >= 2 chiến thuật độc lập đồng thuận cùng chiều (Phương án A+)",
                "ĐK 3.2: Không có bất kỳ chiến thuật nào phản đối mạnh từ bên kia",
                "ĐK 3.3: Khiên Xu Hướng 4H (JEV 4H) và Trọng tài AI Ensemble đồng thuận cùng chiều",
                "ĐK 3.4: Kiểm tra Nhiệt kế Sinh Học Shadow Pathfinder (Tự động hạ nhiệt nếu Win Rate < 40%)",
                "ĐK 3.5: Điểm tổng hợp Hội đồng vượt ngưỡng chuẩn (>= 0.80)"
            ],
            "T4": [
                "ĐK 4.1: Quy tắc Gối Đầu Hòa Vốn: Kiểm tra lệnh cùng chiều trước đó đã Khóa Hòa Vốn chưa",
                "ĐK 4.2: Kiểm tra tương quan Cùng Pha BTC/ETH (Nếu đánh Altcoin) hoặc Rào chắn Ngành (Nếu đánh TradFi)",
                "ĐK 4.3: Tính toán quy mô vốn và đòn bẩy thích ứng theo độ tự tin tín hiệu",
                "ĐK 4.4: Đảm bảo SL/TP tuân thủ khung ATR [1.0% - 3.5%]"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK8]: Chiết khấu chuẩn 0.18% - 0.30% ATR đón nhịp pullback về EMA trên khung M1",
                "ĐK 5.2 [M1 RIÊNG VK8]: Đặt Limit Maker Post-Only (Phí 0.02%), kiên nhẫn chờ nhịp hồi",
                "ĐK 5.3 [M1 RIÊNG VK8]: Rút lệnh nếu dòng tiền Taker đối kháng >= 75% áp sát <= 0.35% giá chờ",
                "ĐK 5.4 [M1 RIÊNG VK8]: Hủy rình mồi nếu giá chạy xa > 1.5x ATR",
                "ĐK 5.5 [M1 RIÊNG VK8]: Hủy rình mồi nếu cấu trúc M1 bị bẻ gãy ngược chiều với RVol >= 2.0x"
            ],
            "T6": [
                "ĐK 6.1: Bảo vệ nến M1 đầu tiên & Kiểm tra chéo Best Bid/Ask chống lỗi -2021",
                "ĐK 6.2: Cài đặt Hard SL và TP1 trực tiếp trên sàn Binance ngay khi khớp",
                "ĐK 6.3: Vòng 1 - Thoát hiểm nếu xuất hiện bão xả ngược chiều RVol M1 >= 2.5x",
                "ĐK 6.4: Vòng 2 - Lãi chạm +0.85% -> Dời SL lên Khóa Hòa Vốn Thép (+0.22% Net BE · Rủi ro = 0$)",
                "ĐK 6.5: Vòng 3 - Thả lỏng bám xu hướng tới Đích TP1 hoặc Khóa lãi cấu trúc ChoCH"
            ]
        }
    },
    "VK9_SHORT_BAN_DINH_RAU_CUC_DAI": {
        "id": "VK9_SHORT_BAN_DINH_RAU_CUC_DAI",
        "code": "VK9",
        "name_vi": "Vũ Khí 9: Bán Đỉnh Râu Cực Đại (Giao Điểm L1∩A4)",
        "short_name": "VK9 · Bán Đỉnh Râu Cực Đại (L1∩A4)",
        "side": "SHORT",
        "icon": "🩸",
        "color": "#f43f5e",
        "is_experimental": True,
        "experimental_badge_vi": "🧪 THỬ NGHIỆM",
        "asset_class_target": "ALTCOIN",
        "group_vi": "PHE BÁN (SLOT B1 · 🧪 THỬ NGHIỆM)",
        "target_goal_vi": "Bắt đỉnh râu xả cực đại >= 65% trên Altcoin khi Trap+AI đồng thuận BÁN bất chấp Trend/JEV còn trễ pha",
        "when_to_use_vi": [
            "Lớp tài sản ALTCOIN · Trap SELL + Trend BUY + AI SELL + JEV 4H BUY (Giao điểm kim cương L1∩A4)",
            "Râu xả trên cực đại U_Wick >= 65%, Râu dưới < 25%, RSI < 65, RVol >= 1.33x, ADX >= 20",
            "Áp dụng vốn thích ứng & đòn bẩy động chuẩn Altcoin (SL [1.5% - 3.5%])"
        ],
        "when_forbidden_vi": [
            "CẤM DÙNG khi xuất hiện Bão Volume Mua cực đại (Extreme Bull Storm RVol >= 5.0x nến xanh đặc)",
            "CẤM DÙNG khi BTC đang bơm bão mạnh hoặc thị trường đi ngang chết xung lực (ADX < 20)",
            "CẤM DÙNG khi râu dưới >= 25% (bẫy quét thanh khoản 2 đầu)"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Lớp tài sản ALTCOIN · Bội số Vol (RVol) >= 1.33x (Đột biến xả đỉnh thật)",
                "ĐK 1.2: Xung lực ADX >= 20.0 (Loại sạch mẫu đi ngang đứng im TIMEOUT_60M)",
                "ĐK 1.3: Vượt bộ lọc thanh khoản & biên độ ATR chuẩn Altcoin",
                "ĐK 1.4: Kiểm tra tương quan BTC Macro (chặn Short khi BTC bơm bão)"
            ],
            "T2": [
                "ĐK 2.1: Râu xả trên cực đại U_Wick >= 65.0% (Xác nhận lực xả Limit áp đảo trên đỉnh)",
                "ĐK 2.2: Râu dưới L_Wick < 25.0% (Không có lực đỡ gom hàng 2 đầu)",
                "ĐK 2.3: Xung lượng chưa quá mua bão parabol: RSI 15M < 65.0",
                "ĐK 2.4: Máy dò bẫy TrapDetector báo SELL đồng thời TrendFollowing trễ pha còn báo BUY",
                "ĐK 2.5: Không nằm trong trạng thái Extreme Bull Storm"
            ],
            "T3": [
                "ĐK 3.1 [SLOT B1 - VK9]: AI Ensemble xác nhận BÁN đồng pha với TrapDetector SELL",
                "ĐK 3.2 [SLOT B1 - VK9]: Mở khóa giao điểm L1∩A4 (85.7% Strict TP · 0% SL lịch sử)",
                "ĐK 3.3 [SLOT B1 - VK9]: Đồng bộ weighted_score <= -0.82 và agreement_ratio >= 0.65",
                "ĐK 3.4 [SLOT B1 - VK9]: Bảo toàn 100% Extreme Bull Storm & Order Flow Veto",
                "ĐK 3.5 [SLOT B1 - VK9]: Gắn nhãn Sổ Kép Shadow+Live để theo dõi & tinh chỉnh"
            ],
            "T4": [
                "ĐK 4.1: Áp dụng Thang Vốn Thích Ứng ($25 -> $20,000) & Đòn Bẩy Động + Sigma Sizing",
                "ĐK 4.2: Quy tắc Gối Đầu Hòa Vốn Thép (cap = 1 Altcoin rủi ro cùng chiều)",
                "ĐK 4.3: Kiểm định Quantum Gate v2.0 (EV > 0, P_Win đạt chuẩn)",
                "ĐK 4.4: Kẹp SL/TP chuẩn lớp tài sản ALTCOIN [1.50%, 3.50%]"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK9]: Chiết khấu nhanh +0.12% đến +0.28% (0.18×ATR · BOM #102F) đặt Limit Maker Post-Only đón nhịp retest đỉnh râu cực đại trên M1",
                "ĐK 5.2 [M1 RIÊNG VK9]: Hủy ngay nếu nến M1 đâm thủng đỉnh râu Climax",
                "ĐK 5.3 [M1 RIÊNG VK9]: Rút lệnh nếu Taker Buy áp đảo >= 75% ở cận khớp <= 0.35%",
                "ĐK 5.4 [M1 RIÊNG VK9]: Hủy rình nếu giá sập vượt > 1.5x ATR trước khi khớp",
                "ĐK 5.5 [M1 RIÊNG VK9]: Ghi Shadow nếu bị hủy an toàn (sau khi sàn xác nhận hủy)"
            ],
            "T6": [
                "ĐK 6.1: Quét WebSocket @bookTicker nhịp 2.0s bảo vệ vị thế tức thì",
                "ĐK 6.2: Vòng 1 - Thoát hiểm Shock Rescue nếu xuất hiện bão bơm M1 ngược chiều",
                "ĐK 6.3: Vòng 2 - Cushion SL (-0.25%) và Flash Hard BE (+0.22% Net BE tại +0.85%)",
                "ĐK 6.4: Vòng 3 - Chốt 50% TP1 và gồng Runner theo Trailing/ChoCH",
                "ĐK 6.5: Tự động cộng dồn vào Sổ Kép Live để đánh giá thăng hạng / thay thế"
            ]
        }
    },
    "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI": {
        "id": "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI",
        "code": "VK10",
        "name_vi": "Vũ Khí 10: Mua Đáy Rút Chân TradFi (Chuẩn S13)",
        "short_name": "VK10 · Mua Đáy Rút Chân TradFi (S13)",
        "side": "LONG",
        "icon": "🏛️",
        "color": "#10b981",
        "is_experimental": True,
        "experimental_badge_vi": "🧪 THỬ NGHIỆM",
        "asset_class_target": "TRADFI",
        "group_vi": "PHE MUA (SLOT B1 TRADFI · 🧪 THỬ NGHIỆM)",
        "target_goal_vi": "Bắt đáy rút chân trên Hàng hóa (Dầu) & Cổ phiếu/ETF TradFi chuẩn S13 (loại sạch phiên chết TIMEOUT_60M)",
        "when_to_use_vi": [
            "Lớp tài sản TRADFI · Trap BUY + AI BUY bất chấp JEV 4H SELL trễ pha",
            "Chuẩn S13: ATR_15M >= 0.38%, ADX <= 30, không phải strong_downtrend, L_Wick >= 38%, RSI >= 33, RVol >= 0.85x",
            "Vốn thích ứng & SL chuẩn TradFi (1x: [1.0%-1.8%], ETF 3x: [1.8%-3.5%])"
        ],
        "when_forbidden_vi": [
            "CẤM DÙNG trong giờ Mở Phiên Mỹ (21:30–22:30 VN · Opening Bell Veto Rule 0.7 #3)",
            "CẤM DÙNG trên hàng hóa rơi thác mạnh (strong_downtrend / ADX > 30) hoặc phiên Á chết biên (ATR < 0.38%)",
            "CẤM BẮT ĐÁY Bear ETF khi Benchmark đang Uptrend & tuân thủ đủ 4 Rào Chắn 10 Ngành TradFi"
        ],
        "stage_conditions_tree": {
            "T1": [
                "ĐK 1.1: Lớp tài sản TRADFI (Dầu CL/BZ, Cổ phiếu, ETF) · RVol >= 0.85x",
                "ĐK 1.2: Co giãn ATR_15M >= 0.38% (Loại sạch phiên Á chết thanh khoản TIMEOUT_60M)",
                "ĐK 1.3: ADX <= 30.0 và Regime != strong_downtrend (Loại sạch Vàng/Bạc rơi thác)",
                "ĐK 1.4: Vận hành độc lập với Crypto AI Bias (TradFi Independent Gate)"
            ],
            "T2": [
                "ĐK 2.1: Râu rút chân dưới L_Wick >= 38.0% (Loại sạch nến thân đặc không râu)",
                "ĐK 2.2: RSI 15M >= 33.0 (Tránh vùng quá bán đứng im chôn vốn)",
                "ĐK 2.3: Máy dò bẫy TrapDetector xác nhận rút chân BUY",
                "ĐK 2.4: Không nằm trong Bão Xả Cực Đại (Extreme Bear Storm)",
                "ĐK 2.5: Không rơi vào giờ Đóng Cửa Phố Wall (TradFi Dead Zone)"
            ],
            "T3": [
                "ĐK 3.1 [SLOT B1 - VK10]: AI Ensemble xác nhận MUA đồng pha với TrapDetector BUY",
                "ĐK 3.2 [SLOT B1 - VK10]: Mở khóa chuẩn S13 (85.7% Strict TP · 0% SL lịch sử)",
                "ĐK 3.3 [SLOT B1 - VK10]: Đồng bộ weighted_score >= +0.82 và agreement_ratio >= 0.65",
                "ĐK 3.4 [SLOT B1 - VK10]: Giữ nguyên 100% Opening Bell Veto & Bear ETF Trap Veto",
                "ĐK 3.5 [SLOT B1 - VK10]: Gắn nhãn Sổ Kép Shadow+Live để theo dõi & tinh chỉnh"
            ],
            "T4": [
                "ĐK 4.1: Áp dụng 4 Rào Chắn Tương Hỗ 10 Phân Lớp TradFi (Tối đa 1 vị thế/ngành)",
                "ĐK 4.2: Thang Vốn Thích Ứng ($25 -> $20,000) & Trần Đòn Bẩy TradFi (<= 4x)",
                "ĐK 4.3: Kiểm định Quantum Gate v2.0 & kẹp SL TradFi (1x [1.0%-1.8%], ETF [1.8%-3.5%])",
                "ĐK 4.4: Xác nhận thanh khoản & Min Notional >= 6.0 USDT"
            ],
            "T5_M1": [
                "ĐK 5.1 [M1 RIÊNG VK10]: Đặt Limit Maker Post-Only đón nhịp retest đáy rút chân trên M1",
                "ĐK 5.2 [M1 RIÊNG VK10]: Hủy ngay nếu nến M1 xuyên thủng đáy cao trào",
                "ĐK 5.3 [M1 RIÊNG VK10]: Rút lệnh nếu Taker Sell xả >= 75% ở cận khớp <= 0.35%",
                "ĐK 5.4 [M1 RIÊNG VK10]: Hủy rình nếu giá bật bay > 1.5x ATR trước khi khớp",
                "ĐK 5.5 [M1 RIÊNG VK10]: Ghi Shadow an toàn sau khi sàn xác nhận hủy"
            ],
            "T6": [
                "ĐK 6.1: Quét WebSocket @bookTicker nhịp 2.0s bảo vệ vị thế TradFi tức thì",
                "ĐK 6.2: Vòng 1 - Cushion SL (-0.25%) & Shock Rescue bảo vệ vốn tuyệt đối",
                "ĐK 6.3: Vòng 2 - Flash Hard BE tại +0.85% (đặc trị biên độ TradFi, ăn trọn sóng như MUU!)",
                "ĐK 6.4: Vòng 3 - Chốt 50% TP1 (+1.5% -> +3.0%) & Trailing Stop",
                "ĐK 6.5: Tự động cộng dồn vào Sổ Kép Live để đánh giá thăng hạng / thay thế"
            ]
        }
    },
}


# ==============================================================================
# 2. NHẬN DIỆN VŨ KHÍ TỪ TÍN HIỆU (WEAPON CLASSIFIER)
# ==============================================================================
def classify_signal_weapon(signal_obj: Any = None, meta: Optional[Dict[str, Any]] = None, direction: str = "") -> Dict[str, Any]:
    """
    Phân loại chính xác một tín hiệu hoặc vị thế đang sử dụng Vũ Khí nào trong Kho 8 Vũ Khí Tiếng Việt.
    Luôn trả về thông tin đầy đủ kèm Cây 28 Ô Điều Kiện 6 Tầng.
    """
    m = dict(meta or {})
    if signal_obj is not None and isinstance(getattr(signal_obj, 'metadata', None), dict):
        merged = dict(signal_obj.metadata)
        merged.update(m)
        m = merged

    sig_dir = str(direction or m.get('direction') or '').upper()
    if not sig_dir and signal_obj is not None:
        raw_s = getattr(signal_obj, 'signal', None)
        s_name = str(getattr(raw_s, 'name', raw_s) or '').upper()
        if 'BUY' in s_name or 'LONG' in s_name:
            sig_dir = 'LONG'
        elif 'SELL' in s_name or 'SHORT' in s_name:
            sig_dir = 'SHORT'
    if sig_dir == 'BUY':
        sig_dir = 'LONG'
    elif sig_dir == 'SELL':
        sig_dir = 'SHORT'

    explicit_id = str(m.get('weapon_id') or '')
    if explicit_id in WEAPON_ARSENAL_CATALOG:
        w_cat = WEAPON_ARSENAL_CATALOG[explicit_id]
        # [BOM #20 FIX]: Chỉ chấp nhận weapon_id tường minh nếu chiều lệnh khớp (tránh lệnh bị Order Flow lật ngược vẫn giữ nhãn cũ)
        if not sig_dir or w_cat["side"] in ("BOTH", sig_dir):
            w_info = dict(w_cat)
            w_info["resolved_direction"] = sig_dir or w_info["side"]
            return w_info
    elif explicit_id:
        # [BOM #33 FIX]: Hỗ trợ nhận diện Vũ Khí Động (DYN-VK11..14) đã lưu trong weapon_lifecycle.json
        try:
            from core.quant_evolution_engine import load_weapon_lifecycle
            _dyn_map_c = (load_weapon_lifecycle().get("dynamic_weapons") or {})
            if explicit_id in _dyn_map_c:
                w_cat = _dyn_map_c[explicit_id]
                if not sig_dir or w_cat.get("side") in ("BOTH", sig_dir):
                    w_info = dict(w_cat)
                    w_info["resolved_direction"] = sig_dir or w_info.get("side", "LONG")
                    return w_info
        except Exception:
            pass

    trap_type = str(m.get('type') or m.get('trap_type') or m.get('primary_setup_type') or '').upper()
    _contrib = m.get('contributing_strategies') or []
    _contrib_str = ','.join(str(x) for x in _contrib) if isinstance(_contrib, (list, tuple, set)) else str(_contrib)
    strat_name = ' '.join(filter(None, [
        str(getattr(signal_obj, 'strategy', '') if signal_obj is not None else m.get('strategy', '')),
        str(m.get('tech_pathway_key') or ''),
        _contrib_str,
    ])).lower()

    # [BOM #121K + #122C FIX]: Whale Pump Storm (RSI >= 60, Pump >= 2.0%, RVol >= 2.0x, U_Wick < 30%) la thuan song ca map (VK1), KHONG BAO GIO la bat nay qua ban (VK4)
    # Doc ca top-level metadata lan market_analysis (aggregator ghi c_recent_pump_pct / c_upper_wick_pct o top-level va rsi trong market_analysis)
    _ma_121k = m.get('market_analysis') if isinstance(m.get('market_analysis'), dict) else {}
    def _f121k(*keys):
        for _src in (m, _ma_121k):
            for _k in keys:
                _v = _src.get(_k)
                if _v is not None:
                    try:
                        return float(_v)
                    except (TypeError, ValueError):
                        continue
        return None
    # [BOM #125C + #131C FIX]: Ưu tiên RSI khung tác chiến 15M; phân tách rõ nguồn thập phân (c_recent_pump_pct/recent_pump_pct) vs nguồn % (pump_pct) để không phóng đại 0.25% -> 25%!
    _rsi_121k = _f121k('tactical_rsi', 'rsi_15m', 'current_rsi', 'rsi')
    _pump_dec_131 = _f121k('c_recent_pump_pct', 'recent_pump_pct', 'close_pump_pct')
    if _pump_dec_131 is not None:
        _pump_121k = _pump_dec_131 * 100.0 if abs(_pump_dec_131) <= 1.0 else _pump_dec_131
    else:
        _pump_121k = _f121k('pump_pct')
    _rv_121k = _f121k('rvol', 'c_vol_ratio', 'vol_ratio', 'candle_vol_ratio')
    # [BOM #141 FIX - M4]: Tách rõ khóa thập phân (c_*_wick_pct / *_wick_pct) khỏi khóa % (u_wick_pct / uw_pct) để không nhân 0.5% -> 50%!
    _uw_dec_141 = _f121k('c_upper_wick_pct', 'upper_wick_pct')
    if _uw_dec_141 is not None:
        _uw_121k = _uw_dec_141 * 100.0 if 0.0 <= _uw_dec_141 <= 1.0 else _uw_dec_141
    else:
        _uw_121k = _f121k('u_wick_pct', 'uw_pct')
    _lw_dec_141 = _f121k('c_lower_wick_pct', 'lower_wick_pct')
    if _lw_dec_141 is not None:
        _lw_121k = _lw_dec_141 * 100.0 if 0.0 <= _lw_dec_141 <= 1.0 else _lw_dec_141
    else:
        _lw_121k = _f121k('l_wick_pct', 'lw_pct')
    # [BOM #140 FIX - PHÁP Y AIOT/USDT -$1.03 TRONG 3 GIÂY]: Cấm _is_whale_pump_121k cướp nhãn tín hiệu BEAR_TRAP / is_oversold_bounce
    # hoặc nến râu dưới rút chân >= 35% thành VK1 (vượt rào VK3 PAUSED & VK4 RSI<=50)!
    _is_whale_pump_121k = (
        sig_dir != 'SHORT'
        and not ('BEAR_TRAP' in trap_type or bool(m.get('is_oversold_bounce')))
        and _rsi_121k is not None and _rsi_121k >= 60.0
        and _pump_121k is not None and _pump_121k >= 2.0
        and _rv_121k is not None and _rv_121k >= 2.0
        and (_uw_121k is None or _uw_121k < 30.0)
        and (_lw_121k is None or _lw_121k < 35.0)
    )

    if (sig_dir != 'LONG') and (bool(m.get('is_vk9_climax_wick_short')) or trap_type == 'VK9_CLIMAX_WICK_SHORT'):
        w_key = "VK9_SHORT_BAN_DINH_RAU_CUC_DAI"
    elif (sig_dir != 'SHORT') and (bool(m.get('is_vk10_tradfi_bottom_long')) or trap_type == 'VK10_TRADFI_BOTTOM_WICK_LONG'):
        w_key = "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI"
    elif (sig_dir != 'SHORT') and (bool(m.get('is_parabolic_long_inversion')) or trap_type == 'PARABOLIC_LONG_INVERSION_ALPHA2'):
        w_key = "VK2_LONG_LAT_NGUOC_SONG_PARABOL"
    elif (sig_dir != 'SHORT') and (bool(m.get('is_momentum_ride')) or _is_whale_pump_121k):
        w_key = "VK1_LONG_THUAN_SONG_CA_MAP"
    elif (sig_dir != 'SHORT') and (bool(m.get('is_oversold_bounce')) or trap_type in ('SELLING_CLIMAX', 'PANIC_CLIMAX_BOUNCE', 'OVERSOLD_BOUNCE')) and 'BEAR_TRAP' not in trap_type:
        w_key = "VK4_LONG_BAT_NAY_QUA_BAN"
    elif (sig_dir != 'LONG') and bool(m.get('is_waterfall_short')):
        w_key = "VK5_SHORT_THAC_DO_CA_MAP_XA"
    elif (sig_dir != 'LONG') and (trap_type == 'BUYING_CLIMAX' or (bool(m.get('is_fading_short')) and 'BULL_TRAP' not in trap_type)):
        w_key = "VK6_SHORT_BAT_DINH_KIET_SUC"
    elif sig_dir == 'LONG' and ('BEAR_TRAP' in trap_type or 'trap' in strat_name):
        w_key = "VK3_LONG_SAN_RU_GOM_DAY"
    elif sig_dir == 'SHORT' and ('BULL_TRAP' in trap_type or 'trap' in strat_name):
        w_key = "VK7_SHORT_BAY_TANG_GIA_RAU_XA"
    elif sig_dir == 'LONG' and 'breakout' in strat_name and bool(m.get('is_momentum_ride')):
        w_key = "VK1_LONG_THUAN_SONG_CA_MAP"
    elif sig_dir == 'SHORT' and 'breakout' in strat_name and bool(m.get('is_waterfall_short')):
        w_key = "VK5_SHORT_THAC_DO_CA_MAP_XA"
    else:
        w_key = "VK8_THUAN_XU_HUONG_DA_KHUNG"

    w_info = dict(WEAPON_ARSENAL_CATALOG.get(w_key, WEAPON_ARSENAL_CATALOG["VK8_THUAN_XU_HUONG_DA_KHUNG"]))
    w_info["resolved_direction"] = sig_dir or ("LONG" if w_info["side"] == "LONG" else "SHORT")
    return w_info


# ==============================================================================
# 3. CƠ CHẾ SINH VẬT SỐNG TỰ THÍCH ỨNG (LIVING ADAPTIVE ORGANISM ENGINE)
# ==============================================================================
def _resolve_default_db_path(db_path: Optional[str] = None) -> str:
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if not db_path or db_path == 'data/trade_bot.db':
        return os.path.join(base_dir, 'data', 'trade_bot.db')
    if not os.path.isabs(db_path):
        return os.path.join(base_dir, db_path)
    return db_path


def _vk_code_sort_key(w: Dict[str, Any]) -> Tuple[int, str]:
    code = str((w or {}).get("code") or "").strip().upper()
    wid = str((w or {}).get("weapon_id") or (w or {}).get("id") or "")
    if code.startswith("VK") and code[2:].isdigit():
        return int(code[2:]), wid
    head = wid.split("_")[0].upper()
    if head.startswith("VK") and head[2:].isdigit():
        return int(head[2:]), wid
    return 9999, wid


def get_living_arsenal_status(db_path: str = 'data/trade_bot.db', rolling_limit: int = 400) -> Dict[str, Any]:
    """
    [V6.1 BO NHO KEP - ETERNAL SO KEP + FRESH EXPONENTIAL HALF-LIFE (6h/12h/24h) + BAYES alpha0=4]:
    - So Kep Lich Su (Shadow + Live W/L & PnL $): Luon giu vinh vien qua moi lan restart/cup dien.
    - Nhan '🔥 UU TIEN / 🛡️ HA NHIET': Tinh bang Ham Mu Ban Ra theo phan lop (ALT 6h / MAJ 12h / TRF 24h)
      + Thu Hoi Bayes Beta-Binomial (alpha0=4) -> Restart 1p giu 100%; cup dien 24h tu truot em ve Trung lap 1.0x!
    - Dong bo trang thai vong doi 2 chieu tu config/weapon_lifecycle.json (OFFICIAL/EXPERIMENTAL/LAB_DEMOTED/PAUSED/DELETED).
    """
    import math as _math
    from core.quant_evolution_engine import (
        load_weapon_lifecycle,
        compute_weapon_half_life_hours,
        bayes_shrunk_win_rate,
        synthesize_dynamic_weapon_tree,
    )

    db_path = _resolve_default_db_path(db_path)
    lc_data = load_weapon_lifecycle()
    lc_states = lc_data.get("states") or {}
    dyn_weapons = lc_data.get("dynamic_weapons") or {}
    now_sec = time.time()

    combined_catalog: Dict[str, Dict[str, Any]] = {}
    for w_id, w_cfg in WEAPON_ARSENAL_CATALOG.items():
        combined_catalog[w_id] = dict(w_cfg)
    for d_id, d_cfg in dyn_weapons.items():
        d_copy = dict(d_cfg)
        if not d_copy.get("stage_conditions_tree"):
            d_copy["stage_conditions_tree"] = synthesize_dynamic_weapon_tree(d_copy)
        combined_catalog[d_id] = d_copy

    weapon_stats: Dict[str, Dict[str, Any]] = {}
    for w_id, w_cfg in combined_catalog.items():
        tree = w_cfg.get("stage_conditions_tree") or {}
        total_conds = sum(len(v) for v in tree.values())
        cur_lc_state = lc_states.get(w_id) or ("EXPERIMENTAL" if w_cfg.get("is_experimental") else "OFFICIAL")
        is_exp_eff = (cur_lc_state == "EXPERIMENTAL")
        hl_h = compute_weapon_half_life_hours(str(w_cfg.get("asset_class_target") or "ALTCOIN"))
        weapon_stats[w_id] = {
            **w_cfg,
            "is_experimental": is_exp_eff,
            "lifecycle_state": cur_lc_state,
            "half_life_hours": hl_h,
            "total_conditions_count": total_conds,
            "shadow_samples": 0,
            "shadow_tp1_wins": 0,
            "shadow_sl_hits": 0,
            "shadow_win_rate": 0.0,
            "fresh_w_wins": 0.0,
            "fresh_w_total": 0.0,
            "fresh_bayes_wr": 50.0,
            "live_trades": 0,
            "live_wins": 0,
            "live_losses": 0,
            "live_sl_hits": 0,
            "live_win_rate": 0.0,
            "live_net_pnl": 0.0,
            "live_gross_profit": 0.0,
            "live_gross_loss": 0.0,
            "live_pf": 0.0,
            "dual_ledger_vi": "Sổ kép: 0 Shadow + 0 Live",
            "adaptive_mode": "SAN_SANG_MAC_DINH",
            "adaptive_badge_vi": "⚡ SẴN SÀNG CHIẾN ĐẤU (MẶC ĐỊNH)",
            "adaptive_weight_mult": 1.0,
            "adaptive_advice_vi": "Cho phép vào lệnh ngay khi hội tụ đủ điều kiện Kỹ thuật + AI + 4H",
        }

    total_shadow_eval = 0
    long_tp1_count = 0
    short_tp1_count = 0
    long_eval_count = 0
    short_eval_count = 0

    _arsenal_db_ok = True
    if os.path.exists(db_path):
        conn = None
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=2.0)
            conn.execute("PRAGMA query_only = ON;")
            cur = conn.cursor()

            cur.execute("""
                SELECT timestamp, symbol, direction, asset_class, station_blocked, block_reason, rvol, outcome, details_json
                FROM shadow_pathfinder_logs
                WHERE outcome IN ('TP1_HIT', 'SL_HIT', 'TIMEOUT_60M', 'TIMEOUT_240M')
                ORDER BY id DESC LIMIT ?
            """, (int(rolling_limit * 2),))
            s_rows = cur.fetchall()

            for ts_raw, sym_col_sh, d_raw, a_cls, st_blk, b_reason, rvol_val, out_val, det_json in s_rows:
                ts_sec_row = (float(ts_raw) / 1000.0) if (ts_raw and float(ts_raw) > 1e11) else float(ts_raw or now_sec)
                age_h = max(0.0, (now_sec - ts_sec_row) / 3600.0)
                d_str = str(d_raw or 'LONG').upper()
                b_str = str(b_reason or '').upper()
                rv = float(rvol_val) if rvol_val is not None else 1.0  # [BOM #121K FIX]: RVol=0.0 hop le, khong ep thanh 1.0
                det = {}
                if det_json:
                    try:
                        det = json.loads(det_json)
                    except Exception:
                        det = {}
                dual = det.get('dual_eval_240m') or det.get('dual_eval_60m') or {}
                direct_res = str(dual.get('direct_1to1') or dual.get('direct_1to2') or out_val or '')
                invert_res = str(dual.get('inverted_1to1') or dual.get('inverted_1to2') or '')

                long_res = str(dual.get('long_1to1') or dual.get('long_1to2') or (direct_res if d_str == 'LONG' else invert_res))
                short_res = str(dual.get('short_1to1') or dual.get('short_1to2') or (direct_res if d_str == 'SHORT' else invert_res))

                if long_res in ('TP1_HIT', 'SL_HIT'):
                    long_eval_count += 1
                    if long_res == 'TP1_HIT':
                        long_tp1_count += 1
                if short_res in ('TP1_HIT', 'SL_HIT'):
                    short_eval_count += 1
                    if short_res == 'TP1_HIT':
                        short_tp1_count += 1

                # Nhận diện Vũ Khí chính xác từ details_json (primary_setup_type + DNA nến + JEV + weapon_id)
                dna = det.get('layer2_candle_dna') or {}
                c_dna = det.get('layer3_consensus_dna') or {}
                setup_up = str(det.get('primary_setup_type') or '').upper()
                path_up = str(det.get('tech_pathway_key') or '').upper()
                ac_up = str(a_cls or det.get('asset_class') or '').upper()
                # [BOM #121K FIX]: Chuan hoa phan lop Shadow (TRADFI_1X / TRADFI_ETF_3X / COMMODITY / GOLD / OIL -> TRADFI) de khop DNA VK10
                if 'TRADFI' in ac_up or ac_up in ('COMMODITY', 'GOLD', 'OIL'):
                    ac_up = 'TRADFI'
                gate_up = str(det.get('layer4_exact_veto_gate') or '').upper()
                rsi_v = float(dna.get('rsi') or 50.0)
                adx_v = float(dna.get('adx') or 0.0)
                atr_v = float(dna.get('atr_pct') or 0.0)
                reg_v = str(dna.get('regime') or '').lower()
                uw_v = float(dna.get('u_wick_pct') or 0.0)
                lw_v = float(dna.get('l_wick_pct') or 0.0)
                pump_v = float(dna.get('pump_pct') or 0.0)
                dump_v = float(dna.get('dump_pct') or 0.0)
                ai_v_sh = str(c_dna.get('ai_vote') or '').upper()
                jev_v = str(c_dna.get('jev_vote') or '').upper()
                explicit_w = str(det.get('weapon_id') or '')

                is_vk9_sh = (
                    ac_up == 'ALTCOIN' and 'TRAP_DETECTOR:SELL' in path_up and 'TREND_FOLLOWING:BUY' in path_up
                    and ai_v_sh == 'SELL' and jev_v == 'BUY' and gate_up == 'T3_JEV_SHIELD_NEED_2_STRATS'
                    and uw_v >= 65.0 and lw_v < 25.0 and rsi_v < 65.0 and rv >= 1.33 and adx_v >= 20.0
                )
                _sym_sh_147 = str(sym_col_sh or det.get('symbol') or '')
                _is_bear_etf_sh_147 = False
                if _sym_sh_147:
                    try:
                        from core.scanner import MarketScanner as _MS147
                        _is_bear_etf_sh_147 = bool(_MS147.is_bear_inverse_etf(_sym_sh_147))
                    except Exception:
                        _is_bear_etf_sh_147 = False
                is_vk10_sh = (
                    ac_up == 'TRADFI' and (not _is_bear_etf_sh_147) and 'TRAP_DETECTOR:BUY' in path_up and ai_v_sh == 'BUY' and jev_v == 'SELL'
                    and atr_v >= 0.38 and (0.0 < adx_v <= 30.0) and ('strong_downtrend' not in reg_v)
                    and lw_v >= 38.0 and rsi_v >= 33.0 and rv >= 0.85
                )

                # [BOM #95H + BOM #110B + BOM #147 P1-9 FIX]: Ưu tiên explicit_w trong combined_catalog TRƯỚC nhánh heuristic VK2
                # để không đánh cắp mẫu Shadow đã gắn nhãn rõ VK6/VK7 vào VK2!
                if explicit_w in combined_catalog and bool(combined_catalog[explicit_w].get("is_dynamic")):
                    w_target = explicit_w
                    # [BOM #121K + #141 H1 FIX]: Chỉ lật khi vũ khí 1 chiều (LONG/SHORT) ngược chiều d_str;
                    # với vũ khí 2 chiều (side="BOTH" như VK11), Shadow explicit_w đã ghi nhận hướng cuối cùng -> cấm đảo 180 độ!
                    _dyn_cat_121k = combined_catalog[explicit_w] or {}
                    _dyn_side_121k = str(_dyn_cat_121k.get("side") or "").upper()
                    _dyn_inverted_121k = (_dyn_side_121k in ("LONG", "SHORT") and _dyn_side_121k != d_str)
                    _dyn_res_121k = invert_res if (_dyn_inverted_121k and invert_res) else direct_res
                    is_win = (_dyn_res_121k == 'TP1_HIT')
                    is_loss = (_dyn_res_121k == 'SL_HIT')
                elif is_vk9_sh and short_res in ('TP1_HIT', 'SL_HIT'):
                    w_target = "VK9_SHORT_BAN_DINH_RAU_CUC_DAI"
                    is_win = (short_res == 'TP1_HIT')
                    is_loss = (short_res == 'SL_HIT')
                elif is_vk10_sh and long_res in ('TP1_HIT', 'SL_HIT'):
                    w_target = "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI"
                    is_win = (long_res == 'TP1_HIT')
                    is_loss = (long_res == 'SL_HIT')
                elif explicit_w in combined_catalog:
                    w_target = explicit_w
                    _w_cat_sh = combined_catalog[explicit_w] or {}
                    _w_side_sh = str(_w_cat_sh.get("side") or "").upper()
                    _use_res_sh = (
                        invert_res
                        if (_w_side_sh in ("LONG", "SHORT") and _w_side_sh != d_str and invert_res)
                        else direct_res
                    )
                    is_win = (_use_res_sh == 'TP1_HIT')
                    is_loss = (_use_res_sh == 'SL_HIT')
                elif ac_up == 'ALTCOIN' and d_str == 'SHORT' and 'TRAP_DETECTOR:SELL' in path_up and jev_v == 'BUY' and rsi_v >= 65.0 and 1.10 <= rv <= 3.50 and invert_res in ('TP1_HIT', 'SL_HIT'):
                    w_target = "VK2_LONG_LAT_NGUOC_SONG_PARABOL"
                    is_win = (invert_res == 'TP1_HIT')
                    is_loss = (invert_res == 'SL_HIT')
                else:
                    if d_str == 'LONG':
                        if setup_up in ('SELLING_CLIMAX', 'PANIC_CLIMAX_BOUNCE', 'OVERSOLD_BOUNCE') or (rsi_v <= 35.0 and 'BEAR_TRAP' not in setup_up):
                            w_target = "VK4_LONG_BAT_NAY_QUA_BAN"
                        elif setup_up == 'BEAR_TRAP_WICK' or lw_v >= 35.0 or ('TRAP' in path_up and lw_v >= 25.0):
                            w_target = "VK3_LONG_SAN_RU_GOM_DAY"
                        elif rv >= 1.80 or pump_v >= 1.20 or 'BREAKOUT' in path_up:
                            w_target = "VK1_LONG_THUAN_SONG_CA_MAP"
                        else:
                            w_target = "VK8_THUAN_XU_HUONG_DA_KHUNG"
                    else:
                        if setup_up == 'BUYING_CLIMAX' or (uw_v >= 35.0 and pump_v >= 1.00) or 'FADING' in b_str:
                            w_target = "VK6_SHORT_BAT_DINH_KIET_SUC"
                        elif setup_up == 'BULL_TRAP_WICK' or uw_v >= 35.0 or 'TRAP_DETECTOR' in path_up:
                            w_target = "VK7_SHORT_BAY_TANG_GIA_RAU_XA"
                        elif dump_v >= 1.20 or rv >= 1.50:
                            w_target = "VK5_SHORT_THAC_DO_CA_MAP_XA"
                        else:
                            w_target = "VK8_THUAN_XU_HUONG_DA_KHUNG"
                    is_win = (direct_res == 'TP1_HIT')
                    is_loss = (direct_res == 'SL_HIT')

                if is_win or is_loss:
                    total_shadow_eval += 1
                    st_w = weapon_stats[w_target]
                    st_w["shadow_samples"] += 1
                    hl_w = float(st_w.get("half_life_hours") or 6.0)
                    decay_w = _math.pow(0.5, age_h / hl_w)
                    st_w["fresh_w_total"] += decay_w
                    if is_win:
                        st_w["shadow_tp1_wins"] += 1
                        st_w["fresh_w_wins"] += decay_w
                    if is_loss:
                        st_w["shadow_sl_hits"] += 1

            # [SỔ KÉP SHADOW + LIVE - BOM #83 FIX, BOM #95H FIX]: Mo cua so 2500 signals / 1500 trades,
            # khu trung 2x PnL khi cung order_id co ca 'Binance Fill' lan 'aggregated', va sua pos_dir chuan 100%!
            sig_lookup: Dict[str, List[Tuple[int, str, str]]] = {}
            try:
                cur.execute("""
                    SELECT timestamp, symbol, signal_type, indicators_json
                    FROM signals
                    ORDER BY id DESC LIMIT 2500
                """)
                for s_ts, s_sym, s_dir, ind_raw in cur.fetchall():
                    if not ind_raw:
                        continue
                    try:
                        ind_j = json.loads(ind_raw)
                    except Exception:
                        continue
                    if str(ind_j.get('execution_status') or '').upper() != 'PASSED':
                        continue
                    s_meta = ind_j.get('metadata') if isinstance(ind_j.get('metadata'), dict) else {}
                    w_id_sig = str(s_meta.get('weapon_id') or '')
                    if w_id_sig not in combined_catalog:
                        w_id_sig = classify_signal_weapon(meta=s_meta, direction=str(s_dir or '')).get('id', '')
                    if w_id_sig in combined_catalog:
                        k_sym = str(s_sym or '').replace('/', '').split(':')[0].upper()
                        ts_ms = int(s_ts or 0)
                        if ts_ms < 10_000_000_000:
                            ts_ms *= 1000
                        sig_lookup.setdefault(k_sym, []).append((ts_ms, str(s_dir or '').upper(), w_id_sig))
            except Exception:
                pass

            cur.execute("""
                SELECT timestamp, symbol, side, strategy, realized_pnl, pnl, fee, order_id, close_reason, raw_json,
                       cost, price, amount, exchange_trade_id, commission_asset
                FROM trades
                WHERE mode = 'live'
                ORDER BY id DESC LIMIT 2000
            """)
            grouped_live: Dict[str, Dict[str, Any]] = {}
            entry_fill_times: Dict[str, List[Tuple[int, str]]] = {}
            for (
                t_ts, sym, side_val, strat_val, rpnl_raw, pnl_raw, fee_v, ord_id,
                c_reason, raw_j_str, cost_v, px_v, amt_v, ex_tid, comm_asset
            ) in cur.fetchall():
                try:
                    t_ms = int(float(t_ts or 0))
                    if 0 < t_ms < 10_000_000_000:
                        t_ms *= 1000
                except Exception:
                    t_ms = 0
                k_sym = str(sym or '').replace('/', '').split(':')[0].upper()
                side_u = str(side_val or '').strip().upper()
                is_close_row = bool(c_reason and str(c_reason).strip()) or (
                    abs(float(rpnl_raw if rpnl_raw is not None else (pnl_raw or 0.0) or 0.0)) > 1e-8
                )
                if not is_close_row:
                    if side_u in ('BUY', 'SELL'):
                        entry_fill_times.setdefault(k_sym, []).append((t_ms, 'LONG' if side_u == 'BUY' else 'SHORT'))
                    continue
                raw_wid = ""
                try:
                    if raw_j_str:
                        _rj = json.loads(raw_j_str) if isinstance(raw_j_str, str) else raw_j_str
                        if isinstance(_rj, dict):
                            raw_wid = str(_rj.get("weapon_id") or "").strip()
                except Exception:
                    raw_wid = ""
                grp_key = f"{k_sym}_{ord_id}" if ord_id else f"{k_sym}_{t_ms // 60000}"
                is_bf_row = bool(str(ex_tid or '').strip()) or (str(strat_val or '').strip().lower() == 'binance fill')
                comm_u = str(comm_asset or 'USDT').strip().upper()
                fee_usd = float(fee_v or 0.0) if comm_u in ('', 'USDT', 'USDC', 'BUSD', 'FDUSD') else 0.0
                # [BOM #126A FIX]: Cột `pnl` của bot-row (realized_pnl IS NULL) đã là net_pnl sau phí — không trừ fee_usd lần 2!
                row_net = (float(rpnl_raw) - fee_usd) if rpnl_raw is not None else float(pnl_raw or 0.0)
                row_noti = float(cost_v or 0.0)
                if row_noti <= 0.0 and px_v and amt_v:
                    try:
                        row_noti = abs(float(px_v) * float(amt_v))
                    except (TypeError, ValueError):
                        row_noti = 0.0
                g = grouped_live.get(grp_key)
                if g is None:
                    grouped_live[grp_key] = {
                        "ts_ms": t_ms,
                        "k_sym": k_sym,
                        "side": side_u,
                        "strategy": str(strat_val or '').strip(),
                        "bf_pnl": row_net if is_bf_row else 0.0,
                        "bot_pnl": 0.0 if is_bf_row else row_net,
                        "bf_noti": row_noti if is_bf_row else 0.0,
                        "bot_noti": 0.0 if is_bf_row else row_noti,
                        "has_bf": is_bf_row,
                        "close_reason": str(c_reason or ''),
                        "raw_wid": raw_wid,
                    }
                else:
                    if is_bf_row:
                        g["bf_pnl"] += row_net
                        g["bf_noti"] += row_noti
                        g["has_bf"] = True
                    else:
                        g["bot_pnl"] += row_net
                        g["bot_noti"] += row_noti
                    if t_ms > g["ts_ms"]:
                        g["ts_ms"] = t_ms
                    if c_reason and not g.get("close_reason"):
                        g["close_reason"] = str(c_reason)
                    if raw_wid and not g.get("raw_wid"):
                        g["raw_wid"] = raw_wid

            generic_strats = (
                '', 'binance fill', 'aggregated', 'unknown', 'manual',
                'manual_adopted', 'reconciled', 'exchange_reconciled',
                'bot_handoff_recovered', 'sniper_m1',
            )
            merged_live_cycles: List[Dict[str, Any]] = []
            for g in sorted(grouped_live.values(), key=lambda x: x["ts_ms"]):
                g["net_pnl"] = g["bf_pnl"] if g.get("has_bf") else g["bot_pnl"]
                est_noti = g["bf_noti"] if (g.get("has_bf") and g["bf_noti"] > 0) else g["bot_noti"]
                strat_clean = g["strategy"]
                strat_low = strat_clean.lower()
                if g["side"] not in ('BUY', 'SELL'):
                    continue
                pos_dir = 'LONG' if g["side"] == 'SELL' else 'SHORT'
                sig_dir_need = 'BUY' if pos_dir == 'LONG' else 'SELL'
                w_id = str(g.get("raw_wid") or "") if str(g.get("raw_wid") or "") in combined_catalog else ""
                if not w_id and strat_low in generic_strats:
                    cands_s = sig_lookup.get(g["k_sym"]) or []
                    best_dt = 48 * 3600 * 1000 + 1
                    for s_ms, s_d, s_wid in cands_s:
                        dt_diff = g["ts_ms"] - s_ms
                        if 0 <= dt_diff <= 48 * 3600 * 1000 and s_d == sig_dir_need and dt_diff < best_dt:
                            best_dt = dt_diff
                            w_id = s_wid
                if not w_id and strat_clean and strat_low not in generic_strats:
                    w_id = classify_signal_weapon(meta={'strategy': strat_clean, 'direction': pos_dir}, direction=pos_dir).get('id', '')
                if w_id not in weapon_stats:
                    continue

                cr_up = str(g.get("close_reason") or "").upper()
                is_part_hint = ("TP1" in cr_up or "CHỐT MỘT PHẦN" in cr_up or "KÍCH HOẠT KHIÊN" in cr_up)
                sym_entries = entry_fill_times.get(g["k_sym"]) or []
                merged_prev = False
                for prev_c in reversed(merged_live_cycles[-20:]):
                    if (
                        prev_c["k_sym"] == g["k_sym"]
                        and prev_c["pos_dir"] == pos_dir
                        and prev_c["w_id"] == w_id
                        and prev_c["parts"] < 6
                        and 0 <= (g["ts_ms"] - prev_c["ts_ms"]) <= 12 * 3600 * 1000
                    ):
                        if any(prev_c["ts_ms"] < e_ms < g["ts_ms"] for e_ms, _ in sym_entries):
                            continue
                        max_n = max(prev_c["notional"], est_noti)
                        split_ok = (max_n <= 0) or (abs(prev_c["notional"] - est_noti) / max_n < 0.72)
                        can_chain = prev_c.get("is_partial_hint") or (prev_c["net_pnl"] > 0.0 and split_ok)
                        if sym_entries:
                            if can_chain or (split_ok and (prev_c["net_pnl"] > 0 or g["net_pnl"] > 0 or is_part_hint)):
                                prev_c["net_pnl"] += g["net_pnl"]
                                prev_c["notional"] += est_noti
                                prev_c["ts_ms"] = g["ts_ms"]
                                prev_c["parts"] += 1
                                prev_c["is_partial_hint"] = prev_c.get("is_partial_hint") or is_part_hint
                                if g.get("close_reason"):
                                    prev_c["close_reason"] = f"{prev_c.get('close_reason', '')} | {g['close_reason']}".strip(' |')
                                merged_prev = True
                                break
                        elif (g["ts_ms"] - prev_c["ts_ms"]) <= 2700 * 1000 and (
                            max_n <= 0 or abs(prev_c["notional"] - est_noti) / max_n < 0.45
                        ):
                            prev_c["net_pnl"] += g["net_pnl"]
                            prev_c["notional"] += est_noti
                            prev_c["ts_ms"] = g["ts_ms"]
                            prev_c["parts"] += 1
                            if g.get("close_reason"):
                                prev_c["close_reason"] = f"{prev_c.get('close_reason', '')} | {g['close_reason']}".strip(' |')
                            merged_prev = True
                            break
                if not merged_prev:
                    merged_live_cycles.append({
                        "k_sym": g["k_sym"],
                        "pos_dir": pos_dir,
                        "w_id": w_id,
                        "net_pnl": float(g["net_pnl"] or 0.0),
                        "notional": float(est_noti or 0.0),
                        "ts_ms": g["ts_ms"],
                        "parts": 1,
                        "is_partial_hint": is_part_hint,
                        "close_reason": str(g.get("close_reason") or ""),
                    })

            for cyc in merged_live_cycles:
                w_id = cyc["w_id"]
                p_val = float(cyc["net_pnl"])
                cr_low = str(cyc.get("close_reason") or "").lower()
                lv_age_h = max(0.0, (now_sec - (float(cyc["ts_ms"]) / 1000.0)) / 3600.0)
                hl_lv = float(weapon_stats[w_id].get("half_life_hours") or 6.0)
                dec_lv = _math.pow(0.5, lv_age_h / hl_lv)
                weapon_stats[w_id]["live_trades"] += 1
                weapon_stats[w_id]["live_net_pnl"] = round(weapon_stats[w_id]["live_net_pnl"] + p_val, 4)
                weapon_stats[w_id]["fresh_w_total"] += dec_lv
                if p_val > 0:
                    weapon_stats[w_id]["live_wins"] += 1
                    weapon_stats[w_id]["live_gross_profit"] = round(weapon_stats[w_id]["live_gross_profit"] + p_val, 4)
                    weapon_stats[w_id]["fresh_w_wins"] += dec_lv
                else:
                    weapon_stats[w_id]["live_losses"] += 1
                    if p_val < 0:
                        weapon_stats[w_id]["live_gross_loss"] = round(weapon_stats[w_id]["live_gross_loss"] + abs(p_val), 4)
                    # [BOM #147 P1-8 + BOM #149 P1-13 + BOM #150 P1 FIX]: Đếm chuẩn SL Live cho Cổng Thăng Hạng Official:
                    # - Tính đủ các nhãn thoát lỗ V6.5 (Bẫy râu, Grace period, Thoát sớm, Đóng thủ công, Deadlock, Twin-Bar, V4 4 khung, Thoát hiểm...)
                    # - Chỉ miễn trừ profit_lock khi không mang nhãn SL thật hoặc chỉ là scratch hòa vốn (|p_val| < 0.05$)
                    _is_profit_lock_tag = any(
                        tok in cr_low for tok in ("trailing stop-loss", "khóa lãi", "hòa vốn", "choch lock", "chốt lời")
                    )
                    _is_true_sl_tag = any(
                        tok in cr_low for tok in (
                            "cắt lỗ", "stop loss", "stop-loss", "shock rescue", "twin-bar",
                            "thoát sớm 4 khung", "thoát sớm", "thoát hiểm", "đóng ngoài bot", "đóng thủ công",
                            "không khớp id sl/tp", "bẫy râu", "grace period", "deadlock",
                            "sl ", "sl;", "gần sl", "cứu hộ"
                        )
                    )
                    if (p_val < 0 and not cr_low.strip()) or (
                        p_val < 0 and _is_true_sl_tag and (not _is_profit_lock_tag or abs(p_val) >= 0.05)
                    ):
                        weapon_stats[w_id]["live_sl_hits"] += 1

        except Exception:
            _arsenal_db_ok = False
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    preferred_weapons = []
    for w_id, st in weapon_stats.items():
        # [BOM #100 + BOM #108D + BOM #116D + BOM #150 P1 FIX]: Lưu tách bạch Shadow thực tế sau thăng hạng (real_shadow_*)
        # để không che khuất suy thoái hậu thăng hạng trên VK11..VK15 khi gộp baseline Shadow LAB (verified_server_stats)!
        st["real_shadow_samples"] = int(st["shadow_samples"])
        st["real_shadow_tp1_wins"] = int(st["shadow_tp1_wins"])
        st["real_shadow_sl_hits"] = int(st["shadow_sl_hits"])
        st["real_shadow_sl_rate"] = (
            round((st["real_shadow_sl_hits"] / st["real_shadow_samples"]) * 100.0, 1)
            if st["real_shadow_samples"] > 0 else 0.0
        )
        if bool(st.get("is_dynamic")):
            dw_meta = combined_catalog.get(w_id) or {}
            v_srv_w = dw_meta.get("verified_server_stats") or {}
            base_sh_n = int(v_srv_w.get("samples_n") or 0)
            if st["shadow_samples"] < base_sh_n and base_sh_n > 0:
                base_sh_tp = int(round(base_sh_n * float(v_srv_w.get("win_rate") or 0.0) / 100.0))
                base_sh_sl = int(round(base_sh_n * float(v_srv_w.get("sl_rate") or 0.0) / 100.0))
                st["shadow_samples"] = base_sh_n
                st["shadow_tp1_wins"] = base_sh_tp
                st["shadow_sl_hits"] = base_sh_sl
                if st["live_trades"] < 3 and st["fresh_w_total"] < 1.0:
                    created_ts = float(dw_meta.get("created_at") or now_sec)
                    created_age_h = max(0.0, (now_sec - created_ts) / 3600.0)
                    hl_dyn = float(st.get("half_life_hours") or 6.0)
                    dyn_decay = _math.pow(0.5, created_age_h / max(1.0, hl_dyn))
                    seed_total = min(6.0, float(base_sh_n) * 0.30) * dyn_decay
                    tp_ratio = (float(base_sh_tp) / max(1, base_sh_n))
                    st["fresh_w_total"] += seed_total
                    st["fresh_w_wins"] += seed_total * tp_ratio
        n_samp = st["shadow_samples"]
        l_samp = st["live_trades"]
        total_samp = n_samp + l_samp
        total_wins = st["shadow_tp1_wins"] + st["live_wins"]
        wr = round((st["shadow_tp1_wins"] / n_samp) * 100.0, 1) if n_samp > 0 else 0.0
        l_wr = round((st["live_wins"] / l_samp) * 100.0, 1) if l_samp > 0 else 0.0
        comb_wr = round((total_wins / total_samp) * 100.0, 1) if total_samp > 0 else 0.0
        st["shadow_win_rate"] = wr
        st["live_win_rate"] = l_wr
        _gp_lv = float(st.get("live_gross_profit") or 0.0)
        _gl_lv = float(st.get("live_gross_loss") or 0.0)
        st["live_pf"] = round(_gp_lv / _gl_lv, 2) if _gl_lv > 1e-6 else (99.0 if _gp_lv > 0.0 else 0.0)
        st["combined_win_rate"] = comb_wr
        fresh_wr = bayes_shrunk_win_rate(st["fresh_w_wins"], st["fresh_w_total"], prior_alpha=4.0)
        st["fresh_bayes_wr"] = fresh_wr
        st["fresh_w_total"] = round(st["fresh_w_total"], 2)
        tot_tp_all = st["shadow_tp1_wins"] + st["live_wins"]
        tot_sl_all = st["shadow_sl_hits"] + st["live_losses"]
        st["dual_ledger_vi"] = (
            f"Sổ kép: {n_samp} Shadow + {l_samp} Live · "
            f"TP {tot_tp_all} / SL {tot_sl_all} · Live {st['live_net_pnl']:+.2f}$"
        )

        lc_st = st.get("lifecycle_state", "OFFICIAL")
        dyn_live_cool = (
            bool(st.get("is_dynamic"))
            and l_samp >= 3
            and l_wr < 45.0
            and float(st.get("live_net_pnl") or 0.0) < -0.50
        )
        if lc_st in ("PAUSED", "LAB_DEMOTED", "DELETED"):
            lbl_map = {"PAUSED": "⏸️ TẠM TẮT", "LAB_DEMOTED": "↩️ ĐÃ HẠ VỀ LAB", "DELETED": "🗑️ ĐÃ XÓA MỀM"}
            st["adaptive_mode"] = "TAM_DUNG"
            st["adaptive_badge_vi"] = lbl_map[lc_st]
            st["adaptive_weight_mult"] = 0.0
            st["adaptive_advice_vi"] = "Người dùng đang tạm tắt/hạ về LAB — chặn mở lệnh Live mới, có thể bật lại 1-click!"
        elif dyn_live_cool or (st["fresh_w_total"] >= 3.0 and fresh_wr <= 41.0):
            st["adaptive_mode"] = "HA_NHIET_PHONG_THU"
            st["adaptive_badge_vi"] = (
                f"🛡️ HẠ NHIỆT LIVE ({l_samp}L WR {l_wr:.0f}%)"
                if dyn_live_cool
                else f"🛡️ HẠ NHIỆT (Tươi {fresh_wr:.0f}% · T½={st['half_life_hours']:.0f}h)"
            )
            st["adaptive_weight_mult"] = 0.88
            st["adaptive_advice_vi"] = f"Dòng tiền/Live đang yếu (Live {l_wr:.0f}%, Bayes {fresh_wr:.1f}%) -> Giảm ưu tiên, nhường Slot!"
        elif st["fresh_w_total"] >= 2.0 and fresh_wr >= 60.0:
            st["adaptive_mode"] = "CHU_LUC_UU_TIEN"
            st["adaptive_badge_vi"] = f"🔥 ƯU TIÊN (Tươi {fresh_wr:.0f}% · T½={st['half_life_hours']:.0f}h)"
            st["adaptive_weight_mult"] = 1.15
            st["adaptive_advice_vi"] = f"Đang thắng tươi (Bayes {fresh_wr:.1f}%, Sổ kép {comb_wr:.0f}%) -> Ưu tiên tranh Slot!"
            preferred_weapons.append(f"{st['code']} ({fresh_wr:.0f}%)")
        else:
            st["adaptive_mode"] = "SAN_SANG_MAC_DINH"
            st["adaptive_badge_vi"] = (
                f"⚡ SẴN SÀNG (Tươi {fresh_wr:.0f}% · {total_samp} mẫu)"
                if total_samp > 0 else "⚡ SẴN SÀNG (Mặc định)"
            )
            st["adaptive_weight_mult"] = 1.0
            st["adaptive_advice_vi"] = "Trạng thái cân bằng (hoặc sau khi dữ liệu cũ bán rã về trung lập 1.0x)!"

    long_wr = round((long_tp1_count / long_eval_count) * 100.0, 1) if long_eval_count > 0 else 50.0
    short_wr = round((short_tp1_count / short_eval_count) * 100.0, 1) if short_eval_count > 0 else 50.0

    if long_eval_count + short_eval_count < 8:
        flow_mode_vi = "🌱 KHỞI ĐỘNG LINH HOẠT"
        flow_desc_vi = "Đủ điều kiện là vào lệnh ngay, đang tích lũy mẫu Shadow."
        dominant_side = "BALANCED"
    elif long_wr >= 65.0 and long_wr > short_wr + 12.0:
        flow_mode_vi = f"🐂 ƯU TIÊN PHE MUA (TP1: {long_wr}%)"
        flow_desc_vi = f"Phe MUA thắng {long_wr}% vs Bán {short_wr}% → Cộng điểm ưu tiên Vũ Khí Mua."
        dominant_side = "LONG"
    elif short_wr >= 65.0 and short_wr > long_wr + 12.0:
        flow_mode_vi = f"🐻 ƯU TIÊN PHE BÁN (TP1: {short_wr}%)"
        flow_desc_vi = f"Phe BÁN thắng {short_wr}% vs Mua {long_wr}% → Cộng điểm ưu tiên Vũ Khí Bán."
        dominant_side = "SHORT"
    else:
        flow_mode_vi = f"⚖️ CÂN BẰNG 2 CHIỀU (Mua {long_wr}% | Bán {short_wr}%)"
        flow_desc_vi = "Phân hóa theo từng mã: Mã nào đạt chuẩn Vũ Khí sẽ tự động kích hoạt."
        dominant_side = "BALANCED"

    weapons_sorted = sorted(weapon_stats.values(), key=_vk_code_sort_key)
    weapons_by_id_sorted = {w["id"]: w for w in weapons_sorted if "id" in w}
    if len(weapons_by_id_sorted) != len(weapon_stats):
        weapons_by_id_sorted = weapon_stats

    return {
        "timestamp": int(time.time()),
        "datetime": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
        "_db_error": not _arsenal_db_ok,
        "flow_mode_vi": flow_mode_vi,
        "flow_desc_vi": flow_desc_vi,
        "dominant_side": dominant_side,
        "long_tp1_win_rate": long_wr,
        "short_tp1_win_rate": short_wr,
        "total_shadow_evaluated": total_shadow_eval,
        "preferred_weapons": preferred_weapons,
        "weapons": weapons_sorted,
        "weapons_by_id": weapons_by_id_sorted,
    }


_ARSENAL_CACHE: Dict[str, Any] = {"ts": 0.0, "db_path": "", "data": None}
_SHADOW_DB_SUMMARY_CACHE: Dict[str, Any] = {"ts": 0.0, "db_path": "", "data": None}


def invalidate_arsenal_cache() -> None:
    """Xóa cache snapshot khi người dùng vừa đổi vòng đời vũ khí / LAB / tinh chỉnh vị thế."""
    with _ARSENAL_LOCK:
        _ARSENAL_CACHE["ts"] = 0.0
        _SHADOW_DB_SUMMARY_CACHE["ts"] = 0.0
        _SHADOW_DUAL_REGIME_CACHE["ts"] = 0.0


def get_living_arsenal_status_cached(db_path: str = 'data/trade_bot.db', ttl_sec: float = 30.0) -> Dict[str, Any]:
    """Trả về trạng thái Living Arsenal có cache TTL chống nghẽn SQLite & tránh AB-BA deadlock (_ARSENAL_LOCK <-> _ENGINE_LOCK)."""
    import copy as _cp_ars
    resolved = _resolve_default_db_path(db_path)
    now = time.time()
    with _ARSENAL_LOCK:
        if (
            _ARSENAL_CACHE["data"] is not None
            and _ARSENAL_CACHE["db_path"] == resolved
            and (now - _ARSENAL_CACHE["ts"]) < ttl_sec
        ):
            return _cp_ars.deepcopy(_ARSENAL_CACHE["data"])
    # [BOM #149 P0-2 FIX]: Tính toán get_living_arsenal_status() (gọi load_weapon_lifecycle -> _ENGINE_LOCK) NGOÀI _ARSENAL_LOCK!
    fresh_ars = get_living_arsenal_status(db_path=resolved)
    if isinstance(fresh_ars, dict) and fresh_ars.get("_db_error"):
        return fresh_ars
    with _ARSENAL_LOCK:
        _ARSENAL_CACHE["data"] = fresh_ars
        _ARSENAL_CACHE["db_path"] = resolved
        _ARSENAL_CACHE["ts"] = time.time()
        return _cp_ars.deepcopy(_ARSENAL_CACHE["data"]) if _ARSENAL_CACHE["data"] else {}


def get_weapon_priority_profile(weapon_id: str, db_path: str = 'data/trade_bot.db') -> Dict[str, Any]:
    """
    Trả về hệ số ưu tiên thực tế của Vũ Khí từ kết quả Shadow + Live (có cache 60s):
    - 🔥 ƯU TIÊN: multiplier = 1.15 (đẩy lên đầu hàng đợi tranh Slot & cộng nhẹ điểm tự tin)
    - ⚡ SẴN SÀNG: multiplier = 1.00
    - 🛡️ HẠ NHIỆT: multiplier = 0.88 (lùi lại nhường Slot cho Vũ Khí Chủ Lực)
    """
    data = get_living_arsenal_status_cached(db_path=db_path, ttl_sec=60.0)
    w_obj = (data.get("weapons_by_id") or {}).get(weapon_id) or {}
    _raw_mult_147 = w_obj.get("adaptive_weight_mult")
    return {
        "weapon_id": weapon_id,
        "adaptive_mode": str(w_obj.get("adaptive_mode") or "SAN_SANG_MAC_DINH"),
        "adaptive_weight_mult": float(1.0 if _raw_mult_147 is None else _raw_mult_147),
        "adaptive_badge_vi": str(w_obj.get("adaptive_badge_vi") or "⚡ SẴN SÀNG"),
        "dominant_side": str(data.get("dominant_side") or "BALANCED"),
    }


_SHADOW_DUAL_REGIME_CACHE: Dict[str, Any] = {"ts": 0.0, "db_path": "", "data": None}


def get_shadow_dual_window_regime(
    db_path: str = 'data/trade_bot.db',
    ttl_sec: float = 30.0,
    max_age_hours: float = 6.0,
) -> Dict[str, Any]:
    """
    [GÓI B - M21/M22 QUÁN QUÂN 22 MÔ HÌNH + BOM #10 FRESHNESS WINDOW 6H]:
    Đo Nhiệt Kế Dòng Tiền 2 Chiều từ Shadow Pathfinder bằng Cửa Sổ Kép (Slow80 + Fast24):
    - Chỉ đọc các mẫu Shadow tươi trong vòng `max_age_hours` (mặc định 6 giờ gần nhất),
      tuyệt đối KHÔNG dùng dữ liệu cũ từ hôm qua/9 tiếng trước để phán đoán thị trường hiện tại!
    - Slow80 (tối đa 80 mẫu tươi gần nhất): Đo xu thế dòng tiền chủ đạo 2 chiều (L_WR vs S_WR).
    - Fast24 (24 mẫu tươi gần nhất): Phát hiện đảo chiều sớm (Zero-Lag Release), không bị trễ pha 1-2h!
    Cache TTL 30s + PRAGMA query_only=ON -> 0ms nghẽn, 0 lock contention với Main Trading Thread.
    """
    resolved = _resolve_default_db_path(db_path)
    now = time.time()
    with _ARSENAL_LOCK:
        if (
            _SHADOW_DUAL_REGIME_CACHE["data"] is not None
            and _SHADOW_DUAL_REGIME_CACHE["db_path"] == resolved
            and float(_SHADOW_DUAL_REGIME_CACHE["data"].get("max_age_hours", 6.0)) == float(max_age_hours)
            and (now - _SHADOW_DUAL_REGIME_CACHE["ts"]) < ttl_sec
        ):
            return dict(_SHADOW_DUAL_REGIME_CACHE["data"])

    res = {
        "slow_long_wr": 50.0, "slow_short_wr": 50.0, "slow_n": 0,
        "fast_long_wr": 50.0, "fast_short_wr": 50.0, "fast_n": 0,
        "dominant_side": "BALANCED",
        "gap_pct": 0.0,
        "max_age_hours": float(max_age_hours),
        "ts": now,
    }
    res_db_ok = True
    if os.path.exists(resolved):
        conn = None
        try:
            cutoff_sec = now - max(1.0, float(max_age_hours)) * 3600.0
            cutoff_ms = cutoff_sec * 1000.0
            conn = sqlite3.connect(f"file:{resolved}?mode=ro", uri=True, timeout=2.0)
            conn.execute("PRAGMA query_only = ON;")
            cur = conn.cursor()
            cur.execute("""
                SELECT asset_class, details_json
                FROM shadow_pathfinder_logs
                WHERE outcome IN ('TP1_HIT', 'SL_HIT', 'TIMEOUT_60M', 'TIMEOUT_240M')
                  AND UPPER(COALESCE(asset_class, '')) NOT LIKE 'TRADFI%'
                  AND (
                      (timestamp >= 100000000000 AND timestamp >= ?)
                      OR (timestamp < 100000000000 AND timestamp >= ?)
                  )
                ORDER BY id DESC LIMIT 300
            """, (cutoff_ms, cutoff_sec))
            rows = cur.fetchall()

            valid_resolved = []
            for ac_col, dj_raw in rows:
                if str(ac_col or '').upper().startswith('TRADFI') or not dj_raw:
                    continue
                try:
                    dj = json.loads(dj_raw)
                except Exception:
                    continue
                if str(ac_col or dj.get('asset_class') or '').upper().startswith('TRADFI'):
                    continue
                dual = dj.get('dual_eval_240m') or dj.get('dual_eval_60m') or {}
                l11 = str(dual.get('long_1to1') or '')
                s11 = str(dual.get('short_1to1') or '')
                if l11 in ('TP1_HIT', 'SL_HIT') or s11 in ('TP1_HIT', 'SL_HIT'):
                    valid_resolved.append((l11, s11))

            def _tally(subset):
                lw = ln = sw = sn = 0
                for l11, s11 in subset:
                    if l11 in ('TP1_HIT', 'SL_HIT'):
                        ln += 1
                        if l11 == 'TP1_HIT':
                            lw += 1
                    if s11 in ('TP1_HIT', 'SL_HIT'):
                        sn += 1
                        if s11 == 'TP1_HIT':
                            sw += 1
                l_wr = round(lw / ln * 100.0, 1) if ln > 0 else 50.0
                s_wr = round(sw / sn * 100.0, 1) if sn > 0 else 50.0
                return l_wr, s_wr, min(ln, sn)

            sl_l, sl_s, sl_n = _tally(valid_resolved[:80])
            fa_l, fa_s, fa_n = _tally(valid_resolved[:24])
            dom_side = "BALANCED"
            gap_v = round(abs(sl_l - sl_s), 1)
            if sl_n >= 15:
                if sl_l >= 62.0 and (sl_l - sl_s) >= 15.0:
                    dom_side = "LONG"
                elif sl_s >= 62.0 and (sl_s - sl_l) >= 15.0:
                    dom_side = "SHORT"
            res.update({
                "slow_long_wr": sl_l, "slow_short_wr": sl_s, "slow_n": sl_n,
                "fast_long_wr": fa_l, "fast_short_wr": fa_s, "fast_n": fa_n,
                "dominant_side": dom_side,
                "gap_pct": gap_v,
            })
        except Exception:
            res_db_ok = False
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    if res_db_ok:
        with _ARSENAL_LOCK:
            _SHADOW_DUAL_REGIME_CACHE["db_path"] = resolved
            _SHADOW_DUAL_REGIME_CACHE["ts"] = now
            _SHADOW_DUAL_REGIME_CACHE["data"] = dict(res)
    return res


def evaluate_shadow_regime_gate(
    direction: str,
    asset_class: str = 'ALTCOIN',
    jev_dir: str = 'NONE',
    jev_conf: float = 0.0,
    rvol: float = 1.0,
    u_wick_pct: float = 0.0,
    l_wick_pct: float = 0.0,
    pump_pct: float = 0.0,
    dump_pct: float = 0.0,
    db_path: str = 'data/trade_bot.db',
    weapon_code: str = '',
) -> Dict[str, Any]:
    """
    [GÓI B - CỔNG CHỨNG THỰC KÉP THÍCH ỨNG 2 TẦNG (M21/M22 — KHÔNG GÒ BÓ VŨ KHÍ + BOM #16 FIX)]:
    - Lớp TRADFI (Cổ phiếu/Hàng hóa/ETF): Vận hành độc lập khỏi dòng tiền Crypto Shadow (Rule 0.7).
    - Thị trường Cân Bằng (gap < 15% hoặc dom < 62%): Mở tự do 100% toàn bộ 10 Vũ Khí.
    - Phe Thuận Dòng (dom_self >= 62% & gap >= 15%): Xếp ưu tiên cao tranh Slot (+12% rank).
    - Nấc 1 Ngược Dòng Trung Bình (62% <= dom_opp < 70% & gap >= 15%):
        KHÔNG cấm cứng! Cho mở lệnh ngay nếu đạt Chứng Thực Kép:
        (JEV 4H đồng thuận >= 75% AND ((RVol >= min_rv AND Wick >= 35%) OR (RVol >= 2.2x AND Wave >= 1.5%)))
        HOẶC Fast24 đã đảo chiều sớm về phe mình (>= 55%)
        HOẶC VK9 (Râu xả đỉnh cực đại >= 65% + RVol >= 1.33x đã qua SLOT B1).
    - Nấc 2 Bão 1 Chiều Cực Đoan (dom_opp >= 70% & gap >= 35%):
        Cho mở lệnh ngược bão khi Fast24 bắt đầu xác nhận đảo chiều (>= 45%) VÀ đạt Chứng Thực Kép (+0.2x RVol).
        Nếu Fast24 vẫn đang bão 80%-95% ngược chiều -> Veto an toàn (0$) tránh chuỗi lỗ cản tàu.
    """
    ac_up = str(asset_class or 'ALTCOIN').upper()
    # [BOM #121K FIX]: TRADFI_1X / TRADFI_ETF_3X / COMMODITY deu van hanh doc lap (truoc day chi khop dung chuoi 'TRADFI')
    if 'TRADFI' in ac_up or ac_up in ('COMMODITY', 'GOLD', 'OIL'):
        ac_up = 'TRADFI'
    if ac_up == 'TRADFI':
        return {
            "allowed": True,
            "tier": "TRADFI_INDEPENDENT",
            "priority_boost": 1.0,
            "reason": "Tài sản TradFi vận hành độc lập khỏi dòng tiền Crypto Shadow",
            "regime": {},
        }

    reg = get_shadow_dual_window_regime(db_path=db_path)
    sl_n = int(reg.get("slow_n") or 0)
    if sl_n < 15:
        return {"allowed": True, "tier": "WARMUP", "priority_boost": 1.0, "reason": "Shadow đang tích lũy mẫu", "regime": reg}

    d_up = str(direction or 'LONG').upper()
    w_up = str(weapon_code or '').upper()
    sl_l = float(reg["slow_long_wr"])
    sl_s = float(reg["slow_short_wr"])
    fa_l = float(reg["fast_long_wr"])
    fa_s = float(reg["fast_short_wr"])
    fa_n = int(reg["fast_n"])

    dom_opp = sl_l if d_up == 'SHORT' else sl_s
    dom_self = sl_s if d_up == 'SHORT' else sl_l
    gap = dom_opp - dom_self
    fast_self = fa_s if d_up == 'SHORT' else fa_l

    # Chuẩn hóa tỷ lệ % (hỗ trợ cả dạng 0..1 và 0..100)
    uw = float(u_wick_pct or 0.0)
    lw = float(l_wick_pct or 0.0)
    pm = float(pump_pct or 0.0)
    dm = float(dump_pct or 0.0)
    # [BOM #120F FIX]: Chỉ nhân *100 cho tỷ lệ thập phân thực (pump/dump <= 0.30 = 30%), tránh nhân nhầm 0.85% -> 85.0%!
    if 0.0 < uw <= 1.0:
        uw *= 100.0
    if 0.0 < lw <= 1.0:
        lw *= 100.0
    if 0.0 < pm <= 0.30:
        pm *= 100.0
    if 0.0 < dm <= 0.30:
        dm *= 100.0

    need_jev = 'BUY' if d_up == 'LONG' else 'SELL'
    has_jev_cert = (str(jev_dir or '').upper() == need_jev and float(jev_conf or 0.0) >= 0.75)
    wick_val = lw if d_up == 'LONG' else uw
    wave_val = pm if d_up == 'LONG' else dm
    rv = float(rvol) if rvol is not None else 1.0  # [BOM #121K FIX]
    min_rv = 1.15 if ac_up == 'TRADFI' else (1.35 if ac_up == 'MAJOR' else 1.60)

    # [BOM #119C FIX]: Nhánh miễn râu (rv >= 2.20 and wave_val >= 1.50) chỉ dành cho Vũ khí Thuận Sóng / Thác Đổ (VK1, VK2, VK5, VK8),
    # KHÔNG cấp nhầm TIER1_SOFT_CERTIFIED cho Vũ khí Bắt Đỉnh/Đáy Râu (VK3, VK4, VK6, VK7, VK9, VK10, VK11+) khi Wick = 2%!
    _is_momentum_or_wf_weapon = w_up in ('', 'VK1', 'VK2', 'VK5', 'VK8')
    has_candle_t1 = (rv >= min_rv and wick_val >= 35.0) or (_is_momentum_or_wf_weapon and rv >= 2.20 and wave_val >= 1.50)
    has_candle_t2 = (rv >= (min_rv + 0.20) and wick_val >= 35.0) or (_is_momentum_or_wf_weapon and rv >= 2.40 and wave_val >= 1.80)

    # Nấc 2: Bão 1 chiều cực đoan (>= 70%, gap >= 35%)
    if dom_opp >= 70.0 and gap >= 35.0:
        if fa_n >= 8 and fast_self >= 45.0 and has_jev_cert and has_candle_t2:
            return {
                "allowed": True, "tier": "TIER2_CERTIFIED_REVERSAL", "priority_boost": 1.0,
                "reason": f"Đạt Chứng Thực Đảo Chiều Nấc 2 (Fast24={fast_self:.1f}%, JEV={jev_conf*100:.0f}%, RVol={rv:.2f}x, Wick={wick_val:.0f}%)",
                "regime": reg,
            }
        return {
            "allowed": False, "tier": "TIER2_EXTREME_STORM_SHIELD", "priority_boost": 0.70,
            "reason": (
                f"Bão Dòng Tiền Shadow Nấc 2 ngược chiều {d_up} (Slow80 opp={dom_opp:.1f}% vs self={dom_self:.1f}%, "
                f"Fast24 self={fast_self:.1f}% < 45%): Chặn mở ngược bão bảo vệ vốn!"
            ),
            "regime": reg,
        }

    # Nấc 1: Lệch dòng trung bình (62%..69.9%, gap >= 15%) -> Chứng Thực Kép mềm không gò bó
    if dom_opp >= 62.0 and gap >= 15.0:
        is_vk9_climax_cert = (w_up == 'VK9' and d_up == 'SHORT' and uw >= 65.0 and rv >= 1.33)
        _is_dyn_vk_code = w_up in ('VK11', 'VK12', 'VK13', 'VK14', 'VK15') or (w_up.startswith('VK') and w_up[2:].isdigit() and int(w_up[2:]) >= 11)
        # [BOM #121K + #122C FIX]: Tra cuu dong blueprint vu khi dong thay vi hardcode VK14/VK15
        # -> Mien san rau 50% (giu RVol >= 1.05) cho mọi vu khi dong SLOT_B2, TREND_MOMENTUM, hoac khong co uw_min/lw_min trong dna_rules (VK12/14/15/16+)
        _dyn_no_wick_req = False
        if _is_dyn_vk_code:
            try:
                from core.quant_evolution_engine import load_weapon_lifecycle
                _lc_dyns = (load_weapon_lifecycle().get("dynamic_weapons") or {})
                for _dw_obj in _lc_dyns.values():
                    if str((_dw_obj or {}).get("code") or "").upper() == w_up:
                        _dw_bp = (_dw_obj or {}).get("blueprint") or {}
                        if str(_dw_bp.get("side") or "").upper() == "BOTH" and isinstance(_dw_bp.get("legs"), dict):
                            _dw_bp = (_dw_bp["legs"].get(d_up) or _dw_bp)
                        _dw_slot = str(_dw_bp.get("slot") or "").upper()
                        _dw_arch = str(_dw_bp.get("quantum_archetype") or "").upper()
                        _dw_rules = (_dw_bp.get("dna_rules") or {})
                        if (
                            _dw_arch == "TREND_MOMENTUM"
                            or ("uw_min" not in _dw_rules and "lw_min" not in _dw_rules)
                        ):
                            _dyn_no_wick_req = True
                        break
            except Exception:
                _dyn_no_wick_req = False
        is_dyn_climax_cert = (_is_dyn_vk_code and (wick_val >= 50.0 or _dyn_no_wick_req) and rv >= 1.05)
        if (fa_n >= 8 and fast_self >= 55.0) or (has_jev_cert and has_candle_t1) or is_vk9_climax_cert or is_dyn_climax_cert:
            return {
                "allowed": True,
                "tier": "TIER1_VK9_CLIMAX_WICK_CERTIFIED" if is_vk9_climax_cert else "TIER1_SOFT_CERTIFIED",
                "priority_boost": 0.95,
                "reason": (
                    f"VK9 Đạt Chứng Thực Râu Xả Đỉnh Cực Đại Nấc 1 (U_Wick={uw:.0f}% >= 65%, RVol={rv:.2f}x)"
                    if is_vk9_climax_cert else
                    f"Đạt Chứng Thực Kép Nấc 1 (JEV={jev_dir} {jev_conf*100:.0f}%, RVol={rv:.2f}x >= {min_rv:.2f}x, Wick={wick_val:.0f}%, Fast24={fast_self:.1f}%)"
                ),
                "regime": reg,
            }
        return {
            "allowed": False, "tier": "TIER1_SOFT_CERT_FAILED", "priority_boost": 0.80,
            "reason": (
                f"Ngược Dòng Shadow Nấc 1 ({d_up} khi Slow80 opp={dom_opp:.1f}%, gap={gap:.1f}%) "
                f"thiếu Chứng Thực Kép [{ac_up}: RVol={rv:.2f}x/{min_rv:.2f}x, Wick={wick_val:.0f}%/35%, JEV={jev_dir}({jev_conf*100:.0f}%)]"
            ),
            "regime": reg,
        }

    # Phe thuận dòng mạnh -> Cộng ưu tiên xếp hạng tranh Slot Pha 2
    if dom_self >= 62.0 and (dom_self - dom_opp) >= 15.0:
        return {
            "allowed": True, "tier": "ALIGNED_PRIORITY", "priority_boost": 1.12,
            "reason": f"Thuận Dòng Shadow mạnh ({d_up} {dom_self:.1f}% vs {dom_opp:.1f}%) -> Ưu tiên tranh Slot!",
            "regime": reg,
        }

    return {"allowed": True, "tier": "BALANCED", "priority_boost": 1.0, "reason": "Thị trường cân bằng 2 chiều (mở tự do 10 Vũ Khí)", "regime": reg}


# ==============================================================================
# 4. ĐO SỰ CÙNG PHA / LỆCH PHA (BTC/ETH -> ALTCOIN & TRADFI) & THANG VỐN SLOT
# ==============================================================================
def build_cross_asset_and_capital_matrix(
    equity_usdt: float = 405.0,
    max_slots: int = 3,
    leverage: int = 5,
    open_positions: Optional[List[Dict[str, Any]]] = None,
    stalking_orders: Optional[Dict[str, Any]] = None,
    btc_context: Optional[Dict[str, Any]] = None,
    eth_context: Optional[Dict[str, Any]] = None,
    exchange: Any = None,
) -> Dict[str, Any]:
    open_list = list(open_positions or [])
    stalk_dict = dict(stalking_orders or {})

    long_open = []
    short_open = []
    alt_open = 0
    major_open = 0
    tradfi_open = 0
    unprotected_long = 0
    unprotected_short = 0

    for pos in open_list:
        p_sym = str(pos.get('symbol') or '').upper()
        p_dir = str(pos.get('direction') or 'LONG').upper()
        entry_p = float(pos.get('entry_price') or 0.0)
        sl_p = float(pos.get('stop_loss') or 0.0)
        is_be_locked = False
        if entry_p > 0 and sl_p > 0:
            if p_dir == 'LONG' and sl_p >= entry_p * 1.00138:
                is_be_locked = True
            elif p_dir == 'SHORT' and sl_p <= entry_p * 0.99862:
                is_be_locked = True

        if p_dir == 'LONG':
            long_open.append(p_sym)
            if not is_be_locked:
                unprotected_long += 1
        else:
            short_open.append(p_sym)
            if not is_be_locked:
                unprotected_short += 1

        base_s = p_sym.split('/')[0].split(':')[0].upper()
        try:
            from core.scanner import MarketScanner as _MS_ca
            _is_trf_ca = _MS_ca.is_tradfi_symbol(p_sym, exchange=exchange)
        except Exception:
            _is_trf_ca = False
        if base_s in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'):
            major_open += 1
        elif _is_trf_ca:
            tradfi_open += 1
        else:
            alt_open += 1

    b_ctx = dict(btc_context or {})
    e_ctx = dict(eth_context or {})
    btc_adx = float(b_ctx['adx'] if b_ctx.get('adx') is not None else (25.0 if e_ctx.get('adx') is None else e_ctx.get('adx')))
    btc_atr = float(b_ctx['atr_pct'] if b_ctx.get('atr_pct') is not None else (0.65 if e_ctx.get('atr_pct') is None else e_ctx.get('atr_pct')))
    btc_regime = str(b_ctx.get('regime') or e_ctx.get('regime') or 'normal').lower()

    if btc_adx < 18.0 and btc_atr < 0.40:
        phase_status_vi = "⏸️ BTC/ETH ĐANG NÉN BIÊN ĐỘ (LỆCH PHA DÒNG TIỀN)"
        phase_rule_vi = (
            "BTC/ETH đang đi ngang cạn thanh khoản: Tự động chặn các lệnh Phá Cản (Breakout) yếu trên Altcoin. "
            "Chỉ cho phép đánh Cổ phiếu/Hàng hóa Mỹ (TradFi) hoặc Altcoin có cá mập bơm độc lập (RVol >= 1.8x)."
        )
    elif 'downtrend' in btc_regime:
        phase_status_vi = "🌊 ĐẦU TÀU BTC/ETH ĐANG SẬP (CÙNG PHA ÁP LỰC BÁN)"
        phase_rule_vi = (
            "BTC đang gây áp lực giảm lên toàn thị trường: Ưu tiên các Vũ Khí BÁN (VK5, VK6, VK7). "
            "Nếu muốn MUA Altcoin ngược bão BTC thì Altcoin đó bắt buộc phải là Sóng Tách Đàn (RVol >= 2.2x + Khiên 4H MUA >= 75%)."
        )
    else:
        phase_status_vi = "🟢 ĐẦU TÀU BTC/ETH ỔN ĐỊNH / THUẬN PHA (MỞ CỬA ĐA VŨ KHÍ)"
        phase_rule_vi = (
            "BTC và ETH đang giữ nhịp tích cực: Cho phép cả 3 lớp tài sản (Altcoin, Major Crypto, TradFi) "
            "triển khai linh hoạt các Vũ Khí Mua và Bán theo đúng tín hiệu hội tụ."
        )

    eff_slots = max(1, int(max_slots or 3))
    max_same_side_unprotected = 1 if eff_slots <= 3 else (2 if eff_slots <= 6 else 3)

    if unprotected_short >= max_same_side_unprotected:
        short_slot_advice_vi = (
            f"🛡️ Đang có {unprotected_short} lệnh BÁN chưa khóa hòa vốn: Tạm chờ lệnh BÁN hiện tại chạm Khóa Hòa Vốn Thép (+0.85%) "
            "mới mở thêm lệnh BÁN mới (Chống rủi ro thị trường giật ngược làm lỗ cả chùm!). Lệnh MUA đối trọng vẫn được phép vào."
        )
    else:
        short_slot_advice_vi = f"✅ Phe BÁN còn trống hạn mức an toàn (Đang mở {len(short_open)} lệnh, Rủi ro chưa khóa: {unprotected_short}/{max_same_side_unprotected})."

    if unprotected_long >= max_same_side_unprotected:
        long_slot_advice_vi = (
            f"🛡️ Đang có {unprotected_long} lệnh MUA chưa khóa hòa vốn: Tạm chờ lệnh MUA hiện tại chạm Khóa Hòa Vốn Thép (+0.85%) "
            "mới mở thêm lệnh MUA mới (Chống sập dây chuyền!). Lệnh BÁN đối trọng vẫn được phép vào."
        )
    else:
        long_slot_advice_vi = f"✅ Phe MUA còn trống hạn mức an toàn (Đang mở {len(long_open)} lệnh, Rủi ro chưa khóa: {unprotected_long}/{max_same_side_unprotected})."

    return {
        "equity_usdt": round(float(equity_usdt or 0.0), 2),
        "max_slots": eff_slots,
        "leverage": int(leverage or 5),
        "open_count": len(open_list),
        "stalking_count": len(stalk_dict),
        "long_open_symbols": long_open,
        "short_open_symbols": short_open,
        "unprotected_long": unprotected_long,
        "unprotected_short": unprotected_short,
        "max_same_side_unprotected": max_same_side_unprotected,
        "phase_status_vi": phase_status_vi,
        "phase_rule_vi": phase_rule_vi,
        "short_slot_advice_vi": short_slot_advice_vi,
        "long_slot_advice_vi": long_slot_advice_vi,
        "asset_classes_matrix": [
            {
                "class_id": "ALTCOIN",
                "name_vi": "LỚP 1: CRYPTO ALTCOIN (Biến động cao · Săn sóng cá mập)",
                "open_count": alt_open,
                "rvol_min": "1.10x (Sóng bơm >= 1.80x)",
                "sniper_discount_vi": "Chiết khấu đón đáy rũ sâu 0.25% - 0.42% (Tránh râu quét)",
                "sl_tp_frame_vi": "SL: 1.5% - 3.5% (Theo ATR) | Khóa Hòa Vốn Thép: +0.85% -> +1.15% | Đích: TP1",
                "correlation_note_vi": "Chịu ảnh hưởng mạnh từ BTC/ETH. Chỉ đánh tách đàn khi RVol đột biến.",
            },
            {
                "class_id": "MAJOR",
                "name_vi": "LỚP 2: ĐẦU TÀU MAJOR (BTC, ETH, SOL, BNB)",
                "open_count": major_open,
                "rvol_min": "1.00x",
                "sniper_discount_vi": "Chiết khấu chuẩn 0.15% - 0.25% (Thanh khoản cực sâu)",
                "sl_tp_frame_vi": "SL: 1.0% - 2.2% | Khóa Hòa Vốn Thép: +0.85% | Đích: TP1",
                "correlation_note_vi": "Kim chỉ nam của toàn thị trường Crypto. Ít râu giả hơn Altcoin.",
            },
            {
                "class_id": "TRADFI",
                "name_vi": "LỚP 3: CỔ PHIẾU, ETF 3X & HÀNG HÓA MỸ (TRADFI)",
                "open_count": tradfi_open,
                "rvol_min": "0.85x (Mở phiên Mỹ >= 1.80x)",
                "sniper_discount_vi": "Chiết khấu tinh gọn 0.10% - 0.20%",
                "sl_tp_frame_vi": "Cổ phiếu 1x SL: 1.0%-1.8% | ETF 3x (SOXL/TQQQ) SL: 1.8%-3.5% | Hòa Vốn Thép: +0.85%",
                "correlation_note_vi": "ĐỘC LẬP 100% VỚI BTC! Đi theo dòng tiền Phiên Mỹ & Wall Street.",
            },
        ],
    }


# ==============================================================================
# 5. TRẠM PHÁT SÓNG SƠ ĐỒ ĐỘNG THỜI GIAN THỰC 6 TẦNG (LIVE PIPELINE TELEMETRY)
# ==============================================================================
def record_pipeline_step(
    stage_num: int,
    symbol: str,
    status: str,
    title_vi: str,
    detail_vi: str,
    direction: str = "",
    weapon_id: str = "",
    branch_vi: str = "",
    metrics: Optional[Dict[str, Any]] = None,
):
    now = time.time()
    w_info = WEAPON_ARSENAL_CATALOG.get(weapon_id) if weapon_id in WEAPON_ARSENAL_CATALOG else None
    if w_info is None and weapon_id:
        try:
            from core.quant_evolution_engine import load_weapon_lifecycle
            w_info = (load_weapon_lifecycle().get("dynamic_weapons") or {}).get(weapon_id)
        except Exception:
            w_info = None
    item = {
        "ts": int(now),
        "time_str": time.strftime('%H:%M:%S', time.localtime(now)),
        "stage_num": int(stage_num),
        "symbol": str(symbol or '').upper(),
        "status": str(status or 'PASSED').upper(),
        "direction": str(direction or '').upper(),
        "title_vi": str(title_vi or ''),
        "detail_vi": str(detail_vi or '')[:260],
        "branch_vi": str(branch_vi or ''),
        "weapon_id": weapon_id,
        "weapon_short_vi": w_info["short_name"] if w_info else "",
        "weapon_icon": w_info["icon"] if w_info else "⚡",
        "metrics": metrics or {},
    }
    with _ARSENAL_LOCK:
        _RECENT_TRACES.append(item)
        try:
            os.makedirs(os.path.dirname(_PIPELINE_TRACE_PATH), exist_ok=True)
            tmp = _PIPELINE_TRACE_PATH + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({
                    "last_updated": int(now),
                    "traces": list(_RECENT_TRACES)[-80:],
                }, f, ensure_ascii=False, indent=2, default=str)
            os.replace(tmp, _PIPELINE_TRACE_PATH)
        except Exception:
            pass


def build_live_pipeline_snapshot(bot_instance: Any = None, db_path: str = 'data/trade_bot.db') -> Dict[str, Any]:
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    gate_path = os.path.join(base_dir, 'data', 'gate_events.json')
    p2_path = os.path.join(base_dir, 'data', 'phase2_last_candidates.json')
    radar_path = os.path.join(base_dir, 'data', 'radar_candidates.json')

    gate_events = []
    if os.path.exists(gate_path):
        try:
            with open(gate_path, 'r', encoding='utf-8') as f:
                gate_events = (json.load(f) or {}).get('events') or []
        except Exception:
            gate_events = []

    p2_candidates = []
    if os.path.exists(p2_path):
        try:
            with open(p2_path, 'r', encoding='utf-8') as f:
                p2_candidates = (json.load(f) or {}).get('candidates') or []
        except Exception:
            p2_candidates = []

    radar_map = {}
    if os.path.exists(radar_path):
        try:
            with open(radar_path, 'r', encoding='utf-8') as f:
                radar_map = json.load(f) or {}
        except Exception:
            radar_map = {}

    open_positions = []
    stalking_orders = {}
    equity_usdt = 405.0
    max_slots = 3
    leverage = 5
    is_running = False
    mode_str = "live"

    if bot_instance is not None:
        is_running = bool(getattr(bot_instance, 'is_running', False))
        mode_str = str(getattr(bot_instance, 'mode', 'live'))
        pos_lock = getattr(bot_instance, '_position_lock', None)
        try:
            if pos_lock is not None:
                with pos_lock:
                    raw_ops = getattr(bot_instance, 'open_positions', []) or []
                    open_positions = [dict(p) for p in list(raw_ops) if isinstance(p, dict)]
                    raw_stk = getattr(bot_instance, 'pending_stalking_orders', {}) or {}
                    stalking_orders = {k: dict(v) for k, v in list(raw_stk.items()) if isinstance(v, dict)}
            else:
                raw_ops = getattr(bot_instance, 'open_positions', []) or []
                open_positions = [dict(p) for p in list(raw_ops) if isinstance(p, dict)]
                raw_stk = getattr(bot_instance, 'pending_stalking_orders', {}) or {}
                stalking_orders = {k: dict(v) for k, v in list(raw_stk.items()) if isinstance(v, dict)}
        except RuntimeError:
            open_positions = []
            stalking_orders = {}
        try:
            if hasattr(bot_instance, 'get_dashboard_positions'):
                dash_pos = bot_instance.get_dashboard_positions()
                # [BOM #137 FIX]: Luôn ưu tiên danh sách đã khử trùng & làm giàu mark_price/uPnL từ get_dashboard_positions (không bỏ qua khi len khác do dedup!)
                if isinstance(dash_pos, list) and (len(dash_pos) > 0 or len(open_positions) == 0):
                    open_positions = [dict(p) for p in dash_pos if isinstance(p, dict)]
        except Exception:
            pass
        if mode_str == 'live' and str(getattr(bot_instance, 'market_type', 'futures')).lower() == 'futures':
            snap = getattr(bot_instance, '_futures_account_snapshot', None) or {}
            equity_usdt = float(snap.get('margin_balance') or snap.get('total_balance') or snap.get('wallet_balance') or getattr(bot_instance, 'balance', 405.0) or 405.0)
        else:
            equity_usdt = float(getattr(bot_instance, 'balance', 1000.0) or 1000.0)
            for _dp in open_positions:
                equity_usdt += float(_dp.get('margin') or _dp.get('cost') or 0.0) + float(_dp.get('unrealized_pnl') or 0.0)
        t_cfg = (getattr(bot_instance, 'config', {}) or {}).get('trading', {}) or {}
        max_slots = int(t_cfg.get('max_open_trades') or t_cfg.get('max_open_positions') or 3)
        leverage = int(t_cfg.get('leverage') or 5)
        if getattr(bot_instance, 'db', None) and getattr(bot_instance.db, 'db_path', None):
            db_path = bot_instance.db.db_path

    arsenal_status = get_living_arsenal_status_cached(db_path=db_path, ttl_sec=30.0)

    btc_ctx = getattr(bot_instance, '_last_btc_chop_ctx', None) if bot_instance else None
    cross_matrix = build_cross_asset_and_capital_matrix(
        equity_usdt=equity_usdt,
        max_slots=max_slots,
        leverage=leverage,
        open_positions=open_positions,
        stalking_orders=stalking_orders,
        btc_context=btc_ctx,
        exchange=getattr(bot_instance, 'exchange', None) if bot_instance else None,
    )

    live_stalking_list = []
    now_ts = time.time()
    for sym, stk in stalking_orders.items():
        w_info = classify_signal_weapon(meta=stk, direction=stk.get('direction', ''))
        sig_px = float(stk.get('signal_price') or stk.get('target_price') or 0.0)
        tgt_px = float(stk.get('target_price') or 0.0)
        inv_px = float(stk.get('invalid_price') or 0.0)
        disc_pct = (abs(tgt_px - sig_px) / sig_px * 100.0) if sig_px > 0 else 0.0
        live_stalking_list.append({
            "symbol": sym,
            "direction": str(stk.get('direction') or 'LONG').upper(),
            "direction_vi": "MUA LÊN (LONG)" if str(stk.get('direction') or '').upper() == 'LONG' else "BÁN XUỐNG (SHORT)",
            "signal_price": sig_px,
            "target_price": tgt_px,
            "invalid_price": inv_px,
            "sl_price": float(stk.get('sl_price') or 0.0),
            "tp_price": float(stk.get('tp_price') or 0.0),
            "discount_pct": round(disc_pct, 2),
            "leverage": int(stk.get('leverage') or leverage),
            "age_sec": int(max(0, now_ts - float(stk.get('created_at') or now_ts))),
            "weapon_id": w_info["id"],
            "weapon_code": w_info["code"],
            "weapon_name_vi": w_info["short_name"],
            "weapon_icon": w_info["icon"],
            "weapon_color": w_info["color"],
            "status_vi": f"Đang đặt Limit Maker đón tại {tgt_px:.6g} (Chiết khấu {disc_pct:.2f}%)",
        })

    live_positions_list = []
    for pos in open_positions:
        sym = str(pos.get('symbol') or '')
        p_dir = str(pos.get('direction') or 'LONG').upper()
        entry_p = float(pos.get('entry_price') or 0.0)
        curr_p = float(pos.get('current_price') or pos.get('mark_price') or entry_p)
        sl_p = float(pos.get('stop_loss') or 0.0)
        tp_p = float(pos.get('take_profit') or 0.0)
        lev = int(pos.get('leverage') or leverage)
        cost_val = float(pos.get('margin') if pos.get('margin') is not None else (pos.get('cost') or 0.0))

        if entry_p > 0:
            raw_move_pct = ((curr_p - entry_p) / entry_p * 100.0) if p_dir == 'LONG' else ((entry_p - curr_p) / entry_p * 100.0)
            sl_dist_pct = (abs(entry_p - sl_p) / entry_p * 100.0) if sl_p > 0 else 2.0
            tp_dist_pct = (abs(tp_p - entry_p) / entry_p * 100.0) if tp_p > 0 else 3.0
        else:
            raw_move_pct = 0.0
            sl_dist_pct = 2.0
            tp_dist_pct = 3.0

        _raw_upnl_v = pos.get('unrealized_pnl')
        unrealized_usdt = float(_raw_upnl_v) if _raw_upnl_v is not None else (cost_val * lev * (raw_move_pct / 100.0))
        roe_pct = raw_move_pct * lev

        is_be_locked = False
        if entry_p > 0 and sl_p > 0:
            if p_dir == 'LONG' and sl_p >= entry_p * 1.00138:
                is_be_locked = True
            elif p_dir == 'SHORT' and sl_p <= entry_p * 0.99862:
                is_be_locked = True

        if raw_move_pct >= 0:
            tp_progress_pct = min(100.0, round((raw_move_pct / max(0.2, tp_dist_pct)) * 100.0, 1))
            sl_danger_pct = 0.0
        else:
            tp_progress_pct = 0.0
            sl_danger_pct = min(100.0, round((abs(raw_move_pct) / max(0.2, sl_dist_pct)) * 100.0, 1))

        w_info = classify_signal_weapon(meta=pos, direction=p_dir)
        protection_stage_vi = (
            "🛡️ VÒNG 2 & 3: ĐÃ KHÓA HÒA VỐN THÉP (Rủi ro = 0$ · Đang thả lỏng ăn TP1)"
            if is_be_locked else
            "⚡ VÒNG 1: ĐANG TRONG KHOẢNG THỞ ATR (Hướng tới mốc Hòa Vốn Thép +0.85%)"
        )

        live_positions_list.append({
            "symbol": sym,
            "direction": p_dir,
            "direction_vi": "MUA LÊN (LONG)" if p_dir == 'LONG' else "BÁN XUỐNG (SHORT)",
            "entry_price": entry_p,
            "current_price": curr_p,
            "stop_loss": sl_p,
            "take_profit": tp_p,
            "leverage": lev,
            "cost_usdt": round(cost_val, 2),
            "raw_pnl_pct": round(raw_move_pct, 2),
            "roe_pct": round(roe_pct, 2),
            "unrealized_usdt": round(unrealized_usdt, 4),
            "is_profitable": raw_move_pct >= 0,
            "is_be_locked": is_be_locked,
            "tp_progress_pct": tp_progress_pct,
            "sl_danger_pct": sl_danger_pct,
            "sl_dist_pct": round(sl_dist_pct, 2),
            "tp_dist_pct": round(tp_dist_pct, 2),
            "partial_tp_done": bool(pos.get('partial_tp_done')),
            "partial_tp2_done": bool(pos.get('partial_tp2_done')),
            "tp1_limit_order_id": pos.get('tp1_limit_order_id'),
            "tp1_limit_price": pos.get('tp1_limit_price'),
            "tp2_limit_order_id": pos.get('tp2_limit_order_id'),
            "tp2_limit_price": pos.get('tp2_limit_price'),
            "v61_tp1_pct": round(float(pos.get('v61_tp1_pct') or 0.0135) * 100.0, 2),
            "v61_tp1_take_pct": int(50 if pos.get('v61_tp1_take_pct') is None else pos.get('v61_tp1_take_pct')),
            "be_trigger_pct": (lambda _bt: round((float(_bt) * 100.0 if float(_bt) < 0.05 else float(_bt)), 3) if isinstance(_bt, (int, float)) and float(_bt) > 0 else 0.85)(pos.get('v61_be_hard_trig_pct') or pos.get('be_trigger_pct')),  # [BOM #121K FIX]: Dung nguong BE thuc te cua vi the (meta luu dang ti le 0.0085 -> hien thi 0.85%)
            "weapon_id": w_info["id"],
            "weapon_code": w_info["code"],
            "weapon_name_vi": w_info["short_name"],
            "weapon_icon": w_info["icon"],
            "weapon_color": w_info["color"],
            "protection_stage_vi": protection_stage_vi,
        })

    t1_passed = []
    t2_branches = {"THUAN_XU_HUONG": [], "BAT_BAY_GIA": [], "SONG_BOM_XA_CA_MAP": []}
    t3_decisions = {"PHE_DUYET_THUAN": [], "LAT_NGUOC_CA_MAP": [], "TU_CHOI_AN_TOAN": []}
    t4_safety = {"VUOT_CONG_AN_TOAN": [], "CHAN_RUI_RO_DANH_MUC": []}
    t5_m1_aborted = []
    active_syms = set(stalking_orders.keys()).union({str(p.get('symbol') or '') for p in open_positions})

    for cand in reversed(p2_candidates[-25:]):
        c_sym = str(cand.get('symbol') or '')
        c_dir = str(cand.get('final_signal') or cand.get('side') or cand.get('ai_direction') or 'HOLD').upper()
        c_rvol = float(1.0 if cand.get('rvol') is None else cand.get('rvol'))
        c_rsi = float(50.0 if cand.get('rsi') is None else cand.get('rsi'))
        c_strats = cand.get('strategies') or {}
        c_outcome = str(cand.get('outcome') or cand.get('status') or '')
        c_reason = str(cand.get('outcome_reason') or '')

        # Gắn Vũ khí thực tế (ưu tiên weapon_id đã phân loại từ bot.py)
        # [BOM #150 P2 FIX]: Chỉ gắn cờ is_parabolic_long_inversion khi lý do chứa PARABOLIC hoặc 3C-KB10 (không gán nhầm các lật ngược Waterfall/Momentum thành VK2)!
        _cr_u_2164 = c_reason.upper()
        is_inv_cand = ('PARABOLIC' in _cr_u_2164) or ('3C-KB10' in _cr_u_2164)
        explicit_wid = str(cand.get('weapon_id') or '')
        cand_w = classify_signal_weapon(
            meta={
                'weapon_id': explicit_wid,
                'is_parabolic_long_inversion': is_inv_cand,
                'strategy': ','.join(c_strats.keys()) if isinstance(c_strats, dict) else str(c_strats),
                'rvol': c_rvol,
                'c_upper_wick_pct': float(cand.get('u_wick_pct') or 0.0) / 100.0,
                'c_lower_wick_pct': float(cand.get('l_wick_pct') or 0.0) / 100.0,
                'direction': 'LONG' if c_dir == 'BUY' else ('SHORT' if c_dir == 'SELL' else ''),
            },
            direction='LONG' if c_dir == 'BUY' else ('SHORT' if c_dir == 'SELL' else ''),
        )

        t1_passed.append({
            "symbol": c_sym,
            "rvol": round(c_rvol, 2),
            "rsi": round(c_rsi, 1),
            "weapon_id": cand_w["id"],
            "weapon_code": cand_w["code"],
            "time": str(cand.get('datetime') or '')[-8:],
        })

        if 'trap_detector' in c_strats:
            t2_branches["BAT_BAY_GIA"].append({"symbol": c_sym, "weapon_id": cand_w["id"], "weapon_code": cand_w["code"], "detail": f"Phát hiện Bẫy Giá (RVol {c_rvol:.2f}x, RSI {c_rsi:.1f})"})
        elif c_rvol >= 1.8 or 'momentum_breakout' in c_strats:
            t2_branches["SONG_BOM_XA_CA_MAP"].append({"symbol": c_sym, "weapon_id": cand_w["id"], "weapon_code": cand_w["code"], "detail": f"Đột biến Volume Cá Mập ({c_rvol:.2f}x, RSI {c_rsi:.1f})"})
        else:
            t2_branches["THUAN_XU_HUONG"].append({"symbol": c_sym, "weapon_id": cand_w["id"], "weapon_code": cand_w["code"], "detail": f"Quét Cấu Trúc Xu Hướng (RVol {c_rvol:.2f}x, RSI {c_rsi:.1f})"})

        if c_outcome in ('EXECUTED', 'STALKING', 'APPROVED'):
            if is_inv_cand or cand_w["code"] == "VK2":
                # [BOM #100 FIX]: Giu nguyen cand_w['id'/'code'] (khong ep VK11 thanh VK2 tren UI T3!)
                t3_decisions["LAT_NGUOC_CA_MAP"].append({
                    "symbol": c_sym,
                    "direction": c_dir,
                    "weapon_id": cand_w["id"] or "VK2_LONG_LAT_NGUOC_SONG_PARABOL",
                    "weapon_code": cand_w["code"] or "VK2",
                    "reason": c_reason or "Lật ngược thế cờ đi cùng cá mập & Khiên 4H",
                })
            else:
                t3_decisions["PHE_DUYET_THUAN"].append({
                    "symbol": c_sym,
                    "direction": c_dir,
                    "weapon_id": cand_w["id"],
                    "weapon_code": cand_w["code"],
                    "reason": c_reason or f"Hội đồng AI & Kỹ thuật đồng thuận {c_dir}",
                })
            is_cur_active = c_sym in active_syms
            t4_safety["VUOT_CONG_AN_TOAN"].append({
                "symbol": c_sym,
                "direction": c_dir,
                "weapon_id": cand_w["id"],
                "weapon_code": cand_w["code"],
                "is_active": is_cur_active,
                "detail": "Đang rình M1 / giữ vị thế" if is_cur_active else "Đã hoàn tất chu kỳ quét",
            })
        elif c_outcome == 'PRE_TRADE_BLOCKED':
            t4_safety["CHAN_RUI_RO_DANH_MUC"].append({
                "symbol": c_sym,
                "weapon_id": cand_w["id"],
                "weapon_code": cand_w["code"],
                "gate": "TẦNG 4 AN TOÀN",
                "reason": c_reason or "Chặn mở thêm tại Cổng An Toàn / Gối Đầu Hòa Vốn",
            })
        else:
            t3_decisions["TU_CHOI_AN_TOAN"].append({
                "symbol": c_sym,
                "weapon_id": cand_w["id"],
                "weapon_code": cand_w["code"],
                "reason": c_reason or "Chưa đủ 2 chiến thuật đồng thuận hoặc Khiên 4H chặn cản tàu",
            })

    for gev in reversed(gate_events[-30:]):
        g_name = str(gev.get('gate') or '').upper()
        g_sym = str(gev.get('symbol') or '')
        g_reason = str(gev.get('reason') or '')
        g_side = str(gev.get('side') or '')
        _g_meta_base = dict(gev.get('meta') or {}) if isinstance(gev.get('meta'), dict) else {}
        if 'direction' not in _g_meta_base and g_side:
            _g_meta_base['direction'] = g_side
        if 'symbol' not in _g_meta_base and g_sym:
            _g_meta_base['symbol'] = g_sym
        if not _g_meta_base.get('weapon_id') and gev.get('weapon_id'):
            _g_meta_base['weapon_id'] = gev.get('weapon_id')
        # Phân loại chính xác Tầng 5 Xạ thủ M1 vs Tầng 4 An toàn vs Tầng 3 Trọng tài
        if any(k in g_name for k in ('SNIPER', 'M1', 'PRE_FILL', 'RUNAWAY')):
            c_w = classify_signal_weapon(meta=_g_meta_base, direction=g_side)
            t5_m1_aborted.append({
                "symbol": g_sym,
                "direction": g_side,
                "weapon_id": c_w["id"],
                "weapon_code": c_w["code"],
                "gate": g_name,
                "reason": g_reason or "M1 rút lệnh bảo vệ vốn an toàn",
                "time": str(gev.get('datetime') or '')[-8:]
            })
        elif any(k in g_name for k in ('CHOP', 'JEV', 'VETO', 'AGREE')):
            c_w3 = classify_signal_weapon(meta=_g_meta_base, direction=g_side)
            t3_decisions["TU_CHOI_AN_TOAN"].append({
                "symbol": g_sym,
                "weapon_id": c_w3["id"],
                "weapon_code": c_w3["code"],
                "reason": f"[{g_name}] {g_reason}",
            })
        else:
            c_w4 = classify_signal_weapon(meta=_g_meta_base, direction=g_side)
            t4_safety["CHAN_RUI_RO_DANH_MUC"].append({
                "symbol": g_sym,
                "weapon_id": c_w4["id"],
                "weapon_code": c_w4["code"],
                "gate": g_name,
                "reason": g_reason,
            })

    _ex_t1_cls = getattr(bot_instance, 'exchange', None) if bot_instance else None
    _t1_major_cnt = 0
    _t1_tradfi_cnt = 0
    _t1_alt_cnt = 0
    def _extract_t1_base(sym_raw: str) -> str:
        s0 = str(sym_raw or '').split(':')[0].strip().upper()
        if '/' in s0:
            return s0.split('/')[0]
        for q in ('USDT', 'USDC', 'BUSD', 'USD'):
            if s0.endswith(q) and len(s0) > len(q):
                return s0[:-len(q)]
        return s0
    try:
        from core.scanner import MarketScanner as _MS_t1
        for _tx in t1_passed:
            _tsym = str(_tx.get('symbol') or '')
            _tbase = _extract_t1_base(_tsym)
            if _tbase in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'):
                _t1_major_cnt += 1
            elif _MS_t1.is_tradfi_symbol(_tsym, exchange=_ex_t1_cls):
                _t1_tradfi_cnt += 1
            else:
                _t1_alt_cnt += 1
    except Exception:
        _t1_major_cnt = len([x for x in t1_passed if _extract_t1_base(x.get('symbol', '')) in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')])
        _t1_alt_cnt = max(0, len(t1_passed) - _t1_major_cnt)

    stages_flow = [
        {
            "stage_num": 1,
            "stage_key": "T1",
            "code": "TẦNG 1",
            "name_vi": "RA-ĐA QUÉT TOÀN THỊ TRƯỜNG",
            "icon": "📡",
            "color": "#38bdf8",
            "cond_count": 4,
            "role_vi": "Quét 200+ cặp Coin & Cổ phiếu Mỹ mỗi chu kỳ · Lọc Bội số Vol (RVol), Biên độ ATR & Loại bỏ coin rác",
            "branches_vi": [
                {"name": "Nhánh 1A: Crypto Altcoin (Biến động cao)", "count": _t1_alt_cnt},
                {"name": "Nhánh 1B: Đầu tàu Major (BTC, ETH, SOL, BNB, XRP)", "count": _t1_major_cnt},
                {"name": "Nhánh 1C: Cổ phiếu & Hàng hóa Mỹ (TradFi)", "count": _t1_tradfi_cnt},
            ],
            "passed_items": t1_passed[:8],
        },
        {
            "stage_num": 2,
            "stage_key": "T2",
            "code": "TẦNG 2",
            "name_vi": "MÁY DÒ BẪY & PHÂN LOẠI VŨ KHÍ KỸ THUẬT",
            "icon": "🔍",
            "color": "#a78bfa",
            "cond_count": 5,
            "role_vi": "Giải mã cấu trúc nến 15M/5M (Râu trên, Râu dưới, RSI, ADX) để rút ra Vũ Khí phù hợp",
            "branches_vi": [
                {"name": "Nhánh 2A: Dò Bẫy Tăng/Giảm (Bull/Bear Trap & Rút chân)", "items": t2_branches["BAT_BAY_GIA"][:5]},
                {"name": "Nhánh 2B: Dò Bão Volume Cá Mập (Bơm Thuận Đà / Xả Thác Đổ)", "items": t2_branches["SONG_BOM_XA_CA_MAP"][:5]},
                {"name": "Nhánh 2C: Dò Cấu Trúc Xu Hướng Chuẩn (SuperTrend / EMA)", "items": t2_branches["THUAN_XU_HUONG"][:5]},
            ],
        },
        {
            "stage_num": 3,
            "stage_key": "T3",
            "code": "TẦNG 3",
            "name_vi": "HỘI ĐỒNG TRỌNG TÀI AI & KHIÊN XU HƯỚNG 4H",
            "icon": "🧠",
            "color": "#00e5ff",
            "cond_count": 5,
            "role_vi": "Kết hợp AI Ensemble + Khiên 4H (JEV) + Nhiệt kế Shadow Pathfinder để Duyệt Thuận, Lật Ngược hay Từ Chối",
            "branches_vi": [
                {"name": "Nhánh 3A [CHO QUA ✅]: Phê Duyệt Thuận Chiều (VK1, VK4, VK5, VK6, VK7, VK8)", "items": t3_decisions["PHE_DUYET_THUAN"][:5]},
                {"name": "Nhánh 3B [LẬT NGƯỢC 🔄]: Lật Ngược Thế Cờ Cùng Cá Mập (VK2 · 3C-KB10)", "items": t3_decisions["LAT_NGUOC_CA_MAP"][:5]},
                {"name": "Nhánh 3C [LOẠI BỎ 🛡️]: Từ Chối An Toàn (Chặn bán cản tàu 4H / Bán đuổi quá bán / Râu 2 đầu)", "items": t3_decisions["TU_CHOI_AN_TOAN"][:6]},
            ],
        },
        {
            "stage_num": 4,
            "stage_key": "T4",
            "code": "TẦNG 4 · 4.5",
            "name_vi": "CỔNG AN TOÀN, QUANTUM & KHIÊN TẦNG 4.5 (ĐU SÓNG 15M / BÃO BTC)",
            "icon": "🛡️",
            "color": "#fbbf24",
            "cond_count": 5,
            "role_vi": "Kiểm tra Slot Danh mục, Quantum Gate v2.0 và Tầng 4.5 (Q18 Đu sóng 3 nến 15M ≥ 3.0×/3.5× ATR + Cầu dao BTC 1H ≥ 1.30% / 15M ≥ 1.25% cho Altcoin)",
            "branches_vi": [
                {"name": "Nhánh 4A [CHO QUA ✅]: Vượt Cổng An toàn, Quantum & Tầng 4.5", "items": t4_safety["VUOT_CONG_AN_TOAN"][:5]},
                {"name": "Nhánh 4B [TẠM HOÃN / T4.5 🛡️]: Chặn Rủi ro Danh mục, Quantum hoặc Đu sóng / Bão BTC", "items": t4_safety["CHAN_RUI_RO_DANH_MUC"][:6]},
            ],
        },
        {
            "stage_num": 5,
            "stage_key": "T5_M1",
            "code": "TẦNG 5",
            "name_vi": "XẠ THỦ SĂN RÌNH ĐÁY/ĐỈNH M1 (LIMIT MAKER)",
            "icon": "🎯",
            "color": "#00ff88",
            "cond_count": 5,
            "role_vi": "M1 tự động nhận diện từng Vũ Khí để áp dụng 5 Điều Kiện Săn Đón & Rút Lệnh Bảo Vệ Vốn riêng biệt!",
            "active_stalking": live_stalking_list,
            "aborted_stalking": t5_m1_aborted[:8],
            "branches_vi": [
                {"name": f"Nhánh 5A [ĐANG RÌNH LIMIT MAKER]: {len(live_stalking_list)} lệnh", "items": live_stalking_list},
                {"name": f"Nhánh 5B [M1 RÚT LỆNH BẢO VỆ VỐN]: {len(t5_m1_aborted)} lượt cứu vốn", "items": t5_m1_aborted[:8]},
                {"name": "Nhánh 5C [5 ĐIỀU KIỆN M1 RIÊNG CHO TỪNG VŨ KHÍ]", "count": 8},
            ],
        },
        {
            "stage_num": 6,
            "stage_key": "T6",
            "code": "TẦNG 6",
            "name_vi": "TAM TẦNG BẢO VỆ VỐN & TỐI ĐA HÓA LỢI NHUẬN TP1",
            "icon": "👑",
            "color": "#10b981",
            "cond_count": 5,
            "role_vi": "Vòng 1: Thoát hiểm bão ngược · Vòng 2: Khóa Hòa Vốn Thép (+0.85%) đưa rủi ro về 0$ · Vòng 3: Ăn trọn TP1",
            "active_positions": live_positions_list,
            "branches_vi": [
                {"name": f"Vị Thế Đang Chiến Đấu ({len(live_positions_list)}/{max_slots} Slot)", "items": live_positions_list},
            ],
        },
    ]

    # ==============================================================================
    # 6. TRÍCH XUẤT TẦNG SHADOW PATHFINDER (THEO DÕI NGẦM RAM + 290+ MẪU SQLITE)
    # ==============================================================================
    shadow_active_ram = []
    if bot_instance is not None and getattr(bot_instance, 'shadow_pathfinder', None) is not None:
        spf = bot_instance.shadow_pathfinder
        try:
            with spf._active_lock:
                for _sk, cand in list(spf._active_candidates.items()):
                    elapsed_min = round(max(0.0, (now_ts - float(cand.registered_at or now_ts)) / 60.0), 1)
                    d_str = str(cand.direction or 'LONG').upper()
                    c_det = dict(getattr(cand, 'details', None) or {})
                    c_l2 = c_det.get('layer2_candle_dna') or {}
                    c_l3 = c_det.get('layer3_consensus_dna') or {}
                    w_spf = classify_signal_weapon(
                        meta={
                            'weapon_id': c_det.get('weapon_id') or '',
                            'primary_setup_type': c_det.get('primary_setup_type') or '',
                            'tech_pathway_key': c_det.get('tech_pathway_key') or '',
                            'rvol': cand.rvol,
                            'c_upper_wick_pct': float(c_l2.get('u_wick_pct') or 0.0) / 100.0,
                            'c_lower_wick_pct': float(c_l2.get('l_wick_pct') or 0.0) / 100.0,
                            'rsi': float(c_l2.get('rsi') or 50.0),
                            'ai_direction': c_l3.get('ai_vote') or '',
                            'jev_direction': c_l3.get('jev_vote') or '',
                            'direction': d_str,
                        },
                        direction=d_str,
                    )
                    shadow_active_ram.append({
                        "symbol": cand.symbol,
                        "direction": d_str,
                        "asset_class": cand.asset_class,
                        "station_blocked": cand.station_blocked,
                        "block_reason": cand.block_reason,
                        "rvol": round(float(cand.rvol if cand.rvol is not None else 1.0), 2),
                        "entry_price": round(float(cand.entry_price or 0.0), 6),
                        "sl_price": round(float(cand.sl_price or 0.0), 6),
                        "tp1_price": round(float(cand.tp1_price or 0.0), 6),
                        "max_up_pct": round(float(cand.max_up_pct or 0.0), 2),
                        "max_down_pct": round(float(cand.max_down_pct or 0.0), 2),
                        "long_1to2": cand.long_1to2,
                        "short_1to2": cand.short_1to2,
                        "elapsed_min": elapsed_min,
                        "weapon_id": w_spf["id"],
                        "weapon_code": w_spf["code"],
                    })
        except Exception:
            pass

    shadow_completed_recent = []
    shadow_total_db = 0
    shadow_tp1_db = 0
    shadow_sl_db = 0
    shadow_timeout_db = 0
    a1_stat = {"n": 0, "tp": 0, "sl": 0}
    a2_stat = {"n": 0, "tp": 0, "sl": 0}
    a3_stat = {"n": 0, "tp": 0, "sl": 0}
    a4_stat = {"n": 0, "tp": 0, "sl": 0}
    a5_stat = {"n": 0, "tp": 0, "sl": 0}
    a6_stat = {"n": 0, "tp": 0, "sl": 0}
    auto_discovered_labs: List[Dict[str, Any]] = []
    db_path = _resolve_default_db_path(db_path)
    now_db_chk = time.time()
    cached_shadow_db = None
    with _ARSENAL_LOCK:
        if (
            _SHADOW_DB_SUMMARY_CACHE["data"] is not None
            and _SHADOW_DB_SUMMARY_CACHE["db_path"] == db_path
            and (now_db_chk - _SHADOW_DB_SUMMARY_CACHE["ts"]) < 45.0
        ):
            cached_shadow_db = _SHADOW_DB_SUMMARY_CACHE["data"]

    if cached_shadow_db is not None:
        shadow_completed_recent = cached_shadow_db["shadow_completed_recent"]
        shadow_total_db = cached_shadow_db["shadow_total_db"]
        shadow_tp1_db = cached_shadow_db["shadow_tp1_db"]
        shadow_sl_db = cached_shadow_db["shadow_sl_db"]
        shadow_timeout_db = cached_shadow_db["shadow_timeout_db"]
        a1_stat = cached_shadow_db["a1_stat"]
        a2_stat = cached_shadow_db["a2_stat"]
        a3_stat = cached_shadow_db["a3_stat"]
        a4_stat = cached_shadow_db.get("a4_stat", a4_stat)
        a5_stat = cached_shadow_db.get("a5_stat", a5_stat)
        a6_stat = cached_shadow_db.get("a6_stat", a6_stat)
        auto_discovered_labs = cached_shadow_db.get("auto_discovered_labs", [])
    elif os.path.exists(db_path):
        conn_s = None
        try:
            conn_s = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=2.0)
            conn_s.execute("PRAGMA query_only = ON;")
            cur_s = conn_s.cursor()
            cur_s.execute("SELECT outcome, COUNT(*) FROM shadow_pathfinder_logs GROUP BY outcome")
            for out_k, cnt_v in cur_s.fetchall():
                shadow_total_db += int(cnt_v or 0)
                if out_k == 'TP1_HIT':
                    shadow_tp1_db = int(cnt_v or 0)
                elif out_k == 'SL_HIT':
                    shadow_sl_db = int(cnt_v or 0)
                elif out_k in ('TIMEOUT_60M', 'TIMEOUT_240M'):
                    shadow_timeout_db += int(cnt_v or 0)

            # [PC1 FIX #4 & BOM #8 + AUTO-DISCOVERY MINER 3 LỚP TÀI SẢN]:
            # Đếm chính xác 3 Vũ Khí Thử Nghiệm (VK2/VK9/VK10), 2 Cụm Lab cố định & Tự Động Khai Phá Cụm Mới (ALTCOIN/MAJOR/TRADFI)!
            cur_s.execute("""
                SELECT symbol, asset_class, rvol, details_json
                FROM shadow_pathfinder_logs
                WHERE outcome IN ('TP1_HIT', 'SL_HIT', 'TIMEOUT_60M', 'TIMEOUT_240M')
                ORDER BY id DESC LIMIT 1500
            """)
            for sym_v_s, ac_v, rv_v, dj_raw in cur_s.fetchall():
                if not dj_raw:
                    continue
                try:
                    dj = json.loads(dj_raw)
                except Exception:
                    continue
                l2 = dj.get('layer2_candle_dna') or {}
                l3 = dj.get('layer3_consensus_dna') or {}
                dual = dj.get('dual_eval_240m') or dj.get('dual_eval_60m') or {}
                ac_up = str(ac_v or dj.get('asset_class') or 'ALTCOIN').upper()
                if 'TRADFI' in ac_up or ac_up in ('COMMODITY', 'GOLD', 'OIL'):
                    ac_up = 'TRADFI'
                tpk_u = str(dj.get('tech_pathway_key') or '').upper()
                gate = str(dj.get('layer4_exact_veto_gate') or '')
                ai_v = str(l3.get('ai_vote') or '').upper()
                jev_v = str(l3.get('jev_vote') or '').upper()
                rsi_v = float(l2.get('rsi') or 50.0)
                adx_v = float(l2.get('adx') or 0.0)
                atr_v = float(l2.get('atr_pct') or 0.0)
                reg_v = str(l2.get('regime') or '').lower()
                uw_v = float(l2.get('u_wick_pct') or 0.0)
                lw_v = float(l2.get('l_wick_pct') or 0.0)
                _rvol_src = l2.get('rvol') if l2.get('rvol') is not None else rv_v
                rvol_v = float(_rvol_src if _rvol_src is not None else 1.0)
                s11 = str(dual.get('short_1to1') or '')
                l11 = str(dual.get('long_1to1') or '')

                # [BOM #150 P2 CLEANUP]: Chuẩn hóa so khớp không phân biệt hoa/thường (tpk_u) & xóa dead code a3_stat/a6_stat/auto_buckets!
                # VK9 (Giao điểm tinh khiết L1 ∩ A4 - ALTCOIN SHORT)
                if (
                    ac_up == 'ALTCOIN' and 'TRAP_DETECTOR:SELL' in tpk_u and 'TREND_FOLLOWING:BUY' in tpk_u
                    and ai_v == 'SELL' and jev_v == 'BUY' and gate == 'T3_JEV_SHIELD_NEED_2_STRATS'
                    and uw_v >= 65.0 and lw_v < 25.0 and rsi_v < 65.0 and rvol_v >= 1.33 and adx_v >= 20.0
                ):
                    a1_stat["n"] += 1
                    if s11 == 'TP1_HIT':
                        a1_stat["tp"] += 1
                    elif s11 == 'SL_HIT':
                        a1_stat["sl"] += 1
                # VK2 (3C-KB10 Parabolic Long Inversion - ALTCOIN LONG)
                if (
                    ac_up == 'ALTCOIN' and 'TRAP_DETECTOR:SELL' in tpk_u and ai_v == 'SELL' and jev_v == 'BUY'
                    and gate == 'T3_JEV_SHIELD_NEED_2_STRATS' and rsi_v >= 65.0 and 1.10 <= rvol_v <= 3.50
                ):
                    a2_stat["n"] += 1
                    if l11 == 'TP1_HIT':
                        a2_stat["tp"] += 1
                    elif l11 == 'SL_HIT':
                        a2_stat["sl"] += 1
                # VK10 (Chuẩn S13 Mua Đáy Rút Chân TradFi - [BOM #148 P1-1 FIX]: loại Bear ETF nghịch đảo khớp 100% SignalAggregator!)
                _is_bear_etf_a5 = False
                if sym_v_s:
                    try:
                        from core.scanner import MarketScanner as _MS148A5
                        _is_bear_etf_a5 = bool(_MS148A5.is_bear_inverse_etf(str(sym_v_s)))
                    except Exception:
                        _is_bear_etf_a5 = False
                if (
                    ac_up == 'TRADFI' and (not _is_bear_etf_a5) and 'TRAP_DETECTOR:BUY' in tpk_u and ai_v == 'BUY' and jev_v == 'SELL'
                    and atr_v >= 0.38 and (0.0 < adx_v <= 30.0) and ('strong_downtrend' not in reg_v)
                    and lw_v >= 38.0 and rsi_v >= 33.0 and rvol_v >= 0.85
                ):
                    a5_stat["n"] += 1
                    if l11 == 'TP1_HIT':
                        a5_stat["tp"] += 1
                    elif l11 == 'SL_HIT':
                        a5_stat["sl"] += 1
            cur_s.execute("""
                SELECT symbol, direction, asset_class, station_blocked, block_reason,
                       rvol, max_mfe, max_mae, outcome, duration_seconds, details_json
                FROM shadow_pathfinder_logs
                ORDER BY id DESC LIMIT 12
            """)
            for r_s in cur_s.fetchall():
                d_json = {}
                try:
                    d_json = json.loads(r_s[10]) if r_s[10] else {}
                except Exception:
                    d_json = {}
                dual = d_json.get('dual_eval_240m') or d_json.get('dual_eval_60m') or {}
                d_s = str(r_s[1] or 'LONG').upper()
                l2_d = d_json.get('layer2_candle_dna') or {}
                l3_d = d_json.get('layer3_consensus_dna') or {}
                w_sc = classify_signal_weapon(
                    meta={
                        'weapon_id': d_json.get('weapon_id') or '',
                        'primary_setup_type': d_json.get('primary_setup_type') or '',
                        'tech_pathway_key': d_json.get('tech_pathway_key') or '',
                        'rvol': r_s[5],
                        'c_upper_wick_pct': float(l2_d.get('u_wick_pct') or 0.0) / 100.0,
                        'c_lower_wick_pct': float(l2_d.get('l_wick_pct') or 0.0) / 100.0,
                        'rsi': float(l2_d.get('rsi') or 50.0),
                        'ai_direction': l3_d.get('ai_vote') or '',
                        'jev_direction': l3_d.get('jev_vote') or '',
                        'direction': d_s,
                    },
                    direction=d_s,
                )
                shadow_completed_recent.append({
                    "symbol": r_s[0],
                    "direction": d_s,
                    "asset_class": r_s[2],
                    "station_blocked": r_s[3],
                    "block_reason": str(r_s[4] or '')[:140],
                    "rvol": round(float(r_s[5] if r_s[5] is not None else 1.0), 2),
                    "max_mfe": round(float(r_s[6] or 0.0), 2),
                    "max_mae": round(float(r_s[7] or 0.0), 2),
                    "direct_outcome": str(dual.get('direct_1to2') or r_s[8] or ''),
                    "inverted_outcome": str(dual.get('inverted_1to2') or ''),
                    "duration_min": round(float(r_s[9] or 0) / 60.0, 1),
                    "weapon_id": w_sc["id"],
                    "weapon_code": w_sc["code"],
                })
            with _ARSENAL_LOCK:
                _SHADOW_DB_SUMMARY_CACHE["db_path"] = db_path
                _SHADOW_DB_SUMMARY_CACHE["ts"] = now_db_chk
                _SHADOW_DB_SUMMARY_CACHE["data"] = {
                    "shadow_completed_recent": shadow_completed_recent,
                    "shadow_total_db": shadow_total_db,
                    "shadow_tp1_db": shadow_tp1_db,
                    "shadow_sl_db": shadow_sl_db,
                    "shadow_timeout_db": shadow_timeout_db,
                    "a1_stat": a1_stat,
                    "a2_stat": a2_stat,
                    "a3_stat": a3_stat,
                    "a4_stat": a4_stat,
                    "a5_stat": a5_stat,
                    "a6_stat": a6_stat,
                    "auto_discovered_labs": auto_discovered_labs,
                }
        except Exception:
            pass
        finally:
            if conn_s is not None:
                try:
                    conn_s.close()
                except Exception:
                    pass

    shield_saved = shadow_sl_db + shadow_timeout_db
    shield_rate = round((shield_saved / shadow_total_db) * 100.0, 1) if shadow_total_db > 0 else 0.0

    # Đưa Tầng Shadow Pathfinder vào stages_flow để hiển thị đồng bộ
    stages_flow.append({
        "stage_num": 7,
        "stage_key": "T7_SHADOW",
        "code": "TẦNG SHADOW",
        "name_vi": "SHADOW PATHFINDER — KIỂM CHỨNG 2 CHIỀU 240P",
        "icon": "🧭",
        "color": "#c084fc",
        "cond_count": 5,
        "role_vi": "Mọi tín hiệu bị chặn rẽ vào đây chấm điểm 240p cả 2 chiều Thuận/Ngược để phản hồi ưu tiên Vũ Khí.",
        "branches_vi": [
            {"name": f"Đang Theo Dõi Ngầm Trong RAM ({len(shadow_active_ram)} mã)", "items": shadow_active_ram[:6]},
            {"name": f"Đã Chốt 240 Phút Gần Nhất ({shadow_total_db} tổng mẫu · Cứu thua {shield_rate}%)", "items": shadow_completed_recent[:6]},
        ],
    })

    # Bổ sung cây điều kiện T7_SHADOW cho mọi vũ khí trong arsenal_status
    _shadow_conds_list = [
        "ĐK 7.1 [VÒNG TUẦN HOÀN]: Nhận toàn bộ tín hiệu bị chặn từ Tầng 1→5 vào RAM (0% GPU)",
        "ĐK 7.2 [CHẤM ĐIỂM 2 CHIỀU]: Theo dõi đồng thời Chiều Thuận & Chiều Lật Ngược tới TP1/SL trong 240 phút",
        "ĐK 7.3 [NGHIỆM CHỨNG N >= 15]: Cần tối thiểu 15 mẫu hoàn tất cùng đường đi & lớp tài sản",
        "ĐK 7.4 [CHUẨN THĂNG HẠNG]: Đạt Win Rate >= 75%, SL <= 20%, Net PnL > +5$ mới mở khóa nâng cấp",
        "ĐK 7.5 [PHẢN HỒI THÍCH ỨNG]: Tự động gắn cờ 🔥 ƯU TIÊN (Bayes WR >= 62%, Fresh W >= 3) hoặc 🛡️ HẠ NHIỆT (Bayes WR < 42%) về Tầng 3",
    ]
    from core.quant_evolution_engine import synthesize_dynamic_weapon_tree as _synth_dw_tree
    for w_k, w_obj in arsenal_status.get("weapons_by_id", {}).items():
        tree_w = w_obj.get("stage_conditions_tree")
        if not isinstance(tree_w, dict) or not tree_w:
            tree_w = _synth_dw_tree(w_obj) if w_obj.get("is_dynamic") else {}
        if "T7_SHADOW" not in tree_w:
            tree_w["T7_SHADOW"] = list(_shadow_conds_list)
        w_obj["stage_conditions_tree"] = tree_w
        w_obj["total_conditions_count"] = sum(len(v) for v in tree_w.values())
    for w_obj in arsenal_status.get("weapons", []):
        tree_w = w_obj.get("stage_conditions_tree")
        if not isinstance(tree_w, dict) or not tree_w:
            tree_w = _synth_dw_tree(w_obj) if w_obj.get("is_dynamic") else {}
        if "T7_SHADOW" not in tree_w:
            tree_w["T7_SHADOW"] = list(_shadow_conds_list)
        w_obj["stage_conditions_tree"] = tree_w
        w_obj["total_conditions_count"] = sum(len(v) for v in tree_w.values())

    def _fmt_alpha_rates(st_d: Dict[str, int]) -> Tuple[float, float, float]:
        n_v = max(0, int(st_d.get("n", 0)))
        tp_v = max(0, int(st_d.get("tp", 0)))
        sl_v = max(0, int(st_d.get("sl", 0)))
        if n_v <= 0:
            return 0.0, 0.0, 0.0
        wr_all = round((tp_v / n_v) * 100.0, 1)
        sl_all = round((sl_v / n_v) * 100.0, 1)
        res_n = tp_v + sl_v
        wr_res = round((tp_v / res_n) * 100.0, 1) if res_n > 0 else 0.0
        return wr_all, sl_all, wr_res

    a1_wr, a1_sl, a1_wr_res = _fmt_alpha_rates(a1_stat)
    a2_wr, a2_sl, a2_wr_res = _fmt_alpha_rates(a2_stat)
    a3_wr, a3_sl, a3_wr_res = _fmt_alpha_rates(a3_stat)
    a5_wr, a5_sl, a5_wr_res = _fmt_alpha_rates(a5_stat)
    a6_wr, a6_sl, a6_wr_res = _fmt_alpha_rates(a6_stat)
    a1_rem = max(0, 15 - a1_stat["n"])
    a3_rem = max(0, 15 - a3_stat["n"])
    a5_rem = max(0, 15 - a5_stat["n"])
    a6_rem = max(0, 15 - a6_stat["n"])

    # [SỔ KÉP SHADOW + LIVE CHO 3 VŨ KHÍ THỬ NGHIỆM: VK2, VK9, VK10]:
    # Khi VK2, VK9, VK10 chạy thực chiến sẽ không còn bị chặn vào Shadow -> Cộng dồn mẫu nền Shadow + lệnh Live!
    _w_map_dl = arsenal_status.get("weapons_by_id") or {}
    def _dual_ledger_stat(base_sh: Dict[str, int], wid_k: str) -> Dict[str, Any]:
        w_l = _w_map_dl.get(wid_k) or {}
        l_n = int(w_l.get("live_trades") or 0)
        l_w = int(w_l.get("live_wins") or 0)
        l_sl = max(0, l_n - l_w)
        l_pnl = float(w_l.get("live_net_pnl") or 0.0)
        sh_n = int(base_sh.get("n") or 0)
        sh_tp = int(base_sh.get("tp") or 0)
        sh_sl = int(base_sh.get("sl") or 0)
        tot_n = sh_n + l_n
        tot_tp = sh_tp + l_w
        tot_sl = sh_sl + l_sl
        strict_wr = round((tot_tp / tot_n) * 100.0, 1) if tot_n > 0 else 0.0
        res_n = tot_tp + tot_sl
        res_wr = round((tot_tp / res_n) * 100.0, 1) if res_n > 0 else 0.0
        sl_pct = round((tot_sl / tot_n) * 100.0, 1) if tot_n > 0 else 0.0
        return {
            "sh_n": sh_n, "l_n": l_n, "l_w": l_w, "l_pnl": l_pnl,
            "tot_n": tot_n, "tot_tp": tot_tp, "tot_sl": tot_sl,
            "strict_wr": strict_wr, "res_wr": res_wr, "sl_pct": sl_pct,
        }

    dl_vk2 = _dual_ledger_stat(a2_stat, "VK2_LONG_LAT_NGUOC_SONG_PARABOL")
    dl_vk9 = _dual_ledger_stat(a1_stat, "VK9_SHORT_BAN_DINH_RAU_CUC_DAI")
    dl_vk10 = _dual_ledger_stat(a5_stat, "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI")

    # Tách bạch hoàn toàn 2 nhóm: (1) 3 Vũ Khí Mới Đang Thử Nghiệm Thực Chiến (Sổ Kép Shadow+Live)
    # và (2) Phòng Thí Nghiệm Mẫu Mới (LAB-1..LAB-2 + Tự Động Khai Phá AUTO-1..AUTO-3 trên 3 Lớp Tài Sản!)
    promoted_weapons = [
        {
            "id": "PROMOTED_VK2",
            "code": "VK2",
            "side": "LONG",
            "is_experimental": True,
            "title_vi": "VK2 · Mua Lật Ngược Parabol (3C-KB10)",
            "weapon_id": "VK2_LONG_LAT_NGUOC_SONG_PARABOL",
            "slot": "🧪 ĐANG THỬ NGHIỆM · SLOT B2 (ALTCOIN)",
            "samples_n": dl_vk2["tot_n"],
            "target_n": 15,
            "win_rate": dl_vk2["strict_wr"],
            "win_rate_all": dl_vk2["strict_wr"],
            "sl_rate": dl_vk2["sl_pct"],
            "status_vi": f"🧪 Thử nghiệm Live (Sổ kép: {dl_vk2['sh_n']} Shadow + {dl_vk2['l_n']} Live · TP {dl_vk2['tot_tp']} / SL {dl_vk2['tot_sl']} · Live {dl_vk2['l_pnl']:+.2f}$)",
            "dna_vi": "ALTCOIN · JEV 4H BUY + RSI >= 65 + RVol 1.1x-3.5x + 4 Tử huyệt F1..F4",
        },
        {
            "id": "PROMOTED_VK9",
            "code": "VK9",
            "side": "SHORT",
            "is_experimental": True,
            "title_vi": "VK9 · Bán Đỉnh Râu Cực Đại (L1∩A4)",
            "weapon_id": "VK9_SHORT_BAN_DINH_RAU_CUC_DAI",
            "slot": "🧪 ĐANG THỬ NGHIỆM · SLOT B1 (ALTCOIN)",
            "samples_n": dl_vk9["tot_n"],
            "target_n": 15,
            "win_rate": dl_vk9["strict_wr"],
            "win_rate_all": dl_vk9["strict_wr"],
            "sl_rate": dl_vk9["sl_pct"],
            "status_vi": f"🧪 Thử nghiệm Live (Sổ kép: {dl_vk9['sh_n']} Shadow + {dl_vk9['l_n']} Live · TP {dl_vk9['tot_tp']} / SL {dl_vk9['tot_sl']} · Live {dl_vk9['l_pnl']:+.2f}$)",
            "dna_vi": "ALTCOIN · Trap SELL + Trend BUY + AI SELL + JEV BUY + U_Wick >= 65% + RSI < 65 + ADX >= 20",
        },
        {
            "id": "PROMOTED_VK10",
            "code": "VK10",
            "side": "LONG",
            "is_experimental": True,
            "title_vi": "VK10 · Mua Đáy Rút Chân TradFi (S13)",
            "weapon_id": "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI",
            "slot": "🧪 ĐANG THỬ NGHIỆM · SLOT B1 (TRADFI)",
            "samples_n": dl_vk10["tot_n"],
            "target_n": 15,
            "win_rate": dl_vk10["strict_wr"],
            "win_rate_all": dl_vk10["strict_wr"],
            "sl_rate": dl_vk10["sl_pct"],
            "status_vi": f"🧪 Thử nghiệm Live (Sổ kép: {dl_vk10['sh_n']} Shadow + {dl_vk10['l_n']} Live · TP {dl_vk10['tot_tp']} / SL {dl_vk10['tot_sl']} · Live {dl_vk10['l_pnl']:+.2f}$)",
            "dna_vi": "TRADFI · Trap BUY + AI BUY + JEV SELL + ATR >= 0.38% + ADX <= 30 + L_Wick >= 38% + RSI >= 33",
        },
    ]

    from core.quant_evolution_engine import (
        run_auto_dna_lab_discovery_and_optimizer,
        load_position_tuning,
        compute_shadow_bayes_breathing_advisor,
        CONSTITUTION_BOUNDS,
        load_weapon_lifecycle,
    )
    # [BOM #149 UI-SPEED]: Dùng TTL 180s + Stale-While-Revalidate + Async Cold-Boot để /so-do-dong mở tức thì (< 1s cold, < 0.05s warm) thay vì treo 16s!
    auto_lab_report = run_auto_dna_lab_discovery_and_optimizer(
        db_path=db_path,
        ttl_sec=180.0,
        allow_async_cold=True,
        stale_while_revalidate=True,
    )
    lc_snap = load_weapon_lifecycle()
    lc_st_map = lc_snap.get("states") or {}
    # Dong bo nhan trang thai tren promoted_weapons (VK2, VK9, VK10 + DYN-VK11..14) — AN HAN vu khi PAUSED/LAB_DEMOTED/DELETED (BOM #90 FIX)
    filtered_promoted = []
    for pw in promoted_weapons:
        p_wid = pw.get("weapon_id", "")
        cur_s = lc_st_map.get(p_wid, "EXPERIMENTAL")
        if cur_s not in ("OFFICIAL", "EXPERIMENTAL"):
            continue
        pw["lifecycle_state"] = cur_s
        pw["is_experimental"] = (cur_s == "EXPERIMENTAL")
        if cur_s == "OFFICIAL":
            pw["slot"] = pw["slot"].replace("🧪 ĐANG THỬ NGHIỆM", "⚔️ CHÍNH THỨC")
            pw["status_vi"] = pw["status_vi"].replace("🧪 Thử nghiệm Live", "⚔️ Vũ khí Chính thức")
        filtered_promoted.append(pw)
    promoted_weapons = filtered_promoted
    for d_wid, dw in (lc_snap.get("dynamic_weapons") or {}).items():
        # [BOM #121K FIX]: Thong nhat nguon trang thai — uu tien lc["states"] (SSOT lifecycle), fallback dw["state"]
        _dw_state = lc_st_map.get(d_wid, dw.get("state"))
        if _dw_state in ("OFFICIAL", "EXPERIMENTAL"):
            w_l = _w_map_dl.get(d_wid) or {}
            v_srv = dw.get("verified_server_stats") or {}
            # [BOM #100 FIX]: Cong gop baseline Shadow LAB (v_srv) voi Live thuc chien cho VK11..14 (khong vut 15 mau Shadow goc khi moi co 1 lenh Live!)
            base_sh_n = int(v_srv.get("samples_n") or 0)
            sh_live_n = int(w_l.get("shadow_samples") or 0)
            lv_n = int(w_l.get("live_trades") or 0)
            eff_sh_n = max(base_sh_n, sh_live_n)
            tot_n_dyn = eff_sh_n + lv_n
            base_sh_sl = round(base_sh_n * float(v_srv.get("sl_rate") or 0.0) / 100.0)
            base_sh_tp = round(base_sh_n * float(v_srv.get("win_rate") or 0.0) / 100.0)
            eff_sh_sl = int(w_l.get("shadow_sl_hits") or 0) if sh_live_n >= base_sh_n else base_sh_sl
            eff_sh_tp = int(w_l.get("shadow_tp1_wins") or 0) if sh_live_n >= base_sh_n else base_sh_tp
            tot_sl_dyn = eff_sh_sl + int(w_l.get("live_losses") or 0)
            tot_tp_dyn = eff_sh_tp + int(w_l.get("live_wins") or 0)
            sl_rate_dyn = round((tot_sl_dyn / tot_n_dyn) * 100.0, 1) if tot_n_dyn > 0 else float(v_srv.get("sl_rate") or 0.0)
            wr_dyn = round((tot_tp_dyn / tot_n_dyn) * 100.0, 1) if tot_n_dyn > 0 else float(v_srv.get("win_rate") or 0.0)
            n_show_dyn = tot_n_dyn
            promoted_weapons.append({
                "id": f"PROMOTED_{dw['code']}",
                "code": dw["code"],
                "side": dw["side"],
                "is_experimental": _dw_state == "EXPERIMENTAL",
                "is_dynamic": True,
                "lifecycle_state": _dw_state,
                "title_vi": dw["short_name"],
                "weapon_id": d_wid,
                "slot": f"{'🧪 ĐANG THỬ NGHIỆM' if _dw_state == 'EXPERIMENTAL' else '⚔️ CHÍNH THỨC'} · {(dw.get('blueprint') or {}).get('slot', 'SLOT_B1')} ({dw.get('asset_class_target', 'ALTCOIN')})",
                "samples_n": n_show_dyn,
                "target_n": 15,
                "win_rate": wr_dyn,
                "win_rate_all": wr_dyn,
                "sl_rate": sl_rate_dyn,
                "status_vi": f"🧪 Vũ khí Động ({w_l.get('dual_ledger_vi', 'Sổ kép mới khởi tạo')} · LAB gốc N={v_srv.get('samples_n',0)} WR {v_srv.get('win_rate',0)}%)",
                "dna_vi": (dw.get("blueprint") or {}).get("m1_profile_vi", ""),
            })

    promoted_weapons.sort(key=_vk_code_sort_key)

    # Thay danh sach lab_candidates bang bo Tu Sinh + Toi Uu 20 Thau Kinh Tieng Viet + Tab Da Bao Trum + Tab Cam (BOM #85)
    lab_candidates = auto_lab_report.get("active_labs") or []
    subsumed_labs = auto_lab_report.get("subsumed_labs") or []
    rejected_labs = auto_lab_report.get("rejected_labs") or []

    shadow_regime_6h = get_shadow_dual_window_regime(db_path=db_path, ttl_sec=45.0, max_age_hours=6.0)
    pos_tuning_cfg = load_position_tuning()
    pos_advisor = compute_shadow_bayes_breathing_advisor(db_path=db_path, ttl_sec=60.0)

    shadow_telemetry = {
        "total_completed": shadow_total_db,
        "tp1_count": shadow_tp1_db,
        "sl_count": shadow_sl_db,
        "timeout_count": shadow_timeout_db,
        "shield_saved_rate_pct": shield_rate,
        "active_ram_count": len(shadow_active_ram),
        "active_ram_list": shadow_active_ram,
        "completed_recent_list": shadow_completed_recent,
        "regime_6h": shadow_regime_6h,
        "promoted_weapons": promoted_weapons,
        "lab_candidates": lab_candidates,
        "subsumed_labs": subsumed_labs,
        "rejected_labs": rejected_labs,
        "lab_loading": bool(auto_lab_report.get("loading")),
        "alpha_watchlist": promoted_weapons + lab_candidates,
    }

    ip_ban_rem = 0.0
    try:
        from core.exchange import get_ip_ban_remaining_seconds
        ip_ban_rem = round(get_ip_ban_remaining_seconds(), 1)
    except Exception:
        pass

    return {
        "timestamp": int(now_ts),
        "datetime": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now_ts)),
        "bot_running": is_running,
        "bot_mode": mode_str,
        "ip_ban_remaining_sec": ip_ban_rem,
        "arsenal_status": arsenal_status,
        "cross_asset_matrix": cross_matrix,
        "stages_flow": stages_flow,
        "shadow_telemetry": shadow_telemetry,
        "position_tuning_panel": {
            "config": pos_tuning_cfg,
            "advisor": pos_advisor.get("advisor_by_class") or {},
            "bounds": CONSTITUTION_BOUNDS,
        },
        "live_stalking": live_stalking_list,
        "t5_aborted_stalking": t5_m1_aborted[:10],
        "live_positions": live_positions_list,
        "radar_candidates": list(radar_map.values())[:10],
    }
