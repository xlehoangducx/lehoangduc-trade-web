import json
import os
import threading
import time
from collections import Counter, deque

_LOCK = threading.Lock()
_EVENTS = deque(maxlen=300)
_COUNTS = Counter()
_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'gate_events.json')

def record_gate_event(gate: str, symbol: str, side: str = '', reason: str = '', meta: dict = None):
    """
    Ghi nhận sự kiện chốt chặn (Pre-Trade Gate / JEV Chop Veto) một cách an toàn và thread-safe.
    Lưu bộ đệm 300 sự kiện gần nhất và xuất ra file JSON để Dashboard Web hiển thị trực quan.
    """
    ev = {
        'ts': int(time.time()),
        'datetime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
        'gate': str(gate),
        'symbol': str(symbol),
        'side': str(side),
        'reason': str(reason)[:300],
        'meta': meta or {}
    }
    with _LOCK:
        _EVENTS.append(ev)
        _COUNTS[gate] += 1
        try:
            os.makedirs(os.path.dirname(_PATH), exist_ok=True)
            tmp = _PATH + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({
                    'counts': dict(_COUNTS),
                    'total_blocked': len(_EVENTS),
                    'last_updated': int(time.time()),
                    'events': list(_EVENTS)[-100:]
                }, f, ensure_ascii=False, indent=2)
            os.replace(tmp, _PATH)
        except Exception:
            pass

def get_gate_summary() -> dict:
    with _LOCK:
        return {
            'counts': dict(_COUNTS),
            'recent_events': list(_EVENTS)[-20:]
        }
