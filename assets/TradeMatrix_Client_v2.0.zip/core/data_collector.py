import logging
import pandas as pd
import os
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)

class DataCollector:
    """
    Lớp thu thập và lưu trữ dữ liệu nến (OHLCV).
    """
    def __init__(self, exchange_connector, data_dir: str = 'data/historical/'):
        self.exchange = exchange_connector
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        # [BOM #18 FIX - RAM TTL CACHE CHỐNG SPAM REST KLINES Ở NHỊP GÓI A 2.0s & PHA 1->2]:
        # 1m cache 8s (cắt ~80% REST weight khi giữ 2-3 lệnh song song), 5m/15m/1h/4h cache 12s (tránh gọi trùng Pha 1->2).
        self._ram_cache_lock = threading.Lock()
        self._ram_ohlcv_cache = {}

    def _get_file_path(self, symbol: str, timeframe: str) -> str:
        """Lấy đường dẫn file CSV cho một mã và khung thời gian (chuẩn hóa chống ký tự cấm trên Windows NTFS như dấu hai chấm ':')."""
        norm_sym = str(symbol or '').split(':')[0].strip().upper()
        safe_symbol = norm_sym.replace('/', '_').replace(':', '_')
        return os.path.join(self.data_dir, f"{safe_symbol}_{timeframe}.csv")

    def fetch_data(self, symbol: str, timeframe: str, limit: int = 500) -> pd.DataFrame:
        """Tải dữ liệu mới từ sàn (có RAM TTL Cache an toàn đa luồng chống IP Ban -1003/418)."""
        tf_str = str(timeframe or '15m').lower()
        ttl_sec = 8.0 if tf_str == '1m' else 12.0
        cache_key = (str(symbol or '').split(':')[0].strip().upper(), tf_str)
        now_m = time.monotonic()
        with self._ram_cache_lock:
            cached = self._ram_ohlcv_cache.get(cache_key)
            if cached is not None:
                c_ts, c_lim, c_df = cached
                lim_i = int(limit or 0)
                if (now_m - c_ts) < ttl_sec and c_lim >= lim_i and c_df is not None and not c_df.empty:
                    return c_df.tail(lim_i).copy() if 0 < lim_i < len(c_df) else c_df.copy()

        logger.info(f"Đang tải dữ liệu {symbol} {timeframe} (limit: {limit})")
        df = self.exchange.get_ohlcv(symbol, timeframe, limit)
        if df is not None and not df.empty:
            with self._ram_cache_lock:
                self._ram_ohlcv_cache[cache_key] = (time.monotonic(), int(limit or len(df)), df.copy())
                if len(self._ram_ohlcv_cache) > 400:
                    # Dọn bớt entry cũ nhất tránh phình RAM dài hạn
                    oldest_keys = sorted(self._ram_ohlcv_cache.items(), key=lambda kv: kv[1][0])[:100]
                    for ok, _ in oldest_keys:
                        self._ram_ohlcv_cache.pop(ok, None)
            self.save_data(df, symbol, timeframe)
        return df

    def get_cached_data(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Lấy dữ liệu đã lưu trữ từ file CSV."""
        filepath = self._get_file_path(symbol, timeframe)
        if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
            try:
                sample = pd.read_csv(filepath, nrows=2)
                idx_col = 'timestamp' if 'timestamp' in sample.columns else ('datetime' if 'datetime' in sample.columns else 0)
                df = pd.read_csv(filepath, index_col=idx_col, parse_dates=True)
                return df
            except Exception as e:
                logger.error(f"Lỗi đọc file cache {filepath}: {str(e)}")
        return None

    def save_data(self, df: pd.DataFrame, symbol: str, timeframe: str) -> None:
        """Lưu trữ dữ liệu vào file CSV theo cơ chế nguyên tử (Atomic Write) an toàn trên Windows đa luồng."""
        if df.empty:
            return
            
        filepath = self._get_file_path(symbol, timeframe)
        # Sử dụng thread id và nano timestamp để tránh va chạm tên tmp giữa các luồng ghi đồng thời
        tmp_path = f"{filepath}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp"
        try:
            df.to_csv(tmp_path)
            # Trên Windows NTFS, nếu file đích đang được luồng khác đọc, os.replace có thể bắn WinError 32
            # Thực hiện retry tối đa 5 lần với thời gian chờ lùi lũy tiến để loại bỏ dứt điểm WinError 32
            for attempt in range(5):
                try:
                    os.replace(tmp_path, filepath)
                    break
                except (PermissionError, OSError) as pe:
                    if attempt < 4:
                        time.sleep(0.08 * (attempt + 1))
                    else:
                        raise pe
            logger.debug(f"Đã lưu dữ liệu vào {filepath}")
        except Exception as e:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
            logger.warning(f"Lỗi lưu file cache {filepath} (đang bị luồng khác truy cập): {str(e)}")
