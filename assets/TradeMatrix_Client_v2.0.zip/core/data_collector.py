import logging
import pandas as pd
import os
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)

class DataCollector:
    """
    Lớp thu thập và lưu trữ dữ liệu nến (OHLCV).
    """
    def __init__(self, exchange_connector, data_dir: str = 'data/historical/'):
        self.exchange = exchange_connector
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)

    def _get_file_path(self, symbol: str, timeframe: str) -> str:
        """Lấy đường dẫn file CSV cho một mã và khung thời gian (chuẩn hóa chống ký tự cấm trên Windows NTFS như dấu hai chấm ':')."""
        safe_symbol = symbol.replace('/', '_').replace(':', '_')
        return os.path.join(self.data_dir, f"{safe_symbol}_{timeframe}.csv")

    def fetch_data(self, symbol: str, timeframe: str, limit: int = 500) -> pd.DataFrame:
        """Tải dữ liệu mới từ sàn."""
        logger.info(f"Đang tải dữ liệu {symbol} {timeframe} (limit: {limit})")
        df = self.exchange.get_ohlcv(symbol, timeframe, limit)
        if not df.empty:
            self.save_data(df, symbol, timeframe)
        return df

    def get_cached_data(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Lấy dữ liệu đã lưu trữ từ file CSV."""
        filepath = self._get_file_path(symbol, timeframe)
        if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
            try:
                sample = pd.read_csv(filepath, nrows=2)
                idx_col = 'timestamp' if 'timestamp' in sample.columns else ('datetime' if 'datetime' in sample.columns else 0)
                df = pd.read_csv(filepath, index_col=idx_col, parse_dates=True)
                return df
            except Exception as e:
                logger.error(f"Lỗi đọc file cache {filepath}: {str(e)}")
        return None

    def save_data(self, df: pd.DataFrame, symbol: str, timeframe: str) -> None:
        """Lưu trữ dữ liệu vào file CSV theo cơ chế nguyên tử (Atomic Write) an toàn trên Windows đa luồng."""
        if df.empty:
            return
            
        filepath = self._get_file_path(symbol, timeframe)
        # Sử dụng thread id và nano timestamp để tránh va chạm tên tmp giữa các luồng ghi đồng thời
        tmp_path = f"{filepath}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp"
        try:
            df.to_csv(tmp_path)
            # Trên Windows NTFS, nếu file đích đang được luồng khác đọc, os.replace có thể bắn WinError 32
            # Thực hiện retry tối đa 5 lần với thời gian chờ lùi lũy tiến để loại bỏ dứt điểm WinError 32
            for attempt in range(5):
                try:
                    os.replace(tmp_path, filepath)
                    break
                except (PermissionError, OSError) as pe:
                    if attempt < 4:
                        time.sleep(0.08 * (attempt + 1))
                    else:
                        raise pe
            logger.debug(f"Đã lưu dữ liệu vào {filepath}")
        except Exception as e:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
            logger.warning(f"Lỗi lưu file cache {filepath} (đang bị luồng khác truy cập): {str(e)}")
