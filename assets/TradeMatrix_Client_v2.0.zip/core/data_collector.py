import logging
import pandas as pd
import os
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)

class DataCollector:
    """
    Lớp thu thập và lưu trữ dữ liệu nến (OHLCV).
    """
    def __init__(self, exchange_connector, data_dir: str = 'data/historical/'):
        self.exchange = exchange_connector
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        # [BOM #18 FIX - RAM TTL CACHE CHỐNG SPAM REST KLINES Ở NHỊP GÓI A 2.0s & PHA 1->2]:
        # 1m cache 8s (cắt ~80% REST weight khi giữ 2-3 lệnh song song), 5m/15m/1h/4h cache 12s (tránh gọi trùng Pha 1->2).
        self._ram_cache_lock = threading.Lock()
        self._ram_ohlcv_cache = {}

    def _get_file_path(self, symbol: str, timeframe: str) -> str:
        """Lấy đường dẫn file CSV cho một mã và khung thời gian (chuẩn hóa chống ký tự cấm trên Windows NTFS như dấu hai chấm ':')."""
        norm_sym = str(symbol or '').split(':')[0].strip().upper()
        safe_symbol = norm_sym.replace('/', '_').replace(':', '_')
        return os.path.join(self.data_dir, f"{safe_symbol}_{timeframe}.csv")

    def fetch_data(self, symbol: str, timeframe: str, limit: int = 500) -> pd.DataFrame:
        """Tải dữ liệu mới từ sàn (có RAM TTL Cache + ghép nối không cắt cụt CSV lịch sử 500 nến)."""
        tf_str = str(timeframe or '15m').lower()
        ttl_sec = 8.0 if tf_str == '1m' else 12.0
        norm_key = str(symbol or '').split(':')[0].strip().upper().replace('/', '')
        cache_key = (norm_key, tf_str)
        now_m = time.monotonic()
        lim_i = int(limit or 0)
        with self._ram_cache_lock:
            cached = self._ram_ohlcv_cache.get(cache_key)
            if cached is not None:
                c_ts, c_lim, c_df = cached
                if (now_m - c_ts) < ttl_sec and c_lim >= lim_i and c_df is not None and not c_df.empty:
                    return c_df.tail(lim_i).copy() if 0 < lim_i < len(c_df) else c_df.copy()

        logger.info(f"Đang tải dữ liệu {symbol} {timeframe} (limit: {limit})")
        df = self.exchange.get_ohlcv(symbol, timeframe, limit)
        if df is not None and not df.empty:
            merged_df = self._merge_with_existing_history(df, symbol, timeframe, cache_key, lim_i)
            with self._ram_cache_lock:
                self._ram_ohlcv_cache[cache_key] = (
                    time.monotonic(),
                    lim_i,
                    merged_df.copy(),
                )
                if len(self._ram_ohlcv_cache) > 400:
                    oldest_keys = sorted(self._ram_ohlcv_cache.items(), key=lambda kv: kv[1][0])[:100]
                    for ok, _ in oldest_keys:
                        self._ram_ohlcv_cache.pop(ok, None)
            self.save_data(merged_df, symbol, timeframe)
            return merged_df.tail(lim_i).copy() if 0 < lim_i < len(merged_df) else merged_df.copy()
        return df

    def _merge_with_existing_history(
        self, new_df: pd.DataFrame, symbol: str, timeframe: str, cache_key: tuple, min_keep: int = 500
    ) -> pd.DataFrame:
        """[BOM #135 FIX]: Hợp nhất nến mới vào bộ đệm RAM/CSV hiện có để limit nhỏ (3..30) KHÔNG cắt cụt lịch sử 500 nến."""
        existing = None
        with self._ram_cache_lock:
            c_ent = self._ram_ohlcv_cache.get(cache_key)
            if c_ent and c_ent[2] is not None and not c_ent[2].empty:
                existing = c_ent[2]
        if existing is None or len(existing) < max(50, len(new_df)):
            disk_df = self.get_cached_data(symbol, timeframe)
            if disk_df is not None and not disk_df.empty:
                existing = disk_df
        if existing is None or existing.empty:
            return new_df
        try:
            # [BOM #136 FIX]: Chống ghép nối nến cũ bị đứt gãy nhiều giờ/ngày làm sai lệch EMA/RSI/ATR!
            tf_s_map = {'1m': 60.0, '3m': 180.0, '5m': 300.0, '15m': 900.0, '30m': 1800.0, '1h': 3600.0, '4h': 14400.0, '1d': 86400.0}
            tf_step = tf_s_map.get(str(timeframe or '15m').lower(), 900.0)
            try:
                _ex_last = pd.Timestamp(existing.index.max()).timestamp()
                _nw_first = pd.Timestamp(new_df.index.min()).timestamp()
                if (_nw_first - _ex_last) > max(tf_step * 8.0, 7200.0):
                    return new_df
            except Exception:
                pass
            if len(new_df) >= 400 and len(new_df) >= len(existing):
                return new_df
            combined = pd.concat([existing, new_df])
            combined = combined[~combined.index.duplicated(keep='last')]
            combined = combined.sort_index()
            keep_n = max(500, int(min_keep or 500), len(new_df))
            if len(combined) > keep_n:
                combined = combined.tail(keep_n)
            return combined
        except Exception:
            return new_df if len(new_df) >= len(existing) else existing

    def get_cached_data(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Lấy dữ liệu đã lưu trữ từ file CSV."""
        filepath = self._get_file_path(symbol, timeframe)
        if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
            try:
                sample = pd.read_csv(filepath, nrows=2)
                idx_col = 'timestamp' if 'timestamp' in sample.columns else ('datetime' if 'datetime' in sample.columns else 0)
                df = pd.read_csv(filepath, index_col=idx_col, parse_dates=True)
                return df
            except Exception as e:
                logger.error(f"Lỗi đọc file cache {filepath}: {str(e)}")
        return None

    def save_data(self, df: pd.DataFrame, symbol: str, timeframe: str) -> None:
        """Lưu trữ dữ liệu vào file CSV theo cơ chế nguyên tử (Atomic Write) an toàn trên Windows đa luồng."""
        if df is None or df.empty:
            return
            
        filepath = self._get_file_path(symbol, timeframe)
        # Sử dụng thread id và nano timestamp để tránh va chạm tên tmp giữa các luồng ghi đồng thời
        tmp_path = f"{filepath}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp"
        try:
            df.to_csv(tmp_path)
            # Trên Windows NTFS, nếu file đích đang được luồng khác đọc, os.replace có thể bắn WinError 32
            # Thực hiện retry tối đa 5 lần với thời gian chờ lùi lũy tiến để loại bỏ dứt điểm WinError 32
            for attempt in range(5):
                try:
                    os.replace(tmp_path, filepath)
                    break
                except (PermissionError, OSError) as pe:
                    if attempt < 4:
                        time.sleep(0.08 * (attempt + 1))
                    else:
                        raise pe
            logger.debug(f"Đã lưu dữ liệu vào {filepath}")
        except Exception as e:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
            logger.warning(f"Lỗi lưu file cache {filepath} (đang bị luồng khác truy cập): {str(e)}")
