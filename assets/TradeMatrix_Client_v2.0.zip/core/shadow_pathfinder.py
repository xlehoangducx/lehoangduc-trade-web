"""
TRADEMATRIX QUANT ECOSYSTEM - SHADOW PATHFINDER (CƠ CHẾ TÌM ĐƯỜNG THỰC CHIẾN SONG HÀNH)
========================================================================================
Single Source of Truth (SSOT) cho Phân Hệ Thu Thập & Thử Nghiệm Tín Hiệu Bị Chặn.
Tuân thủ tuyệt đối Hiến pháp TradeMatrix:
1. Producer-Consumer Architecture: Queue non-blocking, 0% latency cho Main Trading Thread.
2. Zero-Overhead Hardware: 0% GPU (không gọi Ollama lại), < 20MB RAM (Ring Buffer cap 50), < 0.2% CPU.
3. Isolated SQLite WAL Connection: Tránh 100% lỗi `database is locked`.
4. Phân rã Ma Trận 3D: LONG vs SHORT x 3 Lớp Tài Sản x Dải RVol x 7 Trạm Kiểm Soát.
"""

import time
import queue
import logging
import sqlite3
import threading
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Bảng mã 7 Trạm Kiểm Soát Chuẩn Quỹ
STATION_1_SCANNER_RVOL = "STATION_1_SCANNER_RVOL"
STATION_2_AGGREGATOR_SCORE = "STATION_2_AGGREGATOR_SCORE"
STATION_3_RISK_MANAGER = "STATION_3_RISK_MANAGER"
STATION_4_PRE_TRADE_SAFETY = "STATION_4_PRE_TRADE_SAFETY"
STATION_5_QUANTUM_GATE = "STATION_5_QUANTUM_GATE"
STATION_6_SNIPER_PRE_FILL_GUARD = "STATION_6_SNIPER_PRE_FILL_GUARD"
STATION_7_SNIPER_RUNAWAY = "STATION_7_SNIPER_RUNAWAY"

class ShadowCandidate:
    """Đối tượng ứng viên tìm đường ảo lưu trong RAM (siêu nhẹ < 500 bytes)."""
    __slots__ = (
        'symbol', 'direction', 'asset_class', 'station_blocked', 'block_reason',
        'entry_price', 'sl_price', 'tp1_price', 'rvol', 'ai_confidence',
        'registered_at', 'max_mfe', 'max_mae', 'status', 'last_price',
        'closed_at', 'details'
    )

    def __init__(self, symbol: str, direction: str, asset_class: str,
                 station_blocked: str, block_reason: str, entry_price: float,
                 sl_price: float, tp1_price: float, rvol: float,
                 ai_confidence: float, details: Optional[Dict] = None):
        self.symbol = symbol.upper()
        self.direction = direction.upper()
        self.asset_class = asset_class.upper()
        self.station_blocked = station_blocked
        self.block_reason = str(block_reason)[:200]
        self.entry_price = float(entry_price)
        self.sl_price = float(sl_price)
        self.tp1_price = float(tp1_price)
        self.rvol = float(rvol)
        self.ai_confidence = float(ai_confidence)
        self.registered_at = time.time()
        self.max_mfe = 0.0
        self.max_mae = 0.0
        self.status = 'ACTIVE'
        self.last_price = float(entry_price)
        self.closed_at = None
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            'symbol': self.symbol,
            'direction': self.direction,
            'asset_class': self.asset_class,
            'station_blocked': self.station_blocked,
            'block_reason': self.block_reason,
            'entry_price': self.entry_price,
            'sl_price': self.sl_price,
            'tp1_price': self.tp1_price,
            'rvol': self.rvol,
            'ai_confidence': self.ai_confidence,
            'registered_at': self.registered_at,
            'max_mfe': self.max_mfe,
            'max_mae': self.max_mae,
            'status': self.status,
            'duration_seconds': int((self.closed_at or time.time()) - self.registered_at),
            'details': self.details
        }


class ShadowPathfinder:
    """
    Bộ điều phối Tìm Đường Thực Chiến Song Hành đa luồng, cách ly hoàn toàn với Main Trading Thread.
    """

    def __init__(self, db_path: str = 'data/trade_bot.db', max_active: int = 50,
                 max_queue: int = 100, tracking_window_sec: int = 3600,
                 dedup_cooldown_sec: int = 900):
        self.db_path = db_path
        self.max_active = max_active
        self.tracking_window_sec = tracking_window_sec
        self.dedup_cooldown_sec = dedup_cooldown_sec

        # 1. Non-blocking queue giữa Main Thread (Producer) và Pathfinder Worker (Consumer)
        self._queue = queue.Queue(maxsize=max_queue)

        # 2. In-Memory Ring Buffer theo dõi các vị thế ảo (Khóa RLock bảo vệ truy cập đồng thời)
        self._active_lock = threading.RLock()
        self._active_candidates: Dict[str, ShadowCandidate] = {}

        # 3. Bộ lọc chống trùng lặp (Deduplication Gate)
        self._last_registered: Dict[str, float] = {}

        # 4. Cờ kiểm soát luồng ngầm
        self._stop_event = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None

        # 5. Khởi tạo DB Schema
        self._init_db_schema()

        # 6. Khởi động Worker Thread
        self.start()

    def _init_db_schema(self):
        """Khởi tạo bảng shadow_pathfinder_logs với WAL mode an toàn."""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            conn.execute("PRAGMA journal_mode=WAL;")
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS shadow_pathfinder_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                direction TEXT NOT NULL,
                asset_class TEXT NOT NULL,
                station_blocked TEXT NOT NULL,
                block_reason TEXT,
                entry_price REAL NOT NULL,
                sl_price REAL NOT NULL,
                tp1_price REAL NOT NULL,
                rvol REAL,
                ai_confidence REAL,
                max_mfe REAL,
                max_mae REAL,
                outcome TEXT NOT NULL,
                duration_seconds INTEGER,
                closed_timestamp INTEGER,
                details_json TEXT
            );
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_shadow_station ON shadow_pathfinder_logs(station_blocked);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_shadow_outcome ON shadow_pathfinder_logs(outcome);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_shadow_asset_dir ON shadow_pathfinder_logs(asset_class, direction);")
            conn.commit()
            conn.close()
            logger.info("⚡ [SHADOW PATHFINDER] Đã khởi tạo schema shadow_pathfinder_logs an toàn.")
        except Exception as e:
            logger.error("❌ [SHADOW PATHFINDER] Lỗi khởi tạo DB: %s", e)

    def start(self):
        """Khởi chạy Daemon Background Thread."""
        if self._worker_thread and self._worker_thread.is_alive():
            return
        self._stop_event.clear()
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            name="ShadowPathfinderWorker",
            daemon=True
        )
        self._worker_thread.start()
        logger.info("🚀 [SHADOW PATHFINDER] Đã khởi chạy Background Worker Thread thành công.")

    def stop(self):
        """Dừng an toàn luồng worker."""
        self._stop_event.set()
        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=2.0)
        logger.info("🛑 [SHADOW PATHFINDER] Đã dừng Background Worker Thread an toàn.")

    # ---------------------------------------------------------
    # PRODUCER API: Gọi từ Main Thread (Thời gian thực thi < 0.01 ms)
    # ---------------------------------------------------------
    def register_candidate(self, symbol: str, direction: str, entry_price: float,
                           sl_price: float, tp1_price: float, station_blocked: str,
                           block_reason: str, asset_class: str = 'ALTCOIN',
                           rvol: float = 1.0, ai_confidence: float = 0.0,
                           details: Optional[Dict] = None) -> bool:
        """
        Ghi nhận ứng viên bị chặn từ Main Thread.
        Non-blocking hoàn toàn, tự động loại trừ trùng lặp và bảo vệ Main Loop.
        """
        try:
            if not symbol or entry_price <= 0 or sl_price <= 0 or tp1_price <= 0:
                return False

            now = time.time()
            clean_sym = symbol.split(':')[0].strip().upper().replace('/', '')
            clean_dir = direction.upper()
            dedup_key = f"{clean_sym}_{clean_dir}"

            # 1. Deduplication Gate: Bỏ qua nếu vừa đăng ký cùng cặp & chiều trong 15 phút
            last_ts = self._last_registered.get(dedup_key, 0.0)
            if now - last_ts < self.dedup_cooldown_sec:
                return False

            candidate = ShadowCandidate(
                symbol=clean_sym,
                direction=clean_dir,
                asset_class=asset_class,
                station_blocked=station_blocked,
                block_reason=block_reason,
                entry_price=entry_price,
                sl_price=sl_price,
                tp1_price=tp1_price,
                rvol=rvol,
                ai_confidence=ai_confidence,
                details=details
            )

            # 2. Đẩy vào non-blocking queue. Nếu đầy, drop an toàn không treo luồng
            try:
                self._queue.put_nowait(candidate)
                self._last_registered[dedup_key] = now
                return True
            except queue.Full:
                logger.debug("⚠️ [SHADOW PATHFINDER] Hàng đợi đầy (100 mục), bỏ qua candidate %s", dedup_key)
                return False

        except Exception as e:
            logger.debug("Bỏ qua lỗi đăng ký Shadow Candidate: %s", e)
            return False

    # ---------------------------------------------------------
    # MARKET DATA UPDATE: Gọi khi Main Bot nhận nến M1 hoặc tick giá
    # ---------------------------------------------------------
    def update_market_data(self, symbol: str, high: float, low: float,
                           close: float, current_price: Optional[float] = None):
        """
        Cập nhật giá nến M1 thật để kiểm tra TP1/SL ảo.
        Chạy cực nhanh qua RLock in-memory, không gọi API, không tốn GPU.
        """
        try:
            clean_sym = symbol.split(':')[0].strip().upper().replace('/', '')
            curr_p = float(current_price or close)
            high_p = float(high)
            low_p = float(low)

            finished_candidates = []

            with self._active_lock:
                # Tìm các ứng viên đang theo dõi thuộc symbol này
                for key, cand in list(self._active_candidates.items()):
                    if cand.symbol != clean_sym or cand.status != 'ACTIVE':
                        continue

                    cand.last_price = curr_p

                    # 1. Tính toán MFE (Max Favorable Excursion) & MAE (Max Adverse Excursion)
                    if cand.direction == 'LONG':
                        cand_mfe = ((high_p - cand.entry_price) / cand.entry_price) * 100.0
                        cand_mae = ((low_p - cand.entry_price) / cand.entry_price) * 100.0
                        if cand_mfe > cand.max_mfe:
                            cand.max_mfe = cand_mfe
                        if cand_mae < cand.max_mae:
                            cand.max_mae = cand_mae

                        # [NGUYÊN TẮC QUẢN TRỊ RỦI RO BẢO THỦ CHUẨN QUỸ]:
                        # Nếu nến giật 2 đầu chạm cả SL lẫn TP1 trong cùng 1 nến,
                        # giả định xấu nhất là SL chạm trước để tránh nhận vơ lệnh thắng!
                        if low_p <= cand.sl_price:
                            cand.status = 'SL_HIT'
                            cand.closed_at = time.time()
                            finished_candidates.append(cand)
                            del self._active_candidates[key]
                            continue
                        elif high_p >= cand.tp1_price:
                            cand.status = 'TP1_HIT'
                            cand.closed_at = time.time()
                            finished_candidates.append(cand)
                            del self._active_candidates[key]
                            continue

                    else: # SHORT
                        cand_mfe = ((cand.entry_price - low_p) / cand.entry_price) * 100.0
                        cand_mae = ((cand.entry_price - high_p) / cand.entry_price) * 100.0
                        if cand_mfe > cand.max_mfe:
                            cand.max_mfe = cand_mfe
                        if cand_mae < cand.max_mae:
                            cand.max_mae = cand_mae

                        # Chuẩn Quỹ bảo thủ: Kiểm tra SL trước
                        if high_p >= cand.sl_price:
                            cand.status = 'SL_HIT'
                            cand.closed_at = time.time()
                            finished_candidates.append(cand)
                            del self._active_candidates[key]
                            continue
                        elif low_p <= cand.tp1_price:
                            cand.status = 'TP1_HIT'
                            cand.closed_at = time.time()
                            finished_candidates.append(cand)
                            del self._active_candidates[key]
                            continue

            # Ghi kết quả các ứng viên đã chốt vào DB (Bên ngoài lock để giải phóng lock nhanh)
            for finished in finished_candidates:
                self._save_candidate_to_db(finished)

        except Exception as e:
            logger.debug("Lỗi cập nhật market data cho Shadow Pathfinder: %s", e)

    # ---------------------------------------------------------
    # BACKGROUND WORKER LOOP (Consumer Daemon)
    # ---------------------------------------------------------
    def _worker_loop(self):
        """Vòng lặp chạy ngầm độc lập xử lý hàng đợi và dọn dẹp timeout."""
        import json

        while not self._stop_event.is_set():
            try:
                # 1. Hút các candidate mới từ Queue vào Active Map
                while not self._queue.empty():
                    try:
                        cand = self._queue.get_nowait()
                        cand_key = f"{cand.symbol}_{cand.direction}"

                        with self._active_lock:
                            # Nếu đã chạm ngưỡng max_active (50 mục), loại bỏ ứng viên cũ nhất
                            if len(self._active_candidates) >= self.max_active:
                                oldest_key = min(
                                    self._active_candidates.keys(),
                                    key=lambda k: self._active_candidates[k].registered_at
                                )
                                oldest_cand = self._active_candidates.pop(oldest_key)
                                oldest_cand.status = 'DISCARDED_FIFO'
                                oldest_cand.closed_at = time.time()
                                self._save_candidate_to_db(oldest_cand)

                            self._active_candidates[cand_key] = cand
                            logger.info(
                                "🧭 [SHADOW PATHFINDER] Đang theo dõi ngầm: %s %s (Trạm: %s, RVol=%.2fx, TP1=%.4f, SL=%.4f)",
                                cand.symbol, cand.direction, cand.station_blocked,
                                cand.rvol, cand.tp1_price, cand.sl_price
                            )
                    except queue.Empty:
                        break

                # 2. Kiểm tra Timeout 60 phút (3600s) cho các candidate đang active
                now = time.time()
                timeout_candidates = []

                with self._active_lock:
                    for key, cand in list(self._active_candidates.items()):
                        if now - cand.registered_at >= self.tracking_window_sec:
                            cand.status = 'TIMEOUT_60M'
                            cand.closed_at = now
                            timeout_candidates.append(cand)
                            del self._active_candidates[key]

                for tc in timeout_candidates:
                    self._save_candidate_to_db(tc)

                # 3. Dọn dẹp dedup cache cũ (> 1 giờ) để chống phình RAM
                if len(self._last_registered) > 200:
                    cutoff = now - 3600
                    self._last_registered = {k: v for k, v in self._last_registered.items() if v >= cutoff}

            except Exception as e:
                logger.debug("Lỗi trong vòng lặp Shadow Worker: %s", e)

            # Nghỉ 5 giây giữa các lượt kiểm tra timeout (Không chiếm CPU)
            self._stop_event.wait(5.0)

    @staticmethod
    def _safe_json_dumps(obj: Any) -> str:
        """Chuyển đổi an toàn sang JSON chống lỗi TypeError không thể serialize (numpy/timestamp)."""
        import json
        try:
            return json.dumps(obj, default=str, ensure_ascii=False)
        except Exception:
            return "{}"

    def _save_candidate_to_db(self, cand: ShadowCandidate):
        """Ghi 1 dòng kết quả vào SQLite WAL bằng connection độc lập ngắn hạn."""
        import json

        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            duration = int((cand.closed_at or time.time()) - cand.registered_at)

            cursor.execute("""
            INSERT INTO shadow_pathfinder_logs (
                timestamp, symbol, direction, asset_class, station_blocked,
                block_reason, entry_price, sl_price, tp1_price, rvol,
                ai_confidence, max_mfe, max_mae, outcome, duration_seconds,
                closed_timestamp, details_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                int(cand.registered_at * 1000),
                cand.symbol,
                cand.direction,
                cand.asset_class,
                cand.station_blocked,
                cand.block_reason,
                cand.entry_price,
                cand.sl_price,
                cand.tp1_price,
                cand.rvol,
                cand.ai_confidence,
                round(cand.max_mfe, 4),
                round(cand.max_mae, 4),
                cand.status,
                duration,
                int((cand.closed_at or time.time()) * 1000),
                self._safe_json_dumps(cand.details)
            ))
            conn.commit()
            conn.close()

            icon = "🎯" if cand.status == 'TP1_HIT' else ("🛑" if cand.status == 'SL_HIT' else "⏳")
            logger.info(
                "%s [SHADOW KẾT THÚC] %s %s -> %s (MFE=+%.2f%%, MAE=%.2f%%, Giữ %ds, Trạm: %s)",
                icon, cand.symbol, cand.direction, cand.status,
                cand.max_mfe, cand.max_mae, duration, cand.station_blocked
            )
        except Exception as e:
            logger.error("❌ [SHADOW PATHFINDER] Lỗi ghi DB: %s", e)
