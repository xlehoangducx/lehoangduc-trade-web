"""
TRADEMATRIX QUANT ECOSYSTEM - SHADOW PATHFINDER (CƠ CHẾ TÌM ĐƯỜNG THỰC CHIẾN SONG HÀNH)
========================================================================================
Single Source of Truth (SSOT) cho Phân Hệ Thu Thập & Thử Nghiệm Tín Hiệu Bị Chặn.
Tuân thủ tuyệt đối Hiến pháp TradeMatrix:
1. Producer-Consumer Architecture: Queue non-blocking, 0% latency cho Main Trading Thread.
2. Zero-Overhead Hardware: 0% GPU (không gọi Ollama lại), < 20MB RAM (Ring Buffer cap 50), < 0.2% CPU.
3. Isolated SQLite WAL Connection: Tránh 100% lỗi `database is locked`.
4. Phân rã Ma Trận 3D: LONG vs SHORT x 3 Lớp Tài Sản x Dải RVol x 7 Trạm Kiểm Soát.
"""

import time
import math
import queue
import logging
import sqlite3
import threading
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Bảng mã 7 Trạm Kiểm Soát Chuẩn Quỹ
STATION_1_SCANNER_RVOL = "STATION_1_SCANNER_RVOL"
STATION_2_AGGREGATOR_SCORE = "STATION_2_AGGREGATOR_SCORE"
STATION_3_RISK_MANAGER = "STATION_3_RISK_MANAGER"
STATION_4_PRE_TRADE_SAFETY = "STATION_4_PRE_TRADE_SAFETY"
STATION_5_QUANTUM_GATE = "STATION_5_QUANTUM_GATE"
STATION_6_SNIPER_PRE_FILL_GUARD = "STATION_6_SNIPER_PRE_FILL_GUARD"
STATION_7_SNIPER_RUNAWAY = "STATION_7_SNIPER_RUNAWAY"

class ShadowCandidate:
    """Đối tượng ứng viên tìm đường ảo lưu trong RAM (siêu nhẹ, hỗ trợ chấm điểm 2 chiều Thuận & Lật Ngược)."""
    __slots__ = (
        'symbol', 'direction', 'asset_class', 'station_blocked', 'block_reason',
        'entry_price', 'sl_price', 'tp1_price', 'rvol', 'ai_confidence',
        'registered_at', 'max_mfe', 'max_mae', 'status', 'last_price',
        'closed_at', 'direct_closed_at', 'details',
        'sl_dist_pct', 'tp1_dist_pct', 'max_up_pct', 'max_down_pct',
        'long_1to2', 'long_1to1', 'short_1to2', 'short_1to1',
        'pre_tp1_mae_long_pct', 'pre_tp1_mae_short_pct',
        'snapshot_60m_done', 'tp1_is_sub_1r', 'tp1_rr_label'
    )

    def __init__(self, symbol: str, direction: str, asset_class: str,
                 station_blocked: str, block_reason: str, entry_price: float,
                 sl_price: float, tp1_price: float, rvol: float,
                 ai_confidence: float, details: Optional[Dict] = None):
        self.symbol = symbol.upper()
        self.direction = direction.upper()
        _raw_ac = str(asset_class or 'ALTCOIN').upper().strip()
        if any(tok in _raw_ac for tok in ('TRADFI', 'STOCK', 'ETF', 'COMMODITY', 'GOLD', 'OIL')):
            self.asset_class = 'TRADFI'
        elif 'MAJOR' in _raw_ac:
            self.asset_class = 'MAJOR'
        else:
            self.asset_class = 'ALTCOIN'
        self.station_blocked = station_blocked
        self.block_reason = str(block_reason)[:200]
        self.entry_price = float(entry_price)
        self.sl_price = float(sl_price)
        self.tp1_price = float(tp1_price)
        self.rvol = float(rvol)
        self.ai_confidence = float(ai_confidence)
        self.registered_at = time.time()
        self.max_mfe = 0.0
        self.max_mae = 0.0
        self.status = 'ACTIVE'
        self.last_price = float(entry_price)
        self.closed_at = None
        self.direct_closed_at = None
        self.details = dict(details) if isinstance(details, dict) else {}

        # Khung SL/TP chuẩn hóa theo 3 Lớp Tài Sản & Hiến pháp [1.0%, 3.5%] (BOM #90 FIX)
        is_lev_etf = False
        try:
            from core.scanner import MarketScanner
            is_lev_etf = MarketScanner.is_leveraged_etf(self.symbol)
        except Exception:
            is_lev_etf = False
        min_sl_floor = 1.8 if is_lev_etf else (1.0 if self.asset_class in ('TRADFI', 'MAJOR') else 1.5)
        max_sl_cap = 3.5 if (is_lev_etf or self.asset_class == 'ALTCOIN') else (2.2 if self.asset_class == 'MAJOR' else 1.8)
        # [BOM #125D FIX]: Đồng bộ SL/TP1 chuẩn V6.4 C5 (position_tuning.json) và đồng bộ ngược sl_price/tp1_price lưu DB!
        default_sl_pct = 2.75 if is_lev_etf else (1.40 if self.asset_class == 'TRADFI' else (1.70 if self.asset_class == 'MAJOR' else 2.50))
        sl_side_ok = (
            (self.direction == 'LONG' and 0 < self.sl_price < self.entry_price)
            or (self.direction == 'SHORT' and self.sl_price > self.entry_price)
        )
        raw_sl_pct = (abs(self.entry_price - self.sl_price) / self.entry_price * 100.0) if (self.entry_price > 0 and sl_side_ok) else default_sl_pct
        self.sl_dist_pct = min(max_sl_cap, max(min_sl_floor, raw_sl_pct)) if 0.5 <= raw_sl_pct <= 10.0 else default_sl_pct
        tp_side_ok = (
            (self.direction == 'LONG' and self.tp1_price > self.entry_price)
            or (self.direction == 'SHORT' and 0 < self.tp1_price < self.entry_price)
        )
        raw_tp_pct = (abs(self.tp1_price - self.entry_price) / self.entry_price * 100.0) if (self.entry_price > 0 and tp_side_ok) else (1.5 * self.sl_dist_pct)
        if is_lev_etf:
            tp1_min_c, tp1_max_c = 2.00, 2.80
            _v64_tp1_def = 2.30
        elif self.asset_class == 'TRADFI':
            tp1_min_c, tp1_max_c = 0.95, 1.40
            _v64_tp1_def = 0.95
        elif self.asset_class == 'MAJOR':
            tp1_min_c, tp1_max_c = 1.05, 1.40
            _v64_tp1_def = 1.05
        else:
            tp1_min_c, tp1_max_c = 1.35, 1.80
            _v64_tp1_def = 1.35
        # [BOM #138 FIX]: Chỉ nhận raw_tp_pct khi nằm đúng dải TP1 thực chiến [tp1_min_c, tp1_max_c];
        # các caller cũ truyền full-TP (2.0 * sl_dist > tp1_max_c) sẽ rơi về chuẩn V6.4 _v64_tp1_def thay vì bị ghim cứng lên trần tp1_max_c!
        self.tp1_dist_pct = min(tp1_max_c, max(tp1_min_c, raw_tp_pct)) if (tp_side_ok and tp1_min_c <= raw_tp_pct <= tp1_max_c) else _v64_tp1_def
        # Khoảng cách đánh giá R:R thực tế (cặp `long_1to2`/`short_1to2` theo dõi TP1_TARGET vs SL; `long_1to1`/`short_1to1` theo dõi đối xứng 1:1 SL:SL)
        self.tp1_is_sub_1r = bool(self.tp1_dist_pct < self.sl_dist_pct)
        self.tp1_rr_label = f"TP1({self.tp1_dist_pct:.2f}%):SL({self.sl_dist_pct:.2f}%)"
        if self.entry_price > 0:
            if self.direction == 'LONG':
                self.sl_price = self.entry_price * (1.0 - self.sl_dist_pct / 100.0)
                self.tp1_price = self.entry_price * (1.0 + self.tp1_dist_pct / 100.0)
            else:
                self.sl_price = self.entry_price * (1.0 + self.sl_dist_pct / 100.0)
                self.tp1_price = self.entry_price * (1.0 - self.tp1_dist_pct / 100.0)

        self.max_up_pct = 0.0
        self.max_down_pct = 0.0
        self.long_1to2 = 'ACTIVE'
        self.long_1to1 = 'ACTIVE'
        self.short_1to2 = 'ACTIVE'
        self.short_1to1 = 'ACTIVE'
        self.pre_tp1_mae_long_pct = 0.0
        self.pre_tp1_mae_short_pct = 0.0
        self.snapshot_60m_done = False

    def capture_60m_snapshot(self):
        """[V6.1 BOM #73]: Chụp đóng băng kết quả đúng tại phút 60 (dual_eval_60m) rồi tiếp tục theo dõi đến 240p (4h)
        trên CHÍNH XÁC cùng biên SL/TP thực chiến (0 Train-Serve Skew), giảm mạnh tỷ lệ TIMEOUT mù nhãn."""
        if self.snapshot_60m_done:
            return
        self.snapshot_60m_done = True
        l12 = 'TIMEOUT_60M' if self.long_1to2 == 'ACTIVE' else self.long_1to2
        l11 = 'TIMEOUT_60M' if self.long_1to1 == 'ACTIVE' else self.long_1to1
        s12 = 'TIMEOUT_60M' if self.short_1to2 == 'ACTIVE' else self.short_1to2
        s11 = 'TIMEOUT_60M' if self.short_1to1 == 'ACTIVE' else self.short_1to1
        direct_1to2 = l12 if self.direction == 'LONG' else s12
        direct_1to1 = l11 if self.direction == 'LONG' else s11
        inverted_1to2 = s12 if self.direction == 'LONG' else l12
        inverted_1to1 = s11 if self.direction == 'LONG' else l11
        self.details['dual_eval_60m'] = {
            'max_up_pct_60m': round(self.max_up_pct, 4),
            'max_down_pct_60m': round(self.max_down_pct, 4),
            'pre_tp1_mae_long_pct': round(self.pre_tp1_mae_long_pct, 4),
            'pre_tp1_mae_short_pct': round(self.pre_tp1_mae_short_pct, 4),
            'sl_dist_pct': round(self.sl_dist_pct, 4),
            'tp1_dist_pct': round(self.tp1_dist_pct, 4),
            'long_1to2': l12,
            'long_1to1': l11,
            'short_1to2': s12,
            'short_1to1': s11,
            'direct_1to2': direct_1to2,
            'direct_1to1': direct_1to1,
            'inverted_1to2': inverted_1to2,
            'inverted_1to1': inverted_1to1,
        }

    def finalize_dual_eval(self, timeout_label: str = 'TIMEOUT_240M'):
        """Đóng gói kết quả chấm điểm song hành 2 chiều (60m bảo toàn tương thích + 240m 4h giảm censored)."""
        if not self.snapshot_60m_done and timeout_label not in ('DISCARDED_FIFO', 'SHUTDOWN_FLUSH', 'EVICTED_EARLY', 'SHUTDOWN_EARLY'):
            # Kết thúc chuẩn (không phải flush/evict sớm): lưu dual_eval_60m trước khi chốt 240m
            self.capture_60m_snapshot()
        for attr in ('long_1to2', 'long_1to1', 'short_1to2', 'short_1to1'):
            if getattr(self, attr) == 'ACTIVE':
                setattr(self, attr, timeout_label)
        if self.status == 'ACTIVE':
            self.status = timeout_label
        direct_1to2 = self.long_1to2 if self.direction == 'LONG' else self.short_1to2
        direct_1to1 = self.long_1to1 if self.direction == 'LONG' else self.short_1to1
        inverted_1to2 = self.short_1to2 if self.direction == 'LONG' else self.long_1to2
        inverted_1to1 = self.short_1to1 if self.direction == 'LONG' else self.long_1to1
        elapsed_min = round(((self.closed_at or time.time()) - self.registered_at) / 60.0, 1)
        direct_elapsed_min = round(((self.direct_closed_at or self.closed_at or time.time()) - self.registered_at) / 60.0, 1)
        self.details['dual_eval_240m'] = {
            'max_up_pct_240m': round(self.max_up_pct, 4),
            'max_down_pct_240m': round(self.max_down_pct, 4),
            'pre_tp1_mae_long_pct': round(self.pre_tp1_mae_long_pct, 4),
            'pre_tp1_mae_short_pct': round(self.pre_tp1_mae_short_pct, 4),
            'sl_dist_pct': round(self.sl_dist_pct, 4),
            'tp1_dist_pct': round(self.tp1_dist_pct, 4),
            'long_1to2': self.long_1to2,
            'long_1to1': self.long_1to1,
            'short_1to2': self.short_1to2,
            'short_1to1': self.short_1to1,
            'direct_1to2': direct_1to2,
            'direct_1to1': direct_1to1,
            'inverted_1to2': inverted_1to2,
            'inverted_1to1': inverted_1to1,
            'elapsed_minutes': elapsed_min,
            'resolved_window': '<=60m' if direct_elapsed_min <= 60.5 else ('60m-240m' if self.status in ('TP1_HIT', 'SL_HIT') else timeout_label),
        }

    def to_dict(self) -> Dict[str, Any]:
        eff_closed = self.direct_closed_at or self.closed_at or time.time()
        return {
            'symbol': self.symbol,
            'direction': self.direction,
            'asset_class': self.asset_class,
            'station_blocked': self.station_blocked,
            'block_reason': self.block_reason,
            'entry_price': self.entry_price,
            'sl_price': self.sl_price,
            'tp1_price': self.tp1_price,
            'rvol': self.rvol,
            'ai_confidence': self.ai_confidence,
            'registered_at': self.registered_at,
            'max_mfe': self.max_mfe,
            'max_mae': self.max_mae,
            'status': self.status,
            'duration_seconds': int(eff_closed - self.registered_at),
            'details': self.details
        }


class ShadowPathfinder:
    """
    Bộ điều phối Tìm Đường Thực Chiến Song Hành đa luồng, cách ly hoàn toàn với Main Trading Thread.
    """

    def __init__(self, db_path: str = 'data/trade_bot.db', max_active: int = 120,
                 max_queue: int = 150, tracking_window_sec: int = 14400,
                 dedup_cooldown_sec: int = 900, snapshot_60m_sec: int = 3600):
        self.db_path = db_path
        self.max_active = max_active
        self.tracking_window_sec = tracking_window_sec
        self.snapshot_60m_sec = snapshot_60m_sec
        self.dedup_cooldown_sec = dedup_cooldown_sec

        # 1. Non-blocking queue giữa Main Thread (Producer) và Pathfinder Worker (Consumer)
        self._queue = queue.Queue(maxsize=max_queue)

        # 2. In-Memory Ring Buffer theo dõi các vị thế ảo (Khóa RLock bảo vệ truy cập đồng thời)
        self._active_lock = threading.RLock()
        self._active_candidates: Dict[str, ShadowCandidate] = {}

        # 3. Bộ lọc chống trùng lặp (Deduplication Gate)
        self._last_registered: Dict[str, float] = {}

        # 4. Cờ kiểm soát luồng ngầm + hàng đợi ghi DB bất đồng bộ (tách khỏi update_market_data / _position_lock!)
        self._stop_event = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None
        self._db_write_queue: "queue.Queue" = queue.Queue(maxsize=5000)

        # 5. Khởi tạo DB Schema
        self._init_db_schema()

        # 6. Khởi động Worker Thread
        self.start()

    def _init_db_schema(self):
        """Khởi tạo bảng shadow_pathfinder_logs với WAL mode an toàn."""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            conn.execute("PRAGMA journal_mode=WAL;")
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS shadow_pathfinder_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                direction TEXT NOT NULL,
                asset_class TEXT NOT NULL,
                station_blocked TEXT NOT NULL,
                block_reason TEXT,
                entry_price REAL NOT NULL,
                sl_price REAL NOT NULL,
                tp1_price REAL NOT NULL,
                rvol REAL,
                ai_confidence REAL,
                max_mfe REAL,
                max_mae REAL,
                outcome TEXT NOT NULL,
                duration_seconds INTEGER,
                closed_timestamp INTEGER,
                details_json TEXT
            );
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_shadow_station ON shadow_pathfinder_logs(station_blocked);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_shadow_outcome ON shadow_pathfinder_logs(outcome);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_shadow_asset_dir ON shadow_pathfinder_logs(asset_class, direction);")
            conn.commit()
            logger.info("⚡ [SHADOW PATHFINDER] Đã khởi tạo schema shadow_pathfinder_logs an toàn.")
        except Exception as e:
            logger.error("❌ [SHADOW PATHFINDER] Lỗi khởi tạo DB: %s", e)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    def start(self):
        """Khởi chạy Daemon Background Thread."""
        if self._worker_thread and self._worker_thread.is_alive():
            return
        self._stop_event.clear()
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            name="ShadowPathfinderWorker",
            daemon=True
        )
        self._worker_thread.start()
        logger.info("🚀 [SHADOW PATHFINDER] Đã khởi chạy Background Worker Thread thành công.")

    def stop(self):
        """Dừng an toàn luồng worker và flush các mẫu đã phân định kết quả xuống DB (BOM #90 + #121J FIX)."""
        self._stop_event.set()
        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=2.0)
        to_flush = []
        while not self._db_write_queue.empty():
            try:
                to_flush.append(self._db_write_queue.get_nowait())
            except queue.Empty:
                break
        now_stop = time.time()
        with self._active_lock:
            for k, cand in list(self._active_candidates.items()):
                if cand.status in ('TP1_HIT', 'SL_HIT') or cand.snapshot_60m_done:
                    cand.closed_at = now_stop
                    elapsed_c = now_stop - float(cand.registered_at or now_stop)
                    if cand.snapshot_60m_done and cand.status == 'ACTIVE':
                        cand.status = 'TIMEOUT_60M'
                    _stop_lbl = 'TIMEOUT_60M' if cand.snapshot_60m_done else ('SHUTDOWN_EARLY' if elapsed_c < 3600 else 'SHUTDOWN_FLUSH')
                    cand.finalize_dual_eval(timeout_label=_stop_lbl)
                    to_flush.append(cand)
                    del self._active_candidates[k]
        for fc in to_flush:
            self._save_candidate_to_db(fc)
        logger.info("🛑 [SHADOW PATHFINDER] Đã dừng Background Worker Thread an toàn (flushed %d mẫu).", len(to_flush))

    # ---------------------------------------------------------
    # PRODUCER API: Gọi từ Main Thread (Thời gian thực thi < 0.01 ms)
    # ---------------------------------------------------------
    def register_candidate(self, symbol: str, direction: str, entry_price: float,
                           sl_price: float, tp1_price: float, station_blocked: str,
                           block_reason: str, asset_class: str = 'ALTCOIN',
                           rvol: float = 1.0, ai_confidence: float = 0.0,
                           details: Optional[Dict] = None) -> bool:
        """
        Ghi nhận ứng viên bị chặn từ Main Thread.
        Non-blocking hoàn toàn, tự động loại trừ trùng lặp và bảo vệ Main Loop.
        """
        try:
            if not symbol or entry_price <= 0 or sl_price <= 0 or tp1_price <= 0:
                return False

            now = time.time()
            clean_sym = symbol.split(':')[0].strip().upper().replace('/', '')
            clean_dir = direction.upper()
            dedup_key = f"{clean_sym}_{clean_dir}"

            # 1+2. Deduplication Check-and-Set & Non-blocking Enqueue bên trong cùng _active_lock (BOM #120J: chặn TOCTOU race!)
            with self._active_lock:
                last_ts = self._last_registered.get(dedup_key, 0.0)
                if now - last_ts < self.dedup_cooldown_sec:
                    return False

                # [V6.1 BOM #73 & #90]: Bảo đảm 100% mẫu Shadow luôn có weapon_id rõ ràng (không truyền block_reason vào type!)
                enriched_details = dict(details) if isinstance(details, dict) else {}
                if not str(enriched_details.get('weapon_id') or '').strip():
                    try:
                        from core.vietnamese_weapon_arsenal import classify_signal_weapon
                        _l2 = enriched_details.get('layer2_candle_dna') or {}
                        _w_auto = classify_signal_weapon(
                            signal_obj=None,
                            meta={
                                'type': enriched_details.get('primary_setup_type') or '',
                                'strategy': enriched_details.get('tech_pathway_key') or '',
                                'rvol': float(rvol or 1.0),
                                'c_vol_ratio': float(rvol or 1.0),
                                'c_upper_wick_pct': float(_l2.get('u_wick_pct') or 0.0) / 100.0,
                                'c_lower_wick_pct': float(_l2.get('l_wick_pct') or 0.0) / 100.0,
                                'direction': clean_dir,
                            },
                            direction=clean_dir,
                        )
                        if isinstance(_w_auto, dict) and _w_auto.get('id'):
                            enriched_details['weapon_id'] = _w_auto['id']
                            enriched_details['weapon_code'] = _w_auto.get('code', '')
                            enriched_details['weapon_id_source'] = 'shadow_auto_classified'
                    except Exception:
                        pass
                else:
                    enriched_details.setdefault('weapon_id_source', 'exact_caller')

                candidate = ShadowCandidate(
                    symbol=clean_sym,
                    direction=clean_dir,
                    asset_class=asset_class,
                    station_blocked=station_blocked,
                    block_reason=block_reason,
                    entry_price=entry_price,
                    sl_price=sl_price,
                    tp1_price=tp1_price,
                    rvol=rvol,
                    ai_confidence=ai_confidence,
                    details=enriched_details
                )

                try:
                    self._queue.put_nowait(candidate)
                    self._last_registered[dedup_key] = now
                    return True
                except queue.Full:
                    logger.debug("⚠️ [SHADOW PATHFINDER] Hàng đợi đầy (100 mục), bỏ qua candidate %s", dedup_key)
                    return False

        except Exception as e:
            logger.debug("Bỏ qua lỗi đăng ký Shadow Candidate: %s", e)
            return False

    # ---------------------------------------------------------
    # MARKET DATA UPDATE: Gọi khi Main Bot nhận nến M1 hoặc tick giá
    # ---------------------------------------------------------
    def update_market_data(self, symbol: str, high: float, low: float,
                           close: float, current_price: Optional[float] = None,
                           candle_open_ts: Optional[float] = None):
        """
        Cập nhật giá nến M1/tick thật để kiểm tra TP1/SL ảo.
        Chạy cực nhanh qua RLock in-memory, không gọi API, không tốn GPU.
        Nếu candle_open_ts < cand.registered_at (cây nến mở trước thời điểm đăng ký candidate),
        chỉ đánh giá theo giá thực tế hiện tại curr_p để chống nhiễm râu quá khứ (Zero Look-Back).
        """
        try:
            clean_sym = symbol.split(':')[0].strip().upper().replace('/', '')
            curr_p = float(current_price if (current_price is not None and float(current_price or 0) > 0) else (close or 0))
            if not math.isfinite(curr_p) or curr_p <= 0:
                return
            raw_high_p = float(high or 0)
            raw_low_p = float(low or 0)
            if not math.isfinite(raw_high_p) or raw_high_p <= 0:
                raw_high_p = curr_p
            if not math.isfinite(raw_low_p) or raw_low_p <= 0:
                raw_low_p = curr_p
            c_open_sec = None
            if candle_open_ts is not None:
                c_open_sec = float(candle_open_ts) / 1000.0 if float(candle_open_ts) > 1e11 else float(candle_open_ts)

            finished_candidates = []

            with self._active_lock:
                # Tìm các ứng viên đang theo dõi thuộc symbol này
                for key, cand in list(self._active_candidates.items()):
                    if cand.symbol != clean_sym:
                        continue
                    if not math.isfinite(cand.entry_price) or cand.entry_price <= 0:
                        continue

                    cand.last_price = curr_p
                    if c_open_sec is not None and c_open_sec < cand.registered_at:
                        high_p = curr_p
                        low_p = curr_p
                    else:
                        high_p = raw_high_p
                        low_p = raw_low_p

                    # 1. Tính toán biên độ 2 chiều (Up % & Down %) từ Entry
                    up_pct = ((high_p - cand.entry_price) / cand.entry_price) * 100.0
                    down_pct = ((cand.entry_price - low_p) / cand.entry_price) * 100.0
                    if up_pct > cand.max_up_pct:
                        cand.max_up_pct = up_pct
                    if down_pct > cand.max_down_pct:
                        cand.max_down_pct = down_pct

                    # 2. Cập nhật MFE/MAE của chiều gốc (chỉ khi chiều gốc chưa chốt hoặc luôn cập nhật 60m)
                    if cand.direction == 'LONG':
                        if cand.status == 'ACTIVE':
                            cand.max_mfe = max(cand.max_mfe, up_pct)
                            cand.max_mae = min(cand.max_mae, -down_pct)
                    else:
                        if cand.status == 'ACTIVE':
                            cand.max_mfe = max(cand.max_mfe, down_pct)
                            cand.max_mae = min(cand.max_mae, -up_pct)

                    # 3. Chấm điểm đồng thời cả 2 chiều LONG & SHORT (1:2 và 1:1) - Chuẩn Quỹ bảo thủ: Kiểm tra SL trước
                    if cand.long_1to2 == 'ACTIVE':
                        if down_pct >= cand.sl_dist_pct:
                            cand.long_1to2 = 'SL_HIT'
                        elif up_pct >= cand.tp1_dist_pct:
                            cand.long_1to2 = 'TP1_HIT'

                    if cand.long_1to1 == 'ACTIVE':
                        if down_pct > cand.pre_tp1_mae_long_pct:
                            cand.pre_tp1_mae_long_pct = down_pct
                        if down_pct >= cand.sl_dist_pct:
                            cand.long_1to1 = 'SL_HIT'
                        elif up_pct >= cand.sl_dist_pct:
                            cand.long_1to1 = 'TP1_HIT'

                    if cand.short_1to2 == 'ACTIVE':
                        if up_pct >= cand.sl_dist_pct:
                            cand.short_1to2 = 'SL_HIT'
                        elif down_pct >= cand.tp1_dist_pct:
                            cand.short_1to2 = 'TP1_HIT'

                    if cand.short_1to1 == 'ACTIVE':
                        if up_pct > cand.pre_tp1_mae_short_pct:
                            cand.pre_tp1_mae_short_pct = up_pct
                        if up_pct >= cand.sl_dist_pct:
                            cand.short_1to1 = 'SL_HIT'
                        elif down_pct >= cand.sl_dist_pct:
                            cand.short_1to1 = 'TP1_HIT'

                    # 4. Ghi nhận thời điểm chạm đích của Chiều Gốc (Direct Outcome)
                    direct_1to2_now = cand.long_1to2 if cand.direction == 'LONG' else cand.short_1to2
                    if cand.status == 'ACTIVE' and direct_1to2_now in ('TP1_HIT', 'SL_HIT'):
                        cand.status = direct_1to2_now
                        cand.direct_closed_at = time.time()

                    # 5. [BOM #97 FIX]: Chi ket thuc theo doi som khi CA 4 (1:1 va 1:2 cua 2 chieu) deu da phan dinh ro TP1 hoac SL!
                    # (Tranh khi tp1 < sl, 1:2 chot som lam xoa luon 1:1 va gan nhan gia TIMEOUT_240M chi sau vai phut!)
                    if (
                        cand.long_1to1 != 'ACTIVE' and cand.short_1to1 != 'ACTIVE'
                        and cand.long_1to2 != 'ACTIVE' and cand.short_1to2 != 'ACTIVE'
                    ):
                        cand.closed_at = time.time()
                        cand.finalize_dual_eval()
                        finished_candidates.append(cand)
                        del self._active_candidates[key]
                        continue

            # Đẩy ứng viên đã chốt vào hàng đợi ghi DB bất đồng bộ trên Worker Thread (giữ update_market_data 0ms off _position_lock!)
            for finished in finished_candidates:
                try:
                    self._db_write_queue.put_nowait(finished)
                except queue.Full:
                    logger.warning("⚠️ [SHADOW PATHFINDER] Hàng đợi ghi DB đầy, bỏ qua 1 mẫu để bảo vệ Main Thread.")

        except Exception as e:
            logger.debug("Lỗi cập nhật market data cho Shadow Pathfinder: %s", e)

    def feed_bulk_prices(self, price_map: Optional[Dict[str, float]]) -> int:
        """
        [V6.1 BOM #69 FIX]: Bơm giá thị trường thật (0 REST Weight, lấy từ ảnh chụp fetch_tickers của Scanner)
        cho TẤT CẢ các ứng viên Shadow đang hoạt động trong RAM, triệt tiêu hoàn toàn lỗi mù giá 0.0/0.0 TIMEOUT_60M
        khi mã rơi khỏi Top 50 hoặc vừa hủy lệnh rình M1 Sniper!
        """
        if not isinstance(price_map, dict) or not price_map:
            return 0
        with self._active_lock:
            active_syms = {cand.symbol for cand in self._active_candidates.values()}
        updated = 0
        for clean_sym in active_syms:
            px = price_map.get(clean_sym)
            if px is not None and px > 0:
                self.update_market_data(symbol=clean_sym, high=px, low=px, close=px, current_price=px)
                updated += 1
        return updated

    # ---------------------------------------------------------
    # BACKGROUND WORKER LOOP (Consumer Daemon)
    # ---------------------------------------------------------
    def _worker_loop(self):
        """Vòng lặp chạy ngầm độc lập xử lý hàng đợi và dọn dẹp timeout."""
        import json

        while not self._stop_event.is_set():
            try:
                # 0. Rút các mẫu đã phân định kết quả từ update_market_data ghi xuống DB trên Worker Thread riêng
                while not self._db_write_queue.empty():
                    try:
                        fin_cand = self._db_write_queue.get_nowait()
                        self._save_candidate_to_db(fin_cand)
                    except queue.Empty:
                        break

                # 1. Hút các candidate mới từ Queue vào Active Map
                # [BOM #90 FIX]: Khóa theo (symbol, direction, registered_at) để KHÔNG tự ghi đè xóa mẫu 4h sau 15 phút,
                # và ghi DB các mẫu FIFO evicted BÊN NGOÀI _active_lock (tránh treo Main/WS thread)!
                evicted_candidates = []
                while not self._queue.empty():
                    try:
                        cand = self._queue.get_nowait()
                        cand_key = f"{cand.symbol}_{cand.direction}_{int(cand.registered_at)}"

                        with self._active_lock:
                            # Nếu đã chạm ngưỡng max_active, loại bỏ ứng viên cũ nhất (lưu DB bên ngoài lock)
                            if len(self._active_candidates) >= self.max_active:
                                oldest_key = min(
                                    self._active_candidates.keys(),
                                    key=lambda k: self._active_candidates[k].registered_at
                                )
                                oldest_cand = self._active_candidates.pop(oldest_key)
                                now_ev = time.time()
                                elapsed_ev = now_ev - float(oldest_cand.registered_at or now_ev)
                                if oldest_cand.snapshot_60m_done:
                                    _fifo_lbl = 'TIMEOUT_60M'
                                elif elapsed_ev < 3600:
                                    _fifo_lbl = 'EVICTED_EARLY'
                                else:
                                    _fifo_lbl = 'DISCARDED_FIFO'
                                if oldest_cand.status == 'ACTIVE':
                                    oldest_cand.status = _fifo_lbl
                                oldest_cand.closed_at = now_ev
                                oldest_cand.finalize_dual_eval(timeout_label=_fifo_lbl)
                                evicted_candidates.append(oldest_cand)

                            self._active_candidates[cand_key] = cand
                            logger.info(
                                "🧭 [SHADOW PATHFINDER] Đang theo dõi ngầm 2 chiều: %s %s (Trạm: %s, RVol=%.2fx, TP1=%.4f, SL=%.4f)",
                                cand.symbol, cand.direction, cand.station_blocked,
                                cand.rvol, cand.tp1_price, cand.sl_price
                            )
                    except queue.Empty:
                        break
                for ec in evicted_candidates:
                    self._save_candidate_to_db(ec)

                # 2. [V6.1 BOM #73]: Cửa sổ Kép 60p (chụp đóng băng dual_eval_60m) + 240p (4h giảm TIMEOUT_60M mù nhãn)
                now = time.time()
                timeout_candidates = []

                with self._active_lock:
                    for key, cand in list(self._active_candidates.items()):
                        elapsed_s = now - cand.registered_at
                        if elapsed_s >= self.snapshot_60m_sec and not cand.snapshot_60m_done:
                            cand.capture_60m_snapshot()
                        if elapsed_s >= self.tracking_window_sec:
                            to_lbl = 'TIMEOUT_240M' if self.tracking_window_sec > 3600 else 'TIMEOUT_60M'
                            if cand.status == 'ACTIVE':
                                cand.status = to_lbl
                            cand.closed_at = now
                            cand.finalize_dual_eval(timeout_label=to_lbl)
                            timeout_candidates.append(cand)
                            del self._active_candidates[key]

                for tc in timeout_candidates:
                    self._save_candidate_to_db(tc)

                # 3. Dọn dẹp dedup cache cũ (> 1 giờ) để chống phình RAM (thread-safe với _active_lock)
                with self._active_lock:
                    if len(self._last_registered) > 200:
                        cutoff = now - 3600
                        self._last_registered = {k: v for k, v in self._last_registered.items() if v >= cutoff}

            except Exception as e:
                logger.debug("Lỗi trong vòng lặp Shadow Worker: %s", e)

            # [BOM #94 FIX]: Dung queue.get(timeout=1.0) thay vi ngu cung 5s de hut candidate moi trong < 1ms!
            self._stop_event.wait(0.25 if not self._queue.empty() else 1.0)

    @staticmethod
    def _safe_json_dumps(obj: Any) -> str:
        """Chuyển đổi an toàn sang JSON chống lỗi TypeError không thể serialize (numpy/timestamp)."""
        import json
        try:
            return json.dumps(obj, default=str, ensure_ascii=False)
        except Exception:
            return "{}"

    def _save_candidate_to_db(self, cand: ShadowCandidate):
        """Ghi 1 dòng kết quả vào SQLite WAL bằng connection độc lập ngắn hạn."""
        conn = None
        try:
            if 'dual_eval_240m' not in cand.details:
                cand.finalize_dual_eval()
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            eff_closed = cand.direct_closed_at or cand.closed_at or time.time()
            duration = int(eff_closed - cand.registered_at)

            cursor.execute("""
            INSERT INTO shadow_pathfinder_logs (
                timestamp, symbol, direction, asset_class, station_blocked,
                block_reason, entry_price, sl_price, tp1_price, rvol,
                ai_confidence, max_mfe, max_mae, outcome, duration_seconds,
                closed_timestamp, details_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                int(cand.registered_at * 1000),
                cand.symbol,
                cand.direction,
                cand.asset_class,
                cand.station_blocked,
                cand.block_reason,
                cand.entry_price,
                cand.sl_price,
                cand.tp1_price,
                cand.rvol,
                cand.ai_confidence,
                round(cand.max_mfe, 4),
                round(cand.max_mae, 4),
                cand.status,
                duration,
                int((cand.closed_at or time.time()) * 1000),
                self._safe_json_dumps(cand.details)
            ))
            conn.commit()

            dual = cand.details.get('dual_eval_240m') or cand.details.get('dual_eval_60m') or {}
            inv_out = dual.get('inverted_1to2', 'N/A')
            icon = "🎯" if cand.status == 'TP1_HIT' else ("🛑" if cand.status == 'SL_HIT' else "⏳")
            logger.info(
                "%s [SHADOW KẾT THÚC] %s %s -> Thuận:%s | LậtNgược:%s (Up=+%.2f%%, Dn=-%.2f%%, Giữ %ds, Trạm: %s)",
                icon, cand.symbol, cand.direction, cand.status, inv_out,
                cand.max_up_pct, cand.max_down_pct, duration, cand.station_blocked
            )
        except Exception as e:
            logger.error("❌ [SHADOW PATHFINDER] Lỗi ghi DB: %s", e)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
