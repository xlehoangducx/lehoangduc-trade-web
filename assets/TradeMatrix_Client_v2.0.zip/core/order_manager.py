import logging
import time
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class OrderManager:
    """
    Lớp quản lý các lệnh giao dịch.
    """
    def __init__(self, exchange_connector, db_manager, mode='demo'):
        self.exchange = exchange_connector
        self.db = db_manager
        self.mode = mode
        
    def place_order(self, signal: Dict[str, Any]) -> Dict[str, Any]:
        """Đặt lệnh dựa trên tín hiệu giao dịch."""
        symbol = signal.get('symbol')
        side = signal.get('signal_type') # buy hoặc sell
        amount = signal.get('amount')
        price = signal.get('price')
        order_type = signal.get('order_type', 'market')
        
        logger.info(f"Tiến hành đặt lệnh {side} cho {symbol} (amount: {amount})")
        
        order = {}
        if side == 'buy':
            order = self.exchange.create_buy_order(symbol, amount, price, order_type)
        elif side == 'sell':
            order = self.exchange.create_sell_order(symbol, amount, price, order_type)
        else:
            logger.error(f"Loại tín hiệu không hợp lệ: {side}")
            return {}
            
        if order:
            # Lưu lịch sử lệnh
            trade_data = {
                'timestamp': order.get('timestamp') or int(time.time() * 1000),
                'symbol': symbol,
                'side': side,
                'type': order_type,
                'price': order.get('price') or price,
                'amount': amount,
                'cost': order.get('cost', 0),
                'fee': order.get('fee', {}).get('cost', 0),
                'pnl': 0.0, # Chưa tính PNL cho lệnh mới
                'strategy': signal.get('strategy', 'unknown'),
                'status': order.get('status', 'open'),
                'order_id': order.get('id'),
                'mode': self.mode
            }
            self.db.save_trade(trade_data)
            
        return order

    def check_orders(self) -> List[Dict[str, Any]]:
        """Kiểm tra và cập nhật trạng thái các lệnh mở."""
        # Lấy từ db các lệnh có status='open'
        open_db_orders = [t for t in self.db.get_trades() if t.get('status') == 'open' and t.get('order_id')]
        
        updates = []
        for trade in open_db_orders:
            try:
                order = self.exchange.get_order_status(trade['order_id'], trade['symbol'])
                if order and order.get('status') != 'open':
                    # Cập nhật DB
                    trade['status'] = order['status']
                    realized_pnl = float(order.get('info', {}).get('realizedPnl', 0) or 0.0)
                    trade['pnl'] = realized_pnl
                    self.db.update_trade_status(trade['order_id'], order['status'], pnl=realized_pnl)
                    updates.append(order)
            except Exception as e:
                logger.error(f"Lỗi kiểm tra lệnh {trade['order_id']}: {e}")
        return updates

    def cancel_all(self, symbol: str = None) -> int:
        """Hủy tất cả các lệnh mở."""
        open_orders = self.exchange.get_open_orders(symbol)
        count = 0
        import time
        for order in open_orders:
            res = self.exchange.cancel_order(order['id'], order['symbol'])
            if res:
                count += 1
            time.sleep(0.1) # Tránh IP ban
        logger.info(f"Đã hủy {count} lệnh mở.")
        return count

    def get_open_positions(self) -> List[Dict[str, Any]]:
        """Lấy danh sách các vị thế đang mở (chỉ spot balance hoặc positions)."""
        balance = self.exchange.get_balance()
        positions = []
        if 'total' in balance:
            for coin, amount in balance['total'].items():
                if amount > 0.01: # Bỏ qua dust balance
                    positions.append({'coin': coin, 'amount': amount})
        return positions

    def get_trade_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Lấy lịch sử giao dịch."""
        # Gọi db_manager để lấy lịch sử
        return self.db.get_trades(limit=limit)
