"""
TRADEMATRIX QUANT ECOSYSTEM - SHADOW PATHFINDER ALPHA REPORT & 3D MATRIX ANALYZER
=================================================================================
Công cụ định lượng kiểm toán dữ liệu từ cơ chế Tìm Đường Thực Chiến Song Hành.
Phân rã Ma Trận 3D: [LONG/SHORT] x [3 Lớp Tài Sản] x [Dải RVol] x [7 Trạm Kiểm Soát].
Tự động tầm soát các cụm có N >= 20 và Win Rate >= 80% để chủ động đề xuất nâng cấp!
"""

import os
import sys
import json
import sqlite3
from typing import Dict, List, Any

# Đảm bảo import được các module từ thư mục gốc
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def get_rvol_bucket(rvol: float) -> str:
    """Phân dải RVol thành 4 phân khúc chuẩn quỹ."""
    if rvol < 0.85:
        return "< 0.85x (Cạn kiệt)"
    elif rvol < 1.50:
        return "0.85x - 1.50x (Trung bình)"
    elif rvol <= 3.00:
        return "1.50x - 3.00x (Bão Volume)"
    else:
        return "> 3.00x (Siêu Climax)"

from pathlib import Path

def analyze_shadow_alpha(db_path: str = None):
    pc2_db = Path(r"\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\data\trade_bot.db")
    pc1_db = Path(__file__).parent.parent / "data" / "trade_bot.db"
    
    if db_path is None:
        if pc2_db.exists():
            db_path = str(pc2_db)
            print(f"📡 Kết nối trực tiếp Database PC2 Live: {db_path}")
        else:
            db_path = str(pc1_db)
            print(f"📁 Đang đọc Database cục bộ PC1: {db_path}")

    if not os.path.exists(db_path):
        print(f"❌ Không tìm thấy database tại {db_path}")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Kiểm tra bảng có tồn tại không
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='shadow_pathfinder_logs';")
    if not cursor.fetchone():
        print("ℹ️ Bảng 'shadow_pathfinder_logs' chưa có dữ liệu hoặc chưa được tạo.")
        conn.close()
        return

    cursor.execute("SELECT count(*) FROM shadow_pathfinder_logs;")
    total_records = cursor.fetchone()[0]

    print("=" * 80)
    print(f"🧭 BÁO CÁO ĐỊNH LƯỢNG SHADOW PATHFINDER (TỔNG CỘNG: {total_records} MẪU)")
    print("=" * 80)

    if total_records == 0:
        print("ℹ️ Chưa có mẫu nào được ghi nhận. Vui lòng để bot chạy để thu thập dữ liệu.")
        conn.close()
        return

    # 1. Thống kê tổng quan Outcome
    cursor.execute("""
    SELECT outcome, count(*), round(avg(max_mfe), 2), round(avg(max_mae), 2), round(avg(duration_seconds), 0)
    FROM shadow_pathfinder_logs
    GROUP BY outcome;
    """)
    outcome_rows = cursor.fetchall()
    print("\n📊 1. PHÂN PHỐI KẾT CỤC TOÀN CỤC (GLOBAL OUTCOMES):")
    print(f"{'Kết Cục':<15} | {'Số Lượng':<10} | {'Tỷ Lệ (%)':<10} | {'MFE TB (%)':<12} | {'MAE TB (%)':<12} | {'Thời Gian TB (s)':<16}")
    print("-" * 85)
    for row in outcome_rows:
        outc, cnt, avg_mfe, avg_mae, avg_dur = row
        pct = (cnt / total_records) * 100.0
        print(f"{outc:<15} | {cnt:<10} | {pct:>8.1f}% | {avg_mfe:>10.2f}% | {avg_mae:>10.2f}% | {avg_dur:>14.0f}s")

    # 2. Thống kê theo 7 Trạm Kiểm Soát
    cursor.execute("""
    SELECT station_blocked, 
           count(*) as total,
           sum(case when outcome = 'TP1_HIT' then 1 else 0 end) as tp1_hits,
           sum(case when outcome = 'SL_HIT' then 1 else 0 end) as sl_hits,
           sum(case when outcome = 'TIMEOUT_60M' then 1 else 0 end) as timeouts,
           round(avg(max_mfe), 2) as avg_mfe
    FROM shadow_pathfinder_logs
    GROUP BY station_blocked
    ORDER BY total DESC;
    """)
    station_rows = cursor.fetchall()
    print("\n🛑 2. PHÂN TÍCH THEO 7 TRẠM KIỂM SOÁT (STATION FORENSICS):")
    print(f"{'Trạm Bị Chặn':<30} | {'Tổng':<6} | {'TP1':<6} | {'SL':<6} | {'TimeOut':<8} | {'Win Rate (%)':<14} | {'Đánh Giá Bản Chất':<25}")
    print("-" * 105)

    alpha_candidates = []

    for row in station_rows:
        station, tot, tp1, sl, tout, mfe = row
        closed_trades = tp1 + sl
        win_rate = (tp1 / closed_trades * 100.0) if closed_trades > 0 else 0.0

        if win_rate >= 75.0 and closed_trades >= 5:
            assessment = "⚠️ RŨ NON (CHẶN NHẦM SIÊU SÓNG!)"
        elif win_rate <= 35.0 and closed_trades >= 5:
            assessment = "🛡️ CỨU THUA XUẤT SẮC"
        else:
            assessment = "⚖️ CÂN BẰNG RỦI RO"

        print(f"{station:<30} | {tot:<6} | {tp1:<6} | {sl:<6} | {tout:<8} | {win_rate:>12.1f}% | {assessment:<25}")

    # 3. Phân Rã Ma Trận 3D: [Hướng] x [Lớp Tài Sản] x [Dải RVol] x [Trạm]
    cursor.execute("""
    SELECT direction, asset_class, rvol, station_blocked, outcome, max_mfe
    FROM shadow_pathfinder_logs;
    """)
    all_raw = cursor.fetchall()

    clusters: Dict[tuple, Dict[str, Any]] = {}
    for r in all_raw:
        direction, asset_class, rvol, station, outcome, mfe = r
        rvol_b = get_rvol_bucket(float(rvol or 1.0))
        cluster_key = (station, direction, asset_class, rvol_b)

        if cluster_key not in clusters:
            clusters[cluster_key] = {'total': 0, 'tp1': 0, 'sl': 0, 'timeout': 0, 'mfes': []}

        clusters[cluster_key]['total'] += 1
        clusters[cluster_key]['mfes'].append(float(mfe or 0.0))
        if outcome == 'TP1_HIT':
            clusters[cluster_key]['tp1'] += 1
        elif outcome == 'SL_HIT':
            clusters[cluster_key]['sl'] += 1
        else:
            clusters[cluster_key]['timeout'] += 1

    print("\n" + "=" * 80)
    print("🔥 3. TẦM SOÁT MỎ VÀNG ALPHA (CỤM N >= 20 VÀ WIN RATE >= 80% HOẶC N >= 5 & WIN >= 80% GIAI ĐOẠN ĐẦU):")
    print("=" * 80)

    found_alpha = False
    for key, data in sorted(clusters.items(), key=lambda x: x[1]['total'], reverse=True):
        station, direction, asset_class, rvol_b = key
        tot = data['total']
        tp1 = data['tp1']
        sl = data['sl']
        closed = tp1 + sl
        win_rate = (tp1 / closed * 100.0) if closed > 0 else 0.0
        avg_mfe = sum(data['mfes']) / len(data['mfes']) if data['mfes'] else 0.0

        # Tiêu chuẩn mỏ vàng Alpha
        if win_rate >= 80.0 and closed >= 5:
            found_alpha = True
            print(f"\n🚀 [ALPHA PHÁT HIỆN] Trạm: {station} | Chiều: {direction} | Lớp: {asset_class} | RVol: {rvol_b}")
            print(f"   - Mẫu số đóng: {closed}/{tot} (TP1: {tp1}, SL: {sl}, TimeOut: {data['timeout']})")
            print(f"   - Win Rate: {win_rate:.1f}% | MFE Đỉnh TB: +{avg_mfe:.2f}%")
            print(f"   - Kết luận: Trạm {station} đang vô tình CHẶN NHẦM một cụm tín hiệu siêu lãi!")
            print(f"   - Hành động đề xuất: Tạo Bypass / Whitelist có điều kiện cho mẫu hình này.")

    if not found_alpha:
        print("ℹ️ Chưa phát hiện cụm nào đạt tiêu chuẩn Alpha (Win >= 80%, N >= 5). Tiếp tục thu thập thêm mẫu...")

    print("\n" + "=" * 80)
    conn.close()

if __name__ == '__main__':
    analyze_shadow_alpha()
