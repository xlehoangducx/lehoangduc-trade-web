"""
TRADEMATRIX AUTONOMOUS QUANT EVOLUTION LAB (V6.2 - BOM #84)
===========================================================
Cong cu tu tien hoa & kiem toan dinh luong 100% OFFLINE (0 goi REST Binance, PRAGMA query_only=ON):
1. Quet 3 truc tu dong (Cum Don + Phoi 2-4 Nhanh COMBO-* + Lat Cong Veto GATE-INV-*) voi 20 Thau Kinh DNA.
2. Chong Overfitting thich ung: Walk-Forward 70/30 OOS (N < 50) -> tu dong nang len 3-Fold Rolling OOS (N >= 50).
3. Tuong lua Chong Trung Lap (Overlap < 40%) giua cac vu khi moi & vu khi cu.
4. Kiem toan & De xuat Tinh Chinh Phoi 2-4 Tang DNA cho CHINH 10 VU KHI CU (VK1..VK10) + Luat 3 Ky.

Cach chay:
    .\\venv\\Scripts\\python.exe tools/auto_evolution_lab.py
"""

import os
import sys
import json
import argparse
from datetime import datetime

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from core.quant_evolution_engine import (
    MAX_TOTAL_WEAPONS_CAP,
    load_weapon_lifecycle,
    run_auto_dna_lab_discovery_and_optimizer,
    audit_and_optimize_existing_weapons,
)


def main():
    parser = argparse.ArgumentParser(description="TradeMatrix Autonomous Quant Evolution Lab (100% Offline)")
    parser.add_argument("--db", default=os.path.join(ROOT_DIR, "data", "trade_bot.db"), help="Duong dan SQLite trade_bot.db")
    parser.add_argument("--json", action="store_true", help="In ket qua dang JSON")
    args = parser.parse_args()

    db_path = args.db
    existing_audit = audit_and_optimize_existing_weapons(db_path=db_path)
    lab_scan = run_auto_dna_lab_discovery_and_optimizer(db_path=db_path, ttl_sec=0.0)
    lc = load_weapon_lifecycle()

    if args.json:
        print(json.dumps({"existing_weapons": existing_audit, "lab_evolution": lab_scan}, ensure_ascii=False, indent=2))
        return

    db_sum = existing_audit.get("db_summary") or {}
    active_cnt = sum(1 for s in (lc.get("states") or {}).values() if s in ("OFFICIAL", "EXPERIMENTAL"))
    free_slots = max(0, MAX_TOTAL_WEAPONS_CAP - active_cnt)

    print("=" * 112)
    print(f"🧬 TRADEMATRIX AUTONOMOUS QUANT EVOLUTION LAB V6.2 (100% OFFLINE) — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 112)
    print(
        f"📊 Kho dữ liệu Shadow (khử lặp 15M): {db_sum.get('total_dedup_samples', 0)} mẫu | "
        f"Nhãn 240p (4h): {db_sum.get('samples_240m', 0)} | "
        f"Độ phủ weapon_id: {db_sum.get('weapon_id_coverage_pct', 0)}% | "
        f"Phân bổ: {db_sum.get('by_asset_class', {})}"
    )
    print(f"⚔️ Kho Vũ Khí hiện tại: {active_cnt}/{MAX_TOTAL_WEAPONS_CAP} đang hoạt động (còn trống {free_slots} slot chống Overfitting)")

    print("\n" + "-" * 112)
    print("1. KIỂM TOÁN & ĐỀ XUẤT TINH CHỈNH PHỐI 2-4 TẦNG DNA CHO CHÍNH 10 VŨ KHÍ ĐANG CÓ (VK1..VK10)")
    print("-" * 112)
    print(f"{'Mã':<5} | {'Trạng thái':<12} | {'N':>3} | {'TP%':>5} | {'SL%':>5} | {'Net$':>7} | {'Luật 3 Kỳ':<30} | Đề xuất tinh chỉnh OOS")
    print("-" * 112)
    for w in existing_audit.get("weapons") or []:
        r = w["raw"]
        ref = w.get("best_refinement")
        if ref:
            ref_str = (
                f"✨ [{ref['lens_name_vi'][:32]}] N={ref['n']} TP={ref['strict_tp']}% ({ref['tp_delta_pp']:+.1f}pp) "
                f"SL={ref['sl_rate']}% ({ref['sl_delta_pp']:+.1f}pp) OOS({ref['oos_mode']} SL={ref['oos_sl_rate']}%) Net={ref['net_usd']:+.1f}$"
            )
        else:
            ref_str = "— Giữ nguyên (chưa có màng lọc nào cải thiện rõ trên OOS)"
        print(
            f"{w['code']:<5} | {w['state']:<12} | {r['n']:>3} | {r['strict_tp']:>4.1f}% | {r['sl_rate']:>4.1f}% | "
            f"{w['raw_net_usd']:>+6.1f}$ | {w['rule3_verdict']:<30} | {ref_str}"
        )

    overlaps = existing_audit.get("overlaps") or []
    if overlaps:
        print("\n⚠️ Cảnh báo trùng lặp giữa các Vũ Khí hiện có (Overlap >= 15%):")
        for ov in overlaps:
            print(f"   • {ov['a']}  ∩  {ov['b']} : {ov['shared']} mẫu chung ({ov['pct']}%)")

    print("\n" + "-" * 112)
    print("2. BẢNG XẾP HẠNG PHÒNG THÍ NGHIỆM TỰ TIẾN HÓA 3 TRỤC (ĐƠN + PHỐI 2-4 NHÁNH COMBO + LẬT CỔNG VETO)")
    print("-" * 112)
    active_labs = lab_scan.get("active_labs") or []
    print(f"{'Mã':<9} | {'Trục':<9} | {'Slot':<7} | {'N':>3} | {'Coin':>4} | {'TP%':>5} | {'SL%':>5} | {'Net$':>7} | {'OOS':<4} | {'TrùngVK':>7} | {'Kết luận':<17} | Tên mẫu")
    print("-" * 112)
    ready_list = []
    near_list = []
    reject_list = []
    for lb in active_labs:
        oos_s = "PASS" if lb.get("oos_passed") else "FAIL"
        ov_s = f"{lb.get('max_vk_overlap_pct', 0):.0f}%"
        print(
            f"{lb['code']:<9} | {lb.get('axis','SINGLE'):<9} | {lb['slot']:<7} | {lb['samples_n']:>3} | "
            f"{lb['coins_count']:>4} | {lb['win_rate']:>4.1f}% | {lb['sl_rate']:>4.1f}% | "
            f"{float(lb.get('est_net_usd') or 0):>+6.1f}$ | {oos_s:<4} | {ov_s:>7} | {lb['verdict']:<17} | {lb['title_vi'][:42]}"
        )
        if lb["verdict"] == "READY_OPTIMIZED":
            ready_list.append(lb)
        elif lb["verdict"] == "ACCUMULATING_GOOD":
            near_list.append(lb)
        elif lb["verdict"] == "SUGGEST_REJECT":
            reject_list.append(lb)

    print("\n" + "-" * 112)
    print("3. KHUYẾN NGHỊ HÀNH ĐỘNG TỰ TIẾN HÓA (CHỐNG OVERFITTING & GIỮ TRẦN 14 VŨ KHÍ)")
    print("-" * 112)
    if ready_list:
        print(f"🏆 ĐÃ ĐẠT 5/5 CỔNG CỨNG ALPHA ({len(ready_list)} mẫu — sẵn sàng bấm 1-Click Thăng Hạng trên /so-do-dong):")
        for lb in ready_list:
            print(f"   ✅ {lb['code']} ({lb['signature']}): {lb['status_vi']}")
    else:
        print("⏳ Chưa có mẫu nào đạt trọn vẹn 5/5 Cổng Cứng Alpha hôm nay (hàng rào BOM #72 đang bảo vệ chống thăng hạng non).")
    if near_list:
        print(f"🌟 Ứng viên cận ngưỡng sáng nhất ({len(near_list)} mẫu — ưu tiên gom thêm nhãn 240p):")
        for lb in near_list[:4]:
            print(f"   • {lb['code']} [{lb.get('axis')}] N={lb['samples_n']}/15 | TP={lb['win_rate']}% | SL={lb['sl_rate']}% | Net={lb.get('est_net_usd'):+.1f}$ | {lb['title_vi']}")
    if reject_list:
        print(f"🚫 Mẫu đủ dữ liệu nhưng trượt 0/20 thấu kính OOS ({len(reject_list)} mẫu — nên bấm Cấm Thăng Hạng trên UI):")
        for lb in reject_list:
            print(f"   × {lb['code']} ({lb['signature']}): N={lb['samples_n']}, SL={lb['sl_rate']}%")
    subsumed_list = lab_scan.get("subsumed_labs") or []
    if subsumed_list:
        print(f"📦 ĐÃ TỰ ĐỘNG XẾP GỌN SANG TAB 'ĐÃ BAO TRÙM' ({len(subsumed_list)} mẫu con — tiết kiệm trần 14 vũ khí):")
        for sb in subsumed_list:
            print(f"   ↪ {sb['title_vi']} (N={sb['samples_n']}, TP={sb['win_rate']}%)  ==>  Bao trùm bởi {sb.get('covered_by_name')}")
    print("=" * 112)


if __name__ == "__main__":
    main()
