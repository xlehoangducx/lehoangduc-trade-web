"""
TRADEMATRIX AUTOMATED PC2 BACKUP TOOL
Script tự động đóng gói và đẩy bản sao lưu toàn diện (Source code, Web, DB, State) lên Ổ D của PC2.
"""
import os, sys, shutil, zipfile, hashlib, datetime
from pathlib import Path

def main():
    pc1_trade = Path(r'd:\TRADE')
    pc2_base = Path(r'\\192.168.1.10\trade-web')
    pc2_live_bot = pc2_base / 'assets' / 'TradeMatrix_Client_v2.0'
    backup_root = pc2_base / 'BACKUP_MASTER_TRADE_AND_WEB'

    print("=== ĐANG TẠO BẢN SAO LƯU PHÒNG TRỪ RỦI RO LÊN Ổ D PC2 ===")
    if not pc2_base.exists():
        print("❌ Lỗi: Không thể kết nối tới PC2 qua mạng LAN!")
        return 1

    dir_trade_src = backup_root / '01_SOURCE_CODE_TRADE_BOT'
    dir_db_state = backup_root / '02_DATABASE_AND_RUNTIME_STATE'
    dir_web = backup_root / '03_WEB_CLIENT_DASHBOARD'
    dir_archive = backup_root / '04_ARCHIVES_ZIP'
    dir_recovery = backup_root / '05_RECOVERY_SCRIPTS'

    for d in [dir_trade_src, dir_db_state, dir_web, dir_archive, dir_recovery]:
        d.mkdir(parents=True, exist_ok=True)

    # 1. Source code
    ignore_patterns = shutil.ignore_patterns('__pycache__', '*.pyc', '.git', 'venv', '*.log', 'scratch', '*.tmp')
    for sub in ['core', 'ai', 'strategies', 'risk', 'database', 'config', 'tools', 'dashboard', 'docs']:
        s = pc1_trade / sub
        t = dir_trade_src / sub
        if s.exists():
            if t.exists(): shutil.rmtree(t)
            shutil.copytree(s, t, ignore=ignore_patterns)
    for item in pc1_trade.iterdir():
        if item.is_file() and item.suffix in ('.py', '.bat', '.yaml', '.yml', '.md', '.txt', '.html', '.json'):
            shutil.copy2(item, dir_trade_src / item.name)

    # 2. Database & State (đồng bộ đúng cấu trúc restore_from_pc2_backup.py)
    pc2_data_dir = pc2_live_bot / 'data'
    pc1_data_dir = pc1_trade / 'data'
    db_live = pc2_data_dir / 'trade_bot.db'
    if not db_live.exists():
        db_live = pc1_data_dir / 'trade_bot.db'
    if db_live.exists():
        shutil.copy2(db_live, dir_db_state / 'trade_bot.db')
        for suffix in ('-wal', '-shm'):
            sidecar = Path(str(db_live) + suffix)
            if sidecar.exists():
                try:
                    shutil.copy2(sidecar, dir_db_state / f'trade_bot.db{suffix}')
                except (FileNotFoundError, OSError):
                    pass
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        shutil.copy2(db_live, dir_db_state / f'trade_bot_snapshot_{ts}.db')

    # Sao lưu runtime JSON state (bot_state*.json, v.v.) từ PC2 (fallback PC1)
    for src_data_dir in (pc1_data_dir, pc2_data_dir):
        if src_data_dir.exists():
            for jf in src_data_dir.glob('*.json'):
                shutil.copy2(jf, dir_db_state / jf.name)

    # Sao lưu AI models directory (02_DATABASE_AND_RUNTIME_STATE/models)
    models_src = pc2_data_dir / 'models'
    if not models_src.exists():
        models_src = pc1_data_dir / 'models'
    if models_src.exists():
        models_dst = dir_db_state / 'models'
        if models_dst.exists():
            shutil.rmtree(models_dst)
        shutil.copytree(models_src, models_dst, ignore=ignore_patterns)

    # Sao lưu snapshot cấu hình runtime đang chạy trên PC2 (settings, strategies, pairs)
    pc2_cfg_src = pc2_live_bot / 'config'
    if pc2_cfg_src.exists():
        pc2_cfg_dst = dir_db_state / 'pc2_runtime_config'
        pc2_cfg_dst.mkdir(parents=True, exist_ok=True)
        for cfg_name in ('settings.yaml', 'strategies.yaml', 'pairs.yaml'):
            cfg_file = pc2_cfg_src / cfg_name
            if cfg_file.exists():
                shutil.copy2(cfg_file, pc2_cfg_dst / cfg_name)

    # 3. Web
    for item in pc2_base.iterdir():
        if item.is_file() and item.suffix in ('.html', '.ps1', '.md', '.js', '.css'):
            shutil.copy2(item, dir_web / item.name)
    for sub in ['css', 'js']:
        s = pc2_base / sub
        t = dir_web / sub
        if s.exists():
            if t.exists(): shutil.rmtree(t)
            shutil.copytree(s, t)
    
    print("✅ Đã cập nhật bản sao lưu toàn diện thành công trên PC2!")
    return 0

if __name__ == '__main__':
    sys.exit(main())
