"""
TRADEMATRIX DAILY AUDITOR & VERIFICATION HARNESS (CHUYÊN GIA KIỂM TOÁN TỰ ĐỘNG)
Tự động đối soát toàn bộ hệ thống thực chiến PC2 qua mạng LAN:
Đọc database, bóc tách PnL ngày (có trừ phí sàn & gom theo vị thế Round-trip), kiểm tra lệnh âm, và chấm điểm Rubric 100.
"""

import os
import sys
import json
import sqlite3
import requests
from datetime import datetime, date
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

ROOT_DIR = Path(__file__).parent.parent
PC2_DIR = Path(r"\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0")

class DailyAuditor:
    def __init__(self):
        self.rubric_score = 0
        self.max_score = 100
        self.findings = []
        self.today_str = datetime.now().strftime('%Y-%m-%d')
        self.today_compact = datetime.now().strftime('%Y%m%d')

    def run_full_audit(self):
        print("=" * 80)
        print(f"🕵️  TRADEMATRIX AUTOMATED VERIFICATION AUDIT — {datetime.now().strftime('%H:%M:%S %d/%m/%Y')}")
        print("=" * 80)

        # 1. Kiểm tra kết nối LAN & Trạng thái PC2 (20đ)
        lan_score = self._audit_pc2_connection()

        # 2. Kiểm tra Database & Hiệu suất Giao Dịch Hôm Nay (30đ)
        db_score = self._audit_trades_and_pnl()

        # 3. Kiểm tra Tín Hiệu & Độ Đồng Nhất Simulator (30đ)
        sim_score = self._audit_simulator_integrity()

        # 4. Kiểm tra Rào Chắn Cứng Codebase (20đ)
        gate_score = self._audit_hard_constraints()

        total = lan_score + db_score + sim_score + gate_score
        self.rubric_score = total

        print("\n" + "=" * 80)
        print(f"📊 BẢNG ĐIỂM ĐỊNH LƯỢNG RUBRIC SỨC KHỎE HỆ THỐNG: {total}/100 ĐIỂM")
        print(f"  • Kết nối LAN & Daemon PC2    : {lan_score}/20đ")
        print(f"  • Hiệu suất Giao Dịch & SL/TP : {db_score}/30đ")
        print(f"  • Độ Đồng Nhất Tín Hiệu (Sim) : {sim_score}/30đ")
        print(f"  • Rào Chắn Cứng Codebase     : {gate_score}/20đ")
        print("=" * 80)

        if total >= 95:
            print("🟢 ĐÁNH GIÁ TỔNG THỂ: HỆ THỐNG XUẤT SẮC — AN TOÀN VẬN HÀNH THỰC CHIẾN.")
        elif total >= 80:
            print("🟡 ĐÁNH GIÁ TỔNG THỂ: HỆ THỐNG KHẢ DỤNG — CẦN LƯU Ý MỘT SỐ ĐIỂM CẢNH BÁO.")
        else:
            print("🔴 ĐÁNH GIÁ TỔNG THỂ: CẢNH BÁO NGUY HIỂM — CẦN KHẮC PHỤC NGAY CÁC VI PHẠM.")

        if self.findings:
            print("\n📌 CÁC ĐIỂM CẦN CHÚ Ý / HÀNH ĐỘNG:")
            for i, f in enumerate(self.findings, 1):
                print(f"  {i}. {f}")
        print("=" * 80)
        return total

    def _audit_pc2_connection(self):
        score = 0
        if not PC2_DIR.exists():
            self.findings.append("Không thể truy cập thư mục LAN PC2 (\\\\192.168.1.10).")
            return 0
        score += 10

        log_file = PC2_DIR / "logs" / f"bot_{self.today_compact}.log"
        if not log_file.exists():
            log_files = sorted((PC2_DIR / "logs").glob("bot_*.log"), key=os.path.getmtime, reverse=True)
            log_file = log_files[0] if log_files else None

        if log_file and log_file.exists():
            mtime_diff = (datetime.now().timestamp() - log_file.stat().st_mtime)
            if mtime_diff < 180:
                score += 10
                print(f"  [OK] PC2 Live Daemon đang hoạt động liên tục (Log cập nhật cách đây {int(mtime_diff)}s).")
            else:
                score += 5
                self.findings.append(f"PC2 log không ghi nhận hoạt động mới trong {int(mtime_diff//60)} phút qua.")

            try:
                all_error_lines = []
                recent_lines = []
                with open(log_file, 'r', encoding='utf-8', errors='ignore') as lf:
                    for line in lf:
                        if ('[ERROR]' in line or '[CRITICAL]' in line) and 'UserWarning' not in line:
                            all_error_lines.append(line.strip())
                        recent_lines.append(line)
                        if len(recent_lines) > 200:
                            recent_lines.pop(0)

                recent_errors = [l.strip() for l in recent_lines if ('[ERROR]' in l or '[CRITICAL]' in l) and 'UserWarning' not in l]

                if recent_errors:
                    distinct_errors = list(set([l.split(':', 1)[-1].strip() if ':' in l else l for l in recent_errors]))[:5]
                    penalty = min(15, len(distinct_errors) * 5)
                    score = max(0, score - penalty)
                    self.findings.append(f"PC2 Log phát hiện {len(recent_errors)} lỗi Runtime gần nhất: {distinct_errors}")
                    print(f"  [CẢNH BÁO RUNTIME] Phát hiện {len(recent_errors)} lỗi trong log gần nhất (trừ {penalty}đ)!")
                    for err in distinct_errors:
                        print(f"    -> Lỗi chi tiết: {err}")
                elif all_error_lines:
                    distinct_all = list(set([l.split(':', 1)[-1].strip() if ':' in l else l for l in all_error_lines]))[:5]
                    penalty = min(5, len(distinct_all) * 2)
                    score = max(0, score - penalty)
                    self.findings.append(f"PC2 Log từng phát sinh {len(all_error_lines)} lỗi trong ngày: {distinct_all}")
                    print(f"  [CẢNH BÁO LỊCH SỬ LOG NGÀY] Từng phát sinh {len(all_error_lines)} lỗi trong ngày (200 dòng gần nhất đã ổn định, trừ {penalty}đ).")
                    for err in distinct_all:
                        print(f"    -> Lỗi tiêu biểu trong ngày: {err}")
                else:
                    print(f"  [OK] PC2 Log sạch hoàn toàn: Không có lỗi [ERROR] hay [CRITICAL] trong toàn bộ nhật ký hôm nay.")
            except Exception as e_log:
                self.findings.append(f"Không thể đọc nội dung file log PC2: {e_log}")
        else:
            self.findings.append("Không tìm thấy file log trên PC2.")

        return score

    def _audit_trades_and_pnl(self):
        score = 0
        db_file = PC2_DIR / "data" / "trade_bot.db"
        if not db_file.exists():
            self.findings.append("Không tìm thấy database trade_bot.db trên PC2.")
            return 0

        try:
            conn = sqlite3.connect(str(db_file), timeout=5)
            cur = conn.cursor()

            today_start_ts = int(datetime.combine(date.today(), datetime.min.time()).timestamp() * 1000)
            cur.execute("""
                SELECT symbol, side, price, amount, realized_pnl, fee, close_reason, timestamp
                FROM trades
                WHERE timestamp >= ? AND strategy = 'Binance Fill'
                ORDER BY timestamp ASC, id ASC
            """, (today_start_ts,))
            trades = cur.fetchall()

            # Gom các fill đóng (realized_pnl != 0) theo vị thế Round-trip và phân bổ đủ cả phí mở (open fee)
            closed_fills = [r for r in trades if abs(float(r[4] or 0.0)) > 1e-8]
            open_fills = [r for r in trades if abs(float(r[4] or 0.0)) <= 1e-8]
            total_gross_pnl = sum(float(r[4] or 0.0) for r in trades)
            total_fees = sum(float(r[5] or 0.0) for r in trades)
            total_net_pnl = total_gross_pnl - total_fees

            # Map open fee theo symbol trong ngày
            open_fee_by_sym = {}
            for r in open_fills:
                s_name = r[0]
                open_fee_by_sym[s_name] = open_fee_by_sym.get(s_name, 0.0) + float(r[5] or 0.0)

            grouped_positions = []
            for r in closed_fills:
                sym, side, price, amt, rpnl, fee, reason, ts = r
                # Phân bổ open fee nếu có
                allocated_open_fee = open_fee_by_sym.pop(sym, 0.0) if sym in open_fee_by_sym else 0.0
                net_fill = float(rpnl or 0.0) - float(fee or 0.0) - allocated_open_fee
                if grouped_positions and grouped_positions[-1]['symbol'] == sym and abs(ts - grouped_positions[-1]['last_ts']) <= 300_000:
                    grouped_positions[-1]['net_pnl'] += (float(rpnl or 0.0) - float(fee or 0.0))
                    grouped_positions[-1]['last_ts'] = ts
                else:
                    grouped_positions.append({'symbol': sym, 'net_pnl': net_fill, 'last_ts': ts})

            wins = sum(1 for p in grouped_positions if p['net_pnl'] > 0)
            losses = sum(1 for p in grouped_positions if p['net_pnl'] <= 0)
            total_closed = len(grouped_positions)
            winrate = (wins / total_closed * 100) if total_closed > 0 else 0.0

            cur.execute("SELECT open_positions_json, balance FROM bot_state ORDER BY id DESC LIMIT 1")
            state_row = cur.fetchone()
            open_pos = json.loads(state_row[0]) if state_row and state_row[0] else []
            balance = state_row[1] if state_row else 100.0

            conn.close()

            print(f"  [OK] Số dư thực tế: {balance:.2f} USDT | Đang mở {len(open_pos)} vị thế.")
            print(f"  [OK] Hiệu suất hôm nay: {total_closed} vị thế đóng ({len(trades)} fills) | Gross PnL: {total_gross_pnl:+.4f}$ | Phí: -{total_fees:.4f}$ | Net PnL: {total_net_pnl:+.4f} USDT | Tỷ lệ thắng: {winrate:.1f}% ({wins}W / {losses}L)")

            score += 15
            if total_net_pnl >= 0:
                score += 15
            else:
                if abs(total_net_pnl) < 0.5:
                    score += 10
                else:
                    score += 5
                    self.findings.append(f"Hôm nay đang ghi nhận âm Net PnL (sau phí): {total_net_pnl:.4f} USDT.")
        except Exception as e:
            self.findings.append(f"Lỗi truy vấn SQLite trade_bot.db: {e}")

        return score

    def _audit_simulator_integrity(self):
        score = 0
        sim_path = ROOT_DIR / "tools" / "true_signal_simulator.py"
        if not sim_path.exists():
            self.findings.append("Thiếu công cụ tools/true_signal_simulator.py.")
            return 0

        try:
            import subprocess
            res = subprocess.run([sys.executable, str(sim_path)], capture_output=True, text=True, encoding='utf-8', timeout=25)
            if res.returncode == 0:
                for line in res.stdout.split('\n'):
                    if 'Quyết định đồng nhất 100%' in line or 'KẾT LUẬN TOÁN HỌC ĐỊNH LƯỢNG' in line:
                        print(f"  [OK] Simulator: {line.strip()}")
                        score += 30
                        break
                if score == 0:
                    score += 25
            else:
                score += 10
                self.findings.append("true_signal_simulator.py chạy có lỗi trả về non-zero.")
        except Exception as e:
            score += 15
            self.findings.append(f"Không thể chạy tự động true_signal_simulator.py: {e}")

        return score

    def _audit_hard_constraints(self):
        score = 0
        gate_path = ROOT_DIR / "tools" / "hard_constraints_gate.py"
        if not gate_path.exists():
            return 0
        try:
            import subprocess
            res = subprocess.run([sys.executable, str(gate_path)], capture_output=True, text=True, encoding='utf-8', timeout=10)
            if res.returncode == 0:
                print("  [OK] Rào chắn cứng (Hard Constraints): 10/10 tiêu chí vượt qua hoàn hảo.")
                score += 20
            else:
                self.findings.append("Phát hiện vi phạm trong Hard Constraints Gate.")
        except Exception as e:
            self.findings.append(f"Lỗi kiểm tra Hard Constraints Gate: {e}")
        return score

if __name__ == '__main__':
    auditor = DailyAuditor()
    sys.exit(0 if auditor.run_full_audit() >= 95 else 1)
