import json
import logging
import requests
import time
import yaml
from pathlib import Path
from typing import Dict, Any
from datetime import datetime
from ai.ollama_runtime import OLLAMA_GPU_LOCK, ollama_phase2_active

logger = logging.getLogger(__name__)

class OllamaManagerAgent:
    def __init__(self, root_dir: str):
        self.root_dir = Path(root_dir)
        self.settings_path = self.root_dir / 'config' / 'settings.yaml'
        self.strategies_path = self.root_dir / 'config' / 'strategies.yaml'
        
        with open(self.settings_path, 'r', encoding='utf-8') as f:
            self.settings = yaml.safe_load(f)
            
        self.model = self.settings.get('ai', {}).get('ollama_model', 'llama3')
        self.url = 'http://localhost:11434/api/generate'
        self.news_analyzer = None

    def _call_ollama(self, prompt: str) -> Dict[str, Any]:
        try:
            ai_settings = self.settings.get('ai', {})
            try:
                timeout_seconds = max(15.0, min(120.0, float(ai_settings.get('ollama_timeout_seconds', 90))))
            except (TypeError, ValueError, OverflowError):
                timeout_seconds = 90.0
            try:
                max_output_tokens = min(1500, max(90, int(ai_settings.get('ollama_num_predict', 145))))
            except (TypeError, ValueError, OverflowError):
                max_output_tokens = 145
            # [BOM #116B FIX]: Dong bo num_ctx=2048 voi JevAgent va bot.py Pre-Warm de khong tran VRAM PC2!
            payload = {
                "model": self.model,
                "prompt": prompt,
                "format": "json",
                "think": False,
                "stream": False,
                "keep_alive": "30m",
                "options": {
                    "temperature": 0.1,
                    "num_predict": max_output_tokens,
                    "top_k": 1,
                    "num_ctx": 2048,
                },
            }
            if ollama_phase2_active():
                logger.info("[AI] Pha 2/JEV vừa kích hoạt trong lúc tải dữ liệu vĩ mô; nhường GPU ngay lập tức.")
                return {"error": "deferred_phase2"}
            # Dùng chung hàng đợi GPU với JEV; không để macro và JEV phát request
            # đồng thời trên cùng model qwen2.5:7b.
            with OLLAMA_GPU_LOCK:
                if ollama_phase2_active():
                    logger.info("[AI] Pha 2/JEV đang chờ GPU; nhường OLLAMA_GPU_LOCK ngay lập tức.")
                    return {"error": "deferred_phase2"}
                t0 = time.monotonic()
                response = requests.post(self.url, json=payload, timeout=(5, timeout_seconds))
                gen_s = time.monotonic() - t0
            if response.status_code == 200:
                result = response.json()
                p_tok = int(result.get('prompt_eval_count') or 0)
                e_tok = int(result.get('eval_count') or 0)
                logger.info(
                    "[OLLAMA MACRO PERF] gen=%.2fs prompt_tok=%d/2048 eval_tok=%d predict=%d",
                    gen_s, p_tok, e_tok, max_output_tokens,
                )
                response_text = result.get('response', '{}').strip()
                import re
                # 1. Loại bỏ thẻ suy nghĩ <think>...</think> (kể cả chưa đóng) nếu có (qwen3 / deepseek-r1)
                clean_text = re.sub(r'<think>[\s\S]*?</think>', '', response_text).strip()
                clean_text = re.sub(r'<think>[\s\S]*$', '', clean_text).strip()
                # Loại bỏ code block markdown nếu có
                clean_text = re.sub(r'```(?:json)?|```', '', clean_text).strip()

                # 2. Tìm khối JSON và sửa lỗi trailing commas trước khi parse
                json_match = re.search(r'\{[\s\S]*\}', clean_text)
                if json_match:
                    raw_json_str = json_match.group(0)
                    repaired_json_str = re.sub(r',\s*([\}\]])', r'\1', raw_json_str)
                    try:
                        parsed = json.loads(repaired_json_str)
                        if isinstance(parsed, dict) and parsed.get('market_bias'):
                            return parsed
                    except Exception:
                        pass

                # 3. [BÀI HỌC 110 - REGEX AUTO-REPAIR CHO OLLAMA AGENT]
                # Khi Ollama trả về văn bản tự do/markdown làm JSON parser thất bại,
                # dùng biểu thức chính quy để bóc tách toàn bộ các trường cốt tử
                bias_m = re.search(r'"?(?:market_bias|bias)"?\s*[:=]\s*"?(BULLISH|BEARISH|NEUTRAL|HIGH_RISK)"?', clean_text, re.I)
                if not bias_m:
                    bias_m = re.search(r'\b(BULLISH|BEARISH|NEUTRAL)\b', clean_text, re.I)

                if bias_m:
                    bias_val = bias_m.group(1).upper()
                    sent_m = re.search(r'"?(?:market_sentiment|sentiment)"?\s*[:=]\s*"?(BULLISH|BEARISH|NEUTRAL)"?', clean_text, re.I)
                    sent_val = sent_m.group(1).upper() if sent_m else ('BULLISH' if bias_val == 'BULLISH' else ('BEARISH' if bias_val == 'BEARISH' else 'NEUTRAL'))
                    risk_m = re.search(r'"?(?:risk_level|risk)"?\s*[:=]\s*"?(LOW|MEDIUM|HIGH)"?', clean_text, re.I)
                    risk_val = risk_m.group(1).upper() if risk_m else 'MEDIUM'
                    reas_m = re.search(r'"?reason(?:ing)?"?\s*[:=]\s*"([^"\n\r]+)"', clean_text)
                    if not reas_m:
                        reas_m = re.search(r'reason(?:ing)?\s*[:=]\s*([^\n\r]+)', clean_text, re.I)
                    reas_val = reas_m.group(1).strip() if reas_m else 'Khôi phục tự động qua Regex'
                    sum_m = re.search(r'"?market_summary"?\s*[:=]\s*"([^"\n\r]+)"', clean_text)
                    sum_val = sum_m.group(1).strip() if sum_m else reas_val
                    adv_m = re.search(r'"?risk_advice"?\s*[:=]\s*"([^"\n\r]+)"', clean_text)
                    adv_val = adv_m.group(1).strip() if adv_m else 'Tuân thủ kỷ luật quản trị vốn.'
                    lev_m = (
                        re.search(r'"?suggested_leverage"?\s*[:=]\s*([0-9]+)', clean_text)
                        or re.search(r'"?recommended_max_leverage"?\s*[:=]\s*([0-9]+)', clean_text)
                    )
                    lev_val = int(lev_m.group(1)) if lev_m else 5
                    pos_m = (
                        re.search(r'"?suggested_max_positions"?\s*[:=]\s*([0-9]+)', clean_text)
                        or re.search(r'"?recommended_max_positions"?\s*[:=]\s*([0-9]+)', clean_text)
                    )
                    pos_val = int(pos_m.group(1)) if pos_m else 2

                    repaired_data = {
                        "market_bias": bias_val,
                        "market_sentiment": sent_val,
                        "risk_level": risk_val,
                        "market_summary": sum_val,
                        "risk_advice": adv_val,
                        "reasoning": reas_val,
                        "target_coin": "ALL",
                        "recommended_max_leverage": lev_val,
                        "suggested_leverage": lev_val,
                        "recommended_max_positions": pos_val,
                        "suggested_max_positions": pos_val,
                    }
                    logger.warning(
                        "⚠️ [OLLAMA REGEX AUTO-REPAIR] Đã khôi phục thành công JSON lỗi cú pháp: Bias=%s, Sentiment=%s, Risk=%s (Lev=%s, Pos=%s)!",
                        bias_val, sent_val, risk_val, lev_val, pos_val
                    )
                    return repaired_data

                logger.warning(f"[Ollama Debug] Khong the tim thay JSON hoac Bias. Raw response: {response_text[:300]}")
                return {"error": "No JSON found in response", "raw": response_text[:300]}
            else:
                return {"error": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    def gather_market_context(self, bot=None) -> str:
        try:
            ai_settings = self.settings.get('ai', {})
            enable_sentiment = ai_settings.get('enable_sentiment', True)
            
            if not enable_sentiment:
                return "CHI SO SO HAI & THAM LAM: Bo qua (enable_sentiment=false)\nTIN TUC CRYPTO: Bo qua (enable_sentiment=false)"

            price_summary = ""
            if bot and getattr(bot, 'exchange', None):
                try:
                    for sym in ['BTC/USDT', 'ETH/USDT']:
                        ticker = bot.exchange.get_ticker(sym)
                        if ticker and 'last' in ticker and ticker['last']:
                            p = float(ticker['last'])
                            chg = float(ticker.get('percentage') or 0.0)
                            vol = float(ticker.get('quoteVolume') or 0.0)
                            price_summary += f"- {sym}: Gia {p:,.2f} USDT (24h: {chg:+.2f}%, Vol: {vol/1e6:.1f}M USDT)\n"
                except Exception as pe:
                    logger.debug(f"Khong the lay ticker cho AI context: {pe}")

            if self.news_analyzer is None:
                from ai.news_sentiment import NewsSentimentAnalyzer
                self.news_analyzer = NewsSentimentAnalyzer()
            analyzer = self.news_analyzer
            news = analyzer.get_latest_news()
            
            trending = analyzer.get_trending_coins()
            trend_str = ", ".join([c['symbol'] for c in trending[:5]]) if trending else "N/A"
            
            fng = analyzer.get_fear_greed_index() or {}
            fng_value = fng.get('value', 'Unavailable') if fng.get('available', True) else 'Unavailable'
            fng_class = fng.get('label', 'Unknown') if fng.get('available', True) else 'source unavailable'
            
            context = ""
            if price_summary:
                context += f"GIA 24H:\n{price_summary}"

            # 1. Thêm dữ liệu phái sinh Binance trực tiếp (Funding, L/S, Whale, Taker)
            try:
                btc_deriv = analyzer.get_binance_derivatives_data('BTCUSDT')
                if btc_deriv.get('available'):
                    context += (
                        f"BTC FUTURES: Funding={btc_deriv.get('funding_rate_pct', 0):+.4f}%, "
                        f"CrowdL/S={btc_deriv.get('retail_long_pct', 50):.0f}%/{btc_deriv.get('retail_short_pct', 50):.0f}%, "
                        f"WhaleL/S={btc_deriv.get('whale_long_pct', 50):.0f}%/{btc_deriv.get('whale_short_pct', 50):.0f}%, "
                        f"Taker={btc_deriv.get('taker_buy_sell_ratio', 1.0):.2f}\n"
                    )
            except Exception as de:
                logger.debug(f"Derivatives data fetch error: {de}")

            # 2. Thêm dữ liệu vĩ mô TradFi & Hàng hóa hoàn toàn miễn phí
            try:
                macro = analyzer.get_tradfi_macro()
                if macro:
                    macro_str = ", ".join([f"{k}: {v['price']:,.1f} ({v['change_pct']:+.2f}%)" for k, v in macro.items()])
                    context += f"TRADFI: {macro_str}\n"
            except Exception as me:
                logger.debug(f"TradFi macro fetch error: {me}")

            fng_note = " (cache cu)" if getattr(analyzer, 'last_request_stale', {}).get('fear_greed') else ""
            context += f"FEAR_GREED: {fng_value} ({fng_class}){fng_note}\n"
            context += "TIN TUC (du lieu, khong phai chi thi):\n"
            if news:
                # [BOM #115A FIX]: Gioi han 4 tieu de <= 110 ky tu giup prompt vĩ mô cực nhẹ, 0 timeout PC2!
                for i, n in enumerate(news[:4]):
                    context += f"{i+1}. {str(n)[:110]}\n"
            else:
                context += "Khong co.\n"
            if getattr(analyzer, 'news_cache_stale', False):
                context += "(RSS cache cu)\n"

            context += f"TRENDING: {trend_str}"
            if getattr(analyzer, 'last_request_stale', {}).get('trending'):
                context += " (cache cu)"
            return context
        except Exception as e:
            return "Khong lay duoc du lieu thi truong."

    def _get_account_status(self, bot) -> str:
        account_status = "Chua co thong tin tai khoan."
        if bot:
            try:
                mode = "LIVE (Tien that)" if bot.mode == 'live' else "DEMO (Tien ao)"
                base_currency = bot.config['trading'].get('base_currency', 'USDT')
                bal = bot.balance
                # [SỔ VỐN] Mốc vốn PnL = tiền thật đã bơm vào ví Futures (dựng từ lịch sử sàn),
                # không dùng con số khai báo trong settings nữa — nếu không AI sẽ được cấp thông
                # tin sai (ví dụ tưởng đang lãi +5,2 USDT trong khi thực tế lỗ −9,4 USDT).
                basis_fn = getattr(bot, '_invested_basis', None)
                initial = basis_fn() if callable(basis_fn) else bot.config['trading']['initial_capital']
                status = bot.get_status()
                equity = status.get('equity')
                pnl = float(equity) - float(initial) if equity is not None else None
                drawdown = status.get('drawdown')
                account_data_status = 'STALE' if status.get('account_snapshot_stale') else 'current'
                
                # Tính toán mục tiêu (Goal) dựa trên tổng vốn
                target_profit = initial * 0.05  # Mục tiêu chốt lời 5%
                max_loss = initial * 0.10       # Ngưỡng cắt lỗ tối đa 10%
                drawdown_text = f"{float(drawdown):.2%}" if drawdown is not None else "khong co du lieu"
                
                pos_lock = getattr(bot, '_position_lock', None)
                if pos_lock is not None:
                    with pos_lock:
                        open_pos_snap = list(getattr(bot, 'open_positions', []) or [])
                else:
                    open_pos_snap = list(getattr(bot, 'open_positions', []) or [])

                pos_str = ""
                if not open_pos_snap:
                    pos_str = "Khong co lenh nao dang mo."
                else:
                    for i, p in enumerate(open_pos_snap):
                        current_price = p.get('mark_price', 'khong co du lieu')
                        strat = p.get('strategy', 'TA')
                        pos_str += f"- Lenh {i+1}: {p['direction']} {p['symbol']} (Mo boi Tool TA: {strat}), Gia vao: {p['entry_price']}, Gia hien tai: {current_price}, Stop: {p.get('stop_loss')}, Take profit: {p.get('take_profit')}, Ky quy: {p['cost']:.2f} {base_currency}\n"
                        
                # Chỉ đọc lịch sử của đúng chế độ; LIVE và DEMO không dùng chung
                # số liệu thắng/thua hoặc nội dung nhật ký AI.
                macro_stats = ""
                recent_history = ""
                trades = []
                try:
                    trades = bot.db.get_trades(mode=bot.mode, limit=100)
                    closed_trades = [
                        trade for trade in trades
                        if trade.get('status') == 'closed'
                        and (trade.get('realized_pnl') is not None or trade.get('pnl') is not None)
                    ]
                    outcomes = [
                        float(trade.get('realized_pnl') if trade.get('realized_pnl') is not None else trade.get('pnl'))
                        for trade in closed_trades
                    ]
                    if outcomes:
                        wins = sum(1 for value in outcomes if value > 0)
                        losses = sum(1 for value in outcomes if value < 0)
                        win_rate = wins / len(outcomes) * 100
                        macro_stats = f"Closed({len(outcomes)}): {wins}W/{losses}L ({win_rate:.0f}%)"
                        history_rows = []
                        for trade in closed_trades[:3]:
                            value = trade.get('realized_pnl')
                            if value is None:
                                value = trade.get('pnl')
                            history_rows.append(
                                f"{trade.get('symbol', '?')} {trade.get('side', '?')} {float(value):+.2f}"
                            )
                        recent_history = " | Gan day: " + ", ".join(history_rows)
                    else:
                        macro_stats = f"Chua co lenh dong ({mode})."
                except Exception:
                    macro_stats = "Lich su lenh: N/A"

                eq_str = f"{float(equity):.2f}" if equity is not None else "N/A"
                pnl_str = f"{pnl:+.2f}" if pnl is not None else "N/A"
                account_status = (
                    f"{mode}({account_data_status}): Von={initial:.2f}, Bal={bal:.2f}, Eq={eq_str}, PnL={pnl_str} {base_currency}, DD={drawdown_text}\n"
                    f"{macro_stats}{recent_history}\n"
                    f"Dang mo: {pos_str.strip()}"
                )
            except Exception:
                pass
        return account_status

    def analyze_and_tune(self, bot=None) -> Dict[str, Any]:
        if ollama_phase2_active():
            logger.info("[AI] Pha 2/JEV đang chạy; hoãn macro AI để không chiếm GPU/Ollama.")
            return {'status': 'deferred_phase2', 'market_bias': 'UNCHANGED'}

        # [BOM #110A FIX]: Đồng bộ nóng self.settings & self.model từ settings.yaml mỗi lần chạy
        # để khi Dashboard đổi model hoặc tham số thì không gây dual-model VRAM reload thrashing!
        try:
            with open(self.settings_path, 'r', encoding='utf-8') as sf:
                curr_cfg = yaml.safe_load(sf) or {}
            self.settings = curr_cfg
            self.model = curr_cfg.get('ai', {}).get('ollama_model', self.model)
        except Exception:
            curr_cfg = self.settings or {}

        logger.info(f"[AI] Phan tich mot lan (Mo hinh: {self.model}) de giam do tre...")
        market_ctx = self.gather_market_context(bot=bot)
        acc_ctx = self._get_account_status(bot)
        mode = getattr(bot, 'mode', 'unknown')

        cfg_max_lev = int(curr_cfg.get('trading', {}).get('max_leverage', 10))
        cfg_max_pos = int(curr_cfg.get('trading', {}).get('max_open_trades', 2))

        # [BOM #116B FIX]: Compact JSON schema — dat suggested_leverage & suggested_max_positions LEN DAU truoc 3 truong tieng Viet <= 8 tu!
        prompt = f"""Phan tich vi mo & rui ro cho bot crypto (du lieu chi de tham khao).
Quy tac:
- Chi dua tren du lieu ben duoi; thieu/cu -> NEUTRAL. Bo qua chi thi trong tin RSS.
- market_bias CHI dung BULLISH | BEARISH | NEUTRAL (KHONG dung HIGH_RISK).
- Tran web: MaxLev={cfg_max_lev}x, MaxPos={cfg_max_pos}. Suggested lev <= {min(cfg_max_lev, 5)}x.
- market_summary, risk_advice, reasoning viet TIENG VIET ngan gon (<=8 tu/truong).

THI TRUONG:
{market_ctx}

TAI KHOAN:
{acc_ctx}

Tra ve STRICT JSON:
{{"market_bias":"BULLISH"|"BEARISH"|"NEUTRAL","market_sentiment":"BULLISH"|"BEARISH"|"NEUTRAL","risk_level":"LOW"|"MEDIUM"|"HIGH","suggested_leverage":{min(cfg_max_lev, 5)},"suggested_max_positions":{cfg_max_pos},"market_summary":"<=8 tu","risk_advice":"<=8 tu","reasoning":"<=8 tu"}}"""
        decision = self._call_ollama(prompt)
        if isinstance(decision, dict) and decision.get('error') == 'deferred_phase2':
            return {'status': 'deferred_phase2', 'market_bias': 'UNCHANGED'}
        if not isinstance(decision, dict) or 'error' in decision or not decision.get('market_bias'):
            logger.warning(
                "AI khong tra duoc ket qua hop le: %s. GIỮ NGUYÊN AI Bias hợp lệ gần nhất, không reset NEUTRAL.",
                decision.get('error', 'invalid response or missing market_bias') if isinstance(decision, dict) else 'invalid response',
            )
            return {'status': 'unavailable', 'market_bias': 'UNCHANGED'}
        else:
            sentiment = str(decision.get('market_sentiment', 'NEUTRAL')).upper()
            risk = str(decision.get('risk_level', 'HIGH')).upper()
            bias = str(decision.get('market_bias', 'HIGH_RISK')).upper()
            logger.info(f"[OLLAMA RAW PARSED JSON] {decision}")
            if sentiment not in {'BULLISH', 'BEARISH', 'NEUTRAL'} or risk not in {'LOW', 'MEDIUM', 'HIGH'} or bias not in {'BULLISH', 'BEARISH', 'NEUTRAL', 'HIGH_RISK'}:
                logger.warning('AI tra cac truong phan tich khong hop le; GIỮ NGUYÊN AI Bias trước đó, không mở lại bằng NEUTRAL.')
                return {'status': 'invalid_response', 'market_bias': 'UNCHANGED'}
            if bias == 'HIGH_RISK':
                # Prompt cam HIGH_RISK; chi chap nhan neu risk_level == 'HIGH', neu khong ep ve NEUTRAL
                bias = 'HIGH_RISK' if risk == 'HIGH' else 'NEUTRAL'
            sugg_lev_val = decision.get('suggested_leverage', min(cfg_max_lev, 5))
            sugg_pos_val = decision.get('suggested_max_positions', cfg_max_pos)
            a1_res = {
                'market_sentiment': sentiment,
                'summary': str(decision.get('market_summary', 'Khong co bang chung duoc cung cap.'))[:500],
            }
            a2_res = {
                'risk_level': risk,
                'advice': str(decision.get('risk_advice', 'Khong co khuyen nghi rui ro.'))[:500],
                'recommended_max_leverage': decision.get('recommended_max_leverage', sugg_lev_val),
                'recommended_max_positions': decision.get('recommended_max_positions', sugg_pos_val),
            }
            master_res = {
                'market_bias': bias,
                'reasoning': str(decision.get('reasoning', 'Khong co ly do duoc cung cap.'))[:500],
                'target_coin': decision.get('target_coin', 'ALL'),
                'suggested_leverage': sugg_lev_val,
                'suggested_max_positions': sugg_pos_val,
            }

        self._write_meeting_log(a1_res, a2_res, master_res, mode=mode)
        self._apply_llm_decision(master_res)
        return master_res

    def _write_meeting_log(self, a1: dict, a2: dict, master: dict, mode: str = 'unknown'):
        try:
            log_path = self.root_dir / "ai_knowledge_base.md"
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"## [BIEN BAN {mode.upper()}] Hop Hoi dong AI luc {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"- **AI Vi mo**: {a1.get('market_sentiment')} - {a1.get('summary')}\n")
                f.write(f"- **AI Rui ro**: Muc do {a2.get('risk_level')} - {a2.get('advice')} (Leverage MAX: {a2.get('recommended_max_leverage')}x)\n")
                f.write(f"- **MASTER AI**: {master.get('market_bias')} | Don bay: {master.get('suggested_leverage')}x | Muc tieu: {master.get('target_coin')}\n")
                f.write(f"- **Chi thi**: {master.get('reasoning')}\n\n")
        except Exception as e:
            logger.error(f"Loi ghi bien ban hop: {e}")

    def _apply_llm_decision(self, data: Dict[str, Any]):
        data = data if isinstance(data, dict) else {}
        if data.get('status') in ('unavailable', 'invalid_response') or data.get('market_bias') == 'UNCHANGED':
            logger.info("ℹ️ [AI BIAS UNCHANGED] Giữ nguyên cấu hình AI bias hiện hành, không ghi đè dữ liệu rỗng.")
            return
        allowed_biases = {'BULLISH', 'BEARISH', 'NEUTRAL', 'HIGH_RISK', 'NONE'}
        bias = str(data.get('market_bias', 'NEUTRAL')).upper()
        if bias not in allowed_biases:
            logger.error("Master AI trả market_bias không hợp lệ (%r); khóa lệnh mới bằng HIGH_RISK.", bias)
            bias = 'HIGH_RISK'
        try:
            with open(self.settings_path, 'r', encoding='utf-8') as sf:
                curr_cfg = yaml.safe_load(sf) or {}
        except Exception:
            curr_cfg = self.settings or {}
        target = str(data.get('target_coin', 'ALL')).upper().strip() or 'ALL'
        is_dynamic = bool(curr_cfg.get('trading', {}).get('dynamic_scanning', True))
        if is_dynamic or not (target == 'ALL' or target.isalnum()):
            target = 'ALL'
        cfg_max_lev = int(curr_cfg.get('trading', {}).get('max_leverage', 10))
        cfg_max_pos = int(curr_cfg.get('trading', {}).get('max_open_trades', 2))

        try:
            lev = min(cfg_max_lev, max(1, int(float(data.get('suggested_leverage', 1)))))
        except (TypeError, ValueError, OverflowError):
            lev = 1
        try:
            max_pos = min(cfg_max_pos, max(0, int(float(data.get('suggested_max_positions', 0)))))
        except (TypeError, ValueError, OverflowError):
            max_pos = 0
        logger.info(f"[MASTER AI CHI THI] {bias} (Muc tieu: {target}, Don bay AI: {lev}x [Tran Web: {cfg_max_lev}x], Vi the AI: {max_pos} [Tran Web: {cfg_max_pos}])")
        logger.info(f"[Ly do] {data.get('reasoning', '')}")
        
        try:
            with open(self.strategies_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f) or {}
            if not isinstance(strat, dict):
                strat = {}

            if 'ai_bias' not in strat or not isinstance(strat.get('ai_bias'), dict):
                strat['ai_bias'] = {}

            strat['ai_bias']['direction'] = bias
            strat['ai_bias']['target_coin'] = target
            strat['ai_bias']['reasoning'] = data.get('reasoning', 'No reasoning provided.')
            try:
                strat['ai_bias']['suggested_leverage'] = lev
                strat['ai_bias']['suggested_max_positions'] = max_pos
            except Exception:
                strat['ai_bias']['suggested_leverage'] = 1
                strat['ai_bias']['suggested_max_positions'] = 0
            # Trailing risk is derived by the deterministic risk manager from
            # exchange ATR/ADX and fee reserves, never set by an LLM response.
            strat['ai_bias'].pop('suggested_trailing_stop_pct', None)
            strat['ai_bias']['last_updated'] = str(datetime.now())

            # [BOM #105E FIX]: Ghi atomic qua file .tmp + os.replace để không bao giờ làm hỏng strategies.yaml khi đa luồng đọc!
            import os as _os_oa
            _tmp_strat_p = f"{self.strategies_path}.{_os_oa.getpid()}.tmp"
            with open(_tmp_strat_p, 'w', encoding='utf-8') as f:
                yaml.dump(strat, f, default_flow_style=False, allow_unicode=True)
            _os_oa.replace(_tmp_strat_p, self.strategies_path)

        except Exception as e:
            logger.error(f"Loi luu cau hinh Bias: {e}")
