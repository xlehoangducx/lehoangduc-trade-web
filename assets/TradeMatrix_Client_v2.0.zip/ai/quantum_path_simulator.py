"""

Quantum-Inspired Dual-Engine Path Simulator for Algorithmic Trade Validation (v2.0).



Kiến trúc Lượng tử Kép (Dual-Engine Quantum Matrix):

1. NHÁNH CRYPTO PERPETUALS:

   - Mô phỏng Quantum Random Walk 2.500 đường đi giá trong 40 nến tương lai (Hệ quy chiếu Thuận chiều Lệnh).

   - Vướng víu Lượng tử với Bitcoin (BTC Quantum Entanglement Coupling): Phản xạ ngoại lực BTC lên Altcoin chuẩn dấu cho cả LONG và SHORT.

   - Bất đối xứng Thanh khoản & Squeeze (Funding Rate Skew & Liquidity Jump): Mô phỏng rủi ro Short Squeeze / Long Flush.

   - Phễu Biến động Nở rộng (Dynamic Volatility Expansion): Nở rộng ATR khi bứt phá xu hướng.



2. NHÁNH CHỨNG KHOÁN MỸ & ETF TRADFI (223 mã trên Binance):

   - Nhận diện tự động mã Cổ phiếu / ETF Mỹ (NVDA, TSLA, SOXL, SOXS, SNDK...).

   - Bào mòn Toán học Đòn bẩy Đảo chiều (Leveraged ETF Volatility Drag): Trừ hệ số suy giảm cơ học

     khi thị trường sideway (đặc trị bẫy thua lỗ SOXS).

   - Hệ số Phiên Wall Street (Off-Hours Liquidity & Spread Penalty): Phạt râu nến ảo ngoài giờ 20:30 - 03:00 VN.

   - Mô phỏng Nhảy Gap Qua Đêm & Cuối Tuần (Overnight & Weekend Gap Jump Risk).



Đo lường đầu ra:

- P(Win): Xác suất chạm Take-Profit trước khi chạm Stop-Loss.

- P(Loss): Xác suất chạm Stop-Loss trước (hoặc cùng bước nến) khi chạm Take-Profit.

- P(DOA): Xác suất ứ đọng vốn không chạm cả hai (Dead-on-Arrival / Capital Stagnation).

- E[EV]: Kỳ vọng lợi nhuận thuần túy sau phí sàn 2 đầu.

- Leverage Multiplier: Đề xuất đòn bẩy động dựa trên độ chắc chắn lượng tử.

"""



import glob
import math
import os
import threading
import time
import zlib
from typing import Dict, Any, Optional, List
import numpy as np

_RMT_LOCK = threading.Lock()
_RMT_CACHE: Dict[str, Any] = {"ts": 0.0, "data": None}



try:

    from core.scanner import MarketScanner

except ImportError:

    MarketScanner = None





def _safe_float(val: Any, default: float = 0.0) -> float:

    """Chuyển đổi float an toàn, chống NaN / Inf."""

    try:

        f = float(val)

        return f if math.isfinite(f) else default

    except (TypeError, ValueError):

        return default





class QuantumPathSimulator:

    """Quantum-Inspired Monte Carlo & Quantum Walk Path Simulator for High-Frequency Pre-Trade Validation (Dual-Engine v2.0)."""



    KNOWN_INVERSE_ETFS = {"SOXS", "SQQQ", "SPXU", "SDOW", "YANG", "KOLD", "DUST", "FAZ", "TECS", "LABD"}

    KNOWN_BULL_ETFS = {

        "SOXL", "TQQQ", "UPRO", "UDOW", "YINN", "BOIL", "NUGT", "FAS", "TECL", "LABU",

        "NVDL", "TSLL", "MSTU", "MSTX", "CONL", "KORU",

    }



    def __init__(

        self,

        n_paths: int = 2500,

        n_steps: int = 40,

        min_win_prob: float = 0.0,

        max_doa_prob: float = 0.40,

        min_ev_pct: float = 0.0,

        edge_margin: float = 0.10,

    ):

        """

        Args:

            n_paths: Số lượng đường đi mô phỏng đồng thời (vectorized qua NumPy).

            n_steps: Số nến dự phóng tương lai (40 nến 15m ~ 10 giờ tác chiến).

            min_win_prob: Sàn cứng P(Win) tối thiểu (0.0 = tắt; cổng chính dùng EV).

            max_doa_prob: Ngưỡng rủi ro ứ đọng vốn tối đa cho phép (40%).

            min_ev_pct: Kỳ vọng lợi nhuận thuần tối thiểu (tỷ lệ, 0.0 = phải dương sau phí).

            edge_margin: Biên lợi thế yêu cầu so với điểm hòa vốn (0.10 = +10%).

        """

        self.n_paths = int(n_paths)

        self.n_steps = int(n_steps)

        self.min_win_prob = float(min_win_prob)

        self.max_doa_prob = float(max_doa_prob)

        raw_min_ev = float(min_ev_pct)

        # [BÀI HỌC 102]: Khắc phục điểm biên >= 0.05 không bị ép nhầm thành 5%
        if raw_min_ev > 1.0:
            self.min_ev_pct = raw_min_ev / 100.0
        elif raw_min_ev >= 0.05:
            self.min_ev_pct = raw_min_ev / 100.0
        else:
            self.min_ev_pct = raw_min_ev

        self.edge_margin = max(0.0, float(edge_margin))



    @classmethod

    def classify_asset(cls, symbol: str, exchange=None) -> str:

        """Phân loại tài sản: TRADFI_LEVERAGED_ETF, TRADFI_STOCK, TRADFI_COMMODITY, CRYPTO_MAJOR, hoặc CRYPTO_PERPETUAL."""

        if not symbol:

            return "CRYPTO_PERPETUAL"

        clean = str(symbol).split(":")[0].upper().replace("/", "")

        base = clean

        for quote in ("USDT", "USDC", "BUSD", "USD"):

            if base.endswith(quote) and len(base) > len(quote):

                base = base[: -len(quote)]

                break



        # Ưu tiên metadata sàn (underlyingType == 'COIN') trước danh mục tĩnh để tránh Crypto trùng mã TradFi (ON/USDT, DIA/USDT)
        if MarketScanner is not None and hasattr(MarketScanner, "_find_market_entry"):
            try:
                _clean_m_q = str(symbol).split(":")[0].upper()
                _m_q = MarketScanner._find_market_entry(symbol, _clean_m_q, base, exchange=exchange)
                if _m_q:
                    _info_q = _m_q.get("info") or {}
                    _ut_q = str(_info_q.get("underlyingType") or "").upper()
                    _sub_q = [str(x).upper() for x in (_info_q.get("underlyingSubType") or [])]
                    _ct_q = str(_info_q.get("contractType") or "").upper()
                    if (
                        _ut_q == "COIN"
                        and "TRADFI" not in _sub_q
                        and "COMMODITY" not in _sub_q
                        and _ct_q != "TRADIFI_PERPETUAL"
                        and base not in ("PAXG",)
                        and base not in cls.KNOWN_INVERSE_ETFS
                        and base not in cls.KNOWN_BULL_ETFS
                    ):
                        if base in ("BTC", "ETH", "SOL", "BNB", "XRP"):
                            return "CRYPTO_MAJOR"
                        return "CRYPTO_PERPETUAL"
            except Exception:
                pass

        if base in cls.KNOWN_INVERSE_ETFS or base in cls.KNOWN_BULL_ETFS:

            return "TRADFI_LEVERAGED_ETF"



        if MarketScanner is not None and hasattr(MarketScanner, "is_tradfi_commodity"):

            try:

                if MarketScanner.is_tradfi_commodity(symbol, exchange):

                    return "TRADFI_COMMODITY"

            except Exception:

                pass



        if MarketScanner is not None and hasattr(MarketScanner, "is_tradfi_stock"):

            try:

                if MarketScanner.is_tradfi_stock(symbol, exchange):

                    return "TRADFI_STOCK"

            except Exception:

                pass



        if MarketScanner is not None and hasattr(MarketScanner, "KNOWN_TRADFI_BASES"):

            if base in MarketScanner.KNOWN_TRADFI_BASES and (not hasattr(MarketScanner, 'KNOWN_COMMODITY_BASES') or base not in MarketScanner.KNOWN_COMMODITY_BASES):

                return "TRADFI_STOCK"



        known_stocks = {

            "NVDA", "TSLA", "AAPL", "MSFT", "AMZN", "GOOGL", "SNDK",

            "AMD", "PLTR", "COIN", "MSTR", "INTC", "META", "NFLX", "BABA",

            "MU", "SNXX", "MRVL", "SKHY", "CRWD", "ARM", "DELL",

        }

        if base in known_stocks:

            return "TRADFI_STOCK"



        if base in ("BTC", "ETH", "SOL", "BNB", "XRP"):

            return "CRYPTO_MAJOR"



        return "CRYPTO_PERPETUAL"



    def _classify_asset(self, symbol: str, exchange=None) -> str:

        return self.classify_asset(symbol, exchange)



    @staticmethod

    def _analytical_barrier_first_passage(mu: float, sigma: float, sl_dist: float, tp_dist: float) -> float:

        """

        [BÀI HỌC 98 - NGHIỆM ĐÓNG BLACK-SCHOLES DOUBLE-BARRIER FIRST PASSAGE TIME]

        Giải tích chính xác xác suất P(T_TP < T_SL) cho vi phân ngẫu nhiên dX_t = mu*dt + sigma*dW_t.

        Triệt tiêu hoàn toàn sai số mẫu ngẫu nhiên (sampling variance) của Monte Carlo trên các tài sản biến động cao.

        """

        if abs(mu) < 1e-7:

            return sl_dist / (tp_dist + sl_dist) if (tp_dist + sl_dist) > 0 else 0.5

        gamma = 2.0 * mu / (sigma ** 2) if sigma > 1e-6 else 0.0

        gamma = float(np.clip(gamma, -35.0, 35.0))

        num = 1.0 - math.exp(-gamma * sl_dist)

        den = 1.0 - math.exp(-gamma * (tp_dist + sl_dist))

        if abs(den) < 1e-9:

            return sl_dist / (tp_dist + sl_dist) if (tp_dist + sl_dist) > 0 else 0.5

        return float(np.clip(num / den, 0.01, 0.99))



    @staticmethod

    def _calculate_delta(mu: float, sigma: float, n_steps: int = 40) -> float:

        """

        [BÀI HỌC 98 - HỆ SỐ DELTA N(d1) ĐỊNH GIÁ QUYỀN CHỌN ĐỘNG LƯỢNG]

        Tính độ nhạy Delta N(d1) của vị thế (xác suất động lượng tiến sâu vào vùng In-The-Money).

        Dùng để định quy mô vốn động (Dynamic Delta Sizing Multiplier).

        """

        # [BOM #95F FIX]: mu la drift tren moi buoc 15m (cung don vi voi sigma * sqrt(n_steps)),
        # nen tong drift la mu * n_steps, KHONG phai mu * (n_steps * 15/1440) (nho hon 96x!).
        total_drift = mu * max(1, int(n_steps))

        vol = max(1e-5, sigma * math.sqrt(max(1, int(n_steps))))

        d1 = (total_drift + 0.5 * (vol ** 2)) / vol

        return float(0.5 * (1.0 + math.erf(d1 / math.sqrt(2.0))))

    @staticmethod
    def _extract_closed_15m_closes(meta: Optional[Dict[str, Any]]) -> Optional[np.ndarray]:
        """Trích xuất mảng giá đóng cửa 15M đã đóng (bỏ nến đang hình thành)."""
        if not isinstance(meta, dict):
            return None
        dfs = meta.get("dfs")
        if not isinstance(dfs, dict):
            return None
        df_15m = dfs.get("15m")
        if df_15m is None:
            return None
        try:
            if hasattr(df_15m, "empty") and df_15m.empty:
                return None
            if hasattr(df_15m, "columns") and "close" in df_15m.columns:
                ser = df_15m["close"].iloc[:-1] if len(df_15m) >= 2 else df_15m["close"]
                arr = np.asarray(ser, dtype=float)
            elif isinstance(df_15m, dict) and "close" in df_15m:
                raw = df_15m["close"]
                arr = np.asarray(raw[:-1] if len(raw) >= 2 else raw, dtype=float)
            else:
                return None
            arr = arr[np.isfinite(arr) & (arr > 0)]
            return arr if len(arr) >= 15 else None
        except Exception:
            return None

    @staticmethod
    def _compute_hurst_rs(closes: Optional[np.ndarray]) -> tuple:
        """
        [BOM #111C - M3 MANDELBROT HURST EXPONENT H (R/S MEMORY)]:
        Tính chỉ số Hurst trên log-returns 15M đã đóng (0 look-ahead):
        - H >= 0.48: Đủ độ bền xu hướng cho vũ khí Thuận Đà (VK1/VK5/VK8).
        - H <= 0.60: Tránh cản tàu xu hướng Parabol bền vững khi đánh Đảo Chiều (VK4/VK6/VK7/VK9).
        Fail-open (0.50, False) nếu thiếu tối thiểu 25 nến đóng.
        """
        if closes is None or len(closes) < 25:
            return 0.50, False
        rets = np.diff(np.log(np.maximum(closes, 1e-12)))
        rets = rets[np.isfinite(rets)]
        if len(rets) < 24:
            return 0.50, False
        rs_pts = []
        for sub_n in (8, 16, 24, 32):
            if len(rets) >= sub_n:
                seg = rets[-sub_n:]
                dev = np.cumsum(seg - np.mean(seg))
                rng = float(np.max(dev) - np.min(dev))
                sd = float(np.std(seg, ddof=1))
                if sd > 1e-12 and rng > 0.0:
                    rs_pts.append((math.log(sub_n), math.log(rng / sd)))
        if len(rs_pts) < 2:
            return 0.50, False
        xs = np.array([p[0] for p in rs_pts], dtype=float)
        ys = np.array([p[1] for p in rs_pts], dtype=float)
        try:
            hurst = float(np.polyfit(xs, ys, 1)[0])
            if not math.isfinite(hurst):
                return 0.50, False
            return float(np.clip(hurst, 0.05, 0.95)), True
        except Exception:
            return 0.50, False

    @staticmethod
    def _compute_empirical_fpt(
        closes: Optional[np.ndarray],
        is_buy: bool,
        tp_dist: float,
        sl_dist: float,
    ) -> tuple:
        """
        [BOM #111C - M7 EMPIRICAL DRIFT-DIFFUSION FIRST-PASSAGE TIME]:
        Nghiệm đóng Martingale xác suất chạm rào +a_tp (TP1) trước -b_sl dựa trên
        mu & sigma thực nghiệm 14 nến 15M đã đóng (0.04ms, 0 look-ahead).
        """
        if closes is None or len(closes) < 15:
            return None, False
        rets = np.diff(np.log(np.maximum(closes, 1e-12)))
        rets = rets[np.isfinite(rets)]
        if len(rets) < 14:
            return None, False
        r14 = rets[-14:]
        mu_est = float(np.mean(r14))
        sig_est = max(1e-4, float(np.std(r14)))
        drift_dir = mu_est if is_buy else -mu_est
        lam = (2.0 * drift_dir) / (sig_est ** 2)
        a_tp = max(0.005, float(tp_dist))
        b_sl = max(0.008, float(sl_dist))
        try:
            if abs(lam * (a_tp + b_sl)) < 1e-4:
                p_fpt = b_sl / (a_tp + b_sl)
            else:
                e_b = math.exp(max(-20.0, min(20.0, lam * b_sl)))
                e_ma = math.exp(max(-20.0, min(20.0, -lam * a_tp)))
                denom = e_b - e_ma
                if abs(denom) < 1e-12:
                    p_fpt = b_sl / (a_tp + b_sl)
                else:
                    p_fpt = (e_b - 1.0) / denom
            if not math.isfinite(p_fpt):
                return None, False
            return float(np.clip(p_fpt, 0.0, 1.0)), True
        except Exception:
            return None, False

    @classmethod
    def compute_crypto_rmt_coherence(
        cls,
        hist_dir: Optional[str] = None,
        cache_ttl_sec: float = 900.0,
    ) -> Dict[str, Any]:
        """
        [BOM #111C - M1 RIEMANN / RMT MARCHENKO-PASTUR CRYPTO COHERENCE]:
        Đo độ đồng pha thị trường Crypto qua ma trận tương quan 15M đọc thuần CSV local (0 REST calls, cache 15m):
        - Dùng abs_ratio = lmax / N và mp_excess = (lmax - lp) / (N - lp) bất biến theo số lượng mã tươi N.
        - Khối nhiễu thuần Marchenko-Pastur (mp_excess <= 0.0): thị trường phân mảnh nhiễu -> VETO + giảm size 0.70x.
        - Phân mảnh thấp (mp_excess < 0.25 hoặc abs_ratio < 0.40): cho phép chọn lọc, giảm size 0.80x.
        - Đồng pha chuẩn (mp_excess >= 0.25 và abs_ratio >= 0.40): 1.00x bình thường.
        Fail-open hoàn toàn nếu thiếu >= 6 CSV tươi trong 60 phút gần nhất.
        """
        now_m = time.monotonic()
        with _RMT_LOCK:
            cached = _RMT_CACHE.get("data")
            if cached is not None and (now_m - float(_RMT_CACHE.get("ts") or 0.0)) < cache_ttl_sec:
                return dict(cached)

        res: Dict[str, Any] = {
            "available": False,
            "n_coins": 0,
            "t_bars": 0,
            "lmax": 0.0,
            "lambda_plus": 0.0,
            "lmax_ratio": 0.0,
            "abs_ratio": 0.0,
            "mp_excess": 0.0,
            "fragmented_veto": False,
            "rmt_sizing_mult": 1.00,
            "regime_tag": "RMT_UNAVAILABLE",
        }
        try:
            import pandas as pd
            if not hist_dir:
                hist_dir = os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "data",
                    "historical",
                )
            if not os.path.isdir(hist_dir):
                return res
            ref_bases = [
                "BTC_USDT", "ETH_USDT", "SOL_USDT", "BNB_USDT",
                "XRP_USDT", "DOGE_USDT", "ADA_USDT", "LINK_USDT",
                "AVAX_USDT", "SUI_USDT", "NEAR_USDT", "LTC_USDT",
            ]
            now_wall = time.time()
            series_map: Dict[str, Any] = {}
            for base_s in ref_bases:
                matches = sorted(glob.glob(os.path.join(hist_dir, f"{base_s}*_15m.csv")))
                if not matches:
                    continue
                fp = matches[0]
                try:
                    if (now_wall - os.path.getmtime(fp)) > 3600.0:
                        continue
                    hdr_cols = pd.read_csv(fp, nrows=0).columns
                    ts_col = "timestamp" if "timestamp" in hdr_cols else ("datetime" if "datetime" in hdr_cols else None)
                    if not ts_col or "close" not in hdr_cols:
                        continue
                    df_c = pd.read_csv(fp, usecols=[ts_col, "close"]).tail(60)
                    if len(df_c) >= 30:
                        ser = df_c.set_index(ts_col)["close"].astype(float)
                        ser = ser[~ser.index.duplicated(keep="last")]
                        series_map[base_s] = ser
                except Exception:
                    continue
            if len(series_map) >= 6:
                aligned = pd.DataFrame(series_map).dropna().tail(37)
                if len(aligned) >= 25:
                    vals = aligned.values.astype(float)
                    lr = np.diff(np.log(np.maximum(vals, 1e-12)), axis=0)
                    sd = lr.std(axis=0)
                    good = np.isfinite(sd) & (sd > 1e-12)
                    lr = lr[:, good]
                    if lr.shape[1] >= 6 and lr.shape[0] >= 24:
                        z = (lr - lr.mean(axis=0)) / lr.std(axis=0)
                        t_bars, n_coins = z.shape
                        corr = (z.T @ z) / float(t_bars)
                        eigs = np.sort(np.linalg.eigvalsh(corr))
                        lp = (1.0 + math.sqrt(float(n_coins) / float(t_bars))) ** 2
                        lmax = float(eigs[-1])
                        lmax_ratio = lmax / max(1e-6, lp)
                        abs_ratio = lmax / float(n_coins)
                        mp_excess = (lmax - lp) / max(1e-6, float(n_coins) - lp)
                        if mp_excess <= 0.0:
                            frag_veto = True
                            rmt_mult = 0.70
                            tag = "RMT_NOISE_BULK"
                        elif mp_excess < 0.25 or abs_ratio < 0.40:
                            frag_veto = False
                            rmt_mult = 0.80
                            tag = "RMT_FRAGMENTED"
                        else:
                            frag_veto = False
                            rmt_mult = 1.00
                            tag = "RMT_COHERENT"
                        res.update({
                            "available": True,
                            "n_coins": int(n_coins),
                            "t_bars": int(t_bars),
                            "lmax": round(lmax, 4),
                            "lambda_plus": round(lp, 4),
                            "lmax_ratio": round(lmax_ratio, 4),
                            "abs_ratio": round(abs_ratio, 4),
                            "mp_excess": round(mp_excess, 4),
                            "fragmented_veto": frag_veto,
                            "rmt_sizing_mult": rmt_mult,
                            "regime_tag": tag,
                        })
        except Exception:
            pass

        with _RMT_LOCK:
            _RMT_CACHE["ts"] = time.monotonic()
            _RMT_CACHE["data"] = dict(res)
        return res



    def simulate(

        self,

        symbol: str,

        side: str,

        entry_price: float,

        stop_loss: float,

        take_profit: float,

        atr_pct: float,

        adx: float = 30.0,

        score: float = 0.70,

        regime: str = "uptrend",

        fee_rate: float = 0.0005,

        btc_bias: str = "NEUTRAL",

        funding_rate: float = 0.0,

        is_us_open: Optional[bool] = None,

        is_weekend_gap: Optional[bool] = None,

        jev_verdict: Optional[str] = None,

        jev_risk: Optional[str] = None,

        jev_reason: Optional[str] = None,

        exchange: Any = None,

        metadata: Optional[Dict[str, Any]] = None,

    ) -> Dict[str, Any]:

        """Chạy mô phỏng lượng tử đường đi giá trong tương lai với kiến trúc Dual-Engine.



        Toàn bộ phép toán dịch chuyển được chuẩn hóa trên Hệ Quy Chiếu Thuận Chiều Lệnh (Trade-Relative Frame):

        - Chiều dương (+): Giá đi về phía Take-Profit (có lợi cho vị thế, bất kể LONG hay SHORT).

        - Chiều âm (-): Giá đi về phía Stop-Loss (bất lợi cho vị thế).

        """

        t0 = time.perf_counter()



        entry_price = _safe_float(entry_price, 0.0)

        if entry_price <= 0:

            return {

                "symbol": symbol,

                "side": side,

                "asset_class": "UNKNOWN",

                "p_win": 0.0,

                "p_loss": 1.0,

                "p_doa": 0.0,

                "expected_ev_pct": -100.0,

                "reward_risk_ratio": 0.0,

                "pass_gate": False,

                "confidence_tier": "QUANTUM_VETO",

                "leverage_multiplier": 0.0,

                "veto_reasons": ["LỖI_GIÁ_VÀO_KHÔNG_HỢP_LỆ"],

                "time_taken_ms": 0.0,

                "paths_simulated": self.n_paths,

            }



        is_buy = str(side).upper() in ("BUY", "LONG")

        default_sl = entry_price * (0.97 if is_buy else 1.03)

        default_tp = entry_price * (1.06 if is_buy else 0.94)



        stop_loss = _safe_float(stop_loss, default_sl)

        if stop_loss <= 0:

            stop_loss = default_sl

        take_profit = _safe_float(take_profit, default_tp)

        if take_profit <= 0:

            take_profit = default_tp



        atr_pct = _safe_float(atr_pct, 2.5)

        if atr_pct <= 0:

            atr_pct = 2.5

        adx = _safe_float(adx, 25.0)

        if adx <= 0:

            adx = 25.0

        # Độ tự tin (confidence) luôn chuẩn hóa dương trong hệ quy chiếu thuận chiều lệnh

        confidence = abs(_safe_float(score, 0.70))

        fee_rate = max(0.0, _safe_float(fee_rate, 0.0005))

        funding_rate = _safe_float(funding_rate, 0.0)



        asset_class = self._classify_asset(symbol, exchange)

        clean_base = str(symbol).split(":")[0].upper().replace("/", "")

        for q_suffix in ("USDT", "USDC", "BUSD", "USD"):

            if clean_base.endswith(q_suffix) and len(clean_base) > len(q_suffix):

                clean_base = clean_base[: -len(q_suffix)]

                break



        # Khoảng cách tương đối (%) đến TP và SL — [BOM #95F FIX]: Chan SL/TP dao nguoc thay vi clamp 0.2% tao R:R ao!
        if is_buy:
            raw_tp_dist = (take_profit - entry_price) / entry_price
            raw_sl_dist = (entry_price - stop_loss) / entry_price
        else:
            raw_tp_dist = (entry_price - take_profit) / entry_price
            raw_sl_dist = (stop_loss - entry_price) / entry_price

        if raw_tp_dist <= 0 or raw_sl_dist <= 0:
            return {
                "symbol": symbol,
                "side": side,
                "asset_class": asset_class,
                "p_win": 0.0,
                "p_loss": 1.0,
                "p_doa": 0.0,
                "expected_ev_pct": -100.0,
                "reward_risk_ratio": 0.0,
                "pass_gate": False,
                "confidence_tier": "QUANTUM_VETO",
                "leverage_multiplier": 0.0,
                "veto_reasons": ["LỖI_SL_TP_ĐẢO_NGƯỢC_CHIỀU"],
                "time_taken_ms": 0.0,
                "paths_simulated": self.n_paths,
            }

        tp_dist = max(0.002, raw_tp_dist)
        sl_dist = max(0.002, raw_sl_dist)

        # 1. THIẾT LẬP PHA LƯỢNG TỬ (QUANTUM PHASE ANGLE θ TRONG HỆ QUY CHIẾU THUẬN CHIỀU LỆNH)
        # θ > pi/4: Giao thoa tăng cường về phía Take-Profit
        # θ < pi/4: Giao thoa triệt tiêu về phía Stop-Loss
        adx_factor = float(np.clip(adx / 35.0, 0.4, 2.0))
        theta = (math.pi / 4.0) + (confidence * 0.28 * min(1.5, adx_factor))

        # [BÀI HỌC 107 - WHALE CLIMAX EARLY DETECTION]:
        # Nhận diện sớm các cấu trúc Cá Mập xả đỉnh/bắt đáy kiệt sức trước khi tính toán góc pha và drift
        _md = metadata if isinstance(metadata, dict) else {}
        _u_wick = _safe_float(_md.get('c_upper_wick_pct', 0.0) or _md.get('c_upper_wick_ratio', 0.0), 0.0)
        _l_wick = _safe_float(_md.get('c_lower_wick_pct', 0.0) or _md.get('c_lower_wick_ratio', 0.0), 0.0)
        _pump_pct = _safe_float(_md.get('c_recent_pump_pct', 0.0), 0.0)
        _dump_pct = _safe_float(_md.get('c_recent_dump_pct', 0.0), 0.0)
        _vol_ratio = _safe_float(_md.get('c_vol_ratio', 1.0), 1.0)

        # [BOM #95F + #116E FIX]: Bo 'DIA' khoi danh sach ep TradFi vi DIA/USDT la token Crypto; truyen exchange vao is_tradfi_symbol
        _TRADFI_EXACT_BASES = {
            'NVDA', 'NVDAB', 'TSLA', 'TSLAB', 'AAPL', 'AAPLB', 'MSTR', 'MSTRB', 'SOXL', 'SOXLB', 'SOXS',
            'TQQQ', 'SQQQ', 'UPRO', 'SPXU', 'XAU', 'XAG', 'XPT', 'XPD', 'CL', 'BZ', 'NG', 'HG',
            'QQQ', 'SPY', 'IWM', 'USO', 'GLD', 'SLV', 'AMZN', 'MSFT', 'GOOGL', 'META', 'NFLX',
            'AMD', 'AVGO', 'INTC', 'ARM', 'MU', 'QCOM', 'COIN', 'PLTR', 'BABA',
        }
        _is_scanner_tradfi = False
        try:
            from core.scanner import MarketScanner as _MS_Q
            _is_scanner_tradfi = bool(_MS_Q.is_tradfi_symbol(symbol, exchange))
        except Exception:
            _is_scanner_tradfi = False
        _is_tradfi = str(asset_class).startswith("TRADFI") or _is_scanner_tradfi or (str(clean_base) in _TRADFI_EXACT_BASES and not str(asset_class).startswith("CRYPTO"))
        # [BOM #106C FIX]: Đồng bộ 100% Sàn Climax KB10 (Rule 0.9 #17: TradFi 0.5%, Altcoin/Major 0.7%)
        # và Sàn RVol 3 Lớp (Rule 0.9 #22: TradFi 0.85x, Major 1.00x, Altcoin 1.10x) giữa Trạm 3 (Aggregator) & Trạm 4 (Quantum Gate)!
        _pump_thresh = 0.005 if _is_tradfi else 0.007
        _dump_thresh = 0.005 if _is_tradfi else 0.007
        _climax_rvol_req = 0.85 if _is_tradfi else (1.00 if asset_class == "CRYPTO_MAJOR" else 1.10)

        _is_vk2_sig = bool(_md.get('is_parabolic_long_alpha2')) or str(_md.get('weapon_code') or '') == 'VK2' or str(_md.get('type', '')).upper() == 'PARABOLIC_LONG_INVERSION_ALPHA2'
        _is_vk9_sig = bool(_md.get('is_vk9_climax_wick_short')) or str(_md.get('type', '')).upper() == 'VK9_CLIMAX_WICK_SHORT'
        _is_vk10_sig = bool(_md.get('is_vk10_tradfi_bottom_long')) or str(_md.get('type', '')).upper() == 'VK10_TRADFI_BOTTOM_WICK_LONG'
        _is_dyn_sig = bool(_md.get('is_dynamic_weapon'))
        _dyn_arch = str(_md.get('quantum_archetype') or '').upper()
        if _is_dyn_sig and _dyn_arch == 'TRADFI_BOTTOM':
            _is_vk10_sig = True
        elif _is_dyn_sig and _dyn_arch == 'CLIMAX_REVERSAL' and (not is_buy):
            _is_vk9_sig = True

        # [V6.1 BOM #58 & BOM #95F FIX]: Khop 100% 4 quantum_archetype thuc te ('OVERSOLD_BOUNCE', 'CLIMAX_REVERSAL', 'TREND_MOMENTUM', 'TRADFI_BOTTOM')!
        _is_dyn_climax_buy = (
            _is_dyn_sig and is_buy and (
                _dyn_arch in ('TREND_MOMENTUM', 'MOMENTUM_BREAKOUT')
                or (_dyn_arch in ('CLIMAX_REVERSAL', 'OVERSOLD_BOUNCE') and (_l_wick >= 0.25 or _vol_ratio >= 1.10))
                or (_dyn_arch == 'TRADFI_BOTTOM' and _is_tradfi and _l_wick >= 0.35 and _vol_ratio >= 0.85)
            )
        )
        _is_dyn_climax_sell = (
            _is_dyn_sig and (not is_buy) and (
                _dyn_arch in ('TREND_MOMENTUM', 'MOMENTUM_BREAKOUT')
                or (_dyn_arch in ('CLIMAX_REVERSAL', 'OVERSOLD_BOUNCE') and (_u_wick >= 0.35 or _vol_ratio >= 1.10))
            )
        )

        has_verified_physical_climax = (
            (_l_wick >= 0.35 and (_dump_pct >= _dump_thresh or _vol_ratio >= _climax_rvol_req))
            or (bool(_md.get('is_oversold_bounce')) and (_l_wick >= 0.25 or _dump_pct >= _dump_thresh) and _vol_ratio >= _climax_rvol_req)
            or (_is_vk2_sig and _vol_ratio >= 1.10)
            or (_is_vk10_sig and _is_tradfi and _l_wick >= 0.38 and _vol_ratio >= 0.85)
            or _is_dyn_climax_buy
            or bool(_md.get('is_momentum_ride'))
            if is_buy
            else (_u_wick >= 0.35 and (_pump_pct >= _pump_thresh or _vol_ratio >= _climax_rvol_req))
            or (_is_vk9_sig and _u_wick >= 0.65 and _vol_ratio >= 1.33)
            or _is_dyn_climax_sell
            or bool(_md.get('is_waterfall_short'))
        )
        is_whale_climax = has_verified_physical_climax and (
            bool(_md.get('is_fading_short'))
            or bool(_md.get('is_oversold_bounce'))
            or bool(_md.get('is_waterfall_short'))
            or bool(_md.get('is_momentum_ride'))
            or _is_vk9_sig
            or _is_vk10_sig
            or _is_dyn_sig
            or str(_md.get('type', '')).upper() in (
                'EXHAUSTION_FADING_SELL', 'PARABOLIC_EXHAUSTION_SHORT',
                'PANIC_CLIMAX_BOUNCE',
                'VK9_CLIMAX_WICK_SHORT', 'VK10_TRADFI_BOTTOM_WICK_LONG', 'PARABOLIC_LONG_INVERSION_ALPHA2',
                'BULL_TRAP_PUMP', 'BULL_TRAP_WICK', 'BEAR_TRAP_WICK',
                'FADING_SHORT_PHASE2', 'WATERFALL_BREAKDOWN_SHORT',
                'OPENING_BELL_WATERFALL_INVERSION_SHORT', 'OPENING_BELL_MOMENTUM_INVERSION_BUY',
                'MOMENTUM_RIDE_INVERSION_PUMP_STORM', 'WATERFALL_INVERSION_DUMP_STORM',
                'SMART_DOWNTREND_INVERSION_SHORT_I2',
                'MOMENTUM_RIDE',
                'BAND_WALKING_RIDE_SHORT', 'BAND_WALKING_RIDE_BUY',
                'LIQUIDITY_SWEEP_FADING_SHORT', 'LIQUIDITY_SWEEP_BOUNCE_LONG',
                'TREND_EXHAUSTION_FADING_SHORT', 'TREND_EXHAUSTION_BOUNCE_LONG'
            )
        )



        # [BOM #19B FIX]: VK10 TradFi S13 bắt đáy rút chân (ADX <= 30, không phải ETF đảo chiều) là chiến lược đảo chiều vùng hỗ trợ,
        # ADX thấp-vừa (18-30) là điều kiện tối ưu chứ KHÔNG phải điểm yếu xu hướng như TrendFollowing.
        if _is_vk10_sig and is_whale_climax and is_buy and asset_class != "TRADFI_LEVERAGED_ETF":
            theta = (math.pi / 4.0) + (confidence * 0.28 * max(1.05, min(1.5, adx_factor)))

        veto_reasons: List[str] = []

        context_notes: List[str] = []

        favorable_drift_bias = 0.0



        # =========================================================================

        # A. NHÁNH CRYPTO: VƯỚNG VÍU BTC & LỆCH PHA FUNDING RATE

        # =========================================================================

        if asset_class in ("CRYPTO_PERPETUAL", "CRYPTO_MAJOR"):

            is_btc = "BTC" in clean_base

            if not is_btc and btc_bias:

                bias_upper = str(btc_bias).upper()

                if bias_upper == "BULLISH":

                    if is_buy:

                        theta += 0.08  # LONG Altcoin thuận nhịp BTC Bullish -> Tăng cường

                    else:

                        # Nếu là tín hiệu Smart Inversion / Buying Climax độ tự tin cao (>= 82%), giảm mức phạt ngược nhịp BTC
                        if is_whale_climax or confidence >= 0.82:

                            theta -= 0.04 if is_whale_climax else 0.08

                        else:

                            theta -= 0.16

                elif bias_upper == "BEARISH":

                    if not is_buy:

                        theta += 0.08  # SHORT Altcoin thuận nhịp BTC Bearish -> Tăng cường

                    else:

                        if is_whale_climax or confidence >= 0.82:

                            theta -= 0.04 if is_whale_climax else 0.09

                        else:

                            theta -= 0.18



            # Lệch pha Funding Rate (Chuẩn dấu cho cả LONG và SHORT):

            if funding_rate < -0.0003:  # Funding âm sâu -> Phe Short quá đông -> Áp lực Short Squeeze bật tăng

                if is_buy:

                    theta += 0.06

                    favorable_drift_bias += 0.0008

                else:

                    # [BÀI HỌC 107 - MIỄN TRỪ FUNDING ÂM CHO EXHAUSTION FADING SHORT / SIGN VETO FIX]:
                    # Khi coin vừa pump kiệt sức, retail fomo short đẩy funding âm, nhưng cá mập đang xả đỉnh.
                    # Miễn trừ phạt cho setup Fading Short / Whale Climax đã có xác nhận râu/xả thực tế!
                    if is_whale_climax:

                        context_notes.append("EXHAUSTION_CLIMAX_FUNDING_EXEMPTION")

                    else:

                        theta -= 0.10

                        favorable_drift_bias -= 0.0012

            elif funding_rate > 0.0005:  # Funding dương cao -> Phe Long quá đông -> Áp lực Long Flush sập râu

                if is_buy:

                    if is_whale_climax:

                        context_notes.append("ABSORPTION_CLIMAX_FUNDING_EXEMPTION")

                    else:

                        theta -= 0.10

                        favorable_drift_bias -= 0.0012

                else:

                    theta += 0.06

                    favorable_drift_bias += 0.0008



        # =========================================================================

        # B. NHÁNH TRADFI CHỨNG KHOÁN MỸ & ETF: BÀO MÒN DECAY, PHIÊN MỸ & NHẢY GAP

        # =========================================================================

        session_vol_mult = 1.0

        jump_prob = 0.06

        jump_scale = 1.6



        if asset_class in ("TRADFI_STOCK", "TRADFI_LEVERAGED_ETF", "TRADFI_COMMODITY"):

            # 1. Kiểm tra trạng thái phiên Wall Street (20:30 - 03:00 VN) - chỉ áp dụng cho Cổ phiếu & ETF

            if asset_class in ("TRADFI_STOCK", "TRADFI_LEVERAGED_ETF"):

                if is_us_open is None:

                    if MarketScanner is not None and hasattr(MarketScanner, "is_us_market_open"):

                        try:

                            is_us_open = MarketScanner.is_us_market_open()

                        except Exception:

                            is_us_open = False

                    else:

                        is_us_open = False



                if not is_us_open:

                    # Ngoài giờ phiên Mỹ: Thanh khoản mỏng, spread giãn, râu nến ảo dễ quét SL

                    session_vol_mult = 1.35

                    jump_prob = 0.09



            # 2. Kiểm tra Rủi ro Nhảy Gap Cuối Tuần / Qua Đêm (Weekend & Overnight Gap Jump) cho cả Cổ phiếu, ETF & Hàng hóa

            if is_weekend_gap is None:

                if MarketScanner is not None and hasattr(MarketScanner, "is_weekend_gap_risk_window"):

                    try:

                        is_weekend_gap = MarketScanner.is_weekend_gap_risk_window(symbol=symbol)

                    except Exception:

                        is_weekend_gap = False

                else:

                    is_weekend_gap = False



            if is_weekend_gap:

                # Sát giờ đóng cửa phiên Thứ 6 hoặc trong cuối tuần: Rủi ro nhảy Gap mở phiên Thứ 2

                session_vol_mult *= 1.25

                jump_prob = max(jump_prob, 0.14)

                jump_scale = 2.2

                theta -= 0.08



            # 3. Xử lý Bào mòn Toán học ETF (Leveraged ETF Volatility Drag):

            if asset_class == "TRADFI_LEVERAGED_ETF":

                is_inverse = clean_base in self.KNOWN_INVERSE_ETFS
                _etf_2x_bases = {
                    "NVDL", "TSLL", "MSTU", "MSTX", "CONL", "MUU", "MVLL", "SNXX",
                    "SKUU", "SKDD", "CSOPSAMSUNG2L", "CSOPSKHYNIX2L", "UVXY", "BOIL",
                }
                _lev_mag = 2.0 if clean_base in _etf_2x_bases else 3.0
                beta = -_lev_mag if is_inverse else _lev_mag

                sigma_est = (atr_pct / 100.0) / math.sqrt(4.0)



                # Khi thị trường đi ngang (ADX < 32) hoặc tín hiệu yếu (confidence < 0.65):

                # Giá trị nội tại của ETF đòn bẩy tự suy giảm theo phương sai: mu_drag = -0.5 * (beta^2 - |beta|) * sigma^2

                if adx < 32.0 or confidence < 0.65:

                    drag_magnitude = 0.5 * (beta ** 2 - abs(beta)) * (sigma_est ** 2) * 2.5

                    if is_buy:

                        # Mua nắm giữ ETF đòn bẩy khi thị trường cù cưa sẽ bị bào mòn giá trực tiếp về phía SL

                        favorable_drift_bias -= drag_magnitude

                        theta -= 0.15

                        if is_inverse:

                            veto_reasons.append(f"BÀO_MÒN_ETF_ĐẢO_CHIỀU_{clean_base}(ADX={adx:.1f}<32)")

                    else:

                        # Short ETF đảo chiều vẫn chịu rủi ro giật râu cao nếu ADX yếu

                        if is_inverse and adx < 25.0:

                            theta -= 0.08



        # =========================================================================

        # C. HIỆU ỨNG MARKET REGIME & XUNG LỰC ĐA KHUNG (MARKET REGIME QUANTUM COUPLING)

        # =========================================================================

        regime_norm = str(regime or '').lower()

        if regime_norm in ('ranging', 'consolidation', 'choppy', 'sideway'):

            # [BOM #19 FIX]: Với VK10 TradFi bắt đáy rút chân (L_Wick >= 38%, ADX <= 30) vốn chuyên đánh nhịp hồi trong ranging/sideway,
            # không dùng phạt nặng -0.20 của lệnh Trend/Breakout tránh bóp chết 100% hàng hóa dầu/vàng (CL, BZ, XAU).
            if _is_vk10_sig and is_whale_climax and is_buy and asset_class != "TRADFI_LEVERAGED_ETF":
                theta -= 0.04
                favorable_drift_bias -= 0.0002
                context_notes.append(f"VK10_TRADFI_RANGE_ABSORPTION({regime_norm.upper()})")
            else:
                # Thị trường đi ngang/nén biên độ: Triệt tiêu gia tốc thuận chiều, tăng xác suất quét 2 đầu

                theta -= 0.14

                favorable_drift_bias -= 0.0012

                context_notes.append(f"THỊ_TRƯỜNG_RANGING_ĐI_NGANG({regime_norm.upper()})")

                if adx < 25.0:

                    theta -= 0.06

                    favorable_drift_bias -= 0.0006

        elif regime_norm in ('strong_downtrend', 'downtrend'):

            if is_buy:

                # Đánh ngược sóng giảm mạnh: Nếu là tín hiệu Smart Inversion / Climax độ tự tin cao (>= 82%) hoặc Whale Climax,
                # giảm tối đa mức phạt trễ pha 4H để khơi thông lệnh bắt đáy Selling Climax / Momentum Ride!
                if is_whale_climax:

                    theta -= 0.02

                    favorable_drift_bias -= 0.0002

                    context_notes.append(f"SMART_ABSORPTION_BOUNCE({regime_norm.upper()})")

                elif confidence >= 0.82:

                    theta -= 0.08

                    favorable_drift_bias -= 0.0006

                    context_notes.append(f"NGƯỢC_XU_HƯỚNG_GIẢM({regime_norm.upper()})")

                else:

                    theta -= 0.18

                    favorable_drift_bias -= 0.0015

                    context_notes.append(f"NGƯỢC_XU_HƯỚNG_GIẢM({regime_norm.upper()})")

            else:

                # Thuận sóng giảm mạnh: Tăng cường pha lượng tử

                theta += 0.06

                favorable_drift_bias += 0.0005

        elif regime_norm in ('strong_uptrend', 'uptrend'):

            if not is_buy:

                # Đánh ngược sóng tăng mạnh: Nếu là tín hiệu Smart Inversion / Buying Climax Pha 2 (>= 82%) hoặc Whale Climax,
                # giảm tối đa mức phạt trễ pha 4H để khơi thông lệnh SHORT đỉnh cá mập (như SIGN/USDT)!
                if is_whale_climax:

                    theta -= 0.02

                    favorable_drift_bias -= 0.0002

                    context_notes.append(f"EXHAUSTION_FADING_SHORT({regime_norm.upper()})")

                elif confidence >= 0.82:

                    theta -= 0.08

                    favorable_drift_bias -= 0.0006

                    context_notes.append(f"NGƯỢC_XU_HƯỚNG_TĂNG({regime_norm.upper()})")

                else:

                    theta -= 0.18

                    favorable_drift_bias -= 0.0015

                    context_notes.append(f"NGƯỢC_XU_HƯỚNG_TĂNG({regime_norm.upper()})")

            else:

                # Thuận sóng tăng mạnh: Tăng cường pha lượng tử

                theta += 0.06

                favorable_drift_bias += 0.0005



        # =========================================================================

        # D. TÍCH HỢP BẢO VỆ AI JEV AGENT (JEV MULTI-TIMEFRAME RISK COUPLING)

        # =========================================================================

        if jev_verdict and str(jev_verdict).upper() == 'HOLD':

            j_risk = (str(jev_risk or '') + " " + str(jev_reason or '')).lower()

            if any(w in j_risk for w in ('consolidation', 'choppy', 'volume exhaustion', 'conflicting', 'no clear breakout', 'overbought')):

                theta -= 0.12

                favorable_drift_bias -= 0.0010

                context_notes.append("JEV_AI_CẢNH_BÁO_RỦI_RO_NÉN_GIÁ")



        # Kẹp góc pha theta an toàn trong khoảng (0.10, pi/2 - 0.10)

        theta = float(np.clip(theta, 0.10, math.pi / 2.0 - 0.10))



        # Biên độ xác suất lượng tử thuận chiều (forward) và ngược chiều (adverse)

        p_forward = math.sin(theta) ** 2

        p_adverse = math.cos(theta) ** 2



        # Chuẩn hóa biến động 15m với hệ số phiên giao dịch

        sigma_step = ((atr_pct / 100.0) / math.sqrt(4.0)) * session_vol_mult



        # Lực đẩy định hướng kỳ vọng thuận chiều lệnh (Trade-Favorable Quantum Drift).

        #

        # [SỬA LỖI GỐC RỄ] Trước đây drift được cộng vào TỪNG nến trong n_steps nến mà không

        # chuẩn hóa, nên TỔNG drift tích lũy = n_steps × drift_mỗi_nến. Với ATR 1% - 6% và

        # confidence 0.5 - 0.9, tổng drift đạt 6.4% - 38.2%, tức gấp 1.4 - 5.5 lần khoảng cách

        # TP. Hệ quả: mọi đường đi Monte Carlo đều chạm TP, P(Win) bị bão hòa theo score,

        # P(DOA) luôn bằng 0 -> cổng thẩm định mất hoàn toàn năng lực phân biệt.

        # Nay chuẩn hóa bằng 1/sqrt(n_steps) để TỔNG drift cùng bậc với TỔNG sigma.

        # [BOM #19 FIX - CHUẨN HÓA DRIFT BIAS THEO BIÊN ĐỘ THỰC SIGMA_STEP]:
        # Hằng số favorable_drift_bias vốn hiệu chuẩn cho Crypto (sigma_step >= 0.010, ATR >= 2.0%).
        # Với TradFi biên độ mịn (CL/BZ/XAU ATR 0.38%-0.8%, sigma_step ~ 0.002), giữ nguyên hằng số tuyệt đối sẽ
        # làm gamma SDE nổ tới -136.0 (P_win=4%)! Co giãn theo vol_scale = min(1.0, sigma_step / 0.010) giữ nguyên
        # 100% hành vi trên Crypto Altcoin và chuẩn hóa toán học cho TradFi.
        _drift_vol_scale = (
            min(1.0, sigma_step / 0.010)
            if ((_is_tradfi and asset_class != "TRADFI_LEVERAGED_ETF") or asset_class == "CRYPTO_MAJOR")
            else 1.0
        )
        eff_drift_bias = favorable_drift_bias * _drift_vol_scale

        drift_normalizer = 1.0 / math.sqrt(max(1, self.n_steps))

        favorable_quantum_drift = (

            ((p_forward - p_adverse) * sigma_step * 0.85) + eff_drift_bias

        ) * drift_normalizer



        # 2. KHUẾCH TÁN LƯỢNG TỬ ĐỒNG THỜI (VECTORIZED QUANTUM JUMP-DIFFUSION)

        # Tạo seed tất định bằng CRC32 tránh va chạm ở các đồng coin mệnh giá nhỏ (PEPE, SHIB, BONK...)

        seed_str = f"{clean_base}:{is_buy}:{entry_price:.8f}:{adx:.2f}:{confidence:.4f}"

        seed_val = zlib.crc32(seed_str.encode("utf-8")) & 0x7FFFFFFF

        rng = np.random.RandomState(seed_val)



        random_shocks = rng.standard_normal((self.n_paths, self.n_steps))



        # Phễu biến động nở rộng (Dynamic Volatility Expansion): nếu ADX > 35, 8 nến đầu bung biên độ +25%

        if adx > 35.0:

            step_weights = np.ones((1, self.n_steps))

            step_weights[:, : min(8, self.n_steps)] = 1.25

            scaled_sigma = sigma_step * step_weights

        else:

            scaled_sigma = sigma_step



        # Bước dịch chuyển thuận chiều lệnh trên từng nến

        favorable_step_returns = favorable_quantum_drift + (scaled_sigma * random_shocks)



        # Cú nhảy quét thanh khoản Poisson Jump Process

        jump_mask = rng.random_sample((self.n_paths, self.n_steps)) < jump_prob

        jump_magnitudes = rng.standard_normal((self.n_paths, self.n_steps)) * (scaled_sigma * jump_scale)

        favorable_step_returns = np.where(jump_mask, favorable_step_returns + jump_magnitudes, favorable_step_returns)



        # Tích lũy đường đi (Cumulative Returns thuận chiều lệnh: + là tiến tới TP, - là lùi về SL)

        cum_returns = np.cumsum(favorable_step_returns, axis=1)



        # 3. XÁC ĐỊNH SỰ KIỆN CHẠM TP, SL VÀ DOA

        hit_tp_mask = cum_returns >= tp_dist

        hit_sl_mask = cum_returns <= -sl_dist



        has_hit_tp = np.any(hit_tp_mask, axis=1)

        has_hit_sl = np.any(hit_sl_mask, axis=1)



        first_tp_step = np.where(has_hit_tp, np.argmax(hit_tp_mask, axis=1), self.n_steps + 1)

        first_sl_step = np.where(has_hit_sl, np.argmax(hit_sl_mask, axis=1), self.n_steps + 1)



        # Thắng nếu chạm TP trước khi chạm SL

        win_paths = has_hit_tp & (first_tp_step < first_sl_step)

        # Thua nếu chạm SL trước hoặc cùng bước nến với TP (nguyên tắc quản trị rủi ro thận trọng, bảo toàn tổng xác suất = 1.0)

        loss_paths = has_hit_sl & (first_sl_step <= first_tp_step)

        # Cù cưa / Ứ đọng vốn (DOA) nếu không chạm cả 2 trong suốt n_steps

        doa_paths = (~has_hit_tp) & (~has_hit_sl)



        p_win = float(np.sum(win_paths) / self.n_paths)

        p_loss = float(np.sum(loss_paths) / self.n_paths)

        p_doa = float(np.sum(doa_paths) / self.n_paths)



        # 4. KỲ VỌNG LỢI NHUẬN THUẦN TÚY (EXPECTED MONTE CARLO EV)

        total_fee_pct = fee_rate * 2.0

        _tp1_meta_dist = _safe_float(_md.get("v61_tp1_pct") or _md.get("partial_tp_trigger_pct"), 0.0)
        _tp1_take_raw = _md.get("v61_tp1_take_pct", _md.get("tp1_take_pct"))
        try:
            _tp1_take_int = int(_tp1_take_raw) if _tp1_take_raw is not None else 0
        except (TypeError, ValueError):
            _tp1_take_int = 0
        if _tp1_take_int > 0 and 0.005 <= _tp1_meta_dist < tp_dist:
            _part_ratio = max(0.15, min(0.85, _tp1_take_int / 100.0))
            _hit_tp1_mask = cum_returns >= _tp1_meta_dist
            _has_hit_tp1 = np.any(_hit_tp1_mask, axis=1)
            _first_tp1_step = np.where(_has_hit_tp1, np.argmax(_hit_tp1_mask, axis=1), self.n_steps + 1)
            _tp1_before_sl = _has_hit_tp1 & (_first_tp1_step < first_sl_step)
            _pure_loss_prob = float(np.sum(loss_paths & (~_tp1_before_sl)) / self.n_paths)
            _tp1_runner_be_prob = float(np.sum(_tp1_before_sl & (~win_paths)) / self.n_paths)
            _full_win_payoff = (_part_ratio * _tp1_meta_dist) + ((1.0 - _part_ratio) * tp_dist)
            _partial_be_payoff = (_part_ratio * _tp1_meta_dist) + ((1.0 - _part_ratio) * 0.0012)
            expected_ev_pct = (p_win * _full_win_payoff) + (_tp1_runner_be_prob * _partial_be_payoff) - (_pure_loss_prob * sl_dist) - total_fee_pct
        else:
            expected_ev_pct = (p_win * tp_dist) - (p_loss * sl_dist) - total_fee_pct

        reward_risk_ratio = tp_dist / sl_dist if sl_dist > 0 else 1.0



        # [BÀI HỌC 95 - CHUẨN HÓA TOÁN HỌC QUANTUM RESOLVED WINRATE]:

        # Phân định rõ giữa xác suất thô (bị pha loãng bởi DOA) và xác suất phân định kết quả (Resolved Paths).

        # Tỷ lệ hòa vốn breakeven_win_prob chỉ có ý nghĩa trên không gian mẫu đã chạm TP hoặc SL.

        resolved_paths = p_win + p_loss

        p_win_resolved = (p_win / resolved_paths) if resolved_paths > 1e-6 else p_win



        # Điểm hòa vốn lý thuyết (win rate tối thiểu để EV = 0 trước phí) và mức yêu cầu

        # có biên lợi thế. Đây là ngưỡng THẬT SỰ có ý nghĩa kinh tế, thay cho mốc P(Win)

        # tuyệt đối 68% vốn chỉ đạt được nhờ drift bị thổi phồng.

        breakeven_win_prob = sl_dist / (tp_dist + sl_dist) if (tp_dist + sl_dist) > 0 else 0.5

        min_win_required = breakeven_win_prob * (1.0 + self.edge_margin)



        sigma_total_pct = sigma_step * math.sqrt(max(1, self.n_steps)) * 100.0

        # [BOM #95F FIX]: Drift tich luy qua n_steps phai la * n_steps (khong phai sqrt(n_steps))
        drift_total_pct = favorable_quantum_drift * max(1, self.n_steps) * 100.0



        # [BÀI HỌC 98 - GIA CỐ LÕI SDE NGHIỆM ĐÓNG BLACK-SCHOLES & DYNAMIC DELTA SIZING]

        p_analytical = self._analytical_barrier_first_passage(

            favorable_quantum_drift, sigma_step, sl_dist, tp_dist

        )

        delta_factor = self._calculate_delta(favorable_quantum_drift, sigma_step, self.n_steps)

        p_win_dual = 0.50 * p_win_resolved + 0.50 * p_analytical



        # Tính delta_multiplier điều chỉnh quy mô Notional (0.75x đến 1.25x)

        if delta_factor >= 0.68:

            delta_multiplier = 1.25

        elif delta_factor <= 0.48:

            delta_multiplier = 0.75

        else:

            delta_multiplier = 1.00



        # 5. QUYẾT ĐỊNH CỔNG THẨM ĐỊNH LƯỢNG TỬ (TUÂN THỦ TÔN CHỈ THUẬN CÁ MẬP & EV DƯƠNG):

        # Bộ lọc SDE Barrier: Ngăn chặn bẫy sai số mẫu ngẫu nhiên (sampling variance) của Monte Carlo

        # trên các coin biến động cực lớn (như BOME sigma=3.66% P_analytical chỉ 33.17%)

        analytical_min_req = breakeven_win_prob * 1.025

        if p_analytical < analytical_min_req:

            gamma_ratio = (2.0 * favorable_quantum_drift) / ((sigma_step ** 2) + 1e-12)

            veto_reasons.append(

                f"SDE_BARRIER_EV_ÂM(P_analytical={p_analytical:.1%}<{analytical_min_req:.1%},gamma={gamma_ratio:.2f})"

            )



        if self.min_win_prob > 0.0 and p_win_resolved < self.min_win_prob:

            veto_reasons.append(f"XÁC_SUẤT_WIN_THẤP(P_resolved={p_win_resolved:.1%}<{self.min_win_prob:.1%})")

        _ev_pass = expected_ev_pct > self.min_ev_pct

        if p_win_resolved < min_win_required:

            if _ev_pass:

                context_notes.append(

                    f"XÁC_SUẤT_DƯỚI_NGƯỠNG_HÒA_VỐN({p_win_resolved:.1%}<{min_win_required:.1%})_NHƯNG_EV_DƯƠNG({expected_ev_pct*100:+.2f}%)"

                )

            else:

                veto_reasons.append(

                    f"XÁC_SUẤT_DƯỚI_NGƯỠNG_HÒA_VỐN(P_resolved={p_win_resolved:.1%}<{min_win_required:.1%})"

                )

        if not _ev_pass:

            veto_reasons.append(

                f"KỲ_VỌNG_EV_KHÔNG_ĐỦ({expected_ev_pct*100:+.2f}%<={self.min_ev_pct*100:+.2f}%)"

            )

        # Chỉ VETO DOA khi rủi ro ứ đọng thực sự nghiêm trọng (> 60%) HOẶC khi EV không đủ bù rủi ro;

        # Nếu EV dương sau phí và p_win >= p_loss, DOA 40-50% đã được quản trị an toàn bởi DOA Watchdog (25m/120m).

        if p_doa > max(0.60, self.max_doa_prob * 1.5) or (expected_ev_pct <= self.min_ev_pct and p_doa > self.max_doa_prob):

            veto_reasons.append(f"RỦI_RO_Ứ_ĐỌNG_VỐN_DOA(P={p_doa:.1%}>{self.max_doa_prob:.1%})")




        # [BÀI HỌC 101 - CHỐT CHẶN BẤT ĐỐI XỨNG RỦI RO THUA LỖ (ASYMMETRIC LOSS VETO)]:
        # Chặn đứng bẫy toán học: Khi P(Loss) áp đảo P(Win) (như AXTI P_loss=53.6% gấp đôi P_win=25.2%),
        # dù R:R cao kéo EV hơi dương danh nghĩa, nhưng xác suất dính SL do nhiễu thị trường là áp đảo.
        # Cho phép nới lỏng nhẹ cho setup cá mập độ tự tin cao (confidence >= 0.85 & có JEV đồng thuận),
        # nhưng tuyệt đối VETO các lệnh có P(Loss) vượt trội và P(Win) thô quá thấp!
        # [BÀI HỌC 101, 106 & 107 - SMART QUANTUM FLOOR 40% & VERIFIED WHALE CLIMAX EXEMPTION]:
        # Phân biệt rõ:
        # 1. Với lệnh Trend Following / Breakout hoặc tín hiệu thiếu râu/xung lượng Climax vật lý:
        #    Bắt buộc P(Win) >= 40.0% (min_win_floor = 0.40) để triệt tiêu các lệnh đu đỉnh/đu đáy muộn
        #    hoặc đảo chiều non thiếu xác nhận (IDOL, AXTI, NEAR, ENA, PIEVERSE 32.3%, ICNT 37.9%, CAP#3 37.8%).
        # 2. Với lệnh Bắt Đỉnh/Đáy Cá Mập đã xác minh vật lý (Pha 2 Exhaustion Fading Short / Pha 1 Absorption Reversal
        #    có Râu thuận chiều >= 35% hoặc sóng Climax Pump/Dump >= 2.00% hoặc EV >= +0.40% QUANTUM_CONFIRMED):
        #    Miễn trừ sàn 40%, áp dụng min_win_floor = 0.28 bảo toàn 100% các lệnh thắng lớn FOGO, MON, BR, LA, CAP#1, ARIA, CAP#2!
        # [BOM #19 CLEANUP]: Tái sử dụng trực tiếp is_whale_climax, _is_tradfi, _pump_pct, _dump_pct đã tính ở đầu hàm (xóa duplicate block)
        jev_agrees_dir = str(jev_verdict or '').upper() == ('BUY' if is_buy else 'SELL')
        is_high_conviction_whale = (confidence >= 0.85 and jev_agrees_dir and expected_ev_pct >= 0.0035)
        is_exempt_climax = is_high_conviction_whale or is_whale_climax
        max_loss_ratio = 1.85 if is_exempt_climax else 1.35
        min_win_floor = 0.28 if is_exempt_climax else 0.40

        # Khi p_doa cao (>= 25%-35%), p_win thô bị pha loãng bởi các đường đi chưa chạm ngưỡng (đặc biệt TradFi ATR 0.38-0.60%).
        # Nếu p_win_resolved >= min_win_required và expected_ev_pct > self.min_ev_pct,
        # không được dùng sàn p_win thô để phủ quyết sai các tài sản biến động thấp (BNB, BTC, DOGE, CL, BZ, XAU).
        _doa_dilute_floor = 0.25 if (_is_tradfi and is_exempt_climax) else 0.35
        is_diluted_by_doa = (
            p_doa >= _doa_dilute_floor
            and p_win_resolved >= min_win_required
            and expected_ev_pct > self.min_ev_pct
        )

        if p_loss > p_win * max_loss_ratio and not is_diluted_by_doa:
            veto_reasons.append(
                f"RỦI_RO_THUA_ÁP_ĐẢO(P_loss={p_loss:.1%}>{max_loss_ratio:.2f}x P_win={p_win:.1%})"
            )
        if p_win < min_win_floor and not is_diluted_by_doa:
            veto_reasons.append(
                f"XÁC_SUẤT_WIN_THÔ_QUÁ_THẤP(P_win={p_win:.1%}<{min_win_floor:.1%})"
            )

        # [BÀI HỌC 108 - RÀO CHẮN VETO SHORT KHI FUNDING RATE ÂM SÂU]:
        # Khi Funding Rate <= -0.04% (-0.0004) trên Crypto, phe Short bị dồn toa cực độ, tích tụ áp lực Short Squeeze dữ dội.
        # Tuyệt đối cấm Short nếu không có xác nhận Whale Climax thực tế (sóng bơm kiệt sức >= 1.8% hoặc volume bão)!
        if not is_buy and not _is_tradfi and funding_rate <= -0.0004:
            if not is_whale_climax and _pump_pct < 0.018:
                veto_reasons.append(
                    f"BẪY_SHORT_SQUEEZE_FUNDING_ÂM_SÂU(FR={funding_rate*100:.3f}%<=-0.040%_THIẾU_WHALE_CLIMAX)"
                )
        elif is_buy and not _is_tradfi and funding_rate >= 0.0008:
            if not is_whale_climax and _dump_pct < 0.018:
                veto_reasons.append(
                    f"BẪY_LONG_FLUSH_FUNDING_DƯƠNG_CAO(FR={funding_rate*100:.3f}%>=+0.080%_THIẾU_WHALE_CLIMAX)"
                )

        # [BOM #111C - M3 HURST + M7 EMPIRICAL FPT + M1 RMT MARCHENKO-PASTUR]:
        closes_15m = self._extract_closed_15m_closes(_md)
        hurst_val, hurst_valid = self._compute_hurst_rs(closes_15m)
        _def_fpt_tp1 = (
            0.0230 if asset_class == "TRADFI_LEVERAGED_ETF"
            else (0.0105 if (_is_tradfi or asset_class == "CRYPTO_MAJOR") else 0.0135)
        )
        try:
            _tp1_raw_fpt = float(_md.get("v61_tp1_pct") or _def_fpt_tp1)
            if not math.isfinite(_tp1_raw_fpt) or _tp1_raw_fpt <= 0:
                _tp1_raw_fpt = _def_fpt_tp1
        except (TypeError, ValueError):
            _tp1_raw_fpt = _def_fpt_tp1
        _fpt_tp_barrier = min(tp_dist, _tp1_raw_fpt) if tp_dist >= 0.005 else _tp1_raw_fpt
        _fpt_sl_barrier = max(0.010, sl_dist)
        p_emp_fpt, fpt_valid = self._compute_empirical_fpt(closes_15m, is_buy, _fpt_tp_barrier, _fpt_sl_barrier)

        _wid_q = str(_md.get("weapon_id") or "").upper()
        _is_momentum_weapon = (
            _wid_q in (
                "VK1", "VK1_LONG_THUAN_SONG_CA_MAP",
                "VK5", "VK5_SHORT_THAC_DO_CA_MAP_XA",
                "VK8", "VK8_THUAN_XU_HUONG_DA_KHUNG",
            )
            or bool(_md.get("is_momentum_ride") or _md.get("is_waterfall_short"))
            or (_is_dyn_sig and _dyn_arch in ("TREND_MOMENTUM", "MOMENTUM_BREAKOUT"))
        )
        if hurst_valid:
            if _is_momentum_weapon and hurst_val < 0.45:
                veto_reasons.append(f"HURST_CHOP_MẤT_ĐÀ(H={hurst_val:.2f}<0.45)")
            elif (not _is_momentum_weapon) and hurst_val > 0.65:
                veto_reasons.append(f"HURST_TREND_BỀN_CẤM_CẢN_TÀU(H={hurst_val:.2f}>0.65)")
            context_notes.append(f"HURST_{'MOM' if _is_momentum_weapon else 'REV'}(H={hurst_val:.2f})")

        if fpt_valid and p_emp_fpt is not None:
            if _is_momentum_weapon and p_emp_fpt < 0.45:
                veto_reasons.append(f"EMPIRICAL_FPT_THẤP(P_fpt={p_emp_fpt:.1%}<45.0%)")
            context_notes.append(f"EMPIRICAL_FPT({p_emp_fpt:.1%})")

        if _is_tradfi:
            rmt_info: Dict[str, Any] = {
                "available": False, "lmax_ratio": 0.0, "abs_ratio": 0.0, "mp_excess": 0.0,
                "fragmented_veto": False, "rmt_sizing_mult": 1.00, "regime_tag": "RMT_TRADFI_EXEMPT",
            }
        elif closes_15m is not None:
            rmt_info = self.compute_crypto_rmt_coherence()
            if rmt_info.get("available"):
                if rmt_info.get("fragmented_veto"):
                    veto_reasons.append(
                        f"RMT_NHIỄU_PHÂN_MẢNH(lmax/lp={rmt_info['lmax_ratio']:.2f},abs={rmt_info['abs_ratio']:.2f},mp_ex={rmt_info['mp_excess']:.2f})"
                    )
                if float(rmt_info.get("rmt_sizing_mult", 1.0)) < 1.0:
                    context_notes.append(
                        f"RMT_{rmt_info['regime_tag']}(mult={rmt_info['rmt_sizing_mult']:.2f}x,abs={rmt_info['abs_ratio']:.2f},mp_ex={rmt_info['mp_excess']:.2f})"
                    )
        else:
            rmt_info = {
                "available": False, "lmax_ratio": 0.0, "abs_ratio": 0.0, "mp_excess": 0.0,
                "fragmented_veto": False, "rmt_sizing_mult": 1.00, "regime_tag": "RMT_NO_DFS_SKIP",
            }

        pass_gate = len(veto_reasons) == 0



        # Đề xuất đòn bẩy động: xếp hạng theo KỲ VỌNG EV sau phí (không dùng P(Win) bão hòa)

        ev_pct_rank = expected_ev_pct * 100.0

        if not pass_gate:

            leverage_mult = 0.00

            conf_tier = "QUANTUM_VETO"

        elif ev_pct_rank >= 1.50:

            leverage_mult = 1.25

            conf_tier = "QUANTUM_EXCELLENT"

        elif ev_pct_rank >= 0.50:

            leverage_mult = 1.00

            conf_tier = "QUANTUM_CONFIRMED"

        else:

            leverage_mult = 0.75

            conf_tier = "QUANTUM_MARGINAL"

        # [V5.5 DYNAMIC VOLATILITY SIZING COOLDOWN]:
        # Khi độ biến động lượng tử cực lớn (sigma_total_pct >= 35.0%),
        # tự động co leverage_mult xuống tối đa 0.50x để giảm tải rủi ro vốn.
        if pass_gate and sigma_total_pct >= 35.0:

            leverage_mult = min(leverage_mult, 0.50)

            conf_tier += "_EXTREME_VOLATILITY"



        time_taken_ms = (time.perf_counter() - t0) * 1000.0



        return {

            "symbol": symbol,

            "side": side,

            "asset_class": asset_class,

            "p_win": round(p_win, 4),

            "p_win_resolved": round(p_win_resolved, 4),

            "p_analytical": round(p_analytical, 4),

            "p_win_dual": round(p_win_dual, 4),

            "delta_factor": round(delta_factor, 4),

            "delta_multiplier": delta_multiplier,

            "p_loss": round(p_loss, 4),

            "p_doa": round(p_doa, 4),

            "expected_ev_pct": round(expected_ev_pct * 100.0, 3),

            "reward_risk_ratio": round(reward_risk_ratio, 2),

            "breakeven_win_prob": round(breakeven_win_prob, 4),

            "min_win_required": round(min_win_required, 4),

            "sigma_total_pct": round(sigma_total_pct, 3),

            "drift_total_pct": round(drift_total_pct, 3),

            "pass_gate": pass_gate,

            "confidence_tier": conf_tier,

            "leverage_multiplier": leverage_mult,

            "veto_reasons": veto_reasons,

            "context_notes": context_notes,

            "time_taken_ms": round(time_taken_ms, 2),

            "paths_simulated": self.n_paths,

            "hurst_exponent": round(hurst_val, 3),

            "hurst_valid": hurst_valid,

            "p_empirical_fpt": round(p_emp_fpt, 4) if p_emp_fpt is not None else None,

            "fpt_valid": fpt_valid,

            "rmt_available": bool(rmt_info.get("available")),

            "rmt_lmax_ratio": round(float(rmt_info.get("lmax_ratio", 0.0) or 0.0), 3),

            "rmt_abs_ratio": round(float(rmt_info.get("abs_ratio", 0.0) or 0.0), 3),

            "rmt_mp_excess": round(float(rmt_info.get("mp_excess", 0.0) or 0.0), 3),

            "rmt_sizing_mult": float(rmt_info.get("rmt_sizing_mult", 1.0) or 1.0),

            "rmt_regime": str(rmt_info.get("regime_tag", "RMT_SKIP")),

        }

