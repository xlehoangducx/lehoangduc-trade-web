import json
import logging
import requests
import pandas as pd
import threading
import time
from typing import Dict, Any, Optional
import ta
from core.scanner import MarketScanner
from ai.ollama_runtime import OLLAMA_GPU_LOCK

logger = logging.getLogger(__name__)

class JevAgent:
    def __init__(self, model_name: str = "qwen3:14b", endpoint: str = "http://localhost:11434/api/generate",
                 read_timeout_seconds: float = 30.0, num_predict: int = 180):
        self.model_name = model_name
        self.endpoint = endpoint
        self.format = "json"
        self._cooldown_until = 0.0
        self._cooldown_lock = threading.Lock()
        self._failure_cooldown_seconds = 60.0
        self._read_timeout_seconds = max(20.0, min(45.0, float(read_timeout_seconds)))
        self._num_predict = max(120, min(260, int(num_predict)))

    def _cooldown_remaining(self) -> float:
        with self._cooldown_lock:
            return max(0.0, self._cooldown_until - time.monotonic())

    def _start_failure_cooldown(self, seconds: Optional[float] = None) -> None:
        duration = self._failure_cooldown_seconds if seconds is None else max(0.0, float(seconds))
        with self._cooldown_lock:
            self._cooldown_until = max(self._cooldown_until, time.monotonic() + duration)

    @staticmethod
    def _unavailable_result(status: str, detail: str) -> Dict[str, Any]:
        return {
            "decision": "HOLD",
            "confidence": 0.0,
            "reason": f"JEV unavailable ({status}): {str(detail)[:180]}",
            "risk_factors": "JEV/Ollama unavailable; candidate must fail closed",
            "availability_status": status,
        }

    def _extract_tf_metrics(self, df: Optional[pd.DataFrame], tf_label: str) -> Dict[str, Any]:
        """Tính toán nhanh các chỉ báo cốt lõi của khung thời gian phụ (4H hoặc 1H) dựa trên nến đã đóng."""
        if df is None or len(df) < 25:
            return {"status": f"{tf_label} data not available"}
        try:
            closed_tf = df.iloc[:-1] if len(df) > 2 else df
            c = closed_tf['close']
            ema20_s = ta.trend.EMAIndicator(c, window=min(len(c), 20)).ema_indicator()
            ema20 = float(ema20_s.dropna().iloc[-1]) if not ema20_s.dropna().empty else float(c.iloc[-1])
            
            w50 = min(len(c), 50)
            ema50_s = ta.trend.EMAIndicator(c, window=w50).ema_indicator()
            ema50 = float(ema50_s.dropna().iloc[-1]) if not ema50_s.dropna().empty else ema20
            
            curr_c = float(c.iloc[-1])
            rsi_s = ta.momentum.RSIIndicator(c, window=min(len(c)-1, 14)).rsi()
            rsi_val = float(rsi_s.dropna().iloc[-1]) if not rsi_s.dropna().empty else 50.0

            # Đánh giá xu hướng
            if curr_c > ema20 > ema50:
                trend = "BULLISH (Price > EMA20 > EMA50)"
            elif curr_c < ema20 < ema50:
                trend = "BEARISH (Price < EMA20 < EMA50)"
            elif curr_c > ema50:
                trend = "MODERATELY BULLISH (Above EMA50, Testing EMA20)"
            elif curr_c < ema50:
                trend = "MODERATELY BEARISH (Below EMA50, Testing EMA20)"
            else:
                trend = "NEUTRAL / CHOPPY"

            res = {
                "trend": trend,
                "price": curr_c,
                "ema20": ema20,
                "ema50": ema50,
                "rsi": rsi_val
            }

            # Tính toán vi mô chuyên sâu cho khung 5M (Râu nến hấp thụ & RVol)
            if tf_label == "5M" and len(closed_tf) >= 2:
                c_last = closed_tf.iloc[-1]
                rng = float(c_last['high'] - c_last['low']) if (c_last['high'] - c_last['low']) > 0 else 1e-9
                lwick = float((min(c_last['open'], c_last['close']) - c_last['low']) / rng)
                uwick = float((c_last['high'] - max(c_last['open'], c_last['close'])) / rng)
                vol_ma = float(closed_tf['volume'].tail(20).mean() or 1.0)
                rvol = float(c_last['volume'] / vol_ma) if vol_ma > 0 else 1.0
                res.update({
                    "lwick": lwick,
                    "uwick": uwick,
                    "rvol": rvol,
                    "is_green": bool(c_last['close'] >= c_last['open'])
                })

            return res
        except Exception:
            return {"status": f"{tf_label} calculation error"}

    def analyze_klines(
        self,
        df: pd.DataFrame,
        symbol: str,
        df_1h: Optional[pd.DataFrame] = None,
        df_4h: Optional[pd.DataFrame] = None,
        df_5m: Optional[pd.DataFrame] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Phân tích đa khung thời gian (Multi-Timeframe):
        - Khung tác chiến chính (df): 15M (20 nến Price Action, EMA20/50, Volume, RSI, MACD).
        - Khung trung (df_1h): 1H (Cấu trúc sóng & RSI).
        - Khung lớn (df_4h): 4H (La bàn xu hướng lớn EMA20/50, Trend Filter).
        - Khung vi mô (df_5m): 5M (Xác nhận hấp thụ râu nến & vi cấu trúc điểm vào).
        """
        if df is None or len(df) < 25:
            # [SỬA LỖI GỐC RỄ - FAIL-OPEN] Trước đây trả None khi thiếu nến, khiến SignalAggregator
            # không phân biệt được "JEV chưa từng chạy" với "JEV đã chạy và đồng ý", nên ứng viên
            # vẫn được cấp lệnh dù thiếu hoàn toàn tầng xác nhận đa khung. Nay trả HOLD kèm
            # availability_status để cổng JEV AVAILABILITY VETO chặn đúng.
            return self._unavailable_result(
                "insufficient_data",
                f"len(df)={0 if df is None else len(df)} < 25 nến; chưa đủ dữ liệu đa khung",
            )

        cooldown_remaining = self._cooldown_remaining()
        if cooldown_remaining > 0:
            logger.info(
                "[JEV COOLDOWN FAIL-CLOSED] Bỏ qua Ollama cho %s trong %.1fs còn lại; không dùng tín hiệu JEV cũ.",
                symbol, cooldown_remaining,
            )
            return self._unavailable_result("cooldown", f"Ollama đang nghỉ sau lỗi; còn {cooldown_remaining:.1f}s")

        try:
            df = df.copy()
            df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=14).rsi()
            macd_ind = ta.trend.MACD(df['close'])
            df['macd'] = macd_ind.macd()
            df['macd_diff'] = macd_ind.macd_diff()
            df['ema_20'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
            df['ema_50'] = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator()
            df['vol_ma'] = df['volume'].rolling(window=20).mean()

            # QUY TẮC BẤT DI BẤT DỊCH: Nến iloc[-1] là nến đang chạy (chưa đóng cửa), chỉ mới mở vài giây/phút nên volume rất nhỏ (0.01x - 0.20x).
            # Bắt buộc lấy 8 nến ĐÃ ĐÓNG CỬA HOÀN CHỈNH (iloc[:-1], trong đó nến tín hiệu vừa đóng là iloc[-2]) để tính Volume Ratio và cấu trúc nến!
            closed_df = df.iloc[:-1] if len(df) > 2 else df
            recent_df = closed_df.tail(8)
            
            swing_high = float(recent_df['high'].max())
            swing_low = float(recent_df['low'].min())
            last_vol = float(recent_df['volume'].iloc[-1])
            vol_hist_20 = df['volume'].iloc[:-2].tail(20) if len(df) > 3 else recent_df['volume']
            last_vol_ma = float(vol_hist_20.mean() or recent_df['vol_ma'].iloc[-1] or 1.0)
            vol_ratio = (last_vol / last_vol_ma) if last_vol_ma > 0 else 1.0

            price_data = []
            for idx, row in recent_df.iterrows():
                rsi = row.get('rsi', 50.0)
                macd_d = row.get('macd_diff', 0.0)
                ema20 = row.get('ema_20', row['close'])
                ema50 = row.get('ema_50', row['close'])
                c = row['close']
                v = row['volume']
                price_data.append(f"C:{c:.5f} V:{v:.0f} RSI:{rsi:.1f} E20:{ema20:.5f} E50:{ema50:.5f} MD:{macd_d:.5f}")
            
            data_str = "\n".join(price_data)

            curr_close = float(recent_df['close'].iloc[-1])
            curr_ema20 = float(recent_df['ema_20'].iloc[-1])
            curr_ema50 = float(recent_df['ema_50'].iloc[-1])

            # Tính toán bối cảnh đa khung: 4H, 1H và 5M
            m4h = self._extract_tf_metrics(df_4h, "4H")
            m1h = self._extract_tf_metrics(df_1h, "1H")
            m5m = self._extract_tf_metrics(df_5m, "5M")

            if "trend" in m4h:
                ctx_4h = f"- 4H Macro Trend: {m4h['trend']} | Price: {m4h['price']:.5f} | EMA20: {m4h['ema20']:.5f} | EMA50: {m4h['ema50']:.5f} | RSI: {m4h['rsi']:.1f}"
            else:
                ctx_4h = "- 4H Macro Trend: Not Available"

            if "trend" in m1h:
                ctx_1h = f"- 1H Wave Structure: {m1h['trend']} | Price: {m1h['price']:.5f} | RSI: {m1h['rsi']:.1f} | EMA20: {m1h['ema20']:.5f}"
            else:
                ctx_1h = "- 1H Wave Structure: Not Available"

            if "trend" in m5m:
                lw_p = m5m.get('lwick', 0.0) * 100
                uw_p = m5m.get('uwick', 0.0) * 100
                rvol_5m = m5m.get('rvol', 1.0)
                dir_5m = "GREEN (Bullish)" if m5m.get('is_green') else "RED (Bearish)"
                ctx_5m = f"- 5M Micro Action: {m5m['trend']} | Candle: {dir_5m} | Price: {m5m['price']:.5f} | RSI: {m5m['rsi']:.1f} | RVol: {rvol_5m:.2f}x | LowerWick(Absorption): {lw_p:.1f}% | UpperWick(Rejection): {uw_p:.1f}%"
            else:
                ctx_5m = "- 5M Micro Action: Not Available"

            # Phân loại tài sản: Cổ phiếu Mỹ / Hàng hóa (TradFi) vs Tiền điện tử (Crypto)
            is_tradfi = MarketScanner.is_tradfi_stock(symbol) or (
                hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol)
            )

            if is_tradfi:
                role_desc = "You are a Wall Street Quantitative Portfolio Manager specializing in US Equities, Commodities & Stock Perps."
                asset_ctx = f"=== ASSET TYPE: TRADFI EQUITIES / COMMODITIES PERPETUAL ({symbol}) ===\n- Independent TradFi Market: Do NOT link or anchor this asset to Bitcoin or Crypto trends. Evaluate purely based on price action, volume liquidity, and trend continuation."
            else:
                role_desc = "You are a Quantitative Portfolio Manager specializing in Crypto Assets."
                asset_ctx = f"=== ASSET TYPE: CRYPTO FUTURES ({symbol}) ==="

            prompt = f"""{role_desc} Analyze multi-timeframe structure for {symbol} to output BUY, SELL, or HOLD.

{asset_ctx}

=== LAYER 1: 4H MACRO STRATEGY ===
{ctx_4h}

=== LAYER 2: 1H MARKET STRUCTURE ===
{ctx_1h}

=== LAYER 3: 15M TACTICAL EXECUTION ===
- Price: {curr_close:.6f} | Range 8-candles: [{swing_low:.6f} - {swing_high:.6f}]
- EMA20: {curr_ema20:.6f} | EMA50: {curr_ema50:.6f} | Volume Ratio: {vol_ratio:.2f}x
- 15M Recent 8 Candles:
{data_str}

=== LAYER 4: 5M MICRO ABSORPTION & TIMING CONFIRMATION ===
{ctx_5m}

DECISION RULES & MULTI-TIMEFRAME AUDIT (TWO-WAY PERPETUAL FUTURES: LONG & SHORT ARE EQUALLY IMPORTANT):
1. TWO-WAY DEVIL'S ADVOCATE & REVERSAL AUDIT:
   - Upside Exhaustion / Top Rejection: Scrutinize RSI > 68, overhead 4H/1H resistance, or upper rejection wicks (>=30%). If heavy top rejection or bull exhaustion is present, DO NOT BUY; if 4H/15M structure is Bearish or rejecting a swing high, actively output SELL (Go Short)!
   - Downside Absorption / Bottom Bounce: Scrutinize RSI < 32, major 4H/1H support bounce, or lower absorption wicks (>=30%). If strong support absorption is present, DO NOT SELL; if 4H/15M structure is Bullish or reclaiming EMA20, actively output BUY (Go Long)!
2. BUY (Go Long): 4H structure is BULLISH or MODERATELY BULLISH (do NOT output BUY when BOTH 4H and 15M are BEARISH or MODERATELY BEARISH unless 15M RSI < 30 with >=35% 15M lower absorption wick) AND 15M structure cleanly breaks/holds above EMA20/50 with expanding volume (>1.1x) or 15M lower absorption wick (>=30%), with no overhead bull trap.
   - 5M Micro-Timing: A single 5M lower wick alone CANNOT override a Bearish 4H + Bearish 15M structure! If 4H/15M support BUY and 5M confirms with lower absorption wick (>=25%) or holds micro EMA20, boost BUY confidence. (If 5M is actively dumping in a red waterfall without wicks, do not BUY).
3. SELL (Go Short): Actively output SELL when EITHER:
   (a) Bearish Breakdown / Trend Continuation: 4H is Bearish or Moderately Bearish AND 15M holds/breaks below EMA20/50 (or 5M shows active selling / red candles without lower absorption wicks); OR
   (b) Bull Trap / Top Rejection: 15M or 5M shows clear upper rejection wicks (>=30% of candle range), bull exhaustion, or fake breakout at resistance signaling institutional distribution.
   - 5M Micro-Timing: If 5M shows upper rejection wicks, bearish structure, or active dumping without lower wicks while 4H/15M are bearish, this CONFIRMS SELL (boost SELL confidence; do NOT output HOLD!).
4. Invalidation: Invalidation triggers if price breaches key swing levels or opposite EMAs.
5. HOLD: Output HOLD ONLY for flat sideways consolidation, choppy range with no clear breakout/breakdown, or genuine multi-timeframe deadlock. Do NOT output HOLD when 4H/15M are bearish with top rejection or active selling (that is SELL).

CRITICAL: First write "reason" and "risk_factors" to justify the 4H/15M/5M structure, then decide "decision" and "confidence". Output STRICTLY a JSON object matching:
{{
    "reason": "precise 1-sentence technical justification across 4H, 15M, and 5M",
    "risk_factors": "1-sentence noting any observed risk or exhaustion factors (or 'none')",
    "decision": "BUY" | "SELL" | "HOLD",
    "confidence": float (0.0 to 1.0)
}}"""

            payload = {
                "model": self.model_name,
                "prompt": prompt,
                "format": "json",
                "think": False,
                "stream": False,
                "keep_alive": "30m",
                "options": {
                    "temperature": 0.0,
                    "num_predict": self._num_predict,
                    "top_k": 1,
                    "num_ctx": 2048,
                },
            }

            try:
                # Cùng một GPU/model: JEV, macro AI và pre-warm phải đi qua một
                # hàng đợi chung thay vì đá nhau gây ReadTimeout hàng loạt.
                queue_started = time.monotonic()
                with OLLAMA_GPU_LOCK:
                    queue_seconds = time.monotonic() - queue_started
                    generation_started = time.monotonic()
                    response = requests.post(
                        self.endpoint,
                        json=payload,
                        timeout=(5.0, self._read_timeout_seconds),
                    )
                    generation_seconds = time.monotonic() - generation_started
                logger.info(
                    "[JEV OLLAMA PERF] %s queue=%.2fs generation=%.2fs timeout=%.0fs predict=%d",
                    symbol, queue_seconds, generation_seconds, self._read_timeout_seconds, self._num_predict,
                )
            except requests.exceptions.Timeout as e:
                self._start_failure_cooldown()
                logger.error(
                    "[JEV TIMEOUT FAIL-CLOSED] Ollama vượt %.0fs cho %s; bỏ ứng viên này và nghỉ %.0fs để Pha 2 tiếp tục: %s",
                    self._read_timeout_seconds, symbol, self._failure_cooldown_seconds, e,
                )
                return self._unavailable_result("timeout", str(e))
            except requests.exceptions.RequestException as e:
                self._start_failure_cooldown(30.0)
                logger.error("[JEV REQUEST FAIL-CLOSED] Ollama request lỗi cho %s; nghỉ 30s: %s", symbol, e)
                return self._unavailable_result("request_error", str(e))

            if response.status_code != 200:
                self._start_failure_cooldown(30.0)
                logger.error("Ollama API Error cho %s: HTTP %s", symbol, response.status_code)
                return self._unavailable_result("http_error", f"HTTP {response.status_code}")

            try:
                result = response.json()
            except ValueError:
                self._start_failure_cooldown(30.0)
                logger.error("Ollama trả payload không phải JSON cho %s.", symbol)
                return self._unavailable_result("invalid_response", "API response is not valid JSON")
            if not isinstance(result, dict) or not isinstance(result.get("response"), str):
                self._start_failure_cooldown(30.0)
                logger.error("Ollama trả sai cấu trúc response cho %s.", symbol)
                return self._unavailable_result("invalid_response", "API response has an invalid schema")
            response_text = result["response"].strip()
            import re
            import datetime
            import os

            # 1. Trích xuất chuỗi suy luận <think> an toàn độc lập (Non-Greedy)
            raw_thinking = ""
            try:
                think_match = re.search(r'<think>([\s\S]*?)</think>', response_text)
                if think_match:
                    raw_thinking = think_match.group(1).strip()
                elif '<think>' in response_text:
                    raw_thinking = response_text.split('<think>')[-1].split('{')[0].strip()
            except Exception as think_err:
                raw_thinking = f"Extraction note: {think_err}"

            # 2. XÓA SẠCH 100% thẻ <think> khỏi chuỗi để bảo vệ an toàn cho JSON Parser
            clean_text = re.sub(r'<think>[\s\S]*?</think>', '', response_text).strip()
            if '<think>' in clean_text:
                clean_text = clean_text[clean_text.find('{'):] if '{' in clean_text else clean_text

            json_match = re.search(r'\{[\s\S]*\}', clean_text)
            if json_match:
                clean_text = json_match.group(0)
            try:
                # Pre-repair: Xóa dấu phẩy thừa trước ngoặc đóng
                clean_text_repaired = re.sub(r',\s*([\}\]])', r'', clean_text)
                data = json.loads(clean_text_repaired)
            except json.JSONDecodeError as jde:
                # [BÀI HỌC 110 - BUG-06: REGEX AUTO-REPAIR CHO JEV AGENT]
                data = {}
                dec_m = re.search(r'"decision"\s*:\s*"?(BUY|SELL|HOLD)"?', clean_text, re.I)
                conf_m = re.search(r'"confidence"\s*:\s*([0-9.]+)', clean_text)
                reas_m = re.search(r'"reason(?:ing)?"\s*:\s*"([^"\n\r]+)"', clean_text)
                risk_m = re.search(r'"risk(?:_factors)?"\s*:\s*"([^"\n\r]+)"', clean_text)
                if dec_m:
                    data['decision'] = dec_m.group(1).upper()
                    data['confidence'] = float(conf_m.group(1)) if conf_m else 0.75
                    data['reason'] = reas_m.group(1) if reas_m else 'Parsed via regex fallback'
                    data['reasoning'] = data['reason']
                    data['risk_factors'] = risk_m.group(1) if risk_m else 'none'
                    logger.warning(
                        "⚠️ [JEV REGEX AUTO-REPAIR] Đã khôi phục thành công JSON lỗi cú pháp cho %s: %s (Conf: %.2f)!",
                        symbol, data['decision'], data['confidence']
                    )
                else:
                    logger.warning("JEV Agent trả JSON không hợp lệ cho %s (bỏ qua coin này, không phạt cooldown toàn sàn): %s", symbol, jde)
                    try:
                        decisions_dir = os.path.join("logs", "ai_decisions")
                        os.makedirs(decisions_dir, exist_ok=True)
                        log_date = datetime.datetime.now().strftime("%Y%m%d")
                        decision_file = os.path.join(decisions_dir, f"jev_decisions_{log_date}.jsonl")
                        err_entry = {
                            "timestamp": datetime.datetime.now().isoformat(),
                            "symbol": symbol,
                            "model": self.model_name,
                            "decision": "INVALID_JSON",
                            "confidence": 0.0,
                            "reason": f"JSONDecodeError: {jde}",
                            "raw_response": response_text[:2000],
                            "clean_text": clean_text[:1000],
                        }
                        with open(decision_file, "a", encoding="utf-8") as df_log:
                            df_log.write(json.dumps(err_entry, ensure_ascii=False) + "\n")
                    except Exception:
                        pass
                    return self._unavailable_result("invalid_response", "model output is not valid JSON")

            # 3. Lưu vết suy luận AI an toàn vào Full-Spectrum AI Telemetry (logs/ai_decisions)
            # và logs/ai_thoughts (tương thích ngược khi có thẻ <think>)
            try:
                decisions_dir = os.path.join("logs", "ai_decisions")
                os.makedirs(decisions_dir, exist_ok=True)
                log_date = datetime.datetime.now().strftime("%Y%m%d")
                decision_file = os.path.join(decisions_dir, f"jev_decisions_{log_date}.jsonl")
                telemetry_entry = {
                    "timestamp": datetime.datetime.now().isoformat(),
                    "symbol": symbol,
                    "model": self.model_name,
                    "decision": str(data.get("decision", "")).upper(),
                    "confidence": data.get("confidence"),
                    "reason": data.get("reason"),
                    "risk_factors": data.get("risk_factors", "none"),
                    "has_think_tags": bool(raw_thinking),
                    "thinking": raw_thinking,
                    "raw_response": response_text[:2000],
                    "queue_seconds": round(queue_seconds, 3) if 'queue_seconds' in locals() else None,
                    "generation_seconds": round(generation_seconds, 3) if 'generation_seconds' in locals() else None,
                }
                with open(decision_file, "a", encoding="utf-8") as df_log:
                    df_log.write(json.dumps(telemetry_entry, ensure_ascii=False) + "\n")

                if raw_thinking:
                    thoughts_dir = os.path.join("logs", "ai_thoughts")
                    os.makedirs(thoughts_dir, exist_ok=True)
                    thought_file = os.path.join(thoughts_dir, f"jev_thoughts_{log_date}.jsonl")
                    with open(thought_file, "a", encoding="utf-8") as tf:
                        tf.write(json.dumps(telemetry_entry, ensure_ascii=False) + "\n")
            except Exception as log_err:
                logger.debug("Không thể ghi log suy luận JEV: %s", log_err)

            if not all(key in data for key in ("decision", "confidence", "reason")):
                self._start_failure_cooldown(30.0)
                logger.warning("JEV Agent trả sai schema cho %s.", symbol)
                return self._unavailable_result("invalid_response", "model output has an invalid schema")

            decision = str(data["decision"]).upper()
            if decision not in ["BUY", "SELL", "HOLD"]:
                self._start_failure_cooldown(30.0)
                logger.warning("JEV Agent trả decision ngoài BUY/SELL/HOLD cho %s: %r", symbol, decision)
                return self._unavailable_result("invalid_response", "decision must be BUY, SELL or HOLD")
            try:
                confidence = float(data["confidence"])
            except (TypeError, ValueError):
                self._start_failure_cooldown(30.0)
                logger.warning("JEV Agent trả confidence sai định dạng cho %s.", symbol)
                return self._unavailable_result("invalid_response", "confidence is not numeric")
            if not 0.0 <= confidence <= 1.0:
                self._start_failure_cooldown(30.0)
                logger.warning("JEV Agent trả confidence ngoài [0, 1] cho %s.", symbol)
                return self._unavailable_result("invalid_response", "confidence is outside [0, 1]")

            risk_factors = str(data.get("risk_factors", "none"))
            reason_str = str(data.get("reason", ""))
            combined_txt = f"{reason_str} {risk_factors}".lower()
            has_chop_or_conflict_kw = any(
                kw in combined_txt
                for kw in (
                    "choppy", "consolidat", "mixed signal", "conflicting", "sideways",
                    "flat", "no clear", "no strong", "lacks clear", "neutral",
                    "wait for", "indecision", "range-bound", "testing ema"
                )
            )
            if decision == "HOLD" and confidence >= 0.55 and not has_chop_or_conflict_kw:
                m4h_trend_str = str(m4h.get("trend", "")).upper()
                c_last_15m = recent_df.iloc[-1]
                rng_15m = max(1e-9, float(c_last_15m["high"] - c_last_15m["low"]))
                uwick_15m = float((c_last_15m["high"] - max(c_last_15m["open"], c_last_15m["close"])) / rng_15m)
                lwick_15m = float((min(c_last_15m["open"], c_last_15m["close"]) - c_last_15m["low"]) / rng_15m)
                uwick_5m = float(m5m.get("uwick", 0.0) or 0.0)
                lwick_5m = float(m5m.get("lwick", 0.0) or 0.0)

                min_jev_align_rvol = 0.55 if is_tradfi else 0.80
                has_valid_jev_vol = (vol_ratio >= min_jev_align_rvol) or (float(m5m.get("rvol", 0.0) or 0.0) >= 1.15)

                has_bearish_semantic = any(
                    kw in combined_txt
                    for kw in (
                        "bearish structure", "moderately bearish", "bull trap", "top rejection",
                        "upper rejection wick", "upside exhaustion", "bull exhaustion",
                        "active dumping", "active selling", "high-volume red",
                        "heavy bearish", "strong bearish"
                    )
                )
                has_bullish_counter = any(
                    kw in combined_txt
                    for kw in (
                        "bullish structure", "moderately bullish", "breaks above ema",
                        "lower absorption wick", "support bounce", "bear trap", "oversold"
                    )
                )
                has_bullish_semantic = any(
                    kw in combined_txt
                    for kw in (
                        "bullish structure", "moderately bullish", "breaks above ema",
                        "bear trap", "bottom absorption", "lower absorption wick",
                        "downside exhaustion", "support bounce", "active buying",
                        "high-volume green", "heavy bullish", "strong bullish"
                    )
                )
                has_bearish_counter = any(
                    kw in combined_txt
                    for kw in (
                        "bearish structure", "moderately bearish", "breaks below ema",
                        "upper rejection", "bull trap", "upside exhaustion", "dumping", "overbought"
                    )
                )
                if (
                    has_valid_jev_vol
                    and has_bearish_semantic
                    and not has_bullish_counter
                    and ("BEARISH" in m4h_trend_str or curr_close < curr_ema20 or uwick_15m >= 0.30 or uwick_5m >= 0.25)
                    and (curr_close < curr_ema20 or uwick_15m >= 0.30 or uwick_5m >= 0.25)
                ):
                    decision = "SELL"
                    confidence = round(max(0.70, min(0.85, confidence + 0.10)), 2)
                    logger.info(
                        "[JEV SEMANTIC ALIGNMENT] %s: Chuyển hóa HOLD -> SELL (%.2f, RVol=%.2fx) do cấu trúc 4H/15M & phân tích LLM xác nhận Bearish/Top Rejection rõ rệt!",
                        symbol, confidence, vol_ratio
                    )
                elif (
                    has_valid_jev_vol
                    and has_bullish_semantic
                    and not has_bearish_counter
                    and ("BULLISH" in m4h_trend_str or curr_close > curr_ema20 or lwick_15m >= 0.35 or lwick_5m >= 0.25)
                    and (curr_close > curr_ema20 or lwick_15m >= 0.30 or lwick_5m >= 0.25)
                ):
                    decision = "BUY"
                    confidence = round(max(0.70, min(0.85, confidence + 0.10)), 2)
                    logger.info(
                        "[JEV SEMANTIC ALIGNMENT] %s: Chuyển hóa HOLD -> BUY (%.2f, RVol=%.2fx) do cấu trúc 4H/15M & phân tích LLM xác nhận Bullish/Bottom Absorption rõ rệt!",
                        symbol, confidence, vol_ratio
                    )

            logger.info(f"[JEV Agent - {self.model_name}] {symbol} -> {decision} ({confidence}) - {data['reason']} | Risk: {risk_factors}")
            return {
                "decision": decision,
                "confidence": confidence,
                "reason": str(data["reason"]),
                "risk_factors": risk_factors,
                "thinking": raw_thinking,
                "availability_status": "ok",
            }
        except Exception as e:
            logger.error(f"Loi phan tich JEV Agent cho {symbol}: {e}")
            # [SỬA LỖI GỐC RỄ - FAIL-OPEN] Trả None ở đây khiến SignalAggregator coi như JEV không
            # tham gia bỏ phiếu và vẫn duyệt lệnh dựa trên các tín hiệu còn lại (đúng lỗi đã gặp
            # với BEAT/USDT). Nay mở cooldown ngắn và trả HOLD kèm availability_status để
            # cổng JEV AVAILABILITY VETO chặn ứng viên này.
            self._start_failure_cooldown(30.0)
            return self._unavailable_result("exception", f"{type(e).__name__}: {e}")
