from ai.order_flow_analyzer import OrderFlowAnalyzer
import logging

import re

import math

import statistics

import sys

import time

from typing import Dict, List, Optional, Tuple



if sys.platform == 'win32':

    try:

        sys.stdout.reconfigure(encoding='utf-8')

        sys.stderr.reconfigure(encoding='utf-8')

    except Exception:

        pass



from strategies.base_strategy import TradeSignal, Signal

from core.scanner import MarketScanner



logger = logging.getLogger(__name__)





def _chop_entry_is_measured(entry) -> bool:

    """True nếu bối cảnh BTC/ETH là số đo THẬT (không phải 0.0 do thiếu dữ liệu).



    MarketRegimeDetector.detect_regime() trả ``adx=0.0, atr_pct=0.0`` khi không đủ

    100 nến để tính chỉ báo. Nếu coi 0.0 là "đã đo và đang nén" thì CRYPTO CHOP

    SHIELD sẽ bật ở mọi chu kỳ và khóa 100% lệnh Altcoin vô thời hạn — đúng cái bẫy

    "Chop Shield vô hạn" của Bài học 11/39. Vì vậy 0.0 bị coi là CHƯA ĐO ĐƯỢC.

    """

    if not isinstance(entry, dict) or not entry:

        return False

    try:

        adx_val = float(entry.get('adx') or 0.0)

    except (TypeError, ValueError, OverflowError):

        adx_val = 0.0

    try:

        atr_val = float(entry.get('atr_pct') or 0.0)

    except (TypeError, ValueError, OverflowError):

        atr_val = 0.0

    return adx_val > 0.0 or atr_val > 0.0





class SignalAggregator:

    """Combine strategy votes without letting HOLD signals dilute them."""



    _recent_chop_vetoes: Dict[str, float] = {}

    _crypto_market_chop_until: float = 0.0

    INVERSE_PAIRS: Dict[str, str] = {

        'SOXL/USDT': 'SOXS/USDT',

        'SOXS/USDT': 'SOXL/USDT',

    }



    def __init__(self, config: dict = None):

        config = config or {}
        self.config = config
        ai_config = config.get('ai', {})
        self.ai_config = ai_config
        self.consensus_require_technical = bool(ai_config.get('consensus_require_technical', True))

        self.confidence_threshold = float(ai_config.get('confidence_threshold', 0.6))

        # [NGƯỠNG CHẤT LƯỢNG TÍN HIỆU] Sàn điểm tối thiểu của |weighted score| để được cấp lệnh.

        # Tách RIÊNG khỏi confidence_threshold vì confidence_threshold còn được dùng cho ngưỡng

        # động của AI Ensemble và chất lượng đòn bẩy; nếu gộp chung sẽ làm lệch các tầng đó.

        # Hiệu lực = max(confidence_threshold, min_signal_score).

        self.min_signal_score = float(ai_config.get('min_signal_score', 0.80))

        if not (0.0 <= self.min_signal_score <= 1.0):

            self.min_signal_score = 0.80

        self.min_agreeing_strategies = max(

            1, int(ai_config.get('min_agreeing_strategies', 2))

        )

        self._trap_contexts_by_symbol = {}

        self._last_trap_context = {}

        # [P2] HTF CONFLICT VETO: chặn mở lệnh khi CÙNG MỘT chiến thuật báo ngược chiều

        # trên 2 khung thời gian khác nhau với độ tự tin >= ngưỡng. Trước đây

        # `_strategy_votes()` lấy trung bình cộng các khung (trap 1h SELL 67% + 15m BUY 70%

        # -> +0.015), xóa sạch thông tin xung đột và vẫn cho vào lệnh.

        self.htf_conflict_veto = bool(ai_config.get('htf_conflict_veto', True))

        try:

            self.htf_conflict_min_confidence = float(

                ai_config.get('htf_conflict_min_confidence', 0.60)

            )

        except (TypeError, ValueError, OverflowError):

            self.htf_conflict_min_confidence = 0.60

        if not (0.0 < self.htf_conflict_min_confidence <= 1.0):

            self.htf_conflict_min_confidence = 0.60



        self.strategy_weights = {}

        for name, strat_config in config.get('strategies', {}).items():

            if isinstance(strat_config, dict):

                self.strategy_weights[name] = float(strat_config.get('weight', 0.25))



        if not self.strategy_weights:

            self.strategy_weights = {

                'trend_following': 0.3,

                'mean_reversion': 0.25,

                'ai_ensemble': 0.2,

                'jev_agent': 0.3,

                'smart_dca': 0.15,

                'hft_scalping': 0.25,

                'trap_detector': 0.25,

                'momentum_breakout': 0.25,

            }

        self._recent_chop_vetoes = {}

        self._crypto_market_chop_until = 0.0
        try:
            self.order_flow_analyzer = OrderFlowAnalyzer()
        except Exception:
            self.order_flow_analyzer = None



    def _strategy_votes(

        self,

        signals: List[TradeSignal],

        apply_entry_vetoes: bool = True,

        log_vetoes: Optional[bool] = None,

        market_chop_context: Optional[Dict[str, Dict[str, float]]] = None,

    ) -> Dict[str, Tuple[float, float]]:

        """Return one weighted vote per strategy, combining its actionable timeframes."""

        if not signals:

            return {}

        if log_vetoes is None:

            log_vetoes = bool(apply_entry_vetoes)

        by_strategy: Dict[str, List[float]] = {}



        for sig in signals:

            if sig.signal == Signal.BUY:

                direction = 1.0

            elif sig.signal == Signal.SELL:

                direction = -1.0

            else:

                # Tuyệt đối không đưa Signal.HOLD (direction = 0.0) vào mẫu số tổng hợp để tránh làm loãng

                # 31% - 40% điểm raw_score khi giám sát vị thế mở (Cổng JEV HOLD Veto >= 0.70 đã xử lý riêng ở bước lọc vào lệnh).

                continue



            try:

                confidence = float(sig.confidence)

            except (TypeError, ValueError):

                continue

            if math.isnan(confidence) or not (0.0 <= confidence <= 1.0):

                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', sig.strategy).lower()

            by_strategy.setdefault(name, []).append(direction * confidence)



        votes: Dict[str, Tuple[float, float]] = {}



        symbol_name = str(getattr(signals[0], 'symbol', '') or '')
        clean_base = symbol_name.split(':')[0].strip().upper()
        clean_base = clean_base.split('/')[0] if '/' in clean_base else clean_base
        is_tier1 = any(clean_base == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
        is_stock = MarketScanner.is_tradfi_stock(symbol_name)
        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol_name)
        is_tradfi = is_stock or is_commodity
        is_crypto_altcoin = (not is_tier1) and (not is_tradfi)



        # Trích xuất phân tích nến đóng iloc[-2] từ market_analysis để nhận diện sớm Buying/Selling Climax & Bão Volume

        macro_analysis_pre = next(

            (

                s.metadata.get('market_analysis')

                for s in signals

                if isinstance(getattr(s, 'metadata', None), dict)

                and isinstance(s.metadata.get('market_analysis'), dict)

            ),

            {},

        )

        c_upper_wick_pre = float(macro_analysis_pre.get('upper_wick_pct') or 0.0)

        c_lower_wick_pre = float(macro_analysis_pre.get('lower_wick_pct') or 0.0)

        _raw_c_vol_pre = macro_analysis_pre.get('candle_vol_ratio')
        c_vol_ratio_pre = float(_raw_c_vol_pre) if _raw_c_vol_pre is not None else 1.0

        c_recent_pump_pre = float(macro_analysis_pre.get('recent_pump_pct') or 0.0)

        c_recent_dump_pre = float(macro_analysis_pre.get('recent_dump_pct') or 0.0)

        in_fading_short_wl_pre = bool(macro_analysis_pre.get('in_fading_short_watchlist', False))
        is_live_rebounding_pre = bool(macro_analysis_pre.get('is_live_rebounding', False))

        try:
            tactical_rsi_pre = float(macro_analysis_pre.get('tactical_rsi') or macro_analysis_pre.get('rsi') or 50.0)
        except (TypeError, ValueError):
            tactical_rsi_pre = 50.0

        # Fallback lấy trực tiếp từ metadata của các chiến thuật nếu market_analysis chưa nạp đầy đủ
        if c_upper_wick_pre <= 0.0:
            c_upper_wick_pre = max((float((s.metadata or {}).get('c_upper_wick_pct') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if c_lower_wick_pre <= 0.0:
            c_lower_wick_pre = max((float((s.metadata or {}).get('c_lower_wick_pct') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if c_recent_dump_pre <= 0.0:
            c_recent_dump_pre = max((float((s.metadata or {}).get('c_recent_dump') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if c_recent_pump_pre <= 0.0:
            c_recent_pump_pre = max((float((s.metadata or {}).get('c_recent_pump') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if tactical_rsi_pre == 50.0:
            tactical_rsi_pre = next((float((s.metadata or {}).get('tactical_rsi') or 50.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict) and (s.metadata or {}).get('tactical_rsi') is not None), 50.0)

        # [BÀI HỌC 78, 79, 82, 85 & 103]: Nhận diện chuẩn xác Lưỡng Pha Cá Mập Đối Xứng ngay từ đầu _strategy_votes()
        # Chuẩn hóa Ma trận 3 Lớp Tài Sản (Major Crypto, TradFi, Crypto Altcoins) và Đối xứng 2 Chiều (LONG / SHORT)
        is_altcoin_or_tradfi = True  # Mở khóa toàn bộ 3 lớp tài sản (bao gồm cả Major Crypto BTC, ETH, SOL, BNB, XRP)
        min_trap_rvol = 0.40 if is_tradfi else (0.85 if is_crypto_altcoin else 0.70)
        parabolic_thresh_pre = 0.032 if is_tier1 else (0.040 if is_tradfi else 0.055)
        parabolic_ext_pre = 0.042 if is_tier1 else (0.052 if is_tradfi else 0.070)
        # [KB5 CHUẨN HÓA XUNG ĐỘT 1]: Bắt buộc phải có Râu nến vật lý (>= 30%, hoặc >= 25% khi biến động cực đại),
        # tuyệt đối KHÔNG dùng 'or tactical_rsi >= 68.0 / <= 32.0' biến nến xanh/đỏ đặc (0% râu) thành Climax đảo chiều!
        is_panic_selling_climax_pre = (
            ((c_recent_dump_pre >= parabolic_thresh_pre and c_vol_ratio_pre >= 1.80 and c_lower_wick_pre >= 0.30)
             or (c_recent_dump_pre >= parabolic_ext_pre and c_lower_wick_pre >= 0.25))
        )
        is_parabolic_pump_climax_pre = (
            ((c_recent_pump_pre >= parabolic_thresh_pre and c_vol_ratio_pre >= 1.80 and c_upper_wick_pre >= 0.30)
             or (c_recent_pump_pre >= parabolic_ext_pre and c_upper_wick_pre >= 0.25))
        )

        # 0. Thác đổ không râu đỡ (Waterfall Dump): Cá mập đang xả dốc không có lực hấp thụ đáy
        # [V3.7 SSOT FIX #5]: Dùng đúng ATR tác chiến 15M (tactical_atr_pct) thay vì ATR 4H để đồng bộ 100% với core/bot.py
        tactical_atr_pct_pre = float(macro_analysis_pre.get('tactical_atr_pct') or macro_analysis_pre.get('atr_pct') or 0.0)
        macro_rsi_pre = float(macro_analysis_pre.get('rsi') or 50.0)
        eff_atr_dec_pre = (tactical_atr_pct_pre / 100.0) if tactical_atr_pct_pre > 0.20 else tactical_atr_pct_pre
        if is_crypto_altcoin:
            min_waterfall_dump_pre = min(0.038, max(0.020, 1.25 * eff_atr_dec_pre)) if eff_atr_dec_pre > 0 else 0.020
            max_waterfall_dump_pre = 0.055
            wf_rvol_std_pre = 1.30
        elif is_tradfi:
            min_waterfall_dump_pre = max(0.010, 1.10 * eff_atr_dec_pre) if eff_atr_dec_pre > 0 else 0.010
            max_waterfall_dump_pre = 0.045
            wf_rvol_std_pre = 1.25
        else:  # Major Crypto (BTC, ETH, SOL, BNB, XRP)
            min_waterfall_dump_pre = max(0.010, 1.20 * eff_atr_dec_pre) if eff_atr_dec_pre > 0 else 0.010
            max_waterfall_dump_pre = 0.035
            wf_rvol_std_pre = 1.35

        is_waterfall_oversold_bottom_pre = (macro_rsi_pre <= 30.0 or tactical_rsi_pre <= 32.0)
        is_waterfall_dump_shape_pre = (c_upper_wick_pre < 0.28) and (
            c_recent_dump_pre >= max(min_waterfall_dump_pre, c_recent_pump_pre * 1.30)
            or c_recent_dump_pre >= (0.030 if is_crypto_altcoin else 0.018)
            or c_recent_pump_pre <= (0.010 if is_crypto_altcoin else 0.006)
        )
        is_waterfall_dump_pre = (
            (not is_live_rebounding_pre)
            and (not is_panic_selling_climax_pre)
            and (not is_waterfall_oversold_bottom_pre)
            and is_waterfall_dump_shape_pre
            and (tactical_rsi_pre <= 58.0 or c_recent_dump_pre >= c_recent_pump_pre * 1.5)
            and (
                (min_waterfall_dump_pre <= c_recent_dump_pre <= max_waterfall_dump_pre and c_lower_wick_pre < 0.25 and c_vol_ratio_pre >= wf_rvol_std_pre)
                or ((min_waterfall_dump_pre * 1.35) <= c_recent_dump_pre <= max_waterfall_dump_pre and c_lower_wick_pre < 0.30 and c_vol_ratio_pre >= max(1.15, wf_rvol_std_pre - 0.10))
                or (min_waterfall_dump_pre <= c_recent_dump_pre <= max_waterfall_dump_pre and c_lower_wick_pre < 0.20 and c_vol_ratio_pre >= (wf_rvol_std_pre + 0.20))
            )
        )

        # 1. Nến kiệt sức mua phân phối đỉnh (Buying Climax) & Watchlist Pha 2: Bắt buộc có râu trên vật lý >= 30-35%!
        min_climax_wave_pre = 0.018 if is_crypto_altcoin else 0.010
        has_raw_bull_trap_sig = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and (s.metadata.get('timeframe', '15m') == '15m' or c_vol_ratio_pre >= min_trap_rvol)
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE', 'BUYING_CLIMAX')
            for s in signals
        )
        is_buying_climax_candle = (
            (c_upper_wick_pre >= 0.45 and c_upper_wick_pre > c_lower_wick_pre * 1.3 and c_vol_ratio_pre >= (1.25 if is_crypto_altcoin else 1.05) and (c_recent_pump_pre >= min_climax_wave_pre or tactical_rsi_pre >= 58.0))
            or (c_recent_pump_pre >= (0.035 if is_crypto_altcoin else 0.018) and c_upper_wick_pre >= 0.40 and c_vol_ratio_pre >= (1.20 if is_crypto_altcoin else 1.00))
            or (has_raw_bull_trap_sig and c_upper_wick_pre >= 0.35 and (c_recent_pump_pre >= min_climax_wave_pre or tactical_rsi_pre >= 58.0) and (c_vol_ratio_pre >= (max(0.85, min_trap_rvol) if tactical_rsi_pre >= 68.0 else 1.10)))
            or (in_fading_short_wl_pre and c_upper_wick_pre >= 0.35 and c_vol_ratio_pre >= 1.10)
            or (is_parabolic_pump_climax_pre and c_upper_wick_pre >= 0.30)
        )

        # 2. Nến kiệt sức bán gom hàng (Selling Climax): Bắt buộc có râu dưới vật lý >= 30-35%!
        has_raw_bear_trap_sig = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and (s.metadata.get('timeframe', '15m') == '15m' or c_vol_ratio_pre >= min_trap_rvol)
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'BEAR_TRAP_DIP', 'SELLING_CLIMAX')
            for s in signals
        )
        is_selling_climax_candle = (not is_waterfall_dump_pre) and (
            (c_lower_wick_pre >= 0.45 and c_lower_wick_pre > c_upper_wick_pre * 1.3 and c_vol_ratio_pre >= (1.25 if is_crypto_altcoin else 1.05) and (c_recent_dump_pre >= min_climax_wave_pre or tactical_rsi_pre <= 42.0))
            or (c_recent_dump_pre >= (0.035 if is_crypto_altcoin else 0.018) and c_lower_wick_pre >= 0.40 and c_vol_ratio_pre >= (1.20 if is_crypto_altcoin else 1.00))
            or (has_raw_bear_trap_sig and c_lower_wick_pre >= 0.35 and (c_recent_dump_pre >= min_climax_wave_pre or tactical_rsi_pre <= 42.0) and (c_vol_ratio_pre >= (max(0.85, min_trap_rvol) if tactical_rsi_pre <= 32.0 else 1.10)))
            or (is_panic_selling_climax_pre and c_lower_wick_pre >= 0.30)
        )

        # 3. Bão volume cá mập kéo dốc Pha 1 (Whale Pump Storm): Đối xứng hoàn toàn với Waterfall Dump cho 3 lớp tài sản
        min_whale_pump_pre = (min(0.035, max(0.025, 1.25 * eff_atr_dec_pre)) if eff_atr_dec_pre > 0 else 0.025) if is_crypto_altcoin else min_waterfall_dump_pre
        max_whale_pump_pre = max_waterfall_dump_pre
        wp_rvol_std_pre = 2.00 if is_crypto_altcoin else (1.50 if is_tradfi else 1.60)
        is_whale_pump_storm_pre = (
            not is_buying_climax_candle
            and not is_waterfall_dump_pre
            and not is_parabolic_pump_climax_pre
            and c_upper_wick_pre < 0.30
            and (c_recent_pump_pre >= max(min_whale_pump_pre, c_recent_dump_pre * 1.30) or c_recent_dump_pre <= (0.010 if is_crypto_altcoin else 0.006))
            and (
                (min_whale_pump_pre <= c_recent_pump_pre <= max_whale_pump_pre and c_vol_ratio_pre >= wp_rvol_std_pre)
                or (c_vol_ratio_pre >= (wp_rvol_std_pre + 0.50) and (min_whale_pump_pre * 0.75) <= c_recent_pump_pre <= max_whale_pump_pre)
            )
        )

        # --- MUTUALLY EXCLUSIVE & TRAP OVERRIDE RULES (THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN) ---
        # [BÀI HỌC 82, 85 & 105]: Bẫy Bull Trap / Bear Trap chỉ được công nhận là BẪY THẬT (được quyền xóa phiếu ngược chiều)
        # khi có RÂU NẾN VẬT LÝ trên khung 15M (hoặc 1H được 15M đồng thuận râu >= 30%).
        # [BÀI HỌC 105 & FIX AVAX]: Bẫy Bull Trap chỉ có ý nghĩa ở vùng ĐỈNH / QUÁ MUA (RSI >= 45, không trong đợt xả mạnh).
        # Lưu ý: Khi coin vừa Pump mạnh (ví dụ AVAX Pump=5.2%, RSI=85.1, U_Wick=60.7%), giá đóng cửa rút xuống từ đỉnh râu
        # khiến c_recent_dump_pre >= 1.5% nhưng thực chất đang ở ĐỈNH QUÁ MUA (RSI >= 58 hoặc Pump > Dump).
        # Do đó chỉ coi là is_in_dump_or_oversold khi RSI < 58 và đà Dump thực sự lớn hơn đà Pump!
        is_in_dump_or_oversold = (
            (
                (tactical_rsi_pre <= 42.0)
                or (c_recent_dump_pre >= 0.015 and c_recent_dump_pre >= c_recent_pump_pre * 1.15)
                or is_selling_climax_candle
            )
            and (tactical_rsi_pre < 58.0 or is_selling_climax_candle)
            and not is_buying_climax_candle
        )
        is_in_pump_or_overbought = (
            (
                (tactical_rsi_pre >= 58.0)
                or (c_recent_pump_pre >= 0.015 and c_recent_pump_pre >= c_recent_dump_pre * 1.15)
                or is_buying_climax_candle
                or is_whale_pump_storm_pre
            )
            and (tactical_rsi_pre > 42.0 or is_buying_climax_candle or is_whale_pump_storm_pre)
            and not is_selling_climax_candle
        )

        has_15m_bull_trap = (not is_in_dump_or_oversold) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '15m'
            and (
                s.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
                or (s.metadata.get('type') == 'BULL_TRAP_BOUNCE' and c_upper_wick_pre >= 0.35)
            )
            for s in signals
        )

        has_15m_bear_trap = (not is_waterfall_dump_pre) and (not is_in_pump_or_overbought) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '15m'
            and (
                s.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
                or (s.metadata.get('type') == 'BEAR_TRAP_DIP' and c_lower_wick_pre >= 0.35)
            )
            for s in signals
        )

        has_1h_bull_trap_valid = (not is_in_dump_or_oversold) and (c_upper_wick_pre >= 0.30) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '1h'
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
            for s in signals
        )

        has_1h_bear_trap_valid = (not is_waterfall_dump_pre) and (not is_in_pump_or_overbought) and (c_lower_wick_pre >= 0.30) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '1h'
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
            for s in signals
        )

        # [VẤN ĐỀ 1 - SÀN LỌC RVol CHO BẪY GIÁ SMART MONEY THEO 3 PHÂN LỚP TÀI SẢN]:
        # Tránh nhiễu thanh khoản mỏng (râu nến trôi dạt volume cực thấp) bị ngộ nhận thành Bẫy Bull/Bear Trap của Cá Mập.
        # Với TradFi (như SOXL 0.28x), thanh khoản sàn Binance mỏng nhưng tối thiểu phải >= 0.40x.
        # Với Altcoin: tối thiểu phải >= 0.85x. Với Major Crypto: tối thiểu >= 0.70x.
        # Ngoại lệ: Nếu nến đạt Buying/Selling Climax thực chất (pump/dump mạnh) thì được miễn trừ.
        min_trap_rvol = 0.40 if is_tradfi else (0.85 if is_crypto_altcoin else 0.70)
        has_valid_trap_vol = (c_vol_ratio_pre >= min_trap_rvol) or is_buying_climax_candle or is_selling_climax_candle

        has_real_bull_trap_raw = (not is_in_dump_or_oversold) and has_valid_trap_vol and (
            has_15m_bull_trap
            or has_1h_bull_trap_valid
            or is_buying_climax_candle
        )

        has_real_bear_trap_raw = (not is_waterfall_dump_pre) and (not is_in_pump_or_overbought) and has_valid_trap_vol and (
            has_15m_bear_trap
            or has_1h_bear_trap_valid
            or is_selling_climax_candle
        )

        trend_vote = sum(by_strategy.get('trend_following', [0.0])) / len(by_strategy.get('trend_following', [1.0])) if 'trend_following' in by_strategy else 0.0

        breakout_vote = sum(by_strategy.get('momentum_breakout', [0.0])) / len(by_strategy.get('momentum_breakout', [1.0])) if 'momentum_breakout' in by_strategy else 0.0

        jev_vote = sum(by_strategy.get('jev_agent', [0.0])) / len(by_strategy.get('jev_agent', [1.0])) if 'jev_agent' in by_strategy else 0.0
        orig_jev_vote = jev_vote

        ai_vote = sum(by_strategy.get('ai_ensemble', [0.0])) / len(by_strategy.get('ai_ensemble', [1.0])) if 'ai_ensemble' in by_strategy else 0.0

        mean_rev_vote = sum(by_strategy.get('mean_reversion', [0.0])) / len(by_strategy.get('mean_reversion', [1.0])) if 'mean_reversion' in by_strategy else 0.0

        trap_vote_raw = sum(by_strategy.get('trap_detector', [0.0])) / len(by_strategy.get('trap_detector', [1.0])) if 'trap_detector' in by_strategy else 0.0

        # [BÀI HỌC 105, 106 & 107 - SMART ABSORPTION REVERSAL & EXHAUSTION FADING RÂU 1 CHIỀU]:
        # Nhận diện khi cá mập gom hàng hấp thụ đáy / xả đỉnh phân phối và AI Ensemble có độ tự tin cao (>= 70%):
        # [BÀI HỌC 106]: Bắt buộc phải có râu nến vật lý 1 chiều (râu gom/xả >= 30% và râu cản ngược lại < 25%),
        # tuyệt đối cấm đảo ngược cản đầu xe lửa Waterfall Dump (nến đỏ đặc không râu) hay Whale Pump (nến xanh đặc không râu)!
        # [BÀI HỌC 107]: Bắt buộc phải có sóng Pump/Dump thực chất trên nến đóng (>= 1.80%), tránh kích hoạt nhầm khi Pump = 0.00%!
        # [VẤN ĐỀ 1 - SÀN LỌC RVol ĐA TẦNG CHO EXHAUSTION FADING & ABSORPTION REVERSAL]:
        # Phân biệt rõ Major Crypto (BTC/ETH/SOL), TradFi (SOXL/NVDA), và Altcoins (MERL/ACT).
        # Khi cản xu hướng (Fading Sell ngược Uptrend, hoặc Absorption Buy ngược Downtrend):
        # BẮT BUỘC RVol 15M phải đạt ngưỡng đột biến phân phối/hấp thụ thực sự.
        # Nếu RVol thấp (như MERL 0.64x), râu nến chỉ là bull flag tích lũy, cấm kích hoạt Fading cản tàu!
        macro_regime_str = str(macro_analysis_pre.get('regime', '')).lower()
        is_uptrend_ctx = ('uptrend' in macro_regime_str) or (trend_vote > 0.25) or (jev_vote > 0.25)
        is_downtrend_ctx = ('downtrend' in macro_regime_str) or (trend_vote < -0.25) or (jev_vote < -0.25)

        if is_crypto_altcoin:
            rvol_fading_floor = 1.50 if is_uptrend_ctx else 1.20
            rvol_absorp_floor = 1.40 if is_downtrend_ctx else 1.15
        elif is_tradfi:
            rvol_fading_floor = 0.55
            rvol_absorp_floor = 0.55
        else: # Major Crypto (BTC, ETH, SOL...)
            rvol_fading_floor = 1.00
            rvol_absorp_floor = 1.00

        is_ai_absorption_buy = (
            ai_vote >= 0.70
            and (c_vol_ratio_pre >= rvol_absorp_floor or is_selling_climax_candle)
            and (c_recent_dump_pre >= min_climax_wave_pre or is_panic_selling_climax_pre)
            and (c_lower_wick_pre >= 0.30 or (tactical_rsi_pre <= 38.5 and c_lower_wick_pre >= 0.20) or is_selling_climax_candle)
            and (c_upper_wick_pre < 0.25)
            and not (c_recent_pump_pre >= 0.015 and c_recent_dump_pre < min_climax_wave_pre)
        )
        is_ai_exhaustion_sell = (
            ai_vote <= -0.70
            and (c_vol_ratio_pre >= rvol_fading_floor or is_buying_climax_candle)
            and (c_recent_pump_pre >= min_climax_wave_pre or is_parabolic_pump_climax_pre)
            and (c_upper_wick_pre >= 0.35 or is_buying_climax_candle)
            and (c_lower_wick_pre < 0.25)
            and (tactical_rsi_pre >= 55.0 or c_recent_pump_pre >= (0.040 if is_crypto_altcoin else 0.022) or is_parabolic_pump_climax_pre)
            and not (c_recent_dump_pre >= 0.015 and c_recent_pump_pre < min_climax_wave_pre)
        )

        # [TÔN CHỈ SỐ 0 & KB5 CHUẨN HÓA XUNG ĐỘT 2 - ĐỒNG BỘ BREAKOUT, JEV 4H SHIELD & BẪY CÁ MẬP VẬT LÝ]:
        # 1) Chỉ chặn TrapDetector cản tàu khi nến 15M KHÔNG CÓ râu xả/gom đỉnh đáy thực sự (eff_wick < 35% & không phải Climax).
        # 2) Khi JEV 4H đang báo BUY mạnh (>= 70%) và nến chưa có râu xả đỉnh vật lý (< 35%), tuyệt đối bảo vệ đà BUY của Breakout/Trend!
        is_opposed_by_strong_breakout = (
            c_upper_wick_pre < 0.35
            and not is_buying_climax_candle
            and not is_ai_exhaustion_sell
            and (
                (breakout_vote >= 0.50 and ai_vote >= 0.0)
                or (jev_vote >= 0.70 and (breakout_vote > 0.0 or trend_vote > 0.0))
            )
        )
        is_bear_opposed_by_breakout = (
            c_lower_wick_pre < 0.35
            and not is_selling_climax_candle
            and not is_ai_absorption_buy
            and (
                (breakout_vote <= -0.50 and ai_vote <= 0.0)
                or (jev_vote <= -0.70 and (breakout_vote < 0.0 or trend_vote < 0.0))
            )
        )

        has_real_bull_trap = has_real_bull_trap_raw and not is_opposed_by_strong_breakout
        has_real_bear_trap = has_real_bear_trap_raw and not is_bear_opposed_by_breakout

        # [BÀI HỌC 85 & FIX PHÁT HIỆN #10 - THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN ĐỐI XỨNG 2 CHIỀU]:
        # Tuyệt đối KHÔNG kích hoạt majority_wants_buy khi AI đang báo SELL (ai_vote < 0)
        # và KHÔNG kích hoạt majority_wants_sell khi AI đang báo BUY (ai_vote > 0)!
        bearish_vote_cnt = sum(1 for v in (ai_vote, trend_vote, breakout_vote, jev_vote) if v <= -0.25)
        bullish_vote_cnt = sum(1 for v in (ai_vote, trend_vote, breakout_vote, jev_vote) if v >= 0.25)
        total_core_vote = ai_vote + trend_vote + breakout_vote + jev_vote

        majority_wants_sell = (
            (ai_vote <= 0.0 or is_waterfall_dump_pre)
            and (
                (bearish_vote_cnt >= 2 and total_core_vote <= -0.50)
                or is_waterfall_dump_pre
                or (ai_vote <= -0.72 and trend_vote <= 0.0 and jev_vote <= 0.0)
            )
            and not (trend_vote >= 0.35 and jev_vote >= 0.50)
            and not (jev_vote >= 0.70 and not is_waterfall_dump_pre)
        )
        if apply_entry_vetoes and trap_vote_raw > 0 and not has_real_bear_trap and majority_wants_sell:
            by_strategy.pop('trap_detector', None)
            if mean_rev_vote > 0 and (ai_vote <= -0.68 or is_waterfall_dump_pre or c_lower_wick_pre < 0.25):
                by_strategy.pop('mean_reversion', None)
            if log_vetoes:
                logger.info(
                    "🌊 [SMART INVERSION: THUẬN SỐ ĐÔNG SELL] %s: Loại bỏ phiếu Bear Trap giả/trễ pha (Râu dưới 15m=%.1f%%) "
                    "để giữ nguyên phiếu SELL của Số Đông & Cá Mập (AI=%+.2f, JEV=%+.2f, Trend=%+.2f, Breakout=%+.2f)!",
                    symbol_name, c_lower_wick_pre * 100, ai_vote, jev_vote, trend_vote, breakout_vote
                )

        # 2) Đối xứng: Khi TrapDetector báo SELL (trap_vote_raw < 0) nhưng KHÔNG ĐẠT chuẩn Bull Trap vật lý 15m
        # (not has_real_bull_trap) trong khi Số Đông / Bão Volume Cá Mập đang báo BUY: Loại bỏ phiếu Trap giả!
        majority_wants_buy = (
            (ai_vote >= 0.0 or is_whale_pump_storm_pre)
            and (
                (bullish_vote_cnt >= 2 and total_core_vote >= 0.50)
                or is_whale_pump_storm_pre
                or (ai_vote >= 0.72 and trend_vote >= 0.0 and jev_vote >= 0.0)
            )
            and not (trend_vote <= -0.35 and jev_vote <= -0.50)
            and not (jev_vote <= -0.70 and not is_whale_pump_storm_pre)
        )
        if apply_entry_vetoes and trap_vote_raw < 0 and not has_real_bull_trap and majority_wants_buy:
            by_strategy.pop('trap_detector', None)
            if mean_rev_vote < 0 and (ai_vote >= 0.68 or is_whale_pump_storm_pre or c_upper_wick_pre < 0.25):
                by_strategy.pop('mean_reversion', None)
            if log_vetoes:
                logger.info(
                    "🚀 [SMART INVERSION: THUẬN SỐ ĐÔNG BUY] %s: Loại bỏ phiếu Bull Trap giả/trễ pha (Râu trên 15m=%.1f%%) "
                    "để giữ nguyên phiếu BUY của Số Đông & Cá Mập (AI=%+.2f, JEV=%+.2f, Trend=%+.2f, Breakout=%+.2f)!",
                    symbol_name, c_upper_wick_pre * 100, ai_vote, jev_vote, trend_vote, breakout_vote
                )

        # Nếu khung 15m đang bứt phá mạnh (TrendFollowing/Breakout BUY) VÀ JEV Agent MTF xác nhận BUY (>= 0.70)
        # mà không có bẫy xả trên nến 15m (chỉ có tín hiệu TrapDetector 1H cũ từ giờ trước như AKT/USDT),
        # không cho phép tín hiệu 1H trễ pha xóa bỏ sóng tăng 15M hiện tại!
        if apply_entry_vetoes and has_real_bull_trap and not has_15m_bull_trap and not is_buying_climax_candle and (trend_vote >= 0.30 or breakout_vote >= 0.30) and jev_vote >= 0.70:

            has_real_bull_trap = False

            by_strategy.pop('trap_detector', None)



        if apply_entry_vetoes and has_real_bear_trap and not has_15m_bear_trap and not is_selling_climax_candle and (trend_vote <= -0.30 or breakout_vote <= -0.30) and jev_vote <= -0.70:

            has_real_bear_trap = False

            by_strategy.pop('trap_detector', None)



        # [BAI HOC 70] Khử triệt để bẫy pha loãng điểm (Bull Trap dilution & Bear Trap dilution):

        # Khi TrapDetector phát hiện rút râu xả hàng trên nến đóng (Bull Trap), cây nến xanh vừa tạo râu

        # thường đánh lừa các chỉ báo kỹ thuật khác và mô hình ML tưởng lầm là sóng tăng và bỏ phiếu BUY.

        # Các phiếu BUY này nằm trong mẫu số kéo điểm về gần 0 (ví dụ BTC 16:00:49 score=-0.0062) và kích

        # hoạt Opposing Veto giả tạo.

        # Vì vậy, khi có Bull Trap thật, vô hiệu hóa toàn bộ phiếu BUY đối kháng khỏi mẫu số.

        # Tương tự đối xứng: khi có Bear Trap thật, vô hiệu hóa toàn bộ phiếu SELL đối kháng khỏi mẫu số.

        # [KB5]: Đã đồng bộ is_opposed_by_strong_breakout và is_bear_opposed_by_breakout duy nhất từ đầu khối (tránh ghi đè mất JEV 4H Shield).

        neutralized_bull = []

        neutralized_bear = []

        if apply_entry_vetoes and has_real_bull_trap and not is_whale_pump_storm_pre and not is_opposed_by_strong_breakout:

            if trend_vote > 0.0 and 'trend_following' in by_strategy:

                by_strategy.pop('trend_following', None)

                neutralized_bull.append('TrendFollowing')

            if breakout_vote > 0.0 and 'momentum_breakout' in by_strategy:

                by_strategy.pop('momentum_breakout', None)

                neutralized_bull.append('Breakout')

            # [BÀI HỌC 97]: Tuyệt đối KHÔNG vô hiệu hóa AI Ensemble khi độ tự tin cao (ai_vote >= 0.70 / conf >= 70%)!
            if ai_vote > 0.0 and 'ai_ensemble' in by_strategy and ai_vote < 0.70 and not (trend_vote >= 0.25 and ai_vote >= 0.60):

                by_strategy.pop('ai_ensemble', None)

                neutralized_bull.append('AIEnsemble')

            # [B?I H?C 97 & 102]: Tuy?t ??i KH?NG v? hi?u h?a JEV Agent khi ?? t? tin cao (jev_vote >= 0.70)!
            if jev_vote > 0.0 and 'jev_agent' in by_strategy and jev_vote < 0.70:

                by_strategy.pop('jev_agent', None)

                neutralized_bull.append('JEVAgent')

            if mean_rev_vote > 0.0 and 'mean_reversion' in by_strategy:

                by_strategy.pop('mean_reversion', None)

                neutralized_bull.append('MeanReversion')

            if neutralized_bull and log_vetoes:

                logger.warning(

                    "🛡️ CẢNH BÁO BẪY GIÁ (BULL TRAP): TrapDetector phát hiện rút râu xả hàng! "

                    "Vô hiệu hóa đà BUY của %s để chống bẫy pha loãng điểm (Bull Trap dilution).",

                    ', '.join(neutralized_bull),

                )



        # 2. CHỐNG BẮT DAO RƠI KHI SẬP MẠNH (Downtrend crash) & KIỂM ĐỊNH BEAR TRAP THẬT TRƯỚC KHI XÓA PHIẾU SELL:
        # Chỉ coi JEV là bearish khi JEV thực sự ra lệnh SELL (jev_vote <= -0.20),
        # hoặc khi không có đà tăng kỹ thuật (trend_vote <= 0 và breakout_vote <= 0) mà JEV cảnh báo downtrend/dump.
        # Tuyệt đối không bắt chữ cảm tính khi TrendFollowing đang báo BUY dương (như AIO/USDT Trend +0.80)!
        jev_is_bearish = (jev_vote <= -0.20) or (
            trend_vote <= 0.0
            and breakout_vote <= 0.0
            and any(
                isinstance(getattr(s, 'metadata', None), dict)
                and any(w in str(s.metadata.get('reason', '')).lower() for w in ('bearish', 'downtrend', 'drop', 'dump', 'xả'))
                for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
            )
        )

        # Kiểm tra AI Bias hoặc Market Regime vĩ mô từ metadata
        macro_is_bearish = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and (
                str(s.metadata.get('ai_bias', '')).upper() == 'BEARISH'
                or str(s.metadata.get('market_regime', '')).lower() in ('downtrend', 'strong_downtrend', 'bearish')
            )
            for s in signals
        )

        is_coin_technically_pumping = (trend_vote >= 0.20 or breakout_vote >= 0.20)

        has_strong_sell_momentum = (
            not is_coin_technically_pumping and (
                breakout_vote <= -0.20 or 
                trend_vote <= -0.20 or 
                macro_is_bearish
            )
        )

        has_strong_trap_reversal = (
            has_real_bear_trap
            and 'trap_detector' in by_strategy
            and any(
                getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and getattr(s, 'signal', None) == Signal.BUY
                and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                for s in signals
            )
        )

        # Chỉ vô hiệu hóa đà SELL của Số Đông khi Bear Trap hợp lệ (không phải hồi ảo Altcoin < 70% trong downtrend)
        # [BÀI HỌC 85 & 86 - KHẮC PHỤC TRIỆT ĐỂ BẪY BẮT DAO RƠI BEAR TRAP LONG]:
        # C1: Trap 1H SELL xung đột với 15M BUY (khung 1H xả dốc, 15M chỉ là râu nhiễu)
        has_1h_sell_trap = any(
            getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
            and getattr(s, 'signal', None) == Signal.SELL
            and str((getattr(s, 'metadata', None) or {}).get('timeframe') or '').lower() == '1h'
            for s in signals
        )
        has_15m_trap_buy = any(
            getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
            and getattr(s, 'signal', None) == Signal.BUY
            and str((getattr(s, 'metadata', None) or {}).get('timeframe') or '').lower() == '15m'
            for s in signals
        )
        has_other_tech_buy = (trend_vote >= 0.20 or breakout_vote >= 0.20)
        raw_trap_conf_pre = max(
            (
                float(getattr(s, 'confidence', 0.0) or 0.0)
                for s in signals
                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)
            ),
            default=0.0,
        )

        c1_trap_1h_conflict = has_1h_sell_trap
        c2_stale_1h_trap_only = (has_1h_bear_trap_valid and not has_15m_trap_buy and not has_other_tech_buy and (jev_vote <= 0 or ai_vote <= -0.75 or raw_trap_conf_pre <= 0.68))
        c3_jev_hold_weak_trap = (not has_other_tech_buy and jev_vote <= 0 and raw_trap_conf_pre <= 0.73)
        c4_unanimous_macro_sell = (ai_vote <= -0.55 and jev_vote <= -0.20)
        c5_weak_lone_trap = (raw_trap_conf_pre <= 0.68 and not has_other_tech_buy and not has_1h_bear_trap_valid)

        is_fake_altcoin_bear_trap = (
            has_real_bear_trap and is_crypto_altcoin and (
                (has_strong_sell_momentum and not has_strong_trap_reversal)
                or c1_trap_1h_conflict
                or c2_stale_1h_trap_only
                or c3_jev_hold_weak_trap
                or c4_unanimous_macro_sell
                or c5_weak_lone_trap
            )
        )

        if apply_entry_vetoes and has_real_bear_trap and not is_fake_altcoin_bear_trap and not is_waterfall_dump_pre and not is_bear_opposed_by_breakout:

            if trend_vote < 0.0 and 'trend_following' in by_strategy:

                by_strategy.pop('trend_following', None)

                neutralized_bear.append('TrendFollowing')

            if breakout_vote < 0.0 and 'momentum_breakout' in by_strategy:

                by_strategy.pop('momentum_breakout', None)

                neutralized_bear.append('Breakout')

            # [BÀI HỌC 97 & SSOT DOCTRINE]: Tuyệt đối KHÔNG vô hiệu hóa AI Ensemble khi độ tự tin cao (ai_vote <= -0.60)!
            if ai_vote < 0.0 and 'ai_ensemble' in by_strategy and ai_vote > -0.60:

                by_strategy.pop('ai_ensemble', None)

                neutralized_bear.append('AIEnsemble')

            # [BÀI HỌC 97 & 102]: Tuyệt đối KHÔNG vô hiệu hóa JEV Agent khi độ tự tin cao (jev_vote <= -0.70)!
            if jev_vote < 0.0 and 'jev_agent' in by_strategy and jev_vote > -0.70:

                by_strategy.pop('jev_agent', None)

                neutralized_bear.append('JEVAgent')

            if mean_rev_vote < 0.0 and 'mean_reversion' in by_strategy:

                by_strategy.pop('mean_reversion', None)

                neutralized_bear.append('MeanReversion')

            if neutralized_bear and log_vetoes:

                logger.warning(

                    "🛡️ CẢNH BÁO BẪY GIÁ (BEAR TRAP): TrapDetector phát hiện rút chân gom hàng! "

                    "Vô hiệu hóa đà SELL của %s để chống bẫy pha loãng điểm (Bear Trap dilution).",

                    ', '.join(neutralized_bear),

                )



        trap_ctx_data = {

            'has_real_bull_trap': has_real_bull_trap,

            'has_real_bear_trap': has_real_bear_trap and not is_fake_altcoin_bear_trap,

            'has_valid_trap_vol': bool(has_valid_trap_vol),

            'is_fake_altcoin_bear_trap': is_fake_altcoin_bear_trap,

            'is_true_climax_15m': (c_upper_wick_pre >= 0.45 or c_lower_wick_pre >= 0.45),

            'is_whale_pump_storm': is_whale_pump_storm_pre,

            'is_waterfall_dump': is_waterfall_dump_pre,

            'is_ai_absorption_buy': is_ai_absorption_buy,
            'is_ai_exhaustion_sell': is_ai_exhaustion_sell,
            'orig_jev_vote': orig_jev_vote,
            'neutralized_bull': list(neutralized_bull),

            'neutralized_bear': list(neutralized_bear),

        }

        self._last_trap_context = trap_ctx_data

        if not hasattr(self, '_trap_contexts_by_symbol'):

            self._trap_contexts_by_symbol = {}

        self._trap_contexts_by_symbol[symbol_name] = trap_ctx_data

        clean_name_short = symbol_name.split(':')[0].strip().upper()

        self._trap_contexts_by_symbol[clean_name_short] = trap_ctx_data



        if apply_entry_vetoes:

            # A. CẤM TUYỆT ĐỐI BẮT ĐÁY LONG TRÊN ALTCOIN KHI THỊ TRƯỜNG DOWNTREND (MIỄN TRỪ NẾU CÓ BẪY RÚT ĐÁY MẠNH >= 70%):

            if has_strong_sell_momentum and is_crypto_altcoin:

                if not has_strong_trap_reversal and not is_ai_absorption_buy:

                    removed_buy = False

                    for strat_k in list(by_strategy.keys()):

                        if strat_k in ('trap_detector', 'ai_ensemble'):

                            continue

                        orig_len = len(by_strategy[strat_k])

                        filtered_v = [v for v in by_strategy[strat_k] if v <= 0]

                        if len(filtered_v) < orig_len:

                            removed_buy = True

                        if filtered_v:

                            by_strategy[strat_k] = filtered_v

                        else:

                            by_strategy.pop(strat_k, None)

                    if removed_buy and log_vetoes:

                        reason_str = "Toàn sàn/Vĩ mô Downtrend" if macro_is_bearish else f"Đà giảm cục bộ của coin (Trend: {trend_vote:+.2f}, Breakout: {breakout_vote:+.2f})"

                        logger.info("🚫 VETO BUY ALTCOIN (%s): %s, cấm bắt dao rơi Altcoin!", symbol_name, reason_str)



            # C. LỌC BẪY RÂU ĐÁY ALTCOIN YẾU (< 70%) TRONG DOWNTREND (GIỮ NGUYÊN PHIẾU SELL CỦA SỐ ĐÔNG):

            if is_fake_altcoin_bear_trap:

                has_real_bear_trap = False

                if isinstance(getattr(self, '_last_trap_context', None), dict):

                    self._last_trap_context['has_real_bear_trap'] = False

                if hasattr(self, '_trap_contexts_by_symbol'):

                    for k in (symbol_name, clean_name_short if 'clean_name_short' in locals() else symbol_name.split(':')[0].strip().upper()):

                        if k in self._trap_contexts_by_symbol:

                            self._trap_contexts_by_symbol[k]['has_real_bear_trap'] = False

                by_strategy.pop('trap_detector', None)

                if log_vetoes:

                    logger.warning("🛡️ CHẶN BẪY RÂU ALTCOIN (%s): Bẫy rút đáy Altcoin bị phủ quyết trong downtrend vĩ mô để giữ đà SELL thuận theo cá mập!", symbol_name)



        # B. TĂNG LỰC CHO SHORT BẮT ĐỈNH (BULL TRAP SHORT) & ĐỒNG BỘ LƯỠNG PHA CÁ MẬP:

        # Khi xuất hiện Bull Trap thực sự, tăng mạnh trọng số SHORT.

        # [KB5]: Đã đồng bộ is_opposed_by_strong_breakout và is_bear_opposed_by_breakout duy nhất từ đầu khối (tránh ghi đè mất JEV 4H Shield).

        if apply_entry_vetoes and has_real_bull_trap and not is_whale_pump_storm_pre and not is_opposed_by_strong_breakout:
            by_strategy['trap_detector'] = [-0.85]
            if log_vetoes:
                logger.info("🎯 KÍCH HOẠT BULL TRAP SHORT (%s): TrapDetector/Buying Climax xác nhận râu xả đỉnh, ưu tiên SHORT!", symbol_name)

        if apply_entry_vetoes and has_real_bear_trap and not is_fake_altcoin_bear_trap and not is_waterfall_dump_pre and not is_bear_opposed_by_breakout:
            by_strategy['trap_detector'] = [0.85]
            if log_vetoes:
                logger.info("💎 KÍCH HOẠT BEAR TRAP LONG (%s): TrapDetector/Selling Climax xác nhận rút chân gom hàng, ưu tiên BUY!", symbol_name)




        # [BÀI HỌC 78, 82 & 85]: Khơi thông dòng tiền cá mập Pha 1 (Whale Pump Storm) và Thác đổ (Waterfall Breakdown)
        # ngay trong bảng phân bổ phiếu để không bị Veto điểm thô (< 0.80) chặn trước khi tới Smart Dual-Phase Matrix!
        if apply_entry_vetoes and is_whale_pump_storm_pre and not has_real_bull_trap:
            if mean_rev_vote < 0:
                by_strategy.pop('mean_reversion', None)
            if trap_vote_raw < 0:
                by_strategy.pop('trap_detector', None)
            by_strategy['momentum_breakout'] = [max(0.85, breakout_vote)]

        if apply_entry_vetoes and is_waterfall_dump_pre and not has_real_bear_trap and (tactical_rsi_pre > 32.0 or trend_vote <= -0.30 or breakout_vote <= -0.30) and jev_vote < 0.65 and majority_wants_sell:
            if mean_rev_vote > 0:
                by_strategy.pop('mean_reversion', None)
            if trap_vote_raw > 0:
                by_strategy.pop('trap_detector', None)
            by_strategy['momentum_breakout'] = [min(-0.85, breakout_vote)]

        # [BÀI HỌC 105, 107 & 108 - SMART INVERSION: ABSORPTION REVERSAL BUY]:
        # Khi cá mập gom hàng hấp thụ đáy và AI Ensemble tự tin BUY >= 72%:
        # Bãi bỏ các phiếu SELL trễ pha của Breakout/Trend, NHƯNG TUYỆT ĐỐI KHÔNG BẮT ĐÁY CẢN TÀU KHI JEV AGENT 4H ĐANG XẢ MẠNH (<= -0.70)!
        if apply_entry_vetoes and is_ai_absorption_buy:
            if jev_vote <= -0.70:
                if log_vetoes:
                    logger.info(
                        "🛡️ [JEV MTF TREND SHIELD (%s)]: Không kích hoạt Absorption Buy vì JEV Agent MTF đang xả mạnh 4H (%.2f%%)!",
                        symbol_name, abs(jev_vote) * 100
                    )
            else:
                if breakout_vote < 0:
                    by_strategy.pop('momentum_breakout', None)
                if trend_vote < 0:
                    by_strategy.pop('trend_following', None)
                if jev_vote < 0 and jev_vote > -0.70 and (ai_vote >= 0.72 or c_recent_dump_pre >= 0.035 or is_panic_selling_climax_pre):
                    by_strategy.pop('jev_agent', None)
                by_strategy['ai_ensemble'] = [max(0.85, ai_vote)]
                if has_real_bear_trap or is_selling_climax_candle:
                    by_strategy['trap_detector'] = [0.85] # Chỉ xác nhận khi TrapDetector thực sự có tín hiệu rút chân!
                if log_vetoes:
                    logger.info(
                        "🚀 [SMART INVERSION: ABSORPTION REVERSAL BUY (%s)]: AI Ensemble (%.2f%%) xác nhận cá mập gom hàng đáy (RSI: %.1f, Dump: %.2f%%). Loại bỏ phiếu SELL trễ pha, ưu tiên BUY!",
                        symbol_name, ai_vote * 100, tactical_rsi_pre, c_recent_dump_pre * 100
                    )

        # [BÀI HỌC 105, 107 & 108 - SMART INVERSION: EXHAUSTION FADING SELL]:
        # Khi cá mập xả kiệt sức đỉnh và AI Ensemble tự tin SELL <= -72%:
        # Bãi bỏ các phiếu BUY trễ pha của Breakout/Trend, NHƯNG TUYỆT ĐỐI KHÔNG BẮT ĐỈNH CẢN TÀU KHI JEV AGENT 4H ĐANG BƠM MẠNH (>= 0.70)!
        if apply_entry_vetoes and is_ai_exhaustion_sell:
            if jev_vote >= 0.70:
                if log_vetoes:
                    logger.info(
                        "🛡️ [JEV MTF TREND SHIELD (%s)]: Không kích hoạt Exhaustion Fading Sell vì JEV Agent MTF đang bơm mạnh 4H (%.2f%%)!",
                        symbol_name, jev_vote * 100
                    )
            else:
                if breakout_vote > 0:
                    by_strategy.pop('momentum_breakout', None)
                if trend_vote > 0:
                    by_strategy.pop('trend_following', None)
                if jev_vote > 0 and jev_vote < 0.70 and (ai_vote <= -0.72 or c_recent_pump_pre >= 0.035 or is_parabolic_pump_climax_pre):
                    by_strategy.pop('jev_agent', None)
                by_strategy['ai_ensemble'] = [min(-0.85, ai_vote)]
                if has_real_bull_trap or is_buying_climax_candle:
                    by_strategy['trap_detector'] = [-0.85] # Chỉ xác nhận khi TrapDetector thực sự có tín hiệu râu xả đỉnh!
                if log_vetoes:
                    logger.info(
                        "⚡ [SMART INVERSION: EXHAUSTION FADING SELL (%s)]: AI Ensemble (%.2f%%) xác nhận sóng bơm kiệt sức đỉnh (RSI: %.1f, Pump: %.2f%%). Loại bỏ phiếu BUY trễ pha, ưu tiên SHORT!",
                        symbol_name, abs(ai_vote) * 100, tactical_rsi_pre, c_recent_pump_pre * 100
                    )



        # D. GHI NHẬN CẢNH BÁO CONSOLIDATION CHO CẶP ETF ĐÒN BẨY & CHẶN BẪY RÂU ĐƠN LẺ TRONG VÙNG NÉN 15M (CHOP TRACKING)

        clean_sym = symbol_name.split(':')[0].strip().upper()

        jev_warns_consolidation = any(

            isinstance(getattr(s, 'metadata', None), dict)

            and any(w in (str(s.metadata.get('risk_factors', '')) + " " + str(s.metadata.get('reason', ''))).lower() 

                    for w in (

                        'consolidation with no clear breakout',

                        'consolidating without a clear direction',

                        'consolidating between ema',

                        'choppy consolidation',

                        'volume is not significantly expanded',

                        'volume is not significantly expanding',

                        'conflicting 4h and 15m trends with no clear direction',

                        'no clear break above ema',

                        'no clear break',

                        'no clear breakout',

                        'lacks clear directional momentum',

                        'risk of volume exhaustion',

                        'consolidation with no clear break',

                        'choppy consolidation with no clear',

                        'testing ema20 with low volume and choppy consolidation',

                    ))

            for s in signals if getattr(s, 'strategy', '') == 'jev_agent'

        )

        # BẢO VỆ ĐỒNG THUẬN KỸ THUẬT (TECHNICAL CONSENSUS SCOPE BẢO ĐẢM LUÔN KHỞI TẠO):

        # Tính toán trước để luôn sẵn sàng cho cả Rule D (JEV Veto) và Rule E2 (Chop Shield)

        tech_keys = [k for k in by_strategy if k not in ('jev_agent', 'ai_ensemble')]

        has_tech_signal = len(tech_keys) > 0

        raw_trap_conf = max(

            (

                float(getattr(s, 'confidence', 0.0) or 0.0)

                for s in signals

                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')

                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)

            ),

            default=0.0,

        )

        # Đếm các chiến thuật kỹ thuật độc lập (loại trừ JEV và AI Ensemble) có độ tự tin cao (>= 0.65)

        # và phải đồng pha cùng chiều với hướng áp đảo kỹ thuật (không đếm chiến thuật đối kháng)

        tech_votes_signed = [

            (k, sum(by_strategy[k]) / len(by_strategy[k]))

            for k in tech_keys if by_strategy.get(k)

        ]

        dominant_tech_dir = 1.0 if sum(v for _, v in tech_votes_signed) >= 0 else -1.0

        agreeing_tech_count = sum(

            1 for _, v in tech_votes_signed

            if v * dominant_tech_dir > 0 and abs(v) >= 0.65

        )

        has_strong_consensus = (agreeing_tech_count >= 2) or (raw_trap_conf >= 0.78 and c_vol_ratio_pre >= 1.25)



        if apply_entry_vetoes and jev_warns_consolidation:

            now_ts = time.time()

            SignalAggregator._recent_chop_vetoes[clean_sym] = now_ts

            self._recent_chop_vetoes[clean_sym] = now_ts

            # [SỬA LỖI GỐC RỄ - CHOP SHIELD ĐO SAI ĐỐI TƯỢNG]

            # Trước đây khối này chỉ chạy khi ứng viên CHÍNH LÀ BTC/ETH (`if clean_base in ('BTC','ETH')`),

            # và lấy ADX/ATR từ market_analysis của chính ứng viên rồi gán cho biến `btc_adx_val`.

            # Hệ quả kép:

            #   1. Khi ứng viên là Altcoin (99% trường hợp) shield không bao giờ tự kích hoạt, dù mục

            #      đích của nó là "BTC/ETH đang nén thì đừng mở Altcoin".

            #   2. Khi ứng viên là BTC/ETH, phép so `adx >= 22 or atr_pct >= 0.45` lại được kiểm tra

            #      ngay sau tín hiệu ĐẦU TIÊN trong vòng lặp nên gần như luôn đúng -> shield tê liệt.

            # Nay shield dùng bối cảnh BTC/ETH do bot đo độc lập từ dữ liệu 15m của chính BTC/ETH

            # (market_chop_context). Nếu bot không đo được -> KHÔNG kích hoạt (fail-open) thay vì

            # dùng chỉ số sai của ứng viên.

            if apply_entry_vetoes:

                ctx = market_chop_context if isinstance(market_chop_context, dict) else {}

                measured = [

                    c for c in (ctx.get('BTC'), ctx.get('ETH'))

                    if _chop_entry_is_measured(c)

                ]

                btc_adx_val = max(

                    (float(c.get('adx') or 0.0) for c in measured), default=0.0

                )

                btc_atr_val = max(

                    (float(c.get('atr_pct') or 0.0) for c in measured), default=0.0

                )

                btc_is_active_trend = bool(measured) and (

                    btc_adx_val >= 22.0 or btc_atr_val >= 0.45

                )

                last_chop_act = max(

                    getattr(self, '_last_chop_shield_activated_at', 0.0),

                    getattr(SignalAggregator, '_last_chop_shield_activated_at', 0.0),

                )

                if measured and (not btc_is_active_trend) and (now_ts - last_chop_act >= 240.0):

                    SignalAggregator._crypto_market_chop_until = now_ts + 120.0

                    self._crypto_market_chop_until = now_ts + 120.0

                    SignalAggregator._last_chop_shield_activated_at = now_ts

                    self._last_chop_shield_activated_at = now_ts

                    logger.warning(

                        "🛡️ [CRYPTO CHOP SHIELD KÍCH HOẠT] BTC/ETH đang nén sideway / volume cạn kiệt (ADX=%.1f, ATR=%.2f%%). Tạm khóa mở lệnh Breakout đơn lẻ trên Crypto Altcoin trong 2 phút!",

                        btc_adx_val, btc_atr_val

                    )

            is_lone_trap_in_chop = (

                tech_keys == ['trap_detector']

                and (raw_trap_conf < 0.72 or c_vol_ratio_pre < min_trap_rvol)

            )

            is_consolidation_chop_veto = (

                (is_crypto_altcoin or is_tradfi)

                and jev_warns_consolidation

                and not has_strong_consensus

            )

            if apply_entry_vetoes and (

                not has_tech_signal

                or is_lone_trap_in_chop

                or is_consolidation_chop_veto

            ):

                by_strategy.clear()

                logger.warning("🛡️ JEV VETO CONSOLIDATION (%s): JEV Agent cảnh báo thị trường nén đi ngang / không có breakout / volume cạn kiệt, VETO toàn bộ tín hiệu!", symbol_name)

                try:

                    from core.gate_telemetry import record_gate_event

                    record_gate_event('JEV_CHOP_VETO', symbol_name, reason='JEV cảnh báo nén sideway/volume cạn')

                except Exception:

                    pass



        # E. CHẶN CHÉO CẶP ETF NGHỊCH ĐẢO (INVERSE ETF CROSS-VETO):

        # Khi SOXL bị nén đi ngang/chop, SOXS (và ngược lại) cũng bị bào mòn thanh khoản trong vùng sideway

        counter_pair = SignalAggregator.INVERSE_PAIRS.get(clean_sym)

        if apply_entry_vetoes and counter_pair and counter_pair in SignalAggregator._recent_chop_vetoes:

            last_counter_chop = SignalAggregator._recent_chop_vetoes[counter_pair]

            if (time.time() - last_counter_chop) < 3600:

                by_strategy.clear()

                logger.warning(

                    "🛡️ INVERSE ETF CROSS-VETO (%s): Mã đối ứng %s đang bị cảnh báo Sideway/Chop nén biên hẹp (cách đây %.1f phút), cấm mở vị thế bào mòn ETF!",

                    clean_sym, counter_pair, (time.time() - last_counter_chop) / 60.0

                )



        # E1.5. STAND-ASIDE VETO KHI THANH KHOẢN CẠN KIỆT & NÉN BIÊN ĐỘ HẸP (ZERO EDGE):
        # Tránh giao dịch khi thị trường đi ngang cạn kiệt dòng tiền, râu nến trôi dạt (Edge ~ 0).
        macro_adx_pre = float((macro_analysis_pre or {}).get('adx') or 0.0)
        macro_atr_pct_pre = float((macro_analysis_pre or {}).get('atr_pct') or 0.0)
        min_active_rvol = 0.35 if is_tradfi else (0.70 if is_crypto_altcoin else 0.60)
        is_liquidity_dry = (c_vol_ratio_pre < min_active_rvol) and not (is_buying_climax_candle or is_selling_climax_candle or is_whale_pump_storm_pre or is_waterfall_dump_pre)
        is_chop_range = (macro_adx_pre > 0.0 and macro_adx_pre < 18.0) or (0.0 < macro_atr_pct_pre < 0.35)
        
        if apply_entry_vetoes and is_liquidity_dry and is_chop_range and not has_strong_consensus:
            by_strategy.clear()
            if log_vetoes:
                logger.warning(
                    "⏸️ [STAND-ASIDE VETO - ZERO EDGE (%s)]: Thanh khoản cạn kiệt (RVol=%.2fx < %.2fx) và biên độ nén hẹp (ADX=%.1f, ATR=%.2f%%). Đứng ngoài bảo vệ vốn!",
                    symbol_name, c_vol_ratio_pre, min_active_rvol, macro_adx_pre, macro_atr_pct_pre
                )

        # E2. ÁP DỤNG CRYPTO MARKET-WIDE CHOP SHIELD (CHỈ CHO CRYPTO ALTCOIN, MIỄN TRỪ 100% TRADFI VÀ COIN MAJOR):

        chop_deadline = max(

            getattr(self, '_crypto_market_chop_until', 0.0),

            getattr(SignalAggregator, '_crypto_market_chop_until', 0.0),

        )

        if apply_entry_vetoes and is_crypto_altcoin and (time.time() < chop_deadline):

            has_strong_trap = (

                any(

                    getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')

                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70

                    for s in signals

                )

                or (bool(by_strategy.get('trap_detector')) and abs(by_strategy['trap_detector'][0]) >= 0.70)

            )

            # Kịch Bản 2: Cho phép vượt rào Chop Shield nếu Altcoin có đồng thuận kỹ thuật độc lập mạnh mẽ (>= 2 chiến lược kỹ thuật >= 75% cùng chiều lệnh hoặc Trap >= 70%)

            has_strong_alt_momentum = agreeing_tech_count >= 2 and max(

                (

                    float(getattr(s, 'confidence', 0.0) or 0.0)

                    for s in signals

                    if getattr(s, 'strategy', '').lower() not in ('jev_agent', 'jevagent', 'ai_ensemble', 'aiensemble')

                    and (

                        (dominant_tech_dir > 0 and (getattr(s, 'signal', None) == Signal.BUY or getattr(s, 'direction', 0.0) > 0))

                        or (dominant_tech_dir < 0 and (getattr(s, 'signal', None) == Signal.SELL or getattr(s, 'direction', 0.0) < 0))

                    )

                ),

                default=0.0,

            ) >= 0.75

            if not (has_strong_trap or has_strong_alt_momentum):

                by_strategy.clear()

                if log_vetoes:

                    rem_m = max(0.0, (chop_deadline - time.time()) / 60.0)

                    logger.warning(

                        "🛡️ CRYPTO CHOP SHIELD VETO (%s): BTC/ETH đang trong vùng nén sideway cạn volume (còn %.1fm), cấm mở vị thế Altcoin trôi dạt!",

                        symbol_name, rem_m

                    )



        # F0. ĐỒNG BỘ BẢO VỆ LỆNH SELL KHI BULL TRAP + ĐA SỐ CHIẾN THUẬT (KỸ THUẬT/AI) XÁC NHẬN ĐỈNH XẢ HÀNG:
        # Khi xuất hiện Bull Trap thực sự (has_real_bull_trap) đồng thời có >= 2 chiến thuật khác (như TrendFollowing 15m SELL + AI Ensemble SELL,
        # hoặc >= 2 chiến thuật kỹ thuật độc lập SELL >= 60%) đồng thuận SELL tuyệt đối, nhưng JEV Agent nhìn xu hướng 4H/1H cũ vẫn báo BUY trễ pha:
        # [RULE 0 - JEV MTF TREND SHIELD]: TUYỆT ĐỐI CẤM pop('jev_agent') khi JEV Agent 4H đang BUY mạnh (jev_vote >= 0.70)!
        if apply_entry_vetoes and has_real_bull_trap and 'jev_agent' in by_strategy and jev_vote > 0:
            if jev_vote >= 0.70:
                if log_vetoes:
                    logger.info(
                        "🛡️ [JEV MTF TREND SHIELD (%s)]: Giữ nguyên phiếu JEV Agent BUY (%.1f%% >= 70%%); CẤM pop('jev_agent') để bảo vệ cấu trúc xu hướng 4H!",
                        symbol_name, jev_vote * 100
                    )
            else:
                non_jev_strats = {k: sum(v) / len(v) for k, v in by_strategy.items() if k != 'jev_agent' and v}
                non_ai_sell_count = sum(1 for k, v in non_jev_strats.items() if k != 'ai_ensemble' and v <= -0.60)
                if len(non_jev_strats) >= 2 and all(v <= -0.60 for v in non_jev_strats.values()) and non_ai_sell_count >= 2:
                    by_strategy.pop('jev_agent', None)



        # F. CHỐNG TRỄ PHA KHUNG 4H CỦA AI ENSEMBLE KHI ĐA SỐ CHIẾN THUẬT (KỸ THUẬT 15M + JEV AGENT >= 80%) ĐỒNG THUẬN TUYỆT ĐỐI:

        # Ví dụ METIS/USDT (Trend 15m BUY 80% + Trap 15m BUY 67% + JEV BUY 85%, ADX=32.0) hay ELSA/USDT (Trend 15m BUY 75% + JEV BUY 82%, ADX=31.0)

        # bị duy nhất phiếu SELL trễ pha trên khung 4H của AI Ensemble kéo điểm xuống.

        # BẮT BUỘC: Chỉ được bỏ qua phiếu ngược chiều của AI Ensemble khi chỉ số vĩ mô đạt chuẩn Tầng 4:

        # ADX >= 30.0 và ATR < 5.0% (chặn đứng BLUAI ADX=17.0, VELODROME ADX=28.7, RSR#2 ADX=26.6 ATR=5.16%)!

        if apply_entry_vetoes and 'ai_ensemble' in by_strategy and 'jev_agent' in by_strategy:

            ma_vote = next(

                (

                    s.metadata.get('market_analysis')

                    for s in signals

                    if isinstance(getattr(s, 'metadata', None), dict)

                    and isinstance(s.metadata.get('market_analysis'), dict)

                ),

                {},

            )

            try:

                vote_adx = float((ma_vote or {}).get('adx') or 0.0)

            except (TypeError, ValueError):

                vote_adx = 0.0

            try:

                vote_atr = float((ma_vote or {}).get('atr_pct') or 0.0)

            except (TypeError, ValueError):

                vote_atr = 0.0

            macro_ok_for_rule_f = (vote_adx <= 0.0 or vote_adx >= 30.0) and (vote_atr <= 0.0 or vote_atr < 5.0)



            ai_v = sum(by_strategy['ai_ensemble']) / len(by_strategy['ai_ensemble'])

            other_strats = {k: sum(v) / len(v) for k, v in by_strategy.items() if k != 'ai_ensemble' and v}

            tech_strats = {k: v for k, v in other_strats.items() if k != 'jev_agent'}

            tech_max = max(abs(v) for v in tech_strats.values()) if tech_strats else 0.0



            # =========================================================================

            # QUY TẮC PHỦ QUYẾT XUNG ĐỘT AI TUYỆT ĐỐI (AI HARD CONSENSUS VETO)

            # KIỂM CHỨNG ĐỊNH LƯỢNG TRÊN 274 LỆNH LỊCH SỬ THỰC TẾ & MÔ PHỎNG NẾN 15M:

            # -------------------------------------------------------------------------

            # [LÝ DO BẮT BUỘC KHÔNG ĐƯỢC PHÉP THAY ĐỔI CÔNG THỨC / THAM SỐ NÀY]:

            # Trong lịch sử thực chiến, các lệnh lỗ nặng nhất (BOT/USDT, LAB/USDT, ERA/USDT,

            # GTC/USDT, AIOT/USDT, và gần đây nhất là KGEN/USDT -0.13$, 1000PEPE/USDT -0.06$,

            # ID/USDT -0.07$) đều xảy ra do cùng 1 nguyên nhân:

            # - Chỉ báo kỹ thuật (trend_following / momentum) và LLM thấy nến vừa pump mạnh

            #   nên ADX vọt lên >= 35 và hô BUY (> 85%).

            # - Nhưng mô hình Machine Learning (AI Ensemble 91 đặc trưng) nhận diện Order Flow

            #   kiệt sức (Volume Exhaustion) và RSI quá mua nên cảnh báo SELL cực mạnh (79% - 87%).

            # - Quy tắc cũ cố tình "bỏ qua phiếu trễ pha của AI Ensemble" để đu đỉnh, dẫn tới

            #   mua đúng râu nến cao trào và dính Stop-Loss 100% các lần!

            #

            # KẾT QUẢ MÔ PHỎNG THỰC NGHIỆM:

            # - Khi TUYỆT ĐỐI KHÔNG BỎ QUA AI ENSEMBLE đối kháng mạnh (conf >= 0.70), 12 lệnh

            #   đu đỉnh lớn nhất lịch sử bị triệt tiêu 100%.

            # - Tỷ lệ thắng (Win Rate) tăng từ 61.7% lên 64.5%.

            # - Profit Factor nhảy vọt từ 1.39 lên 1.84 (và đạt 2.36 khi kết hợp Payoff Floor).

            # - BẤT KỲ AI ASSISTANT NÀO TRONG TƯƠNG LAI NẾU MUỐN THAY ĐỔI ĐOẠN CODE NÀY BẮT BUỘC

            #   PHẢI CHẠY LẠI MÔ PHỎNG scratch_full_historical_simulation.py ĐỂ KIỂM CHỨNG!

            # =========================================================================

            is_extreme_ai_conflict = (

                (all(v >= 0.60 for v in other_strats.values()) and ai_v <= -0.70) or

                (all(v <= -0.60 for v in other_strats.values()) and ai_v >= 0.70)

            )

            is_major_or_tradfi = is_tier1 or is_tradfi or (clean_base == 'BCH')
            has_macro_dual_brain = (
                is_major_or_tradfi
                and len(other_strats) >= 2
                and abs(jev_vote) >= 0.70
                and all(v * jev_vote > 0 and abs(v) >= 0.60 for v in other_strats.values())
            )

            if is_extreme_ai_conflict and not has_macro_dual_brain:

                # Tuyệt đối giữ nguyên phiếu của AI Ensemble để triệt tiêu điểm số và kích hoạt Micro Consensus Veto trên Altcoins

                logger.warning(

                    "⚠️ [XUNG ĐỘT AI CỰC ĐỘ - BẢO VỆ TỐI THƯỢNG] (%s): Các chiến thuật khác đồng thuận (%s) nhưng AI Ensemble kiên quyết đối kháng (%s %.1f%%)! Tuyệt đối KHÔNG bỏ qua phiếu AI Ensemble để tránh bẫy đu đỉnh cao trào!",

                    symbol_name, "BUY" if ai_v < 0 else "SELL", "SELL" if ai_v < 0 else "BUY", abs(ai_v) * 100

                )

            elif has_macro_dual_brain:

                # Với Major Crypto & TradFi: Khi JEV LLM 4H & Trend đã chỉ huy xu hướng (>= 70%),
                # hạ quyền biểu quyết của Não Tĩnh ML xuống mức tư vấn để bảo toàn xu hướng vĩ mô,
                # chuyển sang rình Limit Maker ở nhịp retest M1 Sniper!
                by_strategy.pop('ai_ensemble', None)
                logger.info(
                    "⚡ [KB 10 DUAL-BRAIN ALIGNMENT] %s (%s): JEV LLM 4H & Trend (%.0f%%) chỉ huy xu hướng vĩ mô, hạ trọng số ML từ 1.2 xuống mức tư vấn đón nhịp retest M1 Sniper!",
                    symbol_name, "Major Crypto" if (is_tier1 or clean_base == 'BCH') else "TradFi", abs(jev_vote) * 100
                )

            elif len(other_strats) >= 2 and len(tech_strats) >= 1 and macro_ok_for_rule_f:

                # Chỉ cho phép bỏ qua AI Ensemble khi AI Ensemble chỉ lưỡng lự nhẹ (|ai_v| < 0.50)

                # và kỹ thuật thực sự có đồng thuận vĩ mô, tuyệt đối không bỏ qua khi AI Ensemble phản kháng mạnh.

                if all(v >= 0.60 for v in other_strats.values()) and jev_vote >= 0.80 and -0.50 < ai_v < 0:

                    by_strategy.pop('ai_ensemble', None)

                    logger.info(

                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận BUY mạnh, bỏ qua phiếu lưỡng lự nhẹ của AI Ensemble (%.1f%% < 50%%)!",

                        symbol_name, len(other_strats), jev_vote * 100, abs(ai_v) * 100

                    )

                elif all(v <= -0.60 for v in other_strats.values()) and jev_vote <= -0.80 and 0 < ai_v < 0.50:

                    by_strategy.pop('ai_ensemble', None)

                    logger.info(

                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận SELL mạnh, bỏ qua phiếu lưỡng lự nhẹ của AI Ensemble (%.1f%% < 50%%)!",

                        symbol_name, len(other_strats), abs(jev_vote) * 100, abs(ai_v) * 100

                    )



        for name, strategy_signals in by_strategy.items():
            if not strategy_signals:
                continue
            # Conflicting timeframes from the same strategy cancel each other.
            vote = sum(strategy_signals) / max(1, len(strategy_signals))
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                votes[name] = (vote, weight)
        return votes



    def _htf_conflicting_frames(
        self,
        signals: List[TradeSignal],
        active_votes: Optional[Dict[str, Tuple[float, float]]] = None,
    ) -> List[dict]:

        """[P2] Tìm các chiến thuật báo NGƯỢC CHIỀU trên nhiều khung thời gian.



        Chỉ xét khung thời gian có thật trong ``signal.metadata['timeframe']`` (do

        ``core/bot.py`` gắn khi chạy chiến thuật đa khung) và giữ tín hiệu tự tin nhất

        cho mỗi cặp (chiến thuật, khung). Một chiến thuật bị coi là xung đột khi tồn tại

        đồng thời một khung BUY và một khung SELL, cả hai đều >= ngưỡng tự tin.

        Nếu ``active_votes`` được truyền vào, bỏ qua các chiến thuật đã bị vô hiệu hóa

        hoặc loại bỏ hợp lệ trong ``_strategy_votes()`` (như Bull/Bear Trap dilution

        hoặc Smart Inversion loại bỏ Trap giả không râu).

        """

        frames: Dict[str, Dict[str, Tuple[float, float]]] = {}

        sym_chk = signals[0].symbol if signals else ''

        trap_ctx = {}

        if hasattr(self, '_trap_contexts_by_symbol') and sym_chk:

            trap_ctx = self._trap_contexts_by_symbol.get(sym_chk, {}) or self._trap_contexts_by_symbol.get(sym_chk.split(':')[0].strip().upper(), {})

        if not trap_ctx:

            trap_ctx = getattr(self, '_last_trap_context', {}) if isinstance(getattr(self, '_last_trap_context', None), dict) else {}

        has_confirmed_15m_override = bool(
            active_votes is not None
            and (
                trap_ctx.get('has_real_bull_trap')
                or trap_ctx.get('has_real_bear_trap')
                or trap_ctx.get('is_waterfall_dump')
                or trap_ctx.get('is_whale_pump_storm')
            )
        )

        for sig in signals or []:

            if sig.signal == Signal.BUY:

                direction = 1.0

            elif sig.signal == Signal.SELL:

                direction = -1.0

            else:

                continue

            metadata = getattr(sig, 'metadata', None)

            timeframe = str((metadata or {}).get('timeframe') or '').strip().lower()

            if not timeframe:

                continue

            try:

                confidence = float(sig.confidence)

            except (TypeError, ValueError):

                continue

            if not math.isfinite(confidence) or not (0.0 <= confidence <= 1.0):

                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', sig.strategy).lower()

            if active_votes is not None and name not in active_votes:

                continue

            if has_confirmed_15m_override and timeframe == '1h':

                # Chỉ miễn trừ chân 1H nếu 15M là Climax vật lý cực hạn (râu >= 45%) hoặc bão volume/thác đổ
                # Tuyệt đối không cho phép nến 15M râu nhỏ bỏ qua tín hiệu Trap xả/gom lớn của khung 1H!
                is_climax_or_whale = bool(
                    trap_ctx.get('is_true_climax_15m')
                    or trap_ctx.get('is_whale_pump_storm')
                    or trap_ctx.get('is_waterfall_dump')
                )
                if not is_climax_or_whale and name in ('trap_detector', 'trapdetector'):
                    pass  # Giữ nguyên chân 1H để phát hiện xung đột HTF, cấm bỏ qua!
                else:
                    active_dir = active_votes.get(name, (0.0, 0.0))[0] if active_votes else 0.0
                    if active_dir * direction < 0:
                        continue

            per_tf = frames.setdefault(name, {})

            prev = per_tf.get(timeframe)

            if prev is None or confidence > prev[1]:

                per_tf[timeframe] = (direction, confidence)



        try:

            threshold = float(getattr(self, 'htf_conflict_min_confidence', 0.60) or 0.60)

        except (TypeError, ValueError, OverflowError):

            threshold = 0.60



        conflicts: List[dict] = []

        for name, per_tf in frames.items():

            long_legs = [(tf, conf) for tf, (d, conf) in per_tf.items() if d > 0 and conf >= threshold]

            short_legs = [(tf, conf) for tf, (d, conf) in per_tf.items() if d < 0 and conf >= threshold]

            if long_legs and short_legs:

                conflicts.append({

                    'strategy': name,

                    'long': sorted(long_legs, key=lambda item: -item[1]),

                    'short': sorted(short_legs, key=lambda item: -item[1]),

                })

        return conflicts



    def calculate_weighted_score(self, signals: List[TradeSignal], votes: Optional[Dict[str, Tuple[float, float]]] = None, apply_entry_vetoes: bool = True, market_chop_context: Optional[Dict[str, Dict[str, float]]] = None) -> float:

        """Return the weighted mean of active strategy votes, in [-1, 1].
        Loại bỏ các chiến thuật tự triệt tiêu đa khung thời gian (|vote| < 0.15)
        để không làm pha loãng mẫu số total_weight của các chiến thuật có tín hiệu thật.
        """

        if votes is None:

            votes = self._strategy_votes(signals, apply_entry_vetoes=apply_entry_vetoes, market_chop_context=market_chop_context)

        active_votes = [(vote, weight) for vote, weight in votes.values() if abs(vote) >= 0.15]
        if not active_votes:
            active_votes = list(votes.values())

        total_weight = sum(weight for _, weight in active_votes)

        if total_weight <= 0:

            return 0.0

        return sum(vote * weight for vote, weight in active_votes) / total_weight



    def _entry_threshold(self, agreeing: int = 0) -> float:

        """Ngưỡng điểm tối thiểu thực tế để cấp lệnh = max(confidence_threshold, min_signal_score)."""

        try:

            floor = float(getattr(self, 'min_signal_score', 0.0) or 0.0)

        except (TypeError, ValueError):

            floor = 0.0

        base_threshold = max(float(self.confidence_threshold), floor)

        # Nếu có từ 3 chiến thuật trở lên đồng thuận tuyệt đối (agreeing >= 3) và ngưỡng gốc >= 0.80,

        # cho phép hạ sàn xuống 0.75 để không bỏ lỡ các siêu sóng bùng nổ (như LSK +33.6%, SPK -5.2%).

        if agreeing >= 3 and base_threshold >= 0.75:

            return 0.72

        return base_threshold



    def determine_final_signal(self, score: float, symbol: str, price: float, threshold: Optional[float] = None) -> TradeSignal:

        abs_score = abs(score)

        eff_threshold = threshold if threshold is not None else self._entry_threshold()

        if abs_score >= eff_threshold:

            direction = Signal.BUY if score > 0 else Signal.SELL

        else:

            direction = Signal.HOLD



        return TradeSignal(

            signal=direction,

            symbol=symbol,

            confidence=abs_score,

            strategy='aggregated',

            price=price,

        )



    def _aggregate_protection_level(

        self, signals: List[TradeSignal], final_signal: Signal, price: float, field: str,

    ) -> Optional[float]:

        """Carry a robust, directionally valid strategy SL/TP into the final vote.



        Aggregate percentage distances rather than absolute prices because each

        timeframe can report a slightly different last price. First collapse a

        strategy's timeframes with a median, then take a strategy-weighted median

        so one unusually wide stop/target cannot dominate the result.

        """

        if final_signal not in (Signal.BUY, Signal.SELL):

            return None

        try:

            reference_price = float(price)

        except (TypeError, ValueError, OverflowError):

            return None

        if not math.isfinite(reference_price) or reference_price <= 0:

            return None



        distances_by_strategy: Dict[str, List[float]] = {}

        for signal in signals:

            if signal.signal != final_signal:

                continue

            try:

                signal_price = float(signal.price)

                level = float(getattr(signal, field))

            except (TypeError, ValueError, OverflowError):

                continue

            if not math.isfinite(signal_price) or signal_price <= 0 or not math.isfinite(level) or level <= 0:

                continue



            if field == 'stop_loss':

                distance = (signal_price - level) / signal_price if final_signal == Signal.BUY else (level - signal_price) / signal_price

            else:

                distance = (level - signal_price) / signal_price if final_signal == Signal.BUY else (signal_price - level) / signal_price

            if not math.isfinite(distance) or distance <= 0:

                continue



            name = re.sub(r'(?<!^)(?=[A-Z])', '_', signal.strategy).lower()

            distances_by_strategy.setdefault(name, []).append(distance)



        weighted_distances = []

        for name, distances in distances_by_strategy.items():

            weight = self.strategy_weights.get(name, 0.1)

            if weight > 0:

                weighted_distances.append((statistics.median(distances), weight))

        if not weighted_distances:

            return None



        weighted_distances.sort(key=lambda item: item[0])

        half_weight = sum(weight for _, weight in weighted_distances) / 2.0

        cumulative = 0.0

        distance = weighted_distances[-1][0]

        for candidate, weight in weighted_distances:

            cumulative += weight

            if cumulative >= half_weight:

                distance = candidate

                break



        if final_signal == Signal.BUY:

            level = reference_price * (1.0 - distance) if field == 'stop_loss' else reference_price * (1.0 + distance)

        else:

            level = reference_price * (1.0 + distance) if field == 'stop_loss' else reference_price * (1.0 - distance)

        return level if math.isfinite(level) and level > 0 else None



    def aggregate(self, signals: List[TradeSignal], market_chop_context: Optional[Dict[str, Dict[str, float]]] = None) -> Optional[TradeSignal]:

        if not signals:

            return None

        if isinstance(signals, dict):
            signals = list(signals.values())
            if not signals:
                return None

        symbol = signals[0].symbol

        pre_llm_veto = next(

            (

                s for s in signals

                if isinstance(getattr(s, 'metadata', None), dict)

                and isinstance(s.metadata.get('pre_llm_entry_veto'), dict)

            ),

            None,

        )

        if pre_llm_veto:

            veto_data = pre_llm_veto.metadata['pre_llm_entry_veto']

            logger.warning(

                '🛡️ [PRE-LLM STRUCTURAL VETO] Hủy mở lệnh %s: JEV/MTF bị bỏ qua (%s); không cấp lệnh mới khi thiếu xác nhận cấu trúc.',

                symbol, veto_data.get('reason', veto_data.get('status', 'unknown')),

            )

            return None



        jev_signals = [

            s for s in signals

            if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')

        ]

        if not jev_signals:

            logger.warning(

                '🛡️ [JEV AVAILABILITY VETO] Hủy ứng viên %s: không có kết quả JEV/MTF; không cấp lệnh khi tầng này chưa chạy.',

                symbol,

            )

            return None



        unavailable_jev = next(

            (

                s for s in signals

                if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')

                and isinstance(getattr(s, 'metadata', None), dict)

                and s.metadata.get('availability_status') not in (None, '', 'ok')

            ),

            None,

        )

        if unavailable_jev:

            status = unavailable_jev.metadata.get('availability_status', 'unavailable')

            logger.warning(

                '🛡️ [JEV AVAILABILITY VETO] Hủy ứng viên %s: Ollama/JEV đang ở trạng thái %s; tiếp tục quét coin kế tiếp.',

                symbol, status,

            )

            return None



        price = signals[0].price

        clean_sym_agg = symbol.split(':')[0].strip().upper()

        clean_base_agg = clean_sym_agg.split('/')[0] if '/' in clean_sym_agg else clean_sym_agg

        is_tier1 = any(clean_base_agg == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))

        is_stock = MarketScanner.is_tradfi_stock(symbol)

        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol)

        is_tradfi = is_stock or is_commodity

        is_crypto_altcoin = (not is_tier1) and (not is_tradfi)



        has_cold_start = any(

            isinstance(getattr(s, 'metadata', None), dict)

            and s.metadata.get('status') == 'cold_start_warmup'

            for s in signals

        )



        votes = self._strategy_votes(signals, market_chop_context=market_chop_context)

        score = self.calculate_weighted_score(signals, votes=votes)

        agreeing = sum(1 for vote, _ in votes.values() if abs(vote) >= 0.15 and vote * score > 0)

        # [BÀI HỌC 102 - TÁCH ĐỒNG THUẬN KỸ THUẬT VÀ MÔ HÌNH AI/LLM]:
        # AI Ensemble và JEV Agent là hai mô hình tương quan (AI học từ đặc trưng kỹ thuật; JEV đọc các khung nến).
        # Tách agreeing_tech để kiểm soát cổng đồng thuận tối thiểu (min_agreeing_strategies) và Opposing Veto,
        # tránh trường hợp 1 kỹ thuật + AI + JEV = 3 tự thổi phồng số lượng chiến thuật kỹ thuật.
        # Đồng thời yêu cầu abs(vote) >= 0.15 để chiến thuật tự triệt tiêu (15m BUY + 1h SELL -> -0.005) không bị đếm ảo là 1 phiếu đồng thuận!
        _non_technical_voters = ('ai_ensemble', 'jev_agent')
        agreeing_tech = sum(
            1 for name, (vote, _) in votes.items()
            if abs(vote) >= 0.15 and vote * score > 0 and name not in _non_technical_voters
        )
        require_tech_consensus = bool(getattr(self, 'consensus_require_technical', True))
        consensus_count = agreeing_tech if require_tech_consensus else agreeing

        entry_threshold = self._entry_threshold(agreeing)

        logger.info(

            'Aggregated score for %s: %+.4f (threshold=%.2f, agreeing strategies=%d/%d, tech=%d)',

            symbol, score, entry_threshold, agreeing, len(votes), agreeing_tech,

        )



        # [P2] HTF CONFLICT VETO (chỉ áp dụng cho luồng MỞ LỆNH MỚI).

        # `_strategy_votes()` gộp các khung của cùng một chiến thuật bằng TRUNG BÌNH CỘNG

        # nên hai khung ngược chiều triệt tiêu nhau và xóa sạch cảnh báo (trap 1h SELL 67%

        # + 15m BUY 70% -> +0.015, vẫn "đồng thuận 3/3"). Một chiến thuật tự mâu thuẫn giữa

        # các khung là bất định thật sự -> không được cấp lệnh, bất kể `agreeing` bao nhiêu.

        if getattr(self, 'htf_conflict_veto', True):

            htf_conflicts = self._htf_conflicting_frames(signals, active_votes=votes)

            if htf_conflicts:

                detail_parts = []

                for conflict in htf_conflicts:

                    legs = (

                        [(tf, 'BUY', conf) for tf, conf in conflict['long']]

                        + [(tf, 'SELL', conf) for tf, conf in conflict['short']]

                    )

                    legs.sort(key=lambda item: item[0])

                    detail_parts.append(

                        conflict['strategy'] + ' ['

                        + ', '.join(f"{tf} {side} {conf * 100:.0f}%" for tf, side, conf in legs)

                        + ']'

                    )

                logger.warning(

                    '🛡️ [HTF CONFLICT VETO] Hủy mở lệnh %s: cùng một chiến thuật báo ngược chiều trên nhiều khung thời gian (ngưỡng %.0f%%), điểm tổng hợp %+.4f bị pha loãng bởi trung bình cộng: %s',

                    symbol, float(getattr(self, 'htf_conflict_min_confidence', 0.60)) * 100,

                    score, ' | '.join(detail_parts),

                )

                return None



        # Thu thập macro ADX và ATR từ market_analysis (nếu có) để chống bẫy Breakout giả & thẩm định vi mô

        macro_analysis = next(

            (

                s.metadata.get('market_analysis')

                for s in signals

                if isinstance(getattr(s, 'metadata', None), dict)

                and isinstance(s.metadata.get('market_analysis'), dict)

            ),

            {},

        )

        try:

            macro_adx = float((macro_analysis or {}).get('adx') or 0.0)

        except (TypeError, ValueError):

            macro_adx = 0.0

        try:

            tactical_adx = float((macro_analysis or {}).get('tactical_adx') or 0.0)

        except (TypeError, ValueError):

            tactical_adx = 0.0

        effective_adx = max(macro_adx, tactical_adx)

        try:

            macro_atr_pre = float((macro_analysis or {}).get('atr_pct') or 0.0)

        except (TypeError, ValueError):

            macro_atr_pre = 0.0



        # 0. COLD-START WARMUP VETO:

        # Nếu AI Ensemble vừa train mới (Cold-start Warmup), chỉ cho phép mở lệnh nếu:

        # - Model AI vừa train phải đạt Mean CV Accuracy >= 0.58 (tránh model học vẹt/nhiễu chỉ ngang tung đồng xu 53% như BABY/USDT).

        # - JEV Agent KHÔNG khuyến nghị HOLD (tránh thị trường nhiễu/lưỡng lự như PHA/USDT)

        # - Có >= 2 chiến thuật độc lập đồng thuận VÀ xu hướng vĩ mô mạnh (ADX >= 24.0, như INIT/USDT ADX=29.9 hay DOGE ADX=51.1).

        # Nếu JEV khuyến nghị HOLD hoặc ADX < 24.0 hoặc < 2 chiến thuật (như TIA/USDT ADX=19.1, FOGO 1/1, PHA 1/1), chặn 100%!

        if has_cold_start:

            cs_sig = next((s for s in signals if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('status') == 'cold_start_warmup'), None)

            trained_cv = float((cs_sig.metadata.get('mean_cv_accuracy') or 0.0) if cs_sig else 0.0)

            if trained_cv < 0.58:

                logger.warning(

                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: Model AI vừa train có độ chính xác CV yếu (%.2f%% < 58.0%%), không đủ tin cậy để cấp lệnh!',

                    symbol, trained_cv * 100,

                )

                return None

            jev_sig_cs = next((s for s in signals if s.strategy.lower() in ('jev_agent', 'jevagent')), None)

            if jev_sig_cs and jev_sig_cs.signal == Signal.HOLD and not (macro_adx >= 40.0 and abs(score) >= 0.84 and agreeing >= 2):

                logger.info(

                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi JEV Agent phân tích MTF khuyến nghị HOLD!',

                    symbol,

                )

                return None

            if agreeing < self.min_agreeing_strategies or macro_adx < 24.0:

                logger.info(

                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi ADX=%.1f < 24.0 hoặc đồng thuận=%d/%d chưa đủ mạnh!',

                    symbol, macro_adx, agreeing, self.min_agreeing_strategies,

                )

                return None



        # [BÀI HỌC 101 - JEV HOLD VETO TOÀN DIỆN CHO MỌI ỨNG VIÊN]:
        # Khi JEV Agent MTF phân tích sâu (4H, 1H, 15M, 5M) và xác định thị trường lưỡng lự / tích lũy đi ngang / rủi ro
        # ra quyết định HOLD (confidence >= 0.55): BẮT BUỘC tôn trọng phán quyết của Master AI!
        # Tuyệt đối cấm để 1-2 chỉ báo kỹ thuật trễ pha (như 1H cũ) cướp quyền mở lệnh cản tàu (như thảm họa AXTI).
        # Miễn trừ duy nhất: Khi có Bão Volume Cá Mập (Whale Pump Storm / Waterfall Dump / Climax) HOẶC Siêu Đồng Thuận Số Đông (>= 3 kỹ thuật cùng chiều điểm >= 0.82).
        jev_sig_gen = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)
        if jev_sig_gen and getattr(jev_sig_gen, 'signal', None) == Signal.HOLD:
            jev_conf_hold = float(getattr(jev_sig_gen, 'confidence', 0.0) or 0.0)
            if jev_conf_hold >= 0.55:
                c_dump_h = float((macro_analysis or {}).get('recent_dump_pct') or 0.0)
                c_pump_h = float((macro_analysis or {}).get('recent_pump_pct') or 0.0)
                _raw_c_vol_h = (macro_analysis or {}).get('candle_vol_ratio')
                c_vol_h = float(_raw_c_vol_h) if _raw_c_vol_h is not None else 1.0
                c_uwick_h = float((macro_analysis or {}).get('upper_wick_pct') or 0.0)
                c_lwick_h = float((macro_analysis or {}).get('lower_wick_pct') or 0.0)
                
                jev_hold_txt = (
                    str(getattr(jev_sig_gen, 'metadata', {}).get('reason', '') or '')
                    + ' '
                    + str(getattr(jev_sig_gen, 'metadata', {}).get('risk_factors', '') or '')
                ).lower()
                is_jev_bearish_warning_for_short = (
                    score < 0
                    and agreeing >= 2
                    and not any(w in jev_hold_txt for w in ('choppy consolidation', 'flat sideways', 'support bounce', 'lower absorption wick', 'oversold'))
                    and any(
                        w in jev_hold_txt
                        for w in (
                            'heavy bearish', 'strong bearish', 'active dumping', 'active selling',
                            'no absorption wick', 'top rejection', 'upper rejection wick',
                            'bull trap', 'bull exhaustion', 'upside exhaustion', 'high-volume red'
                        )
                    )
                )
                # CHỈ CÓ THỰC LỰC CỦA DÒNG TIỀN CÁ MẬP THẬT SỰ (Vol bùng nổ >= 2.0x hoặc râu quét cực đại >= 45%)
                # HOẶC KHI JEV CẢNH BÁO XẢ ĐỈNH/DUMP KHÔNG RÂU THUẬN CHIỀU SHORT (score < 0, agreeing >= 2)
                # MỚI ĐƯỢC PHÉP OVERRIDE JEV HOLD! TUYỆT ĐỐI CẤM SỰ ĐỒNG THUẬN KỸ THUẬT DANH NGHĨA
                # (abs(score) >= 0.82) CƯỚP QUYỀN MỞ LỆNH KHI JEV CẢNH BÁO CẢN HOẶC TÍCH LŨY (như INTC/USDT)!
                has_whale_override = (
                    (c_vol_h >= 2.0 and (c_pump_h >= 0.025 or c_dump_h >= 0.025))
                    or (c_lwick_h >= 0.45 and c_vol_h >= 1.60 and c_dump_h >= 0.015)
                    or (c_uwick_h >= 0.45 and c_vol_h >= 1.60 and c_pump_h >= 0.015)
                    or is_jev_bearish_warning_for_short
                )
                if not has_whale_override:
                    jev_hold_reason = str(getattr(jev_sig_gen, 'metadata', {}).get('reason', '') or 'Thị trường lưỡng lự/nhiễu vi mô')
                    logger.warning(
                        f"🛡️ [JEV HOLD VETO] Hủy mở lệnh {symbol}: JEV Agent MTF (Ollama LLM) khuyến nghị HOLD (Conf: {jev_conf_hold:.1%}) - {jev_hold_reason}! Cấm mở lệnh khi Master AI cảnh báo rủi ro."
                    )
                    return None

        has_breakout_vote = 'momentum_breakout' in votes and (votes['momentum_breakout'][0] * score > 0)

        has_trend_support = 'trend_following' in votes and (votes['trend_following'][0] * score > 0)

        has_trend_or_trap_support = has_trend_support or ('trap_detector' in votes and (votes['trap_detector'][0] * score > 0))

        if has_breakout_vote and macro_adx < 22.0 and not has_trend_or_trap_support:

            logger.warning(

                '🛡️ [WEAK-ADX BREAKOUT VETO] Hủy lệnh %s: MomentumBreakout phát tín hiệu khi ADX vĩ mô quá yếu (ADX=%.1f < 22.0) và thiếu xác nhận Trend/Trap!',

                symbol, macro_adx,

            )

            return None



        # Yêu cầu bắt buộc đủ số chiến thuật đồng thuận (tối thiểu >= min_agreeing_strategies, cấm 1 chiến thuật đơn lẻ tự vượt rào như FOGO/USDT)

        trap_ctx = {}

        if hasattr(self, '_trap_contexts_by_symbol'):

            trap_ctx = self._trap_contexts_by_symbol.get(symbol, {}) or self._trap_contexts_by_symbol.get(clean_sym_agg, {})

        if not trap_ctx:

            trap_ctx = getattr(self, '_last_trap_context', {}) or {}

        has_real_bull_trap_ctx = bool(trap_ctx.get('has_real_bull_trap'))

        has_real_bear_trap_ctx = bool(trap_ctx.get('has_real_bear_trap'))

        has_valid_trap_vol_ctx = bool(trap_ctx.get('has_valid_trap_vol', False))

        is_whale_pump_ctx = bool(trap_ctx.get('is_whale_pump_storm'))

        is_waterfall_ctx = bool(trap_ctx.get('is_waterfall_dump'))

        neutralized_bull_ctx = trap_ctx.get('neutralized_bull', [])

        neutralized_bear_ctx = trap_ctx.get('neutralized_bear', [])

        raw_trap_conf = max(

            (

                float(getattr(s, 'confidence', 0.0) or 0.0)

                for s in signals

                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')

                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)

            ),

            default=0.0,

        )

        

        # [BÀI HỌC 86 - SỬA LỖI NGHỊCH LÝ ĐỒNG THUẬN BẪY]:

        # Khi CẢ 3 CHIẾN THUẬT ĐỒNG THUẬN (agreeing >= 2), không có chiến thuật nào bị vô hiệu hóa (len == 0).

        # Bổ sung 'or agreeing >= 2' để setup đồng thuận tuyệt đối của Cá Mập không bị đánh rớt!

        trap_sig_obj = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector') and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)), None)
        trap_aligned_with_score = (trap_sig_obj is not None) and ((trap_sig_obj.signal == Signal.BUY and score > 0) or (trap_sig_obj.signal == Signal.SELL and score < 0))
        is_confirmed_trap_reversal = (

            (has_real_bull_trap_ctx and (len(neutralized_bull_ctx) > 0 or agreeing >= 2) and score < 0)

            or (has_real_bear_trap_ctx and (len(neutralized_bear_ctx) > 0 or agreeing >= 2) and score > 0)

            or (is_whale_pump_ctx and score > 0)

            or (is_waterfall_ctx and score < 0)

            or (bool(trap_ctx.get('is_ai_absorption_buy')) and score > 0)
            or (bool(trap_ctx.get('is_ai_exhaustion_sell')) and score < 0)
            or (bool(raw_trap_conf >= 0.75) and trap_aligned_with_score and abs(score) >= 0.50 and (has_breakout_vote or has_trend_support or agreeing >= 2))
            or (bool(has_breakout_vote) and agreeing >= 3 and effective_adx >= 25.0)
        )



        # [BÀI HỌC 109 & V3.6 - ĐỒNG THUẬN 3 TRỤ CỘT & 2 TRỤ CỘT HỘI TỤ CAO (DUAL-PILLAR HIGH-CONVICTION & UNOPPOSED WHALE GATE)]:
        # 1. is_multi_pillar_triad: 3 Trụ cột (Tech + AI Ensemble + JEV Agent) đồng thuận |score| >= 0.72.
        # 2. is_dual_pillar_high_conviction: Khi KB10 Dual-Brain đã rút gọn phiếu phụ còn 2 Trụ cột (1 Tech + JEV >= 70% hoặc AI >= 75%)
        #    nhưng điểm hội tụ rất cao (|score| >= 0.78) và 0 phiếu chống (như XRP/USDT -0.8144, US/USDT -0.8233).
        # 3. is_unopposed_whale_flow_gate: Khi có sóng cá mập (Whale Pump Storm / Waterfall Dump) với >= 1 Tech đồng thuận (|score| >= 0.42)
        #    và KHÔNG bị JEV 4H (>= 70%) hay AI Ensemble (>= 70%) đối kháng ngược chiều, cho phép đi tiếp tới cổng Smart Inversion.
        jev_vote_agg = float(votes.get('jev_agent', (0.0, 0.0))[0])
        ai_vote_agg = float(votes.get('ai_ensemble', (0.0, 0.0))[0])
        has_jev_strong_opposing = any(
            getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')
            and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)
            and ((1.0 if s.signal == Signal.BUY else -1.0) * score < 0)
            and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
            for s in signals
        )
        has_ai_strong_opposing = any(
            getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')
            and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)
            and ((1.0 if s.signal == Signal.BUY else -1.0) * score < 0)
            and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
            for s in signals
        )
        is_multi_pillar_triad = (
            agreeing >= 3
            and agreeing_tech >= 1
            and abs(score) >= 0.72
            and not any(v * score < 0 and abs(v) >= 0.70 for _, (v, _) in votes.items())
        )
        is_dual_pillar_high_conviction = (
            agreeing >= 2
            and agreeing_tech >= 1
            and abs(score) >= 0.78
            and not any(v * score < 0 and abs(v) >= 0.35 for _, (v, _) in votes.items())
            and not has_jev_strong_opposing
            and not has_ai_strong_opposing
            and (
                (jev_vote_agg * score > 0 and abs(jev_vote_agg) >= 0.70)
                or (ai_vote_agg * score > 0 and abs(ai_vote_agg) >= 0.75)
            )
        )
        is_unopposed_whale_flow_gate = (
            (is_whale_pump_ctx or is_waterfall_ctx)
            and agreeing_tech >= 1
            and abs(score) >= 0.42
            and not has_jev_strong_opposing
            and not has_ai_strong_opposing
            and not any(v * score < 0 and abs(v) >= 0.70 for _, (v, _) in votes.items())
        )

        if consensus_count < self.min_agreeing_strategies:

            if is_multi_pillar_triad:

                logger.info(

                    '⚡ [MULTI-PILLAR TRIAD CONSENSUS] Cho phép lệnh %s thông qua: Đồng thuận 3 trụ cột thực chất (Tech=%d + AI Ensemble + JEV Agent, score=%+.4f, total=%d)!',

                    symbol, agreeing_tech, score, agreeing,

                )

            elif is_dual_pillar_high_conviction:

                logger.info(

                    '⚡ [DUAL-PILLAR HIGH-CONVICTION V3.6] Cho phép lệnh %s thông qua: Đồng thuận 2 trụ cột hội tụ cao không đối kháng (Tech=%d, JEV=%+.2f, AI=%+.2f, score=%+.4f, total=%d)!',

                    symbol, agreeing_tech, jev_vote_agg, ai_vote_agg, score, agreeing,

                )

            elif is_confirmed_trap_reversal and agreeing >= 2 and agreeing_tech >= 1:

                logger.info(

                    '⚡ [TRAP SETUP MULTI-CONSENSUS] Cho phép lệnh %s thông qua: Bẫy cá mập được xác nhận đa tầng (TrapDetector + Kỹ thuật bứt phá: %s, tech=%d, total=%d)!',

                    symbol, ', '.join(neutralized_bull_ctx if score < 0 else neutralized_bear_ctx) if (neutralized_bull_ctx or neutralized_bear_ctx) else 'Breakout/Trap',

                    agreeing_tech, agreeing,

                )

            elif is_unopposed_whale_flow_gate:

                logger.info(

                    '🌊 [UNOPPOSED WHALE FLOW GATE V3.6] Cho phép ứng viên dòng tiền cá mập %s thông qua tới cổng Smart Inversion (Tech=%d, score=%+.4f, WhalePump=%s, Waterfall=%s)!',

                    symbol, agreeing_tech, score, is_whale_pump_ctx, is_waterfall_ctx,

                )

            else:

                logger.info(

                    'No trade for %s: need %d agreeing strategies, got %d (tech=%d, total=%d)',

                    symbol, self.min_agreeing_strategies, consensus_count, agreeing_tech, agreeing,

                )

                return None



        # PHƯƠNG ÁN A+: PHỦ QUYẾT CHIẾN LƯỢC ĐỐI KHÁNG KHI ĐỒNG THUẬN YẾU (<= 2)

        # Nếu chỉ có 2 chiến thuật đồng thuận (mức sàn tối thiểu) mà có bất kỳ chiến thuật nào

        # (như TrapDetector, AI Ensemble, hoặc Momentum) đối kháng ngược chiều (confidence >= 0.60):

        # Lập tức VETO để triệt tiêu các lệnh đu đỉnh râu nến (như ZEREBRO, SOL, ETH, DUSK)!

        exempt_ai_opposing = False

        if consensus_count <= self.min_agreeing_strategies and not (is_multi_pillar_triad or is_dual_pillar_high_conviction):

            opposing_strats = [

                f"{s_name} ({v:+.2f})" for s_name, (v, _) in votes.items()

                if v * score < 0 and abs(v) >= 0.60

            ]

            if opposing_strats:

                # Kịch Bản 2: Miễn trừ nếu duy nhất AI Ensemble trễ pha 4H đối kháng vừa phải (<70%) trong khi nến 15M có Trap/Reversal mạnh (>= 75%) và ADX >= 25.0

                only_ai_opposing = all('ai_ensemble' in s for s in opposing_strats)

                # Tuyệt đối KHÔNG miễn trừ khi AI Ensemble đối kháng cực độ (>= 70%) trên Altcoins để né đu đỉnh
                ai_opposing_extreme = any(

                    getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')

                    and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)

                    and ((1.0 if s.signal == Signal.BUY else -1.0) * score < 0)

                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70

                    for s in signals

                )

                # Chỉ tính các chiến thuật kỹ thuật độc lập (non-AI) đồng pha cùng chiều với score (không tính HOLD hay ngược chiều)

                agreeing_non_ai_signals = [

                    s for s in signals

                    if getattr(s, 'strategy', '').lower() not in ('jev_agent', 'jevagent', 'ai_ensemble', 'aiensemble')

                    and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)

                    and ((1.0 if s.signal == Signal.BUY else -1.0) * score > 0)

                ]

                has_strong_reversal = (

                    any(

                        getattr(s, 'strategy', '').lower() in ('trap_detector', 'mean_reversion')

                        and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70

                        for s in agreeing_non_ai_signals

                    )

                    or max((float(getattr(s, 'confidence', 0.0) or 0.0) for s in agreeing_non_ai_signals), default=0.0) >= 0.75

                )

                # [TRIỂN KHAI KB 10 CHÍNH THỨC - PHÂN TẦNG LỚP TÀI SẢN & MIỄN TRỪ OPPOSING VETO CHO MAJOR / TRADFI]
                is_major = is_tier1 or (clean_base_agg == 'BCH')
                is_exempt_asset_class = (is_major or is_tradfi)

                has_macro_trend_support = (
                    any(float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70 for s in agreeing_non_ai_signals)
                    or any(
                        getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')
                        and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)
                        and ((1.0 if s.signal == Signal.BUY else -1.0) * score > 0)
                        and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                        for s in signals
                    )
                )

                if only_ai_opposing and is_exempt_asset_class and has_macro_trend_support:
                    # 1. MAJOR CRYPTO & TRADFI: Bãi bỏ điều kiện ai_opposing_extreme, miễn trừ Veto để đi cùng
                    #    xu hướng vĩ mô JEV LLM 4H & TrendFollowing, sau đó vào M1 Sniper Limit Maker đón retest!
                    exempt_ai_opposing = True
                    logger.info(
                        "⚡ [KB 10 DUAL-BRAIN EXEMPTION] %s (%s): Ưu tiên tuyệt đối xu hướng vĩ mô JEV LLM 4H & TrendFollowing (>=70%%), bãi bỏ Veto vi mô của AI Ensemble!",
                        symbol, "Major Crypto" if is_major else "TradFi",
                    )
                elif only_ai_opposing and not ai_opposing_extreme and has_strong_reversal and (macro_adx <= 0.0 or macro_adx >= 25.0):
                    # 2. ALTCOINS: BẮT BUỘC GIỮ NGUYÊN 100% VETO của Não Tĩnh khi ai_opposing_extreme (>=70%)
                    #    để chặn đứng 628 cú xả đỉnh rác như đã chứng minh ở KB 2!
                    exempt_ai_opposing = True
                    logger.info(
                        "⚡ [MIỄN TRỪ OPPOSING VETO ALTCOIN] %s: Kỹ thuật 15M đảo chiều mạnh (>=75%%, ADX=%.1f >= 25.0), bỏ qua phiếu đối kháng 4H của AI Ensemble!",
                        symbol, macro_adx,
                    )
                else:
                    logger.warning(
                        '🚫 [OPPOSING STRATEGY VETO] Hủy mở lệnh %s: Đồng thuận yếu (%d chiến thuật) trong khi có chiến thuật đối kháng mạnh: %s!',
                        symbol, agreeing, ", ".join(opposing_strats),
                    )
                    return None



        # Yêu cầu bắt buộc ít nhất 1 chiến thuật kỹ thuật độc lập (Trend, Breakout, MR, Trap) đồng thuận

        non_ai_agreeing = sum(

            1 for s_name, (v, _) in votes.items()

            if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0

        )

        if non_ai_agreeing < 1:

            logger.info(

                'No trade for %s: cần ít nhất 1 chiến thuật kỹ thuật độc lập (non-AI) đồng thuận, hiện có %d',

                symbol, non_ai_agreeing,

            )

            return None



        # SÀN ĐỒNG THUẬN VI MÔ (ADAPTIVE MICRO CONSENSUS):

        # Đối với Altcoin và Cổ phiếu (ngoài BTC/ETH):

        # Nếu AI Ensemble có độ tự tin thấp/vừa phải (< 60%),

        # thì BẮT BUỘC phải có xu hướng thực chất (ADX >= 30.0, không biến động hỗn loạn ATR < 5.0%) kèm đồng thuận mạnh:

        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 2 chiến thuật kỹ thuật (như CYS ADX=52.8)

        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 1 kỹ thuật + JEV Agent khẳng định mạnh (Conf >= 80%, như INIT ADX=31.6, AVAX ADX=32.2)!

        # Quy tắc này triệt tiêu 100% lệnh thua yếu lực (TAO ADX=26.0, AERO ADX=20.1, WLD ADX=26.4, ON ATR=5.58%)

        # trong khi bảo toàn trọn vẹn 100% các lệnh thắng đa đồng thuận (CYS, INIT, AVAX)!

        clean_sym_pre = symbol.split(':')[0].strip().upper()

        clean_base_pre = clean_sym_pre.split('/')[0] if '/' in clean_sym_pre else clean_sym_pre

        is_tier1 = any(clean_base_pre == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))

        ai_sig = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')), None)

        jev_sig_pre = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)

        jev_conf_pre = 0.0

        if jev_sig_pre:

            try:

                jev_conf_pre = float(jev_sig_pre.confidence)

            except (TypeError, ValueError):

                jev_conf_pre = 0.0



        # Nhận diện đảo chiều Trap mạnh để miễn trừ Dead ADX và hỗ trợ Micro Consensus

        # [BÀI HỌC 86]: Chuẩn hóa ngưỡng Trap đảo chiều 0.68 và bao quát cả real trap / whale flow

        has_strong_trap_reversal = (

            bool(is_confirmed_trap_reversal)

            or bool(has_real_bull_trap_ctx and score < 0)

            or bool(has_real_bear_trap_ctx and score > 0)

            or bool(is_whale_pump_ctx and score > 0)

            or bool(is_waterfall_ctx and score < 0)

            or any(

                getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')

                and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.68

                for s in signals

            )

        )



        # DEAD ADX VETO: Thị trường cạn kiệt xung lực (cả ADX 4H và ADX 15M đều < 20.0)

        # Bắt buộc VETO toàn bộ tín hiệu TrendFollowing / Breakout trên Altcoin khi effective_adx < 20.0

        # (chặn đứng DASH ADX=13.1), trừ khi có Trap/Reversal, Whale Pump, Waterfall, hoặc đồng thuận kỹ thuật mạnh (agreeing >= 3)!

        if is_crypto_altcoin and (0.0 < effective_adx < 20.0):

            if not (has_strong_trap_reversal or agreeing >= 3):

                logger.warning(

                    '🛡️ [DEAD ADX VETO] Hủy mở lệnh %s: Thị trường hoàn toàn đi ngang/cạn kiệt xung lực (ADX_4H=%.1f, ADX_15M=%.1f < 20.0)! Cấm mở lệnh theo xu hướng để tránh chôn vốn!',

                    symbol, macro_adx, tactical_adx

                )

                return None



        # [SỬA LỖI GỐC RỄ - ML FAIL-OPEN] Nếu _ai_analysis() ném ngoại lệ (model chưa train, thiếu

        # feature, lỗi suy luận), bot KHÔNG sinh ra tín hiệu ai_ensemble nào. Trước đây khối sàn

        # đồng thuận vi mô bên dưới được bảo vệ bằng `if ai_sig and ...`, nên khi AI vắng mặt thì

        # toàn bộ tầng thẩm định vi mô bị bỏ qua và lệnh được cấp chỉ với 1 chiến thuật kỹ thuật.

        # Nay AI vắng mặt được coi tương đương "AI Ensemble 0%": bắt buộc phải đạt chuẩn vi mô.

        ai_missing = ai_sig is None and not has_cold_start

        ai_gate_applies = (

            ai_missing

            or (

                ('ai_ensemble' in votes)

                or (ai_sig is not None and ai_sig.signal == Signal.HOLD and not has_cold_start)

            )

        )

        if ai_gate_applies and not is_tier1:

            if ai_missing:

                ai_c = 0.0
                ai_pred_dir = ''

            else:

                try:
                    ai_meta_raw = getattr(ai_sig, 'metadata', None) if isinstance(getattr(ai_sig, 'metadata', None), dict) else {}
                    ai_pred_dir = str(ai_meta_raw.get('prediction') or '').strip().lower()
                    ai_raw_conf = float(ai_meta_raw.get('model_confidence') or getattr(ai_sig, 'confidence', 0.0) or 0.0)
                    if ai_sig.signal == Signal.HOLD:
                        # Nếu AI bị nén thành HOLD do dynamic_threshold trong HIGH_VOLATILITY nhưng có model_confidence >= 0.65,
                        # vẫn trích xuất độ tự tin thực để nhận diện đúng hướng đối kháng của AI Ensemble!
                        ai_c = ai_raw_conf if ai_raw_conf >= 0.65 else 0.0
                    else:
                        ai_c = float(ai_sig.confidence)

                except (TypeError, ValueError):

                    ai_c = 0.0
                    ai_pred_dir = ''

            ai_is_opposing = bool(

                ai_sig is not None

                and (

                    (ai_sig.signal == Signal.BUY and score < 0)

                    or (ai_sig.signal == Signal.SELL and score > 0)

                    or (ai_sig.signal == Signal.HOLD and ai_c >= 0.65 and ((ai_pred_dir == 'up' and score < 0) or (ai_pred_dir == 'down' and score > 0)))

                )

            )

            adx_floor = 25.0 if exempt_ai_opposing else 30.0

            adx_ok_micro = (macro_adx <= 0.0) or (macro_adx >= adx_floor)

            atr_ok_micro = (macro_atr_pre <= 0.0) or (macro_atr_pre < 5.0)

            if ai_is_opposing or ai_c < 0.60:

                # Phân nhánh Tầng 4 (bắt buộc thỏa mãn đồng thời ADX >= 30.0, ATR < 5.0% và không bị AI phản bác

                # hoặc được miễn trừ chính thức do kỹ thuật 15M đảo chiều mạnh):

                # Khi AI Ensemble yếu (< 60%) hoặc KHÔNG KHẢ DỤNG, bắt buộc phải có ít nhất 2 chiến thuật

                # kỹ thuật độc lập đồng thuận HOẶC 1 kỹ thuật độc lập + JEV Agent khẳng định mạnh (>= 80%):

                # [BÀI HỌC 95 - OPPOSING PILLAR VETO & WHALE SOLO ANCHOR PROTECTION]:
                # 1) Chỉ VETO lệnh Solo (agreeing < 2) khi có Trụ Cột lớn (AI Ensemble hoặc JEV) đối kháng cực đoan (>= 70%).
                # 2) Bảo toàn trọn vẹn 100% các lệnh Solo có Dòng tiền Cá Mập bảo trợ (FOGO, CBRS, BLESS, Smart Inversion) khi AI/JEV không đối kháng mạnh!
                ai_strong_opposing = (not exempt_ai_opposing) and ai_is_opposing and (ai_c >= 0.70)
                jev_is_buy = getattr(jev_sig_pre, 'signal', None) in (Signal.BUY, 'BUY', 'buy')
                jev_is_sell = getattr(jev_sig_pre, 'signal', None) in (Signal.SELL, 'SELL', 'sell')
                jev_strong_opposing = bool(jev_sig_pre is not None and ((jev_is_buy and score < 0) or (jev_is_sell and score > 0)) and (jev_conf_pre >= 0.70))
                
                has_whale_anchor_solo = (agreeing >= 1) and (
                    has_strong_trap_reversal or bool(is_whale_pump_ctx) or bool(is_waterfall_ctx) or bool(is_confirmed_trap_reversal)
                )
                has_tech_support = (non_ai_agreeing >= 2) or (non_ai_agreeing >= 1 and jev_conf_pre >= 0.80) or (exempt_ai_opposing and non_ai_agreeing >= 1) or is_confirmed_trap_reversal or has_strong_trap_reversal

                is_strong_consensus = (
                    (not (ai_strong_opposing or jev_strong_opposing))
                    and (has_tech_support or (has_whale_anchor_solo and not ai_is_opposing))
                    and (adx_ok_micro or is_confirmed_trap_reversal or has_strong_trap_reversal)
                    and atr_ok_micro
                )

                if not is_strong_consensus:

                    logger.info(

                        '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble %s (%.2f%%) và cấu trúc vi mô (agree=%d, non_ai=%d, jev=%.2f, ADX=%.1f, ATR=%.2f%%) chưa đạt chuẩn!',

                        symbol,

                        'KHÔNG KHẢ DỤNG' if ai_missing else ('NGƯỢC CHIỀU' if ai_is_opposing else 'yếu (<60%)'),

                        ai_c * 100, agreeing, non_ai_agreeing, jev_conf_pre, macro_adx, macro_atr_pre

                    )

                    return None

            elif ai_c < 0.70 and (macro_adx < 22.0 or (not adx_ok_micro and macro_atr_pre >= 3.0)):

                logger.info(

                    '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble trung bình (%.2f%% < 70%%) nhưng xung lượng vĩ mô yếu hoặc biến động cao (ADX=%.1f, ATR=%.2f%%)!',

                    symbol, ai_c * 100, macro_adx, macro_atr_pre

                )

                return None



        final_signal = self.determine_final_signal(score, symbol, price, threshold=entry_threshold)
        c_upper_wick_pct = 0.0
        c_lower_wick_pct = 0.0
        c_vol_ratio = 1.0
        is_uptrend = False
        is_downtrend = False

        if final_signal.signal != Signal.HOLD:

            # Thu thập market analysis từ tín hiệu 4H và nến đóng hoàn chỉnh sớm nhất để sẵn sàng cho mọi tầng

            market_analysis = next(

                (

                    signal.metadata.get('market_analysis')

                    for signal in signals

                    if isinstance(getattr(signal, 'metadata', None), dict)

                    and isinstance(signal.metadata.get('market_analysis'), dict)

                ),

                {},

            )

            has_bear_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] > 0
                and has_valid_trap_vol_ctx
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
                    for s in signals
                )
            )
            has_bull_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] < 0
                and has_valid_trap_vol_ctx
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
                    for s in signals
                )
            )
            has_real_bull_trap = has_bull_trap_wick or bool(has_real_bull_trap_ctx and score < 0) or bool(is_confirmed_trap_reversal and score < 0)
            has_real_bear_trap = has_bear_trap_wick or bool(has_real_bear_trap_ctx and score > 0) or bool(is_confirmed_trap_reversal and score > 0)
            jev_sig = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)

            # --- BỘ LỌC CỰC HẠN & BẢO VỆ ĐỈNH ĐÁY (CLIMAX & SMART INVERSION GATE) ---
            # [BÀI HỌC 78, 79, 80 & 82]: Thực hiện chuyển hóa Lưỡng Pha thông minh TRƯỚC MTF Trend Filter
            # để hướng lệnh cuối cùng (thực tế tác chiến) được thẩm định chính xác thay vì đánh giá trên hướng nến bứt phá ban đầu.
            try:
                macro_atr_pct = float(market_analysis.get('atr_pct') or 0.0)
                tactical_atr_15m_pct = float(market_analysis.get('tactical_atr_pct') or macro_atr_pct or 0.0)
            except (TypeError, ValueError):
                macro_atr_pct = 0.0
                tactical_atr_15m_pct = 0.0
            try:
                current_rsi = float(market_analysis.get('tactical_rsi') or market_analysis.get('rsi') or 50.0)
            except (TypeError, ValueError):
                current_rsi = 50.0

            # Candlestick Anatomy Metrics từ nến đã đóng iloc[-2] (chống bẫy kiệt sức mua/bán cá mập)
            c_upper_wick_pct = float(market_analysis.get('upper_wick_pct') or 0.0)
            c_lower_wick_pct = float(market_analysis.get('lower_wick_pct') or 0.0)
            _raw_c_vol_agg = market_analysis.get('candle_vol_ratio')
            c_vol_ratio = float(_raw_c_vol_agg) if _raw_c_vol_agg is not None else 1.0
            c_recent_pump = float(market_analysis.get('recent_pump_pct') or 0.0)
            c_recent_dump = float(market_analysis.get('recent_dump_pct') or 0.0)
            in_fading_short_watchlist = bool(market_analysis.get('in_fading_short_watchlist', False))

            original_signal = final_signal.signal

            # [BÀI HỌC 78, 79, 80, 82 & 92] KIẾN TRÚC LƯỠNG PHA & CHUYỂN HÓA BẮT ĐỈNH/ĐÁY TOÀN DIỆN
            # 0. BỘ LỌC THÁC ĐỔ (WATERFALL DUMP PROTECTION):
            # Khi Altcoin đang rơi tự do (Dump >= 2.5% hoặc rơi mạnh >= 3.5%) mà thiếu râu gom hàng (< 30%),
            # TUYỆT ĐỐI KHÔNG bắt dao rơi (chặn đứng thảm họa ZAMA: nến râu dưới 1.4%, rvol 0.59x)!
            # [BÀI HỌC 92]: Cấm nhận diện WaterfallDump nếu nến hiện tại đang bật tăng xanh mạnh (is_live_rebounding)!
            is_live_rebounding = bool(market_analysis.get('is_live_rebounding', False))

            # [BÀI HỌC 103 & KB5 CHUẨN HÓA XUNG ĐỘT 1 - ĐỐI XỨNG LƯỠNG CỰC CÓ RÂU VẬT LÝ CHO CẢ 3 LỚP TÀI SẢN]:
            # Mở khóa toàn bộ 3 lớp tài sản (Major Crypto, TradFi, Crypto Altcoins) và phân tầng ngưỡng theo ATR thực tế.
            is_altcoin_or_tradfi = True
            parabolic_thresh = 0.032 if is_tier1 else (0.040 if is_tradfi else 0.055)
            parabolic_ext = 0.042 if is_tier1 else (0.052 if is_tradfi else 0.070)
            is_panic_selling_climax = (
                ((c_recent_dump >= parabolic_thresh and c_vol_ratio >= 1.80 and c_lower_wick_pct >= 0.30)
                 or (c_recent_dump >= parabolic_ext and c_lower_wick_pct >= 0.25))
            )
            is_parabolic_pump_climax = (
                ((c_recent_pump >= parabolic_thresh and c_vol_ratio >= 1.80 and c_upper_wick_pct >= 0.30)
                 or (c_recent_pump >= parabolic_ext and c_upper_wick_pct >= 0.25))
            )

            # 0. BỘ LỌC THÁC ĐỔ (WATERFALL DUMP PROTECTION - CHUẨN HÓA 3 LỚP TÀI SẢN):
            # [V3.7 SSOT FIX #5]: Dùng đúng ATR tác chiến 15M đồng bộ 100% với core/bot.py
            macro_rsi = float(market_analysis.get('rsi') or 50.0)
            eff_atr_dec = (tactical_atr_15m_pct / 100.0) if tactical_atr_15m_pct > 0.20 else tactical_atr_15m_pct
            if is_crypto_altcoin:
                min_waterfall_dump = min(0.038, max(0.020, 1.25 * eff_atr_dec)) if eff_atr_dec > 0 else 0.020
                max_wf_dump = 0.055
                wf_rvol_std = 1.30
            elif is_tradfi:
                min_waterfall_dump = max(0.010, 1.10 * eff_atr_dec) if eff_atr_dec > 0 else 0.010
                max_wf_dump = 0.045
                wf_rvol_std = 1.25
            else:  # Major Crypto (BTC, ETH, SOL, BNB, XRP)
                min_waterfall_dump = max(0.010, 1.20 * eff_atr_dec) if eff_atr_dec > 0 else 0.010
                max_wf_dump = 0.035
                wf_rvol_std = 1.35

            is_waterfall_oversold_bottom = (macro_rsi <= 30.0 or current_rsi <= 32.0)
            is_waterfall_dump_shape = (c_upper_wick_pct < 0.28) and (
                c_recent_dump >= max(min_waterfall_dump, c_recent_pump * 1.30)
                or c_recent_dump >= (0.030 if is_crypto_altcoin else 0.018)
                or c_recent_pump <= (0.010 if is_crypto_altcoin else 0.006)
            )
            is_waterfall_dump = (
                (not is_live_rebounding)
                and (not is_panic_selling_climax)
                and (not is_waterfall_oversold_bottom)
                and is_waterfall_dump_shape
                and (current_rsi <= 58.0 or c_recent_dump >= c_recent_pump * 1.5)
                and (
                    (min_waterfall_dump <= c_recent_dump <= max_wf_dump and c_lower_wick_pct < 0.25 and c_vol_ratio >= wf_rvol_std)
                    or ((min_waterfall_dump * 1.35) <= c_recent_dump <= max_wf_dump and c_lower_wick_pct < 0.30 and c_vol_ratio >= max(1.15, wf_rvol_std - 0.10))
                    or (min_waterfall_dump <= c_recent_dump <= max_wf_dump and c_lower_wick_pct < 0.20 and c_vol_ratio >= (wf_rvol_std + 0.20))
                )
            )

            # Nến kiệt sức mua phân phối đỉnh (Buying Climax): Ép buộc có râu trên vật lý >= 30-35%!
            min_climax_rvol = 0.40 if is_tradfi else (0.85 if is_crypto_altcoin else 0.70)
            min_climax_wave = 0.018 if is_crypto_altcoin else 0.010
            is_buying_climax_candle = (
                (c_upper_wick_pct >= 0.45 and c_upper_wick_pct > c_lower_wick_pct * 1.3 and c_vol_ratio >= (1.25 if is_crypto_altcoin else 1.05) and (c_recent_pump >= min_climax_wave or current_rsi >= 58.0))
                or (c_recent_pump >= (0.035 if is_crypto_altcoin else 0.018) and c_upper_wick_pct >= 0.40 and c_vol_ratio >= (1.20 if is_crypto_altcoin else 1.00))
                or (has_real_bull_trap and c_upper_wick_pct >= 0.35 and (c_recent_pump >= min_climax_wave or current_rsi >= 58.0) and (c_vol_ratio >= (max(0.85, min_climax_rvol) if current_rsi >= 68.0 else 1.10)))
                or (in_fading_short_watchlist and c_upper_wick_pct >= 0.35 and c_vol_ratio >= 1.10)
                or (is_parabolic_pump_climax and c_upper_wick_pct >= 0.30)
            )

            # Nến kiệt sức bán rút chân gom hàng (Selling Climax): Ép buộc có râu dưới vật lý >= 30-35%!
            is_selling_climax_candle = (not is_waterfall_dump) and (
                (c_lower_wick_pct >= 0.45 and c_lower_wick_pct > c_upper_wick_pct * 1.3 and c_vol_ratio >= (1.25 if is_crypto_altcoin else 1.05) and (c_recent_dump >= min_climax_wave or current_rsi <= 42.0))
                or (c_recent_dump >= (0.035 if is_crypto_altcoin else 0.018) and c_lower_wick_pct >= 0.40 and c_vol_ratio >= (1.20 if is_crypto_altcoin else 1.00))
                or (has_real_bear_trap and c_lower_wick_pct >= 0.35 and (c_recent_dump >= min_climax_wave or current_rsi <= 42.0) and (c_vol_ratio >= (max(0.85, min_climax_rvol) if current_rsi <= 32.0 else 1.10)))
                or (is_panic_selling_climax and c_lower_wick_pct >= 0.30)
            )

            # Bão volume cá mập kéo dốc (Whale Pump Storm): Thuận theo kẻ có tiền (Chuẩn hóa 3 lớp tài sản)
            min_whale_pump = (min(0.035, max(0.025, 1.25 * eff_atr_dec)) if eff_atr_dec > 0 else 0.025) if is_crypto_altcoin else min_waterfall_dump
            wp_rvol_std = 2.00 if is_crypto_altcoin else (1.50 if is_tradfi else 1.60)
            is_whale_pump_storm = (
                not is_buying_climax_candle
                and not is_waterfall_dump
                and not is_parabolic_pump_climax
                and c_upper_wick_pct < 0.30
                and (c_recent_pump >= max(min_whale_pump, c_recent_dump * 1.30) or c_recent_dump <= (0.010 if is_crypto_altcoin else 0.006))
                and (
                    (min_whale_pump <= c_recent_pump <= max_wf_dump and c_vol_ratio >= wp_rvol_std)
                    or (c_vol_ratio >= (wp_rvol_std + 0.50) and (min_whale_pump * 0.75) <= c_recent_pump <= max_wf_dump)
                )
            )

            # [QUY TẮC MỞ KHÓA TRADFI OPENING BELL]: TradFi phiên mở cửa Mỹ dùng bão Volume + RVol >= 1.8x
            is_opening_bell = False
            try:
                from ai.market_regime import MarketRegimeDetector
                is_opening_bell = MarketRegimeDetector.is_tradfi_opening_bell()
            except Exception:
                pass

            is_tradfi_opening_pump = (
                is_tradfi
                and is_opening_bell
                and c_vol_ratio >= 1.8
                and c_upper_wick_pct < 0.30
                and c_recent_pump >= 0.010
                and c_recent_pump <= 0.060
                and current_rsi < 78.0
            )
            is_tradfi_opening_dump = (
                is_tradfi
                and is_opening_bell
                and c_vol_ratio >= 1.8
                and c_lower_wick_pct < 0.30
                and c_recent_dump >= 0.010
                and c_recent_dump <= 0.060
                and current_rsi > 28.0
            )

            # -----------------------------------------------------------------------------------------
            # THỨ TỰ ƯU TIÊN LƯỠNG PHA (SMART DUAL-PHASE MATRIX & SMART INVERSION - KB5 UNIFIED)
            # TÔN CHỈ TỐI THƯỢNG: THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN - LẬT NGƯỢC THẾ CỜ KIẾM LỢI NHUẬN!
            # -----------------------------------------------------------------------------------------
            ai_vote_agg = votes.get('ai_ensemble', (0.0, 0.0))[0] if 'ai_ensemble' in votes else 0.0
            trend_vote_agg = votes.get('trend_following', (0.0, 0.0))[0] if 'trend_following' in votes else 0.0
            breakout_vote_agg = votes.get('momentum_breakout', (0.0, 0.0))[0] if 'momentum_breakout' in votes else 0.0
            jev_vote_agg = votes.get('jev_agent', (0.0, 0.0))[0] if 'jev_agent' in votes else 0.0
            orig_jev_vote = float(trap_ctx.get('orig_jev_vote', jev_vote_agg) or 0.0)
            regime_pre_str = str(market_analysis.get('regime', 'ranging')).lower()

            # [KB5 SMART INVERSION I1 CANDIDATE CHO CRYPTO (ALTCOIN + MAJOR)]: Nến xanh đặc bơm thật khi JEV 4H đang BUY mạnh >= 70%
            is_crypto_opening_inversion = (
                (not is_tradfi)
                and orig_jev_vote >= 0.70
                and c_upper_wick_pct < 0.30
                and c_recent_pump >= min_climax_wave
                and c_recent_pump <= max_wf_dump
                and c_recent_dump < min_climax_wave
                and current_rsi >= 45.0
                and current_rsi < 75.0
                and (c_vol_ratio >= 1.35 or ('uptrend' in regime_pre_str and macro_adx >= 28.0))
            )
            smart_money_supports_sell = (
                original_signal == Signal.SELL
                or ai_vote_agg <= -0.55
                or trend_vote_agg < 0
                or breakout_vote_agg < 0
                or jev_vote_agg < 0
            )

            # 1. CHUYỂN HÓA THÁC ĐỔ CÁ MẬP XẢ (SMART WATERFALL BREAKDOWN SHORT VS BẢO VỆ ĐÁY V4):
            is_fake_bear_dump = bool(trap_ctx.get('is_fake_altcoin_bear_trap'))
            if is_altcoin_or_tradfi and (is_waterfall_dump or is_tradfi_opening_dump or (is_fake_bear_dump and smart_money_supports_sell and c_lower_wick_pct < 0.28 and c_vol_ratio >= 1.25)):
                has_real_bearish_tech = (trend_vote_agg <= -0.30) or (breakout_vote_agg <= -0.30) or (orig_jev_vote <= 0.0) or is_tradfi_opening_dump
                # [KB5 V4]: Cấm Short đuổi ở cuối sóng thác đổ khi cả AI & JEV đều đã SELL sâu ở đáy (chống Short Squeeze)
                late_wf_dump_th = 0.042 if is_crypto_altcoin else 0.028
                is_late_waterfall_exhausted = (ai_vote_agg <= -0.60 and orig_jev_vote <= -0.60 and (c_recent_dump >= late_wf_dump_th or current_rsi <= 38.0))
                # [RULE 0 - JEV MTF TREND SHIELD]: CẤM TUYỆT ĐỐI Short cản tàu khi JEV Agent 4H đang BUY mạnh (>= 70%)!
                is_jev_counter_trend = (orig_jev_vote >= 0.70)
                if is_late_waterfall_exhausted:
                    logger.warning(
                        "🛡️ [KB5 WATERFALL BOTTOM VETO (V4)] Hủy mở lệnh SHORT %s: Thác đổ đã ở cuối sóng (Dump=%.1f%%, RSI=%.1f, AI=%+.2f, JEV=%+.2f)! "
                        "Đứng ngoài né nhịp giật hồi Short Squeeze.",
                        symbol, c_recent_dump * 100, current_rsi, ai_vote_agg, orig_jev_vote
                    )
                    return None
                elif is_jev_counter_trend:
                    logger.warning(
                        "🛡️ [JEV MTF TREND SHIELD (WATERFALL SHORT VETO)] Hủy mở lệnh SHORT %s: JEV Agent 4H đang BUY mạnh (%.1f%% >= 70%%)! "
                        "Cấm Short cản tàu ngược dòng tiền cá mập vĩ mô!",
                        symbol, orig_jev_vote * 100
                    )
                    return None
                elif (current_rsi >= 42.0 or has_real_bearish_tech) and current_rsi > 32.0 and macro_rsi > 30.0 and c_recent_dump <= max_wf_dump and (smart_money_supports_sell or is_tradfi_opening_dump) and (jev_vote_agg <= 0.0) and orig_jev_vote < 0.65:
                    final_signal.signal = Signal.SELL
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_fading_short'] = False  # [BÀI HỌC 92]: Waterfall không phải Fading Short đỉnh
                    final_signal.metadata['is_waterfall_short'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'WATERFALL_BREAKDOWN_SHORT'
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.008
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    logger.info(
                        "🌊 [SMART WATERFALL INVERSION: THUẬN ĐÀ CÁ MẬP XẢ] %s: Phát hiện thác đổ không râu đỡ "
                        "(Dump=%.1f%%, Râu dưới=%.1f%% < 30%%, RVol=%.2fx, RSI=%.1f)! Xác nhận LỆNH SELL THUẬN DÒNG TIỀN CÁ MẬP!",
                        symbol, c_recent_dump * 100, c_lower_wick_pct * 100, c_vol_ratio, current_rsi
                    )
                elif c_recent_dump > max_wf_dump or current_rsi <= 30.0 or (orig_jev_vote >= 0.65 and current_rsi < 45.0):
                    logger.warning(
                        "🛡️ [WATERFALL EXTENDED VETO] Hủy mở lệnh SHORT %s: Nến đã xả sâu hoặc JEV báo gom đáy (Dump=%.1f%%, RSI=%.1f, JEV=%+.2f)! "
                        "Cấm Short đu đáy để né bẫy ép Short Squeeze!",
                        symbol, c_recent_dump * 100, current_rsi, orig_jev_vote
                    )
                    return None
                elif original_signal == Signal.BUY or is_selling_climax_candle or is_whale_pump_storm:
                    logger.warning(
                        "🛡️ [WATERFALL DUMP VETO] Hủy mở lệnh BUY %s: Đang xả dốc (Dump=%.1f%%, RSI=%.1f) và thiếu râu gom hàng "
                        "(Râu dưới=%.1f%% < 30%%, RVol=%.2fx)! Tuyệt đối KHÔNG bắt dao rơi.",
                        symbol, c_recent_dump * 100, current_rsi, c_lower_wick_pct * 100, c_vol_ratio
                    )
                    return None

            # 2. PHA 2 (CHỈ KHI CÓ RÂU XẢ ĐỈNH VẬT LÝ >= 30-35% HOẶC SIÊU SÓNG BƠM PHIÊN MỸ CẦN LẬT NGƯỢC VÀ KHÔNG CHỐNG STRONG UPTREND JEV >= 70%): BẮT ĐỈNH KIỆT SỨC MUA HOẶC INVERSION BUY
            elif is_altcoin_or_tradfi and (is_buying_climax_candle or is_parabolic_pump_climax or is_tradfi_opening_pump or is_crypto_opening_inversion or (in_fading_short_watchlist and c_upper_wick_pct >= 0.35 and c_vol_ratio >= 1.20)):
                # [KB5 XUNG ĐỘT 3 & NHÓM LẬT NGƯỢC I1]: Nếu đang Strong Uptrend (ADX >= 30) + JEV 4H BUY >= 70% hoặc nến thiếu râu trên (< 30%),
                # tuyệt đối CẤM Fading Short cản tàu mà LẬT NGƯỢC thành SMART MOMENTUM RIDE BUY!
                is_jev_uptrend_shield_active = (orig_jev_vote >= 0.70) and (('uptrend' in regime_pre_str and macro_adx >= 28.0) or (c_upper_wick_pct < 0.30))
                has_super_climax = (not is_jev_uptrend_shield_active) and (
                    (c_vol_ratio >= (3.0 if is_crypto_altcoin else 2.2) and c_recent_pump >= (0.035 if is_crypto_altcoin else 0.018) and c_upper_wick_pct >= 0.40) or is_parabolic_pump_climax
                )
                can_fade_short = (not is_jev_uptrend_shield_active) and (has_super_climax or (jev_vote_agg <= 0.0 and ai_vote_agg <= 0.60)) and (c_recent_pump >= min_climax_wave or is_parabolic_pump_climax or orig_jev_vote <= 0.0)

                can_inversion_i1 = (
                    (
                        is_jev_uptrend_shield_active
                        and orig_jev_vote >= 0.70
                        and c_recent_pump >= min_climax_wave
                        and c_recent_pump <= max_wf_dump
                        and c_recent_dump < min_climax_wave
                        and c_upper_wick_pct < 0.30
                        and current_rsi >= 45.0
                        and current_rsi < 75.0
                        and (c_vol_ratio >= 1.35 or ('uptrend' in regime_pre_str and macro_adx >= 28.0))
                    )
                    or is_tradfi_opening_pump
                )

                if can_fade_short:
                    final_signal.signal = Signal.SELL
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_fading_short'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'PARABOLIC_EXHAUSTION_SHORT' if is_parabolic_pump_climax else ('BUYING_CLIMAX' if is_buying_climax_candle else 'FADING_SHORT_PHASE2')
                    final_signal.metadata['target_tp_pct'] = 0.030
                    final_signal.metadata['be_trigger_pct'] = 0.010
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    logger.info(
                        "⚡ [EXHAUSTION FADING SHORT: BẮT ĐỈNH CÁ MẬP] %s: Nến kiệt sức mua phân phối đỉnh "
                        "(Râu trên=%.1f%%, RVol=%.2fx, Pump=%.1f%%, Parabolic=%s, BullTrap=%s, Watchlist=%s)! Xác nhận LỆNH SELL ĐÓN SẬP!",
                        symbol, c_upper_wick_pct * 100, c_vol_ratio, c_recent_pump * 100, is_parabolic_pump_climax, has_real_bull_trap, in_fading_short_watchlist
                    )
                elif can_inversion_i1:
                    # [KB5 SMART INVERSION I1]: Lật ngược lệnh Fading Short cản tàu thành SMART MOMENTUM RIDE BUY!
                    final_signal.signal = Signal.BUY
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_fading_short'] = False
                    final_signal.metadata['is_momentum_ride'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'MOMENTUM_RIDE_INVERSION_I1'
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.008
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    inversion_source = "TradFi Wall Street Opening Bell Storm" if is_tradfi_opening_pump else f"JEV 4H BUY ({orig_jev_vote:+.2f})"
                    logger.info(
                        "🔄 [KB5 SMART INVERSION (I1): LẬT NGƯỢC FADING SHORT -> MOMENTUM RIDE BUY] %s: "
                        "Phát hiện %s trong Uptrend (ADX=%.1f, Râu trên=%.1f%%, Pump=%.2f%%)! Lật ngược thành LỆNH BUY thuận cá mập!",
                        symbol, inversion_source, macro_adx, c_upper_wick_pct * 100, c_recent_pump * 100
                    )
                else:
                    if original_signal == Signal.SELL:
                        logger.warning(
                            "🛡️ [FADING SHORT VETO] Hủy mở lệnh SHORT %s: Thiếu xung lượng bơm đỉnh (Pump=%.2f%% < %.2f%%) hoặc JEV đối kháng mạnh (JEV=%+.2f)!",
                            symbol, c_recent_pump * 100, min_climax_wave * 100, orig_jev_vote
                        )
                    else:
                        logger.warning(
                            "🛡️ [BUYING CLIMAX BUY VETO] Hủy mở lệnh BUY %s: Nến có râu xả đỉnh phân phối (Râu trên=%.1f%% >= 30%%), cấm đu đỉnh râu!",
                            symbol, c_upper_wick_pct * 100
                        )
                    return None

            # 3. PHA 1: THUẬN KẺ CÓ TIỀN - BÃO VOLUME CÁ MẬP (SMART MOMENTUM RIDE BUY - SỬA XUNG ĐỘT 5):
            # Khi nến xanh đặc (râu trên < 25%), RVol >= wp_rvol_std và JEV ủng hộ (>= 0), cho phép RSI lên tới 75.0 thay vì khóa cứng ở 68.0!
            elif is_altcoin_or_tradfi and is_whale_pump_storm and c_upper_wick_pct < 0.30 and not has_real_bull_trap and not is_waterfall_dump and not is_parabolic_pump_climax:
                is_jev_warning_exhaustion = any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and any(w in str(s.metadata.get('reason', '')).lower() for w in ('exhaustion', 'overheated', 'absorption', 'rejection'))
                    for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
                )
                rsi_mom_cap = 75.0 if (c_upper_wick_pct < 0.25 and c_vol_ratio >= wp_rvol_std and orig_jev_vote >= 0.0) else 68.0
                if c_recent_pump > max_wf_dump or current_rsi >= rsi_mom_cap:
                    logger.warning(
                        "🛡️ [PUMP EXTENDED VETO] Hủy mở lệnh BUY %s: Nến đã pump quá dốc (Pump=%.1f%% > %.1f%%, RSI=%.1f >= %.1f)! "
                        "Cấm mua đu đỉnh rướn kiệt sức (đặc trị bài học BEAMX, SHAZ).",
                        symbol, c_recent_pump * 100, max_wf_dump * 100, current_rsi, rsi_mom_cap
                    )
                    return None
                elif not is_jev_warning_exhaustion and jev_vote_agg >= 0.0:
                    final_signal.signal = Signal.BUY
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_momentum_ride'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'MOMENTUM_RIDE'
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.008
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    logger.info(
                        "🚀 [SMART MOMENTUM RIDE: THUẬN KẺ CÓ TIỀN] %s: Bão volume cá mập (RVol=%.2fx, Pump=%.2f%%, Râu trên=%.1f%% < 30%%)! "
                        "Ưu tiên Pha 1: LỆNH BUY LƯỚT SÓNG ăn nhịp rướn cá mập (Cấm cản tàu)!",
                        symbol, c_vol_ratio, c_recent_pump * 100, c_upper_wick_pct * 100
                    )
                else:
                    logger.warning(
                        "🛡️ [MOMENTUM RIDE VETO] Hủy mở lệnh BUY %s: JEV cảnh báo kiệt sức lực mua hoặc JEV đối kháng (JEV=%+.2f)! Cấm đu đỉnh.",
                        symbol, jev_vote_agg
                    )
                    return None

            # 4. PHA 3: BẮT ĐÁY RÚT CHÂN GOM HÀNG (OVERSOLD BOUNCE LONG):
            # Kích hoạt khi có râu dưới hấp thụ vật lý HOẶC nến xả hoảng loạn kiệt sức bán (Panic Selling Climax)!
            elif is_altcoin_or_tradfi and (is_selling_climax_candle or is_panic_selling_climax) and not is_waterfall_dump:
                # [QUY TẮC RÀO CHẮN TRADFI PHIÊN MỸ]: Cấm bắt dao rơi cổ phiếu TradFi trong giờ mở phiên Mỹ (Rule 0.7 #3)
                is_tradfi_bell_blocked = bool(is_tradfi and is_opening_bell)
                has_super_climax_buy = (c_vol_ratio >= (3.0 if is_crypto_altcoin else 2.2) and c_recent_dump >= (0.035 if is_crypto_altcoin else 0.018) and c_lower_wick_pct >= 0.40) or (is_panic_selling_climax and c_lower_wick_pct >= 0.35)
                # Bắt buộc ai_vote_agg > -0.60 (AI Ensemble báo SELL >= 60% là CẤM BUY bắt dao rơi)
                has_valid_dump = (c_recent_dump >= min_climax_wave or is_panic_selling_climax)
                can_bounce_buy = (
                    (not is_tradfi_bell_blocked)
                    and (ai_vote_agg > -0.60)
                    and (has_super_climax_buy or (jev_vote_agg >= 0.0 and ai_vote_agg >= -0.20))
                    and has_valid_dump
                )
                if can_bounce_buy:
                    final_signal.signal = Signal.BUY
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_oversold_bounce'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'PANIC_CLIMAX_BOUNCE' if is_panic_selling_climax else ('SELLING_CLIMAX' if c_lower_wick_pct >= 0.40 else 'BEAR_TRAP_WICK')
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.008
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    logger.info(
                        "💎 [OVERSOLD BOUNCE LONG: BẮT ĐÁY RÚT CHÂN] %s: Nến kiệt sức bán rút chân gom hàng "
                        "(Râu dưới=%.1f%%, RVol=%.2fx, Dump=%.1f%%, PanicClimax=%s, BearTrap=%s)! Xác nhận LỆNH BUY ĐÓN NHỊP HỒI!",
                        symbol, c_lower_wick_pct * 100, c_vol_ratio, c_recent_dump * 100, is_panic_selling_climax, has_real_bear_trap
                    )
                else:
                    if is_tradfi_bell_blocked:
                        logger.warning(
                            "🛡️ [OPENING BELL TRADFI VETO] Hủy mở lệnh BUY bắt đáy %s: Cấm bắt dao rơi cổ phiếu TradFi trong giờ mở phiên Mỹ (Rule 0.7 #3)!",
                            symbol
                        )
                    elif original_signal == Signal.BUY or ai_vote_agg <= -0.60:
                        logger.warning(
                            "🛡️ [OVERSOLD BOUNCE VETO] Hủy mở lệnh BUY %s: AI Ensemble đối kháng mạnh (AI=%+.2f <= -0.60) hoặc thiếu xung lượng xả đáy (Dump=%.2f%%, JEV=%+.2f)!",
                            symbol, ai_vote_agg, c_recent_dump * 100, orig_jev_vote
                        )
                    else:
                        logger.warning(
                            "🛡️ [SELLING CLIMAX SHORT VETO] Hủy mở lệnh SELL %s: Nến có râu dưới gom hàng (Râu dưới=%.1f%% >= 30%%), cấm Short đu đáy râu!",
                            symbol, c_lower_wick_pct * 100
                        )
                    return None
    
                # 5. BỘ LỌC BẢO VỆ CỰC HẠN ĐỐI XỨNG 2 CHIỀU CHO CÁC LỆNH XU HƯỚNG BÌNH THƯỜNG:
    
            elif original_signal == Signal.BUY and (not is_tradfi):
                if is_crypto_altcoin and macro_adx >= 55.0:
                    climax_reason = f"Altcoin bơm xả cực hạn (ADX={macro_adx:.1f})"
                    logger.warning(
                        "🛡️ [BUYING CLIMAX VETO] Hủy lệnh BUY %s: %s! Cấm đu đỉnh mua đuổi.",
                        symbol, climax_reason
                    )
                    return None
                elif current_rsi >= 68.0 and not has_bear_trap_wick:
                    logger.warning(
                        "🛡️ [OVERBOUGHT BUY VETO] Hủy lệnh BUY %s: RSI 15m quá mua (RSI=%.1f >= 68.0) và thiếu Bear Trap! Cấm đu đỉnh mua đuổi.",
                        symbol, current_rsi,
                    )
                    return None
            elif original_signal == Signal.SELL and (not is_tradfi):
                if is_crypto_altcoin and macro_adx >= 55.0:
                    climax_reason = f"Altcoin xả cực hạn (ADX={macro_adx:.1f})"
                    logger.warning(
                        "🛡️ [SELLING CLIMAX VETO] Hủy lệnh SELL %s: %s! Cấm bán đuổi đáy.",
                        symbol, climax_reason
                    )
                    return None
                elif current_rsi <= 32.0 and not has_bull_trap_wick:
                    logger.warning(
                        "🛡️ [OVERSOLD SELL VETO] Hủy lệnh SELL %s: RSI 15m quá bán (RSI=%.1f <= 32.0) và thiếu Bull Trap! Cấm bán tháo đáy nến.",
                        symbol, current_rsi,
                    )
                    return None

            # --- MTF TREND FILTER (Cấm lướt sóng ngược bão dựa trên HƯỚNG TÁC CHIẾN THỰC TẾ) ---

            regime = str(market_analysis.get('regime', 'ranging')).lower()

            ema = str(market_analysis.get('ema_alignment', '')).lower()

            is_downtrend = 'downtrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bearish')

            is_uptrend = 'uptrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bullish')

            # [BÀI HỌC 95, 97 & KB5 UNIFIED MATRIX - PHÂN NHÓM ĐI THEO / LẬT NGƯỢC / ĐỨNG IM]:
            ai_sig_mtf = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')), None)
            ai_conf_mtf = float(getattr(ai_sig_mtf, 'confidence', 0.0) or 0.0) if ai_sig_mtf else 0.0
            ai_dir_mtf = getattr(ai_sig_mtf, 'signal', None)

            jev_sig_mtf = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)
            jev_conf_mtf = float(getattr(jev_sig_mtf, 'confidence', 0.0) or 0.0) if jev_sig_mtf else 0.0
            jev_dir_mtf = getattr(jev_sig_mtf, 'signal', None)
            is_jev_strong_buy = (jev_dir_mtf in (Signal.BUY, 'BUY', 'buy') and jev_conf_mtf >= 0.70)
            is_jev_strong_sell = (jev_dir_mtf in (Signal.SELL, 'SELL', 'sell') and jev_conf_mtf >= 0.70)

            # [BAO VE TUONG QUAN VI MO BTC & TRADFI - 4 GOC DOI XUNG 100%]:
            btc_ctx = (market_chop_context or {}).get('BTC') or {}
            btc_recent_pump = float(btc_ctx.get('recent_pump', 0.0) or 0.0)
            btc_recent_dump = float(btc_ctx.get('recent_dump', 0.0) or 0.0)
            btc_vol_ratio = float(btc_ctx.get('vol_ratio', 1.0) or 1.0)
            btc_is_dumping = (
                bool(btc_ctx.get('is_strong_downtrend'))
                or (bool(btc_ctx.get('is_downtrend')) and float(btc_ctx.get('adx', 0.0)) >= 28.0)
                or (btc_recent_dump >= 0.005 and btc_vol_ratio >= 1.30)
            )
            btc_is_pumping = (
                bool(btc_ctx.get('is_strong_uptrend'))
                or (bool(btc_ctx.get('is_uptrend')) and float(btc_ctx.get('adx', 0.0)) >= 28.0)
                or (btc_recent_pump >= 0.005 and btc_vol_ratio >= 1.30)
            )
            is_crypto_market = not is_tradfi

            # [KB5 NHÓM ĐỨNG IM V3 - ALTCOIN SIDEWAY CHOP FILTER (ADX < 25) ĐỐI XỨNG 2 CHIỀU]:
            # Miễn trừ khi có bão Volume (RVol >= 3.0x), Waterfall Short, Momentum Ride Buy, hoặc đi thuận nhịp dẫn sóng tức thời của BTC!
            if is_crypto_altcoin and 0.0 < macro_adx < 25.0 and not (
                c_vol_ratio >= 3.0
                or is_waterfall_dump
                or is_whale_pump_storm
                or bool(final_signal.metadata.get('is_waterfall_short'))
                or bool(final_signal.metadata.get('is_momentum_ride'))
                or (final_signal.signal == Signal.SELL and btc_is_dumping and c_vol_ratio >= 1.35)
                or (final_signal.signal == Signal.BUY and btc_is_pumping and c_vol_ratio >= 1.35)
            ):
                logger.warning(
                    f"🛡️ [KB5 CHOP STAND-ASIDE VETO (V3)] Hủy mở lệnh {final_signal.signal.value.upper()} {symbol}: "
                    f"Thị trường Altcoin đi ngang thiếu xung lượng (ADX={macro_adx:.1f} < 25.0, RVol={c_vol_ratio:.2f}x)! Đứng ngoài bảo toàn vốn."
                )
                return None

            # 1. GÓC 1: CẤM LONG CRYPTO (ALTCOIN + MAJOR NGOÀI BTC) KHI BTC ĐANG SẬP MẠNH (ĐỐI XỨNG 100% VỚI GÓC 2)
            clean_sym_base_btc = symbol.split('/')[0].split('USDT')[0].split(':')[0].strip().upper()
            is_non_btc_crypto = is_crypto_market and clean_sym_base_btc != 'BTC'
            if is_non_btc_crypto and final_signal.signal == Signal.BUY and btc_is_dumping:
                is_standalone_whale_pump = (is_whale_pump_storm or bool(final_signal.metadata.get('is_momentum_ride'))) and c_vol_ratio >= wp_rvol_std
                is_extreme_climax_bounce = (c_lower_wick_pct >= 0.35 or is_selling_climax_candle) and c_vol_ratio >= wp_rvol_std and has_real_bear_trap
                if not (is_standalone_whale_pump or is_extreme_climax_bounce):
                    logger.warning(
                        f"🛡️ [BTC MACRO DOWNTREND VETO] Hủy mở lệnh BUY {symbol}: "
                        f"Vua thị trường BTC đang sập mạnh ({btc_ctx.get('regime', 'downtrend')}, ADX={float(btc_ctx.get('adx') or 0.0):.1f}, Dump={btc_recent_dump*100:.2f}%)! "
                        f"Cấm mở Long Crypto cản tàu dòng tiền vĩ mô (khi thiếu râu gom đáy >= 35% hoặc không có bão bơm riêng lẻ RVol >= {wp_rvol_std:.2f}x)."
                    )
                    return None

            # 2. GÓC 2: CẤM SHORT CRYPTO (ALTCOIN + MAJOR NGOÀI BTC) KHI BTC ĐANG BƠM MẠNH (SHORT SQUEEZE SHIELD)
            if is_non_btc_crypto and final_signal.signal == Signal.SELL and btc_is_pumping:
                is_extreme_exhaustion_short = (c_upper_wick_pct >= 0.35 or is_buying_climax_candle) and c_vol_ratio >= wp_rvol_std
                is_standalone_waterfall_dump = (is_waterfall_dump or bool(final_signal.metadata.get('is_waterfall_short'))) and c_vol_ratio >= wf_rvol_std
                if not (is_extreme_exhaustion_short or is_standalone_waterfall_dump):
                    logger.warning(
                        f"🛡️ [BTC MACRO UPTREND VETO] Hủy mở lệnh SHORT {symbol}: "
                        f"Vua thị trường BTC đang bơm mạnh ({btc_ctx.get('regime', 'uptrend')}, ADX={float(btc_ctx.get('adx') or 0.0):.1f}, Pump={btc_recent_pump*100:.2f}%)! "
                        f"Cấm mở Short cản tàu dòng tiền vĩ mô tránh bão Short Squeeze (khi thiếu râu xả đỉnh >= 35% hoặc không có thác đổ riêng lẻ RVol >= {wf_rvol_std:.2f}x)."
                    )
                    return None

            # 3. GÓC 3 & 4: ĐỒNG BỘ TRADFI PRE-ENTRY TƯƠNG QUAN 4 GÓC ĐỐI XỨNG (LONG & SHORT)
            if is_tradfi:
                # [KB10 - TRADFI DEAD ZONE GATE]: Giờ đóng cửa Phố Wall (16:00 - 04:00 ET) thanh khoản cạn kiệt
                if is_stock:
                    is_dead_zone = False
                    try:
                        from ai.market_regime import MarketRegimeDetector
                        is_dead_zone = MarketRegimeDetector.is_tradfi_dead_zone()
                    except Exception:
                        pass
                    if is_dead_zone and c_vol_ratio < 0.50:
                        logger.warning(
                            f"🛡️ [TRADFI DEAD ZONE VETO] Hủy mở lệnh {final_signal.signal.value} {symbol}: "
                            f"Cổ phiếu Mỹ rơi vào giờ đóng cửa Phố Wall (16:00 - 04:00 ET) "
                            f"với RVol={c_vol_ratio:.2f}x < 0.50x! Cấm vào lệnh để tránh trôi giá và dính bẫy thanh khoản."
                        )
                        return None

                # [KB10 - TRADFI OPENING BELL GATE & 2-WAY SMART INVERSION (RULE 0.7 #3)]: 09:30 - 10:30 ET
                if is_stock and is_opening_bell:
                    if final_signal.signal == Signal.BUY and c_recent_dump >= 0.010:
                        if c_vol_ratio >= 1.80 and c_lower_wick_pct < 0.30 and orig_jev_vote <= 0.0 and current_rsi > 32.0:
                            final_signal.signal = Signal.SELL
                            final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                            final_signal.metadata['is_fading_short'] = False
                            final_signal.metadata['is_waterfall_short'] = True
                            final_signal.metadata['is_oversold_bounce'] = False
                            final_signal.metadata['type'] = 'OPENING_BELL_WATERFALL_INVERSION_SHORT'
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.008
                            logger.info(
                                f"🔄 [OPENING BELL SMART INVERSION -> SHORT] {symbol}: "
                                f"Phố Wall mở phiên xả bão Volume (Dump={c_recent_dump*100:.2f}%%, RVol={c_vol_ratio:.2f}x >= 1.8x, Râu dưới={c_lower_wick_pct*100:.1f}%% < 30%%)! "
                                f"Lật ngược BUY bắt dao rơi thành SHORT thuận cá mập Wall Street!"
                            )
                        else:
                            logger.warning(
                                f"🛡️ [OPENING BELL KNIFE-CATCHING VETO] Hủy mở lệnh BUY {symbol}: "
                                f"Trong 60m đầu phiên Mỹ đang có nhịp xả hoảng loạn (Dump={c_recent_dump*100:.2f}% >= 1.0%)! "
                                f"Cấm mua bắt dao rơi trong giờ rung lắc mở phiên Wall Street."
                            )
                            return None
                    elif final_signal.signal == Signal.SELL and c_vol_ratio >= 1.80 and c_upper_wick_pct < 0.30:
                        if c_recent_pump >= 0.010 and orig_jev_vote >= 0.0 and current_rsi < 78.0:
                            final_signal.signal = Signal.BUY
                            final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                            final_signal.metadata['is_fading_short'] = False
                            final_signal.metadata['is_momentum_ride'] = True
                            final_signal.metadata['type'] = 'OPENING_BELL_MOMENTUM_INVERSION_BUY'
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.008
                            logger.info(
                                f"🔄 [OPENING BELL SMART INVERSION -> BUY] {symbol}: "
                                f"Phố Wall mở phiên bơm bão Volume (Pump={c_recent_pump*100:.2f}%%, RVol={c_vol_ratio:.2f}x >= 1.8x, Râu trên={c_upper_wick_pct*100:.1f}%% < 30%%)! "
                                f"Lật ngược SHORT cản tàu thành MOMENTUM RIDE BUY thuận cá mập Wall Street!"
                            )
                        else:
                            logger.warning(
                                f"🛡️ [OPENING BELL SHORT VETO] Hủy mở lệnh SHORT {symbol}: "
                                f"Trong 60m đầu phiên Mỹ đang có sóng bão Volume Wall Street (RVol={c_vol_ratio:.2f}x >= 1.8x, "
                                f"Râu trên={c_upper_wick_pct*100:.1f}% < 30%)! Cấm Short cản tàu cá mập mở phiên."
                            )
                            return None

                lead_sym = MarketScanner.get_lead_asset(symbol) if hasattr(MarketScanner, 'get_lead_asset') else None
                lead_base = MarketScanner._clean_base(lead_sym) if lead_sym else None
                lead_ctx = (market_chop_context or {}).get(lead_base) or {}
                lead_is_uptrend = bool(lead_ctx.get('is_uptrend'))
                lead_is_strong_uptrend = bool(lead_ctx.get('is_strong_uptrend'))
                lead_adx = float(lead_ctx.get('adx') or 0.0)
                lead_is_downtrend = bool(lead_ctx.get('is_downtrend'))
                lead_is_strong_downtrend = bool(lead_ctx.get('is_strong_downtrend'))
                is_bear_etf_sym = hasattr(MarketScanner, 'is_bear_inverse_etf') and MarketScanner.is_bear_inverse_etf(symbol)

                # Góc 3A: Chặn mua Bear ETF (SOXS, SQQQ, SPXU, TZA) khi Benchmark ngành đang Uptrend (Rào chắn 3)
                if final_signal.signal == Signal.BUY and is_bear_etf_sym:
                    lead_bullish = lead_is_uptrend or lead_is_strong_uptrend or (lead_adx >= 25.0 and not lead_is_downtrend)
                    if not lead_ctx and is_downtrend and macro_adx >= 25.0:
                        lead_bullish = True
                    if lead_bullish:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [BEAR ETF TRAP VETO] Hủy mở BUY {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Uptrend (ADX={eff_adx:.1f})! Cấm mua Bear ETF bắt đáy."
                        )
                        return None

                # Góc 3B: Đối xứng - Chặn Short Bear ETF khi Benchmark ngành đang Downtrend mạnh
                if final_signal.signal == Signal.SELL and is_bear_etf_sym:
                    lead_bearish = lead_is_downtrend or lead_is_strong_downtrend or (lead_adx >= 25.0 and not lead_is_uptrend)
                    if not lead_ctx and is_uptrend and macro_adx >= 25.0:
                        lead_bearish = True
                    if lead_bearish and c_upper_wick_pct < 0.30:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [BEAR ETF SHORT VETO] Hủy mở SHORT {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Downtrend (ADX={eff_adx:.1f}) khiến Bear ETF tăng mạnh! Cấm Short cản tàu."
                        )
                        return None

                # Góc 4A: Chặn Short cổ phiếu / Bull ETF khi Benchmark ngành đang Uptrend mạnh
                if final_signal.signal == Signal.SELL and not is_bear_etf_sym:
                    bench_uptrend = (lead_is_uptrend or (lead_adx >= 28.0 and not lead_is_downtrend)) if lead_ctx else (is_uptrend and macro_adx >= 28.0)
                    if bench_uptrend and c_upper_wick_pct < 0.30:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [TRADFI BENCHMARK PUMP VETO] Hủy mở SHORT {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Uptrend mạnh (ADX={eff_adx:.1f})! Cấm Short cản tàu."
                        )
                        return None

                # Góc 4B: Đối xứng - Chặn BUY cổ phiếu / Bull ETF khi Benchmark ngành đang Downtrend mạnh mà chưa có râu rút chân
                if final_signal.signal == Signal.BUY and not is_bear_etf_sym:
                    bench_downtrend = (lead_is_downtrend and (lead_is_strong_downtrend or lead_adx >= 28.0)) if lead_ctx else (is_downtrend and macro_adx >= 28.0)
                    if bench_downtrend and c_lower_wick_pct < 0.30:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [TRADFI BENCHMARK DUMP VETO] Hủy mở BUY {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Downtrend mạnh (ADX={eff_adx:.1f}, Râu dưới={c_lower_wick_pct*100:.1f}% < 30%)! Cấm bắt dao rơi cổ phiếu ngược ngành."
                        )
                        return None

            # [KB10 - ĐỐI XỨNG 2 CHIỀU KHIÊN CHỐNG CẢN TÀU & RÂU HẤP THỤ CHO 3 LỚP TÀI SẢN]:
            strong_impulse_th = 0.014 if is_crypto_altcoin else 0.010
            retrace_cap_th = 0.005 if is_crypto_altcoin else 0.0035
            wick_filter_move_th = 0.010 if is_crypto_altcoin else 0.007

            # 1A. Cấm Long khi nến có râu trên dập đầu xả ngược cực đại (LIT/USDT)
            if final_signal.signal == Signal.BUY and c_upper_wick_pct >= 0.60:
                logger.warning(
                    f"🛡️ [LONG KNIFE-CATCHING VETO] Hủy mở lệnh BUY {symbol}: "
                    f"Nến có râu trên xả ngược cực đại (UpperWick={c_upper_wick_pct*100:.1f}% >= 60.0%)! "
                    f"Phe bán đang đè xả dập đầu, cấm mua bắt đáy nến rụt cổ."
                )
                return None

            # 1B. Đối xứng: Cấm Short khi nến có râu dưới rút chân gom hàng cực đại (>= 60%)
            if final_signal.signal == Signal.SELL and c_lower_wick_pct >= 0.60:
                logger.warning(
                    f"🛡️ [SHORT SQUEEZE WICK VETO] Hủy mở lệnh SHORT {symbol}: "
                    f"Nến có râu dưới rút chân gom hàng cực đại (LowerWick={c_lower_wick_pct*100:.1f}% >= 60.0%)! "
                    f"Phe mua đang đỡ giá quyết liệt, cấm Short đuổi đáy râu."
                )
                return None

            # 2A. [KB10 - SHORT STRONG PUMP SHIELD & SMART INVERSION PHA 1]: Cấm Short khi coin đang bơm dốc đứng (INJ, HYPE)
            if final_signal.signal == Signal.SELL and c_recent_pump >= strong_impulse_th and c_recent_dump < retrace_cap_th and c_upper_wick_pct < 0.30:
                if not (is_waterfall_dump or bool(final_signal.metadata.get('is_waterfall_short'))):
                    can_smart_inversion_pump = (c_vol_ratio >= wp_rvol_std and c_upper_wick_pct < 0.25 and orig_jev_vote >= 0.0 and current_rsi < 75.0)
                    if can_smart_inversion_pump:
                        final_signal.signal = Signal.BUY
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        final_signal.metadata['is_fading_short'] = False
                        final_signal.metadata['is_momentum_ride'] = True
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        final_signal.metadata['type'] = 'MOMENTUM_RIDE_INVERSION_PUMP_STORM'
                        final_signal.metadata['target_tp_pct'] = 0.025
                        final_signal.metadata['be_trigger_pct'] = 0.008
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        logger.info(
                            f"🔄 [KB10 SMART INVERSION: LẬT NGƯỢC PUMP SHORT -> MOMENTUM RIDE BUY] {symbol}: "
                            f"Phát hiện bão Volume cá mập (RVol={c_vol_ratio:.2f}x >= {wp_rvol_std:.2f}x, Pump={c_recent_pump*100:.2f}%, Râu trên={c_upper_wick_pct*100:.1f}% < 25%)! "
                            f"Lật ngược Short thành LỆNH BUY thuận cá mập!"
                        )
                    else:
                        logger.warning(
                            f"🛡️ [SHORT STRONG PUMP VETO] Hủy mở lệnh SHORT {symbol}: "
                            f"Coin đang có xung lượng bơm bão (Pump={c_recent_pump*100:.2f}% >= {strong_impulse_th*100:.2f}%, Dump={c_recent_dump*100:.2f}% < {retrace_cap_th*100:.2f}%, "
                            f"Râu trên={c_upper_wick_pct*100:.1f}% < 30%)! Cấm Short cản tàu khi chưa có râu xả đỉnh."
                        )
                        return None

            # 2B. Đối xứng: [KB10 - LONG STRONG DUMP SHIELD & SMART INVERSION WATERFALL SHORT]: Cấm Long khi coin đang xả dốc đứng
            if final_signal.signal == Signal.BUY and c_recent_dump >= strong_impulse_th and c_recent_pump < retrace_cap_th and c_lower_wick_pct < 0.30:
                if not (is_whale_pump_storm or bool(final_signal.metadata.get('is_momentum_ride'))):
                    can_smart_inversion_dump = (c_vol_ratio >= wf_rvol_std and c_lower_wick_pct < 0.25 and orig_jev_vote <= 0.0 and current_rsi > 32.0 and macro_rsi > 30.0)
                    if can_smart_inversion_dump:
                        final_signal.signal = Signal.SELL
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        final_signal.metadata['is_fading_short'] = False
                        final_signal.metadata['is_waterfall_short'] = True
                        final_signal.metadata['is_oversold_bounce'] = False
                        final_signal.metadata['is_momentum_ride'] = False
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        final_signal.metadata['type'] = 'WATERFALL_INVERSION_DUMP_STORM'
                        final_signal.metadata['target_tp_pct'] = 0.025
                        final_signal.metadata['be_trigger_pct'] = 0.008
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        logger.info(
                            f"🔄 [KB10 SMART INVERSION: LẬT NGƯỢC DUMP BUY -> WATERFALL SHORT] {symbol}: "
                            f"Phát hiện thác đổ cá mập (RVol={c_vol_ratio:.2f}x >= {wf_rvol_std:.2f}x, Dump={c_recent_dump*100:.2f}%, Râu dưới={c_lower_wick_pct*100:.1f}% < 25%)! "
                            f"Lật ngược Buy bắt dao rơi thành LỆNH SHORT thuận cá mập xả!"
                        )
                    else:
                        logger.warning(
                            f"🛡️ [LONG STRONG DUMP VETO] Hủy mở lệnh BUY {symbol}: "
                            f"Coin đang có xung lượng xả dốc (Dump={c_recent_dump*100:.2f}% >= {strong_impulse_th*100:.2f}%, Pump={c_recent_pump*100:.2f}% < {retrace_cap_th*100:.2f}%, "
                            f"Râu dưới={c_lower_wick_pct*100:.1f}% < 30%)! Cấm Buy bắt dao rơi khi chưa có râu rút chân."
                        )
                        return None

            # 3A. [KB10 - SHORT ABSORPTION WICK SHIELD]: Cấm Short khi có râu gom hàng đáy và volume thấp (BERA/USDT)
            if final_signal.signal == Signal.SELL and c_lower_wick_pct >= 0.30 and c_recent_pump >= wick_filter_move_th and c_vol_ratio < min_climax_rvol:
                logger.warning(
                    f"🛡️ [SHORT ABSORPTION WICK VETO] Hủy mở lệnh SHORT {symbol}: "
                    f"Nến xuất hiện râu dưới gom hàng (LowerWick={c_lower_wick_pct*100:.1f}% >= 30.0%, Pump={c_recent_pump*100:.2f}%) "
                    f"nhưng volume kiệt (RVol={c_vol_ratio:.2f}x < {min_climax_rvol:.2f}x)! Cấm Short vào bẫy gom hàng cá mập."
                )
                return None

            # 3B. Đối xứng: [KB10 - LONG DISTRIBUTION WICK SHIELD]: Cấm Buy khi có râu xả hàng đỉnh và volume thấp
            if final_signal.signal == Signal.BUY and c_upper_wick_pct >= 0.30 and c_recent_dump >= wick_filter_move_th and c_vol_ratio < min_climax_rvol:
                logger.warning(
                    f"🛡️ [LONG DISTRIBUTION WICK VETO] Hủy mở lệnh BUY {symbol}: "
                    f"Nến xuất hiện râu trên phân phối đỉnh (UpperWick={c_upper_wick_pct*100:.1f}% >= 30.0%, Dump={c_recent_dump*100:.2f}%) "
                    f"nhưng volume kiệt (RVol={c_vol_ratio:.2f}x < {min_climax_rvol:.2f}x)! Cấm Buy vào bẫy xả hàng cạn cầu."
                )
                return None

            # [KB5 NHÓM LẬT NGƯỢC I2/I1 & ĐỨNG IM V2 + V1 ĐỐI XỨNG 2 CHIỀU TRÊN ALTCOIN]:
            if is_crypto_altcoin and final_signal.signal == Signal.BUY:
                is_bottom_absorption_long = bool(final_signal.metadata.get('is_oversold_bounce')) or has_real_bear_trap
                is_clean_whale_ride = bool(final_signal.metadata.get('is_momentum_ride'))

                ai_truly_selling = ((ai_dir_mtf in (Signal.SELL, 'SELL', 'sell') and ai_conf_mtf >= 0.60) or (ai_vote_agg <= -0.60)) and not has_real_bear_trap and ai_vote_agg <= -0.50
                jev_truly_selling = ((jev_dir_mtf in (Signal.SELL, 'SELL', 'sell') and jev_conf_mtf >= 0.65) or (orig_jev_vote <= -0.65)) and orig_jev_vote <= -0.65

                # [KB5 I2]: Nếu vĩ mô đang Downtrend mạnh (ADX >= 28.0) + cả AI & JEV đều báo SELL và nến thiếu râu dưới (< 30%),
                # LẬT NGƯỢC lệnh bắt đáy giả thành SHORT thuận đà xả cá mập!
                if is_downtrend and macro_adx >= 28.0 and ai_truly_selling and (jev_dir_mtf in (Signal.SELL, 'SELL', 'sell') or orig_jev_vote < 0) and c_lower_wick_pct < 0.30 and current_rsi > 32.0:
                    final_signal.signal = Signal.SELL
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_fading_short'] = False
                    final_signal.metadata['is_waterfall_short'] = True
                    final_signal.metadata['is_momentum_ride'] = False
                    final_signal.metadata['is_oversold_bounce'] = False
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'SMART_DOWNTREND_INVERSION_SHORT_I2'
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.008
                    logger.info(
                        f"🔄 [KB5 SMART INVERSION (I2): LẬT NGƯỢC BẮT DAO RƠI -> SHORT THUẬN XU HƯỚNG] {symbol}: "
                        f"Downtrend mạnh (ADX={macro_adx:.1f} >= 28.0, Râu dưới={c_lower_wick_pct*100:.1f}% < 30%) kèm AI & JEV đồng loạt SELL! Lật sang SHORT!"
                    )
                elif is_downtrend and not is_clean_whale_ride and not is_bottom_absorption_long and (c_lower_wick_pct < 0.30 or ai_truly_selling or jev_truly_selling):
                    logger.warning(
                        f"🛡️ [KB5 FALLING KNIFE VETO (V2)] Hủy mở lệnh BUY {symbol}: Cấm bắt dao rơi Altcoin trong Downtrend khi thiếu râu đỡ hoặc AI/JEV báo SELL "
                        f"(Regime={regime.upper()}, LowerWick={c_lower_wick_pct*100:.1f}%, AI={ai_vote_agg:+.2f}, JEV={orig_jev_vote:+.2f})!"
                    )
                    return None
                else:
                    # [KB5 V1 - CHẶN MUA ĐUỔI ĐỈNH ALTCOIN THEO TRENDFOLLOWING EMA TRỄ PHA]:
                    is_early_breakout_long = (breakout_vote_agg > 0.0 and trend_vote_agg <= 0.0)
                    is_low_atr_aligned_uptrend = (0.0 < macro_atr_pct < 2.5 and is_uptrend and ai_vote_agg > 0.0 and orig_jev_vote > 0.0)
                    if (trend_vote_agg > 0.0 or macro_atr_pct >= 2.5) and not (is_early_breakout_long or is_clean_whale_ride or is_bottom_absorption_long or is_low_atr_aligned_uptrend):
                        logger.warning(
                            f"🛡️ [KB5 LAGGING EMA TOP-CHASE VETO (V1)] Hủy mở lệnh BUY {symbol}: "
                            f"Chặn mua đuổi đỉnh Altcoin biến động cao theo chỉ báo EMA trễ pha (TrendVote={trend_vote_agg:+.2f}, BreakoutVote={breakout_vote_agg:+.2f}, ATR={macro_atr_pct:.2f}%)!"
                        )
                        return None
            elif is_crypto_altcoin and final_signal.signal == Signal.SELL:
                is_top_exhaustion_short = bool(final_signal.metadata.get('is_fading_short')) or has_real_bull_trap
                is_clean_waterfall_short = bool(final_signal.metadata.get('is_waterfall_short')) or is_waterfall_dump

                ai_truly_buying = ((ai_dir_mtf in (Signal.BUY, 'BUY', 'buy') and ai_conf_mtf >= 0.60) or (ai_vote_agg >= 0.60)) and not has_real_bull_trap and ai_vote_agg >= 0.50
                jev_truly_buying = ((jev_dir_mtf in (Signal.BUY, 'BUY', 'buy') and jev_conf_mtf >= 0.65) or (orig_jev_vote >= 0.65)) and orig_jev_vote >= 0.65

                # [KB5 I1 DIRECT]: Đối xứng hoàn toàn với KB5 I2 - Nếu vĩ mô đang Uptrend mạnh (ADX >= 28.0) + cả AI & JEV đều báo BUY và nến thiếu râu trên (< 30%),
                # LẬT NGƯỢC lệnh Short cản tàu thành BUY thuận đà bơm cá mập!
                if is_uptrend and macro_adx >= 28.0 and ai_truly_buying and (jev_dir_mtf in (Signal.BUY, 'BUY', 'buy') or orig_jev_vote > 0) and c_upper_wick_pct < 0.30 and current_rsi < 68.0:
                    final_signal.signal = Signal.BUY
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_fading_short'] = False
                    final_signal.metadata['is_waterfall_short'] = False
                    final_signal.metadata['is_oversold_bounce'] = False
                    final_signal.metadata['is_momentum_ride'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'SMART_UPTREND_INVERSION_BUY_I1'
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.008
                    logger.info(
                        f"🔄 [KB5 SMART INVERSION (I1): LẬT NGƯỢC SHORT CẢN TÀU -> BUY THUẬN XU HƯỚNG] {symbol}: "
                        f"Uptrend mạnh (ADX={macro_adx:.1f} >= 28.0, Râu trên={c_upper_wick_pct*100:.1f}% < 30%) kèm AI & JEV đồng loạt BUY! Lật sang BUY!"
                    )
                elif is_uptrend and not is_clean_waterfall_short and not is_top_exhaustion_short and (c_upper_wick_pct < 0.30 or ai_truly_buying or jev_truly_buying):
                    logger.warning(
                        f"🛡️ [KB5 BULL TRAIN VETO (V2_SHORT)] Hủy mở lệnh SELL {symbol}: Cấm Short cản tàu Altcoin trong Uptrend khi thiếu râu xả đỉnh hoặc AI/JEV báo BUY "
                        f"(Regime={regime.upper()}, UpperWick={c_upper_wick_pct*100:.1f}%, AI={ai_vote_agg:+.2f}, JEV={orig_jev_vote:+.2f})!"
                    )
                    return None
                else:
                    # [KB5 V1_SHORT - ĐỐI XỨNG CHẶN BÁN ĐUỔI ĐÁY ALTCOIN THEO EMA TRỄ PHA]:
                    is_early_breakdown_short = (breakout_vote_agg < 0.0 and trend_vote_agg >= 0.0)
                    is_low_atr_aligned_downtrend = (0.0 < macro_atr_pct < 2.5 and is_downtrend and ai_vote_agg < 0.0 and orig_jev_vote < 0.0)
                    if (trend_vote_agg < 0.0 and macro_atr_pct >= 2.5 and current_rsi <= 38.0) and not (is_early_breakdown_short or is_clean_waterfall_short or is_top_exhaustion_short or is_low_atr_aligned_downtrend):
                        logger.warning(
                            f"🛡️ [KB5 LAGGING EMA BOTTOM-CHASE VETO (V1_SHORT)] Hủy mở lệnh SELL {symbol}: "
                            f"Chặn bán đuổi đáy Altcoin biến động cao theo chỉ báo EMA trễ pha (TrendVote={trend_vote_agg:+.2f}, RSI={current_rsi:.1f}, ATR={macro_atr_pct:.2f}%)!"
                        )
                        return None

            if final_signal.signal == Signal.BUY and is_downtrend:
                # [BÀI HỌC 95, 97, 108 & CONSECUTIVE LOSS GATE]: Tuyệt đối CẤM để râu nến giả hoặc thỏa hiệp chỉ báo trễ pha
                # bypass Veto MTF khi xu hướng vĩ mô giảm mạnh (ADX >= 28.0 hoặc strong_downtrend) và AI/JEV kiên quyết SELL >= 70%!
                is_whale_momentum_ride_valid = (
                    bool(final_signal.metadata.get('is_momentum_ride'))
                    and c_vol_ratio >= wp_rvol_std
                )
                macro_bear_dominant = (
                    (macro_adx >= 28.0 or 'strong_downtrend' in regime)
                    and ((ai_dir_mtf == Signal.SELL and ai_conf_mtf >= 0.70) or is_jev_strong_sell)
                )
                if macro_bear_dominant and not is_whale_momentum_ride_valid:
                    _ai_dir_lbl = getattr(ai_dir_mtf, 'value', str(ai_dir_mtf or 'HOLD'))
                    _jev_dir_lbl = getattr(jev_dir_mtf, 'value', str(jev_dir_mtf or 'HOLD'))
                    logger.warning(
                        f"🛡️ [VETO MTF STRONG DOWNTREND] Hủy mở lệnh BUY {symbol}: Xu hướng giảm mạnh ({regime.upper()}, ADX={macro_adx:.1f} >= 28.0) "
                        f"và AI/JEV báo SELL mạnh (AI: {_ai_dir_lbl} {ai_conf_mtf:.1%}, JEV: {_jev_dir_lbl} {jev_conf_mtf:.1%})! Cấm bắt dao rơi cản tàu cá mập."
                    )
                    return None

                has_physical_buy_wick = (
                    has_bear_trap_wick
                    or has_real_bear_trap
                    or (final_signal.metadata.get('is_oversold_bounce') and float(final_signal.metadata.get('c_lower_wick_pct', 0.0)) >= 0.30)
                    or (is_selling_climax_candle and float(final_signal.metadata.get('c_lower_wick_pct', 0.0)) >= 0.35)
                    or final_signal.metadata.get('is_momentum_ride')
                    or (abs(score) >= 0.72 and agreeing >= 3 and c_vol_ratio >= 1.15)
                )

                if has_physical_buy_wick:
                    logger.info(f"⚡ MTF Trap Override: Cho phép BUY {symbol} ngược 4H do phát hiện Quét thanh khoản gom hàng/Oversold Bounce/Momentum Ride/Số Đông Đồng Thuận (Score: {score:+.2f})!")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh BUY {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Cấm bắt dao rơi khi không có bẫy gấu rút chân gom hàng.")
                    return None

            if final_signal.signal == Signal.SELL and is_uptrend:
                # [BÀI HỌC 95, 97, 108 & CONSECUTIVE LOSS GATE]: Tuyệt đối CẤM để râu nến giả hoặc thỏa hiệp chỉ báo trễ pha
                # bypass Veto MTF khi xu hướng vĩ mô tăng mạnh (ADX >= 28.0 hoặc strong_uptrend) và AI/JEV kiên quyết BUY >= 70% (như ACT/USDT)!
                is_whale_waterfall_breakdown = (
                    (is_waterfall_dump or bool(final_signal.metadata.get('is_waterfall_short')))
                    and c_vol_ratio >= wf_rvol_std
                )
                macro_bull_dominant = (
                    (macro_adx >= 28.0 or 'strong_uptrend' in regime)
                    and ((ai_dir_mtf == Signal.BUY and ai_conf_mtf >= 0.70) or is_jev_strong_buy)
                )
                if macro_bull_dominant and not is_whale_waterfall_breakdown:
                    _ai_dir_lbl = getattr(ai_dir_mtf, 'value', str(ai_dir_mtf or 'HOLD'))
                    _jev_dir_lbl = getattr(jev_dir_mtf, 'value', str(jev_dir_mtf or 'HOLD'))
                    logger.warning(
                        f"🛡️ [VETO MTF STRONG UPTREND] Hủy mở lệnh SELL {symbol}: Xu hướng tăng mạnh ({regime.upper()}, ADX={macro_adx:.1f} >= 28.0) "
                        f"và AI/JEV báo BUY mạnh (AI: {_ai_dir_lbl} {ai_conf_mtf:.1%}, JEV: {_jev_dir_lbl} {jev_conf_mtf:.1%})! Cấm Short cản tàu cá mập đang bơm khi không có Waterfall xả bão Volume."
                    )
                    return None

                has_physical_sell_wick = (
                    has_bull_trap_wick
                    or has_real_bull_trap
                    or (final_signal.metadata.get('is_fading_short') and float(final_signal.metadata.get('c_upper_wick_pct', 0.0)) >= 0.35)
                    or (is_buying_climax_candle and float(final_signal.metadata.get('c_upper_wick_pct', 0.0)) >= 0.35)
                    or is_waterfall_dump
                    or bool(final_signal.metadata.get('is_waterfall_short'))
                    or (abs(score) >= 0.72 and agreeing >= 3 and c_vol_ratio >= 1.15)
                )

                if has_physical_sell_wick:
                    logger.info(f"⚡ MTF Trap Override: Cho phép SELL {symbol} ngược 4H do phát hiện Bẫy tăng xả hàng/Buying Climax/Waterfall/Số Đông Đồng Thuận (Score: {score:+.2f})")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh SELL {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Không có xác nhận bẫy tăng xả hàng.")
                    return None

            final_signal.stop_loss = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'stop_loss'
            )

            final_signal.take_profit = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'take_profit'
            )

            # [CHUẨN HÓA SL/TP THÍCH ỨNG ATR THEO 3 LỚP TÀI SẢN CHO CÁC LỆNH CHUYỂN HÓA ĐẶC BIỆT]:
            clean_sym_base = symbol.split('/')[0].split('USDT')[0].split(':')[0].strip().upper()
            is_lev_etf_sym = (
                (hasattr(MarketScanner, 'is_leveraged_etf') and MarketScanner.is_leveraged_etf(symbol))
                or clean_sym_base in ('SOXL', 'SOXS', 'TQQQ', 'SQQQ', 'UPRO', 'SPXU', 'TZA', 'NVDL', 'TSLL', 'MSTU', 'MSTX', 'CONL', 'UVXY')
            )
            if is_tier1:
                sl_min_b, sl_max_b = 0.010, 0.018
            elif is_tradfi:
                sl_min_b, sl_max_b = (0.018, 0.035) if is_lev_etf_sym else (0.010, 0.015)
            else:
                sl_min_b, sl_max_b = 0.015, 0.035
            eff_atr_for_sl = max(
                eff_atr_dec if eff_atr_dec > 0 else 0.012,
                c_recent_pump * 0.42,
                c_recent_dump * 0.42,
            )
            adaptive_sl_dist = min(sl_max_b, max(sl_min_b, 1.5 * eff_atr_for_sl))

            if final_signal.metadata.get('is_momentum_ride') or final_signal.metadata.get('is_oversold_bounce'):
                base_tp = float(final_signal.metadata.get('target_tp_pct', 0.025))
                target_tp = max(base_tp, round(adaptive_sl_dist * 1.8, 4))
                final_signal.take_profit = price * (1.0 + target_tp)
                final_signal.stop_loss = price * (1.0 - adaptive_sl_dist)
            elif final_signal.metadata.get('is_fading_short') or final_signal.metadata.get('is_waterfall_short'):
                base_tp = float(final_signal.metadata.get('target_tp_pct', 0.030 if final_signal.metadata.get('is_fading_short') else 0.025))
                sl_dist_short = min(sl_max_b, max(adaptive_sl_dist, 0.018 if (final_signal.metadata.get('is_fading_short') and not (is_tradfi and not is_lev_etf_sym)) else adaptive_sl_dist))
                target_tp = max(base_tp, round(sl_dist_short * 1.8, 4))
                final_signal.take_profit = price * (1.0 - target_tp)
                final_signal.stop_loss = price * (1.0 + sl_dist_short)

            # Bảo toàn đầy đủ metadata hạ nguồn (dfs cho Pre-Trade Gate & M1 Sniper, type của TrapDetector, reason/risk_factors của JEV)
            shared_dfs = next(
                (
                    s.metadata.get('dfs')
                    for s in signals
                    if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('dfs') is not None
                ),
                None,
            )

            if trap_ctx.get('is_ai_absorption_buy') and final_signal.signal == Signal.BUY:
                trap_type_val = 'SMART_ABSORPTION_REVERSAL_BUY'
            elif trap_ctx.get('is_ai_exhaustion_sell') and final_signal.signal == Signal.SELL:
                trap_type_val = 'EXHAUSTION_FADING_SELL'
            else:
                trap_sigs_matching = [
                    s for s in signals
                    if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                    and getattr(s, 'signal', None) == final_signal.signal
                    and isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type')
                ]
                trap_type_val = next(
                    (s.metadata.get('type') for s in trap_sigs_matching if s.metadata.get('timeframe') == '15m'),
                    next((s.metadata.get('type') for s in trap_sigs_matching), None)
                )

            jev_meta = getattr(jev_sig, 'metadata', {}) if (jev_sig and isinstance(getattr(jev_sig, 'metadata', None), dict)) else {}

            eff_dir_sign = 1.0 if final_signal.signal == Signal.BUY else (-1.0 if final_signal.signal == Signal.SELL else 0.0)
            contrib_strats = sorted(
                name for name, (vote, _weight) in votes.items() if vote * eff_dir_sign > 0
            )
            if not contrib_strats and final_signal.metadata.get('type'):
                contrib_strats = [str(final_signal.metadata.get('type')).lower()]

            raw_agree_ratio = (len(contrib_strats) / len(votes)) if (votes and contrib_strats) else (agreeing / len(votes) if votes else 0.0)
            eff_agreeing = len(contrib_strats) if contrib_strats else agreeing
            eff_agree_ratio = raw_agree_ratio
            is_smart_inversion_signal = (
                final_signal.signal != Signal.HOLD
                and (
                    bool(final_signal.metadata.get('is_momentum_ride'))
                    or bool(final_signal.metadata.get('is_waterfall_short'))
                    or bool(final_signal.metadata.get('is_fading_short'))
                    or bool(final_signal.metadata.get('is_oversold_bounce'))
                )
                and (
                    original_signal != final_signal.signal
                    or str(final_signal.metadata.get('type') or '') == 'MOMENTUM_RIDE_INVERSION_I1'
                )
            )
            if is_smart_inversion_signal:
                eff_agree_ratio = max(raw_agree_ratio, 0.65 if float(getattr(final_signal, 'confidence', 0.0) or 0.0) >= 0.80 else 0.55)
                eff_agreeing = max(eff_agreeing, int(round(eff_agree_ratio * max(1, len(votes)))))

            final_signal.metadata.update({
                'contributing_strategies': contrib_strats,
                'weighted_score': score,
                'agreeing_strategies': eff_agreeing,
                'strategy_count': len(votes),
                'agreement_ratio': eff_agree_ratio,
                'market_analysis': market_analysis,
                'dfs': shared_dfs,
                'type': final_signal.metadata.get('type') or trap_type_val,
                'is_ai_absorption_buy': bool(trap_ctx.get('is_ai_absorption_buy', False)) and final_signal.signal == Signal.BUY,
                'is_ai_exhaustion_sell': bool(trap_ctx.get('is_ai_exhaustion_sell', False)) and final_signal.signal == Signal.SELL,
                'is_fading_short': (bool(final_signal.metadata.get('is_fading_short', False)) or (trap_type_val in ('EXHAUSTION_FADING_SELL', 'BULL_TRAP_WICK', 'BUYING_CLIMAX'))) and final_signal.signal == Signal.SELL,
                'c_upper_wick_pct': float(final_signal.metadata.get('c_upper_wick_pct', c_upper_wick_pct) or c_upper_wick_pct),
                'c_lower_wick_pct': float(final_signal.metadata.get('c_lower_wick_pct', c_lower_wick_pct) or c_lower_wick_pct),
                'c_recent_pump_pct': float(c_recent_pump),
                'c_recent_dump_pct': float(c_recent_dump),
                'c_vol_ratio': float(final_signal.metadata.get('c_vol_ratio', c_vol_ratio) or c_vol_ratio),
                'jev_decision': jev_sig.signal.value.upper() if (jev_sig and hasattr(jev_sig, 'signal') and hasattr(jev_sig.signal, 'value')) else 'NONE',
                'reason': jev_meta.get('reason', ''),
                'risk_factors': (
                    ', '.join(jev_meta['risk_factors'])
                    if isinstance(jev_meta.get('risk_factors'), list)
                    else (jev_meta.get('risk_factors') or 'none')
                ),
            })

        if final_signal.signal == Signal.HOLD and abs(score) < entry_threshold:
            logger.warning(
                '🛡️ [SIGNAL SCORE VETO] %s: |weighted score| %.4f < %.2f; chưa đủ chuẩn cấp lệnh mới.',
                symbol, abs(score), entry_threshold,
            )

        # [ORDER FLOW & TAPE READING GATE]: Thẩm định Ma trận Dòng Lệnh Khớp Thực Tế (CVD + Price Action)
        # Bắt buộc tuân thủ Rào chắn Vĩ mô BTC / MTF 4H / KB10 và tính SL/TP chuẩn 3 lớp tài sản khi lật chiều!
        if final_signal.signal != Signal.HOLD and getattr(self, 'enable_live_order_flow', True) and hasattr(self, 'order_flow_analyzer') and self.order_flow_analyzer and '/' in symbol:
            sig_side_val = getattr(final_signal.signal, 'value', str(final_signal.signal)).upper()
            is_tradfi_sym = MarketScanner.is_tradfi_stock(symbol) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol))
            if not is_tradfi_sym:
                try:
                    pa_meta = {
                        'adx': macro_adx,
                        'rvol': c_vol_ratio,
                        'upper_wick_pct': c_upper_wick_pct,
                        'lower_wick_pct': c_lower_wick_pct,
                        'is_uptrend': is_uptrend,
                        'is_downtrend': is_downtrend,
                    }
                    of_res = self.order_flow_analyzer.evaluate_order_flow_matrix(
                        symbol=symbol,
                        side=sig_side_val,
                        price_action_meta=pa_meta,
                        limit=100
                    )
                    if of_res and not of_res.get('allowed', True):
                        of_action = str(of_res.get('action') or '')
                        can_of_invert_buy = (
                            of_action == 'INVERT_TO_BUY'
                            and (orig_jev_vote >= 0.70 or (ai_vote_agg >= 0.65 and orig_jev_vote >= 0.0))
                            and c_upper_wick_pct < 0.30
                            and current_rsi < 72.0
                            and not btc_is_dumping
                            and not (is_downtrend and macro_adx >= 28.0 and is_jev_strong_sell)
                            and not (c_recent_dump >= strong_impulse_th and c_recent_pump < retrace_cap_th and c_lower_wick_pct < 0.30)
                            and not (c_upper_wick_pct >= 0.30 and c_recent_dump >= wick_filter_move_th and c_vol_ratio < min_climax_rvol)
                        )
                        can_of_invert_short = (
                            of_action == 'INVERT_TO_SHORT'
                            and (orig_jev_vote <= -0.70 or (ai_vote_agg <= -0.65 and orig_jev_vote <= 0.0))
                            and c_lower_wick_pct < 0.30
                            and current_rsi > 32.0
                            and not btc_is_pumping
                            and not (is_uptrend and macro_adx >= 28.0 and is_jev_strong_buy)
                            and not (c_recent_pump >= strong_impulse_th and c_recent_dump < retrace_cap_th and c_upper_wick_pct < 0.30)
                            and not (c_lower_wick_pct >= 0.30 and c_recent_pump >= wick_filter_move_th and c_vol_ratio < min_climax_rvol)
                        )
                        if can_of_invert_buy:
                            logger.warning(
                                f"🚀 [ORDER FLOW SMART INVERSION -> BUY] Lật ngược {sig_side_val} -> BUY cho {symbol} thuận dòng tiền cá mập: "
                                f"{of_res.get('reason')} (JEV={orig_jev_vote:+.2f}, AI={ai_vote_agg:+.2f})"
                            )
                            final_signal.signal = Signal.BUY
                            final_signal.confidence = max(float(final_signal.confidence or 0.80), 0.85)
                            final_signal.metadata['type'] = 'MOMENTUM_RIDE'
                            final_signal.metadata['is_momentum_ride'] = True
                            final_signal.metadata['is_fading_short'] = False
                            final_signal.metadata['is_waterfall_short'] = False
                            final_signal.metadata['is_oversold_bounce'] = False
                            final_signal.metadata['is_ai_exhaustion_sell'] = False
                            final_signal.metadata['is_trap_candidate'] = True
                            final_signal.metadata['is_trap_entry'] = True
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.008
                            final_signal.metadata['order_flow_scenario'] = of_res.get('scenario')
                            new_contrib = sorted(name for name, (vote, _w) in votes.items() if vote > 0) or ['order_flow_momentum_ride']
                            final_signal.metadata['contributing_strategies'] = new_contrib
                            final_signal.metadata['agreeing_strategies'] = len(new_contrib)
                            if final_signal.price and final_signal.price > 0:
                                of_tp_dist = max(0.025, round(adaptive_sl_dist * 1.8, 4))
                                final_signal.stop_loss = final_signal.price * (1.0 - adaptive_sl_dist)
                                final_signal.take_profit = final_signal.price * (1.0 + of_tp_dist)
                        elif can_of_invert_short:
                            logger.warning(
                                f"🌊 [ORDER FLOW SMART INVERSION -> SHORT] Lật ngược {sig_side_val} -> SELL cho {symbol} thuận dòng tiền cá mập xả lũ: "
                                f"{of_res.get('reason')} (JEV={orig_jev_vote:+.2f}, AI={ai_vote_agg:+.2f})"
                            )
                            final_signal.signal = Signal.SELL
                            final_signal.confidence = max(float(final_signal.confidence or 0.80), 0.85)
                            final_signal.metadata['type'] = 'WATERFALL_BREAKDOWN_SHORT'
                            final_signal.metadata['is_waterfall_short'] = True
                            final_signal.metadata['is_fading_short'] = False
                            final_signal.metadata['is_momentum_ride'] = False
                            final_signal.metadata['is_oversold_bounce'] = False
                            final_signal.metadata['is_ai_absorption_buy'] = False
                            final_signal.metadata['is_trap_candidate'] = True
                            final_signal.metadata['is_trap_entry'] = True
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.008
                            final_signal.metadata['order_flow_scenario'] = of_res.get('scenario')
                            new_contrib = sorted(name for name, (vote, _w) in votes.items() if vote < 0) or ['order_flow_waterfall_short']
                            final_signal.metadata['contributing_strategies'] = new_contrib
                            final_signal.metadata['agreeing_strategies'] = len(new_contrib)
                            if final_signal.price and final_signal.price > 0:
                                of_tp_dist = max(0.025, round(adaptive_sl_dist * 1.8, 4))
                                final_signal.stop_loss = final_signal.price * (1.0 + adaptive_sl_dist)
                                final_signal.take_profit = final_signal.price * (1.0 - of_tp_dist)
                        else:
                            logger.warning(
                                f"🛡️ [ORDER FLOW VETO] Hủy mở lệnh {sig_side_val} {symbol}: "
                                f"{of_res.get('reason')} (Scenario: {of_res.get('scenario')})"
                            )
                            return None
                    elif of_res and of_res.get('scenario') in ('BEARISH_ABSORPTION_FADING', 'BULLISH_ABSORPTION_BOUNCE', 'WATERFALL_DUMP_CONFIRMED', 'MOMENTUM_RIDE_CONFIRMED'):
                        final_signal.metadata['order_flow_scenario'] = of_res.get('scenario')
                        logger.info(f"🌊 [ORDER FLOW CONFIRMED] {symbol} {sig_side_val}: {of_res.get('reason')}")
                except Exception as of_err:
                    logger.debug(f"Bỏ qua Order Flow Matrix cho {symbol}: {of_err}")

        return final_signal if final_signal.signal != Signal.HOLD else None



