import logging
import re
import math
import statistics
import sys
import time
from typing import Dict, List, Optional, Tuple

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

from strategies.base_strategy import TradeSignal, Signal
from core.scanner import MarketScanner

logger = logging.getLogger(__name__)


class SignalAggregator:
    """Combine strategy votes without letting HOLD signals dilute them."""

    _recent_chop_vetoes: Dict[str, float] = {}
    _crypto_market_chop_until: float = 0.0
    INVERSE_PAIRS: Dict[str, str] = {
        'SOXL/USDT': 'SOXS/USDT',
        'SOXS/USDT': 'SOXL/USDT',
    }

    def __init__(self, config: dict = None):
        config = config or {}
        ai_config = config.get('ai', {})
        self.confidence_threshold = float(ai_config.get('confidence_threshold', 0.6))
        self.min_agreeing_strategies = max(
            1, int(ai_config.get('min_agreeing_strategies', 2))
        )

        self.strategy_weights = {}
        for name, strat_config in config.get('strategies', {}).items():
            if isinstance(strat_config, dict):
                self.strategy_weights[name] = float(strat_config.get('weight', 0.25))

        if not self.strategy_weights:
            self.strategy_weights = {
                'trend_following': 0.3,
                'mean_reversion': 0.25,
                'ai_ensemble': 0.2,
                'jev_agent': 0.3,
                'smart_dca': 0.15,
                'hft_scalping': 0.25,
                'trap_detector': 0.25,
                'momentum_breakout': 0.25,
            }
        self._recent_chop_vetoes = {}
        self._crypto_market_chop_until = 0.0

    def _strategy_votes(
        self,
        signals: List[TradeSignal],
        apply_entry_vetoes: bool = True,
        log_vetoes: Optional[bool] = None,
    ) -> Dict[str, Tuple[float, float]]:
        """Return one weighted vote per strategy, combining its actionable timeframes."""
        if not signals:
            return {}
        if log_vetoes is None:
            log_vetoes = bool(apply_entry_vetoes)
        by_strategy: Dict[str, List[float]] = {}

        for sig in signals:
            if sig.signal == Signal.BUY:
                direction = 1.0
            elif sig.signal == Signal.SELL:
                direction = -1.0
            else:
                # Tuyệt đối không đưa Signal.HOLD (direction = 0.0) vào mẫu số tổng hợp để tránh làm loãng
                # 31% - 40% điểm raw_score khi giám sát vị thế mở (Cổng JEV HOLD Veto >= 0.70 đã xử lý riêng ở bước lọc vào lệnh).
                continue

            try:
                confidence = float(sig.confidence)
            except (TypeError, ValueError):
                continue
            if math.isnan(confidence) or not (0.0 <= confidence <= 1.0):
                continue
            name = re.sub(r'(?<!^)(?=[A-Z])', '_', sig.strategy).lower()
            by_strategy.setdefault(name, []).append(direction * confidence)

        votes: Dict[str, Tuple[float, float]] = {}
        
        # --- MUTUALLY EXCLUSIVE & TRAP OVERRIDE RULES ---
        # 1. KIỂM TRA BẪY GIÁ (BULL TRAP / BEAR TRAP) TỪ TRAP DETECTOR:
        # Nhận diện đầy đủ cả Wick Sweep và VSA Bounce/Dip từ TrapDetector
        has_real_bull_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE')
            for s in signals
        )
        has_real_bear_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'BEAR_TRAP_DIP')
            for s in signals
        )
        has_15m_bull_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE')
            and s.metadata.get('timeframe') == '15m'
            for s in signals
        )
        has_15m_bear_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'BEAR_TRAP_DIP')
            and s.metadata.get('timeframe') == '15m'
            for s in signals
        )
        trend_vote = sum(by_strategy.get('trend_following', [0.0])) / len(by_strategy.get('trend_following', [1.0])) if 'trend_following' in by_strategy else 0.0
        breakout_vote = sum(by_strategy.get('momentum_breakout', [0.0])) / len(by_strategy.get('momentum_breakout', [1.0])) if 'momentum_breakout' in by_strategy else 0.0
        jev_vote = sum(by_strategy.get('jev_agent', [0.0])) / len(by_strategy.get('jev_agent', [1.0])) if 'jev_agent' in by_strategy else 0.0

        # Nếu khung 15m đang bứt phá mạnh (TrendFollowing/Breakout BUY) VÀ JEV Agent MTF xác nhận BUY (>= 0.70)
        # mà không có bẫy xả trên nến 15m (chỉ có tín hiệu TrapDetector 1H cũ từ giờ trước như AKT/USDT),
        # không cho phép tín hiệu 1H trễ pha xóa bỏ sóng tăng 15M hiện tại!
        if has_real_bull_trap and not has_15m_bull_trap and (trend_vote >= 0.30 or breakout_vote >= 0.30) and jev_vote >= 0.70:
            has_real_bull_trap = False
            by_strategy.pop('trap_detector', None)

        if has_real_bear_trap and not has_15m_bear_trap and (trend_vote <= -0.30 or breakout_vote <= -0.30) and jev_vote <= -0.70:
            has_real_bear_trap = False
            by_strategy.pop('trap_detector', None)

        if has_real_bull_trap:
            neutralized = []
            if trend_vote >= 0.30 and 'trend_following' in by_strategy:
                by_strategy.pop('trend_following', None)
                neutralized.append('TrendFollowing')
            if breakout_vote >= 0.30 and 'momentum_breakout' in by_strategy:
                by_strategy.pop('momentum_breakout', None)
                neutralized.append('Breakout')
            if neutralized and log_vetoes:
                logger.warning(
                    "🛡️ CẢNH BÁO BẪY GIÁ (BULL TRAP): TrapDetector phát hiện rút râu xả hàng! Vô hiệu hóa đà BUY của %s để tránh đu đỉnh.",
                    ', '.join(neutralized),
                )

        symbol_name = str(getattr(signals[0], 'symbol', '') or '')
        clean_base = symbol_name.split(':')[0].strip().upper()
        clean_base = clean_base.split('/')[0] if '/' in clean_base else clean_base
        is_tier1 = any(clean_base == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
        is_stock = MarketScanner.is_tradfi_stock(symbol_name)
        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol_name)
        is_tradfi = is_stock or is_commodity
        is_crypto_altcoin = (not is_tier1) and (not is_tradfi)

        # 2. CHỐNG BẮT DAO RƠI KHI SẬP MẠNH (Downtrend crash):
        # Chỉ coi JEV là bearish khi JEV thực sự ra lệnh SELL (jev_vote <= -0.20),
        # hoặc khi không có đà tăng kỹ thuật (trend_vote <= 0 và breakout_vote <= 0) mà JEV cảnh báo downtrend/dump.
        # Tuyệt đối không bắt chữ cảm tính khi TrendFollowing đang báo BUY dương (như AIO/USDT Trend +0.80)!
        jev_is_bearish = (jev_vote <= -0.20) or (
            trend_vote <= 0.0
            and breakout_vote <= 0.0
            and any(
                isinstance(getattr(s, 'metadata', None), dict)
                and any(w in str(s.metadata.get('reason', '')).lower() for w in ('bearish', 'downtrend', 'drop', 'dump', 'xả'))
                for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
            )
        )
        # Kiểm tra AI Bias hoặc Market Regime vĩ mô từ metadata
        macro_is_bearish = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and (
                str(s.metadata.get('ai_bias', '')).upper() == 'BEARISH'
                or str(s.metadata.get('market_regime', '')).lower() in ('downtrend', 'strong_downtrend', 'bearish')
            )
            for s in signals
        )
        has_strong_sell_momentum = (
            breakout_vote <= -0.20 or 
            trend_vote <= -0.20 or 
            jev_vote <= -0.20 or 
            jev_is_bearish or 
            macro_is_bearish
        )
        has_strong_trap_reversal = any(
            getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
            and getattr(s, 'signal', None) == Signal.BUY
            and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
            for s in signals
        )

        # Chỉ vô hiệu hóa đà SELL của Trend/Breakout khi Bear Trap hợp lệ (không phải hồi ảo Altcoin trong downtrend)
        is_fake_altcoin_bear_trap = (
            has_real_bear_trap and is_crypto_altcoin and has_strong_sell_momentum and not has_strong_trap_reversal
        )
        if has_real_bear_trap and not is_fake_altcoin_bear_trap:
            neutralized_dn = []
            if trend_vote <= -0.30 and 'trend_following' in by_strategy:
                by_strategy.pop('trend_following', None)
                neutralized_dn.append('TrendFollowing')
            if breakout_vote <= -0.30 and 'momentum_breakout' in by_strategy:
                by_strategy.pop('momentum_breakout', None)
                neutralized_dn.append('Breakout')
            if neutralized_dn and log_vetoes:
                logger.warning(
                    "🛡️ CẢNH BÁO BẪY GIÁ (BEAR TRAP): TrapDetector phát hiện quét thanh khoản rút chân gom hàng! Vô hiệu hóa đà SELL của %s để tránh bán đáy.",
                    ', '.join(neutralized_dn),
                )

        if apply_entry_vetoes:
            # A. CẤM TUYỆT ĐỐI BẮT ĐÁY LONG TRÊN ALTCOIN KHI THỊ TRƯỜNG DOWNTREND (MIỄN TRỪ NẾU CÓ BẪY RÚT ĐÁY MẠNH >= 70%):
            if has_strong_sell_momentum and is_crypto_altcoin:
                if not has_strong_trap_reversal:
                    removed_buy = False
                    for strat_k in list(by_strategy.keys()):
                        if strat_k == 'trap_detector':
                            continue
                        orig_len = len(by_strategy[strat_k])
                        filtered_v = [v for v in by_strategy[strat_k] if v <= 0]
                        if len(filtered_v) < orig_len:
                            removed_buy = True
                        if filtered_v:
                            by_strategy[strat_k] = filtered_v
                        else:
                            by_strategy.pop(strat_k, None)
                    if removed_buy and log_vetoes:
                        reason_str = "Toàn sàn/Vĩ mô Downtrend" if macro_is_bearish else f"Đà giảm cục bộ của coin (Trend: {trend_vote:+.2f}, Breakout: {breakout_vote:+.2f})"
                        logger.info("🚫 VETO BUY ALTCOIN (%s): %s, cấm bắt dao rơi Altcoin!", symbol_name, reason_str)

            # C. LỌC BẪY RÂU ĐÁY ALTCOIN YẾU (< 70%) TRONG DOWNTREND:
            if is_fake_altcoin_bear_trap:
                by_strategy.pop('trap_detector', None)
                if log_vetoes:
                    logger.warning("🛡️ CHẶN BẪY RÂU ALTCOIN (%s): Râu rút đáy Altcoin yếu (<70%%) trong downtrend chỉ là hồi ảo, bỏ qua!", symbol_name)

        # B. TĂNG LỰC CHO SHORT BẮT ĐỈNH (BULL TRAP SHORT):
        # Khi xuất hiện Bull Trap thực sự, tăng mạnh trọng số SHORT
        if has_real_bull_trap:
            by_strategy['trap_detector'] = [-0.85]
            if log_vetoes:
                logger.info("🎯 KÍCH HOẠT BULL TRAP SHORT (%s): TrapDetector xác nhận râu xả đỉnh, ưu tiên SHORT!", symbol_name)

        # D. GHI NHẬN CẢNH BÁO CONSOLIDATION CHO CẶP ETF ĐÒN BẨY & CHẶN BẪY RÂU ĐƠN LẺ TRONG VÙNG NÉN 15M (CHOP TRACKING)
        clean_sym = symbol_name.split(':')[0].strip().upper()
        jev_warns_consolidation = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and any(w in (str(s.metadata.get('risk_factors', '')) + " " + str(s.metadata.get('reason', ''))).lower() 
                    for w in (
                        'consolidation with no clear breakout',
                        'consolidating without a clear direction',
                        'consolidating between ema',
                        'choppy consolidation',
                        'volume is not significantly expanded',
                        'volume is not significantly expanding',
                        'conflicting 4h and 15m trends with no clear direction',
                        'no clear break above ema',
                        'no clear break',
                        'no clear breakout',
                        'lacks clear directional momentum',
                        'risk of volume exhaustion',
                        'consolidation with no clear break',
                        'choppy consolidation with no clear',
                        'testing ema20 with low volume and choppy consolidation',
                    ))
            for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
        )
        # BẢO VỆ ĐỒNG THUẬN KỸ THUẬT (TECHNICAL CONSENSUS SCOPE BẢO ĐẢM LUÔN KHỞI TẠO):
        # Tính toán trước để luôn sẵn sàng cho cả Rule D (JEV Veto) và Rule E2 (Chop Shield)
        tech_keys = [k for k in by_strategy if k not in ('jev_agent', 'ai_ensemble')]
        has_tech_signal = len(tech_keys) > 0
        raw_trap_conf = max(
            (
                float(getattr(s, 'confidence', 0.0) or 0.0)
                for s in signals
                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)
            ),
            default=0.0,
        )
        # Đếm các chiến thuật kỹ thuật độc lập (loại trừ JEV và AI Ensemble) có độ tự tin cao (>= 0.65)
        # và phải đồng pha cùng chiều với hướng áp đảo kỹ thuật (không đếm chiến thuật đối kháng)
        tech_votes_signed = [
            (k, sum(by_strategy[k]) / len(by_strategy[k]))
            for k in tech_keys if by_strategy.get(k)
        ]
        dominant_tech_dir = 1.0 if sum(v for _, v in tech_votes_signed) >= 0 else -1.0
        agreeing_tech_count = sum(
            1 for _, v in tech_votes_signed
            if v * dominant_tech_dir > 0 and abs(v) >= 0.65
        )
        has_strong_consensus = (agreeing_tech_count >= 2) or (raw_trap_conf >= 0.65)

        if apply_entry_vetoes and jev_warns_consolidation:
            now_ts = time.time()
            SignalAggregator._recent_chop_vetoes[clean_sym] = now_ts
            self._recent_chop_vetoes[clean_sym] = now_ts
            if clean_base in ('BTC', 'ETH'):
                # Kịch Bản 2: Rút ngắn thời gian phong tỏa xuống 2 phút (120s) và chỉ khóa khi BTC/ETH thực sự nén cạn
                # Chuẩn hóa biên độ thực tế của BTC/ETH trên khung 15m (ADX >= 22.0 hoặc ATR >= 0.45% là đang có sóng)
                # và áp dụng giãn cách tối thiểu 240s giữa 2 lần bật khiên để chống khóa lặp vô hạn mỗi 90s!
                btc_is_active_trend = False
                btc_adx_val = 0.0
                btc_atr_val = 0.0
                for s in signals:
                    ma = (s.metadata or {}).get('market_analysis', {}) if isinstance(getattr(s, 'metadata', None), dict) else {}
                    if ma:
                        btc_adx_val = max(btc_adx_val, float(ma.get('adx') or 0.0))
                        btc_atr_val = max(btc_atr_val, float(ma.get('atr_pct') or 0.0))
                    if btc_adx_val >= 22.0 or btc_atr_val >= 0.45:
                        btc_is_active_trend = True
                        break
                last_chop_act = max(
                    getattr(self, '_last_chop_shield_activated_at', 0.0),
                    getattr(SignalAggregator, '_last_chop_shield_activated_at', 0.0),
                )
                if (not btc_is_active_trend) and (now_ts - last_chop_act >= 240.0):
                    SignalAggregator._crypto_market_chop_until = now_ts + 120.0
                    self._crypto_market_chop_until = now_ts + 120.0
                    SignalAggregator._last_chop_shield_activated_at = now_ts
                    self._last_chop_shield_activated_at = now_ts
                    logger.warning(
                        "🛡️ [CRYPTO CHOP SHIELD KÍCH HOẠT] %s nén sideway / volume cạn kiệt (ADX=%.1f, ATR=%.2f%%). Tạm khóa mở lệnh Breakout đơn lẻ trên Crypto Altcoin trong 2 phút!",
                        clean_base, btc_adx_val, btc_atr_val
                    )
            is_lone_trap_in_chop = (
                tech_keys == ['trap_detector']
                and raw_trap_conf < 0.65
            )
            is_consolidation_chop_veto = (
                (is_crypto_altcoin or is_tradfi)
                and jev_warns_consolidation
                and not has_strong_consensus
            )
            if apply_entry_vetoes and (
                clean_sym in SignalAggregator.INVERSE_PAIRS
                or not has_tech_signal
                or is_lone_trap_in_chop
                or is_consolidation_chop_veto
            ):
                by_strategy.clear()
                logger.warning("🛡️ JEV VETO CONSOLIDATION (%s): JEV Agent cảnh báo thị trường nén đi ngang / không có breakout / volume cạn kiệt, VETO toàn bộ tín hiệu!", symbol_name)
                try:
                    from core.gate_telemetry import record_gate_event
                    record_gate_event('JEV_CHOP_VETO', symbol_name, reason='JEV cảnh báo nén sideway/volume cạn')
                except Exception:
                    pass

        # E. CHẶN CHÉO CẶP ETF NGHỊCH ĐẢO (INVERSE ETF CROSS-VETO):
        # Khi SOXL bị nén đi ngang/chop, SOXS (và ngược lại) cũng bị bào mòn thanh khoản trong vùng sideway
        counter_pair = SignalAggregator.INVERSE_PAIRS.get(clean_sym)
        if apply_entry_vetoes and counter_pair and counter_pair in SignalAggregator._recent_chop_vetoes:
            last_counter_chop = SignalAggregator._recent_chop_vetoes[counter_pair]
            if (time.time() - last_counter_chop) < 3600:
                by_strategy.clear()
                logger.warning(
                    "🛡️ INVERSE ETF CROSS-VETO (%s): Mã đối ứng %s đang bị cảnh báo Sideway/Chop nén biên hẹp (cách đây %.1f phút), cấm mở vị thế bào mòn ETF!",
                    clean_sym, counter_pair, (time.time() - last_counter_chop) / 60.0
                )

        # E2. ÁP DỤNG CRYPTO MARKET-WIDE CHOP SHIELD (CHỈ CHO CRYPTO ALTCOIN, MIỄN TRỪ 100% TRADFI VÀ COIN MAJOR):
        chop_deadline = max(
            getattr(self, '_crypto_market_chop_until', 0.0),
            getattr(SignalAggregator, '_crypto_market_chop_until', 0.0),
        )
        if apply_entry_vetoes and is_crypto_altcoin and (time.time() < chop_deadline):
            has_strong_trap = (
                any(
                    getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                    for s in signals
                )
                or (bool(by_strategy.get('trap_detector')) and abs(by_strategy['trap_detector'][0]) >= 0.70)
            )
            # Kịch Bản 2: Cho phép vượt rào Chop Shield nếu Altcoin có đồng thuận kỹ thuật độc lập mạnh mẽ (>= 2 chiến lược kỹ thuật >= 75% cùng chiều lệnh hoặc Trap >= 70%)
            has_strong_alt_momentum = agreeing_tech_count >= 2 and max(
                (
                    float(getattr(s, 'confidence', 0.0) or 0.0)
                    for s in signals
                    if getattr(s, 'strategy', '').lower() not in ('jev_agent', 'jevagent', 'ai_ensemble', 'aiensemble')
                    and (
                        (dominant_tech_dir > 0 and (getattr(s, 'signal', None) == Signal.BUY or getattr(s, 'direction', 0.0) > 0))
                        or (dominant_tech_dir < 0 and (getattr(s, 'signal', None) == Signal.SELL or getattr(s, 'direction', 0.0) < 0))
                    )
                ),
                default=0.0,
            ) >= 0.75
            if not (has_strong_trap or has_strong_alt_momentum):
                by_strategy.clear()
                if log_vetoes:
                    rem_m = max(0.0, (chop_deadline - time.time()) / 60.0)
                    logger.warning(
                        "🛡️ CRYPTO CHOP SHIELD VETO (%s): BTC/ETH đang trong vùng nén sideway cạn volume (còn %.1fm), cấm mở vị thế Altcoin trôi dạt!",
                        symbol_name, rem_m
                    )

        # F0. ĐỒNG BỘ BẢO VỆ LỆNH SELL KHI BULL TRAP + ĐA SỐ CHIẾN THUẬT (KỸ THUẬT/AI) XÁC NHẬN ĐỈNH XẢ HÀNG:
        # Khi xuất hiện Bull Trap thực sự (has_real_bull_trap) đồng thời có >= 2 chiến thuật khác (như TrendFollowing 15m SELL + AI Ensemble SELL,
        # hoặc >= 2 chiến thuật kỹ thuật độc lập SELL >= 60%) đồng thuận SELL tuyệt đối, nhưng JEV Agent nhìn xu hướng 4H/1H cũ vẫn báo BUY trễ pha:
        # Bỏ phiếu BUY trễ pha của JEV khỏi mẫu số để điểm score không bị kéo tụt dưới 0.50 trước khi tới cổng "⚡ BẢO VỆ LỆNH SELL".
        if has_real_bull_trap and 'jev_agent' in by_strategy and jev_vote > 0:
            non_jev_strats = {k: sum(v) / len(v) for k, v in by_strategy.items() if k != 'jev_agent' and v}
            non_ai_sell_count = sum(1 for k, v in non_jev_strats.items() if k != 'ai_ensemble' and v <= -0.60)
            if len(non_jev_strats) >= 2 and all(v <= -0.60 for v in non_jev_strats.values()) and non_ai_sell_count >= 2:
                by_strategy.pop('jev_agent', None)

        # F. CHỐNG TRỄ PHA KHUNG 4H CỦA AI ENSEMBLE KHI ĐA SỐ CHIẾN THUẬT (KỸ THUẬT 15M + JEV AGENT >= 80%) ĐỒNG THUẬN TUYỆT ĐỐI:
        # Ví dụ METIS/USDT (Trend 15m BUY 80% + Trap 15m BUY 67% + JEV BUY 85%, ADX=32.0) hay ELSA/USDT (Trend 15m BUY 75% + JEV BUY 82%, ADX=31.0)
        # bị duy nhất phiếu SELL trễ pha trên khung 4H của AI Ensemble kéo điểm xuống.
        # BẮT BUỘC: Chỉ được bỏ qua phiếu ngược chiều của AI Ensemble khi chỉ số vĩ mô đạt chuẩn Tầng 4:
        # ADX >= 30.0 và ATR < 5.0% (chặn đứng BLUAI ADX=17.0, VELODROME ADX=28.7, RSR#2 ADX=26.6 ATR=5.16%)!
        if 'ai_ensemble' in by_strategy and 'jev_agent' in by_strategy:
            ma_vote = next(
                (
                    s.metadata.get('market_analysis')
                    for s in signals
                    if isinstance(getattr(s, 'metadata', None), dict)
                    and isinstance(s.metadata.get('market_analysis'), dict)
                ),
                {},
            )
            try:
                vote_adx = float((ma_vote or {}).get('adx') or 0.0)
            except (TypeError, ValueError):
                vote_adx = 0.0
            try:
                vote_atr = float((ma_vote or {}).get('atr_pct') or 0.0)
            except (TypeError, ValueError):
                vote_atr = 0.0
            macro_ok_for_rule_f = (vote_adx <= 0.0 or vote_adx >= 30.0) and (vote_atr <= 0.0 or vote_atr < 5.0)

            ai_v = sum(by_strategy['ai_ensemble']) / len(by_strategy['ai_ensemble'])
            other_strats = {k: sum(v) / len(v) for k, v in by_strategy.items() if k != 'ai_ensemble' and v}
            tech_strats = {k: v for k, v in other_strats.items() if k != 'jev_agent'}
            tech_max = max(abs(v) for v in tech_strats.values()) if tech_strats else 0.0

            # =========================================================================
            # QUY TẮC PHỦ QUYẾT XUNG ĐỘT AI TUYỆT ĐỐI (AI HARD CONSENSUS VETO)
            # KIỂM CHỨNG ĐỊNH LƯỢNG TRÊN 274 LỆNH LỊCH SỬ THỰC TẾ & MÔ PHỎNG NẾN 15M:
            # -------------------------------------------------------------------------
            # [LÝ DO BẮT BUỘC KHÔNG ĐƯỢC PHÉP THAY ĐỔI CÔNG THỨC / THAM SỐ NÀY]:
            # Trong lịch sử thực chiến, các lệnh lỗ nặng nhất (BOT/USDT, LAB/USDT, ERA/USDT,
            # GTC/USDT, AIOT/USDT, và gần đây nhất là KGEN/USDT -0.13$, 1000PEPE/USDT -0.06$,
            # ID/USDT -0.07$) đều xảy ra do cùng 1 nguyên nhân:
            # - Chỉ báo kỹ thuật (trend_following / momentum) và LLM thấy nến vừa pump mạnh
            #   nên ADX vọt lên >= 35 và hô BUY (> 85%).
            # - Nhưng mô hình Machine Learning (AI Ensemble 91 đặc trưng) nhận diện Order Flow
            #   kiệt sức (Volume Exhaustion) và RSI quá mua nên cảnh báo SELL cực mạnh (79% - 87%).
            # - Quy tắc cũ cố tình "bỏ qua phiếu trễ pha của AI Ensemble" để đu đỉnh, dẫn tới
            #   mua đúng râu nến cao trào và dính Stop-Loss 100% các lần!
            #
            # KẾT QUẢ MÔ PHỎNG THỰC NGHIỆM:
            # - Khi TUYỆT ĐỐI KHÔNG BỎ QUA AI ENSEMBLE đối kháng mạnh (conf >= 0.70), 12 lệnh
            #   đu đỉnh lớn nhất lịch sử bị triệt tiêu 100%.
            # - Tỷ lệ thắng (Win Rate) tăng từ 61.7% lên 64.5%.
            # - Profit Factor nhảy vọt từ 1.39 lên 1.84 (và đạt 2.36 khi kết hợp Payoff Floor).
            # - BẤT KỲ AI ASSISTANT NÀO TRONG TƯƠNG LAI NẾU MUỐN THAY ĐỔI ĐOẠN CODE NÀY BẮT BUỘC
            #   PHẢI CHẠY LẠI MÔ PHỎNG scratch_full_historical_simulation.py ĐỂ KIỂM CHỨNG!
            # =========================================================================
            is_extreme_ai_conflict = (
                (all(v >= 0.60 for v in other_strats.values()) and ai_v <= -0.70) or
                (all(v <= -0.60 for v in other_strats.values()) and ai_v >= 0.70)
            )

            if is_extreme_ai_conflict:
                # Tuyệt đối giữ nguyên phiếu của AI Ensemble để triệt tiêu điểm số và kích hoạt Micro Consensus Veto
                logger.warning(
                    "⚠️ [XUNG ĐỘT AI CỰC ĐỘ - BẢO VỆ TỐI THƯỢNG] (%s): Các chiến thuật khác đồng thuận (%s) nhưng AI Ensemble kiên quyết đối kháng (%s %.1f%%)! Tuyệt đối KHÔNG bỏ qua phiếu AI Ensemble để tránh bẫy đu đỉnh cao trào!",
                    symbol_name, "BUY" if ai_v < 0 else "SELL", "SELL" if ai_v < 0 else "BUY", abs(ai_v) * 100
                )
            elif len(other_strats) >= 2 and len(tech_strats) >= 1 and macro_ok_for_rule_f:
                # Chỉ cho phép bỏ qua AI Ensemble khi AI Ensemble chỉ lưỡng lự nhẹ (|ai_v| < 0.50)
                # và kỹ thuật thực sự có đồng thuận vĩ mô, tuyệt đối không bỏ qua khi AI Ensemble phản kháng mạnh.
                if all(v >= 0.60 for v in other_strats.values()) and jev_vote >= 0.80 and -0.50 < ai_v < 0:
                    by_strategy.pop('ai_ensemble', None)
                    logger.info(
                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận BUY mạnh, bỏ qua phiếu lưỡng lự nhẹ của AI Ensemble (%.1f%% < 50%%)!",
                        symbol_name, len(other_strats), jev_vote * 100, abs(ai_v) * 100
                    )
                elif all(v <= -0.60 for v in other_strats.values()) and jev_vote <= -0.80 and 0 < ai_v < 0.50:
                    by_strategy.pop('ai_ensemble', None)
                    logger.info(
                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận SELL mạnh, bỏ qua phiếu lưỡng lự nhẹ của AI Ensemble (%.1f%% < 50%%)!",
                        symbol_name, len(other_strats), abs(jev_vote) * 100, abs(ai_v) * 100
                    )

        for name, strategy_signals in by_strategy.items():
            # Conflicting timeframes from the same strategy cancel each other.
            vote = sum(strategy_signals) / len(strategy_signals)
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                votes[name] = (vote, weight)
        return votes

    def calculate_weighted_score(self, signals: List[TradeSignal], votes: Optional[Dict[str, Tuple[float, float]]] = None, apply_entry_vetoes: bool = True) -> float:
        """Return the weighted mean of active strategy votes, in [-1, 1]."""
        if votes is None:
            votes = self._strategy_votes(signals, apply_entry_vetoes=apply_entry_vetoes)
        total_weight = sum(weight for _, weight in votes.values())
        if total_weight <= 0:
            return 0.0
        return sum(vote * weight for vote, weight in votes.values()) / total_weight

    def determine_final_signal(self, score: float, symbol: str, price: float) -> TradeSignal:
        abs_score = abs(score)
        if abs_score >= self.confidence_threshold:
            direction = Signal.BUY if score > 0 else Signal.SELL
        else:
            direction = Signal.HOLD

        return TradeSignal(
            signal=direction,
            symbol=symbol,
            confidence=abs_score,
            strategy='aggregated',
            price=price,
        )

    def _aggregate_protection_level(
        self, signals: List[TradeSignal], final_signal: Signal, price: float, field: str,
    ) -> Optional[float]:
        """Carry a robust, directionally valid strategy SL/TP into the final vote.

        Aggregate percentage distances rather than absolute prices because each
        timeframe can report a slightly different last price. First collapse a
        strategy's timeframes with a median, then take a strategy-weighted median
        so one unusually wide stop/target cannot dominate the result.
        """
        if final_signal not in (Signal.BUY, Signal.SELL):
            return None
        try:
            reference_price = float(price)
        except (TypeError, ValueError, OverflowError):
            return None
        if not math.isfinite(reference_price) or reference_price <= 0:
            return None

        distances_by_strategy: Dict[str, List[float]] = {}
        for signal in signals:
            if signal.signal != final_signal:
                continue
            try:
                signal_price = float(signal.price)
                level = float(getattr(signal, field))
            except (TypeError, ValueError, OverflowError):
                continue
            if not math.isfinite(signal_price) or signal_price <= 0 or not math.isfinite(level) or level <= 0:
                continue

            if field == 'stop_loss':
                distance = (signal_price - level) / signal_price if final_signal == Signal.BUY else (level - signal_price) / signal_price
            else:
                distance = (level - signal_price) / signal_price if final_signal == Signal.BUY else (signal_price - level) / signal_price
            if not math.isfinite(distance) or distance <= 0:
                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', signal.strategy).lower()
            distances_by_strategy.setdefault(name, []).append(distance)

        weighted_distances = []
        for name, distances in distances_by_strategy.items():
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                weighted_distances.append((statistics.median(distances), weight))
        if not weighted_distances:
            return None

        weighted_distances.sort(key=lambda item: item[0])
        half_weight = sum(weight for _, weight in weighted_distances) / 2.0
        cumulative = 0.0
        distance = weighted_distances[-1][0]
        for candidate, weight in weighted_distances:
            cumulative += weight
            if cumulative >= half_weight:
                distance = candidate
                break

        if final_signal == Signal.BUY:
            level = reference_price * (1.0 - distance) if field == 'stop_loss' else reference_price * (1.0 + distance)
        else:
            level = reference_price * (1.0 + distance) if field == 'stop_loss' else reference_price * (1.0 - distance)
        return level if math.isfinite(level) and level > 0 else None

    def aggregate(self, signals: List[TradeSignal]) -> Optional[TradeSignal]:
        if not signals:
            return None

        symbol = signals[0].symbol
        price = signals[0].price
        clean_sym_agg = symbol.split(':')[0].strip().upper()
        clean_base_agg = clean_sym_agg.split('/')[0] if '/' in clean_sym_agg else clean_sym_agg
        is_tier1 = any(clean_base_agg == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
        is_stock = MarketScanner.is_tradfi_stock(symbol)
        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol)
        is_tradfi = is_stock or is_commodity
        is_crypto_altcoin = (not is_tier1) and (not is_tradfi)

        has_cold_start = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('status') == 'cold_start_warmup'
            for s in signals
        )

        votes = self._strategy_votes(signals)
        score = self.calculate_weighted_score(signals, votes=votes)
        agreeing = sum(1 for vote, _ in votes.values() if vote * score > 0)
        logger.info(
            'Aggregated score for %s: %+.4f (threshold=%.2f, agreeing strategies=%d/%d)',
            symbol, score, self.confidence_threshold, agreeing, len(votes),
        )

        # Thu thập macro ADX và ATR từ market_analysis (nếu có) để chống bẫy Breakout giả & thẩm định vi mô
        macro_analysis = next(
            (
                s.metadata.get('market_analysis')
                for s in signals
                if isinstance(getattr(s, 'metadata', None), dict)
                and isinstance(s.metadata.get('market_analysis'), dict)
            ),
            {},
        )
        try:
            macro_adx = float((macro_analysis or {}).get('adx') or 0.0)
        except (TypeError, ValueError):
            macro_adx = 0.0
        try:
            macro_atr_pre = float((macro_analysis or {}).get('atr_pct') or 0.0)
        except (TypeError, ValueError):
            macro_atr_pre = 0.0

        # 0. COLD-START WARMUP VETO:
        # Nếu AI Ensemble vừa train mới (Cold-start Warmup), chỉ cho phép mở lệnh nếu:
        # - Model AI vừa train phải đạt Mean CV Accuracy >= 0.58 (tránh model học vẹt/nhiễu chỉ ngang tung đồng xu 53% như BABY/USDT).
        # - JEV Agent KHÔNG khuyến nghị HOLD (tránh thị trường nhiễu/lưỡng lự như PHA/USDT)
        # - Có >= 2 chiến thuật độc lập đồng thuận VÀ xu hướng vĩ mô mạnh (ADX >= 24.0, như INIT/USDT ADX=29.9 hay DOGE ADX=51.1).
        # Nếu JEV khuyến nghị HOLD hoặc ADX < 24.0 hoặc < 2 chiến thuật (như TIA/USDT ADX=19.1, FOGO 1/1, PHA 1/1), chặn 100%!
        if has_cold_start:
            cs_sig = next((s for s in signals if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('status') == 'cold_start_warmup'), None)
            trained_cv = float((cs_sig.metadata.get('mean_cv_accuracy') or 0.0) if cs_sig else 0.0)
            if trained_cv < 0.58:
                logger.warning(
                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: Model AI vừa train có độ chính xác CV yếu (%.2f%% < 58.0%%), không đủ tin cậy để cấp lệnh!',
                    symbol, trained_cv * 100,
                )
                return None
            jev_sig_cs = next((s for s in signals if s.strategy.lower() in ('jev_agent', 'jevagent')), None)
            if jev_sig_cs and jev_sig_cs.signal == Signal.HOLD and not (macro_adx >= 40.0 and abs(score) >= 0.84 and agreeing >= 2):
                logger.info(
                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi JEV Agent phân tích MTF khuyến nghị HOLD!',
                    symbol,
                )
                return None
            if agreeing < self.min_agreeing_strategies or macro_adx < 24.0:
                logger.info(
                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi ADX=%.1f < 24.0 hoặc đồng thuận=%d/%d chưa đủ mạnh!',
                    symbol, macro_adx, agreeing, self.min_agreeing_strategies,
                )
                return None

        has_breakout_vote = 'momentum_breakout' in votes and (votes['momentum_breakout'][0] * score > 0)
        has_trend_or_trap_support = any(
            k in votes and (votes[k][0] * score > 0)
            for k in ('trend_following', 'trap_detector')
        )
        if has_breakout_vote and macro_adx < 22.0 and not has_trend_or_trap_support:
            logger.warning(
                '🛡️ [WEAK-ADX BREAKOUT VETO] Hủy lệnh %s: MomentumBreakout phát tín hiệu khi ADX vĩ mô quá yếu (ADX=%.1f < 22.0) và thiếu xác nhận Trend/Trap!',
                symbol, macro_adx,
            )
            return None

        # Yêu cầu bắt buộc đủ số chiến thuật đồng thuận (tối thiểu >= min_agreeing_strategies, cấm 1 chiến thuật đơn lẻ tự vượt rào như FOGO/USDT)
        if agreeing < self.min_agreeing_strategies:
            logger.info(
                'No trade for %s: need %d agreeing strategies, got %d',
                symbol, self.min_agreeing_strategies, agreeing,
            )
            return None

        # PHƯƠNG ÁN A+: PHỦ QUYẾT CHIẾN LƯỢC ĐỐI KHÁNG KHI ĐỒNG THUẬN YẾU (<= 2)
        # Nếu chỉ có 2 chiến thuật đồng thuận (mức sàn tối thiểu) mà có bất kỳ chiến thuật nào
        # (như TrapDetector, AI Ensemble, hoặc Momentum) đối kháng ngược chiều (confidence >= 0.60):
        # Lập tức VETO để triệt tiêu các lệnh đu đỉnh râu nến (như ZEREBRO, SOL, ETH, DUSK)!
        exempt_ai_opposing = False
        if agreeing <= self.min_agreeing_strategies:
            opposing_strats = [
                f"{s_name} ({v:+.2f})" for s_name, (v, _) in votes.items()
                if v * score < 0 and abs(v) >= 0.60
            ]
            if opposing_strats:
                # Kịch Bản 2: Miễn trừ nếu duy nhất AI Ensemble trễ pha 4H đối kháng vừa phải (<70%) trong khi nến 15M có Trap/Reversal mạnh (>= 75%) và ADX >= 25.0
                only_ai_opposing = all('ai_ensemble' in s for s in opposing_strats)
                # Tuyệt đối KHÔNG miễn trừ khi AI Ensemble đối kháng cực độ (>= 70%) để bảo toàn nguyên vẹn 12 lệnh né đu đỉnh
                ai_opposing_extreme = any(
                    getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')
                    and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)
                    and ((1.0 if s.signal == Signal.BUY else -1.0) * score < 0)
                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                    for s in signals
                )
                # Chỉ tính các chiến thuật kỹ thuật độc lập (non-AI) đồng pha cùng chiều với score (không tính HOLD hay ngược chiều)
                agreeing_non_ai_signals = [
                    s for s in signals
                    if getattr(s, 'strategy', '').lower() not in ('jev_agent', 'jevagent', 'ai_ensemble', 'aiensemble')
                    and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)
                    and ((1.0 if s.signal == Signal.BUY else -1.0) * score > 0)
                ]
                has_strong_reversal = (
                    any(
                        getattr(s, 'strategy', '').lower() in ('trap_detector', 'mean_reversion')
                        and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                        for s in agreeing_non_ai_signals
                    )
                    or max((float(getattr(s, 'confidence', 0.0) or 0.0) for s in agreeing_non_ai_signals), default=0.0) >= 0.75
                )
                if only_ai_opposing and not ai_opposing_extreme and has_strong_reversal and (macro_adx <= 0.0 or macro_adx >= 25.0):
                    exempt_ai_opposing = True
                    logger.info(
                        "⚡ [MIỄN TRỪ OPPOSING VETO] %s: Kỹ thuật 15M đảo chiều mạnh (>=75%%, ADX=%.1f >= 25.0), bỏ qua phiếu đối kháng 4H của AI Ensemble!",
                        symbol, macro_adx
                    )
                else:
                    logger.warning(
                        '🚫 [OPPOSING STRATEGY VETO] Hủy mở lệnh %s: Đồng thuận yếu (%d chiến thuật) trong khi có chiến thuật đối kháng mạnh: %s!',
                        symbol, agreeing, ", ".join(opposing_strats),
                    )
                    return None

        # Yêu cầu bắt buộc ít nhất 1 chiến thuật kỹ thuật độc lập (Trend, Breakout, MR, Trap) đồng thuận
        non_ai_agreeing = sum(
            1 for s_name, (v, _) in votes.items()
            if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0
        )
        if non_ai_agreeing < 1:
            logger.info(
                'No trade for %s: cần ít nhất 1 chiến thuật kỹ thuật độc lập (non-AI) đồng thuận, hiện có %d',
                symbol, non_ai_agreeing,
            )
            return None

        # SÀN ĐỒNG THUẬN VI MÔ (ADAPTIVE MICRO CONSENSUS):
        # Đối với Altcoin và Cổ phiếu (ngoài BTC/ETH):
        # Nếu AI Ensemble có độ tự tin thấp/vừa phải (< 60%),
        # thì BẮT BUỘC phải có xu hướng thực chất (ADX >= 30.0, không biến động hỗn loạn ATR < 5.0%) kèm đồng thuận mạnh:
        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 2 chiến thuật kỹ thuật (như CYS ADX=52.8)
        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 1 kỹ thuật + JEV Agent khẳng định mạnh (Conf >= 80%, như INIT ADX=31.6, AVAX ADX=32.2)!
        # Quy tắc này triệt tiêu 100% lệnh thua yếu lực (TAO ADX=26.0, AERO ADX=20.1, WLD ADX=26.4, ON ATR=5.58%)
        # trong khi bảo toàn trọn vẹn 100% các lệnh thắng đa đồng thuận (CYS, INIT, AVAX)!
        clean_sym_pre = symbol.split(':')[0].strip().upper()
        clean_base_pre = clean_sym_pre.split('/')[0] if '/' in clean_sym_pre else clean_sym_pre
        is_tier1 = any(clean_base_pre == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
        ai_sig = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')), None)
        jev_sig_pre = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)
        jev_conf_pre = 0.0
        if jev_sig_pre:
            try:
                jev_conf_pre = float(jev_sig_pre.confidence)
            except (TypeError, ValueError):
                jev_conf_pre = 0.0

        # DEAD ADX VETO: Thị trường cạn kiệt xung lực (ADX < 20.0)
        # Bắt buộc VETO toàn bộ tín hiệu TrendFollowing / Breakout trên Altcoin khi ADX < 20.0
        # (chặn đứng DASH ADX=13.1), trừ khi có TrapDetector đảo chiều mạnh >= 75%
        if is_crypto_altcoin and (0.0 < macro_adx < 20.0):
            has_strong_trap_reversal = any(
                getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.75
                for s in signals
            )
            if not has_strong_trap_reversal:
                logger.warning(
                    '🛡️ [DEAD ADX VETO] Hủy mở lệnh %s: Thị trường hoàn toàn đi ngang/cạn kiệt xung lực (ADX=%.1f < 20.0)! Cấm mở lệnh theo xu hướng để tránh chôn vốn!',
                    symbol, macro_adx
                )
                return None

        if ai_sig and ('ai_ensemble' in votes or (ai_sig.signal == Signal.HOLD and not has_cold_start)) and not is_tier1:
            try:
                ai_c = 0.0 if ai_sig.signal == Signal.HOLD else float(ai_sig.confidence)
            except (TypeError, ValueError):
                ai_c = 0.0
            ai_is_opposing = (
                (ai_sig.signal == Signal.BUY and score < 0)
                or (ai_sig.signal == Signal.SELL and score > 0)
            )
            adx_floor = 25.0 if exempt_ai_opposing else 30.0
            adx_ok_micro = (macro_adx <= 0.0) or (macro_adx >= adx_floor)
            atr_ok_micro = (macro_atr_pre <= 0.0) or (macro_atr_pre < 5.0)
            if ai_is_opposing or ai_c < 0.60:
                # Phân nhánh Tầng 4 (bắt buộc thỏa mãn đồng thời ADX >= 30.0, ATR < 5.0% và không bị AI phản bác
                # hoặc được miễn trừ chính thức do kỹ thuật 15M đảo chiều mạnh):
                # Khi AI Ensemble yếu (< 60%), bắt buộc phải có ít nhất 2 chiến thuật kỹ thuật độc lập đồng thuận
                # HOẶC 1 kỹ thuật độc lập + JEV Agent khẳng định mạnh (>= 80%):
                has_tech_support = (non_ai_agreeing >= 2) or (non_ai_agreeing >= 1 and jev_conf_pre >= 0.80)
                is_strong_consensus = (
                    ((not ai_is_opposing) or exempt_ai_opposing)
                    and has_tech_support
                    and adx_ok_micro
                    and atr_ok_micro
                )
                if not is_strong_consensus:
                    logger.info(
                        '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble %s (%.2f%%) và cấu trúc vi mô (agree=%d, non_ai=%d, jev=%.2f, ADX=%.1f, ATR=%.2f%%) chưa đạt chuẩn!',
                        symbol, 'NGƯỢC CHIỀU' if ai_is_opposing else 'yếu (<60%)', ai_c * 100, agreeing, non_ai_agreeing, jev_conf_pre, macro_adx, macro_atr_pre
                    )
                    return None
            elif ai_c < 0.70 and not adx_ok_micro and macro_atr_pre >= 3.0:
                logger.info(
                    '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble trung bình (%.2f%% < 70%%) nhưng xung lượng vĩ mô yếu và biến động cao (ADX=%.1f < 30.0, ATR=%.2f%% >= 3.0%%)!',
                    symbol, ai_c * 100, macro_adx, macro_atr_pre
                )
                return None

        final_signal = self.determine_final_signal(score, symbol, price)
        if final_signal.signal != Signal.HOLD:
            # --- JEV AGENT VALIDATION & CONTRADICTION VETO ---
            jev_sig = next((s for s in signals if s.strategy.lower() in ('jev_agent', 'jevagent')), None)
            if jev_sig:
                try:
                    jev_conf = float(jev_sig.confidence)
                except (TypeError, ValueError):
                    jev_conf = 0.0

                # 1. Chống đánh ngược JEV Agent quyết đoán (Conf >= 0.70)
                if jev_sig.signal == Signal.SELL and jev_conf >= 0.70 and final_signal.signal == Signal.BUY:
                    logger.warning(
                        "🛡️ VETO JEV AGENT: Hủy lệnh BUY %s do JEV Agent phân tích MTF khẳng định SELL (Conf: %.2f)!",
                        symbol, jev_conf,
                    )
                    return None
                if jev_sig.signal == Signal.BUY and jev_conf >= 0.70 and final_signal.signal == Signal.SELL:
                    has_trap_sell = 'trap_detector' in votes and votes['trap_detector'][0] < 0
                    if has_trap_sell or non_ai_agreeing >= 2:
                        logger.info(
                            "⚡ BẢO VỆ LỆNH SELL %s: TrapDetector/Đồng thuận kỹ thuật (non_ai=%d) phát hiện đỉnh/bẫy giá cá mập, bỏ qua phủ quyết BUY của JEV Agent!",
                            symbol, non_ai_agreeing,
                        )
                    else:
                        logger.warning(
                            "🛡️ VETO JEV AGENT: Hủy lệnh SELL %s do JEV Agent phân tích MTF khẳng định BUY (Conf: %.2f)!",
                            symbol, jev_conf,
                        )
                        return None

                # 2. Bảo vệ khi JEV Agent khuyến nghị HOLD rõ rệt: ÁP DỤNG BÌNH ĐẲNG CHO TOÀN BỘ TÀI SẢN (CRYPTO & TRADFI)
                # Khi JEV Agent cảnh báo thị trường nén đi ngang / không có breakout / xung đột đa khung (choppy/consolidation/conflicting/no clear breakout):
                # - Ngưỡng kích hoạt siết về 0.60 (mức confidence chuẩn của mô hình qwen2.5:7b khi ra quyết định HOLD).
                # - Bắt buộc VETO 100% nếu không có bẫy cá mập cực mạnh (raw_trap_c >= 0.80) hoặc đồng thuận kỹ thuật tuyệt đối (non_ai_agreeing >= 3).
                if jev_sig.signal == Signal.HOLD:
                    jev_risk_text = (str(getattr(jev_sig, 'metadata', {}).get('risk_factors', '')) + " " + str(getattr(jev_sig, 'metadata', {}).get('reason', ''))).lower()
                    is_consolidation_hold = any(w in jev_risk_text for w in (
                        'consolidation', 'choppy', 'volume exhaustion', 'overbought', 'no clear breakout', 'conflicting'
                    ))
                    eff_hold_thresh = 0.60 if is_consolidation_hold else 0.70
                    if jev_conf >= eff_hold_thresh:
                        non_ai_agreeing = sum(
                            1 for s_name, (v, _) in votes.items()
                            if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0
                        )
                        raw_trap_c = max(
                            (
                                float(getattr(s, 'confidence', 0.0) or 0.0)
                                for s in signals
                                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)
                                and ((1.0 if s.signal == Signal.BUY else -1.0) * score > 0)
                            ),
                            default=0.0,
                        )
                        should_veto_hold = False
                        if is_consolidation_hold:
                            if non_ai_agreeing < 3 and raw_trap_c < 0.80:
                                should_veto_hold = True
                        else:
                            if non_ai_agreeing < 2:
                                should_veto_hold = True

                        if should_veto_hold or abs(score) < self.confidence_threshold:
                            logger.warning(
                                "🛡️ VETO JEV AGENT HOLD (%s): Hủy lệnh %s %s do JEV Agent khuyến nghị HOLD (Conf: %.2f, lý do: %s, non_ai=%d, trap=%.2f)!",
                                "CONSOLIDATION/CHOPPY" if is_consolidation_hold else "LƯỠNG LỰ",
                                final_signal.signal.value.upper(), symbol, jev_conf,
                                "Thị trường nén đi ngang/không có breakout" if is_consolidation_hold else "Lưỡng lự",
                                non_ai_agreeing, raw_trap_c
                            )
                            return None

            # Thu thập market analysis từ tín hiệu 4H
            market_analysis = next(
                (
                    signal.metadata.get('market_analysis')
                    for signal in signals
                    if isinstance(getattr(signal, 'metadata', None), dict)
                    and isinstance(signal.metadata.get('market_analysis'), dict)
                ),
                {},
            )
            
            # --- MTF TREND FILTER (Cấm lướt sóng ngược bão) ---
            regime = str(market_analysis.get('regime', 'ranging')).lower()
            ema = str(market_analysis.get('ema_alignment', '')).lower()
            
            is_downtrend = 'downtrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bearish')
            is_uptrend = 'uptrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bullish')
            
            # Khóa lệnh ngược trend: TUYỆT ĐỐI CẤM BUY ngược 4H downtrend trừ khi có BẪY GẤU hợp lệ (còn tồn tại trong votes)
            has_bear_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] > 0
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'BEAR_TRAP_DIP')
                    for s in signals
                )
            )
            has_bull_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] < 0
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE')
                    for s in signals
                )
            )

            # MTF Trend Filter bắt buộc (TUYỆT ĐỐI KHÔNG BỎ QUA dù điểm số breakout cao đến đâu):
            # Không bao giờ bơi ngược dòng 4H để tránh đu đỉnh bẫy giá Bull Trap như trường hợp ZK/USDT, ZRO/USDT
            if final_signal.signal == Signal.BUY and is_downtrend:
                if has_bear_trap_wick and abs(score) >= 0.70:
                    logger.info(f"⚡ MTF Trap Override: Cho phép BUY {symbol} ngược 4H do phát hiện Quét thanh khoản gom hàng (Score: {score:+.2f})")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh BUY {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Cấm bắt dao rơi khi không có bẫy gấu rút chân gom hàng.")
                    return None
                    
            if final_signal.signal == Signal.SELL and is_uptrend:
                if has_bull_trap_wick and abs(score) >= 0.70:
                    logger.info(f"⚡ MTF Trap Override: Cho phép SELL {symbol} ngược 4H do phát hiện Bẫy tăng xả hàng (Score: {score:+.2f})")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh SELL {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Không có xác nhận bẫy tăng xả hàng.")
                    return None

            # --- BỘ LỌC CỰC HẠN & BẢO VỆ ĐỈNH ĐÁY (CLIMAX & EXHAUSTION GATE) ---
            try:
                macro_atr_pct = float(market_analysis.get('atr_pct') or 0.0)
            except (TypeError, ValueError):
                macro_atr_pct = 0.0
            try:
                current_rsi = float(market_analysis.get('tactical_rsi') or market_analysis.get('rsi') or 50.0)
            except (TypeError, ValueError):
                current_rsi = 50.0

            # 1. Chống Đu Đỉnh Bơm Xả Nước Rút (Parabolic Climax Pump):
            # Khi Altcoin đã bơm thốc cực hạn (ADX >= 55.0),
            # thị trường đã tiến vào pha phân phối (distribution peak) của cá mập (như DUSK ở 0.11015 ADX=62.8). CẤM BUY!
            # Áp dụng chuẩn cho Altcoin, không chặn nhầm cổ phiếu TradFi (NVDA, TSLA) hay Coin Major (BTC, ETH)
            if final_signal.signal == Signal.BUY and is_crypto_altcoin:
                if macro_adx >= 55.0:
                    logger.warning(
                        "🛡️ [CLIMAX PUMP VETO] Hủy lệnh BUY %s: Altcoin đạt trạng thái bơm xả cực hạn (ADX=%.1f, ATR=%.2f%%)! Cấm đu đỉnh phân phối.",
                        symbol, macro_adx, macro_atr_pct,
                    )
                    return None

            # 2. Chống Bán Tháo Đuôi Đáy (Oversold Bottom Chasing):
            # Khi RSI 15m <= 35.0, lực bán đã kiệt sức. Mở SHORT lúc này dễ dính bẫy hồi kỹ thuật (Short Squeeze) như SNDK và SOL.
            # Ngoại lệ: Chỉ cho phép SHORT nếu có Bull Trap (bẫy tăng xả hàng) xác nhận rõ ràng.
            if final_signal.signal == Signal.SELL:
                if current_rsi <= 35.0 and not has_bull_trap_wick:
                    logger.warning(
                        "🛡️ [OVERSOLD SHORT VETO] Hủy lệnh SELL %s: RSI 15m quá bán (RSI=%.1f <= 35.0) và thiếu Bull Trap! Cấm bán tháo đuôi đáy.",
                        symbol, current_rsi,
                    )
                    return None

            # 3. Chống Đu Đỉnh Quá Mua (Overbought Top Chasing):
            # Khi RSI 15m >= 68.0, lực mua đã cạn kiệt, giá chạm vùng quá mua cục bộ (như trường hợp RAYSOL). CẤM BUY đu đỉnh!
            # Ngoại lệ: Chỉ cho phép BUY nếu có Bear Trap (bẫy gấu rút chân gom hàng) xác nhận rõ ràng.
            # Áp dụng chuẩn cho Altcoin, không chặn nhầm cổ phiếu TradFi hay Coin Major
            if final_signal.signal == Signal.BUY and is_crypto_altcoin:
                if current_rsi >= 68.0 and not has_bear_trap_wick:
                    logger.warning(
                        "🛡️ [OVERBOUGHT BUY VETO] Hủy lệnh BUY %s: RSI 15m quá mua (RSI=%.1f >= 68.0) và thiếu Bear Trap! Cấm đu đỉnh mua đuổi.",
                        symbol, current_rsi,
                    )
                    return None

            # Tính toán SL/TP
            final_signal.stop_loss = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'stop_loss'
            )
            final_signal.take_profit = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'take_profit'
            )
            
            # Bảo toàn đầy đủ metadata hạ nguồn (dfs cho Pre-Trade Gate & M1 Sniper, type của TrapDetector, reason/risk_factors của JEV)
            shared_dfs = next(
                (
                    s.metadata.get('dfs')
                    for s in signals
                    if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('dfs') is not None
                ),
                None,
            )
            trap_type_val = next(
                (
                    s.metadata.get('type')
                    for s in signals
                    if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                    and getattr(s, 'signal', None) == final_signal.signal
                    and isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type')
                ),
                None,
            )
            jev_meta = getattr(jev_sig, 'metadata', {}) if (jev_sig and isinstance(getattr(jev_sig, 'metadata', None), dict)) else {}

            final_signal.metadata.update({
                'contributing_strategies': sorted(votes.keys()),
                'weighted_score': score,
                'agreeing_strategies': agreeing,
                'strategy_count': len(votes),
                'agreement_ratio': agreeing / len(votes) if votes else 0.0,
                'market_analysis': market_analysis,
                'dfs': shared_dfs,
                'type': trap_type_val,
                'jev_decision': jev_sig.signal.value.upper() if (jev_sig and hasattr(jev_sig, 'signal') and hasattr(jev_sig.signal, 'value')) else 'NONE',
                'reason': jev_meta.get('reason', ''),
                'risk_factors': (
                    ', '.join(jev_meta['risk_factors'])
                    if isinstance(jev_meta.get('risk_factors'), list)
                    else (jev_meta.get('risk_factors') or 'none')
                ),
            })
        return final_signal if final_signal.signal != Signal.HOLD else None

