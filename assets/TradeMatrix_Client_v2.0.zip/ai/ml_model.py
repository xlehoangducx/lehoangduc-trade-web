import os
os.environ["PYTHONWARNINGS"] = "ignore"
import warnings
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)
warnings.filterwarnings('ignore', module='.*sklearn.*')
warnings.filterwarnings('ignore', message='.*delayed.*')
warnings.filterwarnings('ignore', message='.*sklearn.*')
warnings.filterwarnings('ignore', message='.*feature names.*')
warnings.filterwarnings('ignore', message='.*validation.*')

import pandas as pd
import numpy as np
import logging
import joblib
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import cross_val_score, TimeSeriesSplit
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from typing import Tuple, Dict, Any

logger = logging.getLogger(__name__)


def purged_time_series_splits(n_samples: int, n_splits: int = 5, prediction_horizon: int = 5):
    """TimeSeriesSplit có purge: nhãn train không được nhìn vào test fold."""
    splitter = TimeSeriesSplit(n_splits=n_splits)
    for train_idx, test_idx in splitter.split(np.arange(int(n_samples))):
        if len(train_idx) <= prediction_horizon:
            raise ValueError("Training fold quá nhỏ sau khi purge prediction_horizon")
        # Label tại train[-h:] dùng close nằm trong test fold -> phải loại bỏ.
        yield train_idx[:-prediction_horizon], test_idx


class MLPredictor:
    """
    Mô hình học máy dự đoán xu hướng giá sử dụng Ensemble của Random Forest và XGBoost.
    (Machine learning model for price trend prediction using Random Forest and XGBoost Ensemble)
    """
    
    def __init__(self):
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        
        # Khởi tạo các mô hình cơ sở
        rf = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42, n_jobs=-1)
        # Bật early_stopping_rounds để tránh XGBoost overfit
        xgb = XGBClassifier(n_estimators=100, max_depth=6, learning_rate=0.1, random_state=42, eval_metric='logloss')
        
        # Kết hợp bằng VotingClassifier (soft voting để lấy probability)
        ensemble = VotingClassifier(
            estimators=[('rf', rf), ('xgb', xgb)],
            voting='soft'
        )
        
        self.model = Pipeline([
            ('scaler', StandardScaler()),
            ('ensemble', ensemble)
        ])
        self.is_trained = False
        
    def _create_labels(self, df: pd.DataFrame, prediction_horizon: int) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Tạo nhãn (labels) dựa trên biến động giá tương lai.
        1: Giá tăng, 0: Giá giảm
        """
        df = df.copy()
        # Tính giá trị tương lai
        df['future_close'] = df['close'].shift(-prediction_horizon)
        
        # Bỏ các hàng không có dữ liệu tương lai
        df.dropna(subset=['future_close'], inplace=True)
        
        # Tạo nhãn: 1 nếu giá tương lai > giá hiện tại, ngược lại 0
        y = (df['future_close'] > df['close']).astype(int)
        
        # Chỉ lấy các đặc trưng (loại bỏ cột giá trị tương lai)
        feature_cols = [col for col in df.columns if col not in ['open', 'high', 'low', 'close', 'volume', 'future_close', 'timestamp', 'datetime', 'date']]
        X = df[feature_cols]
        
        return X, y

    def train(self, df: pd.DataFrame, prediction_horizon: int = 5) -> Dict[str, float]:
        """
        Huấn luyện mô hình với Cross-Validation kiểu TimeSeries.
        (Train model with TimeSeries Cross-Validation)
        """
        try:
            logger.info(f"Starting model training with horizon {prediction_horizon}")
            X, y = self._create_labels(df, prediction_horizon)
            
            if len(X) < 100:
                logger.error("Not enough data to train the model.")
                raise ValueError("Insufficient data")
                
            # Purged Time Series CV: chặn rò nhãn tương lai qua biên train/test.
            cv_splits = list(purged_time_series_splits(len(X), n_splits=5, prediction_horizon=prediction_horizon))
            cv_scores = cross_val_score(self.model, X, y, cv=cv_splits, scoring='accuracy')
            logger.info(f"Cross-validation accuracy scores: {cv_scores}")
            logger.info(f"Mean CV accuracy: {np.mean(cv_scores):.4f}")
            
            # Huấn luyện trên toàn bộ dữ liệu
            self.model.fit(X, y)
            self.is_trained = True
            
            logger.info("Model training completed.")
            return {"mean_cv_accuracy": np.mean(cv_scores)}
            
        except Exception as e:
            logger.error(f"Error training model: {e}")
            raise
            
    def predict(self, features: pd.DataFrame) -> Tuple[int, float]:
        """
        Dự đoán xu hướng và độ tự tin (confidence).
        (Predict trend and return confidence)
        """
        if not self.is_trained:
            logger.error("Model has not been trained yet.")
            raise RuntimeError("Model not trained")
            
        try:
            # Lấy các cột feature, loại bỏ giá và volume
            feature_cols = [col for col in features.columns if col not in ['open', 'high', 'low', 'close', 'volume', 'timestamp', 'datetime', 'date']]
            X = features[feature_cols]
            
            # Dự đoán trên dòng dữ liệu mới nhất
            latest_X = X.iloc[-1:].copy()
            
            # Đồng bộ chính xác thứ tự và tên cột đặc trưng theo StandardScaler (triệt tiêu UserWarning sklearn.utils)
            scaler = getattr(self.model, 'named_steps', {}).get('scaler')
            if scaler and hasattr(scaler, 'feature_names_in_'):
                expected_cols = list(scaler.feature_names_in_)
                for c in expected_cols:
                    if c not in latest_X.columns:
                        latest_X[c] = 0.0
                latest_X = latest_X[expected_cols]
            
            # Lấy xác suất
            probs = self.model.predict_proba(latest_X)[0]
            
            # Xác định lớp dự đoán và độ tự tin
            prediction = 1 if probs[1] > probs[0] else 0
            confidence = probs[1] if prediction == 1 else probs[0]
            
            return prediction, float(confidence)
            
        except Exception as e:
            logger.error(f"Error making prediction: {e}")
            raise
            
    def evaluate(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict[str, float]:
        """
        Đánh giá mô hình trên tập kiểm tra.
        (Evaluate model on test set)
        """
        if not self.is_trained:
            raise RuntimeError("Model not trained")
            
        predictions = self.model.predict(X_test)
        
        metrics = {
            "accuracy": accuracy_score(y_test, predictions),
            "precision": precision_score(y_test, predictions, zero_division=0),
            "recall": recall_score(y_test, predictions, zero_division=0),
            "f1": f1_score(y_test, predictions, zero_division=0)
        }
        return metrics
        
    def get_feature_importance(self) -> Dict[str, float]:
        """
        Lấy độ quan trọng của các đặc trưng (từ mô hình Random Forest).
        (Get feature importance from Random Forest base model)
        """
        if not self.is_trained:
            raise RuntimeError("Model not trained")
            
        ensemble_step = self.model.named_steps.get('ensemble') if hasattr(self.model, 'named_steps') else self.model
        rf_model = ensemble_step.named_estimators_['rf']
        importances = rf_model.feature_importances_
        # Note: requires knowing the feature names, typically you'd store X.columns during training
        # For simplicity, returning just the array indices as strings if names aren't saved
        return {f"feature_{i}": float(imp) for i, imp in enumerate(importances)}
        
    def save_model(self, path: str):
        """Lưu mô hình (Save model)"""
        if not self.is_trained:
            raise RuntimeError("Cannot save untrained model")
        try:
            joblib.dump(self.model, path)
            logger.info(f"Model saved to {path}")
        except Exception as e:
            logger.error(f"Error saving model: {e}")
            raise
            
    def load_model(self, path: str):
        """Tải mô hình (Load model)"""
        try:
            self.model = joblib.load(path)
            self.is_trained = True
            logger.info(f"Model loaded from {path}")
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            raise
