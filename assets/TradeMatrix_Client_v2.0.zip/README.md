# 🏗️ SƠ ĐỒ CẤU TRÚC HỆ THỐNG TRADE BOT V2
# Cập nhật lần cuối: 2026-09-29
# Mục đích: Tài liệu tham chiếu cho AI hoặc lập trình viên khi nâng cấp/sửa lỗi

## 📁 CẤU TRÚC THƯ MỤC

```
TRADE/                          ← Thư mục gốc dự án
│
├── config/                     ← 🔧 CẤU HÌNH HỆ THỐNG
│   ├── settings.yaml           ← Cấu hình chính (mode, exchange, risk, trading)
│   │                              ⚠️ LƯU Ý: Đang chứa API key plaintext → CẦN CHUYỂN SANG .env
│   │                              ⚠️ LƯU Ý: Dùng USDC nhưng pairs.yaml dùng USDT
│   ├── strategies.yaml         ← Cấu hình chiến lược + AI Bias (được ghi đè runtime)
│   │                              ⚠️ LƯU Ý: PyYAML xóa comments khi dump
│   └── pairs.yaml              ← Danh sách trading pairs, blacklist
│
├── core/                       ← 🧠 CORE ENGINE (Trung tâm điều khiển)
│   ├── bot.py                  ← [49KB] Bot chính: Vòng lặp giao dịch, quản lý position
│   │                              Chứa: TradeBot class, run_cycle(), _execute_signal(),
│   │                              _close_position(), _check_open_positions(),
│   │                              AI background loop, Optimizer loop
│   │                              ⚠️ NHIỀU LỖI CHÍ MẠNG - Xem báo cáo audit
│   ├── exchange.py             ← Kết nối sàn qua CCXT (Spot + Futures)
│   │                              Chứa: ExchangeConnector class
│   │                              ⚠️ THIẾU: Retry logic, Rate limit handling
│   ├── order_manager.py        ← Quản lý lệnh
│   │                              ⚠️ CHƯA HOÀN THIỆN: check_orders() chưa sync DB
│   ├── data_collector.py       ← Thu thập dữ liệu OHLCV
│   │                              ⚠️ NGUY HIỂM: Fallback về stale data khi lỗi
│   ├── scanner.py              ← Quét thị trường tìm coin tiềm năng
│   │                              ⚠️ Fallback về pair cứng khi lỗi
│   ├── optimizer.py            ← Tối ưu hóa tham số chiến lược (chạy mỗi 24h)
│   │                              ⚠️ Backtest không tính phí/slippage
│   └── __init__.py
│
├── strategies/                 ← 📊 CÁC CHIẾN LƯỢC GIAO DỊCH
│   ├── base_strategy.py        ← Base class: Signal enum, TradeSignal dataclass
│   │                              Defines: BUY, SELL, HOLD signals
│   ├── trend_following.py      ← EMA crossover + ADX + Volume + RSI
│   │                              Weight: 0.30 | ⚠️ Hardcode params thay vì dùng config
│   ├── hft_scalping.py         ← Stochastic RSI + Bollinger Bands + EMA200
│   │                              Weight: 0.50 | ⚠️ Đọc file YAML mỗi tick (I/O bottleneck)
│   ├── mean_reversion.py       ← Bollinger Bands + RSI
│   │                              Weight: 0.25 | ⚠️ LOGIC SAI: Entry conditions quá sớm
│   ├── smart_dca.py            ← Dollar Cost Averaging thông minh
│   │                              Weight: 0.15 | ⚠️ KHÔNG CÓ STOP LOSS (cực kỳ nguy hiểm)
│   └── __init__.py
│
├── ai/                         ← 🤖 AI/ML MODULE
│   ├── feature_engine.py       ← Tạo features kỹ thuật cho ML
│   │                              ⚠️ DATA LEAKAGE: Scaler fit trên toàn bộ dataset
│   ├── ml_model.py             ← RandomForest + XGBoost ensemble
│   │                              ⚠️ Overfitting: Không có early stopping cho XGBoost
│   ├── signal_aggregator.py    ← Tổng hợp tín hiệu từ nhiều chiến lược
│   │                              ⚠️ LOGIC SAI: HOLD không tính vào total_weight
│   ├── news_sentiment.py       ← Phân tích tin tức qua RSS
│   │                              ⚠️ PROMPT INJECTION: Tin tức chèn thẳng vào LLM prompt
│   ├── ollama_agent.py         ← Master AI: Phân tích macro, điều chỉnh bias/leverage
│   │                              ⚠️ JSON parse lỗi khi LLM trả markdown
│   ├── market_regime.py        ← Nhận diện chế độ thị trường (trending/ranging)
│   └── __init__.py
│
├── risk/                       ← 🛡️ QUẢN LÝ RỦI RO
│   ├── risk_manager.py         ← SL/TP check, trailing stop, drawdown check
│   │                              ✓ Giới hạn vị thế và tổng ký quỹ theo equity
│   │                              ✓ Slot bổ sung chỉ khi chất lượng tín hiệu đủ cao
│   ├── position_sizer.py       ← Tính kích thước vị thế (Fixed, ATR, Kelly)
│   │                              ⚠️ Không tính leverage khi cap max_size
│   └── __init__.py
│
├── database/                   ← 💾 LƯU TRỮ DỮ LIỆU
│   ├── db_manager.py           ← SQLite CRUD: trades, signals, performance, bot_state
│   │                              ⚠️ Không có WAL mode → "database is locked" khi multi-thread
│   ├── trading.db              ← Database file (HIỆN TRỐNG)
│   └── __init__.py
│
├── dashboard/                  ← 🌐 WEB DASHBOARD
│   ├── app.py                  ← Flask web server + REST API endpoints
│   │                              ⚠️ THREAD LEAK: Start/Pause tạo thread mới không kill cũ
│   │                              ⚠️ KHÔNG CÓ AUTHENTICATION
│   ├── templates/
│   │   └── index.html          ← [43KB] Giao diện web (Chart.js, real-time updates)
│   └── __init__.py
│
├── data/                       ← 📂 DỮ LIỆU
│   ├── historical/             ← File CSV dữ liệu nến (1m, 5m, 15m, 1h, 4h)
│   ├── models/                 ← File .pkl model ML đã train
│   ├── trade_bot.db            ← Database chính (188KB)
│   └── trading_bot.db          ← Database phụ (TRỐNG - có thể xóa)
│
├── logs/                       ← 📋 NHẬT KÝ
│   └── bot_YYYYMMDD.log       ← Log hoạt động theo ngày
│
├── ai_knowledge_base.md        ← 📝 Nhật ký giao dịch cho AI đọc lại
│                                  Ghi tự động khi đóng lệnh + biên bản họp AI
├── requirements.txt            ← Dependencies
├── run_web.py                  ← Entry point chạy bot + dashboard
├── install.bat                 ← Script cài đặt Windows
├── START.bat                   ← Script khởi chạy Windows
├── API BINANCE.txt             ← ⚠️ FILE CHỨA API KEY (NÊN XÓA/MÃ HÓA)
└── README.md                   ← Hướng dẫn sử dụng
```

---

## 🔄 LUỒNG HOẠT ĐỘNG CHÍNH

```
┌──────────────────────────────────────────────────────────────────┐
│                        KHỞI ĐỘNG BOT                             │
│  run_web.py → TradeBot.__init__() → _init_components()           │
│  → Load config → Connect exchange → Init strategies              │
│  → Init AI → Init risk manager → _restore_state()                │
└──────────────────────────┬───────────────────────────────────────┘
                           │
    ┌──────────────────────┼──────────────────────┐
    │                      │                      │
    ▼                      ▼                      ▼
┌──────────┐        ┌──────────┐          ┌──────────────┐
│ AI Loop  │        │ MAIN     │          │ Optimizer    │
│ (Thread) │        │ LOOP     │          │ Loop (Thread)│
│ 5 phút/  │        │ 5 phút/  │          │ 24h/lần      │
│ lần      │        │ lần      │          │              │
│          │        │          │          │              │
│ Ollama   │        │ run_     │          │ Backtest     │
│ Agent    │        │ cycle()  │          │ → Optimize   │
│ → phân   │        │          │          │ → Update     │
│ tích vĩ  │        │          │          │ strategies   │
│ mô       │        │          │          │ .yaml        │
│ → news   │        │          │          │              │
│ → cập    │        │          │          │              │
│ nhật     │        │          │          │              │
│ ai_bias  │        │          │          │              │
│ trong    │        │          │          │              │
│ strategies│       │          │          │              │
│ .yaml    │        │          │          │              │
└──────────┘        └────┬─────┘          └──────────────┘
                         │
                         ▼
    ┌─────────────────────────────────────────┐
    │           run_cycle() chi tiết           │
    │                                         │
    │  1. _check_open_positions()             │
    │     → Kiểm tra SL/TP/Trailing Stop     │
    │     → Đóng lệnh nếu hit               │
    │  2. _check_drawdown()                   │
    │     → Pause nếu vượt ngưỡng           │
    │  3. Đọc AI Bias từ strategies.yaml      │
    │     → Skip nếu NONE hoặc HIGH_RISK     │
    │  4. Scanner quét thị trường             │
    │     (hoặc dùng pairs cố định)          │
    │  5. Với mỗi pair:                       │
    │     → _analyze_market()                 │
    │       → Thu thập data (data_collector)  │
    │       → Chạy 4 strategies              │
    │       → Chạy AI Ensemble               │
    │     → signal_aggregator.aggregate()     │
    │     → _execute_signal()                 │
    │       → risk_manager.can_trade()        │
    │       → position_sizer tính size        │
    │       → Mở/đóng lệnh                  │
    │  6. _save_state() → DB                  │
    │  7. _log_performance()                  │
    └─────────────────────────────────────────┘
```

---

## 🔗 QUAN HỆ GIỮA CÁC MODULE

```
                    ┌─────────────┐
                    │ config/     │
                    │ settings    │
                    │ strategies  │
                    │ pairs       │
                    └──────┬──────┘
                           │ đọc
                           ▼
┌────────────────────────────────────────────────┐
│                  core/bot.py                    │
│              (TRUNG TÂM ĐIỀU KHIỂN)             │
│                                                │
│  Sở hữu và điều phối tất cả modules:          │
├────────────────────────────────────────────────┤
│                                                │
│  ┌──────────┐  ┌──────────┐  ┌──────────────┐ │
│  │ exchange  │  │ data_    │  │ scanner      │ │
│  │ connector │  │ collector│  │              │ │
│  │ (ccxt)   │  │          │  │              │ │
│  └────┬─────┘  └────┬─────┘  └──────┬───────┘ │
│       │              │               │         │
│  ┌────┴──────────────┴───────────────┘         │
│  │                                             │
│  ▼  Data flows to:                             │
│  ┌──────────────────────────────┐              │
│  │ strategies/ (4 chiến lược)   │              │
│  │ + ai/ (ML model + features)  │              │
│  └──────────┬───────────────────┘              │
│             │ signals                          │
│             ▼                                  │
│  ┌──────────────────────┐                      │
│  │ signal_aggregator    │                      │
│  │ (tổng hợp tín hiệu) │                      │
│  └──────────┬───────────┘                      │
│             │ final signal                     │
│             ▼                                  │
│  ┌──────────────────────┐  ┌───────────────┐   │
│  │ risk_manager         │  │ position_sizer│   │
│  │ (kiểm tra rủi ro)   │  │ (tính size)   │   │
│  └──────────┬───────────┘  └───────┬───────┘   │
│             │                      │           │
│             ▼                      ▼           │
│  ┌──────────────────────────────────┐          │
│  │ order_manager + exchange         │          │
│  │ (thực thi lệnh trên sàn)        │          │
│  └──────────────────────────────────┘          │
│                                                │
│  ┌──────────────────────────┐                  │
│  │ database/db_manager      │                  │
│  │ (lưu trades, signals,    │                  │
│  │  performance, bot_state) │                  │
│  └──────────────────────────┘                  │
│                                                │
│  ┌──────────────────────────┐                  │
│  │ ai/ollama_agent          │ ← Thread riêng   │
│  │ (phân tích vĩ mô,       │                  │
│  │  điều chỉnh bias)       │                  │
│  └──────────────────────────┘                  │
└────────────────────────────────────────────────┘
         │
         │ expose API
         ▼
┌─────────────────────┐
│ dashboard/app.py    │
│ (Flask REST API +   │
│  Web UI)            │
└─────────────────────┘
```

---

## 📊 CÁC THAM SỐ QUAN TRỌNG (HIỆN TẠI)

| Tham số | Giá trị | Ghi chú |
|---------|---------|---------|
| Mode | live | Hiển thị mode hiện tại trong `config/settings.yaml` |
| Market Type | futures | USDT-M Futures |
| Leverage | Động 1x–150x (mặc định tối đa 5x) | Trần chỉnh trên dashboard cho DEMO/LIVE; bot chọn theo tín hiệu và giới hạn Binance theo cặp/notional |
| Initial Capital | 21.87 USDC | Giá trị khởi tạo hiện lưu trong cấu hình |
| Max Risk/Trade | 2% | |
| Stop Loss | 4% | |
| Take Profit | 8% | |
| Max Open Positions | Tối đa 2 | Slot AI là gợi ý; slot thứ hai cần độ tin cậy, đồng thuận, xu hướng và biến động đạt điều kiện |
| Max Drawdown | 10% | |
| AI Confidence Threshold | 65% | |
| AI Retrain Interval | 24h | |
| Ollama Model | qwen2.5:14b | |
| Scan Pairs | 10 (dynamic) | |
| Timeframes | 1m, 5m, 15m | |

---

## 📋 LỊCH SỬ THAY ĐỔI

| Ngày | Thay đổi | Người thực hiện |
|------|----------|-----------------|
| 2026-09-29 | Audit toàn diện, phát hiện 31 issues | AI Auditor |
| 2026-09-29 | Viết lại sơ đồ cấu trúc chi tiết | AI Auditor |

---

> 💡 **GHI CHÚ CHO NGƯỜI NÂNG CẤP:**
> - File này PHẢI được cập nhật mỗi khi thay đổi cấu trúc, thêm module, hoặc sửa logic quan trọng.
> - Xem file `ai_knowledge_base.md` để biết lịch sử giao dịch và nhật ký AI.
> - Xem báo cáo audit để biết chi tiết các lỗi cần sửa.
