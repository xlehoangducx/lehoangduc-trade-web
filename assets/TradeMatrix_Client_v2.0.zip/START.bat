@echo off
reg add "HKCU\Console" /f /v "FaceName" /t REG_SZ /d "Consolas" >nul 2>&1
reg add "HKCU\Console" /f /v "CodePage" /t REG_DWORD /d 65001 >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "FaceName" /t REG_SZ /d "Consolas" >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "FontFamily" /t REG_DWORD /d 54 >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "FontSize" /t REG_DWORD /d 1048576 >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "CodePage" /t REG_DWORD /d 65001 >nul 2>&1
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONWARNINGS=ignore
title TRADEMATRIX QUANT CLIENT v2.0

cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" (
    echo [ERROR] Chua cai dat moi truong chay. Hay double-click chay file install.bat truoc!
    pause
    exit /b 1
)

if not exist "data" mkdir data
if not exist "data\historical" mkdir data\historical
if not exist "data\models" mkdir data\models
if not exist "logs" mkdir logs

w32tm /resync /nowait >nul 2>&1

echo.
echo  ======================================================
echo   TRADEMATRIX QUANT CLIENT v2.0 - Starting...
echo   Web Terminal: http://127.0.0.1:5000
echo   He thong giao dich tu dong Binance Futures
echo  ======================================================
echo.

powershell -NoProfile -Command "try { $r = Invoke-RestMethod -Uri 'http://127.0.0.1:5000/health' -TimeoutSec 2; if ($r.status -eq 'ok') { exit 0 } else { exit 1 } } catch { exit 1 }"
if not errorlevel 1 (
    echo Bot dashboard da chay san tai http://127.0.0.1:5000
    start "" "http://127.0.0.1:5000"
    exit /b 0
)

start "" "%~dp0loading.html"

:run_bot
if exist "run_web.pyc" (
    "venv\Scripts\python.exe" -X utf8 run_web.pyc
) else (
    "venv\Scripts\python.exe" -X utf8 run_web.py
)
if errorlevel 1 (
    echo [WARNING] Trade Bot vua dung bat thuong. Thu khoi dong lai sau 10 giay...
    timeout /t 10 /nobreak >nul
    goto run_bot
)

pause
