import sqlite3
import logging
import json
from typing import Dict, Any, List, Optional
import os
import contextlib

logger = logging.getLogger(__name__)

class DatabaseManager:
    """
    Lớp quản lý cơ sở dữ liệu SQLite cho bot.
    """
    def __init__(self, db_path: str = 'data/trade_bot.db'):
        self.db_path = db_path
        db_dir = os.path.dirname(self.db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        self.init_db()



    @contextlib.contextmanager
    def _get_connection(self):
        """Tạo kết nối tới SQLite (thread-safe, WAL mode)."""
        conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=10.0)
        conn.row_factory = sqlite3.Row
        # Kích hoạt WAL mode để hỗ trợ đọc/ghi đồng thời tốt hơn
        conn.execute('PRAGMA journal_mode=WAL;')
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def init_db(self):
        """Khởi tạo cấu trúc các bảng trong DB."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Bảng trades
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    symbol TEXT,
                    side TEXT,
                    type TEXT,
                    price REAL,
                    amount REAL,
                    cost REAL,
                    fee REAL,
                    pnl REAL,
                    strategy TEXT,
                    status TEXT,
                    order_id TEXT,
                    mode TEXT,
                    exchange_trade_id TEXT,
                    client_order_id TEXT,
                    position_side TEXT,
                    commission_asset TEXT,
                    realized_pnl REAL,
                    maker INTEGER,
                    raw_json TEXT
                )
                ''')

                trade_columns = {row[1] for row in cursor.execute('PRAGMA table_info(trades)')}
                for column, column_type in (
                    ('exchange_trade_id', 'TEXT'),
                    ('client_order_id', 'TEXT'),
                    ('position_side', 'TEXT'),
                    ('commission_asset', 'TEXT'),
                    ('realized_pnl', 'REAL'),
                    ('maker', 'INTEGER'),
                    ('raw_json', 'TEXT'),
                ):
                    if column not in trade_columns:
                        cursor.execute(f'ALTER TABLE trades ADD COLUMN {column} {column_type}')
                cursor.execute('''
                    CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_exchange_fill
                    ON trades(mode, symbol, exchange_trade_id)
                    WHERE exchange_trade_id IS NOT NULL AND exchange_trade_id != ''
                ''')
                
                # Bảng signals
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    symbol TEXT,
                    timeframe TEXT,
                    strategy TEXT,
                    signal_type TEXT,
                    confidence REAL,
                    indicators_json TEXT
                )
                ''')
                
                # Bảng performance
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS performance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT,
                    total_trades INTEGER,
                    winning_trades INTEGER,
                    losing_trades INTEGER,
                    total_pnl REAL,
                    win_rate REAL,
                    max_drawdown REAL,
                    balance REAL
                )
                ''')
                
                # Bảng bot_state
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS bot_state (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    mode TEXT,
                    balance REAL,
                    open_positions_json TEXT,
                    last_check INTEGER,
                    peak_balance REAL,
                    trade_count INTEGER,
                    initial_capital REAL
                )
                ''')

                cursor.execute('''
                CREATE TABLE IF NOT EXISTS symbol_cooldowns (
                    mode TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    expires_at REAL NOT NULL,
                    reason TEXT,
                    PRIMARY KEY (mode, symbol)
                )
                ''')

                # Migrate databases created before these restart-critical fields existed.
                existing_columns = {row[1] for row in cursor.execute('PRAGMA table_info(bot_state)')}
                for column, column_type in (
                    ('peak_balance', 'REAL'),
                    ('trade_count', 'INTEGER'),
                    ('initial_capital', 'REAL'),
                    ('pending_protection_cleanup_json', 'TEXT'),
                ):
                    if column not in existing_columns:
                        cursor.execute(f'ALTER TABLE bot_state ADD COLUMN {column} {column_type}')
                
                conn.commit()
                logger.info(f"Đã khởi tạo database tại {self.db_path}")
        except Exception as e:
            logger.error(f"Lỗi khởi tạo database: {str(e)}")

    def save_trade(self, trade_data: Dict[str, Any]) -> None:
        """Lưu bản ghi giao dịch (có kiểm tra chống trùng lặp trước khi INSERT để không làm nhảy AUTOINCREMENT ID)."""
        try:
            mode_val = trade_data.get('mode', 'live')
            symbol_val = trade_data.get('symbol')
            ex_trade_id = trade_data.get('exchange_trade_id')
            order_id_val = str(trade_data.get('order_id')) if trade_data.get('order_id') is not None else None
            status_val = trade_data.get('status')

            with self._get_connection() as conn:
                cursor = conn.cursor()
                if ex_trade_id:
                    exists = cursor.execute(
                        "SELECT 1 FROM trades WHERE mode = ? AND symbol = ? AND exchange_trade_id = ? LIMIT 1",
                        (mode_val, symbol_val, str(ex_trade_id)),
                    ).fetchone()
                    if exists:
                        return
                elif order_id_val and status_val == 'closed':
                    exists_closed = cursor.execute(
                        "SELECT id FROM trades WHERE mode = ? AND order_id = ? AND status = 'closed' AND exchange_trade_id IS NULL AND (pnl IS NOT NULL AND pnl != 0) LIMIT 1",
                        (mode_val, order_id_val),
                    ).fetchone()
                    if exists_closed:
                        return

                cursor.execute('''
                INSERT OR IGNORE INTO trades (
                    timestamp, symbol, side, type, price, amount, cost, fee, pnl,
                    strategy, status, order_id, mode, exchange_trade_id, client_order_id,
                    position_side, commission_asset, realized_pnl, maker, raw_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    trade_data.get('timestamp'), symbol_val, trade_data.get('side'),
                    trade_data.get('type'), trade_data.get('price'), trade_data.get('amount'),
                    trade_data.get('cost'), trade_data.get('fee'), trade_data.get('pnl'),
                    trade_data.get('strategy'), status_val, order_id_val,
                    mode_val, str(ex_trade_id) if ex_trade_id else None,
                    trade_data.get('client_order_id'), trade_data.get('position_side'),
                    trade_data.get('commission_asset'), trade_data.get('realized_pnl'),
                    None if trade_data.get('maker') is None else int(bool(trade_data.get('maker'))),
                    json.dumps(trade_data.get('raw', {}), ensure_ascii=False, default=str)
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Lỗi lưu trade: {str(e)}")

    def update_trade_status(self, order_id: str, status: str, pnl: Optional[float] = None) -> bool:
        """Cập nhật trạng thái lệnh trong trades theo order_id."""
        if not order_id:
            return False
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                if pnl is not None:
                    cursor.execute("UPDATE trades SET status = ?, pnl = ? WHERE order_id = ?", (status, float(pnl), str(order_id)))
                else:
                    cursor.execute("UPDATE trades SET status = ? WHERE order_id = ?", (status, str(order_id)))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Lỗi cập nhật trạng thái trade {order_id}: {str(e)}")
            return False

    def save_signal(self, signal_data: Dict[str, Any]) -> None:
        """Lưu bản ghi tín hiệu."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT INTO signals (timestamp, symbol, timeframe, strategy, signal_type, confidence, indicators_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    signal_data.get('timestamp'), signal_data.get('symbol'), signal_data.get('timeframe'),
                    signal_data.get('strategy'), signal_data.get('signal_type'), signal_data.get('confidence'),
                    json.dumps(signal_data.get('indicators', {}))
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Lỗi lưu signal: {str(e)}")

    def get_trades(self, mode: str = None, limit: int = 100, symbol: Optional[str] = None, start_date: Optional[int] = None, end_date: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
        """Lấy danh sách các giao dịch."""
        query = "SELECT * FROM trades WHERE 1=1"
        params = []
        if mode:
            query += " AND mode = ?"
            params.append(mode)
        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        if start_date:
            query += " AND timestamp >= ?"
            params.append(start_date)
        if end_date:
            query += " AND timestamp <= ?"
            params.append(end_date)

        query += """ AND NOT (
            mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
            AND EXISTS (
                SELECT 1 FROM trades AS fills
                WHERE fills.mode = trades.mode AND fills.order_id = trades.order_id
                    AND fills.exchange_trade_id IS NOT NULL
            )
        )"""
            
        query += " ORDER BY timestamp DESC, id DESC LIMIT ? OFFSET ?"
        params.extend((max(1, min(int(limit), 1000)), max(0, int(offset))))
        
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Lỗi lấy trades: {str(e)}")
        return []

    def get_trade_symbols(self, mode: str = None) -> List[str]:
        """Return known symbols so exchange history sync can include dynamically scanned markets."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                if mode:
                    cursor.execute(
                        "SELECT DISTINCT symbol FROM trades WHERE mode = ? AND symbol IS NOT NULL",
                        (mode,),
                    )
                else:
                    cursor.execute("SELECT DISTINCT symbol FROM trades WHERE symbol IS NOT NULL")
                return [str(row[0]) for row in cursor.fetchall() if row[0]]
        except Exception as e:
            logger.error(f"Lỗi lấy danh sách cặp đã giao dịch: {e}")
            return []

    def get_latest_trade_timestamp(self, mode: str, symbol: str) -> Optional[int]:
        try:
            with self._get_connection() as conn:
                row = conn.execute(
                    "SELECT MAX(timestamp) FROM trades WHERE mode = ? AND symbol = ?",
                    (mode, symbol),
                ).fetchone()
                return int(row[0]) if row and row[0] is not None else None
        except Exception as e:
            logger.error(f"Lỗi lấy mốc đồng bộ {symbol}: {e}")
            return None

    def get_latest_exchange_trade_timestamp(self, mode: str, symbol: str) -> Optional[int]:
        try:
            with self._get_connection() as conn:
                row = conn.execute(
                    "SELECT MAX(timestamp) FROM trades WHERE mode = ? AND symbol = ? AND exchange_trade_id IS NOT NULL",
                    (mode, symbol),
                ).fetchone()
                return int(row[0]) if row and row[0] is not None else None
        except Exception as e:
            logger.error(f"Lỗi lấy mốc fill Binance {symbol}: {e}")
            return None

    def get_total_net_pnl(self, mode: str, quote_currency: str) -> float:
        """Aggregate all fills and local trades for total PnL."""
        query = """
            SELECT COALESCE(SUM(
                CASE
                    WHEN realized_pnl IS NOT NULL THEN realized_pnl -
                        CASE WHEN commission_asset IS NULL OR commission_asset = ? THEN COALESCE(fee, 0) ELSE 0 END
                    WHEN status = 'open' THEN -COALESCE(fee, 0)
                    ELSE COALESCE(pnl, 0)
                END
            ), 0)
            FROM trades
            WHERE mode = ?
            AND NOT (
                mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
                AND EXISTS (
                    SELECT 1 FROM trades AS fills
                    WHERE fills.order_id = trades.order_id
                    AND fills.exchange_trade_id IS NOT NULL
                )
            )
        """
        try:
            with self._get_connection() as conn:
                row = conn.execute(query, (quote_currency, mode)).fetchone()
                return float(row[0] or 0)
        except Exception as e:
            logger.error(f"Lỗi tổng hợp Total PnL: {e}")
            return 0.0

    def get_daily_net_pnl(self, mode: str, start_timestamp: int, quote_currency: str) -> float:
        """Aggregate all fills and local trades for the daily-loss guard."""
        query = """
            SELECT COALESCE(SUM(
                CASE
                    WHEN realized_pnl IS NOT NULL THEN realized_pnl -
                        CASE WHEN commission_asset IS NULL OR commission_asset = ? THEN COALESCE(fee, 0) ELSE 0 END
                    WHEN status = 'open' THEN -COALESCE(fee, 0)
                    ELSE COALESCE(pnl, 0)
                END
            ), 0)
            FROM trades
            WHERE mode = ? AND timestamp >= ?
                AND NOT (
                    mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
                    AND EXISTS (
                        SELECT 1 FROM trades AS fills
                        WHERE fills.mode = trades.mode AND fills.order_id = trades.order_id
                            AND fills.exchange_trade_id IS NOT NULL
                    )
                )
        """
        try:
            with self._get_connection() as conn:
                row = conn.execute(query, (quote_currency, mode, int(start_timestamp))).fetchone()
                return float(row[0] or 0)
        except Exception as e:
            logger.error(f"Lỗi tổng hợp PnL trong ngày: {e}")
            return 0.0

    def get_performance_summary(self) -> Dict[str, Any]:
        """Lấy tổng quan hiệu suất."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM performance ORDER BY id DESC LIMIT 1")
                row = cursor.fetchone()
                if row:
                    return dict(row)
        except Exception as e:
            logger.error(f"Lỗi lấy hiệu suất: {str(e)}")
        return {}

    def save_performance(self, perf: Dict[str, Any]) -> None:
        """Lưu bản ghi hiệu suất ngày vào bảng performance."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT INTO performance (
                    date, total_trades, winning_trades, losing_trades,
                    total_pnl, win_rate, max_drawdown, balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    perf.get('date'),
                    int(perf.get('total_trades', 0) or 0),
                    int(perf.get('winning_trades', 0) or 0),
                    int(perf.get('losing_trades', 0) or 0),
                    float(perf.get('total_pnl', 0.0) or 0.0),
                    float(perf.get('win_rate', 0.0) or 0.0),
                    float(perf.get('max_drawdown', 0.0) or 0.0),
                    float(perf.get('balance', 0.0) or 0.0),
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Lỗi lưu hiệu suất: {str(e)}")

    def cleanup_old_data(self, days: int = 30) -> int:
        """Dọn dẹp các bản ghi signals và bot_state cũ để tối ưu dung lượng DB."""
        try:
            import time
            cutoff_ms = int((time.time() - max(1, int(days)) * 86400) * 1000)
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM signals WHERE timestamp IS NOT NULL AND timestamp < ?", (cutoff_ms,))
                deleted = cursor.rowcount or 0
                cursor.execute("DELETE FROM bot_state WHERE id NOT IN (SELECT id FROM bot_state ORDER BY id DESC LIMIT 200)")
                conn.commit()
                return deleted
        except Exception as e:
            logger.error(f"Lỗi dọn dẹp dữ liệu cũ: {str(e)}")
            return 0

    def save_bot_state(self, state: Dict[str, Any]) -> None:
        """Lưu trạng thái bot."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT INTO bot_state (
                    timestamp, mode, balance, open_positions_json, last_check,
                    peak_balance, trade_count, initial_capital, pending_protection_cleanup_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    state.get('timestamp'), state.get('mode'), state.get('balance'),
                    json.dumps(state.get('open_positions', [])), state.get('last_check'),
                    state.get('peak_balance'), state.get('trade_count'), state.get('initial_capital'),
                    json.dumps(state.get('pending_protection_cleanup', []))
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Lỗi lưu trạng thái bot: {str(e)}")

    def get_bot_state(self, mode: str = None) -> Dict[str, Any]:
        """Lấy trạng thái mới nhất của bot."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                if mode:
                    cursor.execute("SELECT * FROM bot_state WHERE mode = ? ORDER BY id DESC LIMIT 1", (mode,))
                else:
                    cursor.execute("SELECT * FROM bot_state ORDER BY id DESC LIMIT 1")
                row = cursor.fetchone()
                if row:
                    state = dict(row)
                    state['open_positions'] = json.loads(state['open_positions_json'] or '[]')
                    raw_pending = state.get('pending_protection_cleanup_json')
                    state['pending_protection_cleanup'] = json.loads(raw_pending) if raw_pending else []
                    return state
        except Exception as e:
            logger.error(f"Lỗi lấy trạng thái bot: {str(e)}")
        return {}

    def get_daily_pnl(
        self, days: int = 30, mode: str = None, quote_currency: str = 'USDT'
    ) -> List[Dict[str, Any]]:
        """Return daily net trade PnL, optionally isolated by mode."""
        query = """
            SELECT date(timestamp/1000, 'unixepoch') AS date_str,
                   SUM(CASE
                       WHEN realized_pnl IS NOT NULL THEN realized_pnl -
                           CASE WHEN commission_asset IS NULL OR commission_asset = ? THEN COALESCE(fee, 0) ELSE 0 END
                       WHEN status = 'open' THEN -
                           CASE WHEN commission_asset IS NULL OR commission_asset = ? THEN COALESCE(fee, 0) ELSE 0 END
                       ELSE COALESCE(pnl, 0)
                   END) AS daily_pnl
            FROM trades
            WHERE NOT (
                mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
                AND EXISTS (
                    SELECT 1 FROM trades AS fills
                    WHERE fills.mode = trades.mode AND fills.order_id = trades.order_id
                        AND fills.exchange_trade_id IS NOT NULL
                )
            )
        """
        params = [quote_currency, quote_currency]
        if mode:
            query += " AND mode = ?"
            params.append(mode)
        query += " GROUP BY date_str ORDER BY date_str DESC LIMIT ?"
        params.append(max(1, min(int(days), 365)))
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Lỗi lấy daily PnL: {str(e)}")
            return []

    def set_symbol_cooldown(self, mode: str, symbol: str, expires_at: float, reason: str = '') -> bool:
        """Persist a manual-exit cooldown so a restart cannot immediately re-enter."""
        try:
            with self._get_connection() as conn:
                if expires_at <= 0:
                    conn.execute(
                        'DELETE FROM symbol_cooldowns WHERE mode = ? AND symbol = ?',
                        (mode, symbol),
                    )
                else:
                    conn.execute('''
                        INSERT INTO symbol_cooldowns (mode, symbol, expires_at, reason)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(mode, symbol) DO UPDATE SET
                            expires_at = excluded.expires_at,
                            reason = excluded.reason
                    ''', (mode, symbol, float(expires_at), reason))
                conn.commit()
            return True
        except Exception as e:
            logger.error(f"Lỗi lưu cooldown {symbol}: {e}")
            return False

    def get_symbol_cooldowns(self, mode: str) -> Dict[str, float]:
        """Load active symbol cooldowns and remove expired entries."""
        import time
        now = time.time()
        try:
            with self._get_connection() as conn:
                conn.execute(
                    'DELETE FROM symbol_cooldowns WHERE mode = ? AND expires_at <= ?',
                    (mode, now),
                )
                rows = conn.execute(
                    'SELECT symbol, expires_at FROM symbol_cooldowns WHERE mode = ? AND expires_at > ?',
                    (mode, now),
                ).fetchall()
                conn.commit()
                return {str(row['symbol']): float(row['expires_at']) for row in rows}
        except Exception as e:
            logger.error(f"Lỗi đọc cooldown {mode}: {e}")
            return {}

    def clear_history(self, mode: str) -> bool:
        """Xóa trắng lịch sử giao dịch và hiệu suất cho một chế độ."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM trades WHERE mode = ?", (mode,))
                cursor.execute("DELETE FROM performance")
                cursor.execute("DELETE FROM bot_state WHERE mode = ?", (mode,))
                conn.commit()
            return True
        except Exception as e:
            logger.error(f"Lỗi xóa lịch sử {mode}: {str(e)}")
            return False
