import sqlite3
import logging
import json
from typing import Dict, Any, List, Optional, Tuple
import os
import contextlib

logger = logging.getLogger(__name__)

class DatabaseManager:
    """
    Lớp quản lý cơ sở dữ liệu SQLite cho bot.
    """

    @staticmethod
    def _deep_sanitize(obj: Any, max_depth: int = 5) -> Any:
        """Làm sạch triệt để mọi đối tượng DataFrame/Series/ndarrays/Set đa tầng trước khi json.dumps()"""
        if max_depth <= 0:
            return str(obj) if obj is not None else None
        if obj is None or isinstance(obj, (int, float, str, bool)):
            return obj
        # Pandas DataFrame / Series
        if hasattr(obj, 'to_dict'):
            return None
        # Numpy scalar / array / Index
        if hasattr(obj, 'tolist'):
            try:
                return DatabaseManager._deep_sanitize(obj.tolist(), max_depth - 1)
            except Exception:
                return None
        if isinstance(obj, dict):
            clean = {}
            for k, v in obj.items():
                if k in ('dfs', 'candles') or hasattr(v, 'to_dict'):
                    continue
                clean[str(k)] = DatabaseManager._deep_sanitize(v, max_depth - 1)
            return clean
        if isinstance(obj, (list, tuple, set)):
            return [DatabaseManager._deep_sanitize(x, max_depth - 1) for x in obj if not hasattr(x, 'to_dict')]
        return str(obj)

    def __init__(self, db_path: str = 'data/trade_bot.db'):
        self.db_path = db_path
        db_dir = os.path.dirname(self.db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        self.init_db()



    @contextlib.contextmanager
    def _get_ro_connection(self):
        """[BOM #121C]: Tạo kết nối SQLite chỉ đọc (PRAGMA query_only=ON, timeout=10s)."""
        if self.db_path != ':memory:' and os.path.exists(self.db_path):
            conn = sqlite3.connect(
                f"file:{self.db_path}?mode=ro", uri=True, check_same_thread=False, timeout=10.0
            )
        else:
            conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=10.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA query_only = ON;")
            yield conn
        finally:
            conn.close()

    @contextlib.contextmanager
    def _get_connection(self):
        """Tạo kết nối tới SQLite (thread-safe, WAL mode đã bật sẵn ở init_db)."""
        conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=10.0)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def init_db(self):
        """Khởi tạo cấu trúc các bảng trong DB."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('PRAGMA journal_mode=WAL;')
                
                # Bảng trades
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    symbol TEXT,
                    side TEXT,
                    type TEXT,
                    price REAL,
                    amount REAL,
                    cost REAL,
                    fee REAL,
                    pnl REAL,
                    strategy TEXT,
                    status TEXT,
                    order_id TEXT,
                    mode TEXT,
                    exchange_trade_id TEXT,
                    client_order_id TEXT,
                    position_side TEXT,
                    commission_asset TEXT,
                    realized_pnl REAL,
                    maker INTEGER,
                    raw_json TEXT,
                    close_reason TEXT
                )
                ''')

                trade_columns = {row[1] for row in cursor.execute('PRAGMA table_info(trades)')}
                for column, column_type in (
                    ('exchange_trade_id', 'TEXT'),
                    ('client_order_id', 'TEXT'),
                    ('position_side', 'TEXT'),
                    ('commission_asset', 'TEXT'),
                    ('realized_pnl', 'REAL'),
                    ('maker', 'INTEGER'),
                    ('raw_json', 'TEXT'),
                    ('close_reason', 'TEXT'),
                ):
                    if column not in trade_columns:
                        cursor.execute(f'ALTER TABLE trades ADD COLUMN {column} {column_type}')
                cursor.execute('''
                    CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_exchange_fill
                    ON trades(mode, symbol, exchange_trade_id)
                    WHERE exchange_trade_id IS NOT NULL AND exchange_trade_id != ''
                ''')
                
                # Bảng signals
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    symbol TEXT,
                    timeframe TEXT,
                    strategy TEXT,
                    signal_type TEXT,
                    confidence REAL,
                    indicators_json TEXT
                )
                ''')
                
                # Bảng performance
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS performance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT,
                    total_trades INTEGER,
                    winning_trades INTEGER,
                    losing_trades INTEGER,
                    total_pnl REAL,
                    win_rate REAL,
                    max_drawdown REAL,
                    balance REAL
                )
                ''')

                # [M10] Mỗi ngày chỉ 1 dòng/chế độ: thêm cột mode + unique index (date, mode)
                # để save_performance dùng UPSERT thay vì INSERT thuần (trước đây mỗi chu kỳ
                # 60 giây sinh thêm 1 dòng và LIVE/DEMO ghi đè lẫn nhau).
                perf_columns = {row[1] for row in cursor.execute('PRAGMA table_info(performance)')}
                if 'mode' not in perf_columns:
                    cursor.execute('ALTER TABLE performance ADD COLUMN mode TEXT')
                cursor.execute(
                    "UPDATE performance SET mode = 'live' WHERE mode IS NULL OR mode = ''"
                )
                cursor.execute('''
                    DELETE FROM performance
                    WHERE id NOT IN (SELECT MAX(id) FROM performance GROUP BY date, mode)
                ''')
                cursor.execute('''
                    CREATE UNIQUE INDEX IF NOT EXISTS idx_performance_date_mode
                    ON performance(date, mode)
                ''')
                
                # Bảng bot_state
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS bot_state (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    mode TEXT,
                    balance REAL,
                    open_positions_json TEXT,
                    last_check INTEGER,
                    peak_balance REAL,
                    trade_count INTEGER,
                    initial_capital REAL
                )
                ''')

                cursor.execute('''
                CREATE TABLE IF NOT EXISTS symbol_cooldowns (
                    mode TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    expires_at REAL NOT NULL,
                    reason TEXT,
                    PRIMARY KEY (mode, symbol)
                )
                ''')

                # Migrate databases created before these restart-critical fields existed.
                existing_columns = {row[1] for row in cursor.execute('PRAGMA table_info(bot_state)')}
                for column, column_type in (
                    ('peak_balance', 'REAL'),
                    ('trade_count', 'INTEGER'),
                    ('initial_capital', 'REAL'),
                    ('pending_protection_cleanup_json', 'TEXT'),
                    # [H6] Túi JSON chứa sổ vốn (net_deposits / capital_ledger /
                    # deposit_tran_ids / capital_baseline_version). Trước đây
                    # `save_bot_state()` chỉ ghi 9 cột cố định nên toàn bộ sổ vốn bị MẤT
                    # sau mỗi lần restart: `_deposit_tran_ids` rỗng -> lần đồng bộ kế tiếp
                    # cộng lại 7 ngày giao dịch TRANSFER từ Binance -> net_deposits bị
                    # nhân đôi, PnL phiên bị trừ oan.
                    ('extra_json', 'TEXT'),
                ):
                    if column not in existing_columns:
                        cursor.execute(f'ALTER TABLE bot_state ADD COLUMN {column} {column_type}')

                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_trades_mode_sym_oid
                    ON trades(mode, symbol, order_id)
                ''')
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_signals_ts
                    ON signals(timestamp)
                ''')

                conn.commit()
                logger.info(f"Đã khởi tạo database tại {self.db_path}")
        except Exception as e:
            logger.error(f"Lỗi khởi tạo database: {str(e)}")

    def save_trade(self, trade_data: Dict[str, Any]) -> bool:
        """Lưu bản ghi giao dịch (chống trùng lặp, trả True nếu thêm/cập nhật bản ghi mới)."""
        try:
            mode_val = trade_data.get('mode', 'live')
            symbol_val = str(trade_data.get('symbol') or '').split(':')[0]
            raw_side = trade_data.get('side')
            side_val = str(raw_side).strip().upper() if raw_side is not None and str(raw_side).strip() else None
            raw_pos_side = trade_data.get('position_side')
            pos_side_val = (
                str(raw_pos_side).strip().upper()
                if raw_pos_side is not None and str(raw_pos_side).strip()
                else 'BOTH'
            )
            ex_trade_id = trade_data.get('exchange_trade_id')
            order_id_val = str(trade_data.get('order_id')) if trade_data.get('order_id') is not None else None
            status_val = trade_data.get('status')
            close_reason_val = trade_data.get('close_reason')
            strategy_val = trade_data.get('strategy')
            generic_strats = {'', 'unknown', 'binance fill', 'aggregated', 'exchange_sync', 'manual'}

            _norm_sym_sql = "(CASE WHEN instr(symbol, ':') > 0 THEN substr(symbol, 1, instr(symbol, ':') - 1) ELSE symbol END)"
            with self._get_connection() as conn:
                cursor = conn.cursor()
                raw_dict = dict(trade_data.get('raw', {}) or {}) if isinstance(trade_data.get('raw'), dict) else {}
                # [BOM #107D + #124A FIX]: Kế thừa close_reason, strategy thật & metadata Vũ Khí từ bản ghi cùng order_id
                if order_id_val:
                    prior_row = cursor.execute(
                        f"SELECT close_reason, raw_json, strategy FROM trades WHERE mode = ? AND {_norm_sym_sql} = ? AND order_id = ? ORDER BY (exchange_trade_id IS NULL) DESC, id ASC LIMIT 1",
                        (mode_val, symbol_val, order_id_val),
                    ).fetchone()
                    if prior_row:
                        if not close_reason_val and prior_row[0]:
                            close_reason_val = prior_row[0]
                        prior_strat = str(prior_row[2] or '').strip()
                        cur_strat_l = str(strategy_val or '').strip().lower()
                        if prior_strat and prior_strat.lower() not in generic_strats and cur_strat_l in generic_strats:
                            strategy_val = prior_strat
                        if prior_row[1]:
                            try:
                                prior_raw = json.loads(prior_row[1]) if isinstance(prior_row[1], str) else prior_row[1]
                                if isinstance(prior_raw, dict):
                                    for _pk in ('weapon_id', 'weapon_code', 'whole_cycle_net', 'is_partial_tp1', 'close_reason'):
                                        if prior_raw.get(_pk) is not None and prior_raw.get(_pk) != '' and not raw_dict.get(_pk):
                                            raw_dict[_pk] = prior_raw[_pk]
                            except Exception:
                                pass
                if ex_trade_id:
                    exists = cursor.execute(
                        f"SELECT 1 FROM trades WHERE mode = ? AND {_norm_sym_sql} = ? AND exchange_trade_id = ? LIMIT 1",
                        (mode_val, symbol_val, str(ex_trade_id)),
                    ).fetchone()
                    if exists:
                        return False
                    # Khử trùng lặp PnL kép: Nếu đã có bản ghi tạm (do partial-sl ghi trước) với cùng order_id nhưng chưa có exchange_trade_id,
                    # cập nhật đè (UPSERT) thay vì tạo dòng mới để không làm nhân đôi số giao dịch và PnL!
                    if order_id_val:
                        existing_local = cursor.execute(
                            f"SELECT id, strategy FROM trades WHERE mode = ? AND {_norm_sym_sql} = ? AND order_id = ? AND exchange_trade_id IS NULL LIMIT 1",
                            (mode_val, symbol_val, order_id_val),
                        ).fetchone()
                        if existing_local:
                            existing_strat = str(existing_local[1] or '').strip()
                            incoming_strat = str(strategy_val or '').strip()
                            is_generic_existing = existing_strat.lower() in generic_strats
                            final_strat = (incoming_strat or 'Binance Fill') if is_generic_existing else existing_strat
                            cursor.execute('''
                                UPDATE trades SET
                                    timestamp = CASE WHEN ? IS NOT NULL AND ? > 0 THEN ? ELSE timestamp END,
                                    status = COALESCE(?, status),
                                    exchange_trade_id = ?,
                                    side = COALESCE(?, side),
                                    position_side = CASE WHEN position_side IS NULL OR position_side = '' OR (position_side = 'BOTH' AND ? IN ('LONG', 'SHORT')) THEN ? ELSE position_side END,
                                    price = ?,
                                    amount = ?,
                                    cost = ?,
                                    fee = ?,
                                    pnl = ?,
                                    realized_pnl = ?,
                                    strategy = ?,
                                    commission_asset = ?,
                                    maker = ?,
                                    raw_json = ?,
                                    close_reason = COALESCE(?, close_reason)
                                WHERE id = ?
                            ''', (
                                trade_data.get('timestamp'),
                                trade_data.get('timestamp'),
                                trade_data.get('timestamp'),
                                status_val,
                                str(ex_trade_id),
                                side_val,
                                pos_side_val,
                                pos_side_val,
                                trade_data.get('price'),
                                trade_data.get('amount'),
                                trade_data.get('cost'),
                                trade_data.get('fee'),
                                trade_data.get('pnl'),
                                trade_data.get('realized_pnl'),
                                final_strat,
                                trade_data.get('commission_asset'),
                                None if trade_data.get('maker') is None else int(bool(trade_data.get('maker'))),
                                json.dumps(raw_dict, ensure_ascii=False, default=str),
                                close_reason_val,
                                existing_local[0]
                            ))
                            conn.commit()
                            return True
                elif order_id_val and status_val == 'closed':
                    exists_closed = cursor.execute(
                        f"SELECT id FROM trades WHERE mode = ? AND {_norm_sym_sql} = ? AND order_id = ? AND status = 'closed' AND exchange_trade_id IS NULL AND (pnl IS NOT NULL AND pnl != 0) LIMIT 1",
                        (mode_val, symbol_val, order_id_val),
                    ).fetchone()
                    if exists_closed:
                        return False

                cursor.execute('''
                INSERT OR IGNORE INTO trades (
                    timestamp, symbol, side, type, price, amount, cost, fee, pnl,
                    strategy, status, order_id, mode, exchange_trade_id, client_order_id,
                    position_side, commission_asset, realized_pnl, maker, raw_json, close_reason
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    trade_data.get('timestamp'), symbol_val, side_val,
                    trade_data.get('type'), trade_data.get('price'), trade_data.get('amount'),
                    trade_data.get('cost'), trade_data.get('fee'), trade_data.get('pnl'),
                    strategy_val, status_val, order_id_val,
                    mode_val, str(ex_trade_id) if ex_trade_id else None,
                    trade_data.get('client_order_id'), pos_side_val,
                    trade_data.get('commission_asset'), trade_data.get('realized_pnl'),
                    None if trade_data.get('maker') is None else int(bool(trade_data.get('maker'))),
                    json.dumps(raw_dict, ensure_ascii=False, default=str),
                    close_reason_val
                ))
                inserted = bool(cursor.rowcount and cursor.rowcount > 0)
                conn.commit()
                return inserted
        except Exception as e:
            logger.error(f"Lỗi lưu trade: {str(e)}")
            return False

    def update_trade_close_reason(self, mode: str, symbol: str, order_id: str, close_reason: str) -> int:
        """Apply an order-level close audit to every exchange fill for that order."""
        if not mode or not symbol or not order_id or not close_reason:
            return 0
        symbol_val = str(symbol).split(':')[0]
        _norm_sym_sql = "(CASE WHEN instr(symbol, ':') > 0 THEN substr(symbol, 1, instr(symbol, ':') - 1) ELSE symbol END)"
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    f"UPDATE trades SET close_reason = ? WHERE mode = ? AND {_norm_sym_sql} = ? AND order_id = ?",
                    (str(close_reason), str(mode), symbol_val, str(order_id)),
                )
                conn.commit()
                return int(cursor.rowcount or 0)
        except Exception as e:
            logger.error("Lỗi cập nhật close_reason %s %s: %s", symbol_val, order_id, e)
            return 0

    def update_trade_status(self, order_id: str, status: str, pnl: Optional[float] = None,
                            mode: Optional[str] = None, symbol: Optional[str] = None) -> bool:
        """Cập nhật trạng thái lệnh trong trades theo order_id (khoanh vùng theo mode/symbol).

        [SỬA LỖI GỐC RỄ - CẬP NHẬT XUYÊN CHẾ ĐỘ & HAI ĐỊNH NGHĨA PNL]
        Trước đây mệnh đề WHERE chỉ có `order_id`, trong khi `OrderManager.check_orders()`
        lấy TOÀN BỘ lệnh đang mở của cả hai chế độ (`get_trades()` không lọc mode). Một
        order_id của DEMO có thể ghi đè trạng thái + PnL của bản ghi LIVE cùng order_id, hoặc
        ghi đè nhầm dòng entry đang mở. Nay nhận thêm `mode`/`symbol` để giới hạn phạm vi.

        Đồng thời chỉ điền `pnl` khi `realized_pnl` còn trống: `realized_pnl` là số liệu gốc
        của sàn và là nguồn duy nhất cho mọi phép tổng hợp PnL; ghi thêm `pnl` bằng nguồn khác
        sẽ tạo ra hai định nghĩa PnL lệch nhau ngay trong cùng một bảng.
        """
        if not order_id:
            return False
        conditions = ["order_id = ?"]
        params: List[Any] = [str(order_id)]
        if mode:
            conditions.append("mode = ?")
            params.append(str(mode))
        if symbol:
            conditions.append("(CASE WHEN instr(symbol, ':') > 0 THEN substr(symbol, 1, instr(symbol, ':') - 1) ELSE symbol END) = ?")
            params.append(str(symbol).split(':')[0])
        where_clause = " AND ".join(conditions)
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                if pnl is not None:
                    cursor.execute(
                        f"UPDATE trades SET status = ?, "
                        f"pnl = CASE WHEN realized_pnl IS NULL THEN ? ELSE pnl END "
                        f"WHERE {where_clause}",
                        (status, float(pnl), *params),
                    )
                else:
                    cursor.execute(
                        f"UPDATE trades SET status = ? WHERE {where_clause}",
                        (status, *params),
                    )
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Lỗi cập nhật trạng thái trade {order_id}: {str(e)}")
            return False

    def save_signal(self, signal_data: Dict[str, Any]) -> None:
        """Lưu bản ghi tín hiệu (tự động làm sạch các object nặng/DataFrame)."""
        try:
            raw_ind = signal_data.get('indicators', {})
            # Làm sạch triệt để đa tầng: loại bỏ 'dfs', DataFrames nến, Series, ndarrays để chống phình DB
            clean_ind = self._deep_sanitize(raw_ind)

            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT INTO signals (timestamp, symbol, timeframe, strategy, signal_type, confidence, indicators_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    signal_data.get('timestamp'), signal_data.get('symbol'), signal_data.get('timeframe'),
                    signal_data.get('strategy'), signal_data.get('signal_type'), signal_data.get('confidence'),
                    json.dumps(clean_ind, ensure_ascii=False, default=str)
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Lỗi lưu signal: {str(e)}")

    def get_trades(self, mode: str = None, limit: int = 100, symbol: Optional[str] = None, start_date: Optional[int] = None, end_date: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
        """Lấy danh sách các giao dịch."""
        query = "SELECT * FROM trades WHERE 1=1"
        params = []
        if mode:
            query += " AND mode = ?"
            params.append(mode)
        if symbol:
            norm_sym = str(symbol).split(':')[0]
            query += " AND (CASE WHEN instr(symbol, ':') > 0 THEN substr(symbol, 1, instr(symbol, ':') - 1) ELSE symbol END) = ?"
            params.append(norm_sym)
        if start_date:
            query += " AND timestamp >= ?"
            params.append(start_date)
        if end_date:
            query += " AND timestamp <= ?"
            params.append(end_date)

        query += """ AND NOT (
            mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
            AND EXISTS (
                SELECT 1 FROM trades AS fills
                WHERE fills.mode = trades.mode
                    AND (CASE WHEN instr(fills.symbol, ':') > 0 THEN substr(fills.symbol, 1, instr(fills.symbol, ':') - 1) ELSE fills.symbol END)
                        = (CASE WHEN instr(trades.symbol, ':') > 0 THEN substr(trades.symbol, 1, instr(trades.symbol, ':') - 1) ELSE trades.symbol END)
                    AND fills.order_id = trades.order_id
                    AND fills.exchange_trade_id IS NOT NULL
            )
        )"""
            
        query += " ORDER BY timestamp DESC, id DESC LIMIT ? OFFSET ?"
        params.extend((max(1, min(int(limit), 1000)), max(0, int(offset))))
        
        try:
            with self._get_ro_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Lỗi lấy trades: {str(e)}")
        return []

    def get_trade_watermark(self, mode: str) -> Tuple[int, int]:
        """Return (count, max_id) for fast cache validation without scanning rows."""
        try:
            with self._get_ro_connection() as conn:
                row = conn.execute(
                    "SELECT COUNT(*), COALESCE(MAX(id), 0) FROM trades WHERE mode = ?",
                    (mode,),
                ).fetchone()
                if row:
                    return int(row[0] or 0), int(row[1] or 0)
        except Exception as e:
            logger.debug(f"Lỗi lấy watermark trades ({mode}): {e}")
        return (0, 0)

    def get_trade_symbols(self, mode: str = None) -> List[str]:
        """Return known symbols so exchange history sync can include dynamically scanned markets."""
        try:
            with self._get_ro_connection() as conn:
                cursor = conn.cursor()
                if mode:
                    cursor.execute(
                        "SELECT DISTINCT symbol FROM trades WHERE mode = ? AND symbol IS NOT NULL",
                        (mode,),
                    )
                else:
                    cursor.execute("SELECT DISTINCT symbol FROM trades WHERE symbol IS NOT NULL")
                return [str(row[0]) for row in cursor.fetchall() if row[0]]
        except Exception as e:
            logger.error(f"Lỗi lấy danh sách cặp đã giao dịch: {e}")
            return []

    def get_latest_exchange_trade_timestamp(self, mode: str, symbol: str) -> Optional[int]:
        try:
            norm_sym = str(symbol or '').split(':')[0]
            with self._get_ro_connection() as conn:
                row = conn.execute(
                    "SELECT MAX(timestamp) FROM trades WHERE mode = ? AND (CASE WHEN instr(symbol, ':') > 0 THEN substr(symbol, 1, instr(symbol, ':') - 1) ELSE symbol END) = ? AND exchange_trade_id IS NOT NULL",
                    (mode, norm_sym),
                ).fetchone()
                return int(row[0]) if row and row[0] is not None else None
        except Exception as e:
            logger.error(f"Lỗi lấy mốc fill Binance {symbol}: {e}")
            return None

    def _query_total_net_pnl(self, conn, mode: str, quote_currency: str) -> float:
        query = """
            SELECT COALESCE(SUM(
                CASE
                    WHEN realized_pnl IS NOT NULL THEN realized_pnl -
                        CASE WHEN commission_asset IS NULL OR UPPER(commission_asset) = UPPER(?) THEN COALESCE(fee, 0) ELSE 0 END
                    WHEN status = 'open' THEN 
                        CASE WHEN commission_asset IS NULL OR UPPER(commission_asset) = UPPER(?) THEN -COALESCE(fee, 0) ELSE 0 END
                    ELSE COALESCE(pnl, 0)
                END
            ), 0)
            FROM trades
            WHERE mode = ?
            AND NOT (
                mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
                AND EXISTS (
                    SELECT 1 FROM trades AS fills
                    WHERE fills.mode = trades.mode
                    AND (CASE WHEN instr(fills.symbol, ':') > 0 THEN substr(fills.symbol, 1, instr(fills.symbol, ':') - 1) ELSE fills.symbol END)
                        = (CASE WHEN instr(trades.symbol, ':') > 0 THEN substr(trades.symbol, 1, instr(trades.symbol, ':') - 1) ELSE trades.symbol END)
                    AND fills.order_id = trades.order_id
                    AND fills.exchange_trade_id IS NOT NULL
                )
            )
        """
        row = conn.execute(query, (quote_currency, quote_currency, mode)).fetchone()
        return float(row[0] or 0)

    def get_total_net_pnl(self, mode: str, quote_currency: str) -> float:
        """Aggregate all fills and local trades for total PnL."""
        try:
            with self._get_ro_connection() as conn:
                return self._query_total_net_pnl(conn, mode, quote_currency)
        except Exception as e:
            logger.error(f"Lỗi tổng hợp Total PnL: {e}")
            return 0.0

    def get_daily_net_pnl(self, mode: str, start_timestamp: int, quote_currency: str) -> Optional[float]:
        """Aggregate daily PnL; return None when the guard cannot read the database."""
        query = """
            SELECT COALESCE(SUM(
                CASE
                    WHEN realized_pnl IS NOT NULL THEN realized_pnl -
                        CASE WHEN commission_asset IS NULL OR UPPER(commission_asset) = UPPER(?) THEN COALESCE(fee, 0) ELSE 0 END
                    WHEN status = 'open' THEN 
                        CASE WHEN commission_asset IS NULL OR UPPER(commission_asset) = UPPER(?) THEN -COALESCE(fee, 0) ELSE 0 END
                    ELSE COALESCE(pnl, 0)
                END
            ), 0)
            FROM trades
            WHERE mode = ? AND timestamp >= ?
                AND NOT (
                    mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
                    AND EXISTS (
                        SELECT 1 FROM trades AS fills
                        WHERE fills.mode = trades.mode
                            AND (CASE WHEN instr(fills.symbol, ':') > 0 THEN substr(fills.symbol, 1, instr(fills.symbol, ':') - 1) ELSE fills.symbol END)
                                = (CASE WHEN instr(trades.symbol, ':') > 0 THEN substr(trades.symbol, 1, instr(trades.symbol, ':') - 1) ELSE trades.symbol END)
                            AND fills.order_id = trades.order_id
                            AND fills.exchange_trade_id IS NOT NULL
                    )
                )
        """
        try:
            with self._get_ro_connection() as conn:
                row = conn.execute(query, (quote_currency, quote_currency, mode, int(start_timestamp))).fetchone()
                return float(row[0] or 0)
        except Exception as e:
            logger.error(f"Lỗi tổng hợp PnL trong ngày: {e}")
            return None

    def get_performance_summary(self, mode: str = 'live', quote_currency: str = 'USDT') -> Dict[str, Any]:
        """Tổng hợp hiệu suất thực tế từ bảng trades (orders đóng) thay vì chỉ đọc lại bảng performance."""
        try:
            with self._get_ro_connection() as conn:
                cursor = conn.cursor()
                query = """
                    WITH closed_orders AS (
                        SELECT 
                            CASE WHEN instr(symbol, ':') > 0 THEN substr(symbol, 1, instr(symbol, ':') - 1) ELSE symbol END AS norm_symbol,
                            COALESCE(order_id, CAST(id AS TEXT)) AS grp_order_id,
                            SUM(
                                CASE 
                                    WHEN realized_pnl IS NOT NULL THEN realized_pnl - 
                                        CASE WHEN commission_asset IS NULL OR UPPER(commission_asset) = UPPER(?) THEN COALESCE(fee, 0) ELSE 0 END
                                    ELSE COALESCE(pnl, 0)
                                END
                            ) AS net_pnl
                        FROM trades
                        WHERE mode = ?
                          AND (
                              (exchange_trade_id IS NOT NULL AND (
                                  (realized_pnl IS NOT NULL AND ABS(realized_pnl) > 1e-12)
                                  OR (close_reason IS NOT NULL AND TRIM(close_reason) != '')
                              ))
                              OR (exchange_trade_id IS NULL AND status = 'closed' AND pnl IS NOT NULL AND (
                                  ABS(pnl) > 1e-12
                                  OR (close_reason IS NOT NULL AND TRIM(close_reason) != '')
                                  OR mode != 'live'
                              ))
                          )
                          AND NOT (
                              exchange_trade_id IS NULL AND order_id IS NOT NULL
                              AND EXISTS (
                                  SELECT 1 FROM trades AS fills 
                                  WHERE fills.mode = trades.mode
                                    AND (CASE WHEN instr(fills.symbol, ':') > 0 THEN substr(fills.symbol, 1, instr(fills.symbol, ':') - 1) ELSE fills.symbol END)
                                        = (CASE WHEN instr(trades.symbol, ':') > 0 THEN substr(trades.symbol, 1, instr(trades.symbol, ':') - 1) ELSE trades.symbol END)
                                    AND fills.order_id = trades.order_id 
                                    AND fills.exchange_trade_id IS NOT NULL
                              )
                          )
                        GROUP BY norm_symbol, grp_order_id
                    )
                    SELECT 
                        COUNT(*) AS total_closed_orders,
                        SUM(CASE WHEN net_pnl > 0.00001 THEN 1 ELSE 0 END) AS wins,
                        SUM(CASE WHEN net_pnl < -0.00001 THEN 1 ELSE 0 END) AS losses,
                        SUM(CASE WHEN ABS(net_pnl) <= 0.00001 THEN 1 ELSE 0 END) AS evens,
                        COALESCE(SUM(net_pnl), 0.0) AS total_realized_pnl,
                        COALESCE(SUM(CASE WHEN net_pnl > 0.00001 THEN net_pnl ELSE 0 END), 0.0) AS gross_profit,
                        COALESCE(SUM(CASE WHEN net_pnl < -0.00001 THEN ABS(net_pnl) ELSE 0 END), 0.0) AS gross_loss
                    FROM closed_orders
                """
                row = cursor.execute(query, (quote_currency, mode)).fetchone()
                if row:
                    total = int(row['total_closed_orders'] or 0)
                    wins = int(row['wins'] or 0)
                    losses = int(row['losses'] or 0)
                    evens = int(row['evens'] or 0)
                    tot_pnl = float(row['total_realized_pnl'] or 0.0)
                    full_net_pnl = self._query_total_net_pnl(conn, mode, quote_currency)
                    if abs(full_net_pnl) > 1e-12 or total > 0:
                        tot_pnl = full_net_pnl
                    gross_profit = float(row['gross_profit'] or 0.0)
                    gross_loss = float(row['gross_loss'] or 0.0)
                    win_rate = (wins / total * 100.0) if total > 0 else 0.0
                    profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else (999.0 if gross_profit > 0 else 1.0)
                    avg_win = (gross_profit / wins) if wins > 0 else 0.0
                    avg_loss = (gross_loss / losses) if losses > 0 else 0.0
                    payoff = (avg_win / avg_loss) if avg_loss > 0 else (avg_win if avg_win > 0 else 1.0)
                    
                    return {
                        'total_trades': total,
                        'winning_trades': wins,
                        'losing_trades': losses,
                        'even_trades': evens,
                        'total_pnl': tot_pnl,
                        'gross_profit': gross_profit,
                        'gross_loss': gross_loss,
                        'win_rate': round(win_rate, 2),
                        'profit_factor': round(profit_factor, 2),
                        'payoff_ratio': round(payoff, 2),
                    }
        except Exception as e:
            logger.error(f"Lỗi lấy hiệu suất tổng hợp: {str(e)}")
        return {
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'even_trades': 0,
            'total_pnl': 0.0,
            'win_rate': 0.0,
            'profit_factor': 1.0,
            'payoff_ratio': 1.0,
        }

    def save_performance(self, perf: Dict[str, Any]) -> None:
        """Ghi đè bản ghi hiệu suất của ngày (mỗi ngày 1 dòng, tách theo mode).

        [SỬA LỖI GỐC RỄ - PHÌNH BẢNG & GHI ĐÈ CHÉO CHẾ ĐỘ]
        Trước đây hàm này INSERT thuần nên mỗi chu kỳ 60 giây lại sinh một dòng mới cho
        cùng một ngày (hàng nghìn dòng/ngày, chỉ cắt bớt khi vượt 500 dòng ở cleanup), và
        bảng `performance` không có cột `mode` nên số liệu LIVE và DEMO ghi đè lẫn nhau.
        Nay dùng UPSERT theo (date, mode) với unique index, giữ đúng 1 dòng/ngày/chế độ.
        """
        perf_date = perf.get('date')
        mode_val = str(perf.get('mode') or 'live')
        if not perf_date:
            logger.warning("Bỏ qua lưu performance: thiếu ngày.")
            return
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT INTO performance (
                    date, mode, total_trades, winning_trades, losing_trades,
                    total_pnl, win_rate, max_drawdown, balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(date, mode) DO UPDATE SET
                    total_trades = excluded.total_trades,
                    winning_trades = excluded.winning_trades,
                    losing_trades = excluded.losing_trades,
                    total_pnl = excluded.total_pnl,
                    win_rate = excluded.win_rate,
                    max_drawdown = excluded.max_drawdown,
                    balance = excluded.balance
                ''', (
                    perf_date,
                    mode_val,
                    int(perf.get('total_trades', 0) or 0),
                    int(perf.get('winning_trades', 0) or 0),
                    int(perf.get('losing_trades', 0) or 0),
                    float(perf.get('total_pnl', 0.0) or 0.0),
                    float(perf.get('win_rate', 0.0) or 0.0),
                    float(perf.get('max_drawdown', 0.0) or 0.0),
                    float(perf.get('balance', 0.0) or 0.0),
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Lỗi lưu hiệu suất: {str(e)}")

    def cleanup_old_data(self, days: int = 30, mode: Optional[str] = None) -> int:
        """Dọn dẹp các bản ghi signals, bot_state và performance cũ (tách riêng theo từng mode)."""
        try:
            import time
            cutoff_ms = int((time.time() - max(1, int(days)) * 86400) * 1000)
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM signals WHERE timestamp IS NOT NULL AND timestamp < ?", (cutoff_ms,))
                deleted = cursor.rowcount or 0
                if mode:
                    cursor.execute(
                        "DELETE FROM bot_state WHERE mode = ? AND id NOT IN (SELECT id FROM bot_state WHERE mode = ? ORDER BY id DESC LIMIT 200)",
                        (mode, mode),
                    )
                    cursor.execute(
                        "DELETE FROM performance WHERE mode = ? AND id NOT IN (SELECT id FROM performance WHERE mode = ? ORDER BY id DESC LIMIT 500)",
                        (mode, mode),
                    )
                else:
                    cursor.execute(
                        "DELETE FROM bot_state WHERE id NOT IN (SELECT b2.id FROM bot_state b2 WHERE b2.mode IS bot_state.mode ORDER BY b2.id DESC LIMIT 200)"
                    )
                    cursor.execute(
                        "DELETE FROM performance WHERE id NOT IN (SELECT p2.id FROM performance p2 WHERE p2.mode IS performance.mode ORDER BY p2.id DESC LIMIT 500)"
                    )
                conn.commit()
                return deleted
        except Exception as e:
            logger.error(f"Lỗi dọn dẹp dữ liệu cũ: {str(e)}")
            return 0

    def save_bot_state(self, state: Dict[str, Any]) -> None:
        """Lưu trạng thái bot."""
        # Các cột đã có sẵn trong schema bot_state.
        fixed_columns = {
            'timestamp', 'mode', 'balance', 'open_positions_json', 'last_check',
            'peak_balance', 'trade_count', 'initial_capital',
            'pending_protection_cleanup_json', 'extra_json', 'id',
            'open_positions', 'pending_protection_cleanup',
        }
        # [H6] Mọi trường phi-schema (sổ vốn nạp/rút, mốc phiên bản vốn gốc, danh sách
        # tranId đã cộng) được đóng gói vào extra_json để KHÔNG mất khi restart.
        extra = {}
        for key, value in (state or {}).items():
            if key in fixed_columns:
                continue
            try:
                json.dumps(value)
            except (TypeError, ValueError) as ser_err:
                logger.debug("Bỏ qua trường extra không thể JSON hóa (%s): %s", key, ser_err)
                continue
            extra[key] = value
        extra_json = json.dumps(extra, ensure_ascii=False) if extra else None
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT INTO bot_state (
                    timestamp, mode, balance, open_positions_json, last_check,
                    peak_balance, trade_count, initial_capital, pending_protection_cleanup_json,
                    extra_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    state.get('timestamp'), state.get('mode'), state.get('balance'),
                    json.dumps(state.get('open_positions', []), ensure_ascii=False, default=str), state.get('last_check'),
                    state.get('peak_balance'), state.get('trade_count'), state.get('initial_capital'),
                    json.dumps(state.get('pending_protection_cleanup', []), ensure_ascii=False, default=str),
                    extra_json,
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Lỗi lưu trạng thái bot: {str(e)}")

    def get_bot_state(self, mode: str = None) -> Dict[str, Any]:
        """Lấy trạng thái mới nhất của bot."""
        try:
            with self._get_ro_connection() as conn:
                cursor = conn.cursor()
                if mode:
                    cursor.execute("SELECT * FROM bot_state WHERE mode = ? ORDER BY id DESC LIMIT 1", (mode,))
                else:
                    cursor.execute("SELECT * FROM bot_state ORDER BY id DESC LIMIT 1")
                row = cursor.fetchone()
                if row:
                    state = dict(row)
                    state['open_positions'] = json.loads(state['open_positions_json'] or '[]')
                    raw_pending = state.get('pending_protection_cleanup_json')
                    state['pending_protection_cleanup'] = json.loads(raw_pending) if raw_pending else []
                    # [H6] Bung túi JSON chứa sổ vốn nạp/rút đã lưu kèm trạng thái.
                    raw_extra = state.get('extra_json')
                    if raw_extra:
                        try:
                            extra = json.loads(raw_extra)
                        except (TypeError, ValueError):
                            extra = None
                        if isinstance(extra, dict):
                            for extra_key, extra_value in extra.items():
                                state.setdefault(extra_key, extra_value)
                    return state
        except Exception as e:
            logger.error(f"Lỗi lấy trạng thái bot: {str(e)}")
        return {}

    def get_daily_pnl(
        self, days: int = 30, mode: str = None, quote_currency: str = 'USDT'
    ) -> List[Dict[str, Any]]:
        """Return daily net trade PnL, optionally isolated by mode."""
        query = """
            SELECT date(timestamp/1000, 'unixepoch', '+7 hours') AS date_str,
                   SUM(CASE
                       WHEN realized_pnl IS NOT NULL THEN realized_pnl -
                           CASE WHEN commission_asset IS NULL OR UPPER(commission_asset) = UPPER(?) THEN COALESCE(fee, 0) ELSE 0 END
                       WHEN status = 'open' THEN -
                           CASE WHEN commission_asset IS NULL OR UPPER(commission_asset) = UPPER(?) THEN COALESCE(fee, 0) ELSE 0 END
                       ELSE COALESCE(pnl, 0)
                   END) AS daily_pnl
            FROM trades
            WHERE NOT (
                mode = 'live' AND exchange_trade_id IS NULL AND order_id IS NOT NULL
                AND EXISTS (
                    SELECT 1 FROM trades AS fills
                    WHERE fills.mode = trades.mode
                        AND (CASE WHEN instr(fills.symbol, ':') > 0 THEN substr(fills.symbol, 1, instr(fills.symbol, ':') - 1) ELSE fills.symbol END)
                            = (CASE WHEN instr(trades.symbol, ':') > 0 THEN substr(trades.symbol, 1, instr(trades.symbol, ':') - 1) ELSE trades.symbol END)
                        AND fills.order_id = trades.order_id
                        AND fills.exchange_trade_id IS NOT NULL
                )
            )
        """
        params = [quote_currency, quote_currency]
        if mode:
            query += " AND mode = ?"
            params.append(mode)
        query += " GROUP BY date_str ORDER BY date_str DESC LIMIT ?"
        params.append(max(1, min(int(days), 365)))
        try:
            with self._get_ro_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Lỗi lấy daily PnL: {str(e)}")
            return []

    def set_symbol_cooldown(self, mode: str, symbol: str, expires_at: float, reason: str = '') -> bool:
        """Persist a manual-exit cooldown so a restart cannot immediately re-enter."""
        try:
            with self._get_connection() as conn:
                if expires_at <= 0:
                    conn.execute(
                        'DELETE FROM symbol_cooldowns WHERE mode = ? AND symbol = ?',
                        (mode, symbol),
                    )
                else:
                    conn.execute('''
                        INSERT INTO symbol_cooldowns (mode, symbol, expires_at, reason)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(mode, symbol) DO UPDATE SET
                            expires_at = excluded.expires_at,
                            reason = excluded.reason
                    ''', (mode, symbol, float(expires_at), reason))
                conn.commit()
            return True
        except Exception as e:
            logger.error(f"Lỗi lưu cooldown {symbol}: {e}")
            return False

    def get_symbol_cooldowns(self, mode: str) -> Dict[str, float]:
        """Load active symbol cooldowns (read-only query)."""
        import time
        now = time.time()
        try:
            with self._get_ro_connection() as conn:
                rows = conn.execute(
                    'SELECT symbol, expires_at FROM symbol_cooldowns WHERE mode = ? AND expires_at > ?',
                    (mode, now),
                ).fetchall()
                return {str(row['symbol']): float(row['expires_at']) for row in rows}
        except Exception as e:
            logger.error(f"Lỗi đọc cooldown {mode}: {e}")
            return {}

    def clear_history(self, mode: str) -> bool:
        """Xóa trắng lịch sử giao dịch và hiệu suất cho một chế độ."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM trades WHERE mode = ?", (mode,))
                cursor.execute("DELETE FROM performance WHERE mode = ?", (mode,))
                cursor.execute("DELETE FROM bot_state WHERE mode = ?", (mode,))
                conn.commit()
            return True
        except Exception as e:
            logger.error(f"Lỗi xóa lịch sử {mode}: {str(e)}")
            return False
