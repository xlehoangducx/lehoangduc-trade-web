# CẨM NANG VẬN HÀNH TÁC CHIẾN HẰNG NGÀY (DAILY PLAYBOOK)
> **Quy trình chuẩn mực để vận hành hệ thống TradeMatrix qua 3 phiên chat chuyên trách trên Antigravity IDE.**

---

## 🎯 1. TẠI SAO BẠN KHÔNG CẦN COPY-PASTE PROMPT DÀI NỮA?
Tệp [`AGENTS.md`](file:///d:/TRADE/AGENTS.md) và [`GEMINI.md`](file:///d:/TRADE/GEMINI.md) đã được tinh gọn thành **Bản Hiến Pháp Tinh Gọn (< 15KB)**. Mỗi khi bạn mở bất kỳ phiên chat nào trong Antigravity, hệ thống sẽ **tự động nạp 100% quy tắc và tôn chỉ** mà không bị cắt cụt (0% Truncation)!

---

## 🏛️ 2. QUY TRÌNH 3 PHIÊN CHAT CHUYÊN TRÁCH

Bạn hãy tạo sẵn 3 phiên chat ở thanh menu bên trái (Sidebar) của Antigravity và đặt tên như sau:

### 🟢 PHIÊN 1: `[OPS] Giám Sát Thực Chiến PC2`
- **Mục đích:** Điểm danh buổi sáng, kiểm tra số dư, theo dõi PnL, đối soát vị thế sàn Binance.
- **Quy tắc:** Chỉ đọc dữ liệu và báo cáo. Tuyệt đối không chỉnh sửa code trong phiên này.
- **Câu lệnh bạn gõ mỗi ngày (Chọn 1 trong các câu sau):**
  > `"Chạy kiểm toán ngày PC2"`  
  > *(Hoặc: `"audit"`, hoặc double-click `CHECK_HE_THONG.bat` trên màn hình).*
- **AI sẽ làm gì:** Tự động chạy `python tools/daily_auditor.py`, đọc database PC2 qua LAN, xuất bảng điểm Rubric 100 và danh sách các vị thế.

---

### 🔬 PHIÊN 2: `[QUANT] Phòng Thí Nghiệm & Mô Phỏng`
- **Mục đích:** Phân tích pháp y các lệnh vừa đóng (tại sao lệnh thắng, tại sao lệnh cắt lỗ), chạy mô phỏng đối chứng nến quá khứ.
- **Quy tắc:** Mọi nhận định kỹ thuật phải dựa trên số liệu thực từ 15,000 cụm tín hiệu của PC2. Tuyệt đối không sửa code toàn sàn chỉ từ 1 lệnh đơn lẻ khi chưa kiểm chứng 3 lớp tài sản!
- **Câu lệnh bạn gõ:**
  > `"Pháp y lệnh [Tên coin] vừa đóng và chạy true_signal_simulator đối soát."`
- **AI sẽ làm gì:** Trích xuất log, đối soát phiếu bầu của 4 chiến thuật, tìm ra nguyên nhân do nến giật râu hay do xu hướng, và đưa ra kiến nghị định lượng.

---

### 🛠️ PHIÊN 3: `[DEV] Xưởng Nâng Cấp Code & Web`
- **Mục đích:** Sửa lỗi logic ngầm, tối ưu hóa giao diện Web Dashboard, nâng cấp cơ chế chốt lời/cắt lỗ.
- **Quy tắc:** Mọi thay đổi bắt buộc phải vượt qua `tools/hard_constraints_gate.py` và chạy qua `deploy_web_client.py` để đồng bộ an toàn sang PC2.
- **Câu lệnh bạn gõ:**
  > `"Nâng cấp [Tính năng X]. Kiểm tra Hard Gate rồi deploy sang PC2."`
- **AI sẽ làm gì:** Đọc `docs/FEATURE_MAP.md`, sửa code, chạy linter kiểm tra rào chắn cứng, đóng gói zip, đối soát SHA-256 sang LAN PC2 và đẩy Git Cloudflare Pages.
