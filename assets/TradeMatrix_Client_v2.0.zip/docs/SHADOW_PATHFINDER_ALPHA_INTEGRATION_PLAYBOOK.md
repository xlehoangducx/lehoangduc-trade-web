# 🏛️ SHADOW PATHFINDER MULTI-LAYER ALPHA & SIGNAL INJECTION PLAYBOOK (SSOT)
> **Single Source of Truth (SSOT) Về Cơ Chế Dò Tìm Tín Hiệu Đa Tầng Song Hành 2 Chiều (Thuận & Lật Ngược), Ma Trận 3 Lớp Tài Sản, Thang Vốn Tăng Dần ($25 \to $20,000) Và Bản Đồ Cấy Ghép 8 Tầng Chống Hỗn Loạn Code.**  
> *Mọi phiên AI mới khi nhận lệnh: "Kiểm tra SHADOW PATHFINDER xem có tín hiệu nào đủ điều kiện thêm vô tool không" BẮT BUỘC đọc và tuân thủ 100% tài liệu này.*

---

## ⚡ 1. GIAO THỨC TỰ ĐỘNG KHI NGƯỜI DÙNG YÊU CẦU KIỂM TRA SHADOW PATHFINDER

Khi người dùng khởi tạo phiên mới và hỏi: **"Kiểm tra SHADOW PATHFINDER có tín hiệu nào đủ điều kiện thêm vô tool không"**, AI BẮT BUỘC thực hiện đúng trình tự 5 bước sau (TUYỆT ĐỐI KHÔNG tự ý nhồi code hay sửa nhiều chỗ cùng lúc):

1. **Bước 1 — Chạy Kiểm Toán Đa Tầng & 2 Chiều (`Direct` vs `Inverted`):**
   - Chạy `python tools/report_shadow_alpha.py`.
   - Công cụ sẽ tự động kết nối DB Live trên PC2 (`\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\data\trade_bot.db`), bóc tách toàn bộ các mẫu theo:
     * **Đường đi qua các tầng (`Multi-Layer Pathway`)**: `[Tầng 1: Chiến thuật gốc] -> [Tầng 2: DNA Nến 15M & RVol] -> [Tầng 3: AI Ensemble & JEV 4H MTF] -> [Tầng 4: Cổng Rào Chắn Chính Xác] -> [Lớp Tài Sản: ALTCOIN / MAJOR / TRADFI]`.
     * **Kết quả chấm điểm song hành 60 phút cho CẢ 2 CHIỀU**:
       - **Chiều Thuận (`DIRECT`)**: Đi theo chiều của chiến thuật kỹ thuật gốc.
       - **Chiều Lật Ngược (`INVERTED`)**: Lật ngược `LONG <-> SHORT` (khi tín hiệu gốc báo `SL_HIT` liên tục nhưng chiều ngược lại chạm `TP1`).
2. **Bước 2 — Đối Chiếu Bộ 5 Tiêu Chuẩn Cứng Chuẩn Quỹ (`5-Gate Alpha Promotion Protocol`):**
   - Kiểm tra xem có cụm đường đi nào (cùng Đường đi các tầng + cùng Lớp tài sản + cùng Bộ điều kiện Nến/RVol/RSI/Wick) đạt đủ **5 Tiêu Chuẩn Cứng** ở Mục 5 dưới đây hay chưa (`N >= 15` mẫu hoàn tất 60m, `Win Rate >= 75.0%`, `SL Rate <= 20.0%`, `Net PnL > +5.0 USDT`).
   - **Nếu CHƯA ĐỦ $N \ge 15$ hoặc Win Rate $< 75\%$:** Báo cáo rõ tiến độ tích lũy của từng cụm (ví dụ `12/15 mẫu`), giữ nguyên rào chắn, tuyệt đối không mở khóa sớm.
3. **Bước 3 — Xác Định Đúng Vị Trí Cấy Ghép (`SLOT A`, `SLOT B1`, hoặc `SLOT B2`) & Lớp Tài Sản:**
   - Nếu có cụm ĐẠT ĐỦ 5 TIÊU CHUẨN, tra cứu **Bản Đồ 8 Tầng & 3 Vị Trí Cấy Ghép Cố Định** ở Mục 2 và **Ma Trận 3 Lớp Tài Sản** ở Mục 3 để xác định chính xác vị trí code duy nhất được phép thêm vào.
   - **TUYỆT ĐỐI CẤM** cấy code ngoài 3 Slot này và **TUYỆT ĐỐI CẤM** bypass các tầng bảo vệ phía sau (Tầng 4 Danh mục $\to$ Tầng 5 An toàn & Thang vốn $\to$ Tầng 6 Quantum Gate $\to$ Tầng 7 Sniper M1 $\to$ Tầng 8 Tam Tầng SL V4.1).
4. **Bước 4 — Chạy Mô Phỏng Đối Soát Hồi Quy Lịch Sử Trước Khi Đề Xuất/Triển Khai:**
   - Chạy `python tools/full_historical_signal_and_position_simulator.py`: Bắt buộc **`False Exits (Lệnh thắng bị mất) = 0 / 219 (0.0%)`** và `Net PnL Delta >= +137.46 USDT`.
   - Chạy `python tools/hard_constraints_gate.py` (`11/11 PASSED`) và `python tools/audit_system_integrity.py` (`6/6 PASSED`).
5. **Bước 5 — Báo Cáo Minh Bạch & Đồng Bộ PC2:**
   - Trình bày rõ cho người dùng: Cụm nào đạt chuẩn, thuộc Lớp tài sản nào, cấy vào `SLOT` nào, kết quả Simulator ra sao. Khi người dùng duyệt mới đồng bộ sang PC2 qua `python deploy_web_client.py` và dọn rác `python tools/clean_workspace.py`.

---

## 🧬 2. BẢN ĐỒ KIẾN TRÚC 8 TẦNG TUẦN HOÀN TÍN HIỆU & 3 VỊ TRÍ CẤY GHÉP ĐƯỢC CẤP PHÉP

Một tín hiệu từ lúc quét nến đến khi mở vị thế và đóng lệnh bắt buộc đi qua **8 Tầng Tuần Hoàn** theo đúng trật tự cố định sau đây:

```mermaid
flowchart TD
    T1["TẦNG 1: NGUỒN CHIẾN THUẬT & VI CẤU TRÚC NẾN 15M<br/>(trend_following, trap_detector, mean_reversion, momentum_breakout)<br/>+ DNA Nến: RVol, U_Wick%, L_Wick%, Body%, Pump%, Dump%, RSI, ADX, ATR%, Regime"]
    T1 --> T2["TẦNG 2: AI ENSEMBLE & CỔNG FAST-SKIP PRE-LLM<br/>(core/bot.py:11850-12080)<br/>🔹 SLOT A (Vị trí cấy ghép 1): Miễn trừ Fast-Skip cho cụm tín hiệu đạt chuẩn<br/>để được đi tiếp vào JEV 4H MTF & Aggregator"]
    T2 --> T3["TẦNG 3: JEV 4H MTF & SIGNAL AGGREGATOR CONSENSUS<br/>(ai/signal_aggregator.py:3300-4550)<br/>🔹 SLOT B1 (Vị trí cấy ghép 2 - Smart Unlock): Mở khóa đồng thuận thuận chiều kỹ thuật<br/>🔹 SLOT B2 (Vị trí cấy ghép 3 - Smart Inversion): Lật chiều chuẩn hóa SL/TP theo ATR lớp tài sản"]
    T3 --> T4["TẦNG 4: MACRO AI BIAS & QUẢN TRỊ DANH MỤC ĐA TÀI SẢN<br/>(core/bot.py:12140-12310 — Khóa tương hỗ 10 ngành TradFi, giới hạn max_at_risk)"]
    T4 --> T5["TẦNG 5: PRE-TRADE SAFETY & THANG VỐN TĂNG DẦN ($25 -> $20,000)<br/>(core/bot.py:3310-3680 — Funding Squeeze Gate, Cooldown, 5 Bộ lọc sàn Binance)"]
    T5 --> T6["TẦNG 6: QUANTUM MONTE CARLO VALIDATION GATE<br/>(core/bot.py:3685-3750 — Kiểm định 2,500 kịch bản: EV > 0, P_win >= ngưỡng, P_doa <= 40%)"]
    T6 --> T7["TẦNG 7: ZERO-TIMER M1 SNIPER STALKING & PRE-FILL GUARD<br/>(core/bot.py:4450-4800 — Đặt Limit Maker, rút lệnh khi M1 giật ngược ở vùng cận khớp <= 0.35%)"]
    T7 --> T8["TẦNG 8: TAM TẦNG BẢO VỆ VỐN & CHỐT LÃI V4.1<br/>(Shock Rescue, Deep Loss -1.0%, ChoCH Lock, Cushion -0.25%, MFE Ratchet, Flash BE +0.22%, TP1 50%)"]
```

### 📌 Quy Định Chi Tiết 3 Vị Trí Cấy Ghép Duy Nhất (`SLOT A`, `SLOT B1`, `SLOT B2`):

#### 🔹 1. `SLOT A` — Nhóm Miễn Trừ Fast-Skip (`Fast-Skip Exemption Anchor`)
- **Vị trí file & hàm:** [`core/bot.py`](file:///d:/TRADE/core/bot.py#L11920-L12070) (Khối `SMART INVERSION ANCHOR` ngay trước cổng `FAST-SKIP PRE-LLM`).
- **Áp dụng cho:** Các cụm tín hiệu bị chặn tại cổng **`T2_FAST_SKIP_COUNTER_TREND`**, **`T2_FAST_SKIP_TWIN_WICK`**, hoặc **`T2_FAST_SKIP_RANGING_CHOP`**.
- **Quy tắc cấy ghép:**
  * Chỉ cấp quyền `allow_llm_eval = True` khi thỏa mãn chính xác tổ hợp `[Asset Class + Chiến thuật gốc + RVol + RSI + Pump/Dump/Wick]`.
  * Tín hiệu sau khi được miễn trừ Fast-Skip **bắt buộc phải gọi JEV 4H MTF và đi vào Tầng 3 (`signal_aggregator.aggregate`)**, tuyệt đối không được nhảy cóc vào mở lệnh!

#### 🔹 2. `SLOT B1` — Nhóm Mở Khóa Thuận Chiều Kỹ Thuật (`Aggregator Smart Unlock`)
- **Vị trí file & hàm:** [`ai/signal_aggregator.py`](file:///d:/TRADE/ai/signal_aggregator.py#L4350-L4480) (Khối kiểm tra đồng thuận `agreeing_strategies >= min_agree` trong `aggregate()`).
- **Áp dụng cho:** Các cụm tín hiệu bị chặn tại **`T3_JEV_SHIELD_NEED_2_STRATS`** hoặc **`T3_SCORE_BELOW_THRESHOLD`** mà kết quả kiểm định 60 phút chứng minh **Chiều Thuận Kỹ Thuật (`DIRECT`)** đạt Win Rate $\ge 75.0\%$ với $N \ge 15$ (Ví dụ: `trap_detector: SELL + AI Ensemble: SELL` có râu xả đỉnh cực đại `U_Wick >= 65%`, đà tăng đã gãy `RSI < 65`, `RVol >= 1.33x` dù JEV 4H còn báo BUY).
- **Quy tắc cấy ghép:**
  * Chỉ mở khóa cho phép cặp đồng thuận `Chiến thuật Kỹ thuật + AI Ensemble` giữ hiệu lực (`min_agree` thỏa mãn từ 2 phiếu thực tế này) khi các điều kiện nến vật lý (`U_Wick`, `RSI`, `RVol`) đạt ngưỡng cứng của đúng Lớp Tài Sản.
  * Sau khi qua Tầng 3, tín hiệu bắt buộc đi tiếp qua Tầng 4 $\to$ Tầng 8.

#### 🔹 3. `SLOT B2` — Nhóm Lật Ngược Chiều Thông Minh (`Aggregator Smart Inversion`)
- **Vị trí file & hàm:** [`ai/signal_aggregator.py`](file:///d:/TRADE/ai/signal_aggregator.py#L3450-L3650) (Khối `SMART INVERSION ENGINE` trong `aggregate()`).
- **Áp dụng cho:** Các cụm tín hiệu bị chặn tại Tầng 3 mà **Chiều Thuận (`DIRECT`) dính SL $\ge 70\%$**, nhưng khi **Lật Ngược Chiều (`INVERTED`)** lại đạt Win Rate $\ge 75.0\%$ với $N \ge 15$ (Ví dụ: `trap_detector: SELL` báo đỉnh sớm khi sóng đang bơm Parabolic `RSI >= 65`, `JEV 4H: BUY >= 80%`, `1.10x <= RVol <= 3.50x` $\implies$ Lật sang `LONG` ăn trọn sóng tăng).
- **Quy tắc cấy ghép (4 bước bắt buộc để không lỗi):**
  1. Lật `final_signal.signal` sang chiều `INVERTED` (`Signal.BUY` hoặc `Signal.SELL`).
  2. Đồng bộ dấu `weighted_score = +abs(weighted_score)` (nếu lật sang `BUY`) hoặc `-abs(weighted_score)` (nếu lật sang `SELL`).
  3. **Tính lại `stop_loss` và `take_profit` theo đúng khung `ATR` của Lớp Tài Sản** (Xem Mục 3A), tuyệt đối không giữ SL/TP của chiều cũ!
  4. Gắn cờ metadata rõ ràng (`is_shadow_smart_inversion = True`, `setup_origin = ...`) và cho đi tiếp qua Tầng 4 $\to$ Tầng 8.

---

## 🏛️ 3. MA TRẬN 3 LỚP TÀI SẢN (`ALTCOIN`, `MAJOR`, `TRADFI`) & THANG VỐN TĂNG DẦN ($25 \to $20,000)

### A. Ma Trận Tham Số Định Lượng Riêng Biệt Theo 3 Lớp Tài Sản
> [!WARNING]
> **CẤM TUYỆT ĐỐI** lấy ngưỡng `Pump%`, `Wick%`, `RVol` hay `SL/TP` của `ALTCOIN` áp cho `TRADFI` hoặc `MAJOR`! Mọi điều kiện mở khóa tại `SLOT A / B1 / B2` bắt buộc kiểm tra `asset_class` (`ALTCOIN`, `MAJOR`, `TRADFI`) trước tiên.

| Thông Số Định Lượng | 1. `ALTCOIN` (Crypto Altcoins) | 2. `MAJOR` (`BTC, ETH, SOL, BNB, XRP`) | 3. `TRADFI` (Vàng, Bạc, Dầu, Cổ Phiếu/ETF) |
| :--- | :--- | :--- | :--- |
| **Sàn RVol Tối Thiểu (`min_trap_rvol`)** | **`>= 1.10x`** (Đột biến: `>= 1.33x - 1.50x`) | **`>= 1.00x`** (Đột biến: `>= 1.35x`) | **`>= 0.85x`** (Mở phiên Mỹ: `>= 1.80x`) |
| **Sàn Biên Độ Sóng (`min_climax_pump/dump`)** | **`>= 0.70%`** (Parabolic: `>= 2.0%`) | **`>= 0.55%`** (Parabolic: `>= 1.2%`) | **`>= 0.50%`** (ETF 3x: `>= 1.5%`) |
| **Ngưỡng Râu Từ Chối Đỉnh/Đáy (`wick_pct`)** | Thường `>= 45%`, Cực đại **`>= 65%`** | Thường `>= 38%`, Cực đại **`>= 55%`** | Thường `>= 35%`, Cực đại **`>= 50%`** |
| **Khung Stop-Loss Thích Ứng ATR (`sl_range`)** | **`[1.50%, 3.50%]`** ($1.5 \times \text{ATR}_{15M}$) | **`[1.00%, 2.20%]`** ($1.3 \times \text{ATR}_{15M}$) | 1x: **`[1.00%, 1.80%]`** \| ETF 3x: **`[1.80%, 3.50%]`** |
| **Khung Take-Profit 1 (`tp1_range`)** | **`[2.20%, 5.25%]`** ($\text{R:R} \ge 1.5x$) | **`[1.50%, 3.50%]`** ($\text{R:R} \ge 1.5x$) | 1x: **`[1.50%, 2.70%]`** \| ETF 3x: **`[2.70%, 5.25%]`** |
| **Ngưỡng Chấm Điểm Shadow (`1:1` / `1:2`)** | **`±2.0%`** (1:1) và **`±4.0%`** (1:2) | **`±1.2%`** (1:1) và **`±2.4%`** (1:2) | **`±1.0%`** (1:1) và **`±2.0%`** (1:2) |
| **Rào Chắn Đặc Thù Bắt Buộc Ở Tầng 4-6** | Chặn Funding Squeeze ($<-0.08\%$) & Sóng Bão M1 | Chặn Tường Cá Mập Orderbook ($Z \ge 3.0$) | 4 Rào chắn tương hỗ 10 ngành & Cầu dao Benchmark |

### B. Cơ Chế Thang Vốn Tăng Dần 4 Bậc (`Dynamic Capital Scaling: $25 \to $20,000+`)
Hệ thống tự động nhận diện `Equity` hiện tại của tài khoản để điều chỉnh khối lượng, đòn bẩy và số vị thế mở đồng thời tại Tầng 4 & Tầng 5:

| Bậc Vốn (Equity Tier) | Quy Mô Tài Khoản (USDT) | Rủi Ro Cơ Bản / Lệnh (`risk_per_trade`) | Đòn Bẩy Tối Đa (`max_leverage`) | Số Vị Thế Rủi Ro Đồng Thời (`max_at_risk`) | Cơ Chế Bảo Vệ Đặc Thù Sàn Binance |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Tier 1: Micro Seed** | **`25$ – 100$`** | `1.5% – 2.0% NAV` | Crypto `5x–8x`, TradFi `3x–5x` | Tối đa **`2`** vị thế | Ép `notional = max(6.0, notional)` vượt sàn `MIN_NOTIONAL 5.0$`; cấm chia lẻ dưới Lot Size. |
| **Tier 2: Growth (Hiện tại)** | **`100$ – 1,000$`** *(~405$)* | `1.0% – 1.5% NAV` | Crypto `5x–10x`, TradFi `3x–5x` | Tối đa **`3 – 4`** vị thế | Nhân hệ số `Quantum leverage_multiplier (0.75x - 1.0x)`; tổng ký quỹ $\le 50\%$ NAV (chống lỗi `-2019`). |
| **Tier 3: Pro Quant** | **`1,000$ – 5,000$`** | `0.75% – 1.0% NAV` | Crypto `3x–7x`, TradFi `2x–4x` | Tối đa **`5`** vị thế (tối đa 1 mã/ngành) | Giới hạn Notional mỗi mã Altcoin $\le 15\%$ NAV để tránh trượt giá thanh khoản (Slippage). |
| **Tier 4: Institutional** | **`5,000$ – 20,000$+`** | `0.50% – 0.75% NAV` | Crypto `2x–5x`, TradFi `2x–3x` | Tối đa **`6`** vị thế đa ngành | Kiểm tra độ sâu Orderbook (`Depth >= 10x Notional`), ưu tiên `MAJOR` & `TRADFI`, chia lệnh Maker. |

---

## 📦 4. HỢP ĐỒNG DỮ LIỆU ĐA TẦNG TRONG `SHADOW_PATHFINDER_LOGS` (`DETAILS_JSON` SCHEMA)

Mỗi bản ghi trong bảng `shadow_pathfinder_logs` lưu trữ đầy đủ dấu vân tay 4 tầng và kết quả chấm điểm 2 chiều trong `details_json`:

```json
{
  "layer1_tech_strategies": {
    "trap_detector": {"signal": "SELL", "confidence": 0.66, "type": "BUYING_CLIMAX"},
    "trend_following": {"signal": "BUY", "confidence": 0.79, "type": "TREND_FOLLOWING"}
  },
  "tech_pathway_key": "trap_detector:SELL+trend_following:BUY",
  "primary_setup_type": "BUYING_CLIMAX",
  "layer2_candle_dna": {
    "regime": "uptrend",
    "adx": 28.8,
    "atr_pct": 2.58,
    "rsi": 62.8,
    "rvol": 2.99,
    "u_wick_pct": 71.5,
    "l_wick_pct": 13.0,
    "body_pct": 15.5,
    "pump_pct": 5.3,
    "dump_pct": 0.6
  },
  "layer3_consensus_dna": {
    "ai_vote": "SELL",
    "ai_conf": 0.7275,
    "jev_vote": "BUY",
    "jev_conf": 0.85,
    "weighted_score": -0.2728,
    "agreeing_strategies": 1
  },
  "layer4_exact_veto_gate": "T3_JEV_SHIELD_NEED_2_STRATS",
  "recommended_slot": "SLOT_B1_OR_B2",
  "dual_eval_60m": {
    "max_up_pct_60m": 0.22,
    "max_down_pct_60m": 5.29,
    "long_1to2": "SL_HIT",
    "long_1to1": "SL_HIT",
    "short_1to2": "TP1_HIT",
    "short_1to1": "TP1_HIT"
  }
}
```

---

## 🏆 5. BỘ 5 TIÊU CHUẨN CỨNG CHUẨN QUỸ (`5-GATE ALPHA PROMOTION PROTOCOL`)

Một cụm đường đi trong `Shadow Pathfinder` chỉ được phép cấy vào tool khi đạt đồng thời cả **5 Tiêu Chuẩn Cứng**:

1. **Tiêu chuẩn 1 (Cỡ Mẫu Quỹ — Sample Size):**
   - Cùng 1 đường đi (`tech_pathway_key + ai_vote + jev_vote + exact_veto_gate`) + Cùng 1 Lớp Tài Sản (`ALTCOIN` / `MAJOR` / `TRADFI`) + Cùng Bộ lọc Nến (`RVol`, `RSI`, `U_Wick/L_Wick`) phải tích lũy đủ **$N \ge 15$ mẫu đã hoàn tất 60 phút** (Từ $N \ge 8$ đến $14$: đưa vào danh sách **`⏳ WATCHLIST SẮP ĐỦ MẪU`**, chưa sửa code).
2. **Tiêu chuẩn 2 (Tỷ Lệ Thắng & Kiểm Soát Thua Lỗ Chiều Đề Xuất):**
   - Tỷ lệ chạm mục tiêu (`TP_HIT` ở chiều đề xuất `LONG` hoặc `SHORT`) đạt **$\ge 75.0\%$**.
   - Tỷ lệ dính Stop-Loss (`SL_HIT` ở chiều đề xuất) **$\le 20.0\%$**.
3. **Tiêu chuẩn 3 (Kỳ Vọng Toán Học & Lợi Nhuận Ròng):**
   - Biên độ thuận lợi trung bình $\text{Avg Favorable Excursion} \ge 1.8 \times \text{Avg Adverse Excursion}$.
   - Tổng lợi nhuận ròng ước tính của cụm $> +5.0\text{ USDT}$.
4. **Tiêu chuẩn 4 (Đúng Slot Cấy Ghép & Đúng Khung Tham Số Lớp Tài Sản):**
   - Chỉ được cấy vào đúng `SLOT A`, `SLOT B1` hoặc `SLOT B2` tương ứng với `layer4_exact_veto_gate`.
   - Khung SL/TP và điều kiện RVol/Wick bắt buộc áp đúng theo bảng `3-Asset Class Parameter Matrix` (Mục 3A).
5. **Tiêu chuẩn 5 (Kiểm Định Hồi Quy Lịch Sử Zero False Exits):**
   - Chạy `python tools/full_historical_signal_and_position_simulator.py` đạt **`False Exits = 0 / 219 (0.0%)`**.
   - Chạy `python tools/hard_constraints_gate.py` đạt **`11/11 PASSED`**.

---

## 📋 6. BẢNG THEO DÕI 3 CỤM ĐƯỜNG ĐI TIỀM NĂNG ĐANG TÍCH LŨY MẪU (BASELINE HIỆN TẠI)

| Mã Cụm | Đường Đi Qua Các Tầng (`Multi-Layer Pathway`) | Bộ Điều Kiện Nến 15M & RVol (`ALTCOIN`) | Chiều Thực Tế Ăn Tiền & Slot Cấy Ghép | Tiến Độ Mẫu ($N / 15$) | Hiệu Suất Thực Tế 60 Phút | Hành Động Chuẩn Quỹ |
| :---: | :--- | :--- | :--- | :---: | :--- | :--- |
| **CỤM ALPHA #1** | `T1: trap_detector=SELL`<br/>`T2: AI=SELL`<br/>`T3: JEV 4H=BUY`<br/>`Gate: T3_JEV_SHIELD_NEED_2_STRATS` | **`U_Wick >= 65%`**<br/>**`RSI < 65`**<br/>**`RVol >= 1.33x`**<br/>*(Râu xả đỉnh cực dài & đà tăng đã gãy)* | **Đánh `SHORT`** (Thuận Trap+AI)<br/>👉 **`SLOT B1`** (`ai/signal_aggregator.py`) | **`8 / 15`** | - Đánh `LONG`: 7/8 dính SL.<br/>- **Đánh `SHORT`: `7/8 (87.5%)` ăn TP (`-2.53% → -5.29%`), `0/8 (0%)` dính SL!** | ⏳ **WATCHLIST ƯU TIÊN SỐ 1**<br/>Đợi đủ $N = 15$ mẫu (còn thiếu 7 mẫu). Nếu giữ Win Rate $\ge 75\%$, cấy vào `SLOT B1`. |
| **CỤM ALPHA #2** | `T1: trap_detector=SELL`<br/>`T2: AI=SELL`<br/>`T3: JEV 4H=BUY`<br/>`Gate: T3_JEV_SHIELD_NEED_2_STRATS` | **`RSI >= 65`**<br/>**`1.10x <= RVol <= 3.50x`**<br/>*(Đang bơm Parabolic mạnh, chưa gãy RSI)* | **Lật sang `LONG`** (Thuận JEV 4H)<br/>👉 **`SLOT B2`** (`ai/signal_aggregator.py`) | **`12 / 15`** | - Đánh `SHORT`: 9/12 dính SL.<br/>- **Lật sang `LONG`: `9/12 (75.0%)` ăn TP (`+3.21% → +25.31%`), chỉ 2/12 dính SL!** | ⏳ **SẮP ĐẠT NGƯỠNG ($12/15$)**<br/>Chỉ còn thiếu **3 mẫu** nữa. Khi đạt $N = 15$ và Win Rate $\ge 75\%$, cấy vào `SLOT B2`. |
| **CỤM ALPHA #3** | `T1: trend_following=BUY`<br/>`T2: AI=SELL`<br/>`T3: JEV=SKIP`<br/>`Gate: T2_FAST_SKIP_COUNTER_TREND` | **`RSI >= 56`**<br/>**`Pump >= 0.50%`**<br/>**`RVol >= 1.20x`**<br/>*(Đà tăng 15M đang lên đều)* | **Đánh `LONG`** (Miễn trừ Fast-Skip để gọi JEV 4H)<br/>👉 **`SLOT A`** (`core/bot.py`) | **`10 / 15`** | - Đánh `SHORT`: 0/10 thắng, 6/10 dính SL.<br/>- **Đánh `LONG`: `6/10` ăn TP (`+2.34% → +8.68%`), `0/10` dính SL trước!** | ⏳ **WATCHLIST TÍCH LŨY ($10/15$)**<br/>Còn thiếu **5 mẫu** để đạt $N = 15$. Khi đủ chuẩn, cấy vào `SLOT A` mở cổng gọi JEV 4H. |

---

## 🛡️ 7. CỔNG 6 — KIỂM CHỨNG DRY-RUN 8 TRẠM TỰ ĐỘNG (`BOM #133`) & 5 NGUYÊN NHÂN GÂY LỖI LIÊN HOÀN KHI CẤY MẪU MỚI

### A. Tại sao trước đây cứ thăng hạng LAB mới (`VK11..VK15`, `LAB-48`) là đẻ lỗi ở các tầng?
Phân tích pháp y chuỗi hồi quy `BOM #84 → #132` và tái dựng 17 mẫu `LAB-48` chỉ ra **5 nguyên nhân gốc rễ**:
1. **Chặn nhầm ở `_has_strong_vk_consensus` (`ai/signal_aggregator.py:3294-3306`):** Các cụm lật chiều (như `TRAP_BUY + JEV_BUY → SHORT`) có sẵn `>= 2` phiếu gốc đối nghịch nên bị Aggregator từ chối kích hoạt Vũ Khí Động nếu thiếu `priority` hoặc bị phân sai slot.
2. **`_build_8station_blueprint()` gán sai `SLOT_B1` thay vì `SLOT_B2`:** Trước `BOM #133`, hàm chỉ xét `jev_v` mà không kiểm tra `pathway_family` có ngược chiều với `side` hay không → gán nhầm `SLOT_B1` + `CLIMAX_REVERSAL` (`0.18×ATR`) cho các cụm đảo chiều, lệch cả Tầng 3 lẫn Tầng 4 Quantum (`VK11`, `LAB-48`).
3. **Phòng LAB mù trước Tầng 3 & Tầng 4:** 5 tiêu chuẩn cũ (`Mục 5`) chỉ chấm trên `shadow_pathfinder_logs` + M1 CSV mà **chưa từng chạy thử qua `SignalAggregator.aggregate()` và `QuantumPathSimulator.simulate()`**. Hậu quả là mẫu báo `READY_OPTIMIZED` nhưng vừa bấm cấy thì `16/17` mẫu bị khiên T3 chặn/cướp ngược chiều (như `LAB-48` bị `VK1 LONG` cướp 3 mẫu).
4. **Xung đột ngầm với khiên bảo vệ vũ khí lõi:** Các khiên mới (ví dụ `BOM #130 R4` bảo vệ `VK5/VK6/VK8 SHORT`) hoặc miễn trừ diện rộng (`_is_dyn_short_lw_ok`) vô tình chặn oan TP hoặc cho lọt SL của vũ khí thử nghiệm mới.
5. **Lệch pha giả lập Pre-LLM (`core/bot.py:1548`) vs `SignalAggregator`:** Pre-LLM dùng `RVol >= 1.00x` để quyết định có gọi JEV 4H cho `SLOT_B` hay không, và đọc `votes` / `atr_pct` hơi khác nếu không có bước kiểm tra chung.

### B. Cơ chế Cổng 6 Bắt Buộc Khi Thăng Hạng (`BOM #133 — Tự Động Hóa 100% Trong Tool`)
Mọi lệnh gọi `promote_lab_to_dynamic_weapon()` (từ nút bấm Web `/api/v61/weapon_lifecycle` hay script) **BẮT BUỘC** vượt qua **Cổng 6 (`run_8station_pre_promotion_dry_run` trong `core/quant_evolution_engine.py`)** trước khi được phép ghi `config/weapon_lifecycle.json`:
- Dùng **Thread-local Lifecycle Overlay (`_DRY_RUN_LOCAL`)** — không bao giờ chạm file Live đang chạy, 100% Offline (`PRAGMA query_only = ON`, `order_flow_analyzer` mock `ALLOW`).
- Reconstruct lại toàn bộ mẫu Shadow khớp DNA của ứng viên (tối đa 60 mẫu gần nhất) $\to$ chạy qua **thật** `SignalAggregator.aggregate()` (Tầng 3) và `QuantumPathSimulator.simulate()` (Tầng 4).
- **Ngưỡng chặn cứng tự động của Cổng 6 (vi phạm bất kỳ dòng nào = TỪ CHỐI THĂNG HẠNG NGAY):**
  1. **Mẫu tái dựng tối thiểu:** `total_tested >= 10`.
  2. **Cấm tuyệt đối cướp chiều ngược (`180°`):** `hijacked_opposite == 0` (chỉ cần 1 mẫu bị vũ khí khác lật ngược chiều với ứng viên $\implies$ CHẶN).
  3. **Tỷ lệ mở khóa đúng `weapon_id` tại Tầng 3:** `matched_own / total_tested >= 60.0%` (tránh mẫu chết yểu ở `T3` hoặc bị khiên cũ khóa hết).
  4. **Trần trùng lặp với vũ khí sẵn có:** `hijacked_same_other / total_tested <= 25.0%`.
  5. **Tỷ lệ sống sót qua kép `T3 + T4 Quantum`:** `t4_passed / total_tested >= 45.0%`.
  6. **SL sau khi lọc qua `T3 + T4`:** Nếu có $\ge 4$ lệnh phân định (`TP/SL`) sau T4 thì `t4_post_sl_rate <= 25.0%`.
- Người dùng/UI cũng có thể chạy kiểm tra trước qua `/api/v61/lab_action` với `action = "dry_run_lab"` mà không cần bấm thăng hạng.

---

## 🔄 8. QUY CHUẨN VÒNG ĐỜI 3 CẤP: `LAB → THỬ NGHIỆM (EXPERIMENTAL) → CHÍNH THỨC (OFFICIAL)`

*Chuyển giai đoạn được khóa cứng phía máy chủ (`quant_evolution_engine.py`), không tin payload trình duyệt và không thăng hạng theo cảm tính:*

| Chuyển tiếp | Cổng kiểm định bắt buộc (`Server-Side Guard`) | Điều kiện định lượng cứng | Quyền & Phạm vi thực chiến |
| :--- | :--- | :--- | :--- |
| **1. `LAB → EXPERIMENTAL`** *(Thử nghiệm)* | **6 Cổng (`5-Gate Alpha` + `Gate 6 Dry-Run`)**<br/>Hàm `promote_lab_to_dynamic_weapon()` | • `N >= 15` (cùng đường đi + lớp tài sản), `Strict WR >= 75.0%` *(hoặc Chứng thực kép `15M ResWR >= 85% & M1 WR >= 80%`, hoặc `M1 Rescue fills >= 12 & WR >= 75%`)*<br/>• `SL <= 20.0%` (`<= 10–15%` với nhánh kép/M1)<br/>• `Net ước tính > +5.0$`, `OOS 70/30 PASS`, tổng vũ khí `< trần 14`<br/>• **Cổng 6:** `hijacked_opposite == 0`, `T3 khớp >= 60%`, `trùng <= 25%`, `T3+T4 qua >= 45%`, `SL hậu lọc <= 25%`. | Chạy Live dưới nhãn `🧪 THỬ NGHIỆM`; Sổ kép theo dõi riêng với hàm bán rã `T½` (6h/12h/24h); tự hạ nhiệt trọng số (`0.88x`) nếu `>= 3 lệnh Live` có `WR < 45%` & `Net < -$0.50`. |
| **2. `EXPERIMENTAL → OFFICIAL`** *(Chính thức)* | **Cổng Tốt Nghiệp Thực Chiến (`Official Graduation Guard`)**<br/>Hàm `update_weapon_lifecycle_state()` | • Đọc Sổ kép Live thật từ `get_living_arsenal_status()` (chu kỳ vị thế đã ghép + chống trừ phí kép):<br/>• **`N_live >= 15`** lệnh thực chiến đã đóng<br/>• **`Net PnL Live > +0.0 USDT`**<br/>• **`WR Live >= 55.0%`** *(hoặc **`PF Live >= 1.50` với `WR >= 40.0%`**)*<br/>• **`SL Live <= 30.0%`**<br/>• `0` lỗi liên tầng / hồi quy mở lệnh. | Trở thành Vũ Khí Chính Thức (`⚔️ CHÍNH THỨC`), bỏ huy hiệu thử nghiệm. |
| **3. `PAUSE / DEMOTE / BAN`** *(Tạm tắt / Hạ về LAB / Cấm)* | `update_weapon_lifecycle_state()` / `reject_lab_cluster()` | • **Tạm tắt (`PAUSED`):** Khi `N_live >= 10` âm tiền kéo dài hoặc bị `R4/Macro` mới thay thế tốt hơn.<br/>• **Cấm vĩnh viễn (`REJECTED`):** Overfit `M1 Replay WR < 50%` & `Net < 0` (`COMBO-4`), `0/20` lens qua OOS ở `N >= 15`, hoặc `SL thực >= 30%` / `TIMEOUT > 50%`. | Đóng ngay mọi đường vào lệnh mới (`is_weapon_enabled_for_live() == False`), bảo toàn `id_map` không nhảy số. |

---

## 🛠️ 9. KỶ LUẬT CHỐNG CHỒNG CODE CŨ & LỘ TRÌNH PHÒNG LAB TỰ CHỦ (SELF-VERIFYING LAB)

### A. Checklist chống sót / chồng code cũ mỗi khi sửa tầng tín hiệu
1. **Không bao giờ viết nhánh vá song song mà giữ lại điều kiện cũ chạy trước/sau nó** (như `or is_tradfi_opening_pump` ở `BOM #26` hoặc `if not dyn_vk_unlocked` vá tay rải rác). Trước khi thêm `if ...`, luôn grep toàn bộ biến cờ (`weapon_id`, `is_dynamic_weapon`, `dyn_vk_unlocked`) trong cả `bot.py`, `signal_aggregator.py`, `quantum_path_simulator.py`.
2. **Mỗi khi sửa `SignalAggregator` hoặc thêm khiên mới cho `VK1..VK10`:** chạy `run_8station_pre_promotion_dry_run` trên chính các Vũ Khí Động đang hoạt động (`VK11..VK15`) để phát hiện tức thì nếu khiên mới vô tình giết vũ khí động đang chạy.
3. **Bắt buộc chạy đủ 6 cổng Offline** (`test_bom*.py` + `exhaustive_10axis_audit.py` + `hard_constraints_gate.py` + `audit_system_integrity.py` + `full_historical_signal_and_position_simulator.py` + `clean_workspace.py`).

### B. Kế hoạch nâng cấp Phòng LAB chuẩn & tự chủ (4 Pha — Tool tự kiểm, không cần Antigravity dò tay)
1. **Pha 1 *(Đã triển khai trong `BOM #133`)* — Khớp Blueprint + Gate 6 Dry-Run + Graduation Guard:** Tool tự phát hiện đảo chiều (`SLOT_B2`), tự chạy thử `T3 + T4` trước khi cho phép thăng hạng lên `EXPERIMENTAL`, và tự khóa nâng cấp lên `OFFICIAL` cho đến khi đủ `15` lệnh Live có lãi.
2. **Pha 2 — Tầng 1–2 & Tầng 5 Full Replay trong LAB (Kế tiếp):** Mở rộng `run_8station_pre_promotion_dry_run` gọi thêm trình giả lập logic Pre-LLM Fast-Skip (`bot.py:1380-1615`) và M1 Sniper Replay trực tiếp trên *tập đã qua T3+T4* (hiện M1 Replay chạy trên tập thô Shadow trước T3/T4 nên chưa đo được mẫu sau khi lọc qua `SignalAggregator + Quantum`).
3. **Pha 3 — Hồi quy chéo `Existing Dynamic Weapons Regression` trên UI:** Bấm 1 nút trên Web kiểm tra lại định kỳ toàn bộ `VK11+` đang bật mỗi tuần xem có bị xung đột với các bản vá mới không; tự động gắn cảnh báo `⚠️ MẤT ĐỒNG BỘ TẦNG` nếu tỷ lệ T3 xuống `< 60%`.
4. **Pha 4 — Lọc & Chặn Trùng Chéo Ngay Từ Lúc Sinh Cụm LAB (`Auto-Gate-Aware Discovery`):** Nhúng sẵn kiểm tra xung đột `R4`, `Fast-Skip RVol >= 1.00`, và `Slot/Priority` ngay trong `run_auto_dna_lab_discovery_and_optimizer()` để các mẫu bị xung đột kiến trúc **tự rớt khỏi danh sách đề xuất `READY_OPTIMIZED`** ngay từ đầu, chỉ hiện các mẫu thực sự sạch 8 Trạm.
