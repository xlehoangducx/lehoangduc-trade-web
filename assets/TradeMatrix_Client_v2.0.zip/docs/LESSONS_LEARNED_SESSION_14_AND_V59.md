# TỔNG KẾT BÀI HỌC PHIÊN 14 & KIẾN TRÚC V5.9 (VIETNAMESE QUANT FLOW · GÓI A · GÓI B)
> **Single Source of Truth (SSOT) Toàn Diện Từ Vĩ Mô Đến Vi Mô — Cập Nhật 20/11/2026**
> *Tài liệu bắt buộc cho mọi phiên AI mới: Tổng hợp toàn bộ kiến trúc Việt hóa `/so-do-dong`, 11 Quả Bom Nổ Chậm đã triệt tiêu, 6 Lỗi chuyển đổi PC1, Gói A (Đa luồng WebSocket 2.0s), Gói B (Shadow 2-Tier `M21/M22` kiểm chứng trên 22 mô hình), 6 Cụm Alpha, và lộ trình nâng cấp dài hạn.*

---

## 🧭 1. TOÀN CẢNH KIẾN TRÚC HIỆN TẠI (VĨ MÔ $\to$ VI MÔ)

### A. Hạ Tầng 2 Máy Tính & Trạng Thái Hiện Tại (20/11/2026)
- **PC1 (`d:/TRADE` — Bản Nâng Cấp V5.9 Tiếng Việt & Sơ Đồ Luồng `/so-do-dong`):**
  - Đã tích hợp hoàn chỉnh: **BOM #1 $\to$ #11**, **6 Lỗi Chuyển Đổi PC1**, **Gói A (WebSocket `@bookTicker` 2.0s / 0 REST weight)**, **Gói B (Shadow 2-Tier `M21/M22` + Freshness 6h)**, **Quy tắc Gối Đầu Hòa Vốn Thép (`correlation_cap = 1`)**, **6 Cụm Alpha động từ SQLite**, và đã gộp đủ **`587 mẫu` Shadow** từ PC2 về DB PC1 để nghiên cứu.
  - **LƯU Ý ĐỒNG BỘ:** Chưa chạy `deploy_web_client.py` đẩy bản V5.9 sang PC2 cho đến khi người dùng xác nhận PC1 chạy thực chiến ổn định và ra lệnh đồng bộ.
- **PC2 (`\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` — Bản Gốc An Toàn Đã Vá BOM #1 $\to$ #6):**
  - Giữ nguyên bản gốc đã đạt `5W/0L (+2.64 USDT)` sáng 20/11 và đã được vá phẫu thuật dứt điểm **BOM #1 $\to$ BOM #6** (`core/bot.py`, `core/exchange.py`, `risk/risk_manager.py`). Không trộn giao diện PC1 sang khi chưa được lệnh.
- **Web Cloud (`D:\WEB_TRADE_BOT` — Cloudflare Pages & `cloud_sync.py`):**
  - **KHÔNG BỊ ẢNH HƯỞNG** bởi bản Việt hóa PC1 vì `dashboard_v2.js` và `cloud_sync.py` đọc trường số & cờ trạng thái chuẩn (`trailing_status`, `trailing_active`, `pnl`, `strategy`), không parse chuỗi log tiếng Anh/Việt.
  - Đã vá **BOM #9** trong `deploy_web_client.py` (thêm `core/vietnamese_weapon_arsenal.py` & `dashboard/templates/pipeline_map.html` vào `files_to_sync`) để khi deploy sang PC2 & ZIP Cloud không bị thiếu file gây lỗi 500.

### B. Vòng Tuần Hoàn Tín Hiệu 7 Tầng + Giao Diện Trực Quan `/so-do-dong`
1. **Tầng 1 (Radar Quét 50+ Cặp — 8 Luồng An Toàn API):** Quét 3 Lớp Tài Sản (`ALTCOIN / MAJOR / TRADFI`), ghi log song ngữ chuẩn `[MarketAnalysis]`.
2. **Tầng 2 (Máy Dò Bẫy & Lọc Nhanh Pre-LLM):** `TrapDetector`, `TrendFollowing`, `Breakout`, `MeanReversion`, `AI Ensemble ML` + `Fast-Skip Pre-LLM` (tiết kiệm 5–8s GPU Ollama; miễn trừ cho Whale Pump / Waterfall / Climax).
3. **Tầng 3 (Hội Đồng AI & Khiên Xu Hướng 4H JEV + Định Danh 8 Vũ Khí):**
   - `SignalAggregator` tính điểm hội tụ, Smart Inversion, JEV MTF Shield (`>= 70%`), và `SLOT B2 (3C-KB10 Parabolic Long Inversion)`.
   - `core/vietnamese_weapon_arsenal.py` định danh 8 Vũ Khí (`VK1–VK4` Mua, `VK5–VK7` Bán, `VK8` Linh hoạt 2 chiều) — **TUYỆT ĐỐI KHÔNG cộng/trừ `final_signal.confidence`** để bảo toàn 100% toán học Đòn Bẩy Động & Quantum Gate.
4. **Tầng 3.5 (Gói B — Cổng Chứng Thực Kép Shadow Regime `M21/M22`):** Xếp hạng ưu tiên ứng viên Pha 2 (+8% rank cho phe thuận dòng Shadow) và kiểm định chứng thực kép cho lệnh ngược dòng bão (chi tiết Mục 4).
5. **Tầng 4 (Cổng An Toàn, Gối Đầu Hòa Vốn Thép & Quantum Gate):** `RiskManager` (`correlation_cap = 1` trên PC1 — chỉ mở Altcoin thứ 2 cùng chiều khi lệnh 1 đã Free-Roll `protection_status in ('exchange_stop', 'exchange_stop_verified')`), `Pre-Trade Safety Gate`, `Quantum Path Simulator`.
6. **Tầng 5 (Xạ Thủ Rình Mồi M1 Limit Maker Zero-Timer):** Rình khớp Maker 0.02%, chỉ ghi Shadow/Gate Event **SAU KHI** sàn xác nhận hủy thành công (`_cancel_stalking_order == True`).
7. **Tầng 6 (Tam Tầng Bảo Vệ Vốn V4.1 & Kéo SL/TP WebSocket 2.0s — Gói A):**
   - Nhịp nhanh `2.0s` đọc Best Bid/Ask từ WebSocket `@bookTicker` (0 REST weight) để bắt đỉnh MFE `+0.85%`, Flash Hard BE, MFE Ratchet, ChoCH Early Lock, Shock Rescue tức thì.
   - Nhịp đối soát sàn `sync_live_positions_with_exchange()` mỗi `10–15s`.
8. **Tầng 7 (Shadow Pathfinder 2 Chiều 60 Phút):** Mọi tín hiệu bị chặn từ Tầng 1 $\to$ Tầng 5 đều rẽ vào RAM (`0% GPU`), chấm song song cả chiều Thuận (`Direct`) & Lật Ngược (`Inverted`) với biên SL/TP đã kẹp chuẩn 3 lớp tài sản (BOM #5), lưu xuống SQLite `shadow_pathfinder_logs` để phản hồi về Gói B và theo dõi **6 Cụm Alpha** trên `/so-do-dong`.

---

## 💣 2. DANH MỤC 11 QUẢ BOM NỔ CHẬM & 6 LỖI CHUYỂN ĐỔI ĐÃ TRIỆT TIÊU (CẤM TÁI PHẠM!)

### A. 11 Quả Bom Nổ Chậm Đã Bắt Quả Tang & Xử Lý Dứt Điểm
| Mã BOM | Phạm Vi | Bản Chất Quả Bom | Cách Vá Chuẩn Đã Áp Dụng |
| :--- | :--- | :--- | :--- |
| **BOM #1** | PC1 & PC2 | `is_inverted_parabolic_or_momentum_pos` xóa `ai_ensemble` vô điều kiện $\implies$ `dual_ai_jev_opposing` luôn `False` (dead code), lệnh SLOT B2 gồng tới Full SL khi JEV 4H thực sự đảo chiều. | Thêm `jev_strongly_opposes_open_pos` (`>= 0.70`): chỉ bảo vệ khi JEV 4H chưa đảo chiều; khi JEV 4H đảo chiều giữ nguyên `ai_ensemble` cho thoát sớm thông minh (`core/bot.py`). |
| **BOM #2** | PC1 & PC2 | `retry_api_call` spam retry khi gặp lỗi `418 / -1003` khiến Binance gia hạn án phạt IP ban. | Cấy Cầu Dao IP Ban `_extract_and_activate_ip_ban` ngắt retry tức thì tới `banned until + 3s` (`core/exchange.py`). |
| **BOM #3** | PC1 & PC2 | Ghi `_register_shadow_stalking_safe` & `record_gate_event` **trước** `_cancel_stalking_order` $\implies$ lệnh đã khớp vẫn bị ghi Shadow ảo. | Chuyển xuống **SAU** `if not self._cancel_stalking_order(...): continue` ở cả `pre_inval == 'abort'` và `is_runner_away` (`core/bot.py`). |
| **BOM #4** | PC1 & PC2 | `TB1 PHANTOM LAST-PRICE SPIKE GUARD` chỉ kiểm tra `raw_app_pnl >= 0.0045` (1 chiều dương), bỏ sót râu sập âm ảo gây Shock Rescue cắt oan. | Đổi thành `abs(raw_app_pnl) >= 0.0045`, kẹp đối xứng cả 2 chiều theo `Best Bid / Best Ask` (`core/bot.py`). |
| **BOM #5** | PC1 & PC2 | `_register_shadow_candidate_safe` không kẹp biên SL/TP, để tín hiệu thô ghi `SL=4.5% / TP=9.0%` làm méo tỷ lệ `TIMEOUT_60M`. | Kẹp chuẩn 3 Lớp Tài Sản: `ALTCOIN [1.5%, 3.5%]`, `MAJOR [1.0%, 2.2%]`, `TRADFI [1.0%, 1.8%]` (ETF `[1.8%, 3.5%]`), TP `[1.5x, 2.0x SL]` trần `6.0%` (`core/bot.py`). |
| **BOM #6** | PC1 & PC2 | `_is_position_risk_free` (`bot.py:1875`) & `can_trade` (`risk_manager.py:216`) kiểm tra `protection_status == 'exchange_stop'` nhưng sau khi xác minh sàn code gán `'exchange_stop_verified'` $\implies$ kẹt Free-Roll Recycling! | Đổi cả 2 nơi sang `protection_status in ('exchange_stop', 'exchange_stop_verified')`. |
| **BOM #7** | Phân tích định lượng | Model ML `CV < 58%` chỉ bị Fast-Skip chu kỳ Warm-up #1 rồi load lại chạy bình thường. **Kiểm chứng thực tế 62 model PC1/PC2: 57/62 (91.9%) có CV 40%–56% (gồm cả `ETH`, `ETHFI`, `1000PEPE` thắng)!** | **QUYẾT ĐỊNH CHÍNH THỨC: KHÔNG CHẶN VĨNH VIỄN `CV < 58%`** để tránh giết 92% số cặp coin; chỉ giữ Warm-up #1 + lọc `dynamic_threshold >= 0.58` kết hợp JEV 4H. |
| **BOM #8** | PC1 | `build_live_pipeline_snapshot()` bỏ qua cache + full-table scan `shadow_pathfinder_logs` + `json.loads()` mỗi 3s khi mở `/so-do-dong` $\implies$ nguy cơ CPU cao & SQLite lock + đọc sai key `max_open_positions`. | Thêm cache TTL `30s/20s` + `PRAGMA query_only = ON` + `LIMIT 1500` + bọc thread-safe snapshot + đọc đúng `max_open_trades` (`core/vietnamese_weapon_arsenal.py`). |
| **BOM #9** | PC1 | `deploy_web_client.py` (`files_to_sync`) thiếu `core/vietnamese_weapon_arsenal.py` & `dashboard/templates/pipeline_map.html` $\implies$ deploy sang PC2 sẽ làm Gói B tê liệt im lặng & lỗi 500 `/so-do-dong`. | Đã bổ sung đủ cả 2 file vào `files_to_sync` (`deploy_web_client.py`). |
| **BOM #10** | PC1 | `get_shadow_dual_window_regime()` đọc 80 dòng cuối không lọc thời gian $\implies$ nếu máy nghỉ 9 tiếng sẽ lấy nhiệt kế cũ của quá khứ để phán hiện tại. | Bổ sung bộ lọc tươi **`max_age_hours = 6.0` giờ** (xử lý cả epoch giây & mili-giây); nếu chưa đủ 15 mẫu tươi $\implies$ tự về `WARMUP / BALANCED` mở tự do 8 Vũ Khí. |
| **BOM #11** | Môi trường PC1 | Đồng hồ Windows PC1 từng lệch `-36.5s` (`-36514ms`) so với Binance làm lệch so sánh nến M1 (`candle_ts` vs `entry_ts`). | Người dùng đã sync giờ Windows chuẩn; luôn nhắc kiểm tra Offset `< 1000ms` hoặc chạy `Fix_Time.bat` khi khởi động máy. |

### B. 6 Lỗi Chuyển Đổi Sang Tiếng Việt Trên PC1 Đã Khắc Phục Sạch
1. **Xóa đột biến `confidence` ($\pm 0.04$)** trong `ai/signal_aggregator.py` để bảo toàn 100% Đòn Bẩy Động & Quantum Gate.
2. **Chặn gán nhầm 40 dòng `'Binance Fill'`** vào `VK8` trong `vietnamese_weapon_arsenal.py`.
3. **Khôi phục log song ngữ bảo toàn 100% Regex** (`[MarketAnalysis]`, `[FAST-SKIP PRE-LLM]`, `[JEV Agent MTF] ... (confidence: ...%)`, `Aggregated score for`, `[ADVERSE SHOCK RESCUE]`, `[ChoCH EARLY PROFIT LOCK]`) cho 4 công cụ Pháp Y & Simulator.
4. **Khôi phục bộ lọc `mean_reversion`** khớp 100% bản Live PC2 và sửa lỗi dịch ngược `Bear Trap` (Bẫy Giảm) vs `Bull Trap` (Bẫy Tăng).
5. **Thay số cứng Alpha Watchlist bằng truy vấn SQLite động 100%** + truyền đủ `primary_setup_type` trong `_build_phase2_telemetry_payload`.
6. **Đồng bộ `max_open_trades: 3`** trong `config/settings.yaml`.

---

## ⚡ 3. GÓI A — KIẾN TRÚC ĐA LUỒNG WEBSOCKET 2.0s & CHỐNG BAN API

- **`core/binance_ws.py`:** Gộp thêm stream `@bookTicker` vào chung Combined Stream hiện có (`sync_active_ticker_symbols`, `get_live_book_ticker`, tối đa 8 mã, Self-Healing tự thu hồi khi đóng lệnh, **0 REST API weight**).
- **`core/bot.py` (`_position_management_loop` & `_check_open_positions_locked`):**
  - **Nhịp Nhanh `2.0s`:** Lấy Best Bid/Ask trực tiếp từ RAM WebSocket `@bookTicker` để phản xạ kéo SL/TP, Flash Hard BE `+0.85%`, MFE Ratchet, ChoCH & Shock Rescue nhanh gấp **5 lần** (`10s` $\to$ `2.0s`, fallback REST nếu WS quá hạn `> 3.0s`).
  - **Nhịp Đối Soát Sàn `10–15s`:** Chỉ gọi `sync_live_positions_with_exchange()` theo chu kỳ an toàn.
  - **Pha 1 Quét Đa Luồng:** Giảm `ThreadPoolExecutor(max_workers=15)` xuống **`max_workers=8`** chống burst 60 REST requests cùng giây gây `-1003 / 418`.

---

## 🧭 4. GÓI B — SHADOW ADAPTIVE 2-TIER REGIME (`M21/M22`) & LỘ TRÌNH 8 $\to$ 12 VŨ KHÍ

### A. Bằng Chứng Mô Phỏng 22 Mô Hình (53 Vị Thế Live PC2 `18/11–20/11` + 584 Mẫu Shadow OOS)
- Lọc theo WR từng Vũ Khí đơn lẻ ở `N = 5` **KHÔNG HIỆU QUẢ** (độ tách biệt chỉ `+7.3%`, Delta PnL `+0.20 USDT` do mẫu quá nhỏ).
- **Quán Quân Tuyệt Đối — `M21/M22` (Cửa Sổ Kép `Slow80 / Fast24` trong 6h tươi + Thang Chứng Thực 2 Tầng 3 Lớp Tài Sản):**
  - **Baseline (`M0`):** `30W / 23L (56.6% WR)`, Net **`-3.9106 USDT`**, MaxDD **`-8.41 USDT`**.
  - **Quán Quân `M21/M22`:** **`28W / 13L (68.3% WR)`**, Net **`+2.49 đến +2.69 USDT` (`Δ +6.40 đến +6.61 USDT`)**, MaxDD giảm 62% xuống **`-3.21 USDT`**, độ tự do **`77.4%`**, cứu sạch **10 lệnh thua nặng (`-6.52 USDT`)** trong khi giữ trọn các lệnh thắng ngược dòng lớn (`AIOT +1.61`, `0G +0.69`, `USELESS +1.29`)!
- **Quy Luật Vận Hành Không Gò Bó Vũ Khí:**
  1. **Cân Bằng (`gap < 15%` hoặc `dom < 62%` hoặc `slow_n < 15` trong 6h):** Mở tự do 100% toàn bộ 8 Vũ Khí.
  2. **Thuận Dòng (`dom_self >= 62%`, `gap >= 15%`):** Cộng `+8%` điểm xếp hạng ưu tiên tranh Slot ở Pha 2 (không sửa `confidence`).
  3. **Nấc 1 Ngược Dòng (`62%..69.9%`, `gap >= 15%`):** Cho phép mở tự do khi đạt **Chứng Thực Kép** (`JEV >= 75%` + `RVol >= 1.15x TradFi / 1.35x Major / 1.60x Altcoin` + `Wick >= 35%`, hoặc `RVol >= 2.2x & Wave >= 1.5%`) HOẶC `Fast24` đảo chiều `>= 55%`.
  4. **Nấc 2 Bão 1 Chiều Cực Đoan (`>= 70%`, `gap >= 35%`):** Chỉ mở ngược bão khi `Fast24 >= 45%` + Chứng Thực Kép (`+0.2x RVol`); chặn chuỗi thua cản tàu kiểu đêm 19/11 (`Fast24` lên tới `81%–94%` 1 chiều).

### B. 6 Cụm Mẫu Alpha Đang Nghiệm Chứng Trên PC1 (587 Mẫu Shadow) & Tầm Nhìn Dài Hạn
1. `ALPHA_1` (`SLOT B1`): Bán Đỉnh Râu Dài (`11/15`, WR `63.6%`, SL `18.2%`).
2. `ALPHA_2` (`SLOT B2` — Đã cấy ghép): Mua Lật Ngược Sóng Parabol `3C-KB10` (`21/15`, WR `71.4%`, SL `19.0%`).
3. `ALPHA_3` (`SLOT A`): Mua Đà Tăng Thuận Xu Hướng (`13/15`, WR `53.8%`, SL `15.4%`).
4. `ALPHA_4` (`SLOT B1` — Mới): Bán Đỉnh Xác Nhận Kép `Trap+AI` (`20/15`, WR `60.0%`, SL `40.0%` $\implies$ chưa đạt chuẩn `WR >= 75%`, cần thêm bộ lọc DNA nến).
5. `ALPHA_5` (`SLOT B1` — Mới): Mua Đáy Rút Chân `TRADFI` (`6/15`, WR `100.0%`, SL `0.0%` — tiềm năng `VK9`).
6. `ALPHA_6` (`SLOT A` — Mới): Mua Bật Nảy Quá Bán Sâu `MeanReversion` (`6/15`, WR `66.7%` — tiềm năng `VK12`).
- **Tầm nhìn dài hạn:** Chỉ mở rộng Kho Vũ Khí từ **8 lên tối đa 10–14 Vũ Khí cốt lõi** (cấm phình 50–100 vũ khí gây Overfitting); dùng Shadow dài hạn cho 3 trụ cột: (1) Nhiệt kế thời gian thực `M21/M22`, (2) Khai phá Alpha chuẩn 5 Tiêu Chuẩn Cứng, (3) Phát hiện thoái hóa chiến lược (Edge Decay) theo mùa thị trường.

---

## ⚠️ 5. QUY TẮC BẮT BUỘC CHO PHIÊN MỚI
1. **CẤM chạy `python tools/report_shadow_alpha.py` hay bất kỳ script gọi REST Binance nào trên máy đang chạy Live** để tránh trùng tải/ban IP (`418 / -1003`); chỉ dùng `full_historical_signal_and_position_simulator.py` (100% offline) hoặc đọc bản sao SQLite `trade_bot.db`.
2. **Kiểm toán `StartTime >= ModifiedTime` và `Offset < 1000ms`** ngay khi mở phiên kiểm tra Live.
3. **Điểm Tin Cậy AI (`docs/AI_TRUST_SCORECARD.md`) vẫn giữ ở `37%`** cho đến khi V5.9 chạy thực chiến và chốt lãi tiền tươi thực tế (`Net PnL > 0`, `False Exits = 0`).
