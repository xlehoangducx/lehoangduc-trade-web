# BÀI HỌC PHIÊN 16 & TỔNG KẾT KIẾN TRÚC V6.4 (`BOM #30 → #126A–D`)
> **SSOT Bàn Giao Chính Thức Sau Đợt Pháp Y PC2 & Triển Khai Trọn Gói `BOM #126A–D` (25/11/2026)**
> *Mục tiêu: Đồng bộ hóa tuyệt đối Tài liệu ↔ Cấu hình ↔ Mã nguồn, khóa chặt 9 mâu thuẫn đã phát hiện, triệt tiêu 6 nguyên nhân gốc rễ gây hồi quy, và lập Bản đồ 10 Điểm Nóng Liên Kết Chéo cho mọi phiên nâng cấp sau.*

---

## 1. BỨC TRANH HỆ THỐNG HIỆN HÀNH (V6.4 — `50bc5ec`)

### 1.1. Hạ Tầng 2 Máy Tính & Trạng Thái Đồng Bộ
| Thành phần | Vai trò hiện tại | Trạng thái & Thông số xác thực |
| :--- | :--- | :--- |
| **PC1 (`d:\TRADE`)** | **DEV & QUANT Offline** (`PC1_BOT_PROCS=0`) | Python 3.14.7 venv, kho nguồn SSOT & chạy 5 Cổng Kiểm Toán Offline. Tuyệt đối KHÔNG chạy bot Live hoặc REST scan Binance trên PC1 khi PC2 đang live. |
| **PC2 (`\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0`)** | **LIVE Machine Duy Nhất** | Đã đồng bộ **83/83 file SHA-256** từ PC1 qua `deploy_web_client.py` (ZIP `TradeMatrix_Client_v2.0.zip` = `1,118,829 bytes`, GitHub commit `50bc5ec`, backup ổ D PC2). |
| **Lưu ý vận hành PC2** | Đồng hồ Windows & Tiến trình RAM | Log đêm `25/11` ghi nhận lệch đồng hồ PC2 `1025ms` (`05:19:22`) $\to$ `1153ms` (`06:17:29`). Khi nâng cấp hoặc khởi động lại trên PC2, luôn chạy `Fix_Time.bat` + `RESTART.bat` để đồng bộ NTP và nạp code mới vào RAM (`StartTime >= ModifiedTime`). |

### 1.2. Kho 15 Vũ Khí & Vòng Đời (`config/weapon_lifecycle.json`)
Hệ thống đã mở rộng từ **10 vũ khí (V6.0)** lên **15 vũ khí (`VK1..VK15`, V6.4)**:
- **Static `OFFICIAL` (5 vũ khí):** `VK1`, `VK4`, `VK5`, `VK6`, `VK8`.
- **Static `PAUSED` (3 vũ khí):** `VK2`, `VK3`, `VK7` (bị chặn cấp aggregator theo DNA/lifecycle, tránh nhiễu âm).
- **Static `EXPERIMENTAL` (2 vũ khí):** `VK9` (`L1∩A4`, ALTCOIN SHORT), `VK10` (`TRADFI S13`, TRADFI LONG).
- **Dynamic `EXPERIMENTAL` (5 vũ khí do `QuantEvolutionEngine` tiến hóa từ Shadow Alpha):**
  - `VK11_BOTH_DONG_9756` (`SLOT_B2`, `BOTH`, `TREND_MOMENTUM`)
  - `VK12_SHORT_DONG_9620` (`SLOT_A`, `SHORT`, `TREND_MOMENTUM`)
  - `VK13_SHORT_DONG_6296` (`SLOT_B1`, `SHORT`, `CLIMAX_REVERSAL`)
  - `VK14_LONG_DONG_8090` (`SLOT_B2`, `LONG`, `TREND_MOMENTUM`)
  - `VK15_LONG_DONG_2765` (`SLOT_B2`, `LONG`, `TREND_MOMENTUM`)

### 1.3. Cơ Chế Định Cỡ, Danh Mục & Pháp Y Đêm `25/11`
- **Risk Parity 4 Phân Lớp (`config/position_tuning.json`):**
  - `ALTCOIN`: `base_risk_pct = 0.35`, `sl_default_pct = 2.5`, `max_notional_pct = 20.0`.
  - `MAJOR`: `base_risk_pct = 0.35`, `sl_default_pct = 1.7`, `max_notional_pct = 25.0`.
  - `TRADFI_1X`: `base_risk_pct = 0.35`, `sl_default_pct = 1.4`, `max_notional_pct = 20.0`.
  - `TRADFI_ETF_3X`: `base_risk_pct = 0.30`, `sl_default_pct = 2.75`, `max_notional_pct = 15.0`.
  - **Global Risk Controls:** `soft_dd_enabled = True`, `soft_dd_tier1_pct = 5.0` (`0.7x`), `soft_dd_tier2_pct = 8.0` (`0.4x`), `liquidity_impact_max_vol_ratio = 0.0015`, `min_tp_slice_usd = 6.5`, `liquidation_sl_multiple = 4.0`, `hot_reload_new_positions_only = True`.
- **Phân lớp TradFi:** Đã mở rộng lên **250 mã TradFi** trong `core/scanner.py` (kèm bản vá `NVDD/TSLS/MSTZ` ở `BOM #126`).
- **Pháp y Live Đêm `25/11` (01:16–07:03) trước `BOM #126A–D`:**
  1. `ARIA/USDT SHORT` (`VK6`, `01:16:56 -> 02:31:18`, `-\$0.334` net): Lọt lưới do `JEV HALLUCINATION GUARD` (`ai/jev_agent.py`) nối `AND` giữa 4H & 15M; khi 4H `STRONG BULLISH` (`C=0.30729 > EMA20=0.28998 > EMA50=0.26079`) nhưng LLM ảo giác `"4H bearish"`, điều kiện `AND` làm guard không kích hoạt.
  2. `HYPE/USDT SHORT` (`VK12`, `04:00:53 -> 04:47:04`, `-\$0.381` net): Entry hợp lệ lúc vào; gặp nến M1 xanh thật `$2.45M` (`V=40,851.2`, `20.11x`, `body=81.0%`), được Shock Rescue cắt lỗ sớm ở `-0.46%` thay vì `-1.50%` Full SL.
  3. **Hồi quy `BOM #125D` trên `core/binance_ws.py`:** Lỗi `self._streams_need_restart = True` ghi đè `asyncio.Event` gây `'bool' object has no attribute 'set'` 4 lần (`05:17:04`, `05:18:28`, `06:16:08`, `06:17:22`) — đã triệt tiêu ở `BOM #126A`.
- **Chỉ số tin cậy AI ([`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md)):** Giữ nguyên **`10%`** (chỉ tăng khi vị thế Live mới sau bản vá có `Net PnL > 0` và `False Exits = 0`).

---

## 2. TỔNG HỢP 9 MÂU THUẪN ĐÃ PHÁT HIỆN & XỬ LÝ (TÀI LIỆU ↔ CẤU HÌNH ↔ CODE)

| # | Nguồn A vs Nguồn B | Mô tả mâu thuẫn | Kết luận & Trạng thái hiện tại |
| :-: | :--- | :--- | :--- |
| **1** | `AGENTS.md` / `SESSION_15` vs Kho code thực tế | Tài liệu cũ ghi V6.0, 10 vũ khí, PC1 chạy Live chưa sync PC2 | **Thực tế (`BOM #126A–D`):** V6.4, **15 vũ khí (`VK1..VK15`)**, PC2 là máy Live duy nhất đã sync **83/83 SHA-256** (`50bc5ec`), PC1 chỉ chạy Offline (`PC1_BOT_PROCS=0`). |
| **2** | `docs/FEATURE_MAP.md` vs `position_tuning.json` / `scanner.py` | Tài liệu cũ ghi `Major 10x–20x, Altcoin 3x–10x`, Weekend Shield đóng lệnh trước thứ Bảy, `238` mã TradFi | **Thực tế:** Risk Parity 4 phân lớp (Altcoin `≤ 5x`), Weekend Shield kéo Net BE (`weekend_close=false`), **250** mã TradFi. |
| **3** | `AGENTS.md §0.7(4)` vs Codebase | Quy tắc ghi Sandbox Mã Mới `< 72h` (đòn bẩy `≤ 3x`, TradFi `2x`, margin `≤ 10%`, cooldown 24h) | **CHƯA triển khai trong code** (đã gắn nhãn cảnh báo trong `AGENTS.md` để phiên sau không tưởng nhầm đã có gate này). |
| **4** | `core/bot.py` (`SLOT_A`) vs `ai/signal_aggregator.py` | `bot.py` khớp trực tiếp danh sách `signals` thô, trong khi `SignalAggregator._strategy_votes()` pop `mean_reversion BUY` | Gãy đối xứng giữa Pha 1 và Aggregator trên vũ khí `SLOT_A` ngược xu hướng — **đã vá trong `BOM #126B`**. |
| **5** | Macro / BTC / BearETF Shields vs `KB5 Smart Inversions` | Các khiên Macro chạy TRƯỚC khi `KB5` lật chiều tín hiệu, khiến lệnh sau khi lật chiều lách qua toàn bộ Macro Veto | **Đã vá (`BOM #126B`):** Bổ sung tái kiểm định `POST-KB5` ngay sau bước lật chiều. |
| **6** | `SignalAggregator._record_veto()` vs `ShadowPathfinder` | Veto tại `BOM101_WEAPON_DNA` và `WEAPON_PAUSED_LIFECYCLE` bỏ trống `weapon_id`, làm `ShadowPathfinder` gán nhầm nhãn (ví dụ `IRYSUSDT` `id=2400` thành `VK8` thay vì `VK6`) | **Đã vá (`BOM #126B`):** Truyền đầy đủ `weapon_id` vào mọi nhánh `_record_veto()`. |
| **7** | `core/bot.py` DB `pnl` vs `risk_manager.py` & `vietnamese_weapon_arsenal.py` | Khi `realized_pnl IS NULL`, `bot.py` đã lưu `pnl = net_pnl` (đã trừ phí), nhưng 2 module kia lại trừ `fee_usd` thêm lần nữa | Gây sai lệch thống kê/rủi ro trừ phí kép — **đã vá trong `BOM #126A`**. |
| **8** | `cloud_sync.py` `verify_license_tokens` vs `poll_and_execute_commands` | `verify_license_tokens` cho phép chạy nếu còn ít nhất 1 token hợp lệ, nhưng `poll_and_execute_commands` dừng bot ngay nếu token 1 bị revoke; hot-reload lại đọc sai key `"firebase_project_id"` thay vì `"project_id"` | Đã chuẩn hóa multi-token & sửa đúng key `"project_id"` trong **`BOM #126C`**. |
| **9** | `dashboard/templates/index.html` vs LIVE Spot / Snapshot lỗi | UI Live Spot (`margin_balance=null`) và lúc Futures snapshot tạm mất đã rơi về công thức tính PnL của chế độ DEMO | Đã khóa **fail-closed** trong **`BOM #126C`**, không bao giờ hiển thị số DEMO trên tài khoản LIVE. |

---

## 3. PHÂN TÍCH NGUYÊN NHÂN LẶP LẠI LỖI & HỒI QUY KHI NÂNG CẤP (6 ROOT CAUSES)

Trong quá trình nâng cấp nhanh từ V6.0 lên V6.4 (`BOM #30 → #126D`), các lỗi mới thường phát sinh ngay sau một lần vá vì 6 nguyên nhân gốc rễ sau:
1. **Nhầm kiểu dữ liệu & hệ quy chiếu (`Type / Coordinate Mixing`):**
   - Gán `bool` (`True`) đè lên `asyncio.Event` (`_streams_need_restart` — gây crash 4 lần đêm `25/11`); trộn `time.monotonic()` với Unix epoch; đổi tên biến JS (`fullSlBudget`) khiến hàm gọi thiếu giá trị; dùng `gamma` thô thay vì `gamma * sl_dist`.
2. **SSOT phân mảnh bị cập nhật lệch nhịp (`Split-Brain Distributed Tables`):**
   - Một khái niệm nằm rải rác ở 2–3 file (ví dụ danh sách ETF đảo chiều trong `scanner.py` thiếu `NVDD/TSLS/MSTZ`; làm tròn `ROUND_FLOOR` bị thiếu ở 1 nhánh; `KB5` `I_BRK_BUY` / `I_TF_SELL` lệch DNA trong `vietnamese_weapon_arsenal.py`).
3. **Thứ tự luồng điều khiển & `continue` sớm nuốt cờ trì hoãn (`Control-Flow Ordering & Deferred Flags`):**
   - Đặt cờ như `_sl_needs_qty_resize`, `FAIR ROTATION`, `JEV HOLD` deferred, hay chạy Macro Shields trước `KB5` rồi `continue` sớm ở vòng lặp khiến bước bảo vệ/tái kiểm định phía sau bị bỏ qua hoàn toàn.
4. **Gom nhóm quá rộng hoặc nhầm `AND` ↔ `OR` & Blind Direction:**
   - `is_strict_4h_bull and is_strict_15m_bull` làm lọt `ARIA/USDT` dù 4H đã `STRONG BULLISH`; `is_vk9_or_vk10_pos` gom nhầm vị thế `SLOT_B2`; `trap_ctx` kiểm tra không gắn với chiều lệnh.
5. **Điểm biên `0` / `None` / Hệ thống phân cấp Exception & Sót biến khi sửa gấp:**
   - Chia cho `vol_sma == 0`; bắt `ccxt.OperationFailed` nhưng không ngờ nó là lớp cha của `NetworkError`; sửa tay nhanh ở `BOM #126B` từng để lọt 2 lỗi `NameError` tạm thời trước khi bị Cổng #9 AST (`hard_constraints_gate.py`) tóm gọn.
6. **Unit Test kiểm tra khớp chuỗi (String-Match) thay vì kiểm tra hành vi thực thi:**
   - Test cũ chỉ grep sự tồn tại của dòng code thay vì dựng giả lập/mock gọi thẳng hàm để ép chạy qua đủ nhánh `LONG/SHORT` và 3 lớp tài sản (`ALTCOIN/MAJOR/TRADFI`).

---

## 4. BẢN ĐỒ 10 ĐIỂM NÓNG LIÊN KẾT CHÉO (COUPLED-HOTSPOT MAP)
> [!WARNING]
> **KHI SỬA HOẶC NÂNG CẤP CỘT A, PHẢI KIỂM TRA ĐỒNG THỜI CỘT B, C, D TRƯỚC KHI CHẠY TEST:**

| # | Điểm nóng đang sửa (Cột A) | File / Tầng kéo theo (Cột B) | Luồng / Bất biến dễ bị gãy (Cột C) | Kiểm chứng bắt buộc (Cột D) |
| :-: | :--- | :--- | :--- | :--- |
| **1** | Thêm / sửa Vũ Khí hoặc `KB5` | `core/vietnamese_weapon_arsenal.py`, `config/weapon_lifecycle.json`, `ai/signal_aggregator.py`, `core/bot.py` (`SLOT_A`) | Khớp chiều `side` trong `classify_signal_weapon`, `PAUSED/EXPERIMENTAL` lifecycle, và đồng bộ `SLOT_A` vs `_strategy_votes()` | `test_bom126.py`, `exhaustive_10axis_audit.py` |
| **2** | Macro / JEV MTF / BearETF Shields | `ai/jev_agent.py`, `ai/signal_aggregator.py` (`POST-KB5`), `core/scanner.py` | Khiên chạy trước `KB5` sẽ bị tín hiệu đảo chiều lách qua; logic `AND/OR` 4H vs 15M trong Hallucination Guard | `test_bom126.py`, kiểm tra cả thuận & ngược trend |
| **3** | Rào chắn & Danh mục TradFi / ETF 3x | `core/scanner.py`, `config/position_tuning.json`, `risk/risk_manager.py`, `core/quant_evolution_engine.py` | ETF nghịch (`NVDD/TSLS/MSTZ`), `sigma_step` TradFi, Opening Bell chỉ chặn `is_tradfi_stock` (miễn Hàng hóa 24/5), SL `[1.8%, 3.5%]` | `exhaustive_10axis_audit.py`, `test_bom125.py` |
| **4** | Quản lý SL / Cushion SL / Flash BE / MFE | `core/bot.py`, `core/binance_ws.py`, `risk/risk_manager.py` | `False Exits` tăng (`> 0`), cắt non `< +0.85%`, mất cờ `_sl_needs_qty_resize` do `continue`, lỗi `-2021` không Market Exit | `full_historical_signal_and_position_simulator.py` (**False Exits = 0**) |
| **5** | WebSocket `@bookTicker` & Event Loop | `core/binance_ws.py`, `core/bot.py`, `core/exchange.py` | Không được ghi đè `asyncio.Event` bằng `bool`; giữ 0 REST weight cho nhịp `2.0s` và bảo vệ Cầu dao IP `418/-1003` | `test_bom126.py` + `audit_system_integrity.py` |
| **6** | Tính PnL ròng & DB Schema | `core/bot.py`, `database/db_manager.py`, `risk/risk_manager.py`, `core/vietnamese_weapon_arsenal.py` | Cấm trừ phí 2 lần khi `realized_pnl IS NULL`; mọi query đọc DB từ UI/audit phải bật `PRAGMA query_only=ON` | `test_bom126.py` + `exhaustive_10axis_audit.py` |
| **7** | Shadow Pathfinder & Quant Evolution | `core/shadow_pathfinder.py`, `core/quant_evolution_engine.py`, `ai/signal_aggregator.py` (`_record_veto`) | Thiếu `weapon_id` tại `_record_veto()` làm sai nhãn cụm Alpha; biến động `CV < 58%` không được khóa cứng vĩnh viễn | `test_bom126.py` + `audit_system_integrity.py` |
| **8** | Cloud Sync, License & Hot Reload | `cloud_sync.py`, `core/optimizer.py` | Multi-token không được kill bot chỉ vì token phụ hết hạn; đúng key `"project_id"` | `test_bom126.py` (behavioral mocks) |
| **9** | Dashboard API & Giao Diện Web | `dashboard/app.py`, `dashboard/templates/index.html`, `dashboard/templates/pipeline_map.html` | UI LIVE không bao giờ rơi về công thức DEMO khi `margin_balance=null`; giữ regex log song ngữ | `test_bom126.py` + kiểm tra AST/JS vars |
| **10** | Deploy & Quy trình dọn Workspace | `deploy_web_client.py`, `tools/clean_workspace.py`, `AGENTS.md` / `GEMINI.md` | Thiếu file trong manifest `deploy_web_client.py`; `AGENTS.md` ≠ `GEMINI.md` hoặc vượt `21 KB` (bị cắt cụt khi nạp phiên) | `audit_system_integrity.py`, byte-size check `< 21,000 B` |

---

## 5. CHECKLIST 6 CỔNG XÁC MINH TRƯỚC KHI ĐÓNG PHIÊN HOẶC DEPLOY
Mọi thay đổi mã nguồn trên PC1 bắt buộc vượt qua đủ **6 cổng Offline** trước khi xin phép người dùng chạy `deploy_web_client.py`:
1. **Unit & Behavioral Tests:** `venv\Scripts\python.exe -m unittest tests/test_bom126.py tests/test_bom125.py` (`30/30 OK` hoặc hơn).
2. **Quét 10 Trục Toàn Kho Code:** `venv\Scripts\python.exe tools/exhaustive_10axis_audit.py` (**`10/10 AXES PASSED | Critical Errors=0 | Advisory Warnings=0`**).
3. **Cổng Rào Chắn Cứng:** `venv\Scripts\python.exe tools/hard_constraints_gate.py` (**`11/11 PASSED`** — chặn AST NameError, time_based_exits, SL bounds, Binance filters).
4. **Kiểm Toán Toàn Vẹn Hệ Thống:** `venv\Scripts\python.exe tools/audit_system_integrity.py` (**`6/6 PASSED`**).
5. **Mô Phỏng Lịch Sử Chuẩn Quỹ:** `venv\Scripts\python.exe tools/full_historical_signal_and_position_simulator.py` (**`False Exits = 0 / 219 (0.0%)`**, không rớt Net PnL).
6. **Sạch Workspace & Đồng Bộ Quy Tắc:** Chạy `venv\Scripts\python.exe tools/clean_workspace.py`, xác nhận `PC1_BOT_PROCS=0`, `AGENTS.md == GEMINI.md` và cả 2 `< 21,000 bytes`. Khi người dùng duyệt deploy: chạy `deploy_web_client.py` (xác nhận SHA-256 `83/83`), sau đó trên PC2 chạy `Fix_Time.bat` + `RESTART.bat`.

---

## 6. BỔ SUNG HẬU PHIÊN 16 (`BOM #128 → #133`: CHỐNG LỖI THĂNG HẠNG LAB TỰ ĐỘNG)
- **`BOM #128–#132`:** Khóa `0.40×TP1` runner SL, sửa 29 lỗi ngầm liên tầng (`VK11` Quantum, `VK12` `votes.pop()`, `JEV Hallucination Guard 0.65`, dead-code `RSI>=70`), đảo dấu Cầu dao liên tài sản trên 11 Bear ETF, bỏ `continue` chặn TP1 lệnh tay, dọn sạch `< 0.08` ATR `%` & lỗ hổng đảo chiều kép Opening Bell + KB5.
- **`BOM #133` (Cổng 6 Tự Kiểm Trước Thăng Hạng):** `_build_8station_blueprint()` tự phân biệt `SLOT_B2` cho cụm đảo chiều; `promote_lab_to_dynamic_weapon()` ép chạy **Cổng 6 (`run_8station_pre_promotion_dry_run`)** trên `SignalAggregator + QuantumPathSimulator` (thread-local `_DRY_RUN_LOCAL`); `update_weapon_lifecycle_state()` ép **Official Graduation Guard** (`N_live >= 15`, `Net > 0$`, `WR >= 55%` hoặc `PF >= 1.50`, `SL <= 30%`).
- **Quy chuẩn chi tiết & Lộ trình Phòng LAB Tự Chủ (không lặp lại):** Xem [`docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md` §§7–9](file:///d:/TRADE/docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md).
