# TRADEMATRIX QUANT ECOSYSTEM — SSOT MA TRẬN TAM TẦNG BẢO VỆ VỐN & CHỐT LÃI TOÀN DIỆN V4.1
> **Single Source of Truth (SSOT) Quy Chuẩn Thoát Lệnh Đa Phân Tầng Thực Chiến.**  
> *Bảo vệ 100% tài nguyên vốn từ dưới +0.85% đến đỉnh sóng Runner. CẤM MỌI PHIÊN AI MỚI TỰ Ý XÓA HOẶC NHẦM LẪN LÀ LỖI!*

---

## 🏛️ 0. TÔN CHỈ THIẾT KẾ CỐT LÕI
Hệ thống thoát lệnh TradeMatrix vận hành theo **Nguyên lý Đa Tầng Bất Đối Xứng (Multi-Tier Asymmetric Convexity)**:
1. **Khi lệnh mới vào (0.0% đến +0.35% MFE):** Cho lệnh không gian thở tự nhiên theo sóng nến 15M, loại bỏ hoàn toàn các cơ chế cắt non mù quáng theo thời gian (`doa_15m/25m/35m` đã bị đào thải ở Rule 0.1.1).
2. **Khi lệnh có lãi non (+0.12% đến +0.80% MFE):** Không phó mặc thả nổi. Nếu thị trường xuất hiện nến ChoCH M1 đảo chiều đối kháng hoặc Vua BTC bão bơm/xả, kích hoạt **Chốt Non Tiền Tươi (ChoCH Early Profit Lock)** hoặc **Cầu Dao Cứu Hộ BTC** để khóa lãi dương sau phí!
3. **Khi lệnh đạt MFE +0.55% đến +0.80%:** Kích hoạt **Đệm Mềm Cushion SL (-0.25%)** để triệt tiêu nguy cơ lỗ sâu nếu giá quay đầu.
4. **Khi lệnh đạt MFE từ +0.85% đến +1.15% (sau 4.5 phút):** Kích hoạt **Flash Hard BE (+0.22% Net BE)** theo công thức thích ứng ATR $\max(0.85\%, 0.85 \times \text{ATR})$ để bảo toàn thành quả cho TradFi Cổ phiếu Mỹ và tài sản thanh khoản cao.
5. **Khi lệnh chạm TP1 (+1.5% đến +2.2%):** Chốt 50% tiền tươi và kích hoạt Trailing Stop + **CRR Snell Optimal Peak Exit** để chốt đỉnh sóng Runner khi có râu xả $\ge 35\%$.

---

## 📊 I. BẢN ĐỒ CHI TIẾT MA TRẬN 5 CẤP THOÁT LỆNH

```mermaid
flowchart TD
    E["0. Vào Vị Thế (Entry)"] --> L1{"1. Vùng Lãi Non: +0.12% -> +0.80%"}
    
    L1 -->|"M1 Xuất Hiện ChoCH Đối Kháng (RVol >= 1.5x, Thân >= 60%)"| A1["🎯 ChoCH Early Profit Lock: Chốt Non Tiền Tươi (+0.15% -> +0.45% sau phí)"]
    L1 -->|"BTC Bão Bơm/Xả >= 0.85%"| A2["🚨 Cầu Dao Liên Tài Sản: Thoát Khẩn Cấp Tránh Squeeze"]
    L1 -->|"MFE Chạm +0.80% (hoặc +0.55% có Râu >= 35%)"| A3["🛡️ Cushion SL: Siết SL Về -0.25% (Đệm Mềm Bảo Vệ)"]
    
    A3 --> L2{"2. Vùng Hard BE: +0.85% -> +1.15%"}
    L2 -->|"MFE >= max(0.85%, 0.85*ATR) & Held >= 4.5m"| B1["🔒 Flash Hard BE: Khóa Cứng Hòa Vốn (+0.22% Net BE)"]
    L2 -->|"Râu Cản Iceberg >= 40% ở +0.80% -> +0.95%"| B2["🧊 Iceberg Wick Ratchet: Co Hẹp SL Vi Mô Về -0.60 ATR"]
    
    B1 --> L3{"3. Vùng Chốt Lời TP1 & Runner: >= +1.50%"}
    L3 -->|"Chạm TP1 (+1.50% -> +2.20%)"| C1["💰 Chốt 50% Khối Lượng Tiền Tươi & Kích Hoạt Trailing Stop"]
    L3 -->|"Nến Xuất Hiện Râu Xả Đỉnh >= 35% hoặc g(S) >= C(S)"| C2["🎯 CRR Snell Optimal Peak Exit: Chốt Đỉnh Sóng Runner"]
```

---

## 🔬 II. CHI TIẾT TỪNG CƠ CHẾ DƯỚI MỐC +0.85% MFE

### 1. `🎯 ChoCH Early Profit Lock` (Chốt Non Tiền Tươi Vi Cấu Trúc)
* **Vị trí code:** [`core/bot.py:6435 - 6480`](file:///d:/TRADE/core/bot.py#L6435-L6480)
* **Ngưỡng kích hoạt:** PnL ròng sau phí từ **`+0.12%` đến `+0.80%`**, đỉnh MFE từng đạt $\ge +0.35\%$.
* **Điều kiện toán học:**
  - Nến M1 đã đóng xuất hiện thân nến đặc $\ge 60\%$ đối kháng với vị thế.
  - Volume nến M1 đột biến $RVol_{M1} \ge 1.50x$ (Major $1.60x$, TradFi $1.35x$).
  - Giá sụt giảm từ đỉnh $\ge 0.12\%$ (ở vùng lãi mỏng $\le 0.35\%$) hoặc sụt giảm $\ge 0.22\%$ (ở vùng lãi trung gian $+0.35\% \rightarrow +0.80\%$).
* **Hành động:** Đóng Market ngay lập tức để đút túi tiền tươi.
* **Chứng thực thực chiến PC2:** `HYPE/USDT` (14/11) chốt lãi non `+0.0566 USDT` (+0.27%) trước khi giá quay đầu.

### 2. `🚨 Cầu Dao Cứu Hộ Liên Tài Sản` (Lead Benchmark Squeeze & Dump Shield)
* **Vị trí code:** [`core/bot.py:6705 - 6745`](file:///d:/TRADE/core/bot.py#L6705-L6745)
* **Ngưỡng kích hoạt:** Lãi mỏng hoặc chớm âm nhỏ khi đang giữ vị thế Altcoin.
* **Điều kiện toán học:**
  - Short Altcoin nhưng Vua Bitcoin (`BTC/USDT`) bão bơm $\ge +0.85\%$ trên 15M/1M.
  - Long Altcoin nhưng `BTC/USDT` bão xả $\le -0.85\%$.
* **Hành động:** Thoát Market ngay để tránh bị cuốn phăng trong các cú quét bão sàn.
* **Chứng thực thực chiến PC2:** `IOTA/USDT` (13/11) thoát lỗ vỏn vẹn `-0.0115 USDT` khi BTC bão bơm +0.89%.

### 3. `🛡️ Cushion SL` (Đệm Mềm Chống Sập Vốn)
* **Vị trí code:** [`core/bot.py:9286`](file:///d:/TRADE/core/bot.py#L9286) & [`core/bot.py:9412`](file:///d:/TRADE/core/bot.py#L9412)
* **Ngưỡng kích hoạt:** MFE đạt **`+0.80%`** (hoặc chỉ cần `+0.55%` kèm râu đảo chiều $\ge 35\%$ hoặc giá thủng EMA20), giữ $\ge 3.0$ phút.
* **Hành động:** Kéo SL từ mức xa ban đầu ($-1.5\% \rightarrow -3.5\%$) siết chặt về **`-0.25%`** (hoặc `-0.40%`).
* **Ý nghĩa:** Bảo vệ $98.5\%$ vốn gốc, biến cú sập ngược thành vết trầy xước không đáng kể.

### 4. `🧊 Iceberg Reversal Wick Ratchet` (Rào Chắn Râu Cản Tảng Băng Chìm)
* **Vị trí code:** [`core/bot.py:9372 - 9380`](file:///d:/TRADE/core/bot.py#L9372-L9380)
* **Ngưỡng kích hoạt:** Lãi thực tế `+0.80%` đến `+0.95%`, giữ $\ge 3.0$ phút.
* **Điều kiện toán học:** Râu nến cản đối kháng $\ge 40\%$ (dấu hiệu lệnh ẩn Iceberg chặn đường).
* **Hành động:** Co hẹp SL vi mô dí sát về `-0.60 ATR` hoặc cách giá hiện tại `+0.40%`.

### 5. `🛡️ ChoCH Net BE & MFE Drawdown Ratchet` (Tấm Khiên Thép Triệt Tiêu Vùng No Man's Land)
* **Vị trí code:** [`core/bot.py:6698 - 6715`](file:///d:/TRADE/core/bot.py#L6698-L6715) & [`core/bot.py:9455 - 9630`](file:///d:/TRADE/core/bot.py#L9455-L9630)
* **Bối cảnh ra đời:** Khắc phục bài học lệnh `HOME/USDT` (16/11) từng đạt đỉnh $MFE = +0.75\%$ nhưng bị ChoCH M1 giật ngược và dời SL về vùng âm $-0.20\%$, khiến dính SL lỗ $-0.1676\text{ USDT}$.
* **Quy tắc bất biến (Steel Floor Invariant):**
  1. **ChoCH Net BE Lock:** Nếu vị thế ĐÃ TỪNG ĐẠT $MFE \ge +0.55\%$, khi ChoCH M1 đối kháng xuất hiện ($RVol \ge 1.5x$), mức SL sàn BẮT BUỘC neo tối thiểu ở **`Net BE (+0.10%)`**, **TUYỆT ĐỐI CẤM dời SL về vùng âm (`-0.20%`)**!
  2. **MFE Drawdown Ratchet:** Khi vị thế đạt $MFE \ge +0.55\%$ (với Altcoin $ADX < 20$ hoặc TradFi) hoặc $MFE \ge +0.75\%$ (với Altcoin $ADX \ge 20$), nếu giá sụt giảm từ đỉnh $(Peak\text{ }MFE - Current\text{ }PnL) \ge 0.25\%$ và vị thế vẫn đang dương $\ge +0.10\%$, tự động nâng SL sàn lên **`Net BE (+0.10%)`**.
* **Ý nghĩa:** Không bao giờ để một vị thế đã có lãi lớn $+0.55\% \rightarrow +0.80\%$ bị trôi ngược về lỗ, trong khi vẫn giữ nguyên không gian thở để các siêu sóng tiếp tục bứt phá lên TP1.

---

## 🔒 III. BẢN CHẤT FLASH HARD BE Ở MỐC +0.85% (BÀI HỌC V4.0)

### 1. Công thức toán học trong code:
* **Vị trí code:** [`core/bot.py:9264 - 9276`](file:///d:/TRADE/core/bot.py#L9264-L9276) & [`core/bot.py:9390 - 9402`](file:///d:/TRADE/core/bot.py#L9390-L9402):
  $$\text{Điều kiện kích hoạt Hard BE} = (\text{profit\_pct} \ge \text{be\_hard\_trig}) \;\lor\; (\text{profit\_pct} \ge +1.15\%) \;\lor\; (\text{profit\_pct} \ge \max(0.0085, 0.85 \times \text{ATR}))$$
  với điều kiện kèm theo: $\text{held\_minutes} \ge 4.5\text{ phút}$.

### 2. Vì sao tuyệt đối cấm xóa mốc `+0.85%`?
1. **Đối với TradFi Cổ Phiếu Mỹ (NVDA, TSLA, AAPL, QQQ...) & Hàng Hóa:**
   - Biên độ ATR 15M của TradFi rất thấp ($0.6\% - 0.9\%$).
   - Sóng biến động trong phiên thường chỉ đạt $+0.85\% - +1.00\%$ rồi rung lắc.
   - Nếu ép cứng phải đợi $+1.15\%$ mới khóa Hard BE thì **TradFi không bao giờ chạm được Hard BE**, khiến vị thế đang lãi biến thành lỗ!
2. **Đối với Altcoin biến động cao (ATR >= 3.0%):**
   - Công thức `0.85 * ATR` tự động giãn thành $0.85 \times 3.0\% = \mathbf{+2.55\%}$.
   - Do đó, Altcoin biến động lớn hoàn toàn không bị kẹt ở $+0.85\%$ mà được nới không gian thở rất rộng.
3. **Đối với lệnh `XRP/USDT` hôm 15/11:**
   - Lệnh Short XRP chạm $+0.85\%$ sau 4.5 phút, kích hoạt Hard BE kéo SL về $+0.22\%$.
   - Khi có râu giật quét SL, lệnh chốt lãi xanh **`+0.0538 USDT`**. Đây là lệnh THẮNG bảo toàn vốn thành công theo chuẩn Quỹ, **tuyệt đối không được coi là lỗi cắt non**!

---

## 🚫 IV. QUY CHUẨN ĐỐI SOÁT DÀNH CHO MỌI PHIÊN AI MỚI TRÊN ANTIGRAVITY IDE
*Mọi phiên chat AI mới khi đọc mã nguồn hoặc phân tích lệnh đóng BẮT BUỘC TUÂN THỦ:*
1. **CẤM NHẦM LẪN:** Tuyệt đối không nhầm lẫn giữa *"Khóa hòa vốn non mù quáng trước 4.5 phút hoặc dưới +0.65% MFE"* (đã bị cấm ở Rule 0.1.2) với *"Flash Hard BE thích ứng ATR sau 4.5 phút"* ($\max(0.85\%, 0.85 \times \text{ATR})$).
2. **CẤM TỰ Ý ĐỀ XUẤT XÓA BỎ:** Cấm mọi đề xuất xóa bỏ mốc `+0.85%` trong [`core/bot.py:9270`](file:///d:/TRADE/core/bot.py#L9270) và [`core/bot.py:9396`](file:///d:/TRADE/core/bot.py#L9396).
3. **HIỂU RÕ VÙNG DƯỚI +0.85%:** Vùng dưới $+0.85\%$ được bảo hộ độc lập bởi `ChoCH Early Profit Lock` và `Cushion SL`. Nếu có ChoCH đối kháng, bot được quyền chốt non bảo toàn tiền tươi!
