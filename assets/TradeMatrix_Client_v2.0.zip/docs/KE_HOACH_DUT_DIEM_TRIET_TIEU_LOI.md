# KẾ HOẠCH DỨT ĐIỂM: TÔN CHỈ TRIỆT TIÊU LỖI ĐẦU-CUỐI & KIỂM TOÁN VÒNG ĐỜI TÍN HIỆU
> **Single Source of Truth (SSOT) — Cẩm Nang Bất Biến Ngăn Ngừa Lỗi Tái Diễn Qua Mọi Phiên Làm Việc**
> *Tài liệu bắt buộc đọc đối với mọi phiên AI mới trước khi tiến hành sửa đổi mã nguồn hoặc đề xuất logic.*

---

## 🏛️ I. TẠI SAO TRẢI QUA NHIỀU PHIÊN MÀ VẪN CHƯA HẾT LỖI? (4 CĂN NGUYÊN GỐC RỄ)

Kiểm toán định lượng độc lập trên toàn bộ lịch sử các phiên (từ Phiên 1 đến Phiên 6) đã bóc tách chính xác 4 căn nguyên khiến lỗi liên tục xuất hiện:

### 1. Hiệu ứng "Mở Cửa Xả Lũ" — Lỗi Sau Bị Che Khuất Bởi Lỗi Trước (Cascading Latent Bugs)
* **Bản chất kiến trúc:** TradeMatrix là chuỗi liên hoàn 8 tầng:
  $$\text{Scanner} \rightarrow \text{Data Collector} \rightarrow \text{AI Ensemble/JEV} \rightarrow \text{Aggregator} \rightarrow \text{Pre-Trade Gate} \rightarrow \text{Quantum Gate} \rightarrow \text{M1 Sniper} \rightarrow \text{Execution}$$
* **Cơ chế che giấu lỗi:** Trước đây, hệ thống có các rào chắn thô (cắt theo thời gian `doa_time_based`, chặn cứng `Fading Short`, hoặc vô hiệu hóa JEV). Các rào chắn thô này **chặn đứng 95% tín hiệu ngay từ Tầng 3 và Tầng 4**. Do tín hiệu không bao giờ chạm tới Tầng 5 (Pre-Trade Gate) hay Tầng 6 (Quantum Gate), nên những đoạn code ở các tầng sau chưa từng được kích hoạt trong thực tế.
* **Khi sửa tầng trước, tầng sau mới lộ lỗi:** Khi các phiên gần đây (Phiên 3, 4) gỡ bỏ các rào chắn sai lầm và cho phép dòng tiền cá mập (`Momentum Ride`, `Fading Short`) đi qua, dữ liệu thực tế mới lần đầu tiên chảy tới Pre-Trade Gate và Quantum Gate. Lúc này, các lỗi logic ngầm vốn nằm im từ trước (như lỗi thiếu điều kiện so sánh Tường Sổ Lệnh trong Kịch bản B, hay lỗi triệt tiêu ATR sàn 1H trong Quantum Gate) mới bộc lộ ra trên Live log.

### 2. Tư Duy "Sửa Ngọn Không Sửa Gốc" (Symptom-Based Patching Thiếu End-to-End Tracing)
* **Thói quen xấu của AI:** Khi thấy lỗi A, AI chỉ sửa đúng dòng code gây ra lỗi A, mà không đặt câu hỏi: *"Sau khi sửa dòng này, tín hiệu đi tiếp sẽ gặp những hàm nào, biến nào, cờ nào?"*.
* **Vi phạm Exhaustive Branch Coverage (Rào chắn 10 Rule 0.8):** 
  - Sửa chiều BUY nhưng quên chiều SELL.
  - Sửa Altcoin nhưng quên TradFi Cổ phiếu Mỹ và Major Crypto.
  - Sửa nhánh chính (Kịch bản A) nhưng bỏ quên nhánh phụ (Kịch bản B và Kịch bản C).

### 3. Khoảng Cách Giữa "Mô Phỏng Nến Tĩnh" Và "Biến Động Thực Chiến Thời Gian Thực"
* **Mô phỏng (Simulator):** Chạy trên nến tĩnh đã đóng (Closed Candles M1/M15) và bảng lệnh trong Database. Không có độ trễ mạng, không có nến nhảy từng giây, không có hiện tượng cá mập kê tường ảo rồi rút lệnh sau 2 giây. Do đó, Simulator luôn báo Pass 100%.
* **Thực chiến PC2 (Live Daemon):** Nhận WebSocket orderbook thời gian thực, nến dao động liên tục, trượt giá slippage, và đồng hồ hệ thống có thể bị trôi (`clock drift`). Lỗi thực chiến thường phát sinh tại các "điểm tiếp xúc động" (Dynamic Touchpoints) này.

### 4. Bệnh Tự Mãn & "Báo Cáo Sớm" Của AI (Lý Do AI Trust Score Bị Ghim Ở 45%)
* Các phiên AI trước có xu hướng vội vã: Sửa xong một vài dòng code, chạy cú pháp AST thấy xanh là vội vàng kết luận "Hệ thống đã hoàn hảo 100%, không còn lỗi nào".
* Sự khẳng định vội vã khi chưa đối soát log live thực tế khiến người dùng mất niềm tin khi bot treo thực tế lại phát sinh lỗi.

---

## 🛑 II. MA TRẬN 3 NGUYÊN TẮC THÉP BẮT BUỘC ĐỂ DỨT ĐIỂM LỖI

Mọi phiên làm việc mới khi chạm vào code BẮT BUỘC tuân thủ nghiêm ngặt 3 nguyên tắc sau:

### ⚡ NGUYÊN TẮC 1: KIỂM TOÁN VÒNG ĐỜI TÍN HIỆU ĐẦU-CUỐI (END-TO-END SIGNAL LIFECYCLE AUDIT)
Khi sửa đổi bất kỳ logic tín hiệu nào (BUY, SELL, FADING, MOMENTUM, WATERFALL), AI **BẮT BUỘC PHẢI TRACE 100% HÀNH TRÌNH** qua 8 trạm kiểm soát:
1. **Trạm 1 (Scanner):** Cặp giao dịch có nằm trong Ma Trận 3 Lớp Tài Sản không? Có bị chặn bởi Weekend Shield hay Sandbox không?
2. **Trạm 2 (Multi-Strategy & AI Ensemble):** Điểm số chiến lược kỹ thuật, AI Bias, và phán đoán của Ollama JEV Agent có đồng nhất không?
3. **Trạm 3 (Aggregator):** Các cờ metadata (`is_momentum_ride`, `is_waterfall_short`, `is_fading_short`, `is_oversold_bounce`, `is_trap_entry`) có được đóng gói đầy đủ vào `signal.metadata` không?
4. **Trạm 4 (Pre-Trade Safety Gate):** 
   - Kiểm tra `sig_adx`: Bắt buộc lấy $\max(tactical\_adx, macro\_adx)$.
   - Kiểm tra Tường Sổ Lệnh (Z-Score >= 3.0): Phải luôn so sánh với ngưỡng dòng tiền Taker `cvd_fuel_thresh` (Nếu Taker $\ge 60\%$, công nhận nuốt tường, cấm chặn oan!).
5. **Trạm 5 (Quantum Gate):** Đo lường Monte Carlo 40 bước: Sàn biến động `q_atr_pct = max(raw_q_atr_pct, eff_q_atr_pct)` không bao giờ được phép bị triệt tiêu về 0. Fallback `q_adx` đầy đủ.
6. **Trạm 6 (M1 Sniper Stalking):** Đặt lệnh Limit Maker rình rập:
   - Bộ đệm nhiễu 45s chỉ áp dụng cho biến động bình thường.
   - Khi có dòng tiền cực đoan (`is_extreme_flow`, Taker đối kháng $\ge 80\%$), phải hạ thời gian chờ về 0s để rút lệnh tức thì!
7. **Trạm 7 (Execution & Sàn Binance):** Kiểm toán 5 bộ lọc sàn (`LOT_SIZE`, `MIN_NOTIONAL >= 5$`, `PRICE_FILTER`, `PERCENT_PRICE`, `MAX_NUM_ALGO_ORDERS <= 10`).
8. **Trạm 8 (Position Manager):** Bảo toàn Tam Tầng SL V4.1 (`ChoCH Lock +0.12% -> +0.80%`, `Cushion SL -0.25%`, `Flash Hard BE +0.85%`).

---

### ⚡ NGUYÊN TẮC 2: QUY TẮC BAO PHỦ TOÀN PHẦN (EXHAUSTIVE BRANCH COVERAGE)
* Khi sửa logic cho chiều **BUY**, BẮT BUỘC mở nhánh **SELL** ra đối soát song song.
* Khi sửa logic cho **Crypto Altcoins**, BẮT BUỘC kiểm tra xem có ảnh hưởng tiêu cực tới **TradFi Cổ Phiếu Mỹ** và **Major Crypto (BTC/ETH/SOL)** hay không.
* Khi sửa nhánh chính (Kịch bản A), BẮT BUỘC rà soát toàn bộ các khối `elif`, `else` (Kịch bản B, C) và khối `except / fallback`.

---

### ⚡ NGUYÊN TẮC 3: ĐỐI SOÁT TRỰC TIẾP TRÊN LOG RUNTIME PC2
* **Tuyệt đối không chỉ tin vào Simulator:** Simulator là điều kiện CẦN, đọc Live Log trên PC2 là điều kiện ĐỦ.
* Trước khi kết luận một phiên sửa lỗi:
  1. Kiểm tra tiến trình PC2 đã nạp code mới vào RAM chưa: `StartTime(Process) >= ModifiedTime(File)`. Nếu chưa, bắt buộc yêu cầu chạy `RESTART.bat`.
  2. Quét 500 dòng log gần nhất trên PC2: Bảo đảm vòng tuần hoàn Scanner $\rightarrow$ Aggregator $\rightarrow$ Sniper $\rightarrow$ Position Manager diễn ra trơn tru, không có lỗi ngoại lệ ngầm.
  3. Kiểm tra sai lệch thời gian: `Offset < 1000ms`. Nếu offset $\ge 1000ms$, bắt buộc cảnh báo chạy `Fix_Time.bat`.

---

## 📋 III. BẢNG CHECKLIST 7 BƯỚC NGHIỆM THU TRƯỚC KHI BÁO CÁO NGƯỜI DÙNG

| Bước | Hạng Mục Kiểm Tra | Công Cụ / Tệp Thực Thi | Tiêu Chuẩn Nghiệm Thu |
| :---: | :--- | :--- | :--- |
| **1** | **Cú pháp & Biến toàn cục** | `python -c "import ast, symtable..."` | 100% tệp Python sạch 0 lỗi scope/NameError |
| **2** | **11 Rào Chắn Cứng Codebase** | `python tools/hard_constraints_gate.py` | Đạt **11/11 PASSED (100%)** |
| **3** | **Kiểm định Zero-Regression** | `python tools/pre_deployment_unified_simulator.py` | 0 lệnh thắng bị biến thành thua (0 / 523 lệnh) |
| **4** | **Kiểm định Ma Sát Thực Chiến** | `python tools/true_signal_simulator.py` | Net PnL và Win Rate cải thiện trên cả 3 lớp tài sản |
| **5** | **Đồng Bộ SMB & Cloudflare** | `python deploy_web_client.py` | 100% SHA-256 khớp giữa PC1 và PC2; Backup Ổ D cập nhật |
| **6** | **Kiểm Toán Tiến Trình RAM PC2** | `tools/daily_auditor.py` & Live Log | RAM nạp mã mới; Clock Offset < 1000ms |
| **7** | **Dọn Sạch Không Gian Làm Việc** | `python tools/clean_workspace.py` | Xóa 100% script tạm thời trong `scratch/` |

---

> [!CAUTION]
> **TÔN CHỈ THỰC THI CHO MỌI PHIÊN AI MỚI:**
> Không bao giờ tự ý tuyên bố "hệ thống đã hết 100% lỗi" nếu chưa thực hiện đủ 7 bước nghiệm thu trên. Tôn trọng dữ liệu thực tế, giữ tâm thế cẩn trọng, bảo vệ tài khoản người dùng là ưu tiên tối thượng!
