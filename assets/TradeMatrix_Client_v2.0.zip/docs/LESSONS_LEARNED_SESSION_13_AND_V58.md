# TRADEMATRIX QUANT ECOSYSTEM — BÀI HỌC THỰC CHIẾN & ĐỐI SOÁT ĐỊNH LƯỢNG V5.8 (PRE_V56 SURGICAL RELEASE)
> **Tài liệu SSOT Đúc kết Toàn diện Phiên 13 & Tổng Hợp Đối Chiếu 4 Phiên: "Khôi Phục Nền Tảng Sạch `PRE_V56`, Bảo Tồn 100% Dữ Liệu Shadow Pathfinder (274 Mẫu), Phẫu Thuật 7 Điểm Vi Cấu Trúc Đồng Thuận Và Loại Bỏ 3 Đề Xuất Xung Đột Gây Hại".**  
> *Kế thừa tri thức, nhìn thẳng vào sự thật, loại bỏ ảo tưởng phức tạp hóa 10 Setups V5.6, đồng bộ hóa 100% giữa PC1 Dev và PC2 Live Daemon.*

---

## 🏛️ I. TỔNG QUAN VẬN HÀNH, KHÔI PHỤC `PRE_V56` & BẢO TỒN DỮ LIỆU SHADOW PATHFINDER
- **Vốn khởi điểm (Initial Capital):** 100.00 USDT.
- **Tài khoản thực tế Live PC2 (Equity):** ~407.37 - 409.59 USDT (Tăng trưởng ròng **> +307%**).
- **Trạng thái vị thế Binance Futures Live:** 0 vị thế mở (Flat hoàn toàn).
- **Quyết định Kiến trúc Chiến lược:**
  1. **Khôi phục nền tảng sạch `PRE_V56_UPGRADE_20261118_215459`:** Loại bỏ hoàn toàn sự phức tạp hóa quá mức (Over-engineering & Combinatorial Explosion) của đợt chia 10 Setups V5.6, giữ nguyên nền tảng V5.5 Institutional Release thanh thoát kèm cỗ máy `ShadowPathfinder`.
  2. **Bảo tồn 100% tài sản dữ liệu thực tế `shadow_pathfinder_logs` (274+ mẫu):** Sao lưu dự phòng ra 3 định dạng (`.json`, `.csv`, `.sql`) trên ổ D của PC2 (`BACKUP_MASTER_TRADE_AND_WEB`) và bảo toàn nguyên vẹn trong `trade_bot.db` trên PC2 Live.

---

## 🩸 II. GIẢI PHẪU 4 CA LỆNH THỰC CHIẾN & PHÂN LOẠI BẢN CHẤT

| Ca Lệnh | Cặp & Chiều | Entry $\to$ Exit | MFE $\to$ MAE | PnL Thực Tế | Bản Chất Vi Cấu Trúc & Hành Vi Giá Sau Khi Đóng |
| :---: | :---: | :---: | :---: | :---: | :--- |
| **1** | `LYN/USDT` **SHORT** | `0.017060` $\to$ `0.017080` | **`+0.64%`** $\to$ `-0.12%` | `-0.1531$` | **Vào đúng đỉnh (Setup Fading Short)**, đã lãi `+0.64%`, bị code cũ `is_mfe_ratchet_breached` tự ý xả Market âm khi dãn spread. Ngay sau đó giá sập về `0.01691` (**đạt trọn TP1 +0.88%**). |
| **2** | `SOPH/USDT` #1 **SHORT** | `0.001013` $\to$ `0.001015` | **`+0.69%`** $\to$ `-0.20%` | `-0.1877$` | **Vào đúng đỉnh**, đã lãi `+0.69%`, bị `is_mfe_ratchet_breached` cắt Market âm ở giây 102. Ngay sau đó giá sập về `0.001008` (**đạt trọn TP1 +0.88%**). |
| **3** | `SOPH/USDT` #2 **SHORT** | `0.001043` $\to$ `0.001059` | `+0.00%` $\to$ `-1.53%` | `-1.1287$` | Rơi vào 20% xác suất sóng tiếp diễn (Continuation Surge). Cầu dao `Deep Loss Circuit Breaker (-1.00%)` cắt ở phút 4.4 trước khi giá bay lên `0.001078` (cứu 56% vốn so với Full SL `-3.54%`). |
| **4** | `AKT/USDT` **LONG** | `0.513800` $\to$ `0.508500` | `+0.00%` $\to$ `-1.05%` | `-0.8682$` | **Lỗi bắt dao rơi ngược JEV 4H SELL 85%**: Do `regime='high_volatility'` làm tê liệt `is_jev_downtrend_shield_active`, để nhánh `I_TF_SELL -> BUY` lật sang Long. |

---

## 🛠️ III. 7 BẢN VÁ PHẪU THUẬT ĐỒNG THUẬN TRÊN NỀN TẢNG SẠCH `PRE_V56`

Sau khi đối chiếu chéo toàn bộ 4 phiên chat (`4ce00e56`, `adc02a28`, `faeae23f`, `73a79e1e`), hệ thống chỉ áp dụng **7 bản vá phẫu thuật chuẩn xác 100%** (False Exits = 0 / 219):

1. **Xóa sổ vĩnh viễn `is_mfe_ratchet_breached` (`core/bot.py:10308 & 10466`):**
   - Triệt tiêu hoàn toàn hành vi tự ý xả Market âm khi `MFE >= +0.50%` và giá thoái lui nhẹ về dưới `+0.10%`. Trả MFE Ratchet về đúng SSOT V4.1 Section 5 (chỉ nâng lệnh điều kiện Stop-Market bảo vệ vốn trên sàn Binance).
2. **Xóa sổ bản sao cắt Market âm `🚨 ChoCH Breach Exit` (`core/bot.py:7053 & 7177`):**
   - Trong `_check_microstructure_choch_invalidation()`, khi `pnl_pct < 0.0010` (dưới mức Net BE `+0.10%`) hoặc `is_already_breached == True`, bắt buộc `return False` để Cushion SL (`-0.25%`) hoặc SL sàn ban đầu bảo vệ vị thế, tuyệt đối cấm xả Market âm.
3. **Vá điểm mù `JEV MTF Trend Shield` cả 2 chiều Long/Short (`ai/signal_aggregator.py:3350, 4050, 4174`):**
   - Kích hoạt lá chắn khi `orig_jev_vote >= 0.70` (Uptrend Shield) hoặc `orig_jev_vote <= -0.70` (Downtrend Shield) ngay cả khi `regime == 'high_volatility'` (`macro_adx >= 28.0` hoặc `c_recent_pump/dump >= 2.0%`), đồng thời khóa cứng nhánh Inversion TF không cho bẻ lái ngược JEV 4H $\ge 70\%$.
4. **Triệt tiêu lỗi Crash Runtime `UnboundLocalError: c_recent_pump` & `rvol_m1_val` (`ai/signal_aggregator.py:3132` & `core/bot.py:8038`):**
   - Khởi tạo mặc định `c_recent_pump = 0.0`, `c_recent_dump = 0.0` trước khối `if final_signal.signal != Signal.HOLD:`, và khởi tạo `rvol_m1_val = 1.0` trước `if len(closed_m1) >= 11:`.
5. **Khắc phục đứt gãy hợp đồng dữ liệu RVol trong Shadow Pathfinder (`core/bot.py:3112, 3148, 12324`):**
   - Đọc đầy đủ chuỗi fallback `c_vol_ratio` $\to$ `candle_vol_ratio` $\to$ `rvol` $\to$ `market_analysis['candle_vol_ratio']`, chấm dứt hiện tượng mẫu bị chặn ở Trạm 2 bị gán mặc định `RVol = 1.00x`.
6. **Chuẩn hóa `ai_ensemble_vote`, `orig_ai_vote`, dấu ngoặc `is_fading_short` & dấu `weighted_score` khi OFA Invert (`ai/signal_aggregator.py:1034, 1672, 4400, 4503, 4531` & `core/bot.py:12123, 12165`):**
   - Lưu `orig_ai_vote` bất biến trước khi `pop('ai_ensemble')` (bổ sung đối xứng `has_alt_exhaustion_bounce_long_override`).
   - Tách dấu ngoặc `bool(final_signal.metadata.get('is_fading_short', False))` khỏi điều kiện `c_lower_wick_pct < 0.28` để không làm mất cờ Fading Short đã duyệt.
   - Đổi dấu `weighted_score = +abs(...)` / `-abs(...)` đồng bộ khi Order Flow Smart Inversion lật chiều.
   - Kiểm tra đối xứng `pair_ai_vote > -0.35` (cho BUY trong BEARISH bias) và `pair_ai_vote < 0.35` (cho SELL trong BULLISH bias), bảo đảm không Veto oan khi Ollama 4H trả về Neutral (`0.0`).
7. **Mở rộng nhận diện `is_trap_trade` tại Trạm 7 & Chuẩn hóa hiển thị Tổng Net PnL Telegram (`core/bot.py:5820, 8019, 11906`):**
   - Bổ sung `'PARABOLIC_EXHAUSTION'`, `'PANIC_CLIMAX'`, `'FADING'`, `'EXHAUSTION'`, `'SWEEP'` và cờ `is_fading_short` / `is_oversold_bounce` vào `is_trap_trade` để giữ vững ngưỡng đảo chiều `0.50` ngoài Grace Period.
   - Đưa `Tổng Net PnL toàn lệnh` lên dòng đầu tiên của thông báo đóng lệnh Telegram để khớp 100% với tổng các mảnh multi-fills trên App Binance.
8. **Hóa giải xung đột giữa Buffer Sàn `0.22%` và `is_mfe_ratchet_sl` / `is_ewick_sl` (`core/bot.py:10438, 10596`):**
   - Khi `is_mfe_ratchet_ready` hoặc `is_ewick_choke_ready` kích hoạt ở vùng PnL hiện tại `+0.10% -> +0.35%`, bộ đệm sàn Binance `0.22%` ép `new_sl` xuống thấp hơn `mfe_ratchet_sl` (`+0.14%`), từng làm `is_mfe_ratchet_sl` trả về `False` khiến bot bỏ qua không nâng SL trên sàn. Đã mở khóa cho phép cập nhật SL ngay khi `new_sl` nằm từ sàn đệm Cushion (`-0.25%`) trở lên và cải thiện SL hiện tại (`improves_stop`).
9. **Khóa chiều cải thiện SL trong `AUTO-RETRY CHOKE SL` & Tự động dọn cờ `choke_sl_pending` (`core/bot.py:7227, 9601, 10705`):**
   - Bắt buộc kiểm tra `target_choke > curr_sl_val` (LONG) / `target_choke < curr_sl_val` (SHORT) và tự động xóa sạch `choke_sl_pending` ngay khi SL đã được nâng lên Cushion SL hoặc Hòa Vốn, chặn đứng nguy cơ nhánh retry cũ kéo lùi SL từ Hòa Vốn về `-1.0 ATR`.
10. **Cách ly râu nến 15M/M1 quá khứ khỏi `ShadowPathfinder` (Zero Look-Back Isolation) (`core/shadow_pathfinder.py:228` & `core/bot.py:8001, 11479`):**
    - Tại Pha 1 15M (`core/bot.py:11479`), chỉ truyền giá khớp thực tế hiện tại `_curr_p1_px = float(_last_p1_c['close'])` thay vì `high`/`low` của cả cây nến 15M (vốn chứa râu quá khứ trước thời điểm đăng ký candidate gây `SL_HIT` ảo sau 67–90 giây như `BULLAUSDT`). Tại `update_market_data`, bổ sung kiểm tra `candle_open_ts < cand.registered_at` để kẹp về `curr_p`.
11. **Ưu tiên chọn Chiến Thuật Kỹ Thuật bị chặn tại `STATION_2_AGGREGATOR_SCORE` (`core/bot.py:12350`):**
    - Lọc `tech_p2_sigs` (loại trừ phiếu Veto của `ai_ensemble` / `jev_agent`) trước khi chọn `best_p2_sig`, chấm dứt lỗi bốc nhầm phiếu Veto (`SELL`) để đăng ký ngược chiều vào `ShadowPathfinder` khi lệnh kỹ thuật (`BUY`, như `CAP/USDT` và `AKE/USDT`) bị chặn.
12. **Chặn dự báo ngược chiều trong chu kỳ `Cold-Start Warmup` & Đồng bộ `ai_ensemble_vote` (`core/bot.py:1429, 12154, 12194` & `ai/signal_aggregator.py:2410`):**
    - Tính trước dự báo out-of-sample ngay khi model vừa train xong (`status='cold_start_warmup'`); nếu model mới dự báo ngược chiều tín hiệu kỹ thuật với độ tự tin $\ge 60\%$ (như ca `SKY/USDT` #2 dự báo `BUY 64.6%` khi kỹ thuật báo `SELL`), kích hoạt `COLD-START OPPOSING VETO` chặn ngay từ đầu.
    - Đồng bộ `pair_ai_vote` tại `core/bot.py:12154, 12194` đọc `ai_ensemble_vote` sau phân xử để tôn trọng 100% cơ chế hạ quyền ML trễ pha của Bài học 97, Bài học 108 (`SOPH/USDT` 23:17, `IDOL/USDT`) và KB10 Dual-Brain (`XAG/USDT`).

---

## 🚫 IV. 3 ĐỀ XUẤT XUNG ĐỘT GIỮA CÁC PHIÊN ĐÃ BỊ BÁC BỎ VĨNH VIỄN (CẤM TÁI ĐỀ XUẤT)

1. **❌ CẤM ép nến M1 phải có râu từ chối `u_wick >= 30%` mới miễn trừ `is_climax_setup` trong M1 Sniper ("Bom 1" của Phiên 2 `73a79e1e`):**
   - *Lý do bác bỏ:* Để giá khớp được lệnh Limit Sell đón đỉnh ở trên giá thị trường (`+0.50%` đến `+0.80%`), bắt buộc phải có nến M1 xanh rướn lên. Nếu hủy lệnh rình mỗi khi nến M1 xanh chưa có râu $\ge 30\%$, hệ thống sẽ **HỦY OAN (FALSE ABORT) toàn bộ 249 - 251 lệnh thắng `EXHAUSTION_FADING_SHORT` (Win Rate 80.4% - 82.7%)**! Chốt chặn Sóng Bão hiện có (`is_storm_setup: body >= 70% & u_wick < 25%`) đã bảo vệ đầy đủ.
2. **❌ CẤM nới lỏng `deep_loss_limit` theo ATR (`min(-1.00%, -0.55 * ATR)`):**
   - *Lý do bác bỏ:* Mốc cứng `-1.00%` (sau 4 nến M1 đóng mà `MFE < +0.65%`) là cầu dao cứu hộ cho Bad Entry, đã cứu 56% vốn trong ca `SOPH #2` trước khi giá bay lên sát Full SL `-3.54%`.
3. **❌ CẤM ép cứng `pair_ai_vote <= -0.40` trong AI Bias Gate:**
   - *Lý do bác bỏ:* Làm Veto oan toàn bộ tín hiệu trên các Altcoin khi mô hình 4H trả về Neutral (`0.0`).

---

## 🔬 V. KIỂM TOÁN SHADOW PATHFINDER ĐA TẦNG 2 CHIỀU & ĐỐI SOÁT CHUẨN QUỸ

- **Shadow Pathfinder Đa Tầng 2 Chiều (`python tools/report_shadow_alpha.py`, SSOT: [`docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md`](file:///d:/TRADE/docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md)):**
  - Tổng cộng: **280+ mẫu** đã được backfill 100% dấu vân tay 4 tầng (`layer1_tech_strategies`, `layer2_candle_dna`, `layer3_consensus_dna`, `layer4_exact_veto_gate`) và chấm điểm song hành 60 phút cho cả **Chiều Thuận (`DIRECT`)** lẫn **Chiều Lật Ngược (`INVERTED`)**.
  - Trạm 2 (Aggregator Score): Tỷ lệ cứu thua toàn cục **> 94.0%** (`SL_HIT` + `TIMEOUT_60M`).
  - **3 Cụm Đường Đi Đa Tầng Đang Theo Dõi Sát (Watchlist tiến tới $N \ge 15$):**
    1. **Cụm Alpha #1 (`SLOT B1` - Mở khóa Short):** `trap_detector:SELL + AI:SELL + JEV 4H:BUY` khi **`U_Wick >= 65% & RSI < 65 & RVol >= 1.33x`** ($N = 8/15$ mẫu: Đánh `SHORT` thắng **7/8 = 87.5%**, 0% dính SL).
    2. **Cụm Alpha #2 (`SLOT B2` - Lật chiều sang Long):** `trap_detector:SELL + AI:SELL + JEV 4H:BUY` khi **`RSI >= 65 & 1.10x <= RVol <= 3.50x`** ($N = 12/15$ mẫu: Lật sang `LONG` thắng **9/12 = 75.0%**).
    3. **Cụm Alpha #3 (`SLOT A` - Miễn trừ Fast-Skip gọi JEV):** `trend_following:BUY + AI:SELL -> FAST_SKIP_COUNTER_TREND` khi **`RSI >= 56 & Pump >= 0.50% & RVol >= 1.20x`** ($N = 10/15$ mẫu: Đánh `LONG` thắng **6/10**, 0% dính SL trước).
  - Giữ nguyên 100% kỷ luật rào chắn cho đến khi cụm tích lũy đủ **$N \ge 15$ mẫu hoàn tất 60m** và vượt qua Bộ 5 Tiêu Chuẩn Cứng.
- **Hard Constraints Gate (`python tools/hard_constraints_gate.py`):** **11/11 PASSED (100%)**.
- **System Integrity Auditor (`python tools/audit_system_integrity.py`):** **6/6 PASSED (100%)**, 0 Syntax/AST/NameError.
- **Full Historical Simulator (`python tools/full_historical_signal_and_position_simulator.py`):**
  - **False Exits (Lệnh thắng bị mất):** **`0 / 219 (0.0%)`** ✅.
  - **Net PnL Delta:** **`+137.46 USDT`**.
