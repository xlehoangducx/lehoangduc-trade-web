# BÀI HỌC PHIÊN 17 & TỔNG KẾT KIẾN TRÚC V6.5 (`BOM #127 → #148`)
> **SSOT Bàn Giao Chính Thức — Toàn Bộ Phiên Làm Việc `25/11/2026 → 28/11/2026` (22 gói nâng cấp `BOM #127 → #148`)**
> *Mục tiêu: Khóa toàn bộ kiến trúc thực chiến 8.5 tầng V6.5, tổng hợp 10 mâu thuẫn giữa Tài liệu ↔ Cấu hình ↔ Mã nguồn, tự kiểm điểm không khoan nhượng 8 chuỗi lỗi lặp/tự tạo hồi quy, phân tích vì sao sửa 1 lần dễ phát sinh lỗi mới, và lập **Bản đồ 14 Điểm Nóng Liên Kết Chéo** để Phiên 18+ làm việc chính xác, không lặp lại vết xe đổ.*

---

## 1. BỨC TRANH KIẾN TRÚC THỰC CHIẾN HIỆN HÀNH (V6.5 — `BOM #148`)

### 1.1. Hạ Tầng 2 Máy Tính & Trạng Thái Đồng Bộ
| Thành phần | Vai trò hiện tại | Trạng thái & Thông số xác thực |
| :--- | :--- | :--- |
| **PC1 (`d:\TRADE`)** | **DEV & QUANT Offline** (`PC1_BOT_PROCS=0`) | Python 3.14.7 (`venv\Scripts\python.exe`), bộ test **170/170 PASS** (`test_bom125.py` → `test_bom148.py`), 5 cổng kiểm toán Offline. CẤM chạy bot Live hoặc gọi REST Binance trên PC1 khi PC2 đang live. |
| **PC2 (`\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0`)** | **LIVE Machine Duy Nhất** | Đã đồng bộ **100% SHA-256** (`deploy_web_client.py`, ZIP `TradeMatrix_Client_v2.0.zip`, backup ổ D PC2). Equity thực chiến `~$405.88–$415.11 USDT` (Peak `$415.11`). Chạy qua đêm `BOM #147` (`00:59 → 10:02` ngày `28/11`): `0` lỗi log trên `114,405` dòng, **4W/1L (`80% WR`), `+$0.6194` ròng**. Sau khi deploy `BOM #148`, nhớ chạy `Fix_Time.bat` + `RESTART.bat` trên PC2 để nạp RAM mới. |
| **AI Trust Scorecard** | [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md) | **Giữ nguyên `10%` (Báo động đỏ tối thượng)** — tuân thủ *Live Profit Invariant*: không tự cộng điểm vì kết quả test/simulator hay 1 đêm đơn lẻ, đặc biệt sau khi chính `BOM #147` từng tạo ra 2 bản vá vô tác dụng bị `BOM #148` bắt lại. |

### 1.2. Đường Ống Vào Lệnh & Quản Trị Vị Thế 8.5 Tầng (End-to-End V6.5)
1. **Tầng 1 — Radar & Phân Loại Tài Sản 1 Nguồn Duy Nhất ([`core/scanner.py`](file:///d:/TRADE/core/scanner.py)):**
   - **294 mã TradFi** (`KNOWN_TRADFI_BASES`), **42 mã Hàng hóa** (`KNOWN_COMMODITY_BASES`, đã gồm `XAU`, `XAG`, `CL`, `BZ`, `NG`, `HG`, `PAXG`), **10 phân lớp ngành** (`SECTOR_MAP`), **35 cặp đảo chiều** (`DIRECT_INVERSES`), cùng danh mục loại trừ Crypto trùng mã (`CRYPTO_TICKER_EXCLUSIONS`: `ON`, `DIA`, `MUBARAK`, ...).
   - **`PAXG/USDT`:** Được xử lý thống nhất là **`TRADFI_COMMODITY`** (miễn giờ mở phiên chứng khoán Phố Wall `is_tradfi_stock=False`, nhưng **khóa rủi ro nhảy Gap cuối tuần** `is_weekend_gap_risk_window=True` giống Vàng CME `XAU/USDT`).
   - **Data Collector ([`core/data_collector.py`](file:///d:/TRADE/core/data_collector.py)):** Tự động hủy RAM cache ngay khi chuyển nến (`candle-bucket rollover`, neo `done_bucket` theo `ram_df.index[-1]`), lưu tích lũy CSV vượt 500 nến (giữ RAM gọn, bảo toàn đĩa khi đọc lỗi tạm thời).
2. **Tầng 2 — Chiến Lược Kỹ Thuật + AI/ML + JEV Đa Khung 4H/1H/15M:**
   - 6 chiến lược cơ sở + AI Ensemble + **JEV Agent (`qwen2.5:7b`)** ([`ai/jev_agent.py`](file:///d:/TRADE/ai/jev_agent.py)): đã vá **JEV 4H Contradiction/Hallucination Guard** dùng logic `OR`/De Morgan fail-closed (`0.65`), nhận diện phủ định (*negation guard*), miễn trừ lỗi chia `vol=0`, và vượt cache khi giá crash mạnh.
3. **Tầng 3 — Tổng Hợp Tín Hiệu, Vũ Khí & Khiên DNA ([`ai/signal_aggregator.py`](file:///d:/TRADE/ai/signal_aggregator.py)):**
   - Hợp nhất 15 Vũ Khí (`SLOT_A` / `SLOT_B1` / `SLOT_B2`), tái kiểm định **`POST-KB5`** sau mọi bước lật chiều, gắn đầy đủ `weapon_id` vào mọi nhánh `_record_veto()`.
   - **Rule R4 (`BOM #130`):** Chặn `ALTCOIN SHORT` khi `Pump >= 6.0%` mà `U_Wick < 65%`, hoặc `RSI 15M >= 68.0` trên mọi vũ khí; giữ nguyên sweet-spot và râu xả cực đại (`UW >= 65%`).
   - **`BOM #144-TINY`:** Chặn `ALTCOIN LONG` Blow-Off (`RVol >= 8.0x & RSI >= 71.0`) và `TRADFI` Dead-ATR (`0 < ATR < 0.32%`).
   - **Anti-Paused-Hijack & Trend Hammer Fallthrough (`BOM #147–#148`):** Kèo 4 trụ thuận xu hướng (`Trend/BO + AI + JEV`) không bị cướp nhãn sang `VK3/VK7 (PAUSED)` hay bị giết bởi `OVERSOLD_BOUNCE_VETO`; Pha 3 không bao giờ tự chế `'BEAR_TRAP_WICK'` khi `TrapDetector` không phát tín hiệu; Benchmark ngành TradFi có fallback `BENCHMARK_LEADERS[sector]`.
4. **Tầng 4 — Cổng Lượng Tử Monte Carlo ([`ai/quantum_path_simulator.py`](file:///d:/TRADE/ai/quantum_path_simulator.py)):**
   - `2,500` quỹ đạo, xử lý **DOA Right-Censoring** (`BOM #135`) cho `BTC/BNB/XAU` ATR thấp, từ chối EV âm kể cả khi có TP1 (`BOM #137`), lấy bậc đòn bẩy ETF 2x/3x trực tiếp từ `MarketScanner.get_etf_leverage_tier()`, và yêu cầu xác nhận vật lý thật cho `TREND_MOMENTUM` động (`BOM #145`).
5. **Tầng 4.5 (MỚI — `BOM #146`, gói `S_CLEAN_3`) — Pre-Entry Macro & Exhaustion Guard ([`core/bot.py`](file:///d:/TRADE/core/bot.py)):**
   - Đứng giữa **Tầng 4 (Quantum PASS)** và **Tầng 5 (M1 Sniper)**; kiểm chứng đủ 6 khung nến (`1m/5m/15m/30m/1h/4h`) trên tối đa `705/706` vị thế Live (`LIVE_407: +$7.90`, cứu `11` lệnh thua `+$8.50`, chỉ rơi `4` lệnh thắng nhỏ `-$0.60`) và `4,250` mẫu Shadow (`5/6` khung dương).
   - **3 bộ lọc sạch duy nhất được duyệt (đã loại bỏ `Q10`, `Q16`, `H1_VWAP`, `H1_EMA20_Z`, `4H_WICK` vì overfit):**
     1. `Q18` (15M 3-Bar Chase, nến đã đóng `iloc[-2]`): chặn đuổi giá $\ge 3.0\times\text{ATR}$ (`TRADFI_ETF_3X`: $\ge 3.5\times\text{ATR}$).
     2. `BTC 1H Flash Shield`: chặn ngược sóng BTC 1H $\ge 1.30\%$ (**chỉ ALTCOIN**).
     3. `BTC 15M Extreme Flash Shield`: chặn ngược sóng BTC 15M $\ge 1.25\%$ (**chỉ ALTCOIN**).
   - Lưu vết `STATION_5B_LAYER45_PRE_ENTRY` trong [`core/shadow_pathfinder.py`](file:///d:/TRADE/core/shadow_pathfinder.py), ghi `metadata['layer45_guard']` TRƯỚC nhánh `return` (`BOM #148`), và đẩy telemetry `LAYER45_PRE_ENTRY` lên `/so-do-dong`.
6. **Tầng 5 — M1 Sniper & CKS (`BOM #143`, `BOM #147–#148`):**
   - **`S01` (Trend-Only M1 Filter):** Chỉ chặn vũ khí bám xu hướng khi M1 cản đầu, miễn trừ vũ khí đảo chiều (`OVERSOLD_BOUNCE`/`CLIMAX_REVERSAL`), đọc trực tiếp trường top-level của `stalking`.
   - **`S04` (Pre-Fill Velocity Brake):** Hủy lệnh Limit đang rình nếu nến M1 sập/bật thẳng $\ge 2.0\times\text{ATR}$ không râu đỡ.
   - **Stalking Flip Exemption (`BOM #148`):** Khi lật chiều rình trên cùng 1 mã, không tự đếm chính mã đó vào trần `pending_stalking_orders`.
   - **Partial-Fill 12s Grace (`BOM #139`):** Cho cửa sổ hoàn tất khớp 1 phần trước khi hủy phần dư, tránh kẹt vị thế nửa vời.
7. **Tầng 6 — Quản Trị Vị Thế, Tam Tầng SL V4.1 & Gói `S20_PRO_C` (`BOM #127–#129`, `#143`, `#147–#148`):**
   - **Tam Tầng SL V4.1** ([`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md)): Cushion SL, Flash Hard BE (`max(0.85%, 0.85*ATR)`), ATR-adaptive MFE Ratchet (`BOM #127A`), sàn lãi dương hậu TP1 `0.40×TP1` (`BOM #128B`), và **Bậc thang 5 TP (`D5`, TP1–TP5 bật đủ 5 bậc)** với mức khóa SL lũy tiến (`TP1 → 80%×TP1`, `TP2 → TP1`, ...; khi người dùng chỉ bật tới `TP2`, tôn trọng TP2 làm trần chốt cứng trên sàn theo `BOM #139`).
   - **`S09` (Twin-Bar M1 Shock):** Bắt cú xả/bật 2 nến liên tiếp trong cửa sổ nến M1 thứ `6..10` (`PnL <= -0.60%` Altcoin), bổ sung cho Shock Rescue đơn nến (`bars 1..5`).
   - **`V4` (4TF Simultaneous Flip):** Thoát chủ động khi 4 khung đồng loạt đảo chiều (tôn trọng lệnh tay/JEV/ETF 3x và kiểm tra kết quả đóng trước khi báo Telegram).
   - **`S19` (Kaufman ER Trailing):** Dùng Efficiency Ratio nới khoảng thở cho sóng chạy thẳng, siết khi giá nhiễu chop; đọc đúng TP2 từ `v61_tp_lock_tiers[1][0]` + fallback `take_profit`.
   - **CRR Snell Optimal Peak Exit (`BOM #148`):** Chỉ gửi Telegram khi `_crr_closed_res is not None` (triệt tiêu race bắn đúp Telegram).
   - **Cross-Asset Emergency Guard (`BOM #131–#132`, `#148`):** Đảo đúng dấu cho Bear Inverse ETF (`SOXS/SQQQ/SPXU/...`), áp ngưỡng riêng cho ETF 3x, và bảo vệ cả `VK2/VK9/VK10`.

### 1.3. Kho 15 Vũ Khí (`config/weapon_lifecycle.json`) & Risk Parity 4 Phân Lớp (`config/position_tuning.json`)
- **Trạng thái 15 Vũ Khí hiện hành (khớp 100% PC1 & PC2):**
  - **`OFFICIAL` (5):** `VK1`, `VK4`, `VK5`, `VK6`, `VK8`.
  - **`PAUSED` (5):** `VK2`, `VK3`, `VK7`, **`VK12`**, **`VK13`** *(lưu ý: `VK12` & `VK13` đã bị tạm tắt sau kiểm định Phiên 17; tài liệu `SESSION_16` cũ vẫn ghi chúng là `EXPERIMENTAL`)*.
  - **`EXPERIMENTAL` (5):** `VK9` (Altcoin SHORT), `VK10` (TradFi LONG), `VK11` (2 chiều `SLOT_B2`), `VK14` (LONG `SLOT_B2`), `VK15` (LONG `SLOT_B2`).
  - **Kỷ luật định cỡ & thăng hạng (`BOM #133`, `#139`, `#141`):** Mọi vũ khí `EXPERIMENTAL` bị khóa trần Wilson-Kelly `≤ 0.60x` (luôn nhỏ hơn `OFFICIAL`, kể cả khi vượt 15 lệnh Live); muốn lên `OFFICIAL` bắt buộc vượt **Graduation Guard** (`N_live >= 15`, `Net > 0$`, `WR >= 55%` hoặc `PF >= 1.50`, `SL <= 30%`); muốn thăng từ LAB lên `EXPERIMENTAL` bắt buộc vượt **Cổng 6 Dry-Run 8 Trạm** (`hijacked_opposite == 0`, `T3 >= 60%`, `T3+T4 >= 45%`).

- **Ma trận Risk Parity 4 Phân Lớp (`cap_schema_version = 3`, `config/position_tuning.json`):**

| Phân lớp | Risk/lệnh | SL `[min–max]` (Mặc định) | Lev tối đa | Trần Notional | Cushion / Hard BE | Chốt TP1 | Bậc thang TP1 → TP5 (%) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **`ALTCOIN`** | `0.35%` | `1.5%–3.5%` (`2.5%`) | `5x` | `15.0%` | `0.80% / 0.85%` | `50%` | `1.35 → 2.40 → 3.80 → 5.50 → 7.50` |
| **`MAJOR`** | `0.35%` | `1.0%–2.2%` (`1.7%`) | `5x` | `20.0%` | `0.75% / 0.90%` | `50%` | `1.05 → 1.80 → 2.60 → 3.60 → 5.00` |
| **`TRADFI_1X`** | `0.35%` | `1.0%–1.8%` (`1.4%`) | `4x` | `18.0%` | `0.65% / 0.85%` | `30%` | `0.95 → 1.60 → 2.40 → 3.40 → 4.80` |
| **`TRADFI_ETF_3X`** | `0.30%` | `1.8%–3.5%` (`2.75%`) | `2x` | `15.0%` | `1.20% / 1.80%` | `50%` | `2.30 → 3.80 → 5.20 → 6.80 → 8.50` |

---

## 2. LỘ TRÌNH 22 GÓI NÂNG CẤP & VÁ LỖI PHIÊN 17 (`BOM #127 → #148`)

| Giai đoạn | Các BOM | Trọng tâm cốt lõi đã khóa vào mã nguồn & unit test |
| :--- | :---: | :--- |
| **GĐ 1 — Chốt lãi, MFE & D5 Ladder** | `#127 → #129` | ATR-adaptive MFE Ratchet + E_wick (`#127A`), phân biệt Telegram BE vs Profit Lock (`#127B`), Shock Rescue body floor + pre-entry M1 guard (`#127C/E`), DNA floor vũ khí động (`#127D`), **D5 5-Stage TP Ladder** + `0.40×TP1` floor + `T7` 15m breath (`#128`), handoff recovery + consistency partial TP (`#129`). |
| **GĐ 2 — Khiên DNA & Exhaustive Audit** | `#130 → #132` | **Rule R4** Altcoin SHORT (`Pump>=6% & UW<65%` hoặc `RSI>=68`) (`#130`); xóa dead import `get_tuning_for_symbol`, bảo vệ ETF 3x, mở khóa dead-code `RSI>=70` VK15, sửa log `EVAA` (`#131`); đảo dấu Bear ETF trên Cross-Asset Guard, sửa fallback `closed_m1_count`, chuẩn hóa ATR `%`, không `continue` lệnh tay `-2021`, reset `_v61_peak_equity` (`#132`). |
| **GĐ 3 — Cổng 6 LAB Tự Kiểm** | `#133` | `_build_8station_blueprint` tự phân `SLOT_B2`, `run_8station_pre_promotion_dry_run` trên `SignalAggregator+Quantum` (thread-local overlay sạch), `Official Graduation Guard`, tạm tắt `VK12/VK13`. |
| **GĐ 4 — Quantum, Cache, DB & Sizing** | `#134 → #139` | 20 lỗi liên tầng (`#134`); DOA right-censoring BTC/BNB/XAU + CSV merge không cắt 500 nến (`#135`); giới hạn Shock Rescue `5` nến M1 + tích lũy CSV vượt 500 nến (`#136`); Quantum EV âm + JEV comma/crash + Free-Roll chặn resize-pending + bảo toàn đĩa CSV (`#137`); đối soát Live 5h PC2 (`#138`); **Partial-fill 12s grace + `EXPERIMENTAL <= 0.60x < OFFICIAL` + TP2 hard cap** (`#139`). |
| **GĐ 5 — Pháp y Live & Vi Cấu Trúc M1** | `#140 → #144` | Đọc đúng `states` schema `weapon_lifecycle.json`, chống cướp `BEAR_TRAP` sang `VK1`, `CRYPTO_TICKER_EXCLUSIONS`, JEV negation/De Morgan (`#140`); slashless MAJOR, chống double-invert `VK11`, bảo toàn `loss_streaks` khi restore (`#141`); OrderFlow `429` backoff, DB multi-fill cleanup (`#142`); **Gói `S20_PRO_C`** (`S01`, `S04`, `S09`, `V4`, `S19`) (`#143`); **`BOM #144-TINY`** (Altcoin Blow-Off `RVol>=8x & RSI>=71`, TradFi Dead-ATR `<0.32%`, PnL% dùng `invested_basis`) (`#144`). |
| **GĐ 6 — Asset SSOT, Tầng 4.5 & Hậu Kiểm** | `#145 → #148` | Dọn sạch legacy `I2`, ETF tier SSOT, Quantum `TREND_MOMENTUM` cần xác nhận vật lý (`#145`); **Tầng 4.5 `S_CLEAN_3`** kiểm chứng 6 khung trên 705 vị thế Live (`#146`); chống cướp `VK3/VK7`, `OVERSOLD_BOUNCE_VETO` fallthrough, `daily_auditor.py` RO+`mode='live'`, DataCollector bucket rollover, 15 ETF mới + 4 hàng hóa (`#147`); sửa triệt để fallback Pha 3 `'OVERSOLD_BOUNCE'`, khóa `max_up_pct_240m`, cột `symbol` cho `VK10`, `BENCHMARK_LEADERS`, `HG/USDT`, trailing RVol shift-1, chặn double-Telegram CRR Snell (`#148`). |

---

## 3. TỔNG HỢP 10 MÂU THUẪN PHÁT HIỆN GIỮA 2 BÊN (TÀI LIỆU ↔ CẤU HÌNH ↔ CODE ↔ CÁC TẦNG)

| # | Nguồn A vs Nguồn B | Mô tả mâu thuẫn đã phát hiện | Trạng thái & Kết luận SSOT |
| :-: | :--- | :--- | :--- |
| **1** | `AGENTS.md` / `SESSION_16` vs Thực tế PC1/PC2 | Tài liệu cũ ghi `V6.4`, `BOM #126`, `83/83 SHA-256`, `250` mã TradFi, `VK12/VK13` là `EXPERIMENTAL`, không có Tầng 4.5 và `S20_PRO_C`. | **Đã đồng bộ trong `SESSION_17` & `AGENTS.md`/`GEMINI.md`:** `V6.5` (`BOM #148`), **294** mã TradFi / **42** Commodity, `VK12/VK13` đã **`PAUSED`**, có Tầng 4.5 `S_CLEAN_3` & `S20_PRO_C`. |
| **2** | `docs/FEATURE_MAP.md` vs Codebase V6.5 | `FEATURE_MAP.md` cũ vẫn ghi "Kho 8 Vũ Khí", "238 mã TradFi", "Major 10x–20x, Altcoin 3x–10x", "Weekend Shield đóng trước thứ 7", thiếu `quant_evolution_engine.py` & `exhaustive_10axis_audit.py`. | **Đã cập nhật `docs/FEATURE_MAP.md`** về đúng chuẩn V6.5 (15 vũ khí, 294 TradFi, Risk Parity 4 lớp, `weekend_close=false`). |
| **3** | `docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md` vs `config/position_tuning.json` | Tài liệu V4.1 ghi số tham khảo cũ `TP1 +1.5% đến +2.2%`, trong khi `position_tuning.json` hiện hành (D5) dùng `ALTCOIN 1.35%`, `MAJOR 1.05%`, `TRADFI_1X 0.95%`, `TRADFI_ETF_3X 2.30%`. | **Quy tắc phân định:** Logic 5 cấp thoát lệnh & cấm xóa Hard BE `+0.85%` lấy theo `TAM_TANG_V41`; **con số TP1–TP5 / SL / Cap thực thi lấy SSOT từ `config/position_tuning.json`**. |
| **4** | `AGENTS.md §0.7(4)` vs Codebase | Quy tắc ghi *Sandbox Mã Mới `< 72h`* (`lev <= 3x`, margin `<= 10%`, cooldown 24h) nhưng vẫn **CHƯA triển khai trong code**. | **Còn lưu ý:** Giữ nhãn cảnh báo rõ để phiên mới không nhầm là gate đang chạy thực tế. |
| **5** | `PAXG/USDT` (Crypto 24/7 vs Vàng CME 24/5) | Người dùng hỏi rõ cách xử lý `PAXG/USDT` khi có lúc sợ nhầm thành Crypto hoặc US Stock. | **Chốt thực tế trong `core/scanner.py`:** `PAXG` thuộc `KNOWN_COMMODITY_BASES` (`TRADFI_COMMODITY`) → chạy 24/5 (miễn giờ Wall Street), **khóa cuối tuần giống `XAU/USDT`** để tránh thanh khoản mỏng & gap CME sáng Thứ 2. |
| **6** | `MarketScanner` vs `QuantumPathSimulator` vs `RiskManager` vs `Simulator` | Danh mục ETF 2x/3x, Hàng hóa (`HG`, `GLD`, `SLV`, `USO`), Bear Inverse ETF (`SOXS`, `TZA`, `KOLD`, `DUST`...) và Crypto trùng mã (`ON`, `DIA`, `MUBARAK`) từng khai báo rải rác 4–5 file, liên tục phân loại nhầm sang `TRADFI_STOCK`. | **Đã hợp nhất về `MarketScanner` SSOT** (`BOM #140/#145/#147/#148`); mọi module khác bắt buộc gọi `MarketScanner.*` thay vì hardcode danh sách riêng. |
| **7** | Kèo Thuận Xu Hướng 4 Trụ vs `TrapDetector` + `PAUSED VK3/VK7` | Khi `TrendFollowing + Breakout + AI + JEV` đều thuận chiều nhưng nến có thêm râu `TrapDetector`, Aggregator cũ gắn `type='BEAR_TRAP_WICK'`/`'BULL_TRAP_WICK'` rồi giết sạch ở `WEAPON_PAUSED_LIFECYCLE` hoặc `OVERSOLD_BOUNCE_VETO`. | **Đã khóa (`BOM #145/#147/#148`):** Bảo toàn kèo 4 trụ thuận xu hướng (`ANTI-PAUSED-HIJACK` & `TREND HAMMER FALLTHROUGH`) và cấm fallback Pha 3 tự chế `'BEAR_TRAP_WICK'`. |
| **8** | `ShadowPathfinder` Writer vs `QuantEvolutionEngine` & `VietnameseWeaponArsenal` Readers | Writer lưu `dual_eval_240m.max_up_pct_240m` và cột SQL `symbol`, nhưng 2 Reader ở `BOM #147` lại đọc `max_up_pct` (không tồn tại) và `det.get('symbol')` (không `SELECT` cột `symbol`). | **Đã vá đồng bộ schema (`BOM #148`):** Luôn đọc đúng khóa schema của Writer và test bằng SQLite thật (`test_bom148.py`). |
| **9** | `S01 / S19` (`BOM #143`) vs Cấu trúc Dict `stalking` & `v61_tp_lock_tiers` | `BOM #143` đọc `stalking['metadata']` (rỗng) cho `S01` và đọc sai index/key TP2 cho `S19`. | **Đã vá (`BOM #147/#148`):** Đọc đúng trường top-level `stalking` và `v61_tp_lock_tiers[1][0]` kèm fallback `take_profit`. |
| **10** | `tools/daily_auditor.py` vs Quy Chuẩn An Toàn SQLite (`PRAGMA query_only=ON`) | `daily_auditor.py` mở DB PC2 qua SMB ở chế độ đọc-ghi mặc định và gộp cả lệnh demo/không lọc `exchange_trade_id`. | **Đã vá (`BOM #147`):** Bắt buộc `?mode=ro` + `PRAGMA query_only=ON` + `mode='live'` + lọc `exchange_trade_id`. |

---

## 4. TỰ KIỂM ĐIỂM KHÔNG KHOAN NHƯỢNG: 8 LỖI LẶP LẠI & TỰ TẠO HỒI QUY TRONG PHIÊN 17

> [!CAUTION]
> **Nguyên tắc học thật từ sai lầm:** Phiên 17 chạy rất nhanh qua 22 BOM (`#127 → #148`), nhưng chính tốc độ vá lỗi nối tiếp đã lộ rõ **8 kiểu sai lầm tự gây** lặp đi lặp lại. Mọi phiên mới BẮT BUỘC đọc thuộc lòng 8 bẫy này trước khi chạm vào code.

| # | Lỗi lặp lại / Tự gây hồi quy | Bằng chứng thực tế trong Phiên 17 | Lý do gốc rễ | Cách khóa vĩnh viễn cho Phiên 18+ |
| :-: | :--- | :--- | :--- | :--- |
| **1** | **Bản vá "Vô tác dụng" do đoán tên khóa (No-op Fix)** | `BOM #147` sửa `simulate_manual_position_tuning` đọc `max_up_pct` thay vì `max_up_pct_240m`, và sửa `vietnamese_weapon_arsenal` đọc `det.get('symbol')` khi SQL không `SELECT symbol` → chạy không lỗi nhưng hoàn toàn vô dụng! | Sửa Reader mà **không đọc lại Writer** (`shadow_pathfinder.py`) và không viết unit test kiểm chứng giá trị đầu ra thực tế (chỉ kiểm tra không crash). | **Luật Bất Biến #1:** Trước khi sửa bất kỳ chỗ ĐỌC dict/JSON/SQL nào, PHẢI mở file GHI xác nhận tên khóa + viết test dùng dữ liệu thật (giả lập MFE `3.50%` trong `dual_eval_240m`, `max_mfe` cột DB đông cứng `1.35%`) để test FAIL trước khi sửa! |
| **2** | **Vá nửa vời, sót nhánh fallback / nhánh đối xứng (Half-Patch Trap)** | `BOM #145` và `#147` vá `VK3`/`VK7` hijack ở nhánh chính nhưng quên dòng `L4500` fallback Pha 3 vẫn tự gán `'BEAR_TRAP_WICK'`, quên `not _ai_popped_short_ok` đối xứng ở Pha 2, quên thụt lề log `[EXHAUSTION FADING SHORT]`, quên `BENCHMARK_LEADERS` fallback (`BOM #148` mới xong). | Sửa đúng chỗ nhìn thấy trong log mà không quét **toàn bộ khối `if/elif/else`** và nhánh đối xứng `LONG ↔ SHORT`. | **Luật Bất Biến #2:** Khi vá bất kỳ logic nào ở `signal_aggregator.py` hoặc `bot.py`, BẮT BUỘC grep toàn bộ chuỗi đích (ví dụ `'BEAR_TRAP_WICK'`, `_ai_popped_`, `lead_base`) trong cả file và đối chiếu đủ 2 chiều `LONG ↔ SHORT`. |
| **3** | **Phân mảnh bảng phân loại tài sản (Split-Brain Asset Tables)** | Lỗi phân loại nhầm sang `TRADFI_STOCK` hoặc thiếu ETF 2x/3x lặp lại qua **6 BOM** (`#134`, `#136`, `#140`, `#141`, `#145`, `#147`, `#148`: `MUBARAK`, `ON`, `DIA`, `TBT`, `HG`, 15 ETF mới `BOIL/KOLD/TNA/TZA/...`, `PAXG`). | Nhiều file tự giữ tập hằng số riêng thay vì gọi `MarketScanner`; thêm mã mới vào `KNOWN_TRADFI_BASES` mà quên `SECTOR_MAP`, `DIRECT_INVERSES`, `KNOWN_COMMODITY_BASES`, `get_etf_leverage_tier`. | **Luật Bất Biến #3:** `core/scanner.py` là **SSOT duy nhất**. Thêm bất kỳ mã TradFi/ETF/Commodity nào PHẢI cập nhật đồng bộ đủ 5 bảng trong `scanner.py` + kiểm thử offline (`exchange=None`) cho cả 4 lớp. |
| **4** | **Ghi dữ liệu / Telemetry SAU lệnh `return` (Post-Return Dead Write)** | `BOM #146` gán `signal.metadata['layer45_guard'] = l45_metrics` SAU nhánh `if not l45_ok: return` → mọi lệnh bị Tầng 4.5 chặn đều mất sạch số liệu chẩn đoán trong Shadow DB (`BOM #148` phải dời lên trước `if`). | Viết chốt chặn `if not ok: return` trước rồi mới nhớ gắn metadata ở dưới. | **Luật Bất Biến #4:** Luôn gắn `metadata[...]` và `record_gate_event(...)` **TRƯỚC** mọi lệnh `return` / `continue` sớm. |
| **5** | **Sửa cấu trúc mới nhưng làm vỡ hợp đồng cũ (Cross-BOM Regression)** | `BOM #147` thêm `'TZA': 'TNA'` làm gãy `test_bom134` (`TZA -> IWM`); `BOM #131` sửa `closed_m1_count=0` làm hỏng fallback khi `df_m1` rỗng (`BOM #132`); `BOM #143` (`S01/S19`) đọc sai vị trí trường của `bot.py` (`BOM #147`). | Chỉ kiểm tra yêu cầu mới mà quên kiểm tra ngữ nghĩa hợp đồng của các BOM cũ (`test_bom125..147`). | **Luật Bất Biến #5:** BẮT BUỘC chạy **toàn bộ** `unittest discover -s tests` (không chỉ chạy 1 file test mới) sau mọi chỉnh sửa. |
| **6** | **Cache thời gian thực bỏ qua ranh giới nến & lệch đồng hồ (`monotonic` vs `time`)** | `DataCollector` cache 12s bỏ qua thời điểm đóng nến (`BOM #147`), rồi `done_bucket` neo `time.time()` thay vì `ram_df.index[-1]` (`BOM #148`); `_adaptive_trailing_metrics()` cache 60s không check rollover 15m và tính RVol dính nến hiện tại `iloc[-1]` (`BOM #148`). | Quên rằng nến sàn đóng đúng mốc `:00` UTC trong khi cache TTL trượt tự do, và nến cuối `iloc[-1]` chưa đóng làm méo RVol / gây look-ahead. | **Luật Bất Biến #6:** Mọi cache dữ liệu nến PHẢI kết hợp `bucket = int(last_bar_ts // tf_sec)`; mọi chỉ báo RVol/ATR/Chase PHẢI tính trên nến đã đóng (`iloc[-2]` / `iloc[-21:-1]`). |
| **7** | **Nhánh code cũ sống dai (Zombie Legacy Code) & Rò rỉ nhánh phụ** | `I2` legacy tồn tại đến `BOM #145`; ngưỡng `< 0.08` ATR `%` bị vá 2 lần (`#132`, `#147`); `get_tuning_for_symbol` gọi nhầm hàm không tồn tại (`#131`); CRR Snell bắn đúp Telegram khi đóng trượt (`#148`). | Nâng cấp bằng cách "đắp thêm nhánh mới" mà không grep và xóa sạch nhánh cũ cùng chức năng. | **Luật Bất Biến #7:** Quy tắc **Hard Purge** (Rule 0.9 #21) — thêm cơ chế mới thay thế cơ chế cũ PHẢI xóa sạch cơ chế cũ + thêm test khẳng định chuỗi cũ không còn tồn tại. |
| **8** | **Test phụ thuộc ngày/giờ thật & Mô phỏng mẫu hẹp** | `test_bom135` (`XAU/USDT`) và `test_bom147` (`MSTX/USDT`) PASS vào Thứ 5–6 nhưng FAIL ngay sáng Thứ 7 (`28/11`) vì không mock `is_weekend_gap_risk_window` / `is_us_market_open`; mô phỏng Tầng 4.5 đợt 1 chỉ chạy trên 136 vị thế 15M thay vì đủ 6 khung `1m..4h` trên 705 vị thế Live. | Không cô lập thời gian hệ thống trong test TradFi; chỉ lọc mẫu có nến 15M gần nhất khi backtest. | **Luật Bất Biến #8:** Mọi unit test chạm TradFi PHẢI mock `is_weekend_gap_risk_window` & `is_us_market_open`; mọi đề xuất thêm tầng lọc PHẢI kiểm định đa khung `1m/5m/15m/30m/1h/4h` trên toàn bộ lịch sử Live + Shadow OOS. |

---

## 5. VÌ SAO SỬA 1 LẦN / NÂNG CẤP DỄ PHÁT SINH LỖI MỚI & BẢN ĐỒ 14 ĐIỂM NÓNG

### 5.1. Tại sao sửa 1 chỗ trong TradeMatrix hay sinh lỗi ở chỗ khác?
Hệ thống TradeMatrix hiện là một đồ thị liên kết chặt **8.5 tầng × 4 lớp tài sản × 15 vũ khí × 2 chiều (LONG/SHORT)** nằm trong 2 file lõi rất lớn (`core/bot.py` ~1.32 MB, `ai/signal_aggregator.py` ~375 KB):
1. **Dữ liệu truyền qua `dict` không ép kiểu (`signal.metadata`, `stalking`, `details_json`, `market_chop_context`):** Sửa tên khóa hoặc vị trí lồng nhau ở Tầng A sẽ âm thầm biến thành `None`/`0.0` (không raise Exception!) ở Tầng B hoặc phòng Lab.
2. **Hiệu ứng chuỗi điều kiện ưu tiên (`if / elif / continue / return`):** Chèn 1 cổng chặn mới vào giữa vòng lặp (như Tầng 4.5, S01, S09, Anti-Paused-Hijack) có thể chặn luôn bước ghi telemetry, bước dời SL, hoặc bước cập nhật TP ở cuối hàm.
3. **Bất đối xứng giữa 4 lớp tài sản & 2 chiều:** Một ngưỡng đúng cho `ALTCOIN` (`1.30%`, `ATR >= 1.5%`) sẽ giết oan `TRADFI_1X` (`ATR 0.4%`) hoặc cắt non `TRADFI_ETF_3X` (`ATR 3.0%`), và Bear ETF (`SOXS/SQQQ`) luôn có **dấu ngược** với Benchmark ngành (`SOXL/QQQ`).
4. **Độ trễ đồng bộ giữa Tài liệu ↔ Test ↔ Config PC1/PC2:** Config runtime trên PC2 (`weapon_lifecycle.json`, `position_tuning.json`, `settings.yaml`) được giữ lại khi deploy — nếu code mới đổi schema mà không giữ tương thích ngược (fallback) sẽ hỏng trên PC2 ngay sau `RESTART.bat`.

### 5.2. Bản Đồ 14 Điểm Nóng Liên Kết Chéo (Mở rộng từ 10 Điểm Nóng V6.4 → 14 Điểm Nóng V6.5)
> [!WARNING]
> **KHI SỬA CỘT A, PHẢI KIỂM TRA ĐỒNG THỜI CỘT B & C TRƯỚC KHI VIẾT TEST:**

| # | Điểm nóng đang sửa (Cột A) | File / Tầng kéo theo (Cột B) | Bất biến / Lỗi ngầm dễ phát sinh (Cột C) |
| :-: | :--- | :--- | :--- |
| **1** | Vũ Khí (`VK1..VK15`) / `KB5` / `PAUSED` | `vietnamese_weapon_arsenal.py`, `weapon_lifecycle.json`, `signal_aggregator.py`, `bot.py` (`SLOT_A`) | Fallback Pha 2/3 cướp nhãn sang `VK3/VK7 PAUSED`; `SLOT_A` lệch `_strategy_votes()`; `EXPERIMENTAL` vượt trần `0.60x`. |
| **2** | Macro / JEV MTF / BearETF Shields | `jev_agent.py`, `signal_aggregator.py` (`POST-KB5`), `bot.py` (`_get_market_chop_context`) | Khiên chạy trước `KB5` bị lách; thiếu `BENCHMARK_LEADERS` fallback; `JEV` dùng `AND` thay vì `OR`/De Morgan. |
| **3** | **Phân loại Tài sản (Asset-Class SSOT)** *(Nâng cấp từ #3)* | `scanner.py`, `quantum_path_simulator.py`, `risk_manager.py`, `signal_aggregator.py`, `vietnamese_weapon_arsenal.py`, `full_historical_*simulator.py` | Phân loại nhầm `TRADFI_STOCK` khi offline (`exchange=None`); quên 1 trong 5 bảng (`KNOWN_TRADFI_BASES`, `KNOWN_COMMODITY_BASES`, `SECTOR_MAP`, `DIRECT_INVERSES`, `get_etf_leverage_tier`); `PAXG/HG` & Crypto trùng mã (`ON/DIA/MUBARAK`). |
| **4** | Quản lý SL / Cushion / Flash BE / MFE / D5 TP1–TP5 | `bot.py`, `binance_ws.py`, `quant_evolution_engine.py`, `position_tuning.json` | `False Exits > 0`; cắt non `< +0.85%`; `continue` nuốt TP1–TP5 lệnh tay; xóa nhầm mốc `0.40×TP1`; lỗi `-2021` không Market Exit. |
| **5** | WebSocket `@bookTicker` & Event Loop | `binance_ws.py`, `bot.py`, `exchange.py` | Ghi đè `asyncio.Event` bằng `bool`; làm tăng REST weight nhịp `2.0s`; lách Cầu dao IP `418/-1003` hoặc OrderFlow `429`. |
| **6** | Tính PnL ròng, DB Multi-Fill & `daily_auditor.py` | `bot.py`, `db_manager.py`, `risk_manager.py`, `vietnamese_weapon_arsenal.py`, `tools/daily_auditor.py` | Trừ phí kép khi `realized_pnl IS NULL`; xóa nhầm runner khi dọn synthetic close; mở SQLite PC2 thiếu `?mode=ro` + `PRAGMA query_only=ON`. |
| **7** | Shadow Pathfinder & Phòng LAB Tự Chủ (`Cổng 6`) | `shadow_pathfinder.py`, `quant_evolution_engine.py`, `signal_aggregator.py` (`_record_veto`) | Thiếu `weapon_id` tại `_record_veto`; **lệch tên khóa `details_json`** (`max_up_pct_240m` vs `max_up_pct`); quên `SELECT symbol` khi lọc Bear ETF; TOCTOU đặt mã vũ khí động. |
| **8** | Cloud Sync, License & Hot Reload | `cloud_sync.py`, `core/optimizer.py`, `dashboard/app.py` | Multi-token kill bot khi 1 token phụ lỗi; sai key `"project_id"`; reset balance/history quên reset `_v61_peak_equity` (kẹt Soft DD). |
| **9** | Dashboard API & Giao Diện Web (`/`, `/so-do-dong`) | `dashboard/app.py`, `index.html`, `pipeline_map.html` | JS `ReferenceError` crash `window.onload`; UI LIVE rơi về công thức DEMO; sai nhãn Tầng 4.5 / TP1 / SL; mất regex song ngữ. |
| **10** | Deploy Manifest, Docs & Clean Workspace | `deploy_web_client.py`, `clean_workspace.py`, `AGENTS.md`, `GEMINI.md` | Thiếu file mới trong `files_to_sync`; `AGENTS.md ≠ GEMINI.md` hoặc vượt `21 KB` (bị cắt cụt); sót file `.bak`/scratch. |
| **11** | **Tầng 4.5 Pre-Entry (`S_CLEAN_3`)** *(MỚI V6.5)* | `bot.py` (`_layer45_pre_entry_guard`, `_get_market_chop_context`), `shadow_pathfinder.py`, `gate_telemetry.py`, `pipeline_map.html` | Ghi `metadata['layer45_guard']` SAU `return`; để BTC Flash chặn nhầm `MAJOR`/`TRADFI`; dùng nến đang chạy `iloc[-1]` thay vì `iloc[-2]`; quên `weapon_id` trong `record_gate_event`. |
| **12** | **M1 Microstructure (`S01/S04/S09/V4/S19`) & Stalking** *(MỚI V6.5)* | `bot.py`, `data_collector.py`, `quant_evolution_engine.py` | Đọc sai cấu trúc `stalking` (top-level vs `metadata`); tự khóa khi đảo chiều stalking cùng mã; `S19` không đọc `v61_tp_lock_tiers[1][0]`; `V4`/`CRR Snell` bắn Telegram trước khi xác nhận đóng thành công. |
| **13** | **Cache Nến & Bucket Rollover** *(MỚI V6.5)* | `data_collector.py`, `bot.py` (`_adaptive_trailing_metrics`, `_get_market_chop_context`, `_get_position_closed_m1_count`) | Trộn `time.monotonic()` với Unix timestamp; trả nến cũ trong 12s–60s đầu sau khi đóng nến; tính RVol dính nến hiện tại `iloc[-1]` làm méo mẫu số; chia `vol_sma == 0`. |
| **14** | **Bộ Test Hồi Quy & Tính Tất Định Theo Thời Gian** *(MỚI V6.5)* | `tests/test_bom125.py` → `tests/test_bom148.py` | Test TradFi không mock `is_weekend_gap_risk_window` / `is_us_market_open` (FAIL vào Thứ 7/CN hoặc ngoài giờ Mỹ); test chỉ grep chuỗi thay vì ép chạy hành vi thật; `sqlite3.connect()` trong test thiếu `timeout=` gây cảnh báo Axis 07. |

---

## 6. QUY TRÌNH 6 BƯỚC "CHỐNG ĐẺ LỖI" BẮT BUỘC CHO PHIÊN 18+

1. **Grep Ngược & Đọc Đúng Writer Trước Khi Sửa:** Trước khi sửa bất kỳ khóa/hàm/bảng tài sản nào, grep toàn bộ kho code để thấy mọi điểm gọi, mọi nhánh `LONG/SHORT`, và đọc tận mắt nơi GHI dữ liệu.
2. **Xóa Sạch Code Cũ Khi Nâng Cấp (Hard Purge):** Không bao giờ đắp thêm `if` mới chồng lên nhánh cũ; kiểm tra luôn mọi nhánh `else`/fallback liền kề.
3. **Ghi Metadata & Telemetry TRƯỚC Mọi `return`/`continue`:** Đặc biệt tại các cổng veto mới và nhánh đóng khẩn cấp (riêng Telegram chỉ gửi SAU khi xác nhận đóng thành công).
4. **Viết Behavioral Test "Fail-Before-Fix" + Mock Thời Gian:** Với mọi lỗi P0/P1, tạo test tái hiện đúng dữ liệu thực (SQLite thật, DataFrame thật, mock phiên Mỹ/cuối tuần cho TradFi) và chạy toàn bộ `unittest discover -s tests`.
5. **Bắt Buộc Vượt 5 Cổng Kiểm Toán Offline (0 REST Binance):**
   - `venv\Scripts\python.exe -m unittest discover -s tests -p "test_*.py"` (**`170+ / 170+ PASS`**)
   - `venv\Scripts\python.exe tools/exhaustive_10axis_audit.py` (**`10/10 AXES PASSED | Critical Errors=0 | Advisory Warnings=0`**)
   - `venv\Scripts\python.exe tools/hard_constraints_gate.py` (**`11/11 PASSED`**)
   - `venv\Scripts\python.exe tools/audit_system_integrity.py` (**`6/6 PASSED`**)
   - `venv\Scripts\python.exe tools/full_historical_signal_and_position_simulator.py` (**`False Exits = 0 / 219 (0.0%)`**)
6. **Deploy Sạch & Xác Minh Hậu Deploy:** Chỉ chạy `deploy_web_client.py` khi người dùng duyệt → chạy `tools/clean_workspace.py` → kiểm chứng SHA-256 PC1 = PC2 và `PC1_BOT_PROCS = 0` → nhắc người dùng chạy `Fix_Time.bat` + `RESTART.bat` trên PC2 để nạp RAM mới.
