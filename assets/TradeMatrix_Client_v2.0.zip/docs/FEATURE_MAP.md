# BẢN ĐỒ TÍNH NĂNG & KIẾN TRÚC HỆ THỐNG TRADEMATRIX MASTER QUANT
> **Tài liệu tham chiếu toàn diện về cấu trúc mã nguồn, luồng dữ liệu, giao diện Web và các quy tắc vận hành.**

---

## 🗺️ 1. CẤU TRÚC THƯ MỤC & PHÂN LOẠI MÃ NGUỒN CHUẨN SSOT

```
D:\TRADE
├── 🧠 ai/                           # BỘ NÃO ĐỊNH LƯỢNG & ĐA KHUNG THỜI GIAN
│   ├── signal_aggregator.py         # Bộ tổng hợp tín hiệu, Veto Engine, Smart Inversion & Consensus
│   ├── order_flow_analyzer.py       # Phân tích dòng lệnh Taker CVD, tường thanh khoản 100-level & Smart Inversion
│   ├── jev_agent.py                 # Tác tử AI Đa Khung Thời Gian (Ollama 7B qwen2.5:7b)
│   ├── ml_model.py                  # Mô hình Directional Predictor (XGBoost / Ensemble 15M)
│   ├── feature_engine.py            # Trích xuất đặc trưng kỹ thuật số hóa
│   ├── market_regime.py             # Phân loại trạng thái thị trường (Trending vs. Choppy & Decoupling)
│   ├── quantum_path_simulator.py    # Mô phỏng đường đi Monte Carlo & Tính toán kỳ vọng toán học EV
│   ├── quant_validation_engine.py   # Động cơ kiểm định định lượng OOS Walk-Forward & Bootstrap
│   ├── ollama_agent.py              # Phân tích Bias vĩ mô bằng LLM cục bộ
│   ├── ollama_runtime.py            # Quản trị tiến trình Ollama ngầm
│   └── news_sentiment.py            # Phân tích tâm lý thị trường & Tin tức vĩ mô
│
├── ⚙️ core/                          # ĐỘNG CƠ THỰC THI & QUẢN TRỊ VỊ THẾ
│   ├── bot.py                       # Vòng lặp chính, Tầng 4.5 S_CLEAN_3 (BOM #146), Gói M1 S20_PRO_C (BOM #143), WebSocket 2.0s, Tam Tầng SL V4.1 & D5 5-TP Ladder
│   ├── exchange.py                  # Kết nối CCXT Binance Futures + Cầu Dao Bảo Vệ IP 418/-1003
│   ├── binance_ws.py                # Luồng WebSocket Combined Stream (@depth20@100ms + @bookTicker 0 REST weight + User Data Stream)
│   ├── shadow_pathfinder.py         # Cỗ máy theo dõi ngầm 2 chiều 60p/240p (Direct & Inverted, Tầng 4.5 STATION_5B, kẹp biên SL/TP 4 phân lớp)
│   ├── vietnamese_weapon_arsenal.py # Kho 15 Vũ Khí sống (VK1..VK15), Sơ Đồ Động /so-do-dong, 6 Cụm Alpha SQLite động & Động cơ Gói B (M21/M22 Freshness 6h)
│   ├── quant_evolution_engine.py    # Phòng LAB tự tiến hóa, Cổng 6 Dry-Run 8 Trạm (BOM #133), Graduation Guard & Risk Parity 4 phân lớp (position_tuning.json)
│   ├── scanner.py                   # SSOT Phân loại Tài sản: 294 mã TradFi, 42 mã Hàng hóa (PAXG/HG/XAU...), 10 ngành, 35 cặp DIRECT_INVERSES & bậc ETF 2x/3x
│   ├── data_collector.py            # Thu thập & tích lũy CSV OHLCV đa khung (vượt 500 nến, hủy cache theo candle-bucket rollover)
│   ├── gate_telemetry.py            # Quản trị Radar và ghi nhận sự kiện Telemetry Gate (gồm LAYER45_PRE_ENTRY)
│   ├── optimizer.py                 # Tự động tối ưu hóa trọng số chiến lược theo hiệu suất
│   └── telegram_notifier.py         # Kênh thông báo bất đồng bộ tức thời qua Telegram Bot
│
├── 🛡️ risk/                          # QUẢN TRỊ RỦI RO & PHÂN BỔ VỐN
│   └── risk_manager.py              # Cầu dao Max Drawdown, Mutual Exclusion 4 Rào chắn TradFi, Tương quan
│
├── 📈 strategies/                    # CHIẾN LƯỢC KỸ THUẬT NỀN TẢNG
│   ├── base_strategy.py             # Lớp cơ sở TradeSignal & Signal Enum
│   ├── trend_following.py           # Bám theo xu hướng EMA / ADX
│   ├── trap_detector.py             # Nhận diện bẫy giá cá mập (Pinbar râu vật lý >= 35%)
│   ├── momentum_breakout.py         # Đón sóng bùng nổ thanh khoản và phá vỡ cản
│   ├── mean_reversion.py            # Đón nhịp hồi phục khi RSI/Bollinger quá bán/quá mua
│   ├── hft_scalping.py              # Chiến lược lướt sóng ngắn hạn
│   └── smart_dca.py                 # Chiến lược phân bổ vốn thông minh
│
├── 🗄️ database/                      # CƠ SỞ DỮ LIỆU ĐỊNH LƯỢNG SQLITE WAL
│   └── db_manager.py                # Quản lý bảng trades, signals, bot_state, symbol_cooldowns
│
├── 🌐 dashboard/                     # GIAO DIỆN TERMINAL & REST API NỘI BỘ
│   ├── app.py                       # Flask Server (Port 5000) tiếp nhận lệnh điều khiển từ xa
│   └── templates/ & static/         # Giao diện giám sát cục bộ
│
├── ☁️ cloud_sync.py                  # CẦU NỐI ĐIỀU KHIỂN TỪ XA VỚI CLOUDFLARE WEB
│   # Lắng nghe Firestore bot_commands/{uid} và đẩy Telemetry thời gian thực
│
├── 📚 docs/                          # TÀI LIỆU VẬN HÀNH, PLAYBOOK & BẢNG ĐIỂM CHUẨN SSOT
│   ├── QUANT_WORKFLOW_PLAYBOOK.md   # [SSOT] Cẩm nang vận hành, phát triển & đối soát định lượng chuẩn quỹ 7 bước
│   ├── AI_TRUST_SCORECARD.md        # Bảng theo dõi và chấm điểm chỉ số tin cậy AI qua từng phiên
│   ├── FEATURE_MAP.md               # Bản đồ tính năng và sơ đồ kiến trúc hệ thống
│   ├── BINANCE_EXCHANGE_ERROR_CATALOG.md # Danh mục 13 mã lỗi Binance và 238 mã cổ phiếu TradFi
│   ├── BANG_QUAN_LY_VON_VA_DON_BAY.md # Quy chuẩn quản lý vốn và đòn bẩy đa tầng
│   └── DAILY_PLAYBOOK.md            # Cẩm nang tác chiến hằng ngày cho người dùng
│
├── 🧪 tools/                         # BỘ CÔNG CỤ TỰ KIỂM CHỨNG & RÀO CHẮN CỨNG
│   ├── exhaustive_10axis_audit.py   # [DEV] Quét tự động 10 Trục toàn kho (AST, ghost hasattr, IP ban, JS DOM VM, 100% Offline)
│   ├── daily_auditor.py             # [OPS] Kiểm toán PC2 Read-Only (?mode=ro + PRAGMA query_only=ON + mode='live'), tính PnL
│   ├── full_historical_signal_and_position_simulator.py # [QUANT] Replay toàn diện 760 vị thế + tín hiệu (False Exits = 0/219)
│   ├── true_signal_simulator.py     # [QUANT] Replay nến và đối soát tín hiệu thực tế từ log
│   ├── full_spectrum_impact_simulator.py # [QUANT] Mô phỏng 4 kịch bản đối chứng toàn diện (KB1-KB4)
│   ├── clean_workspace.py           # [CLEANUP] Tự động dọn sạch rác, script tạm thời trên PC1 và PC2
│   └── hard_constraints_gate.py     # [DEV] Linter quét 11 Rào chắn cứng & AST SymTable trước khi deploy
│
└── 📜 deploy_web_client.py          # TRẠM ĐÓNG GÓI, ĐỐI SOÁT SHA-256 LAN & ĐẨY CLOUDFLARE PAGES
```

---

## 🏛️ 2. MA TRẬN 4 PHÂN LỚP TÀI SẢN (`config/position_tuning.json` — V6.5)

Hệ thống phân định rạch ròi 4 phân lớp tài sản (`Risk Parity`, `cap_schema_version = 3`):

| Tiêu Chí | Major Crypto | TradFi 1x (Cổ Phiếu & Hàng Hóa) | TradFi ETF 2x/3x | Crypto Altcoins |
| :--- | :--- | :--- | :--- | :--- |
| **Mã đại diện** | `BTC`, `ETH`, `SOL`, `BNB`, `XRP` | `NVDA`, `TSLA`, `XAU`, `XAG`, `CL`, `HG`, `PAXG` | `SOXL/SOXS`, `TQQQ/SQQQ`, `MSTU/MSTZ`, `TNA/TZA` | `SUI`, `HYPE`, `ZRO`... |
| **Khung giờ GD** | 24/7 liên tục | Cổ phiếu: Wall Street; Hàng hóa (`XAU/PAXG/HG/CL`): 24/5 (khóa cuối tuần) | Phiên Wall Street (khóa cuối tuần) | 24/7 liên tục |
| **Đòn bẩy tối đa** | **≤ 5x** | **≤ 4x** | **≤ 2x** | **≤ 5x** |
| **Risk / Trần Notional** | `0.35%` / `20.0%` | `0.35%` / `18.0%` | `0.30%` / `15.0%` | `0.35%` / `15.0%` |
| **Khung SL `[min–max]`** | `1.0%–2.2%` (`1.7%`) | `1.0%–1.8%` (`1.4%`) | `1.8%–3.5%` (`2.75%`) | `1.5%–3.5%` (`2.5%`) |
| **TP1 / Bậc TP1→TP5** | `1.05%` (`50%`) | `0.95%` (`30%`) | `2.30%` (`50%`) | `1.35%` (`50%`) |
| **Khiên bảo vệ** | Không bị Weekend Shield chặn | **Weekend Shield chặn mở mới & kéo Net BE** (`weekend_close=false`) | Mutual Exclusion + Benchmark Shield + Đảo dấu Bear ETF | Tầng 4.5 BTC Flash (`1H 1.30% / 15M 1.25%`) + R4 Short Shield + Cooldown 180m |

---

## 🌐 3. BẢN ĐỒ GIAO DIỆN WEB DASHBOARD & REST API

Địa chỉ triển khai: `https://lehoangduc.pages.dev/dashboard` (kết nối với Local Port 5000 qua Cloud Sync).

### A. Các Nút Bấm Điều Khiển Trên Web:
1. **Nút `BẬT BOT` (`btnStartBot`):** Gửi command `start` -> Kiểm tra bản quyền -> Khởi chạy vòng lặp giao dịch.
2. **Nút `TẠM DỪNG` (`btnStopBot`):** Gửi command `stop` -> Dừng vòng lặp quét, giữ nguyên các lệnh và bảo vệ Binance.
3. **Nút `QUÉT 1 CHU KỲ` (`btnTriggerCycle`):** Gửi command `run_cycle` -> Chạy 1 vòng quét 50+ cặp ngay lập tức.
4. **Nút `ĐÓNG TOÀN BỘ` (`btnEmergencyClose`):** Gửi command `emergency_close` -> Đóng Market toàn bộ các vị thế đang mở.
5. **Nút `x Đóng` trên từng dòng vị thế:** Gửi command `close_position` kèm `{symbol, direction}` -> Đóng Market vị thế chỉ định.

### B. Các Endpoint REST API Trong [`dashboard/app.py`](file:///d:/TRADE/dashboard/app.py):
- `GET /`: Giao diện điều khiển chính (`dashboard/templates/index.html`, có nút dẫn sang `/so-do-dong`).
- `GET /so-do-dong`: Giao diện Sơ Đồ Luồng Định Lượng 7 Tầng (`dashboard/templates/pipeline_map.html`, đồ họa đường cong Bézier + 4 tab: Sơ đồ luồng, Vũ khí Mua/Bán/2 Chiều, Shadow 60p + 6 Cụm Alpha, Thực chiến).
- `GET /api/pipeline_live`: API thời gian thực (cache TTL 20–30s, `PRAGMA query_only=ON`, thread-safe) cấp dữ liệu cho `/so-do-dong`.
- `GET /api/status`: Lấy số dư, trạng thái bot, PnL ngày, radar candidates.
- `GET /api/positions`: Lấy danh sách vị thế đang mở từ RAM/Binance.
- `POST /api/positions/close`: Tiếp nhận đóng vị thế thủ công Market.
- `POST /api/start` & `POST /api/stop`: Khởi động và dừng bot an toàn (Idempotent).

---

## 🛡️ 4. HỆ THỐNG KIỂM TOÁN TỰ ĐỘNG, PLAYBOOK & BẢNG ĐIỂM TIN CẬY
- **Kế hoạch dứt điểm & Quy trình kiểm toán vòng đời tín hiệu đầu-cuối:** [`docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md`](file:///d:/TRADE/docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md) (SSOT bóc tách 4 căn nguyên gốc rễ tại sao nhiều phiên chưa hết lỗi, 3 nguyên tắc thép và checklist 7 bước nghiệm thu chống lỗi tái diễn).
- **SSOT Ma Trận Tam Tầng Bảo Vệ Vốn & Chốt Lãi Toàn Diện V4.1:** [`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md) (Quy chuẩn thoát lệnh 5 cấp: Chốt non ChoCH +0.12% -> +0.80%, Cushion SL -0.25%, Flash Hard BE max(0.85%, 0.85 ATR) sau 4.5m, CRR Snell Peak Exit và Trailing Stop).
- **Tổng kết bài học & các lỗi đã triệt tiêu tại Phiên 2, 3 & Kiểm tra:** [`docs/LESSONS_LEARNED_SESSION_2_3.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_2_3.md) (SSOT bóc tách 8 lỗi logic ngầm tầng sâu, kết quả mô phỏng 451 vị thế lịch sử và bài học tâm lý giao dịch).
- **Cẩm nang vận hành & đối soát định lượng chuẩn quỹ 7 bước:** [`docs/QUANT_WORKFLOW_PLAYBOOK.md`](file:///d:/TRADE/docs/QUANT_WORKFLOW_PLAYBOOK.md) (SSOT hướng dẫn quy trình đối soát 578 lệnh, giải phẫu 4 vấn đề vi mô và bảng phòng trừ 7 lỗi AI).
- **Bảng theo dõi chỉ số tin cậy AI:** [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md) (Chấm điểm định lượng sau mỗi phiên chat, theo dõi tiến độ nâng cao độ tin cậy đến ngưỡng an tâm tuyệt đối $\ge 95\%$).
- **Bộ 11 Rào chắn cứng bằng code:** [`tools/hard_constraints_gate.py`](file:///d:/TRADE/tools/hard_constraints_gate.py) (Tự động quét regex và AST chống NameError trước mọi lần build/deploy).
- **Kiểm toán viên thực chiến hằng ngày:** [`tools/daily_auditor.py`](file:///d:/TRADE/tools/daily_auditor.py) (Kiểm tra kết nối LAN, đọc database và quét lỗi runtime log thời gian thực).
- **Gói Vá Hoàn Thiện Đồng Bộ Phiên 3 (V4.2):** Sửa lỗi JEV Regex decision fallback ([`ai/jev_agent.py`](file:///d:/TRADE/ai/jev_agent.py)), hạ sàn RVol Altcoin đồng bộ 0.50x ([`core/bot.py`](file:///d:/TRADE/core/bot.py)), bổ sung Threading Lock chống spam API QQQ/SOXL, lưu vết 100% tín hiệu DB `signals`, khử gọi đúp `_select_dynamic_leverage`, và chuẩn hóa chuỗi log Opposing Veto.

- `POST /api/start` & `POST /api/stop`: Khởi động và dừng bot an toàn (Idempotent).
- `POST /api/run_cycle`: Kích hoạt chu kỳ phân tích thủ công.
