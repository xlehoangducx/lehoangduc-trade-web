# BẢN ĐỒ TÍNH NĂNG & KIẾN TRÚC HỆ THỐNG TRADEMATRIX MASTER QUANT
> **Tài liệu tham chiếu toàn diện về cấu trúc mã nguồn, luồng dữ liệu, giao diện Web và các quy tắc vận hành.**

---

## 🗺️ 1. CẤU TRÚC THƯ MỤC & PHÂN LOẠI MÃ NGUỒN (100 FILES)

```
D:\TRADE
├── 🧠 ai/                           # BỘ NÃO ĐỊNH LƯỢNG & ĐA KHUNG THỜI GIAN
│   ├── signal_aggregator.py         # Bộ tổng hợp tín hiệu, Veto Engine, Smart Inversion & Consensus
│   ├── jev_agent.py                 # Tác tử AI Đa Khung Thời Gian (Ollama 7B qwen2.5:7b)
│   ├── ml_model.py                  # Mô hình Directional Predictor (XGBoost 15M)
│   ├── feature_engine.py            # Trích xuất 91 đặc trưng kỹ thuật số hóa
│   ├── market_regime.py             # Phân loại trạng thái thị trường (Trending vs. Choppy)
│   ├── quantum_path_simulator.py    # Mô phỏng đường đi Monte Carlo & Tính toán kỳ vọng toán học EV
│   └── news_sentiment.py            # Phân tích tâm lý thị trường & Tin tức vĩ mô
│
├── ⚙️ core/                          # ĐỘNG CƠ THỰC THI & QUẢN TRỊ VỊ THẾ
│   ├── bot.py                       # Vòng lặp chính, Quản lý vị thế, Tam Tầng SL V3.0, Telemetry Gate
│   ├── exchange.py                  # Kết nối CCXT Binance Futures (REST API & WebSocket Streams)
│   ├── scanner.py                   # Quét Radar 50+ cặp tiền tệ tìm kiếm ứng viên Pha 1/Pha 2
│   ├── gate_telemetry.py            # Quản trị Radar và ghi nhận sự kiện Telemetry Gate Mode 7
│   ├── firebase_telemetry.py        # Đồng bộ trạng thái cấp thấp lên Firestore
│   ├── order_manager.py             # Quản trị vòng đời lệnh Limit Maker / Market
│   └── telegram_notifier.py         # Kênh thông báo tức thời qua Telegram Bot
│
├── 🛡️ risk/                          # QUẢN TRỊ RỦI RO & PHÂN BỔ VỐN
│   ├── risk_manager.py              # Cầu dao Max Drawdown 10%, Weekend Shield, Giới hạn Notional TradFi
│   └── position_sizer.py            # Phân bổ ký quỹ thích ứng theo độ biến động ATR và đòn bẩy sàn
│
├── 📈 strategies/                    # 4 CHIẾN LƯỢC KỸ THUẬT NỀN TẢNG
│   ├── trend_following.py           # Bám theo xu hướng EMA / MACD
│   ├── trap_detector.py             # Nhận diện bẫy giá cá mập (Pinbar râu vật lý >= 35%)
│   ├── momentum_breakout.py         # Đón sóng bùng nổ thanh khoản và phá vỡ cản
│   └── mean_reversion.py            # Đón nhịp hồi phục khi RSI/Bollinger quá bán/quá mua
│
├── 🌐 dashboard/ & web/              # GIAO DIỆN TERMINAL & REST API NỘI BỘ
│   ├── app.py                       # Flask Server (Port 5000) tiếp nhận lệnh điều khiển từ xa
│   └── templates/ & static/         # Giao diện giám sát cục bộ
│
├── ☁️ cloud_sync.py                  # CẦU NỐI ĐIỀU KHIỂN TỪ XA VỚI CLOUDFLARE WEB
│   # Lắng nghe Firestore bot_commands/{uid} và đẩy Telemetry thời gian thực
│
├── 🧪 tools/                         # BỘ CÔNG CỤ TỰ KIỂM CHỨNG & RÀO CHẮN CỨNG
│   ├── daily_auditor.py             # [OPS] Tự động kiểm toán PC2, tính PnL và chấm Rubric 100
│   ├── true_signal_simulator.py      # [QUANT] Replay nến và đối soát tín hiệu thực tế từ log
│   └── hard_constraints_gate.py     # [DEV] Linter quét AST chặn đứng lỗi lặp lại trước khi deploy
│
└── 📜 deploy_web_client.py          # TRẠM ĐÓNG GÓI, ĐỐI SOÁT LAN & ĐẨY CLOUDFLARE PAGES
```

---

## 🏛️ 2. MA TRẬN 3 LỚP TÀI SẢN (THREE-TIER ASSET MATRIX)

Hệ thống phân định rạch ròi 3 lớp tài sản với cơ chế quản trị rủi ro hoàn toàn khác nhau:

| Tiêu Chí | Lớp 1: Major Crypto | Lớp 2: TradFi (Cổ Phiếu Mỹ) | Lớp 3: Crypto Altcoins |
| :--- | :--- | :--- | :--- |
| **Mã đại diện** | `BTC/USDT`, `ETH/USDT`, `SOL/USDT` | `NVDA`, `TSLA`, `MRVL`, `TQQQ`, `XAU` | `MOVR`, `WAL`, `SKYAI`, `PEPE`... |
| **Khung giờ GD** | 24/7 liên tục | Phiên Wall Street (21:30 - 04:00 VN) | 24/7 liên tục |
| **Đòn bẩy tối đa** | Lên tới 10x - 20x | **Khống chế cứng $\le 4x$** | Thích ứng 3x - 10x |
| **Trần Ký Quỹ** | Linh hoạt theo vốn | **Tối đa 20% NAV** | Thích ứng theo Slot ($50 - $100: 2 lệnh) |
| **Đặc tính ATR** | Thấp & Trung bình (0.4% - 0.9%) | Bước giá cổ phiếu, rủi ro nhảy Gap | **Biến động cực cao (1.5% - 4.5%)** |
| **Cơ chế Stop-Loss** | Chuẩn 1.0 - 1.5 ATR | SL ngắn bám sát, cấm nới rộng | Cần vùng đệm chống Stop-Hunt râu nến |
| **Khiên bảo vệ** | Không bị Weekend Shield chặn | **Weekend Shield đóng trước thứ 7** | Cooldown 180m khi đóng lỗ |

---

## 🌐 3. BẢN ĐỒ GIAO DIỆN WEB DASHBOARD & REST API

Địa chỉ triển khai: `https://lehoangduc.pages.dev/dashboard` (kết nối với Local Port 5000 qua Cloud Sync).

### A. Các Nút Bấm Điều Khiển Trên Web:
1. **Nút `BẬT BOT` (`btnStartBot`):** Gửi command `start` -> Kiểm tra bản quyền -> Khởi chạy vòng lặp giao dịch.
2. **Nút `TẠM DỪNG` (`btnStopBot`):** Gửi command `stop` -> Dừng vòng lặp quét, giữ nguyên các lệnh và bảo vệ Binance.
3. **Nút `QUÉT 1 CHU KỲ` (`btnTriggerCycle`):** Gửi command `run_cycle` -> Chạy 1 vòng quét 50+ cặp ngay lập tức.
4. **Nút `ĐÓNG TOÀN BỘ` (`btnEmergencyClose`):** Gửi command `emergency_close` -> Đóng Market toàn bộ các vị thế đang mở.
5. **Nút `x Đóng` trên từng dòng vị thế:** Gửi command `close_position` kèm `{symbol, direction}` -> Đóng Market vị thế chỉ định.

### B. Các Endpoint REST API Trong [`dashboard/app.py`](file:///d:/TRADE/dashboard/app.py):
- `GET /api/status`: Lấy số dư, trạng thái bot, PnL ngày, radar candidates.
- `GET /api/positions`: Lấy danh sách vị thế đang mở từ RAM/Binance.
- `POST /api/positions/close`: Tiếp nhận đóng vị thế thủ công Market.
- `POST /api/start` & `POST /api/stop`: Khởi động và dừng bot an toàn (Idempotent).
- `POST /api/run_cycle`: Kích hoạt chu kỳ phân tích thủ công.
