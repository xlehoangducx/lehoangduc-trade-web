import logging
import math
import os
import re
import sqlite3
import threading
import time
from typing import Tuple, List, Dict, Any
from core.scanner import MarketScanner

logger = logging.getLogger(__name__)

_WK_CACHE_LOCK = threading.Lock()
_WK_STATS_CACHE: Dict[str, Any] = {"ts": 0.0, "db_path": "", "by_code": {}}

# [BOM #111C - M8 WILSON 95% LB + QUARTER-KELLY PRIORS]:
# Chuẩn hóa trên 2,072 sự kiện khớp nến UTC (V6.4 C5):
# - VK6 (67.7% LB) & VK8 (66.1% LB, OOS +$24.91) -> 1.35x
# - VK1 (60.8% LB), VK4 (59.8% LB), VK5 (62.1% LB) -> 1.25x
# - VK7 (58.9% LB nhưng OOS -$3.96) -> oos_cap_1x=True giữ 1.00x cho tới khi >= 5 live wins mới
# - VK3 (44.7% LB), VK2 -> nếu bật lại vẫn hạ 0.65x; VK9/VK10/VK11 (EXPERIMENTAL) giữ trung tính 1.00x khi < 15 live.
WEAPON_WILSON_PRIORS: Dict[str, Dict[str, Any]] = {
    "VK1": {"wins": 15, "n": 18, "experimental": False, "oos_cap_1x": False},
    "VK2": {"wins": 7, "n": 10, "experimental": True, "oos_cap_1x": True},
    "VK3": {"wins": 53, "n": 97, "experimental": False, "oos_cap_1x": True},
    "VK4": {"wins": 30, "n": 40, "experimental": False, "oos_cap_1x": False},
    "VK5": {"wins": 21, "n": 26, "experimental": False, "oos_cap_1x": False},
    "VK6": {"wins": 97, "n": 128, "experimental": False, "oos_cap_1x": False},
    "VK7": {"wins": 119, "n": 180, "experimental": False, "oos_cap_1x": True},
    "VK8": {"wins": 137, "n": 188, "experimental": False, "oos_cap_1x": False},
}


def _extract_weapon_code(tag: Any) -> str:
    """Trích mã vũ khí chuẩn VK1..VK14 từ weapon_id hoặc strategy tag."""
    txt = str(tag or "").upper()
    if not txt:
        return ""
    m = re.search(r"(VK\d+)", txt)
    return m.group(1) if m else ""


def wilson_lower_bound(wins: float, n: float, z: float = 1.96) -> float:
    """Tính cận dưới khoảng tin cậy Wilson Score 95% (chống phóng đại win rate trên mẫu nhỏ)."""
    if n <= 0:
        return 0.0
    p = max(0.0, min(1.0, float(wins) / float(n)))
    n_f = float(n)
    z2 = float(z) * float(z)
    denom = 1.0 + z2 / n_f
    center = p + z2 / (2.0 * n_f)
    rad = float(z) * math.sqrt((p * (1.0 - p) + z2 / (4.0 * n_f)) / n_f)
    return max(0.0, (center - rad) / denom)

class RiskManager:
    """
    Quản lý rủi ro: Kích thước lệnh, cắt lỗ, chốt lời, drawdown.
    (Risk management: Position sizing, SL/TP, drawdown)
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        risk_cfg = self.config.get("risk", self.config)
        self.max_risk_per_trade = float(risk_cfg.get("max_risk_per_trade", 0.0060))
        if self.max_risk_per_trade > 0.010:
            self.max_risk_per_trade = 0.0060 # Khống chế trần 0.60% equity
        self.max_drawdown = risk_cfg.get("max_drawdown", risk_cfg.get("max_drawdown_pct", 0.15)) # 15% drawdown tối đa
        trading_cfg = self.config.get("trading", {}) if isinstance(self.config, dict) else {}
        if not isinstance(trading_cfg, dict):
            trading_cfg = {}
        self.max_open_positions = int(
            trading_cfg.get(
                "max_open_trades",
                risk_cfg.get("max_open_positions", risk_cfg.get("max_open_trades", 3)),
            )
            or 3
        )
        self.max_margin_utilization_pct = risk_cfg.get("max_margin_utilization_pct", 0.50)
        self.trailing_stop_pct = risk_cfg.get("trailing_stop_pct", 0.02)
        
    def can_trade(
        self,
        signal: Any,
        balance: float,
        open_positions: List[Dict],
        account_equity: float = None,
        max_open_positions: int = None,
        base_max_open_positions: int = None,
    ) -> Tuple[bool, str]:
        """
        Kiểm tra xem có được phép giao dịch không dựa trên các quy tắc rủi ro.
        (Check if trading is allowed based on risk rules)
        """
        if not math.isfinite(float(balance)) or balance <= 0:
            return False, "Insufficient balance"

        raw_sig = getattr(signal, 'signal', None)
        direction = str(getattr(raw_sig, 'value', raw_sig) or '').lower()
        if direction not in ('buy', 'sell'):
            return False, "Signal is not actionable"

        price = getattr(signal, 'price', None)
        if price is None or not math.isfinite(float(price)) or float(price) <= 0:
            return False, "Invalid signal price"

        risk_pct = float(self.max_risk_per_trade)
        if not math.isfinite(risk_pct) or not 0 < risk_pct <= 0.05:
            return False, "max_risk_per_trade must be between 0 and 5%"
            
        effective_max_pos = int(max_open_positions) if max_open_positions is not None else int(self.max_open_positions)
        if len(open_positions) >= effective_max_pos:
            return False, f"Max open positions ({effective_max_pos}) reached"
            
        # `balance` is free margin in LIVE and uncommitted cash in DEMO. Add
        # already-used margin back when measuring the portfolio-wide limit.
        total_exposure = sum(
            float(pos.get('exchange_initial_margin') or pos.get('cost') or pos.get('position_size') or 0.0)
            for pos in open_positions
        )
        try:
            equity = float(account_equity) if account_equity is not None else float(balance) + total_exposure
        except (TypeError, ValueError, OverflowError):
            equity = float(balance) + total_exposure
        if not math.isfinite(equity) or equity <= 0:
            return False, "Invalid account equity"

        try:
            margin_limit = float(self.max_margin_utilization_pct)
            if margin_limit > 1:
                margin_limit /= 100.0
        except (TypeError, ValueError, OverflowError):
            margin_limit = 0.50
        if not math.isfinite(margin_limit) or not 0.05 <= margin_limit <= 0.90:
            margin_limit = 0.50
        # [M11 - CỔNG KÝ QUỸ CHỈ CHẶN KHI ĐÃ VƯỢT TRẦN]
        # Trước đây chỉ so `total_exposure >= equity * limit`, tức là chỉ chặn khi tổng ký quỹ
        # HIỆN TẠI đã vượt trần; lệnh mới cuối cùng vẫn có thể đẩy tổng ký quỹ vượt trần thêm
        # đúng một vị thế nữa rồi mới bị chặn ở lần sau. Nay phải chừa đủ chỗ cho MỘT vị thế
        # nữa mới cho mở: ngân sách ước lượng = max(ký quỹ bình quân hiện có, trần/số slot).
        margin_cap = equity * margin_limit
        try:
            slot_count = max(1, int(effective_max_pos))
        except (TypeError, ValueError):
            slot_count = 1
        next_position_budget = 0.0
        if margin_cap > 0:
            avg_margin = (total_exposure / len(open_positions)) if open_positions else 0.0
            next_position_budget = max(avg_margin, margin_cap / slot_count)
            if total_exposure + next_position_budget > margin_cap:
                return False, (
                    f"Total margin ({total_exposure:.2f}) + vị thế mới (~{next_position_budget:.2f}) "
                    f"vượt giới hạn an toàn ({margin_limit:.0%} of equity = {margin_cap:.2f})"
                )
            
        symbol = getattr(signal, 'symbol', '') or ''
        clean_sym = symbol.split(':')[0].strip().upper()
        base_coin = clean_sym.split('/')[0] if '/' in clean_sym else clean_sym
        is_tier1 = base_coin in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
        is_stock = MarketScanner.is_tradfi_stock(symbol)
        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol)
        is_tradfi = is_stock or is_commodity
        tradfi_cfg = self.config.get('tradfi', {})

        # Nếu đang ở chế độ CHỈ CỔ PHIẾU / HÀNG HÓA MỸ -> Khóa toàn bộ lệnh Crypto
        if tradfi_cfg.get('only_tradfi', False) and not is_tradfi:
            return False, "Chế độ 'Chỉ Cổ Phiếu Mỹ' đang bật (Tạm dừng giao dịch Crypto)"

        # QUẢN TRỊ RỦI RO RIÊNG BIỆT CHO CỔ PHIẾU & HÀNG HÓA TRADFI:
        if is_tradfi:
            if not tradfi_cfg.get('enabled', False):
                return False, "Chế độ giao dịch cổ phiếu/hàng hóa (TradFi) đang TẮT"
            # [M12 - KHIÊN CUỐI TUẦN SAI KHUNG GIỜ]
            # Trước đây dùng `is_us_weekend()` (chỉ đúng Thứ 7 & CN theo giờ New York), nên:
            #   • Hàng hóa 24/5 (XAU/XAG/CL) bị khóa oan cả ngày CN dù CME Globex đã mở lại
            #     từ 18:00 EST Chủ Nhật (05:00 Thứ Hai VN) - Lesson #30;
            #   • Ngược lại, chiều Thứ Sáu sau 16:00 EST đến hết Thứ Sáu (và rạng sáng Thứ Hai
            #     trước 09:30 EST) KHÔNG bị chặn, đúng lúc thanh khoản mỏng nhất và dễ dính
            #     gap mở cửa - chính rủi ro mà khiên này sinh ra để chặn.
            # Nay dùng `is_weekend_gap_risk_window(symbol)` - hàm đã phân định đúng lịch CME
            # Globex 24/5 cho hàng hóa và lịch NYSE/NASDAQ cho cổ phiếu.
            if MarketScanner.is_weekend_gap_risk_window(symbol):
                return False, "Khung giờ rủi ro gap cuối tuần: Tạm dừng mở vị thế mới TradFi"
            # Chỉ áp dụng bộ lọc giờ phiên Wall Street (09:30 - 16:00 EST) cho Cổ phiếu/ETF, miễn trừ cho Hàng hóa (Vàng XAU, Bạc XAG, Dầu CL giao dịch 24/5)
            if is_stock and tradfi_cfg.get('session_filter', True) and not MarketScanner.is_us_market_open():
                return False, "Thị trường cổ phiếu Mỹ đang ngoài phiên giao dịch (09:30 - 16:00 EST)"

            # [RÀO CHẮN UNMAPPED TRADFI GUARD]: Khóa tuyệt đối nếu mã TradFi chưa map ma trận ngành
            target_sector = MarketScanner.get_tradfi_sector(symbol)
            if not target_sector:
                logger.warning(
                    f"🔔 [UNMAPPED TRADFI GUARD] Mã {symbol} có tín hiệu nhưng CHƯA NẰM TRONG MA TRẬN NGÀNH! "
                    f"Bot tạm dừng vào lệnh để bảo vệ vốn."
                )
                return False, f"Mã TradFi {symbol} chưa được định danh trong Ma trận 10 Phân lớp Ngành"

            # [BỐN RÀO CHẮN TƯƠNG HỖ BẤT BIẾN TRADFI]:
            inv_pair = MarketScanner.get_tradfi_inverse_pair(symbol)
            same_underlying = MarketScanner.get_same_underlying_asset(symbol)

            for pos in open_positions:
                pos_sym = pos.get('symbol', '').split(':')[0].strip().upper()
                pos_base = pos_sym.split('/')[0] if '/' in pos_sym else pos_sym
                pos_dir = str(pos.get('direction', 'LONG')).upper()

                # Rào chắn 1: Khóa Đối Nghịch Tuyệt Đối (SOXL vs SOXS, TQQQ vs SQQQ)
                if inv_pair and (pos_sym == inv_pair or pos_base == MarketScanner._clean_base(inv_pair)):
                    return False, f"Khóa đối nghịch 1-1: Đang giữ {pos_sym} ({pos_dir}), cấm mở {symbol} ({direction.upper()})"

                # Rào chắn 2: Khóa Cổ Phiếu Cùng Gốc (NVDA vs NVDL, TSLA vs TSLL)
                if same_underlying and (pos_sym == same_underlying or pos_base == MarketScanner._clean_base(same_underlying)):
                    return False, f"Khóa cổ phiếu cùng gốc: Đang giữ {pos_sym}, cấm mở mã đòn bẩy {symbol}"
                if MarketScanner.get_same_underlying_asset(pos_sym) and (
                    MarketScanner.get_same_underlying_asset(pos_sym) == symbol
                    or MarketScanner._clean_base(MarketScanner.get_same_underlying_asset(pos_sym)) == MarketScanner._clean_base(symbol)
                ):
                    return False, f"Khóa cổ phiếu cùng gốc: Đang giữ mã đòn bẩy {pos_sym}, cấm mở {symbol}"

                # Rào chắn 4: Khống Chế Đơn Ngành (Tối đa 1 vị thế rủi ro cho mỗi nhóm ngành)
                pos_sector = MarketScanner.get_tradfi_sector(pos_sym)
                if pos_sector and target_sector and pos_sector == target_sector:
                    return False, f"Khống chế đơn ngành: Đang giữ {'lệnh rình mồi' if bool(pos.get('is_stalking') or pos.get('target_price') or not pos.get('entry_timestamp_ms')) else 'vị thế'} {pos_sym} thuộc nhóm {pos_sector}, tối đa 1 ghế/ngành"

            max_stock_trades = int(tradfi_cfg.get('max_open_trades', 1))
            current_stock_trades = sum(
                1 for pos in open_positions
                if MarketScanner.is_tradfi_stock(pos.get('symbol', ''))
                or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(pos.get('symbol', '')))
            )
            if current_stock_trades >= max_stock_trades:
                return False, f"Đã đạt số vị thế TradFi tối đa ({max_stock_trades})"

            max_stock_margin_ratio = float(tradfi_cfg.get('max_margin_ratio', 0.25))
            stock_margin_cap = equity * max_stock_margin_ratio
            current_stock_exposure = sum(
                float(pos.get('exchange_initial_margin') or pos.get('cost') or pos.get('position_size') or 0.0)
                for pos in open_positions
                if MarketScanner.is_tradfi_stock(pos.get('symbol', ''))
                or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(pos.get('symbol', '')))
            )
            avg_stock_margin = (current_stock_exposure / current_stock_trades) if current_stock_trades > 0 else 0.0
            next_stock_budget = max(avg_stock_margin, stock_margin_cap / max(1, max_stock_trades)) if current_stock_trades > 0 else min(next_position_budget, stock_margin_cap)
            if current_stock_exposure + next_stock_budget > stock_margin_cap + 1e-6:
                return False, (
                    f"Ký quỹ TradFi ({current_stock_exposure:.2f}) + vị thế mới "
                    f"(~{next_stock_budget:.2f}) vượt giới hạn an toàn "
                    f"({max_stock_margin_ratio:.0%} vốn)"
                )

        # Chặn rủi ro tương quan cùng chiều cho Crypto Altcoins (Portfolio Correlation Cap):
        # Tránh việc mở nhiều vị thế Altcoin cùng chiều (Short hoặc Long) đồng thời.
        # Hoàn toàn miễn trừ và không tính gộp các vị thế Cổ phiếu & Hàng hóa Mỹ (TradFi).
        elif not is_tier1 and open_positions:
            same_dir_altcoins = 0
            for pos in open_positions:
                pos_sym = pos.get('symbol', '')
                if MarketScanner.is_tradfi_stock(pos_sym) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(pos_sym)):
                    continue  # Bỏ qua TradFi, không tính vào tương quan Altcoin

                # MIỄN TRỪ FREE-ROLL: Nếu vị thế Altcoin cũ đã chốt lời từng phần hoặc dời SL về hòa vốn (rủi ro = 0),
                # không tính vào tương quan rủi ro để mở đường cho cơ chế Free-Roll Slot Recycling (Lesson #31)
                is_free_roll = False
                entry_p = float(pos.get('entry_price') or 0.0)
                sl_p = float(pos.get('stop_loss') or 0.0)
                p_dir = (pos.get('direction') or pos.get('side', '')).lower()
                if entry_p > 0 and sl_p > 0:
                    beyond_be = (
                        (p_dir in ('buy', 'long') and sl_p >= entry_p * 1.0012)
                        or (p_dir in ('sell', 'short') and sl_p <= entry_p * 0.9988)
                    )
                    # [V6.1 BOM #57 FIX]: Ở chế độ 0% (Kéo SL Bậc Thang 100%), partial_tp_done chỉ đánh dấu đã chạm TP1 chứ CHƯA chốt tiền tươi!
                    # Do đó chỉ tính Free-Roll theo partial_tp_done khi THỰC SỰ đã chốt lời một phần (tp1_take_pct > 0 hoặc partial_tp_pnl > 0);
                    # với chế độ 0%, BẮT BUỘC SL sàn phải thực sự vượt mốc hòa vốn (beyond_be) mới mở khóa gối đầu lệnh tiếp theo!
                    has_partial_tp_done = bool(pos.get('partial_tp_done')) and (
                        int(50 if pos.get('v61_tp1_take_pct') is None else pos.get('v61_tp1_take_pct')) > 0
                        or float(pos.get('partial_tp_pnl', 0.0) or 0.0) > 1e-6
                    )
                    # [BOM #6 & BOM #107A FIX]: Khớp 1-1 với _is_free_roll_position (core/bot.py:L2036 & Bất biến #28):
                    # Chỉ công nhận protection_confirmed khi protection_status in ('exchange_stop', 'exchange_stop_verified')
                    # và KHÔNG có cờ protection_review_required (chặn sl_order_id cũ khi stop_unverified!).
                    is_demo_pos = (
                        str(pos.get('order_id') or '').startswith('demo')
                        or str(pos.get('mode') or '').lower() == 'demo'
                    )
                    has_stop_id_or_demo = bool(pos.get('sl_order_id')) or is_demo_pos
                    protection_confirmed = (
                        not bool(pos.get('protection_review_required'))
                        and has_stop_id_or_demo
                        and (
                            pos.get('protection_status') in ('exchange_stop', 'exchange_stop_verified')
                            or bool(pos.get('exchange_stop_verified'))
                        )
                    )
                    # [BÀI HỌC 95 - FREE-ROLL RECYCLING CHUẨN XÁC]:
                    # Nếu vị thế đã đút túi TP1 thật (has_partial_tp_done) HOẶC SL đã dời vượt mốc hòa vốn,
                    # vị thế chính thức trở thành Free-Roll, giải phóng slot rủi ro cho coin Altcoin tiếp theo!
                    is_free_roll = (beyond_be or has_partial_tp_done) and protection_confirmed
                if is_free_roll:
                    continue

                pos_dir = (pos.get('direction') or pos.get('side', '')).lower()
                clean_pos_sym = pos_sym.split(':')[0].strip().upper()
                pos_base = clean_pos_sym.split('/')[0] if '/' in clean_pos_sym else clean_pos_sym
                is_pos_tier1 = pos_base in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
                is_same_dir = (direction in ('buy', 'long') and pos_dir in ('buy', 'long')) or \
                              (direction in ('sell', 'short') and pos_dir in ('sell', 'short'))
                if not is_pos_tier1 and is_same_dir:
                    same_dir_altcoins += 1
            # [QUY TẮC GỐI ĐẦU HÒA VỐN THÉP - CHỐNG LỖ CHÙM]:
            # Với quy mô 1 -> 4 Slot: Tối đa 1 vị thế Altcoin cùng chiều đang chịu rủi ro âm.
            # Chỉ khi lệnh đó đã chạm Khóa Hòa Vốn Thép (Free-Roll rủi ro = 0$) thì mới tự động mở khóa cho lệnh tiếp theo gối đầu!
            # Với quy mô >= 5 Slot (vốn lớn): cho phép tối đa 2 lệnh rủi ro cùng chiều + các lệnh Free-Roll gối đầu.
            cap_basis = int(base_max_open_positions) if base_max_open_positions is not None else int(effective_max_pos)
            correlation_cap = 1 if cap_basis <= 4 else 2
            if same_dir_altcoins >= correlation_cap:
                return False, f"Đã có {same_dir_altcoins} vị thế Altcoin cùng chiều ({direction.upper()}) chưa khóa hòa vốn (trần tương quan {correlation_cap}/{cap_basis}); chờ lệnh cũ hòa vốn hoặc mở chiều đối trọng"
        
        return True, "Trade allowed"
        
    def check_stop_loss(self, position: Dict, current_price: float) -> bool:
        """
        Kiểm tra xem giá hiện tại đã chạm mức cắt lỗ chưa.
        (Check if current price hit stop loss)
        """
        sl_price = position.get('stop_loss')
        direction = str(position.get('direction') or position.get('side') or '').upper()
        
        if not sl_price:
            return False
            
        if direction in ('BUY', 'LONG') and current_price <= sl_price:
            return True
        elif direction in ('SELL', 'SHORT') and current_price >= sl_price:
            return True
            
        return False
        
    def check_take_profit(self, position: Dict, current_price: float) -> bool:
        """
        Kiểm tra xem giá hiện tại đã chạm mức chốt lời chưa.
        (Check if current price hit take profit)
        """
        tp_price = position.get('take_profit')
        direction = str(position.get('direction') or position.get('side') or '').upper()
        
        if not tp_price:
            return False
            
        if direction in ('BUY', 'LONG') and current_price >= tp_price:
            return True
        elif direction in ('SELL', 'SHORT') and current_price <= tp_price:
            return True
            
        return False
        
    def check_drawdown(self, current_balance: float, peak_balance: float) -> Tuple[bool, float]:
        """
        Kiểm tra mức sụt giảm tài khoản (drawdown).
        Trả về (True/False tạm dừng giao dịch, tỷ lệ drawdown hiện tại).
        (Check account drawdown)
        """
        if peak_balance <= 0:
            return False, 0.0
            
        drawdown_pct = (peak_balance - current_balance) / peak_balance
        
        if drawdown_pct >= self.max_drawdown:
            logger.warning(f"Max drawdown reached! Current DD: {drawdown_pct*100:.2f}%")
            return True, drawdown_pct
            
        return False, drawdown_pct

    def should_take_profit_or_reinvest(self, pnl: float, balance: float) -> str:
        """
        Quản lý lợi nhuận thông minh.
        (Smart profit management based on total return)
        
        - Lợi nhuận < 20% vốn ban đầu: reinvest (tái đầu tư toàn bộ)
        - Lợi nhuận 20% - 50%: take_profit (rút 30% lợi nhuận)
        - Lợi nhuận > 50%: take_profit (rút 50% lợi nhuận)
        Lưu ý: hàm chỉ trả về action state, bot cần thực hiện logic rút tiền ở ngoài.
        """
        if pnl <= 0:
            return 'reinvest'
            
        initial_capital = balance - pnl
        
        if initial_capital <= 0:
            return 'reinvest'
            
        profit_pct = pnl / initial_capital
        
        if profit_pct < 0.20:
            return 'reinvest'
        elif 0.20 <= profit_pct <= 0.50:
            return 'partial' # Gợi ý rút 30%
        else:
            return 'take_profit' # Gợi ý rút 50%

    def _load_live_weapon_counts(self, db_path: str, cache_ttl_sec: float = 300.0) -> Dict[str, Tuple[int, int]]:
        """[BOM #112B FIX]: Đọc số lệnh Live thắng/tổng theo mã vũ khí qua SQLite read-only (PRAGMA query_only=ON, cache 5p).
        Gộp trùng order_id (ưu tiên 'Binance Fill' > 'aggregated'), đọc raw_json.weapon_id và đối chiếu signals PASSED 48h."""
        now_m = time.monotonic()
        with _WK_CACHE_LOCK:
            if (
                _WK_STATS_CACHE.get("db_path") == db_path
                and (now_m - float(_WK_STATS_CACHE.get("ts") or 0.0)) < cache_ttl_sec
            ):
                return dict(_WK_STATS_CACHE.get("by_code") or {})

        by_code: Dict[str, List[int]] = {}
        if db_path and os.path.exists(db_path):
            con = None
            try:
                import json
                from core.vietnamese_weapon_arsenal import WEAPON_ARSENAL_CATALOG, classify_signal_weapon

                con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=3.0)
                con.execute("PRAGMA query_only = ON;")

                sig_lookup: Dict[str, List[Tuple[int, str, str]]] = {}
                try:
                    sig_rows = con.execute(
                        """
                        SELECT timestamp, symbol, signal_type, indicators_json
                        FROM signals
                        ORDER BY id DESC LIMIT 2500
                        """
                    ).fetchall()
                    for s_ts, s_sym, s_dir, ind_raw in sig_rows:
                        if not ind_raw:
                            continue
                        try:
                            ind_j = json.loads(ind_raw)
                        except Exception:
                            continue
                        if str(ind_j.get("execution_status") or "").upper() != "PASSED":
                            continue
                        s_meta = ind_j.get("metadata") if isinstance(ind_j.get("metadata"), dict) else {}
                        w_id_sig = str(s_meta.get("weapon_id") or "")
                        if w_id_sig not in WEAPON_ARSENAL_CATALOG:
                            w_id_sig = classify_signal_weapon(meta=s_meta, direction=str(s_dir or "")).get("id", "")
                        code_sig = _extract_weapon_code(w_id_sig)
                        if not code_sig:
                            continue
                        k_sym = str(s_sym or "").replace("/", "").split(":")[0].upper()
                        try:
                            ts_ms = int(float(s_ts or 0))
                        except Exception:
                            ts_ms = 0
                        if 0 < ts_ms < 10_000_000_000:
                            ts_ms *= 1000
                        sig_lookup.setdefault(k_sym, []).append((ts_ms, str(s_dir or "").upper(), code_sig))
                except Exception:
                    pass

                rows = con.execute(
                    """
                    SELECT timestamp, symbol, side, strategy, realized_pnl, pnl, fee, order_id, raw_json
                    FROM trades
                    WHERE mode = 'live'
                      AND (close_reason IS NOT NULL OR ABS(COALESCE(realized_pnl, pnl, 0.0)) > 1e-8)
                    ORDER BY id DESC LIMIT 1500
                    """
                ).fetchall()

                grouped_live: Dict[str, Dict[str, Any]] = {}
                for t_ts, sym, side_val, strat_val, rpnl_raw, pnl_raw, fee_v, ord_id, raw_j_str in rows:
                    try:
                        t_ms = int(float(t_ts or 0))
                        if 0 < t_ms < 10_000_000_000:
                            t_ms *= 1000
                    except Exception:
                        t_ms = 0
                    raw_wid = ""
                    try:
                        if raw_j_str:
                            _rj = json.loads(raw_j_str) if isinstance(raw_j_str, str) else raw_j_str
                            if isinstance(_rj, dict):
                                raw_wid = str(_rj.get("weapon_id") or _rj.get("weapon_code") or "").strip()
                    except Exception:
                        raw_wid = ""
                    k_sym = str(sym or "").replace("/", "").split(":")[0].upper()
                    grp_key = f"{k_sym}_{ord_id}" if ord_id else f"{k_sym}_{t_ms // 60000}"
                    is_bf_row = (str(strat_val or "").strip().lower() == "binance fill")
                    row_net = (float(rpnl_raw) - float(fee_v or 0.0)) if rpnl_raw is not None else float(pnl_raw or 0.0)
                    g = grouped_live.get(grp_key)
                    if g is None:
                        grouped_live[grp_key] = {
                            "ts_ms": t_ms,
                            "k_sym": k_sym,
                            "side": str(side_val or "").upper(),
                            "strategy": str(strat_val or "").strip(),
                            "bf_pnl": row_net if is_bf_row else 0.0,
                            "bot_pnl": 0.0 if is_bf_row else row_net,
                            "has_bf": is_bf_row,
                            "raw_wid": raw_wid,
                        }
                    else:
                        if is_bf_row:
                            g["bf_pnl"] += row_net
                            g["has_bf"] = True
                        else:
                            g["bot_pnl"] += row_net
                        if t_ms > g["ts_ms"]:
                            g["ts_ms"] = t_ms
                        if raw_wid and not g.get("raw_wid"):
                            g["raw_wid"] = raw_wid

                generic_strats = (
                    "", "binance fill", "aggregated", "unknown", "manual",
                    "manual_adopted", "reconciled", "exchange_reconciled",
                )
                for g in grouped_live.values():
                    net_pnl = g["bf_pnl"] if g.get("has_bf") else g["bot_pnl"]
                    code = _extract_weapon_code(g.get("raw_wid"))
                    strat_clean = g["strategy"]
                    if not code:
                        code = _extract_weapon_code(strat_clean)
                    pos_dir = "LONG" if g["side"] == "SELL" else "SHORT"
                    sig_dir_need = "BUY" if pos_dir == "LONG" else "SELL"
                    if not code and strat_clean.lower() in generic_strats:
                        best_dt = 48 * 3600 * 1000 + 1
                        for s_ms, s_d, s_code in (sig_lookup.get(g["k_sym"]) or []):
                            dt_diff = g["ts_ms"] - s_ms
                            if 0 <= dt_diff <= 48 * 3600 * 1000 and s_d == sig_dir_need and dt_diff < best_dt:
                                best_dt = dt_diff
                                code = s_code
                    if not code and strat_clean:
                        w_fb = classify_signal_weapon(meta={"strategy": strat_clean, "direction": pos_dir}, direction=pos_dir)
                        code = _extract_weapon_code(w_fb.get("id", ""))
                    if not code:
                        continue
                    rec = by_code.setdefault(code, [0, 0])
                    rec[1] += 1
                    if float(net_pnl or 0.0) > 0.0:
                        rec[0] += 1
            except Exception:
                pass
            finally:
                if con is not None:
                    try:
                        con.close()
                    except Exception:
                        pass

        out = {k: (v[0], v[1]) for k, v in by_code.items()}
        with _WK_CACHE_LOCK:
            _WK_STATS_CACHE["ts"] = time.monotonic()
            _WK_STATS_CACHE["db_path"] = db_path
            _WK_STATS_CACHE["by_code"] = dict(out)
        return out

    def get_weapon_wilson_kelly_multiplier(
        self,
        weapon_id: str,
        db_path: str = "data/trade_bot.db",
    ) -> Tuple[float, Dict[str, Any]]:
        """
        [BOM #111C - M8 WILSON 95% LB + QUARTER-KELLY SIZING]:
        Phóng to vốn thận trọng cho vũ khí có Wilson Lower Bound >= 58%..65% (1.25x..1.35x),
        giữ trung tính 1.00x cho mẫu thử nghiệm < 15 lệnh, và co nhỏ 0.65x với vũ khí LB < 45%.
        Fail-safe trả về (1.0, ...) nếu gặp sự cố đọc DB.
        """
        try:
            code = _extract_weapon_code(weapon_id)
            if not code:
                return 1.0, {"weapon_code": "", "wilson_lb_pct": 0.0, "n_total": 0, "tier": "UNCLASSIFIED"}

            live_counts = self._load_live_weapon_counts(db_path)
            live_w, live_n = live_counts.get(code, (0, 0))
            prior = WEAPON_WILSON_PRIORS.get(code)

            if prior is None:
                # VK9, VK10, VK11, DYN-*: giữ trung tính 1.00x khi mẫu Live < 15
                if live_n < 15:
                    return 1.0, {
                        "weapon_code": code,
                        "wilson_lb_pct": round(wilson_lower_bound(live_w, live_n) * 100.0, 1) if live_n > 0 else 0.0,
                        "n_total": live_n,
                        "live_n": live_n,
                        "tier": "EXPERIMENTAL_NEUTRAL",
                    }
                w_tot, n_tot = live_w, live_n
                is_exp, oos_cap = False, False
            else:
                is_exp = bool(prior.get("experimental"))
                oos_cap = bool(prior.get("oos_cap_1x"))
                if is_exp and live_n < 15:
                    return 1.0, {
                        "weapon_code": code,
                        "wilson_lb_pct": round(wilson_lower_bound(prior["wins"] + live_w, prior["n"] + live_n) * 100.0, 1),
                        "n_total": prior["n"] + live_n,
                        "live_n": live_n,
                        "tier": "EXPERIMENTAL_NEUTRAL",
                    }
                w_tot = int(prior["wins"]) + live_w
                n_tot = int(prior["n"]) + live_n

            lb = wilson_lower_bound(w_tot, n_tot)
            if lb >= 0.65:
                mult = 1.35
                tier = "KELLY_TIER_A"
            elif lb >= 0.58:
                mult = 1.25
                tier = "KELLY_TIER_B"
            elif n_tot >= 10 and lb < 0.45:
                mult = 0.65
                tier = "KELLY_DEFENSIVE"
            else:
                mult = 1.00
                tier = "KELLY_NEUTRAL"

            if oos_cap and live_w < 5 and mult > 1.00:
                mult = 1.00
                tier = f"{tier}_OOS_CAP"

            mult = max(0.65, min(1.35, float(mult)))
            return mult, {
                "weapon_code": code,
                "wilson_lb_pct": round(lb * 100.0, 1),
                "w_total": w_tot,
                "n_total": n_tot,
                "live_w": live_w,
                "live_n": live_n,
                "tier": tier,
            }
        except Exception as e:
            logger.debug("Wilson-Kelly fallback cho %s: %s", weapon_id, e)
            return 1.0, {"weapon_code": "", "wilson_lb_pct": 0.0, "n_total": 0, "fallback": True}
