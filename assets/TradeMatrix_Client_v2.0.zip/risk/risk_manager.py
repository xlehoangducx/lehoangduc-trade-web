import logging
import math
from typing import Tuple, List, Dict, Any
from core.scanner import MarketScanner

logger = logging.getLogger(__name__)

class RiskManager:
    """
    Quản lý rủi ro: Kích thước lệnh, cắt lỗ, chốt lời, drawdown.
    (Risk management: Position sizing, SL/TP, drawdown)
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        risk_cfg = self.config.get("risk", self.config)
        self.max_risk_per_trade = float(risk_cfg.get("max_risk_per_trade", 0.0060))
        if self.max_risk_per_trade > 0.010:
            self.max_risk_per_trade = 0.0060 # Khống chế trần 0.60% equity
        self.max_drawdown = risk_cfg.get("max_drawdown", risk_cfg.get("max_drawdown_pct", 0.15)) # 15% drawdown tối đa
        self.max_open_positions = risk_cfg.get("max_open_positions", risk_cfg.get("max_open_trades", 3))
        self.max_margin_utilization_pct = risk_cfg.get("max_margin_utilization_pct", 0.50)
        self.trailing_stop_pct = risk_cfg.get("trailing_stop_pct", 0.02)
        
    def can_trade(
        self,
        signal: Any,
        balance: float,
        open_positions: List[Dict],
        account_equity: float = None,
        max_open_positions: int = None,
    ) -> Tuple[bool, str]:
        """
        Kiểm tra xem có được phép giao dịch không dựa trên các quy tắc rủi ro.
        (Check if trading is allowed based on risk rules)
        """
        if not math.isfinite(float(balance)) or balance <= 0:
            return False, "Insufficient balance"

        raw_sig = getattr(signal, 'signal', None)
        direction = str(getattr(raw_sig, 'value', raw_sig) or '').lower()
        if direction not in ('buy', 'sell'):
            return False, "Signal is not actionable"

        price = getattr(signal, 'price', None)
        if price is None or not math.isfinite(float(price)) or float(price) <= 0:
            return False, "Invalid signal price"

        risk_pct = float(self.max_risk_per_trade)
        if not math.isfinite(risk_pct) or not 0 < risk_pct <= 0.05:
            return False, "max_risk_per_trade must be between 0 and 5%"
            
        effective_max_pos = int(max_open_positions) if max_open_positions is not None else int(self.max_open_positions)
        if len(open_positions) >= effective_max_pos:
            return False, f"Max open positions ({effective_max_pos}) reached"
            
        # `balance` is free margin in LIVE and uncommitted cash in DEMO. Add
        # already-used margin back when measuring the portfolio-wide limit.
        total_exposure = sum(
            float(pos.get('exchange_initial_margin') or pos.get('cost') or pos.get('position_size') or 0.0)
            for pos in open_positions
        )
        try:
            equity = float(account_equity) if account_equity is not None else float(balance) + total_exposure
        except (TypeError, ValueError, OverflowError):
            equity = float(balance) + total_exposure
        if not math.isfinite(equity) or equity <= 0:
            return False, "Invalid account equity"

        try:
            margin_limit = float(self.max_margin_utilization_pct)
            if margin_limit > 1:
                margin_limit /= 100.0
        except (TypeError, ValueError, OverflowError):
            margin_limit = 0.50
        if not math.isfinite(margin_limit) or not 0.05 <= margin_limit <= 0.90:
            margin_limit = 0.50
        # [M11 - CỔNG KÝ QUỸ CHỈ CHẶN KHI ĐÃ VƯỢT TRẦN]
        # Trước đây chỉ so `total_exposure >= equity * limit`, tức là chỉ chặn khi tổng ký quỹ
        # HIỆN TẠI đã vượt trần; lệnh mới cuối cùng vẫn có thể đẩy tổng ký quỹ vượt trần thêm
        # đúng một vị thế nữa rồi mới bị chặn ở lần sau. Nay phải chừa đủ chỗ cho MỘT vị thế
        # nữa mới cho mở: ngân sách ước lượng = max(ký quỹ bình quân hiện có, trần/số slot).
        margin_cap = equity * margin_limit
        try:
            slot_count = max(1, int(effective_max_pos))
        except (TypeError, ValueError):
            slot_count = 1
        next_position_budget = 0.0
        if margin_cap > 0:
            avg_margin = (total_exposure / len(open_positions)) if open_positions else 0.0
            next_position_budget = max(avg_margin, margin_cap / slot_count)
            if total_exposure + next_position_budget > margin_cap:
                return False, (
                    f"Total margin ({total_exposure:.2f}) + vị thế mới (~{next_position_budget:.2f}) "
                    f"vượt giới hạn an toàn ({margin_limit:.0%} of equity = {margin_cap:.2f})"
                )
            
        symbol = getattr(signal, 'symbol', '') or ''
        clean_sym = symbol.split(':')[0].strip().upper()
        base_coin = clean_sym.split('/')[0] if '/' in clean_sym else clean_sym
        is_tier1 = base_coin in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
        is_stock = MarketScanner.is_tradfi_stock(symbol)
        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol)
        is_tradfi = is_stock or is_commodity
        tradfi_cfg = self.config.get('tradfi', {})

        # Nếu đang ở chế độ CHỈ CỔ PHIẾU / HÀNG HÓA MỸ -> Khóa toàn bộ lệnh Crypto
        if tradfi_cfg.get('only_tradfi', False) and not is_tradfi:
            return False, "Chế độ 'Chỉ Cổ Phiếu Mỹ' đang bật (Tạm dừng giao dịch Crypto)"

        # QUẢN TRỊ RỦI RO RIÊNG BIỆT CHO CỔ PHIẾU & HÀNG HÓA TRADFI:
        if is_tradfi:
            if not tradfi_cfg.get('enabled', False):
                return False, "Chế độ giao dịch cổ phiếu/hàng hóa (TradFi) đang TẮT"
            # [M12 - KHIÊN CUỐI TUẦN SAI KHUNG GIỜ]
            # Trước đây dùng `is_us_weekend()` (chỉ đúng Thứ 7 & CN theo giờ New York), nên:
            #   • Hàng hóa 24/5 (XAU/XAG/CL) bị khóa oan cả ngày CN dù CME Globex đã mở lại
            #     từ 18:00 EST Chủ Nhật (05:00 Thứ Hai VN) - Lesson #30;
            #   • Ngược lại, chiều Thứ Sáu sau 16:00 EST đến hết Thứ Sáu (và rạng sáng Thứ Hai
            #     trước 09:30 EST) KHÔNG bị chặn, đúng lúc thanh khoản mỏng nhất và dễ dính
            #     gap mở cửa - chính rủi ro mà khiên này sinh ra để chặn.
            # Nay dùng `is_weekend_gap_risk_window(symbol)` - hàm đã phân định đúng lịch CME
            # Globex 24/5 cho hàng hóa và lịch NYSE/NASDAQ cho cổ phiếu.
            if MarketScanner.is_weekend_gap_risk_window(symbol):
                return False, "Khung giờ rủi ro gap cuối tuần: Tạm dừng mở vị thế mới TradFi"
            # Chỉ áp dụng bộ lọc giờ phiên Wall Street (09:30 - 16:00 EST) cho Cổ phiếu/ETF, miễn trừ cho Hàng hóa (Vàng XAU, Bạc XAG, Dầu CL giao dịch 24/5)
            if is_stock and tradfi_cfg.get('session_filter', True) and not MarketScanner.is_us_market_open():
                return False, "Thị trường cổ phiếu Mỹ đang ngoài phiên giao dịch (09:30 - 16:00 EST)"

            # [RÀO CHẮN UNMAPPED TRADFI GUARD]: Khóa tuyệt đối nếu mã TradFi chưa map ma trận ngành
            target_sector = MarketScanner.get_tradfi_sector(symbol)
            if not target_sector:
                logger.warning(
                    f"🔔 [UNMAPPED TRADFI GUARD] Mã {symbol} có tín hiệu nhưng CHƯA NẰM TRONG MA TRẬN NGÀNH! "
                    f"Bot tạm dừng vào lệnh để bảo vệ vốn."
                )
                return False, f"Mã TradFi {symbol} chưa được định danh trong Ma trận 10 Phân lớp Ngành"

            # [BỐN RÀO CHẮN TƯƠNG HỖ BẤT BIẾN TRADFI]:
            inv_pair = MarketScanner.get_tradfi_inverse_pair(symbol)
            same_underlying = MarketScanner.get_same_underlying_asset(symbol)

            for pos in open_positions:
                pos_sym = pos.get('symbol', '').split(':')[0].strip().upper()
                pos_base = pos_sym.split('/')[0] if '/' in pos_sym else pos_sym
                pos_dir = str(pos.get('direction', 'LONG')).upper()

                # Rào chắn 1: Khóa Đối Nghịch Tuyệt Đối (SOXL vs SOXS, TQQQ vs SQQQ)
                if inv_pair and (pos_sym == inv_pair or pos_base == MarketScanner._clean_base(inv_pair)):
                    return False, f"Khóa đối nghịch 1-1: Đang giữ {pos_sym} ({pos_dir}), cấm mở {symbol} ({direction.upper()})"

                # Rào chắn 2: Khóa Cổ Phiếu Cùng Gốc (NVDA vs NVDL, TSLA vs TSLL)
                if same_underlying and (pos_sym == same_underlying or pos_base == MarketScanner._clean_base(same_underlying)):
                    return False, f"Khóa cổ phiếu cùng gốc: Đang giữ {pos_sym}, cấm mở mã đòn bẩy {symbol}"
                if MarketScanner.get_same_underlying_asset(pos_sym) and (
                    MarketScanner.get_same_underlying_asset(pos_sym) == symbol
                    or MarketScanner._clean_base(MarketScanner.get_same_underlying_asset(pos_sym)) == MarketScanner._clean_base(symbol)
                ):
                    return False, f"Khóa cổ phiếu cùng gốc: Đang giữ mã đòn bẩy {pos_sym}, cấm mở {symbol}"

                # Rào chắn 4: Khống Chế Đơn Ngành (Tối đa 1 vị thế rủi ro cho mỗi nhóm ngành)
                pos_sector = MarketScanner.get_tradfi_sector(pos_sym)
                if pos_sector and target_sector and pos_sector == target_sector:
                    return False, f"Khống chế đơn ngành: Đang giữ {'lệnh rình mồi' if bool(pos.get('is_stalking') or pos.get('target_price') or not pos.get('entry_timestamp_ms')) else 'vị thế'} {pos_sym} thuộc nhóm {pos_sector}, tối đa 1 ghế/ngành"

            max_stock_trades = int(tradfi_cfg.get('max_open_trades', 1))
            current_stock_trades = sum(
                1 for pos in open_positions
                if MarketScanner.is_tradfi_stock(pos.get('symbol', ''))
                or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(pos.get('symbol', '')))
            )
            if current_stock_trades >= max_stock_trades:
                return False, f"Đã đạt số vị thế TradFi tối đa ({max_stock_trades})"

            max_stock_margin_ratio = float(tradfi_cfg.get('max_margin_ratio', 0.25))
            stock_margin_cap = equity * max_stock_margin_ratio
            current_stock_exposure = sum(
                float(pos.get('exchange_initial_margin') or pos.get('cost') or pos.get('position_size') or 0.0)
                for pos in open_positions
                if MarketScanner.is_tradfi_stock(pos.get('symbol', ''))
                or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(pos.get('symbol', '')))
            )
            avg_stock_margin = (current_stock_exposure / current_stock_trades) if current_stock_trades > 0 else 0.0
            next_stock_budget = max(avg_stock_margin, stock_margin_cap / max(1, max_stock_trades)) if current_stock_trades > 0 else min(next_position_budget, stock_margin_cap)
            if current_stock_exposure + next_stock_budget > stock_margin_cap + 1e-6:
                return False, (
                    f"Ký quỹ TradFi ({current_stock_exposure:.2f}) + vị thế mới "
                    f"(~{next_stock_budget:.2f}) vượt giới hạn an toàn "
                    f"({max_stock_margin_ratio:.0%} vốn)"
                )

        # Chặn rủi ro tương quan cùng chiều cho Crypto Altcoins (Portfolio Correlation Cap):
        # Tránh việc mở nhiều vị thế Altcoin cùng chiều (Short hoặc Long) đồng thời.
        # Hoàn toàn miễn trừ và không tính gộp các vị thế Cổ phiếu & Hàng hóa Mỹ (TradFi).
        elif not is_tier1 and open_positions:
            same_dir_altcoins = 0
            for pos in open_positions:
                pos_sym = pos.get('symbol', '')
                if MarketScanner.is_tradfi_stock(pos_sym) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(pos_sym)):
                    continue  # Bỏ qua TradFi, không tính vào tương quan Altcoin

                # MIỄN TRỪ FREE-ROLL: Nếu vị thế Altcoin cũ đã chốt lời từng phần hoặc dời SL về hòa vốn (rủi ro = 0),
                # không tính vào tương quan rủi ro để mở đường cho cơ chế Free-Roll Slot Recycling (Lesson #31)
                is_free_roll = False
                entry_p = float(pos.get('entry_price') or 0.0)
                sl_p = float(pos.get('stop_loss') or 0.0)
                p_dir = (pos.get('direction') or pos.get('side', '')).lower()
                if entry_p > 0 and sl_p > 0:
                    beyond_be = (
                        (p_dir in ('buy', 'long') and sl_p >= entry_p * 1.0012)
                        or (p_dir in ('sell', 'short') and sl_p <= entry_p * 0.9988)
                    )
                    has_partial_tp_done = bool(pos.get('partial_tp_done'))
                    protection_confirmed = bool(
                        pos.get('sl_order_id') or pos.get('exchange_stop_verified')
                        or pos.get('protection_status') == 'exchange_stop'
                    )
                    # [BÀI HỌC 95 - FREE-ROLL RECYCLING CHUẨN XÁC]:
                    # Nếu vị thế đã đút túi TP1 (partial_tp_done) HOẶC SL đã dời vượt mốc hòa vốn,
                    # vị thế chính thức trở thành Free-Roll, giải phóng slot rủi ro cho coin Altcoin tiếp theo!
                    is_free_roll = (beyond_be or has_partial_tp_done) and protection_confirmed
                if is_free_roll:
                    continue

                pos_dir = (pos.get('direction') or pos.get('side', '')).lower()
                clean_pos_sym = pos_sym.split(':')[0].strip().upper()
                pos_base = clean_pos_sym.split('/')[0] if '/' in clean_pos_sym else clean_pos_sym
                is_pos_tier1 = pos_base in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
                is_same_dir = (direction in ('buy', 'long') and pos_dir in ('buy', 'long')) or \
                              (direction in ('sell', 'short') and pos_dir in ('sell', 'short'))
                if not is_pos_tier1 and is_same_dir:
                    same_dir_altcoins += 1
            # [BÀI HỌC 102]: Trần tương quan Altcoin co giãn theo số vị thế hiệu dụng (effective_max_pos).
            # Với vốn 100$ (effective_max_pos = 2) -> cap = 1; khi vốn tăng (max_pos >= 3) -> cap = 2.
            correlation_cap = max(1, min(int(effective_max_pos) - 1, 2))
            if same_dir_altcoins >= correlation_cap:
                return False, f"Đã có {same_dir_altcoins} vị thế Altcoin cùng chiều ({direction.upper()}) đang chịu rủi ro (trần tương quan {correlation_cap}/{effective_max_pos}), chặn mở thêm để kiểm soát rủi ro tương quan"
        
        return True, "Trade allowed"
        
    def calculate_position_size(self, balance: float, entry_price: float, stop_loss_price: float) -> float:
        """
        Tính toán quy mô vị thế (số lượng coin/token) dựa trên rủi ro cho phép.
        (Calculate position size based on allowed risk)
        """
        if entry_price <= 0 or stop_loss_price <= 0 or entry_price == stop_loss_price:
            logger.warning("Invalid prices for position sizing")
            return 0.0
            
        risk_amount = balance * self.max_risk_per_trade
        # Khoảng cách cắt lỗ tuyệt đối
        price_risk = abs(entry_price - stop_loss_price)
        
        # Số lượng = Số tiền rủi ro / Rủi ro trên mỗi đơn vị
        position_size = risk_amount / price_risk
        
        return position_size
        
    def check_stop_loss(self, position: Dict, current_price: float) -> bool:
        """
        Kiểm tra xem giá hiện tại đã chạm mức cắt lỗ chưa.
        (Check if current price hit stop loss)
        """
        sl_price = position.get('stop_loss')
        direction = position.get('direction') or position.get('side', '').upper()
        
        if not sl_price:
            return False
            
        if direction in ('BUY', 'LONG') and current_price <= sl_price:
            return True
        elif direction in ('SELL', 'SHORT') and current_price >= sl_price:
            return True
            
        return False
        
    def check_take_profit(self, position: Dict, current_price: float) -> bool:
        """
        Kiểm tra xem giá hiện tại đã chạm mức chốt lời chưa.
        (Check if current price hit take profit)
        """
        tp_price = position.get('take_profit')
        direction = position.get('direction') or position.get('side', '').upper()
        
        if not tp_price:
            return False
            
        if direction in ('BUY', 'LONG') and current_price >= tp_price:
            return True
        elif direction in ('SELL', 'SHORT') and current_price <= tp_price:
            return True
            
        return False
        
    def update_trailing_stop(self, position: Dict, current_price: float) -> float:
        """
        Cập nhật mức cắt lỗ trượt (trailing stop).
        (Update trailing stop level)
        """
        current_sl = position.get('stop_loss', 0.0)
        direction = position.get('direction') or position.get('side', '').upper()
        
        if direction in ('BUY', 'LONG'):
            # Tính SL mới dựa trên giá hiện tại
            new_sl = current_price * (1 - self.trailing_stop_pct)
            # Chỉ cập nhật nếu SL mới cao hơn SL cũ (dịch lên)
            if new_sl > current_sl:
                return new_sl
        elif direction in ('SELL', 'SHORT'):
            new_sl = current_price * (1 + self.trailing_stop_pct)
            # Chỉ cập nhật nếu SL mới thấp hơn SL cũ (dịch xuống) hoặc chưa có SL (0.0)
            if current_sl == 0.0 or new_sl < current_sl:
                return new_sl
                
        return current_sl
        
    def check_drawdown(self, current_balance: float, peak_balance: float) -> Tuple[bool, float]:
        """
        Kiểm tra mức sụt giảm tài khoản (drawdown).
        Trả về (True/False tạm dừng giao dịch, tỷ lệ drawdown hiện tại).
        (Check account drawdown)
        """
        if peak_balance <= 0:
            return False, 0.0
            
        drawdown_pct = (peak_balance - current_balance) / peak_balance
        
        if drawdown_pct >= self.max_drawdown:
            logger.warning(f"Max drawdown reached! Current DD: {drawdown_pct*100:.2f}%")
            return True, drawdown_pct
            
        return False, drawdown_pct

    def should_take_profit_or_reinvest(self, pnl: float, balance: float) -> str:
        """
        Quản lý lợi nhuận thông minh.
        (Smart profit management based on total return)
        
        - Lợi nhuận < 20% vốn ban đầu: reinvest (tái đầu tư toàn bộ)
        - Lợi nhuận 20% - 50%: take_profit (rút 30% lợi nhuận)
        - Lợi nhuận > 50%: take_profit (rút 50% lợi nhuận)
        Lưu ý: hàm chỉ trả về action state, bot cần thực hiện logic rút tiền ở ngoài.
        """
        if pnl <= 0:
            return 'reinvest'
            
        initial_capital = balance - pnl
        
        if initial_capital <= 0:
            return 'reinvest'
            
        profit_pct = pnl / initial_capital
        
        if profit_pct < 0.20:
            return 'reinvest'
        elif 0.20 <= profit_pct <= 0.50:
            return 'partial' # Gợi ý rút 30%
        else:
            return 'take_profit' # Gợi ý rút 50%
