# 📑 BÁO CÁO CHIẾN LƯỢC QUẢN LÝ VỐN & ĐÒN BẨY ĐỊNH LƯỢNG
### *(Hệ thống Giao dịch Tự động Binance Futures: Quy mô 40 USDT -> 10,000 USDT)*

---

## 📌 I. TỔNG QUAN ĐIỀU HÀNH (EXECUTIVE SUMMARY)

Một trong những sai lầm chết người của người giao dịch cá nhân là giữ nguyên tư duy đòn bẩy khi vốn tăng lên. 
* **Khi vốn nhỏ (40$ - 50$)**: Kẻ thù lớn nhất là **Rào cản thanh khoản tối thiểu (Min Notional = 5$)**. Nếu dùng đòn bẩy quá nhỏ (1x - 3x), bot sẽ bị sàn chặn lệnh hoặc cọc hết vốn cho 1 lệnh duy nhất.
* **Khi vốn lớn (1,000$ - 10,000$)**: Kẻ thù lớn nhất là **Độ trượt giá (Slippage) & Rủi ro đồng pha toàn thị trường**. Khi đó, đòn bẩy bắt buộc phải hạ xuống **3x - 5x** để kéo khoảng cách thanh lý xa ngoài 25% - 30%, biến tài khoản thành một "pháo đài bất khả xâm phạm".

```mermaid
flowchart LR
    subgraph Vốn Nhỏ ["Vốn Nhỏ (40$ - 100$)"]
        A1["Ưu tiên: Đạt Min Notional sàn"] --> A2["Đòn bẩy: 8x - 10x"]
        A2 --> A3["Số lệnh: 2 - 3 lệnh"]
    end
    subgraph Vốn Trung ["Vốn Trung Bình (300$ - 1,000$)"]
        B1["Ưu tiên: Tối ưu lợi nhuận/Rủi ro"] --> B2["Đòn bẩy: 5x - 7x"]
        B2 --> B3["Số lệnh: 3 - 5 lệnh"]
    end
    subgraph Vốn Lớn ["Vốn Lớn (3,000$ - 10,000$)"]
        C1["Ưu tiên: Bảo tồn tài sản & Chống sập"] --> C2["Đòn bẩy: 3x - 4x"]
        C2 --> C3["Số lệnh: 5 - 6 lệnh"]
    end
    Vốn Nhỏ ==> Vốn Trung ==> Vốn Lớn
```

---

## 📊 II. BẢNG PHÂN BỔ ĐỊNH LƯỢNG CHI TIẾT THEO TỪNG CỘT MỐC

Dưới đây là bảng ma trận định lượng được tính toán chuẩn xác cho bot:

| Cột mốc Vốn | Đòn bẩy Tối đa (`max_leverage`) | Số lệnh Tối đa (`max_open_trades`) | Tiền ký quỹ / 1 lệnh | % Ký quỹ trên tổng vốn | Giá trị vị thế (Notional) | Khoảng cách Thanh lý | Khoảng đệm An toàn Stop Loss | Mức lỗ SL tối đa / lệnh |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **40$ – 50$** *(Hiện tại)* | **8x – 10x** | **2 lệnh** | `1.2$ – 1.6$` | `~3.0%` | `12$ – 16$` | **-10.0%** | **Gấp 3.0 lần SL (3.5%)** | `0.65$` (1.5%) |
| **100$** | **7x – 10x** | **2 – 3 lệnh** | `2.5$ – 3.0$` | `~2.8%` | `20$ – 30$` | **-11.5%** | **Gấp 3.5 lần SL** | `1.50$` (1.5%) |
| **300$** | **7x – 8x** | **3 – 4 lệnh** | `6.0$ – 7.5$` | `~2.3%` | `45$ – 60$` | **-13.0%** | **Gấp 4.0 lần SL** | `4.50$` (1.5%) |
| **500$** | **5x – 7x** | **4 lệnh** | `10.0$ – 12.0$` | `~2.2%` | `60$ – 80$` | **-16.0%** | **Gấp 4.8 lần SL** | `7.50$` (1.5%) |
| **1,000$** | **5x – 6x** | **4 – 5 lệnh** | `20.0$ – 25.0$` | `~2.2%` | `100$ – 150$` | **-18.0%** | **Gấp 5.5 lần SL** | `12.0$` (1.2%) |
| **3,000$** | **4x – 5x** | **5 lệnh** | `50.0$ – 60.0$` | `~1.8%` | `220$ – 300$` | **-22.0%** | **Gấp 7.0 lần SL** | `30.0$` (1.0%) |
| **5,000$** | **3x – 5x** | **5 – 6 lệnh** | `80.0$ – 100.0$` | `~1.8%` | `300$ – 450$` | **-25.0%** | **Gấp 8.0 lần SL** | `50.0$` (1.0%) |
| **10,000$** *(Whale)* | **3x – 4x** | **5 – 6 lệnh** | `150.0$ – 180.0$` | `~1.6%` | `500$ – 700$` | **-28.0% – -32.0%** | **Gấp 10 lần SL** | `80.0$` (0.8%) |

---

## 🔍 III. GIẢNG GIẢI CHI TIẾT TỪNG THÀNH PHẦN (DEEP-DIVE)

### 1. Tại sao Vốn Càng Lớn thì Đòn Bẩy Càng Giảm?
* **Với vốn 43$**: Bạn mở vị thế 15$, nếu lỗ 3.5% thì mất `0.52$` — con số này rất nhỏ. Nhưng nếu đòn bẩy chỉ 2x, bạn phải cọc tận `7.5$` (gần 20% tài khoản) chỉ cho một lệnh!
* **Với vốn 10,000$**: Vị thế mỗi lệnh là 600$ - 1,000$. Chỉ cần đòn bẩy `3x - 4x`, tiền cọc là 150$ - 250$ (chỉ chiếm 1.5% - 2.5% vốn). Lợi ích lớn nhất là: **Giá phải giảm tới 30% thì tài khoản mới cháy!** Không một cú rút râu hay tin tức bất ngờ nào của thị trường có thể giết chết tài khoản của bạn.

### 2. Tại sao Số Lệnh Đồng Thời Tối Đa Không Quá 6 Lệnh?
* **Hiệu ứng "Đồng pha Thị trường" (Market Correlation):**  
  Khi Bitcoin dump 5% trong 15 phút, 95% Altcoin sẽ lập tức rơi theo.
  * Nếu bạn mở **10 lệnh**: Cả 10 lệnh sẽ cùng quét Stop-Loss cùng một lúc $\rightarrow$ Bạn lỗ $10 \times 1.5\% = 15\%$ tổng vốn chỉ sau 1 cây nến đỏ.
  * Nếu bạn chỉ mở **2 - 4 lệnh**: Rủi ro tối đa bị giới hạn ở mức $3\% - 5\%$. Sau khi nến đỏ qua đi, bot vẫn còn nguyên 95% tiền mặt để bắt đáy ở nhịp phục hồi.

### 3. Quy tắc "Đệm Tiền Mặt" (Free Margin Cushion) Luôn Giữ > 70%
* Trong tài khoản Futures, tiền mặt chưa dùng (Free Margin) chính là tấm áo giáp bảo vệ.
* Khi chỉ sử dụng 10% - 25% vốn làm ký quỹ, bạn sẽ không bao giờ bị sàn Binance cảnh báo gọi ký quỹ (Margin Call), và tâm lý giao dịch sẽ luôn ở trạng thái thoải mái nhất.

---

## 🛠️ IV. MẪU CẤU HÌNH THEO TỪNG GIAI ĐOẠN TRONG `config/settings.yaml`

Bạn chỉ cần đối chiếu mốc vốn của mình và thay thế đoạn tương ứng vào [`config/settings.yaml`](file:///d:/TRADE/config/settings.yaml):

````carousel
```yaml
# GIAI ĐOẠN 1: VỐN 40$ - 100$ (HIỆN TẠI)
risk:
  max_risk_per_trade: 0.015        # Chấp nhận rủi ro 1.5% (~0.65$ - 1.5$)
  max_daily_loss_pct: 0.05         # Dừng khẩn cấp nếu ngày âm quá 5%
  max_margin_utilization_pct: 0.40 # Ký quỹ tối đa 40% vốn

trading:
  leverage: 5                      # Đòn bẩy sàn mặc định
  max_leverage: 10                 # Trần đòn bẩy AI tối đa (8x - 10x)
  max_open_trades: 2               # Tối đa 2 lệnh đồng thời (Tốt nhất)
```
<!-- slide -->
```yaml
# GIAI ĐOẠN 2: VỐN 300$ - 500$
risk:
  max_risk_per_trade: 0.015        # 1.5% rủi ro (~4.5$ - 7.5$)
  max_daily_loss_pct: 0.04         # Dừng khẩn cấp siết về 4%
  max_margin_utilization_pct: 0.35 # Ký quỹ tối đa 35% vốn

trading:
  leverage: 5
  max_leverage: 8                  # Hạ trần đòn bẩy AI về 8x
  max_open_trades: 3               # Mở rộng lên 3 lệnh đồng thời
```
<!-- slide -->
```yaml
# GIAI ĐOẠN 3: VỐN 1,000$ (CHUYÊN NGHIỆP)
risk:
  max_risk_per_trade: 0.012        # Hạ rủi ro về 1.2% (~12$ / lệnh)
  max_daily_loss_pct: 0.035        # Dừng khẩn cấp ngày 3.5% (35$)
  max_margin_utilization_pct: 0.30 # Giữ lại 70% tiền mặt tự do

trading:
  leverage: 5
  max_leverage: 6                  # Trần đòn bẩy AI tối đa 6x
  max_open_trades: 4               # Quản lý 4 cơ hội tốt nhất
```
<!-- slide -->
```yaml
# GIAI ĐOẠN 4: VỐN 5,000$ - 10,000$ (CÁ VOI / BẢO TỒN TÀI SẢN)
risk:
  max_risk_per_trade: 0.008        # Chỉ chấp nhận rủi ro 0.8% (80$ trên 10,000$)
  max_daily_loss_pct: 0.02         # Dừng khẩn cấp ngày 2.0% (200$)
  max_margin_utilization_pct: 0.25 # Ký quỹ tối đa 25%, giữ 75% tiền mặt

trading:
  leverage: 3
  max_leverage: 4                  # Trần đòn bẩy 4x (Khoảng cách cháy > 28%)
  max_open_trades: 5               # Tối đa 5 - 6 lệnh đồng thời
```
````

---

## 💎 V. CHIẾN LƯỢC RÚT LÃI BỎ TÚI (PROFIT HARVESTING)

1. **Nguyên tắc "Cắt Lãi 50%":**
   * Mỗi khi bot tạo ra lợi nhuận đạt cột mốc **+25%**:
   * Rút ngay **50% số tiền lãi** sang ví Giao ngay (Spot) hoặc chuyển về tài khoản ngân hàng.
   * Để lại 50% tiền lãi vào vốn gốc để bot chạy lãi kép tự nhiên.
2. **Nguyên tắc "Không Nạp 1 Cục":**
   * Nếu bạn dự định đầu tư 10,000$, tuyệt đối không nạp cả 10,000$ vào tài khoản Futures trong ngày đầu tiên.
   * Hãy bắt đầu với 500$ -> 1,000$ -> 3,000$, kiểm tra bot chạy nhịp nhàng qua từng chu kỳ thị trường rồi mới nâng dần lên.
