import logging
import re
import math
import statistics
import sys
from typing import Dict, List, Optional, Tuple

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

from strategies.base_strategy import TradeSignal, Signal
from core.scanner import MarketScanner

logger = logging.getLogger(__name__)


class SignalAggregator:
    """Combine strategy votes without letting HOLD signals dilute them."""

    def __init__(self, config: dict = None):
        config = config or {}
        ai_config = config.get('ai', {})
        self.confidence_threshold = float(ai_config.get('confidence_threshold', 0.6))
        self.min_agreeing_strategies = max(
            1, int(ai_config.get('min_agreeing_strategies', 2))
        )

        self.strategy_weights = {}
        for name, strat_config in config.get('strategies', {}).items():
            if isinstance(strat_config, dict):
                self.strategy_weights[name] = float(strat_config.get('weight', 0.25))

        if not self.strategy_weights:
            self.strategy_weights = {
                'trend_following': 0.3,
                'mean_reversion': 0.25,
                'ai_ensemble': 0.2,
                'jev_agent': 0.3,
                'smart_dca': 0.15,
                'hft_scalping': 0.25,
                'trap_detector': 0.25,
                'momentum_breakout': 0.25,
            }

    def _strategy_votes(self, signals: List[TradeSignal]) -> Dict[str, Tuple[float, float]]:
        """Return one weighted vote per strategy, combining its actionable timeframes."""
        by_strategy: Dict[str, List[float]] = {}

        for sig in signals:
            if sig.signal == Signal.BUY:
                direction = 1.0
            elif sig.signal == Signal.SELL:
                direction = -1.0
            else:
                # Nếu AI có chủ ý kiên quyết chọn HOLD (confidence >= 0.70 do thị trường cực xấu/rủi ro), thì mới kéo điểm tổng về 0.
                # Nếu AI chỉ phân vân/lưỡng lự (confidence < 0.70), bỏ qua để không kìm hãm hay làm loãng tín hiệu của các chiến thuật kỹ thuật khác.
                try:
                    conf_check = float(sig.confidence)
                except (TypeError, ValueError):
                    conf_check = 0.0
                if conf_check < 0.70:
                    continue
                direction = 0.0

            try:
                confidence = float(sig.confidence)
            except (TypeError, ValueError):
                continue
            if not 0.0 <= confidence <= 1.0:
                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', sig.strategy).lower()
            by_strategy.setdefault(name, []).append(direction * confidence)

        votes: Dict[str, Tuple[float, float]] = {}
        
        # --- MUTUALLY EXCLUSIVE & TRAP OVERRIDE RULES ---
        # 1. KIỂM TRA BẪY GIÁ (BULL TRAP / BEAR TRAP) TỪ TRAP DETECTOR:
        # Chỉ TrapDetector với xác nhận gom/xả hàng thực thụ mới được xem là bẫy giá (KHÔNG dùng MeanReversion để phủ quyết xu hướng)
        has_real_bull_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') == 'BULL_TRAP_WICK'
            for s in signals
        )
        has_real_bear_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') == 'BEAR_TRAP_WICK'
            for s in signals
        )
        trend_vote = sum(by_strategy.get('trend_following', [0.0])) / len(by_strategy.get('trend_following', [1.0])) if 'trend_following' in by_strategy else 0.0
        breakout_vote = sum(by_strategy.get('momentum_breakout', [0.0])) / len(by_strategy.get('momentum_breakout', [1.0])) if 'momentum_breakout' in by_strategy else 0.0
        jev_vote = sum(by_strategy.get('jev_agent', [0.0])) / len(by_strategy.get('jev_agent', [1.0])) if 'jev_agent' in by_strategy else 0.0

        if has_real_bull_trap:
            neutralized = []
            if trend_vote >= 0.30 and 'trend_following' in by_strategy:
                by_strategy.pop('trend_following', None)
                neutralized.append('TrendFollowing')
            if breakout_vote >= 0.30 and 'momentum_breakout' in by_strategy:
                by_strategy.pop('momentum_breakout', None)
                neutralized.append('Breakout')
            if neutralized:
                logger.warning(
                    "🛡️ CẢNH BÁO BẪY GIÁ (BULL TRAP): TrapDetector phát hiện rút râu xả hàng! Vô hiệu hóa đà BUY của %s để tránh đu đỉnh.",
                    ', '.join(neutralized),
                )

        if has_real_bear_trap:
            neutralized_dn = []
            if trend_vote <= -0.30 and 'trend_following' in by_strategy:
                by_strategy.pop('trend_following', None)
                neutralized_dn.append('TrendFollowing')
            if breakout_vote <= -0.30 and 'momentum_breakout' in by_strategy:
                by_strategy.pop('momentum_breakout', None)
                neutralized_dn.append('Breakout')
            if neutralized_dn:
                logger.warning(
                    "🛡️ CẢNH BÁO BẪY GIÁ (BEAR TRAP): TrapDetector phát hiện quét thanh khoản rút chân gom hàng! Vô hiệu hóa đà SELL của %s để tránh bán đáy.",
                    ', '.join(neutralized_dn),
                )

        # 2. CHỐNG BẮT DAO RƠI KHI SẬP MẠNH (Downtrend crash):
        # Kiểm tra kỹ lưỡng tín hiệu Bearish từ JEV, TrendFollowing, Breakout hoặc AI Bias toàn thị trường
        jev_is_bearish = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and any(w in str(s.metadata.get('reason', '')).lower() for w in ('bearish', 'downtrend', 'drop', 'dump', 'xả', 'caution', 'exhaustion'))
            for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
        )
        # Kiểm tra AI Bias hoặc Market Regime vĩ mô từ metadata
        macro_is_bearish = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and (
                str(s.metadata.get('ai_bias', '')).upper() == 'BEARISH'
                or str(s.metadata.get('market_regime', '')).lower() in ('downtrend', 'strong_downtrend', 'bearish')
            )
            for s in signals
        )
        has_strong_sell_momentum = (
            breakout_vote <= -0.20 or 
            trend_vote <= -0.20 or 
            jev_vote <= -0.20 or 
            jev_is_bearish or 
            macro_is_bearish
        )

        symbol_name = str(getattr(signals[0], 'symbol', '') or '')
        is_tier1 = any(t in symbol_name for t in ('BTC', 'ETH'))
        is_stock = MarketScanner.is_tradfi_stock(symbol_name)

        # A. CẤM TUYỆT ĐỐI BẮT ĐÁY LONG TRÊN ALTCOIN KHI THỊ TRƯỜNG DOWNTREND:
        # Số liệu thực nghiệm chứng minh 78.6% râu nến Altcoin bị quét thủng đáy trong Downtrend.
        # Không cho phép bất kỳ nhận định cục bộ nào vượt rào cấm bắt dao rơi Altcoin.
        # Lưu ý: Cổ phiếu Mỹ (TradFi Stock) không bị chi phối bởi Bitcoin/Crypto Downtrend nên được miễn trừ.
        if has_strong_sell_momentum and not is_tier1 and not is_stock:
            for strat_k in ('mean_reversion', 'trend_following', 'smart_dca', 'trap_detector'):
                if strat_k in by_strategy:
                    filtered_v = [v for v in by_strategy[strat_k] if v <= 0]
                    if filtered_v:
                        by_strategy[strat_k] = filtered_v
                    else:
                        by_strategy.pop(strat_k, None)
            reason_str = "Toàn sàn/Vĩ mô Downtrend" if macro_is_bearish else f"Đà giảm cục bộ của coin (Trend: {trend_vote:+.2f}, Breakout: {breakout_vote:+.2f})"
            logger.info("🚫 VETO BUY ALTCOIN (%s): %s, cấm bắt dao rơi Altcoin!", symbol_name, reason_str)

        # B. TĂNG LỰC CHO SHORT BẮT ĐỈNH (BULL TRAP SHORT):
        # Khi xuất hiện Bull Trap trong thị trường gấu, tăng mạnh trọng số SHORT
        if has_real_bull_trap:
            by_strategy['trap_detector'] = [-0.85]
            logger.info("🎯 KÍCH HOẠT BULL TRAP SHORT (%s): TrapDetector xác nhận râu xả đỉnh, ưu tiên SHORT!", symbol_name)

        # C. LỌC BẪY RÂU ĐÁY ALTCOIN (BEAR TRAP TRÊN ALTCOIN):
        if has_real_bear_trap and not is_tier1 and not is_stock and has_strong_sell_momentum:
            by_strategy.pop('trap_detector', None)
            logger.warning("🛡️ CHẶN BẪY RÂU ALTCOIN (%s): Râu rút đáy Altcoin trong downtrend chỉ là hồi ảo, bỏ qua!", symbol_name)

        for name, strategy_signals in by_strategy.items():
            # Conflicting timeframes from the same strategy cancel each other.
            vote = sum(strategy_signals) / len(strategy_signals)
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                votes[name] = (vote, weight)
        return votes

    def calculate_weighted_score(self, signals: List[TradeSignal]) -> float:
        """Return the weighted mean of active strategy votes, in [-1, 1]."""
        votes = self._strategy_votes(signals)
        total_weight = sum(weight for _, weight in votes.values())
        if total_weight <= 0:
            return 0.0
        return sum(vote * weight for vote, weight in votes.values()) / total_weight

    def determine_final_signal(self, score: float, symbol: str, price: float) -> TradeSignal:
        abs_score = abs(score)
        if abs_score >= self.confidence_threshold:
            direction = Signal.BUY if score > 0 else Signal.SELL
        else:
            direction = Signal.HOLD

        return TradeSignal(
            signal=direction,
            symbol=symbol,
            confidence=abs_score,
            strategy='aggregated',
            price=price,
        )

    def _aggregate_protection_level(
        self, signals: List[TradeSignal], final_signal: Signal, price: float, field: str,
    ) -> Optional[float]:
        """Carry a robust, directionally valid strategy SL/TP into the final vote.

        Aggregate percentage distances rather than absolute prices because each
        timeframe can report a slightly different last price. First collapse a
        strategy's timeframes with a median, then take a strategy-weighted median
        so one unusually wide stop/target cannot dominate the result.
        """
        if final_signal not in (Signal.BUY, Signal.SELL):
            return None
        try:
            reference_price = float(price)
        except (TypeError, ValueError, OverflowError):
            return None
        if not math.isfinite(reference_price) or reference_price <= 0:
            return None

        distances_by_strategy: Dict[str, List[float]] = {}
        for signal in signals:
            if signal.signal != final_signal:
                continue
            try:
                signal_price = float(signal.price)
                level = float(getattr(signal, field))
            except (TypeError, ValueError, OverflowError):
                continue
            if not math.isfinite(signal_price) or signal_price <= 0 or not math.isfinite(level) or level <= 0:
                continue

            if field == 'stop_loss':
                distance = (signal_price - level) / signal_price if final_signal == Signal.BUY else (level - signal_price) / signal_price
            else:
                distance = (level - signal_price) / signal_price if final_signal == Signal.BUY else (signal_price - level) / signal_price
            if not math.isfinite(distance) or distance <= 0:
                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', signal.strategy).lower()
            distances_by_strategy.setdefault(name, []).append(distance)

        weighted_distances = []
        for name, distances in distances_by_strategy.items():
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                weighted_distances.append((statistics.median(distances), weight))
        if not weighted_distances:
            return None

        weighted_distances.sort(key=lambda item: item[0])
        half_weight = sum(weight for _, weight in weighted_distances) / 2.0
        cumulative = 0.0
        distance = weighted_distances[-1][0]
        for candidate, weight in weighted_distances:
            cumulative += weight
            if cumulative >= half_weight:
                distance = candidate
                break

        if final_signal == Signal.BUY:
            level = reference_price * (1.0 - distance) if field == 'stop_loss' else reference_price * (1.0 + distance)
        else:
            level = reference_price * (1.0 + distance) if field == 'stop_loss' else reference_price * (1.0 - distance)
        return level if math.isfinite(level) and level > 0 else None

    def aggregate(self, signals: List[TradeSignal]) -> Optional[TradeSignal]:
        if not signals:
            return None

        symbol = signals[0].symbol
        price = signals[0].price
        votes = self._strategy_votes(signals)
        score = self.calculate_weighted_score(signals)
        agreeing = sum(1 for vote, _ in votes.values() if vote * score > 0)
        logger.info(
            'Aggregated score for %s: %+.4f (threshold=%.2f, agreeing strategies=%d/%d)',
            symbol, score, self.confidence_threshold, agreeing, len(votes),
        )

        # Cho phép tín hiệu Bứt phá/Sập mạnh độ tự tin cao (>=85%) từ MomentumBreakout được thực thi ngay
        is_strong_breakdown = (
            score <= -0.80 and 
            any(s.strategy == 'momentum_breakout' and s.signal == Signal.SELL and getattr(s, 'confidence', 0.0) >= 0.85 for s in signals)
        )
        is_strong_breakout = (
            score >= 0.80 and 
            any(s.strategy == 'momentum_breakout' and s.signal == Signal.BUY and getattr(s, 'confidence', 0.0) >= 0.85 for s in signals)
        )
        is_god_mode = abs(score) >= 0.95 or is_strong_breakdown or is_strong_breakout
        if is_strong_breakdown:
            logger.info("🚀 BREAKDOWN SẬP MẠNH ĐƯỢC KÍCH HOẠT: MomentumBreakout phát hiện thủng hỗ trợ (Score: %.2f), cho phép SHORT đón sóng giảm!", score)
        elif is_strong_breakout:
            logger.info("🚀 BREAKOUT BƠM MẠNH ĐƯỢC KÍCH HOẠT: MomentumBreakout phát hiện bứt phá đỉnh (Score: %.2f), cho phép BUY đón sóng bão tăng!", score)

        if agreeing < self.min_agreeing_strategies and not is_god_mode:
            logger.info(
                'No trade for %s: need %d agreeing strategies, got %d',
                symbol, self.min_agreeing_strategies, agreeing,
            )
            return None

        # Yêu cầu bắt buộc ít nhất 1 chiến thuật kỹ thuật độc lập (Trend, Breakout, MR, Trap) đồng thuận
        non_ai_agreeing = sum(
            1 for s_name, (v, _) in votes.items()
            if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0
        )
        if non_ai_agreeing < 1 and not is_god_mode:
            logger.info(
                'No trade for %s: cần ít nhất 1 chiến thuật kỹ thuật độc lập (non-AI) đồng thuận, hiện có %d',
                symbol, non_ai_agreeing,
            )
            return None

        final_signal = self.determine_final_signal(score, symbol, price)
        if final_signal.signal != Signal.HOLD:
            # --- JEV AGENT VALIDATION & CONTRADICTION VETO ---
            jev_sig = next((s for s in signals if s.strategy.lower() in ('jev_agent', 'jevagent')), None)
            if jev_sig:
                try:
                    jev_conf = float(jev_sig.confidence)
                except (TypeError, ValueError):
                    jev_conf = 0.0

                # 1. Chống đánh ngược JEV Agent quyết đoán (Conf >= 0.70)
                if jev_sig.signal == Signal.SELL and jev_conf >= 0.70 and final_signal.signal == Signal.BUY:
                    logger.warning(
                        "🛡️ VETO JEV AGENT: Hủy lệnh BUY %s do JEV Agent phân tích MTF khẳng định SELL (Conf: %.2f)!",
                        symbol, jev_conf,
                    )
                    return None
                if jev_sig.signal == Signal.BUY and jev_conf >= 0.70 and final_signal.signal == Signal.SELL:
                    has_trap_sell = 'trap_detector' in votes and votes['trap_detector'][0] < 0
                    if has_trap_sell or non_ai_agreeing >= 2:
                        logger.info(
                            "⚡ BẢO VỆ LỆNH SELL %s: TrapDetector/Đồng thuận kỹ thuật (non_ai=%d) phát hiện đỉnh/bẫy giá cá mập, bỏ qua phủ quyết BUY của JEV Agent!",
                            symbol, non_ai_agreeing,
                        )
                    else:
                        logger.warning(
                            "🛡️ VETO JEV AGENT: Hủy lệnh SELL %s do JEV Agent phân tích MTF khẳng định BUY (Conf: %.2f)!",
                            symbol, jev_conf,
                        )
                        return None

                # 2. Bảo vệ khi JEV Agent khuyến nghị HOLD rõ rệt (Conf >= 0.75 - thị trường nhiễu/lưỡng lự)
                if jev_sig.signal == Signal.HOLD and jev_conf >= 0.75:
                    non_ai_agreeing = sum(
                        1 for s_name, (v, _) in votes.items()
                        if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0
                    )
                    # Yêu cầu tối thiểu 2 chiến thuật kỹ thuật độc lập đồng thuận VÀ điểm tuyệt đối >= confidence_threshold
                    if non_ai_agreeing < 2 or abs(score) < self.confidence_threshold:
                        logger.warning(
                            "🛡️ VETO JEV AGENT HOLD: Hủy lệnh %s %s do JEV Agent khuyến nghị HOLD (Conf: %.2f) và không đủ đồng thuận kỹ thuật (non_ai=%d, score=%+.4f)!",
                            final_signal.signal.value.upper(), symbol, jev_conf, non_ai_agreeing, score,
                        )
                        return None

            # Thu thập market analysis từ tín hiệu 4H
            market_analysis = next(
                (
                    signal.metadata.get('market_analysis')
                    for signal in signals
                    if isinstance(getattr(signal, 'metadata', None), dict)
                    and isinstance(signal.metadata.get('market_analysis'), dict)
                ),
                {},
            )
            
            # --- MTF TREND FILTER (Cấm lướt sóng ngược bão) ---
            regime = str(market_analysis.get('regime', 'ranging')).lower()
            ema = str(market_analysis.get('ema_alignment', '')).lower()
            
            is_downtrend = 'downtrend' in regime or ema == 'bearish'
            is_uptrend = 'uptrend' in regime or ema == 'bullish'
            
            # Khóa lệnh ngược trend: TUYỆT ĐỐI CẤM BUY ngược 4H downtrend trừ khi có BẪY GẤU RÚT CHÂN (BEAR_TRAP_WICK)
            has_bear_trap_wick = any(
                isinstance(getattr(s, 'metadata', None), dict)
                and s.metadata.get('type') == 'BEAR_TRAP_WICK'
                for s in signals
            )
            has_bull_trap_wick = any(
                isinstance(getattr(s, 'metadata', None), dict)
                and s.metadata.get('type') == 'BULL_TRAP_WICK'
                for s in signals
            )

            # MTF Trend Filter bắt buộc (TUYỆT ĐỐI KHÔNG BỎ QUA dù điểm số breakout cao đến đâu):
            # Không bao giờ bơi ngược dòng 4H để tránh đu đỉnh bẫy giá Bull Trap như trường hợp ZK/USDT
            if final_signal.signal == Signal.BUY and is_downtrend:
                if has_bear_trap_wick and abs(score) >= 0.70:
                    logger.info(f"⚡ MTF Trap Override: Cho phép BUY {symbol} ngược 4H do phát hiện Quét thanh khoản gom hàng (BEAR_TRAP_WICK, Score: {score:+.2f})")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh BUY {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Cấm bắt dao rơi khi không có bẫy gấu rút chân gom hàng.")
                    return None
                    
            if final_signal.signal == Signal.SELL and is_uptrend:
                if has_bull_trap_wick and abs(score) >= 0.70:
                    logger.info(f"⚡ MTF Trap Override: Cho phép SELL {symbol} ngược 4H do phát hiện Bẫy tăng xả hàng (BULL_TRAP_WICK, Score: {score:+.2f})")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh SELL {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Không có xác nhận bẫy tăng xả hàng.")
                    return None
            
            # Tính toán SL/TP
            final_signal.stop_loss = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'stop_loss'
            )
            final_signal.take_profit = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'take_profit'
            )
            
            final_signal.metadata.update({
                'weighted_score': score,
                'agreeing_strategies': agreeing,
                'strategy_count': len(votes),
                'agreement_ratio': agreeing / len(votes) if votes else 0.0,
                'market_analysis': market_analysis,
            })
        return final_signal if final_signal.signal != Signal.HOLD else None

