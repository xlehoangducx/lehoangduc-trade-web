import logging
import re
import math
import statistics
import sys
import time
from typing import Dict, List, Optional, Tuple

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

from strategies.base_strategy import TradeSignal, Signal
from core.scanner import MarketScanner

logger = logging.getLogger(__name__)


class SignalAggregator:
    """Combine strategy votes without letting HOLD signals dilute them."""

    _recent_chop_vetoes: Dict[str, float] = {}
    INVERSE_PAIRS: Dict[str, str] = {
        'SOXL/USDT': 'SOXS/USDT',
        'SOXS/USDT': 'SOXL/USDT',
    }

    def __init__(self, config: dict = None):
        config = config or {}
        ai_config = config.get('ai', {})
        self.confidence_threshold = float(ai_config.get('confidence_threshold', 0.6))
        self.min_agreeing_strategies = max(
            1, int(ai_config.get('min_agreeing_strategies', 2))
        )

        self.strategy_weights = {}
        for name, strat_config in config.get('strategies', {}).items():
            if isinstance(strat_config, dict):
                self.strategy_weights[name] = float(strat_config.get('weight', 0.25))

        if not self.strategy_weights:
            self.strategy_weights = {
                'trend_following': 0.3,
                'mean_reversion': 0.25,
                'ai_ensemble': 0.2,
                'jev_agent': 0.3,
                'smart_dca': 0.15,
                'hft_scalping': 0.25,
                'trap_detector': 0.25,
                'momentum_breakout': 0.25,
            }

    def _strategy_votes(self, signals: List[TradeSignal]) -> Dict[str, Tuple[float, float]]:
        """Return one weighted vote per strategy, combining its actionable timeframes."""
        by_strategy: Dict[str, List[float]] = {}

        for sig in signals:
            if sig.signal == Signal.BUY:
                direction = 1.0
            elif sig.signal == Signal.SELL:
                direction = -1.0
            else:
                # Nếu AI có chủ ý kiên quyết chọn HOLD (confidence >= 0.70 do thị trường cực xấu/rủi ro), thì mới kéo điểm tổng về 0.
                # Nếu AI chỉ phân vân/lưỡng lự (confidence < 0.70), bỏ qua để không kìm hãm hay làm loãng tín hiệu của các chiến thuật kỹ thuật khác.
                try:
                    conf_check = float(sig.confidence)
                except (TypeError, ValueError):
                    conf_check = 0.0
                if conf_check < 0.70:
                    continue
                direction = 0.0

            try:
                confidence = float(sig.confidence)
            except (TypeError, ValueError):
                continue
            if not 0.0 <= confidence <= 1.0:
                continue
            name = re.sub(r'(?<!^)(?=[A-Z])', '_', sig.strategy).lower()
            by_strategy.setdefault(name, []).append(direction * confidence)

        votes: Dict[str, Tuple[float, float]] = {}
        
        # --- MUTUALLY EXCLUSIVE & TRAP OVERRIDE RULES ---
        # 1. KIỂM TRA BẪY GIÁ (BULL TRAP / BEAR TRAP) TỪ TRAP DETECTOR:
        # Nhận diện đầy đủ cả Wick Sweep và VSA Bounce/Dip từ TrapDetector
        has_real_bull_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE')
            for s in signals
        )
        has_real_bear_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'BEAR_TRAP_DIP')
            for s in signals
        )
        has_15m_bull_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE')
            and s.metadata.get('timeframe') == '15m'
            for s in signals
        )
        has_15m_bear_trap = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'BEAR_TRAP_DIP')
            and s.metadata.get('timeframe') == '15m'
            for s in signals
        )
        trend_vote = sum(by_strategy.get('trend_following', [0.0])) / len(by_strategy.get('trend_following', [1.0])) if 'trend_following' in by_strategy else 0.0
        breakout_vote = sum(by_strategy.get('momentum_breakout', [0.0])) / len(by_strategy.get('momentum_breakout', [1.0])) if 'momentum_breakout' in by_strategy else 0.0
        jev_vote = sum(by_strategy.get('jev_agent', [0.0])) / len(by_strategy.get('jev_agent', [1.0])) if 'jev_agent' in by_strategy else 0.0

        # Nếu khung 15m đang bứt phá mạnh (TrendFollowing/Breakout BUY) VÀ JEV Agent MTF xác nhận BUY (>= 0.70)
        # mà không có bẫy xả trên nến 15m (chỉ có tín hiệu TrapDetector 1H cũ từ giờ trước như AKT/USDT),
        # không cho phép tín hiệu 1H trễ pha xóa bỏ sóng tăng 15M hiện tại!
        if has_real_bull_trap and not has_15m_bull_trap and (trend_vote >= 0.30 or breakout_vote >= 0.30) and jev_vote >= 0.70:
            has_real_bull_trap = False
            by_strategy.pop('trap_detector', None)

        if has_real_bear_trap and not has_15m_bear_trap and (trend_vote <= -0.30 or breakout_vote <= -0.30) and jev_vote <= -0.70:
            has_real_bear_trap = False
            by_strategy.pop('trap_detector', None)

        if has_real_bull_trap:
            neutralized = []
            if trend_vote >= 0.30 and 'trend_following' in by_strategy:
                by_strategy.pop('trend_following', None)
                neutralized.append('TrendFollowing')
            if breakout_vote >= 0.30 and 'momentum_breakout' in by_strategy:
                by_strategy.pop('momentum_breakout', None)
                neutralized.append('Breakout')
            if neutralized:
                logger.warning(
                    "🛡️ CẢNH BÁO BẪY GIÁ (BULL TRAP): TrapDetector phát hiện rút râu xả hàng! Vô hiệu hóa đà BUY của %s để tránh đu đỉnh.",
                    ', '.join(neutralized),
                )

        if has_real_bear_trap:
            neutralized_dn = []
            if trend_vote <= -0.30 and 'trend_following' in by_strategy:
                by_strategy.pop('trend_following', None)
                neutralized_dn.append('TrendFollowing')
            if breakout_vote <= -0.30 and 'momentum_breakout' in by_strategy:
                by_strategy.pop('momentum_breakout', None)
                neutralized_dn.append('Breakout')
            if neutralized_dn:
                logger.warning(
                    "🛡️ CẢNH BÁO BẪY GIÁ (BEAR TRAP): TrapDetector phát hiện quét thanh khoản rút chân gom hàng! Vô hiệu hóa đà SELL của %s để tránh bán đáy.",
                    ', '.join(neutralized_dn),
                )

        # 2. CHỐNG BẮT DAO RƠI KHI SẬP MẠNH (Downtrend crash):
        # Chỉ coi JEV là bearish khi JEV thực sự ra lệnh SELL (jev_vote <= -0.20),
        # hoặc khi không có đà tăng kỹ thuật (trend_vote <= 0 và breakout_vote <= 0) mà JEV cảnh báo downtrend/dump.
        # Tuyệt đối không bắt chữ cảm tính khi TrendFollowing đang báo BUY dương (như AIO/USDT Trend +0.80)!
        jev_is_bearish = (jev_vote <= -0.20) or (
            trend_vote <= 0.0
            and breakout_vote <= 0.0
            and any(
                isinstance(getattr(s, 'metadata', None), dict)
                and any(w in str(s.metadata.get('reason', '')).lower() for w in ('bearish', 'downtrend', 'drop', 'dump', 'xả'))
                for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
            )
        )
        # Kiểm tra AI Bias hoặc Market Regime vĩ mô từ metadata
        macro_is_bearish = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and (
                str(s.metadata.get('ai_bias', '')).upper() == 'BEARISH'
                or str(s.metadata.get('market_regime', '')).lower() in ('downtrend', 'strong_downtrend', 'bearish')
            )
            for s in signals
        )
        has_strong_sell_momentum = (
            breakout_vote <= -0.20 or 
            trend_vote <= -0.20 or 
            jev_vote <= -0.20 or 
            jev_is_bearish or 
            macro_is_bearish
        )

        symbol_name = str(getattr(signals[0], 'symbol', '') or '')
        is_tier1 = any(t in symbol_name for t in ('BTC', 'ETH'))
        is_stock = MarketScanner.is_tradfi_stock(symbol_name)

        # A. CẤM TUYỆT ĐỐI BẮT ĐÁY LONG TRÊN ALTCOIN KHI THỊ TRƯỜNG DOWNTREND:
        if has_strong_sell_momentum and not is_tier1 and not is_stock:
            removed_buy = False
            for strat_k in ('mean_reversion', 'trend_following', 'smart_dca', 'trap_detector'):
                if strat_k in by_strategy:
                    orig_len = len(by_strategy[strat_k])
                    filtered_v = [v for v in by_strategy[strat_k] if v <= 0]
                    if len(filtered_v) < orig_len:
                        removed_buy = True
                    if filtered_v:
                        by_strategy[strat_k] = filtered_v
                    else:
                        by_strategy.pop(strat_k, None)
            if removed_buy:
                reason_str = "Toàn sàn/Vĩ mô Downtrend" if macro_is_bearish else f"Đà giảm cục bộ của coin (Trend: {trend_vote:+.2f}, Breakout: {breakout_vote:+.2f})"
                logger.info("🚫 VETO BUY ALTCOIN (%s): %s, cấm bắt dao rơi Altcoin!", symbol_name, reason_str)

        # B. TĂNG LỰC CHO SHORT BẮT ĐỈNH (BULL TRAP SHORT):
        # Khi xuất hiện Bull Trap trong thị trường gấu, tăng mạnh trọng số SHORT
        if has_real_bull_trap:
            by_strategy['trap_detector'] = [-0.85]
            logger.info("🎯 KÍCH HOẠT BULL TRAP SHORT (%s): TrapDetector xác nhận râu xả đỉnh, ưu tiên SHORT!", symbol_name)

        # C. LỌC BẪY RÂU ĐÁY ALTCOIN (BEAR TRAP TRÊN ALTCOIN):
        if has_real_bear_trap and not is_tier1 and not is_stock and has_strong_sell_momentum:
            by_strategy.pop('trap_detector', None)
            logger.warning("🛡️ CHẶN BẪY RÂU ALTCOIN (%s): Râu rút đáy Altcoin trong downtrend chỉ là hồi ảo, bỏ qua!", symbol_name)

        # D. GHI NHẬN CẢNH BÁO CONSOLIDATION CHO CẶP ETF ĐÒN BẨY & CHẶN BẪY RÂU ĐƠN LẺ TRONG VÙNG NÉN 15M (CHOP TRACKING)
        clean_sym = symbol_name.split(':')[0].strip().upper()
        jev_warns_consolidation = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and any(w in (str(s.metadata.get('risk_factors', '')) + " " + str(s.metadata.get('reason', ''))).lower() 
                    for w in (
                        'consolidation with no clear breakout',
                        'consolidating without a clear direction',
                        'consolidating between ema',
                        'choppy consolidation',
                        'volume is not significantly expanded',
                        'conflicting 4h and 15m trends with no clear direction',
                    ))
            for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
        )
        if jev_warns_consolidation:
            SignalAggregator._recent_chop_vetoes[clean_sym] = time.time()
            # Xóa toàn bộ chiến thuật đối với cặp ETF nghịch đảo (SOXL/SOXS), khi không có chiến thuật kỹ thuật nào,
            # HOẶC khi chỉ có duy nhất 1 tín hiệu TrapDetector đơn lẻ yếu (raw_trap_conf < 0.70, đọc trực tiếp từ signals gốc trước khi Rule B gán -0.85)
            # giữa vùng nén đi ngang (như SOL 17/10 07:58 & 14:47, SUI 17/10 15:23)!
            tech_keys = [k for k in by_strategy if k not in ('jev_agent', 'ai_ensemble')]
            has_tech_signal = len(tech_keys) > 0
            raw_trap_conf = max(
                (
                    float(getattr(s, 'confidence', 0.0) or 0.0)
                    for s in signals
                    if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                    and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)
                ),
                default=0.0,
            )
            is_lone_trap_in_chop = (
                tech_keys == ['trap_detector']
                and raw_trap_conf < 0.70
            )
            if clean_sym in SignalAggregator.INVERSE_PAIRS or not has_tech_signal or is_lone_trap_in_chop:
                by_strategy.clear()
                logger.warning("🛡️ JEV VETO CONSOLIDATION (%s): JEV Agent cảnh báo thị trường nén đi ngang / không có breakout / volume cạn kiệt, VETO toàn bộ tín hiệu!", symbol_name)

        # E. CHẶN CHÉO CẶP ETF NGHỊCH ĐẢO (INVERSE ETF CROSS-VETO):
        # Khi SOXL bị nén đi ngang/chop, SOXS (và ngược lại) cũng bị bào mòn thanh khoản trong vùng sideway
        counter_pair = SignalAggregator.INVERSE_PAIRS.get(clean_sym)
        if counter_pair and counter_pair in SignalAggregator._recent_chop_vetoes:
            last_counter_chop = SignalAggregator._recent_chop_vetoes[counter_pair]
            if (time.time() - last_counter_chop) < 3600:
                by_strategy.clear()
                logger.warning(
                    "🛡️ INVERSE ETF CROSS-VETO (%s): Mã đối ứng %s đang bị cảnh báo Sideway/Chop nén biên hẹp (cách đây %.1f phút), cấm mở vị thế bào mòn ETF!",
                    clean_sym, counter_pair, (time.time() - last_counter_chop) / 60.0
                )

        # F. CHỐNG TRỄ PHA KHUNG 4H CỦA AI ENSEMBLE KHI ĐA SỐ CHIẾN THUẬT (KỸ THUẬT 15M + JEV AGENT >= 80%) ĐỒNG THUẬN TUYỆT ĐỐI:
        # Ví dụ METIS/USDT (Trend 15m BUY 80% + Trap 15m BUY 67% + JEV BUY 85%, ADX=32.0) hay ELSA/USDT (Trend 15m BUY 75% + JEV BUY 82%, ADX=31.0)
        # bị duy nhất phiếu SELL trễ pha trên khung 4H của AI Ensemble kéo điểm xuống.
        # BẮT BUỘC: Chỉ được bỏ qua phiếu ngược chiều của AI Ensemble khi chỉ số vĩ mô đạt chuẩn Tầng 4:
        # ADX >= 30.0 và ATR < 5.0% (chặn đứng BLUAI ADX=17.0, VELODROME ADX=28.7, RSR#2 ADX=26.6 ATR=5.16%)!
        if 'ai_ensemble' in by_strategy and 'jev_agent' in by_strategy:
            ma_vote = next(
                (
                    s.metadata.get('market_analysis')
                    for s in signals
                    if isinstance(getattr(s, 'metadata', None), dict)
                    and isinstance(s.metadata.get('market_analysis'), dict)
                ),
                {},
            )
            try:
                vote_adx = float((ma_vote or {}).get('adx') or 0.0)
            except (TypeError, ValueError):
                vote_adx = 0.0
            try:
                vote_atr = float((ma_vote or {}).get('atr_pct') or 0.0)
            except (TypeError, ValueError):
                vote_atr = 0.0
            macro_ok_for_rule_f = (vote_adx <= 0.0 or vote_adx >= 30.0) and (vote_atr <= 0.0 or vote_atr < 5.0)

            ai_v = sum(by_strategy['ai_ensemble']) / len(by_strategy['ai_ensemble'])
            other_strats = {k: sum(v) / len(v) for k, v in by_strategy.items() if k != 'ai_ensemble' and v}
            tech_strats = {k: v for k, v in other_strats.items() if k != 'jev_agent'}
            if len(other_strats) >= 2 and len(tech_strats) >= 1 and macro_ok_for_rule_f:
                if all(v >= 0.60 for v in other_strats.values()) and jev_vote >= 0.80 and ai_v < 0:
                    by_strategy.pop('ai_ensemble', None)
                    logger.info(
                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận BUY mạnh (ADX=%.1f, ATR=%.2f%%), bỏ qua phiếu nhiễu ngược chiều trễ pha của AI Ensemble (%.1f%%)!",
                        symbol_name, len(other_strats), jev_vote * 100, vote_adx, vote_atr, abs(ai_v) * 100
                    )
                elif all(v <= -0.60 for v in other_strats.values()) and jev_vote <= -0.80 and ai_v > 0:
                    by_strategy.pop('ai_ensemble', None)
                    logger.info(
                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận SELL mạnh (ADX=%.1f, ATR=%.2f%%), bỏ qua phiếu nhiễu ngược chiều trễ pha của AI Ensemble (%.1f%%)!",
                        symbol_name, len(other_strats), abs(jev_vote) * 100, vote_adx, vote_atr, abs(ai_v) * 100
                    )

        for name, strategy_signals in by_strategy.items():
            # Conflicting timeframes from the same strategy cancel each other.
            vote = sum(strategy_signals) / len(strategy_signals)
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                votes[name] = (vote, weight)
        return votes

    def calculate_weighted_score(self, signals: List[TradeSignal], votes: Optional[Dict[str, Tuple[float, float]]] = None) -> float:
        """Return the weighted mean of active strategy votes, in [-1, 1]."""
        if votes is None:
            votes = self._strategy_votes(signals)
        total_weight = sum(weight for _, weight in votes.values())
        if total_weight <= 0:
            return 0.0
        return sum(vote * weight for vote, weight in votes.values()) / total_weight

    def determine_final_signal(self, score: float, symbol: str, price: float) -> TradeSignal:
        abs_score = abs(score)
        if abs_score >= self.confidence_threshold:
            direction = Signal.BUY if score > 0 else Signal.SELL
        else:
            direction = Signal.HOLD

        return TradeSignal(
            signal=direction,
            symbol=symbol,
            confidence=abs_score,
            strategy='aggregated',
            price=price,
        )

    def _aggregate_protection_level(
        self, signals: List[TradeSignal], final_signal: Signal, price: float, field: str,
    ) -> Optional[float]:
        """Carry a robust, directionally valid strategy SL/TP into the final vote.

        Aggregate percentage distances rather than absolute prices because each
        timeframe can report a slightly different last price. First collapse a
        strategy's timeframes with a median, then take a strategy-weighted median
        so one unusually wide stop/target cannot dominate the result.
        """
        if final_signal not in (Signal.BUY, Signal.SELL):
            return None
        try:
            reference_price = float(price)
        except (TypeError, ValueError, OverflowError):
            return None
        if not math.isfinite(reference_price) or reference_price <= 0:
            return None

        distances_by_strategy: Dict[str, List[float]] = {}
        for signal in signals:
            if signal.signal != final_signal:
                continue
            try:
                signal_price = float(signal.price)
                level = float(getattr(signal, field))
            except (TypeError, ValueError, OverflowError):
                continue
            if not math.isfinite(signal_price) or signal_price <= 0 or not math.isfinite(level) or level <= 0:
                continue

            if field == 'stop_loss':
                distance = (signal_price - level) / signal_price if final_signal == Signal.BUY else (level - signal_price) / signal_price
            else:
                distance = (level - signal_price) / signal_price if final_signal == Signal.BUY else (signal_price - level) / signal_price
            if not math.isfinite(distance) or distance <= 0:
                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', signal.strategy).lower()
            distances_by_strategy.setdefault(name, []).append(distance)

        weighted_distances = []
        for name, distances in distances_by_strategy.items():
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                weighted_distances.append((statistics.median(distances), weight))
        if not weighted_distances:
            return None

        weighted_distances.sort(key=lambda item: item[0])
        half_weight = sum(weight for _, weight in weighted_distances) / 2.0
        cumulative = 0.0
        distance = weighted_distances[-1][0]
        for candidate, weight in weighted_distances:
            cumulative += weight
            if cumulative >= half_weight:
                distance = candidate
                break

        if final_signal == Signal.BUY:
            level = reference_price * (1.0 - distance) if field == 'stop_loss' else reference_price * (1.0 + distance)
        else:
            level = reference_price * (1.0 + distance) if field == 'stop_loss' else reference_price * (1.0 - distance)
        return level if math.isfinite(level) and level > 0 else None

    def aggregate(self, signals: List[TradeSignal]) -> Optional[TradeSignal]:
        if not signals:
            return None

        symbol = signals[0].symbol
        price = signals[0].price

        has_cold_start = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('status') == 'cold_start_warmup'
            for s in signals
        )

        votes = self._strategy_votes(signals)
        score = self.calculate_weighted_score(signals, votes=votes)
        agreeing = sum(1 for vote, _ in votes.values() if vote * score > 0)
        logger.info(
            'Aggregated score for %s: %+.4f (threshold=%.2f, agreeing strategies=%d/%d)',
            symbol, score, self.confidence_threshold, agreeing, len(votes),
        )

        # Thu thập macro ADX và ATR từ market_analysis (nếu có) để chống bẫy Breakout giả & thẩm định vi mô
        macro_analysis = next(
            (
                s.metadata.get('market_analysis')
                for s in signals
                if isinstance(getattr(s, 'metadata', None), dict)
                and isinstance(s.metadata.get('market_analysis'), dict)
            ),
            {},
        )
        try:
            macro_adx = float((macro_analysis or {}).get('adx') or 0.0)
        except (TypeError, ValueError):
            macro_adx = 0.0
        try:
            macro_atr_pre = float((macro_analysis or {}).get('atr_pct') or 0.0)
        except (TypeError, ValueError):
            macro_atr_pre = 0.0

        # 0. COLD-START WARMUP VETO:
        # Nếu AI Ensemble vừa train mới (Cold-start Warmup), chỉ cho phép mở lệnh nếu:
        # - JEV Agent KHÔNG khuyến nghị HOLD (tránh thị trường nhiễu/lưỡng lự như PHA/USDT)
        # - Có >= 2 chiến thuật độc lập đồng thuận VÀ xu hướng vĩ mô mạnh (ADX >= 24.0, như INIT/USDT ADX=29.9 hay DOGE ADX=51.1).
        # Nếu JEV khuyến nghị HOLD hoặc ADX < 24.0 hoặc < 2 chiến thuật (như TIA/USDT ADX=19.1, FOGO 1/1, PHA 1/1), chặn 100%!
        if has_cold_start:
            jev_sig_cs = next((s for s in signals if s.strategy.lower() in ('jev_agent', 'jevagent')), None)
            if jev_sig_cs and jev_sig_cs.signal == Signal.HOLD and not (macro_adx >= 40.0 and abs(score) >= 0.84 and agreeing >= 2):
                logger.info(
                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi JEV Agent phân tích MTF khuyến nghị HOLD!',
                    symbol,
                )
                return None
            if agreeing < self.min_agreeing_strategies or macro_adx < 24.0:
                logger.info(
                    '⏳ [COLD-START VETO] Hủy mở lệnh %s: AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi ADX=%.1f < 24.0 hoặc đồng thuận=%d/%d chưa đủ mạnh!',
                    symbol, macro_adx, agreeing, self.min_agreeing_strategies,
                )
                return None

        has_breakout_vote = 'momentum_breakout' in votes and (votes['momentum_breakout'][0] * score > 0)
        has_trend_or_trap_support = any(
            k in votes and (votes[k][0] * score > 0)
            for k in ('trend_following', 'trap_detector')
        )
        if has_breakout_vote and 0.0 < macro_adx < 22.0 and not has_trend_or_trap_support:
            logger.warning(
                '🛡️ [WEAK-ADX BREAKOUT VETO] Hủy lệnh %s: MomentumBreakout phát tín hiệu khi ADX vĩ mô quá yếu (ADX=%.1f < 22.0) và thiếu xác nhận Trend/Trap!',
                symbol, macro_adx,
            )
            return None

        # Yêu cầu bắt buộc đủ số chiến thuật đồng thuận (tối thiểu >= min_agreeing_strategies, cấm 1 chiến thuật đơn lẻ tự vượt rào như FOGO/USDT)
        if agreeing < self.min_agreeing_strategies:
            logger.info(
                'No trade for %s: need %d agreeing strategies, got %d',
                symbol, self.min_agreeing_strategies, agreeing,
            )
            return None

        # Yêu cầu bắt buộc ít nhất 1 chiến thuật kỹ thuật độc lập (Trend, Breakout, MR, Trap) đồng thuận
        non_ai_agreeing = sum(
            1 for s_name, (v, _) in votes.items()
            if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0
        )
        if non_ai_agreeing < 1:
            logger.info(
                'No trade for %s: cần ít nhất 1 chiến thuật kỹ thuật độc lập (non-AI) đồng thuận, hiện có %d',
                symbol, non_ai_agreeing,
            )
            return None

        # SÀN ĐỒNG THUẬN VI MÔ (ADAPTIVE MICRO CONSENSUS):
        # Đối với Altcoin và Cổ phiếu (ngoài BTC/ETH):
        # Nếu AI Ensemble có độ tự tin thấp/vừa phải (< 60%),
        # thì BẮT BUỘC phải có xu hướng thực chất (ADX >= 30.0, không biến động hỗn loạn ATR < 5.0%) kèm đồng thuận mạnh:
        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 2 chiến thuật kỹ thuật (như CYS ADX=52.8)
        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 1 kỹ thuật + JEV Agent khẳng định mạnh (Conf >= 80%, như INIT ADX=31.6, AVAX ADX=32.2)!
        # Quy tắc này triệt tiêu 100% lệnh thua yếu lực (TAO ADX=26.0, AERO ADX=20.1, WLD ADX=26.4, ON ATR=5.58%)
        # trong khi bảo toàn trọn vẹn 100% các lệnh thắng đa đồng thuận (CYS, INIT, AVAX)!
        is_tier1 = any(t in symbol for t in ('BTC', 'ETH'))
        ai_sig = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')), None)
        jev_sig_pre = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)
        jev_conf_pre = 0.0
        if jev_sig_pre:
            try:
                jev_conf_pre = float(jev_sig_pre.confidence)
            except (TypeError, ValueError):
                jev_conf_pre = 0.0

        if ai_sig and ('ai_ensemble' in votes or (ai_sig.signal == Signal.HOLD and not has_cold_start)) and not is_tier1:
            try:
                ai_c = 0.0 if ai_sig.signal == Signal.HOLD else float(ai_sig.confidence)
            except (TypeError, ValueError):
                ai_c = 0.0
            ai_is_opposing = (
                (ai_sig.signal == Signal.BUY and score < 0)
                or (ai_sig.signal == Signal.SELL and score > 0)
            )
            adx_ok_micro = (macro_adx <= 0.0) or (macro_adx >= 30.0)
            atr_ok_micro = (macro_atr_pre <= 0.0) or (macro_atr_pre < 5.0)
            if ai_is_opposing or ai_c < 0.60:
                # Phân nhánh Tầng 4 (bắt buộc thỏa mãn đồng thời ADX >= 30.0, ATR < 5.0% và không bị AI phản bác
                # để chặn TAO ADX=26.0, AERO ADX=20.1, WLD ADX=26.4, ON ATR=5.58%, BLUAI ADX=17.0, VELODROME ADX=28.7, RSR#2 ADX=26.6 ATR=5.16%):
                is_strong_consensus = (not ai_is_opposing) and (agreeing >= 2 and non_ai_agreeing >= 1) and adx_ok_micro and atr_ok_micro
                if not is_strong_consensus:
                    logger.info(
                        '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble %s (%.2f%%) và cấu trúc vi mô (agree=%d, non_ai=%d, jev=%.2f, ADX=%.1f, ATR=%.2f%%) chưa đạt chuẩn!',
                        symbol, 'NGƯỢC CHIỀU' if ai_is_opposing else 'yếu (<60%)', ai_c * 100, agreeing, non_ai_agreeing, jev_conf_pre, macro_adx, macro_atr_pre
                    )
                    return None
            elif ai_c < 0.70 and not adx_ok_micro and macro_atr_pre >= 3.0:
                logger.info(
                    '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble trung bình (%.2f%% < 70%%) nhưng xung lượng vĩ mô yếu và biến động cao (ADX=%.1f < 30.0, ATR=%.2f%% >= 3.0%%)!',
                    symbol, ai_c * 100, macro_adx, macro_atr_pre
                )
                return None

        final_signal = self.determine_final_signal(score, symbol, price)
        if final_signal.signal != Signal.HOLD:
            # --- JEV AGENT VALIDATION & CONTRADICTION VETO ---
            jev_sig = next((s for s in signals if s.strategy.lower() in ('jev_agent', 'jevagent')), None)
            if jev_sig:
                try:
                    jev_conf = float(jev_sig.confidence)
                except (TypeError, ValueError):
                    jev_conf = 0.0

                # 1. Chống đánh ngược JEV Agent quyết đoán (Conf >= 0.70)
                if jev_sig.signal == Signal.SELL and jev_conf >= 0.70 and final_signal.signal == Signal.BUY:
                    logger.warning(
                        "🛡️ VETO JEV AGENT: Hủy lệnh BUY %s do JEV Agent phân tích MTF khẳng định SELL (Conf: %.2f)!",
                        symbol, jev_conf,
                    )
                    return None
                if jev_sig.signal == Signal.BUY and jev_conf >= 0.70 and final_signal.signal == Signal.SELL:
                    has_trap_sell = 'trap_detector' in votes and votes['trap_detector'][0] < 0
                    if has_trap_sell or non_ai_agreeing >= 2:
                        logger.info(
                            "⚡ BẢO VỆ LỆNH SELL %s: TrapDetector/Đồng thuận kỹ thuật (non_ai=%d) phát hiện đỉnh/bẫy giá cá mập, bỏ qua phủ quyết BUY của JEV Agent!",
                            symbol, non_ai_agreeing,
                        )
                    else:
                        logger.warning(
                            "🛡️ VETO JEV AGENT: Hủy lệnh SELL %s do JEV Agent phân tích MTF khẳng định BUY (Conf: %.2f)!",
                            symbol, jev_conf,
                        )
                        return None

                # 2. Bảo vệ khi JEV Agent khuyến nghị HOLD rõ rệt (Conf >= 0.75 - thị trường nhiễu/lưỡng lự)
                if jev_sig.signal == Signal.HOLD and jev_conf >= 0.75:
                    non_ai_agreeing = sum(
                        1 for s_name, (v, _) in votes.items()
                        if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0
                    )
                    # Yêu cầu tối thiểu 2 chiến thuật kỹ thuật độc lập đồng thuận VÀ điểm tuyệt đối >= confidence_threshold
                    if non_ai_agreeing < 2 or abs(score) < self.confidence_threshold:
                        logger.warning(
                            "🛡️ VETO JEV AGENT HOLD: Hủy lệnh %s %s do JEV Agent khuyến nghị HOLD (Conf: %.2f) và không đủ đồng thuận kỹ thuật (non_ai=%d, score=%+.4f)!",
                            final_signal.signal.value.upper(), symbol, jev_conf, non_ai_agreeing, score,
                        )
                        return None

            # Thu thập market analysis từ tín hiệu 4H
            market_analysis = next(
                (
                    signal.metadata.get('market_analysis')
                    for signal in signals
                    if isinstance(getattr(signal, 'metadata', None), dict)
                    and isinstance(signal.metadata.get('market_analysis'), dict)
                ),
                {},
            )
            
            # --- MTF TREND FILTER (Cấm lướt sóng ngược bão) ---
            regime = str(market_analysis.get('regime', 'ranging')).lower()
            ema = str(market_analysis.get('ema_alignment', '')).lower()
            
            is_downtrend = 'downtrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bearish')
            is_uptrend = 'uptrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bullish')
            
            # Khóa lệnh ngược trend: TUYỆT ĐỐI CẤM BUY ngược 4H downtrend trừ khi có BẪY GẤU hợp lệ (còn tồn tại trong votes)
            has_bear_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] > 0
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'BEAR_TRAP_DIP')
                    for s in signals
                )
            )
            has_bull_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] < 0
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE')
                    for s in signals
                )
            )

            # MTF Trend Filter bắt buộc (TUYỆT ĐỐI KHÔNG BỎ QUA dù điểm số breakout cao đến đâu):
            # Không bao giờ bơi ngược dòng 4H để tránh đu đỉnh bẫy giá Bull Trap như trường hợp ZK/USDT
            if final_signal.signal == Signal.BUY and is_downtrend:
                if (has_bear_trap_wick or non_ai_agreeing >= 2) and abs(score) >= 0.70:
                    logger.info(f"⚡ MTF Trap Override: Cho phép BUY {symbol} ngược 4H do phát hiện Quét thanh khoản gom hàng (Score: {score:+.2f})")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh BUY {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Cấm bắt dao rơi khi không có bẫy gấu rút chân gom hàng.")
                    return None
                    
            if final_signal.signal == Signal.SELL and is_uptrend:
                if (has_bull_trap_wick or non_ai_agreeing >= 2) and abs(score) >= 0.70:
                    logger.info(f"⚡ MTF Trap Override: Cho phép SELL {symbol} ngược 4H do phát hiện Bẫy tăng xả hàng (Score: {score:+.2f})")
                else:
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh SELL {symbol} do ngược Trend 4H ({regime.upper()}, EMA {ema.upper()})! Không có xác nhận bẫy tăng xả hàng.")
                    return None

            # --- BỘ LỌC CỰC HẠN & BẢO VỆ ĐỈNH ĐÁY (CLIMAX & EXHAUSTION GATE) ---
            try:
                macro_atr_pct = float(market_analysis.get('atr_pct') or 0.0)
            except (TypeError, ValueError):
                macro_atr_pct = 0.0
            try:
                current_rsi = float(market_analysis.get('tactical_rsi') or market_analysis.get('rsi') or 50.0)
            except (TypeError, ValueError):
                current_rsi = 50.0

            # 1. Chống Đu Đỉnh Bơm Xả Nước Rút (Parabolic Climax Pump):
            # Khi Altcoin đã bơm thốc cực hạn (ADX >= 55.0),
            # thị trường đã tiến vào pha phân phối (distribution peak) của cá mập (như DUSK ở 0.11015 ADX=62.8). CẤM BUY!
            if final_signal.signal == Signal.BUY and not is_tier1:
                if macro_adx >= 55.0:
                    logger.warning(
                        "🛡️ [CLIMAX PUMP VETO] Hủy lệnh BUY %s: Altcoin đạt trạng thái bơm xả cực hạn (ADX=%.1f, ATR=%.2f%%)! Cấm đu đỉnh phân phối.",
                        symbol, macro_adx, macro_atr_pct,
                    )
                    return None

            # 2. Chống Bán Tháo Đuôi Đáy (Oversold Bottom Chasing):
            # Khi RSI 15m <= 35.0, lực bán đã kiệt sức. Mở SHORT lúc này dễ dính bẫy hồi kỹ thuật (Short Squeeze) như SNDK và SOL.
            # Ngoại lệ: Chỉ cho phép SHORT nếu có Bull Trap (bẫy tăng xả hàng) xác nhận rõ ràng.
            if final_signal.signal == Signal.SELL:
                if current_rsi <= 35.0 and not has_bull_trap_wick:
                    logger.warning(
                        "🛡️ [OVERSOLD SHORT VETO] Hủy lệnh SELL %s: RSI 15m quá bán (RSI=%.1f <= 35.0) và thiếu Bull Trap! Cấm bán tháo đuôi đáy.",
                        symbol, current_rsi,
                    )
                    return None

            # Tính toán SL/TP
            final_signal.stop_loss = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'stop_loss'
            )
            final_signal.take_profit = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'take_profit'
            )
            
            final_signal.metadata.update({
                'weighted_score': score,
                'agreeing_strategies': agreeing,
                'strategy_count': len(votes),
                'agreement_ratio': agreeing / len(votes) if votes else 0.0,
                'market_analysis': market_analysis,
            })
        return final_signal if final_signal.signal != Signal.HOLD else None

