@echo off
color 0A
echo =======================================================
echo     AUTO FIX: DONG BO THOI GIAN CHO BINANCE API
echo =======================================================
echo.
echo Kiem tra quyen Administrator (Quyen quan tri cao nhat)...

:: Check for admin privileges
net session >nul 2>&1
if %errorLevel% == 0 (
    echo [OK] Da cap quyen Administrator. Dang bat dau dong bo...
) else (
    color 0C
    echo [CBB] Ban chua cap quyen Administrator!
    echo Cach sua: Hay bam chuot phai vao file "Fix_Time.bat" nay
    echo va chon "Run as Administrator" de tien trinh duoc chay.
    echo.
    pause
    exit /b
)

echo.
echo [1/3] Dang khoi dong lai dich vu Windows Time (w32time)...
net stop w32time >nul 2>&1
net start w32time >nul 2>&1

echo [2/3] Dang ep Windows huy dong bo cu, xoa cache...
w32tm /unregister >nul 2>&1
w32tm /register >nul 2>&1
net start w32time >nul 2>&1

echo [3/3] Dang lay thoi gian cuc chuan tu may chu Quoc te...
w32tm /resync /nowait

echo.
echo =======================================================
echo [THANH CONG] DONG HO WINDOWS DA DUOC CHINH XAC TUYET DOI!
echo Ban da co the mo START.bat va chay bot binh thuong.
echo =======================================================
pause
