# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & GROUND TRUTH
> **Single Source of Truth (SSOT) Tự Động Cho Mọi Phiên Chat Mới Trong Project `TRADE`**  
> *Antigravity tự động nạp tệp này vào ngữ cảnh AI ngay khi mở phiên hội thoại mới.*  
> *Người dùng KHÔNG CẦN phải gõ lại lịch sử chat hay hướng dẫn dài.*

---

## 1. BỐI CẢNH 2 MÁY TÍNH (DUAL-PC ARCHITECTURE)
* **💻 PC1 (Máy Phát Triển - Dev Machine):**
  * Thư mục làm việc: `D:\TRADE` (và `D:\WEB_TRADE_BOT`).
  * Môi trường: Google Antigravity IDE, Python 3.14.7 64-bit Virtual Environment.
  * Nhiệm vụ: Lập trình, phân tích nến, kiểm toán code, đóng gói `TradeMatrix_Client_v2.0_clean.zip`, đồng bộ mã sạch sang PC2 qua mạng LAN và đẩy Git lên Cloudflare Pages.
* **🖥️ PC2 (Máy Thử Nghiệm Chạy Treo 24/24 - Live Daemon):**
  * Thư mục nhận mã qua LAN: `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0`.
  * Trạng thái thực tế: Treo thực chiến 24/7 trên Binance Futures với tiền thật (Equity ~50.43 USDT).
  * Trí tuệ nhân tạo: Ollama local chạy card GTX 1060 6GB với model duy nhất `qwen2.5:7b`.
  * Điều khiển: Khởi chạy bằng `START.bat`, khởi động lại bằng `RESTART.bat`.

---

## 2. 10 CĂN NGUYÊN GỐC RỄ & BÀI HỌC THỰC CHIẾN XƯƠNG MÁU
Mọi quyết định chỉnh sửa code đều bắt nguồn từ 10 bài học thực tế qua hơn 29,000 bước kiểm chứng:
1. **Lệch giờ API Binance (-1021):** Đồng hồ Windows lệch vài giây làm lệnh bị từ chối `Timestamp outside recvWindow` -> Có [`Fix_Time.bat`](file:///d:/TRADE/Fix_Time.bat) ép đồng bộ w32tm và tự động resync khi chạy [`START.bat`](file:///d:/TRADE/START.bat).
2. **Căn bệnh "Ăn hạt cát, thua cả tảng đá" (Payoff 0.44):** Trailing stop siết non `+0.16%` (+0.02$), nhưng SL thả trôi `-5%` đến `-10%` -> Chuẩn hóa Fixed Fractional Risk 0.6% NAV, SL tối đa 1.5 ATR.
3. **Thảm họa TradFi `BOT/USDT` (-1.24 USDT):** Mã cổ phiếu Mỹ phái sinh trên Binance bị nhận diện nhầm là Altcoin nên cấp vốn 55% NAV -> Nhận diện động CCXT metadata, giới hạn Notional TradFi tối đa 20% NAV và đòn bẩy $\le 4x$.
4. **Bẫy nến chưa đóng (Unfinished Candle):** Quét nến `iloc[-1]` thấy xanh nhảy vào, vài chục giây sau nến đóng rút râu đỏ -> Pre-Trade Safety Gate neo vào nến đã đóng hoàn toàn `iloc[-2]`.
5. **Rào cản sàn Binance MIN_NOTIONAL 5.00 USDT:** Vốn nhỏ (~50 USDT), vị thế ~10 USDT không thể chia thành 3-5 nấc chốt lời vì mỗi nấc sẽ dưới 5 USDT -> Phát minh Dynamic Adaptive K-Stages tự động chia 1 đến 5 nấc tùy Notional.
6. **Đọng vốn SOL/USDT gồng 200m:** Gồng lãi `+0.43%` rồi dính SL ngược -> Thoát vốn đọng sau 120 phút (8 nến 15m), nâng buffer hòa vốn từ `0.03%` lên `0.12%` để luôn vượt phí Taker sàn 2 đầu `0.10%`.
7. **Bẫy xả ZEREBRO (-0.218 USDT) do kẹt Grace Period:** TrapDetector thấy râu xả nhưng bị Grace Period khóa tay -> Phá khóa Grace Period khẩn cấp khi Trap ngược chiều $\ge 65\%$.
8. **M1 Sniper Retest Stalking (Lệnh Rình Ảo Trong RAM):** Bot rình nến 1m thoái lui để khớp lệnh Maker 0.02% (tiết kiệm 60% phí); nếu nến 1m gãy cấu trúc xả mạnh thì tự hủy trong RAM để né sập sâu. (Lưu ý: Khi đang rình, bot CHƯA gửi lệnh lên Binance để tránh khóa ký quỹ).
9. **Bẫy Cắt Non Râu Nhiễu (Premature Wick-Cut) & Chặn Chốt Lời Sau Giảm Tải:** De-risking 0.40 ATR không có bộ lọc thời gian làm 78% vị thế bị cắt non 50% ở râu nến giật 12s đầu, sau đó giá tăng ngược lại bị chặn chốt lời do cờ `partial_sl_done` -> Nâng lên 0.65 ATR, ép giữ tối thiểu $\ge 1.0$ phút và mở khóa Partial TP cho phần vị thế còn lại khi hồi phục.
10. **Bẫy Thả Trôi Lệnh Tay (Manual Order Abandonment):** Khi người dùng tự vào lệnh trên Binance, bot sợ xung đột nên đánh dấu review và bỏ qua không đặt SL/TP làm lệnh tay bị thả trôi lỗ nặng -> Phát minh Công Tắc Đồng Bộ 2 Chiều "Auto-Adopt Manual Positions" trên Web & Tool: khi BẬT, bot tự tra cứu/đặt SL sàn và kích hoạt trọn bộ Trailing Stop + Chốt lời + Cắt giảm tải.
11. **Tử Huyệt Chop Shield Vô Hạn & Đá Nhau Giữa Code Và Chú Thích:** Quét BTC mỗi 60s làm JEV Agent liên tục gia hạn `_crypto_market_chop_until = now + 300s`, kết hợp code ép $\ge 3$ kỹ thuật (trong khi chú thích ghi $\ge 2$) làm Altcoin bị khóa chết 100% trong 3 tiếng -> Chuẩn hóa Kịch Bản 2 Thận Trọng: rút thời gian khóa xuống 120s, cho Altcoin vượt rào khi $\ge 2$ kỹ thuật $\ge 75\%$ hoặc Trap $\ge 70\%$, tăng Profit Factor lên 0.63 (+50%) và Payoff Ratio lên 0.27 (+58.8%).
12. **Xung Đột Khởi Động Trình Duyệt Nhảy Non (Start-up Race Condition):** `START.bat` mở `loading.html` ở giây 0 trong khi Python cần 8-12s để bind Port 5000; `loading.html` giả lập 4s rồi redirect non làm trình duyệt dính lỗi `ERR_CONNECTION_REFUSED` (buộc phải bấm Reload 2 lần) -> Thêm CORS header `*` trong Flask và viết lại `loading.html` chỉ chuyển hướng khi HTTP 200 JSON hợp lệ.
13. **Bẫy Nến Chưa Đóng Trong Anti-FOMO & Nâng Tầm TrapDetector:** Anti-FOMO lấy `iloc[-1]` nến chưa đóng làm râu giật tức thời từ chối lệnh oan -> Chốt cứng nến đã đóng `iloc[-2]`; TrapDetector bị chặn trần 0.70 làm rớt tín hiệu pinbar cá mập -> Nâng trần lên 0.80. Thực nghiệm Replay 117,613 sự kiện từ 2 PC chứng minh Tool Mới tăng Profit Factor lên 0.57 (+51.9%), Payoff lên 0.24 (+61.8%) và mở khóa thêm +25.2% lệnh.
14. **Giải Mã Trajectory Vị Thế Giảm Vốn $100 & Nghịch Lý Nấc SL:** 77.8% vị thế sau khi chạm Nấc 1 (-0.65 ATR) cắm thẳng xuống Hard SL (-1.5 ATR), chỉ 16% vòng lại hòa vốn và 3.7% chạm TP. Vốn $100 chia 3-4 nấc kém hiệu quả hơn 2 nấc do nhân số lần phí Taker 0.05% sàn và 75% vốn còn lại gánh lỗ sâu. Giải pháp tối ưu: Kịch bản 5 (Cắt 50% ở 0.65 ATR + Siết SL phần còn lại về 1.0 ATR) kết hợp Smart Volume Gate (xả >= 1.8x đóng 100%), giảm 45.8% lỗ, nâng Payoff lên 0.39 và hạ Max DD xuống 7.11%.
15. **Tích Hợp Telemetry Gate (Mode 7) - Phòng Vệ Tối Thượng Đa Tầng Vốn:** Thay vì chia nấc cứng theo giá làm dính cắt non râu giật, tại Nấc 1 (0.65 ATR) bot kiểm tra Volume (`rvol`) và tốc độ rơi (`held_minutes`): Nếu cá mập xả mạnh $\ge 1.6x$ hoặc gãy nhanh $\le 15m$ -> Đóng 100% vị thế khẩn cấp né cú rơi 1.5 ATR; nếu volume cạn kiệt $< 1.6x$ -> Cắt 50% và siết SL về 1.0 ATR đón 44.3% nhịp rút râu hòa vốn. Giảm 25% tổng thiệt hại vốn và hạ Max DD xuống 7.91% - 8.02% xuyên suốt mọi tầng vốn từ $50 đến $500.
16. **Kiểm Toán Tổng Thể, Khử Xung Đột Veto & Gia Cố 7 Điểm Trọng Yếu:** Qua giám định thực tế PC2 (19,205 dòng log), phát hiện xung đột đá nhau giữa Miễn trừ Opposing Veto và Micro Consensus Veto khi AI Ensemble đối kháng cực độ $\ge 70\%$ (vừa in miễn trừ vừa in veto) -> Chặn đứng miễn trừ khi AI $\ge 70\%$ và đồng bộ cờ `exempt_ai_opposing`. Đồng thời vá dứt điểm 6 điểm tiềm ẩn: lỗi `[WinError 3]` tạo DB không có thư mục cha, nuốt ngoại lệ khi cập nhật lại TP sàn, đọc cache nến CSV header `datetime`, deprecation trong FeatureEngine và bare `except:`.
17. **Tam Tầng Phòng Vệ Tự Động Khi Vắng Mặt & Đối Soát Mô Phỏng Lịch Sử:** Khi người dùng vắng mặt và việc đặt TP sàn bị từ chối do Notional $< 5$ USDT, bot tự động kích hoạt **Local RAM Watchdog & Trailing Stop** để bán chốt lời tại đích mà không cần can thiệp thủ công, đồng thời giữ Hard SL sàn và báo Telegram. Mô phỏng thực nghiệm 140 setup chứng minh Tool Hiện Tại giảm 54.7% thua lỗ (từ -45.02$ còn -20.37$), nâng Profit Factor lên 0.57 và Payoff lên 0.78.
18. **Giải Mã Vắng Lệnh Đêm 24-25/10, Khử Lỗi Cold-Start `<=` & Phân Lớp RVol Thích Ứng:** Bot thực tế đã mở SHORT SUI (cắt sớm DOA 25m -0.13$) và đặt 2 lệnh M1 Sniper Maker (ENA, RED) nhưng bị timeout do giá chạy thẳng. Khắc phục triệt để 4 điểm thắt nút: sửa lỗi logic `agreeing <= min_agreeing` thành `<` trong Cold-Start Veto (tránh hủy oan lệnh 2 đồng thuận), chuẩn hóa `agreeing_tech_count` loại trừ AI và ép cùng chiều, tích hợp Phân lớp thanh khoản thích ứng (hạ sàn RVol xuống 0.20 cho Major Pairs và nến $\ge 300k$ USDT để né bẫy sụt volume ban đêm của SOL), và co hẹp retest M1 Sniper về 0.12% - 0.22% khi tín hiệu $\ge 75\%$ để khớp lệnh Maker đón trọn sóng.
19. **Báo Cáo Thực Nghiệm Mô Phỏng Toàn Diện Đa Kịch Bản (Dual-PC Replay 749 Lệnh & 606 Cụm Tín Hiệu):** Tái lập toàn bộ 743 chu kỳ lệnh thực tế (PC1 + PC2) và 606 cụm tín hiệu (từ 2,601 dòng log 11 ngày): Baseline cũ (KB 0) chịu lỗ -16.43 USDT, PF 0.68, Max DD 36.87%; Bản vá Đề xuất chuẩn (KB 1) lật ngược thế cờ lên **+3.27 USDT**, nâng PF lên **1.10** (+61.8%), Payoff **0.80** (+63.3%) và giảm Max DD xuống **5.61%**; Bản vá Thận trọng (KB 2) đạt **+5.97 USDT**, PF **1.19**, Max DD **4.79%**; trong khi vào lệnh Market (KB 3) lỗ sâu **-76.19 USDT** do phí Taker/trượt giá. Khẳng định M1 Sniper Maker kết hợp Phân lớp RVol 0.20 cho Major là chìa khóa vàng giúp hệ thống tăng trưởng dương bền vững.
20. **Đại Phẫu Kiểm Toán Toàn Diện Codebase, Mở Khóa Mode 7 Vốn Nhỏ & Đồng Bộ 5 Điểm Trọng Yếu:** Rà soát toàn bộ 38 tệp Python, vá dứt điểm 5 tử huyệt tiềm ẩn: (1) Mở khóa Telemetry Gate Mode 7 cho vị thế nhỏ `total_sl_stages >= 1`, cho phép lệnh 1-nấc xả 100% khi cá mập dump $\ge 1.6x$ hoặc gãy nhanh $\le 15m$, và siết Hard SL về 1.0 ATR khi volume cạn kiệt (tiết kiệm 33.3% - 56.7% lỗ); (2) Đảm bảo trần ký quỹ Altcoin không đè bẹp Notional dưới sàn 10.60 USDT khi đòn bẩy $\le 2x$; (3) Sửa lỗi lệch index và sinh NaN trong tính True Range của M1 Sniper thành `df['close'].shift(1)`; (4) Đồng bộ miễn trừ Volume Exhaustion cho Major Pairs, TradFi và nến $\ge 300k$ USDT; (5) Bổ sung cờ `_force_sl_update` ép sàn Binance lập tức nâng SL về Hòa Vốn (+0.12%) khi vị thế $< 5$ USDT đạt $+1.10\%$ profit.
21. **Chuẩn Hóa Ma Trận 3 Lớp Tài Sản (Major Crypto - TradFi - Altcoins) & Vá 3 Điểm Nghẽn TradFi:** Khắc phục triệt để tương tác chéo giữa 3 lớp: (1) Sửa lỗi `not is_tier1` thành `is_crypto_altcoin` trong Climax Pump Veto & Overbought Veto (`ai/signal_aggregator.py`), giải phóng cổ phiếu Mỹ (NVDA, TSLA) không bị chặn nhầm bởi bẫy Altcoin; (2) Mở rộng Khiên Cuối Tuần (Weekend Shield) bao trùm cả Hàng hóa TradFi (`is_tradfi_commodity`: XAU, XAG, CL) chống rủi ro nhảy Gap sáng thứ Hai (`core/bot.py`); (3) Bổ sung `is_tradfi_pre` vào sàn RVol 0.20 thích ứng (`core/bot.py`), khơi thông thanh khoản phiên Wall Street.

22. **Đối Soát Thực Nghiệm 3 Lớp Tài Sản (Dual-PC 745 Vị Thế & 606 Tín Hiệu Sau Fix):** Mô phỏng tái lập toàn diện khẳng định bản vá mới đưa tổng PnL từ **-16.47 USDT** lên **+5.78 USDT** (tăng +22.25$), nâng Profit Factor từ 0.68 lên **1.19** (+75%) và siết Max DD từ 37.0% xuống **4.97%**: (1) Major Crypto (+5.25$, PF 2.89) tối ưu trọn vẹn nhờ sàn RVol 0.20 ban đêm; (2) TradFi giảm 85.4% thiệt hại (từ -6.38$ còn -0.93$) nhờ gỡ bẫy Climax Veto cho NVDA/TSLA và che chắn Weekend Shield cho Vàng/Dầu; (3) Altcoins lật ngược từ -13.25$ lên **+1.47$** nhờ mở khóa Telemetry Gate Mode 7 xả 100% khi cá mập dump và sửa True Range M1 Sniper.

---

## 3. BẢN ĐỒ 44 FILE LÀM VIỆC CỐT LÕI
* **Lõi (Core):** `core/bot.py` (bộ não chính), `core/scanner.py` (quét đa luồng 50 coin), `core/exchange.py` (CCXT pool 100), `core/order_manager.py`, `core/data_collector.py` (tải nến MTF song song), `core/telegram_notifier.py` (Queue async, ép IPv4), `core/firebase_telemetry.py`, `core/gate_telemetry.py`, `core/optimizer.py`.
* **Chiến thuật (Strategies):** `strategies/trend_following.py`, `trap_detector.py`, `momentum_breakout.py`, `mean_reversion.py`, `hft_scalping.py`, `smart_dca.py`, `base_strategy.py`.
* **Trí tuệ nhân tạo (AI):** `ai/signal_aggregator.py` (Consensus Veto & Chop Shield), `ai/jev_agent.py` (Ollama qwen2.5:7b), `ai/ml_model.py` (XGBoost 91 features), `ai/feature_engine.py`, `ai/quantum_path_simulator.py`, `ai/market_regime.py`, `ai/news_sentiment.py`, `ai/ollama_agent.py`.
* **Rủi ro & DB (Risk/DB):** `risk/risk_manager.py`, `risk/position_sizer.py`, `database/db_manager.py`.
* **Giao diện & Web:** `dashboard/app.py`, `dashboard/templates/index.html` (Flank Radar Cyberpunk, link chart Binance, copy coin), `loading.html`.
* **Đồng bộ & Triển khai:** `cloud_sync.py`, `sync_telemetry_loop.py`, `deploy_web_client.py` (script deploy tự động 1 chạm), `run_web.py`.
* **Cấu hình & Batch:** `config/settings.yaml`, `config/strategies.yaml`, `config/pairs.yaml`, `.env`, `START.bat`, `RESTART.bat`, `Fix_Time.bat`, `install.bat`, `requirements.txt`.
* **Tài liệu SSOT:** `HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md` (toàn văn thuật toán & kiểm chứng 105 lệnh).

---

## 4. 4 QUY TẮC BẮT BUỘC CHO MỌI PHIÊN LÀM VIỆC CỦA AI

### Quy Tắc 1: Tự Động Kế Thừa Bối Cảnh (Không Cần Nhắc Lại)
* Ngay khi bắt đầu phiên hội thoại mới, AI mặc định đã đọc hiểu toàn bộ nội dung trong tệp này và tệp mẹ [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md). Người dùng chỉ cần đưa ra yêu cầu ngắn gọn cho ngày làm việc mới.

### Quy Tắc 2: Bắt Buộc Cập Nhật Tài Liệu Mẹ Ngay Sau Khi Sửa Code
* **Sau mỗi lần sửa lỗi, tối ưu hay thêm tính năng mới:** AI BẮT BUỘC phải cập nhật ngay lập tức vào [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md) và [`AGENTS.md`](file:///d:/TRADE/AGENTS.md) / [`GEMINI.md`](file:///d:/TRADE/GEMINI.md).
* Ghi rõ: Ngày cập nhật, tệp đã sửa, lý do căn nguyên và kết quả kiểm thử. Điều này ép tất cả các phiên chat sau (ngày 25, 26, 27...) đều tự động nắm chắc phiên bản mới nhất.

### Quy Tắc 3: Chính Sách Dọn Rác Tuyệt Đối (Zero-Pollution Policy)
* **Tuyệt đối KHÔNG ĐƯỢC TẠO** file tạm, file rác, file nháp (như `test_*.py`, `temp_*`, `*.tmp`, `*.bak`) trực tiếp trong thư mục `d:\TRADE`.
* Mọi script kiểm tra tạm thời chỉ được phép đặt trong thư mục cách ly `scratch/` và **phải được tự động dọn dẹp sạch sẽ** sau khi hoàn thành.
* Đảm bảo thư mục làm việc `d:\TRADE` và mã nguồn PC2 luôn tinh khiết 100%.

### Quy Tắc 4: Kiểm Thử Toàn Diện & Đồng Bộ LAN 1-Chạm
Khi nhận bất kỳ yêu cầu sửa đổi nào, AI phải thực hiện đủ 3 bước:
1. **Kiểm tra cú pháp:** Biên dịch `py_compile` tất cả file sửa đổi, bảo đảm 0 syntax errors.
2. **Kiểm tra xung đột:** Chạy `pip check` bảo đảm không lỗi phụ thuộc.
3. **Đồng bộ tự động sang PC2 & Web:** Chạy lệnh `python deploy_web_client.py` để:
   * Copy toàn bộ mã sạch sang `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` qua LAN.
   * Tạo gói zip sạch `TradeMatrix_Client_v2.0_clean.zip`.
   * Commit và Push lên GitHub để Cloudflare Pages tự build web mới.
   * Xác nhận tỷ lệ trùng khớp Hash SHA-256 đạt 100%.
