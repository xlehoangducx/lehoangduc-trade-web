# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & LEAN CONSTITUTION
> **Single Source of Truth (SSOT) Tinh Gọn — Nạp Tự Động 100% Không Bị Cắt Cụt (Zero Truncation Guarantee)**
> *Dành riêng cho mọi phiên làm việc mới trên Antigravity IDE. Người dùng KHÔNG CẦN copy-paste prompt dài.*

---

## 👑 0. TÔN CHỈ TỐI THƯỢNG (SUPREME QUANT DOCTRINE)
### **"THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN (SMART INVERSION & WHALE FLOW ALIGNMENT)"**
1. **Mục tiêu cốt lõi:** Kiếm lợi nhuận bền vững bằng cách đi cùng phe Số Đông Chiến Lược và Dòng Tiền Cá Mập (Smart Money / Whale Flow). TUYỆT ĐỐI KHÔNG rơi vào tư duy phòng thủ thụ động / chỉ né tránh (`return None` / Veto = 0$).
2. **Phân tích Ngược lại (Inversion Analysis):** Trước mọi lệnh thua hoặc xung đột tín hiệu, câu hỏi bắt buộc phải là: *"Làm thế nào để LẬT NGƯỢC (Invert) lệnh thua đó thành LỆNH THẮNG đi thuận dòng tiền cá mập?"*:
   - **Cá mập xả thác đổ / Số đông báo SELL:** Loại bỏ bẫy đáy giả, xác nhận lệnh SHORT (`🌊 SMART WATERFALL BREAKDOWN SHORT`).
   - **Cá mập bơm bão Volume (nến xanh đặc râu < 30%, RVol >= 1.8x):** Cấm Short cản tàu, kích hoạt `🚀 SMART MOMENTUM RIDE BUY` (Pha 1).
   - **Sóng bơm kiệt sức xuất hiện râu xả đỉnh >= 35%:** Ưu tiên Pha 2 (`⚡ EXHAUSTION FADING SHORT`) bắt đỉnh ăn trọn nhịp sập.
   - **Bảo vệ JEV Đa Khung Thời Gian (`JEV MTF TREND SHIELD`):** Tuyệt đối cấm xóa phiếu của JEV Agent (`pop('jev_agent')`) hoặc ép Short ngược trend khi JEV 4H đang báo BUY mạnh $\ge 70\%$.

---

## 🛑 0.1. DANH MỤC 6 CƠ CHẾ ĐÃ BỊ ĐÀO THẢI VĨNH VIỄN (PURGED ANTI-PATTERNS)
*CẤM BẬT LẠI HOẶC TÁI ĐỀ XUẤT 6 CƠ CHẾ ĐÃ CHỨNG MINH GÂY THIỆT HẠI NẶNG NÀY:*
1. **CẮT THEO THỜI GIAN MÙ QUÁNG (`doa_15m`, `doa_25m`, `doa_35m`, `idle_120m`):** Đã xóa sổ vĩnh viễn (gây lỗ -3.63 USDT, cắt đúng đáy 87.5%). Thay bằng Mode 7 Telemetry Gate (xả khi volume dump $\ge 1.6x$).
2. **KHÓA HÒA VỐN NON TRƯỚC TP1 (dưới +0.65% MFE hoặc dưới 4.5 phút đầu):** Làm 82% lệnh bị quét văng siêu sóng. Thay bằng Tam Tầng Bảo Vệ Vốn V3.0 (Cushion SL -0.25% tại MFE +0.80%, Hard BE +0.22% tại MFE +1.15%).
3. **DE-RISKING SỚM KHÔNG LỌC THỜI GIAN (0.40 ATR):** Cắt non ở râu giật 12s đầu. Thay bằng 0.65 ATR + ép giữ $\ge 1.0$ phút.
4. **CHOP SHIELD VÔ HẠN (ATR BTC $\ge 1.2\%$ trên 15M):** Khóa cứng Altcoin suốt 3 tiếng. Thay bằng ADX/ATR kèm giãn cách 120s.
5. **ĐẨY `Signal.HOLD` VÀO `by_strategy`:** Kéo tụt 31% điểm raw_score của phe đa số. HOLD chỉ làm Veto độc lập.
6. **BỎ RƠI SIÊU SÓNG BẰNG FAST-SKIP PRE-LLM:** Bỏ rơi coin tăng dựng đứng. Whale Pump Storm được miễn trừ Fast-Skip để mở Pha 1.

---

## 🛑 0.2. GIAO THỨC BÁO ĐỘNG ĐỎ KHI CHUỖI THUA LIÊN TIẾP (CONSECUTIVE LOSS FORENSIC GATE)
1. **Quy tắc kích hoạt:** Khi hệ thống ghi nhận >= 2 lệnh thua liên tiếp trên Live:
   - NGHIÊM CẤM coi đây là "nhiễu ngẫu nhiên". BẮT BUỘC coi đây là dấu hiệu tiềm ẩn LỖI HỆ THỐNG / LỖI LOGIC NGẦM (Semantic Bug).
   - TỰ ĐỘNG KÍCH HOẠT quy trình Pháp y 4 Tầng: (1) Nguồn tín hiệu M1/15M -> (2) Phán đoán của LLM/AI -> (3) Bộ lọc Aggregator -> (4) Quá trình siết SL/thoát lệnh.
   - BẮT BUỘC rà soát toàn diện code, chạy mô phỏng chuẩn quỹ đối chứng trước khi đưa ra bất kỳ kết luận hay can thiệp nào.

---

## 🔬 0.3. TIÊU CHUẨN MÔ PHỎNG CHUẨN QUỸ ĐỊNH LƯỢNG (INSTITUTIONAL REPLAY STANDARD)
1. **BẮT BUỘC MÔ PHỎNG TOÀN BỘ LỊCH SỬ TRƯỚC MỌI ĐỀ XUẤT:**
   - TUYỆT ĐỐI CẤM tự ý sửa bộ quy tắc/tín hiệu khi **CHƯA CHẠY MÔ PHỎNG HỒI QUY ĐỐI SOÁT TRÊN TOÀN BỘ DỮ LIỆU LỊCH SỬ** (`trade_bot.db` và log PC2 qua `tools/true_signal_simulator.py` hoặc `tools/full_spectrum_impact_simulator.py`).
   - BẮT BUỘC đo lường chính xác **Hiệu ứng Lan tỏa (Ripple Effect)**: Lệnh thay đổi có làm mất lệnh đang thắng không? (False Exits phải = 0!).
   - Chỉ được đề xuất khi: **Tổng Net PnL tăng lên VÀ không làm suy giảm tỷ lệ thắng của các cụm chiến lược dương khác!**
2. **Cỗ máy Replay chuẩn quỹ bắt buộc bao gồm:**
   - Dữ liệu nến M1/Tick, đo chính xác đường cong MFE/MAE thực tế.
   - Nhân tố dẫn dắt vĩ mô: BTC Dominance, ATR BTC (Crypto); QQQ/SPY, VIX, Giờ mở phiên Mỹ (TradFi).
   - Tái lập đầy đủ chi phí: Phí Maker 0.02%, Taker 0.05%, trượt giá slippage, chốt 50% TP1 và Cushion SL.

---

## 💡 0.4. QUY TRÌNH PHÁP Y PHÂN LOẠI 6 NHÓM TÍN HIỆU THUA & MA TRẬN QUYẾT ĐỊNH
Khi người dùng yêu cầu phân tích một lệnh lỗ, AI BẮT BUỘC phải điều tra sâu 4 tầng và phân loại lệnh vào chính xác 1 trong 6 nhóm:
1. **🔄 Nhóm 1: Có thể Lật Ngược (Smart Inversion Candidates):** Vào sai hướng khi cá mập đang bơm/xả thác đổ. Lập phương án LẬT NGƯỢC (Invert) đi thuận sóng cá mập. Báo cáo cả 2 kịch bản: PnL Veto (0$) vs PnL Invert (+).
2. **📈 Nhóm 2: Vi phạm Xu Hướng Vĩ Mô (MTF Trend Violation):** Vào ngược xu hướng 4H/1H khi cấu trúc chưa đảo chiều. Siết chặt rào chắn `JEV MTF TREND SHIELD`, cấm bypass khi thiếu râu xả đỉnh vật lý $\ge 35\%$.
3. **⏸️ Nhóm 3: Nên Đứng Ngoài (Veto / Stand Aside - Zero Edge):** Thị trường sideway tích lũy nén biên độ, bẫy giá cả 2 đầu, $RVol_{15M} < 0.8x$. ĐỨNG NGOÀI TUYỆT ĐỐI (Veto = 0$). Thà mất cơ hội còn hơn mất vốn.
4. **⚡ Nhóm 4: Phân tích Yếu / Tín hiệu Suy Kiệt Sớm (Weak Signal / Early Exhaustion):** Dòng tiền đột ngột quay xe sau 2-8 phút. Kích hoạt Shock Rescue / ChoCH Choke SL thoát hiểm khẩn cấp ở lỗ nhỏ (-0.15% -> -0.45%), triệt tiêu nguy cơ dính full SL.
5. **🐛 Nhóm 5: Lỗi Code / Lỗi Logic Ngầm (Semantic & Runtime Bugs):** Phân tích đúng nhưng lỗ do lỗi code (NameError, kẹt luồng, crash trailing stop). Sửa dứt điểm lỗi logic ngầm, kiểm thử AST 100%. Tuyệt đối KHÔNG đổ lỗi cho tín hiệu!
6. **🎲 Nhóm 6: Nhiễu Ngẫu Nhiên thuộc Cụm Chiến Thuật Sinh Lời (Statistical Noise):** Lệnh thua là chi phí rủi ro ngẫu nhiên bình thường của chiến thuật có kỳ vọng dương (EV > 0). TUYỆT ĐỐI KHÔNG TÙY TIỆN XÓA BỎ HOẶC ĐẢO NGƯỢC CHIẾN THUẬT.

---

## ⚖️ 0.5. QUY CHUẨN TỔNG KẾT, CHẤM ĐIỂM & GIAO THỨC DỌN RÁC
1. **Quy tắc bắt buộc khi Chấm điểm / Tổng kết phiên:**
   - **Tự tổng kết trung thực:** Bóc tách các lỗi phát sinh/ngầm trong phiên (không che giấu, không báo cáo sớm khi chưa đọc live log).
   - **Chấm điểm khách quan:** Theo Rubric 100 tại `docs/AI_TRUST_SCORECARD.md` và cập nhật tiến trình đến ngưỡng $\ge 95\%$.
   - **TỰ ĐỘNG DỌN RÁC CUỐI PHIÊN (`tools/clean_workspace.py`):** Xóa sạch 100% script kiểm thử tạm thời trong `scratch/`, file nháp, dump tạm trên cả PC1 và PC2. Giữ không gian làm việc tinh gọn, chỉ còn lại code SSOT trong `docs/FEATURE_MAP.md`.
2. **CẢNH BÁO CHỈ SỐ TIN CẬY (AI TRUST: 45% — VÙNG GIÁM SÁT THỬ THÁCH):**
   - AI từng nhiều lần tự khẳng định "hết lỗi" nhưng PC2 vẫn lỗi. Bắt buộc xuất phát từ tâm thế cẩn trọng, kiểm thử lặp đi lặp lại trên log runtime thực tế, database và mô phỏng trước khi kết luận!

---

## 🛑 0.6. BỘ QUY TẮC BẤT BIẾN SÀN BINANCE & BẢNG PHÒNG TRỪ 13 LỖI THỰC CHIẾN
1. **5 Bộ Lọc Sàn Cứng (Binance Order Filters Invariants):**
   - **`LOT_SIZE`**: BTC tối thiểu `0.001 BTC`, ETH `0.01 ETH`, SOL `0.1 SOL`. Format qua `amount_to_precision()`. Nếu không đủ ký quỹ (~17$), skip an toàn, cấm ép lệnh gây `-1013`.
   - **`MIN_NOTIONAL`**: Lệnh mở mới bắt buộc notional $\ge 5.00\text{ USDT}$ (`notional = max(6.0, notional)`). Miễn trừ cho lệnh đóng (`reduceOnly=True`).
   - **`PRICE_FILTER`**: Format qua `price_to_precision()`.
   - **`PERCENT_PRICE`**: Giá Limit không lệch quá 2% so với giá Mark.
   - **`MAX_NUM_ALGO_ORDERS`**: Tối đa 10 lệnh điều kiện (SL/TP) đồng thời.
2. **Bảng Phòng Trừ 13 Mã Lỗi Binance Futures:**
   - `-1013`: Thiếu format precision hoặc notional < 5.0$.
   - `-2011`: Tra cứu/hủy Algo Order ID `30000...` qua endpoint thường. Bắt buộc dùng `params={'trigger': True}` hoặc tra cứu `/fapi/v1/userTrades`.
   - `-2019`: Thiếu ký quỹ. Khống chế trần sử dụng ký quỹ $\le 50\%$ NAV.
   - `-2021`: Stop price đặt sai chiều so với giá hiện tại. Đóng bằng Market thông thường nếu giá đã vượt qua.
   - `-2022`: ReduceOnly đặt khi không có vị thế mở hoặc sai chiều.
   - `-4116`: ClientOrderId trùng lặp. Dùng lại bản ghi gốc, cấm đặt thêm.
   - `-4181`: startTime > endTime hoặc âm khi đồng bộ userTrades.
   - `-1021`: Timestamp lệch > 1000ms. Bù trừ `load_time_difference()` và gọi `w32tm /resync`.
   - `-4411`: TradFi agreement required. Ký tự động qua `/fapi/v1/stock/contract`.
   - `-5022`: Post Only bị từ chối do giá trôi qua. Chuyển sang tái rình mồi hoặc hủy an toàn.
   - `-1111`: Precision over maximum. Format float chuẩn `f"{val:.{prec}f}"`.
3. **Top 3 Lỗi Logic Ngầm Từng Làm Treo Tool PC2 (Cấm Tuyệt Đối):**
   - **NameError / UnboundLocalError:** Quét Rào chắn 9 (AST SymTable) 100% trước khi deploy!
   - **Lỗi Unpack dữ liệu nến:** Không unpack thừa trong `get_ohlcv`, trả DataFrame chuẩn.
   - **AttributeError trên AI / Aggregator:** Cấm truy cập thuộc tính chưa khởi tạo (`aggregator.config`).

---

## 🏛️ 0.7. MA TRẬN 10 PHÂN LỚP TRADFI & SMART INVERSION PHIÊN MỸ
1. **10 Phân Lớp Ngành TradFi Trên Binance (SSOT 238 Mã — Chi tiết xem `docs/QUANT_WORKFLOW_PLAYBOOK.md`):**
   - `SEMICONDUCTOR` (53 mã): Benchmark `SOXL` (Bull 3x) vs `SOXS` (Bear 3x), `NVDL` (2x) vs `NVDA` (1x), `SMH`. Đại diện: `NVDA, AMD, AVGO, ASML, AMAT, MU, TSM, QCOM, ARM, SMCI...`
   - `NASDAQ_TECH` (55 mã): Benchmark `QQQ`, `TQQQ` (Bull 3x) vs `SQQQ` (Bear 3x). Đại diện: `AAPL, MSFT, AMZN, GOOGL, META, NFLX, PLTR, CRM, ORCL...`
   - `ASIAN_TECH` (13 mã): `BABA, PDD, MEITUAN, TENCENT, KUAISHOU, HK0700...`
   - `AI_INFRA_ENERGY` (8 mã): `VST, CEG, OKLO, SMR, VRT, BE, FLNC, URNM`.
   - `CRYPTO_PROXY` (13 mã): Benchmark `BTC` & `MSTR`, `MSTU/MSTX` (2x) vs `MSTR`, `CONL` (2x) vs `COIN`, `MARA, IREN...`
   - `EV_AEROSPACE` (11 mã): Benchmark `TSLA`, `TSLL` (2x) vs `TSLA`, `RIVN, BYD, NIO, RKLB, ASTS...`
   - `COMMODITY_METALS` (8 mã 24/5 CME Globex): `XAU, XAG, PAXG, PLAT, PALL, COPPER, GDX`. (Miễn trừ session phiên Mỹ).
   - `COMMODITY_ENERGY` (7 mã 24/5 CME Globex): `CL, BZ, NATGAS, XOM, OXY, XLE, EQT`.
   - `BROAD_INDEX` (21 mã): `UPRO` (Bull 3x) vs `SPXU` (Bear 3x), `IWM` (Bull) vs `TZA` (Bear 3x), `UVXY, SPY...`
   - `TRADITIONAL_VALUE` (49 mã): Y tế (`LLY, NVO, PFE...`), Tài chính (`JPM, GS, BAC, HOOD, IBKR...`), Tiêu dùng (`WMT, COST, KO, DIS...`).
2. **4 Rào Chắn Tương Hỗ Bất Biến (Mutual Exclusion Invariants):**
   - **Rào chắn 1 (Khóa Đối Nghịch):** Giữ LONG `SOXL`, CẤM mở LONG `SOXS` (hoặc SHORT `SOXL`). Tương tự `TQQQ/SQQQ`, `UPRO/SPXU`.
   - **Rào chắn 2 (Khóa Cùng Gốc):** CẤM mở đồng thời cổ phiếu cơ sở và ETF đòn bẩy đơn (`NVDA + NVDL`, `TSLA + TSLL`, `MSTR + MSTU`).
   - **Rào chắn 3 (Chặn Bắt Đáy Bear ETF):** Benchmark Uptrend (EMA20 > EMA50, ADX $\ge 25$), CẤM MUA BẮT ĐÁY `SOXS, SQQQ, SPXU, TZA`.
   - **Rào chắn 4 (Khống Chế Đơn Ngành):** Tối đa 1 vị thế rủi ro cho mỗi nhóm ngành.
3. **Mở Khóa Smart Inversion Giờ Mở Phiên Mỹ (21:30 - 22:30 VN):**
   - Trong 60m đầu phiên Mỹ, nếu có sóng đẩy volume bão ($RVol \ge 1.8x$) và nến xanh đặc râu xả đỉnh $< 30\%$, **LẬT NGƯỢC TÍN HIỆU SHORT CẢN TÀU THÀNH MOMENTUM RIDE BUY** đi thuận cá mập Wall Street!
4. **Giao Thức Sandbox Cho Mã Mới Niêm Yết (< 72h):**
   - Đòn bẩy $\le 3x$ (TradFi $2x$), ký quỹ $\le 10\%$ NAV, SL thích ứng ATR. Sau 48 nến M15 tự tính tương quan Pearson $r$ với `BTC, SOXL, QQQ, SPY` để gán ngành. Thua $\ge 2$ lệnh kích hoạt Cooldown cách ly 24h.
5. **Giao Thức Khóa Lệnh Mã Mới Chưa Phân Lớp (Zero Blind Entry):**
   - Phát hiện mã chưa có trong Ma Trận Ngành: CẤM TỰ ĐỘNG MỞ LỆNH, bắn cảnh báo Telegram và tự động báo cáo trên màn hình qua `tools/daily_auditor.py`.

---

## 🔬 0.8. QUY TRÌNH PHÁT TRIỂN & ĐỐI SOÁT ĐỊNH LƯỢNG CHUẨN QUỸ 7 BƯỚC
*BẮT BUỘC TUÂN THỦ TRONG MỌI PHIÊN SỬA CODE HOẶC NÂNG CẤP HỆ THỐNG:*
1. **Bước 1 (Phân Lập Đơn Lẻ):** Giải quyết từng vấn đề một, không làm gộp. Giải phẫu nguyên nhân gốc rễ và công thức định lượng trước khi gõ code.
2. **Bước 2 (Mô Phỏng Toàn Phần Chuẩn Quỹ):** Xây dựng cỗ máy mô phỏng chứa $100\%$ cơ chế: Nến M1/M15, M1 Sniper Stalking, Phí Maker 0.02%/Taker 0.05%, Slippage, Shock Rescue, ChoCH Invalidation, Tam Tầng SL, Trailing Stop, 3 lớp tài sản. **TUYỆT ĐỐI NÓI KHÔNG VỚI TIMER (Zero-Timer Invariant)**.
3. **Bước 3 (Đối Soát Lũy Kế 578 Lệnh Lịch Sử):** Đo lường chi tiết Win Rate, Net PnL, PnL Delta và **Side-Effect (False Exits BẮT BUỘC = 0)**.
4. **Bước 4 (Rà Soát Mã Nguồn & Thứ Tự Thực Thi):** Xóa sạch mã chết/biến timeout cũ. Kiểm tra trật tự ưu tiên bảo vệ vốn trong vòng lặp vị thế: `Shock Rescue -> ChoCH Invalidation -> Tam Tầng SL V3.0 -> Partial TP1 -> Trailing Stop -> Hard SL/TP`.
5. **Bước 5 (Dò Tìm Lỗi Logic Ngầm & Đá Nhau Giữa Các Tầng):** Kiểm tra tính nhất quán tuần hoàn tín hiệu từ Scanner $\rightarrow$ Aggregator $\rightarrow$ Sniper $\rightarrow$ Position Manager $\rightarrow$ Telemetry $\rightarrow$ Database.
6. **Bước 6 (Kiểm Tra Toàn Cục):** Chạy `python tools/hard_constraints_gate.py` đạt $11/11$ Passed và quét AST SymTable $0$ lỗi.
7. **Bước 7 (Đồng Bộ LAN PC2 & Đẩy Cloud):** Chạy `python deploy_web_client.py` đồng bộ SMB sang PC2, đẩy Git Cloudflare Pages và chạy `python tools/clean_workspace.py`.

---

## 🚫 0.9. BẢNG PHÒNG TRỪ 7 LỖI THỰC CHIẾN & TÔN CHỈ THỰC THI
1. **Tuyệt đối cấm Timer trong Sniper Stalking:** Đã xóa bỏ vĩnh viễn `timeout_sec`. Lệnh rình chỉ hủy khi giá chạy mất ($Runner\text{ }Away > 1.5 ATR$) hoặc nến M1 gãy vỡ cấu trúc với $RVol_{M1} \ge 2.0x$.
2. **Hiểu đúng Nghịch Lý Win Rate vs Payoff Ratio:** Win Rate $37\%$ nhưng Net PnL $+14.41\text{ USDT}$ (lãi kỷ lục) vì mức lỗ trung bình giảm $75.5\%$ (từ $-0.20\$$ xuống $-0.05\$$) trong khi mức lãi trung bình giữ $+0.30\$$ (Payoff Ratio $6.21x$). Tỷ lệ bảo toàn vốn thực tế đạt $54.5\%$.
3. **Cập nhật Fresh Dynamic Peak MFE:** Bắt buộc tính trực tiếp từ giá đỉnh nến M1 thời gian thực, cấm đọc giá trị tĩnh trong RAM.
4. **Rào chắn Timestamp Nến M1:** ChoCH Invalidation bắt buộc kiểm tra $ts_{\text{candle}} \ge ts_{\text{entry}} - 10s$ để tránh lấy nhầm nến quá khứ trước entry.
5. **Tắt Thông Báo Telegram Khi Rình Mồi:** CẤM gửi tin nhắn Telegram khi đang đặt lệnh rình Post-Only Limit Maker. Chỉ gửi thông báo khi lệnh ĐÃ KHỚP thành vị thế mở.
6. **Dọn Sạch Workspace Cuối Phiên:** Tự động chạy `tools/clean_workspace.py` xóa sạch $100\%$ file tạm trong `scratch/`, không để lẫn với code bot.
7. **Bảo Toàn Quy Tắc Zero Truncation:** Giữ `AGENTS.md` và `GEMINI.md` dưới $22\text{ KB}$ để hệ thống Antigravity nạp tự động $100\%$ không bị cắt cụt.

---

## 🏛️ 1. KIẾN TRÚC 2 MÁY TÍNH & MA TRẬN 3 LỚP TÀI SẢN
- **💻 PC1 (Máy Phát Triển - Dev Machine):** `d:\TRADE` (Python 3.14.7 64-bit venv, Antigravity IDE).
- **🖥️ PC2 (Máy Thử Nghiệm 24/7 - Live Daemon):** `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` (Binance Futures Live, Equity ~102.18 USDT, Ollama `qwen2.5:7b`).
- **Ma trận 3 Lớp Tài Sản (Three-Tier Asset Matrix):**
  1. **Major Crypto (`BTC`, `ETH`, `SOL`):** Thanh khoản dày, ATR 0.4% - 0.9%, không bị chặn bởi Weekend Shield.
  2. **TradFi Cổ Phiếu Mỹ (`NVDA`, `TSLA`, `MRVL`, `TQQQ`):** Đòn bẩy $\le 4x$, trần ký quỹ 20% NAV, đóng trước thứ 7 qua Weekend Shield, SL ngắn bám sát, cấm nới rộng.
  3. **Crypto Altcoins (`MOVR`, `WAL`, `PEPE`, `SKYAI`):** ATR biến động lớn (1.5% - 4.5%), cần vùng đệm Stop-Loss thích ứng theo ATR, cooldown 180m khi đóng lỗ.
  *⚠️ NGUYÊN TẮC: Tuyệt đối không lấy kết quả của 1 coin Altcoin đơn lẻ để sửa đổi SL/TP toàn sàn khi chưa chạy mô phỏng đối chứng trên cả 3 lớp tài sản!*

---

## 🧭 2. QUY CHUẨN 3 PHIÊN CHAT MỚI TRÊN ANTIGRAVITY
*Khi người dùng mở một phiên chat mới, chỉ cần gõ tiền tố tương ứng:*
### 🟢 1. PHIÊN `[OPS]` — GIÁM SÁT THỰC CHIẾN HẰNG NGÀY
- **Nhiệm vụ:** Điểm danh sáng, check số dư, PnL ngày, đối soát vị thế mở, kiểm tra lệnh SL/TP sàn.
- **Lệnh mở màn:** `"Chạy kiểm toán ngày PC2"` (hoặc `"audit"`).
- **Hành động của AI:** Tự động chạy `python tools/daily_auditor.py`, đọc database PC2 qua LAN, chấm điểm Rubric 100. Tuyệt đối không sửa code trong phiên này.

### 🔬 2. PHIÊN `[QUANT]` — PHÒNG THÍ NGHIỆM & MÔ PHỎNG TÍN HIỆU
- **Nhiệm vụ:** Phân tích pháp y các lệnh vừa đóng, giải phẫu nguyên nhân nến quét SL, chạy mô phỏng tái lập.
- **Lệnh mở màn:** `"Pháp y lệnh [Tên coin] và chạy true_signal_simulator đối soát."`
- **Hành động của AI:** Chạy `python tools/true_signal_simulator.py`, phân tích trên 3 lớp tài sản trước khi đưa ra bất kỳ kiến nghị thay đổi nào.

### 🛠️ 3. PHIÊN `[DEV]` — XƯỞNG SỬA CODE & NÂNG CẤP WEB
- **Nhiệm vụ:** Sửa lỗi logic ngầm, tối ưu hóa giao diện Web Dashboard, nâng cấp cơ chế chốt lời/cắt lỗ.
- **Lệnh mở màn:** `"Nâng cấp [Tính năng X]. Kiểm tra Hard Gate rồi deploy sang PC2."`
- **Hành động của AI:** Tham chiếu `docs/FEATURE_MAP.md`, sửa code, chạy `python tools/hard_constraints_gate.py` (vượt 100%), chạy `python deploy_web_client.py` (đồng bộ LAN PC2 và đẩy Git Cloudflare).

---

## 🛡️ 3. RÀO CHẮN CỨNG BẰNG CODE (HARD CONSTRAINTS GATE 11/11)
*Được thực thi tự động qua `tools/hard_constraints_gate.py` trước mỗi lần deploy:*
1. **Rào chắn 1:** Cấm bật lại `time_based_exits` trong `config/settings.yaml`.
2. **Rào chắn 2:** Cấm `pop('jev_agent')` thiếu khiên `JEV MTF TREND SHIELD` trong `ai/signal_aggregator.py`.
3. **Rào chắn 3:** Bảo đảm Stop-Loss luôn nằm trong khung an toàn định lượng `[1.0%, 3.5%]`.
4. **Rào chắn 4:** Endpoint `/api/stop` và `/api/pause` luôn trả về HTTP 200 idempotent, cấm báo lỗi `Bot chưa chạy`.
5. **Rào chắn 5:** `cloud_sync.py` bắt buộc có bộ đệm cache bản quyền 60s và gửi ACK tức thì cho Web.
6. **Rào chắn 6:** Cấm bypass MTF Trend Veto khi không có Whale Waterfall Breakdown trong `ai/signal_aggregator.py`.
7. **Rào chắn 7:** Altcoin biến động cao phải có biên độ Stop-Loss thích ứng ATR lên đến 3.5% trong `core/bot.py`.
8. **Rào chắn 8:** Cushion SL phải được bảo vệ bởi bộ lọc thời gian held_minutes >= 3.0 trong `core/bot.py`.
9. **Rào chắn 9:** Quét cú pháp AST chống biến chưa định nghĩa (NameError runtime) trong `tools/hard_constraints_gate.py`.
10. **Rào chắn 10:** Ma trận KB5 đồng bộ SSOT xuyên suốt giữa `core/bot.py` và `ai/signal_aggregator.py`.
11. **Rào chắn 11:** Kiểm toán bộ lọc sàn Binance Futures (-2011, -2021, -4181, -1021, -4411, -4116, Min Notional).

---

## 📚 4. BẢN ĐỒ TÀI LIỆU HỆ THỐNG
- **Cẩm nang vận hành & đối soát định lượng chuẩn quỹ 7 bước:** [`docs/QUANT_WORKFLOW_PLAYBOOK.md`](file:///d:/TRADE/docs/QUANT_WORKFLOW_PLAYBOOK.md)
- **Bản đồ tính năng & 100 tệp code:** [`docs/FEATURE_MAP.md`](file:///d:/TRADE/docs/FEATURE_MAP.md)
- **Cẩm nang tác chiến hằng ngày:** [`docs/DAILY_PLAYBOOK.md`](file:///d:/TRADE/docs/DAILY_PLAYBOOK.md)
- **Kho lưu trữ 109 bài học lịch sử đầy đủ:** [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md)
