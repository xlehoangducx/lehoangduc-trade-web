# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & LEAN CONSTITUTION

> **Single Source of Truth (SSOT) Tinh Gọn — Nạp Tự Động 100% Không Bị Cắt Cụt (Zero Truncation)**

> *Dành riêng cho mọi phiên làm việc mới trên Antigravity IDE. Người dùng KHÔNG CẦN copy-paste prompt dài.*



---



## 👑 0. TÔN CHỈ TỐI THƯỢNG (SUPREME QUANT DOCTRINE)

### **"THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN (SMART INVERSION & WHALE FLOW ALIGNMENT)"**

1. **Mục tiêu cốt lõi:** Kiếm lợi nhuận bền vững bằng cách đi cùng phe Số Đông Chiến Lược và Dòng Tiền Cá Mập (Smart Money / Whale Flow). TUYỆT ĐỐI KHÔNG rơi vào tư duy phòng thủ thụ động / chỉ né tránh (`return None` / Veto = 0$).

2. **Phân tích Ngược lại (Inversion Analysis):** Trước mọi lệnh thua hoặc xung đột tín hiệu, câu hỏi bắt buộc phải là: *"Làm thế nào để LẬT NGƯỢC (Invert) lệnh thua đó thành LỆNH THẮNG đi thuận dòng tiền cá mập?"*:

   - **Cá mập xả thác đổ / Số đông báo SELL:** Loại bỏ bẫy đáy giả, xác nhận lệnh SHORT (`🌊 SMART WATERFALL BREAKDOWN SHORT`).

   - **Cá mập bơm bão Volume (nến xanh đặc râu < 30%, RVol >= 1.8x):** Cấm Short cản tàu, kích hoạt `🚀 SMART MOMENTUM RIDE BUY` (Pha 1).

   - **Sóng bơm kiệt sức xuất hiện râu xả đỉnh >= 35%:** Ưu tiên Pha 2 (`⚡ EXHAUSTION FADING SHORT`) bắt đỉnh ăn trọn nhịp sập.

   - **Bảo vệ JEV Đa Khung Thời Gian (`JEV MTF TREND SHIELD`):** Tuyệt đối cấm xóa phiếu của JEV Agent (`pop('jev_agent')`) hoặc ép Short ngược trend khi JEV 4H đang báo BUY mạnh $\ge 70\%$.



---



## 🛑 0.1. DANH MỤC 6 CƠ CHẾ ĐÃ BỊ ĐÀO THẢI VĨNH VIỄN (PURGED ANTI-PATTERNS)

*CẤM BẬT LẠI HOẶC TÁI ĐỀ XUẤT 6 CƠ CHẾ ĐÃ CHỨNG MINH GÂY THIỆT HẠI NẶNG NÀY:*

1. **CẮT THEO THỜI GIAN MÙ QUÁNG (`doa_15m`, `doa_25m`, `doa_35m`, `idle_120m`):** Đã xóa sổ vĩnh viễn (gây lỗ -3.63 USDT, cắt đúng đáy 87.5%). Thay bằng Mode 7 Telemetry Gate (xả khi volume dump $\ge 1.6x$).

2. **KHÓA HÒA VỐN NON TRƯỚC TP1 (dưới +0.65% MFE hoặc dưới 4.5 phút đầu):** Làm 82% lệnh bị quét văng siêu sóng. Thay bằng Tam Tầng Bảo Vệ Vốn V3.0 (Cushion SL -0.25% tại MFE +0.80%, Hard BE +0.22% tại MFE +1.15%).

3. **DE-RISKING SỚM KHÔNG LỌC THỜI GIAN (0.40 ATR):** Cắt non ở râu giật 12s đầu. Thay bằng 0.65 ATR + ép giữ $\ge 1.0$ phút.

4. **CHOP SHIELD VÔ HẠN (ATR BTC $\ge 1.2\%$ trên 15M):** Khóa cứng Altcoin suốt 3 tiếng. Thay bằng ADX/ATR kèm giãn cách 120s.

5. **ĐẨY `Signal.HOLD` VÀO `by_strategy`:** Kéo tụt 31% điểm raw_score của phe đa số. HOLD chỉ làm Veto độc lập.

6. **BỎ RƠI SIÊU SÓNG BẰNG FAST-SKIP PRE-LLM:** Bỏ rơi coin tăng dựng đứng. Whale Pump Storm được miễn trừ Fast-Skip để mở Pha 1.



---



## 🛑 0.2. GIAO THỨC BÁO ĐỘNG ĐỎ KHI CHUỖI THUA LIÊN TIẾP (CONSECUTIVE LOSS FORENSIC GATE)

1. **Quy tắc kích hoạt:** Khi hệ thống ghi nhận >= 2 lệnh thua liên tiếp trên Live:

   - NGHIÊM CẤM coi đây là "nhiễu ngẫu nhiên". BẮT BUỘC coi đây là dấu hiệu tiềm ẩn LỖI HỆ THỐNG / LỖI LOGIC NGẦM (Semantic Bug).

   - TỰ ĐỘNG KÍCH HOẠT quy trình Pháp y 4 Tầng: (1) Nguồn tín hiệu M1/15M -> (2) Phán đoán của LLM/AI -> (3) Bộ lọc Aggregator -> (4) Quá trình siết SL/thoát lệnh.

   - BẮT BUỘC rà soát toàn diện code, chạy mô phỏng chuẩn quỹ đối chứng trước khi đưa ra bất kỳ kết luận hay can thiệp nào.



---



## 🔬 0.3. TIÊU CHUẨN MÔ PHỎNG CHUẨN QUỸ ĐỊNH LƯỢNG (INSTITUTIONAL REPLAY & PRE-PROPOSAL REGRESSION STANDARD)

1. **BẮT BUỘC MÔ PHỎNG TOÀN BỘ LỊCH SỬ TRƯỚC MỌI ĐỀ XUẤT (Pre-Proposal Full Regression Simulation):**
   - TUYỆT ĐỐI CẤM tự ý đề xuất hoặc áp dụng bất kỳ thay đổi nào vào bộ quy tắc/tín hiệu khi **CHƯA CHẠY MÔ PHỎNG HỒI QUY ĐỐI SOÁT TRÊN TOÀN BỘ DỮ LIỆU LỊCH SỬ** (`trade_bot.db` và log PC2) qua `tools/true_signal_simulator.py` hoặc `tools/full_spectrum_impact_simulator.py`.
   - BẮT BUỘC phải đo lường chính xác **Hiệu ứng Lan tỏa (Side-effect / Ripple Effect)** lên các vị thế lịch sử cũ:
     - Thay đổi này sẽ làm LỜI THÊM bao nhiêu $ trên các vị thế tương tự?
     - Có làm mất (hoặc đảo chiều sai) các lệnh vốn dĩ đang THẮNG trong lịch sử không?
     - Tác động chéo giữa 3 lớp tài sản (Major Crypto, TradFi Cổ phiếu Mỹ, Altcoins) ra sao?
   - Chỉ được phép đề xuất thay đổi khi kết quả mô phỏng định lượng chứng minh: **Tổng Net PnL tăng lên VÀ không làm suy giảm tỷ lệ thắng (Win Rate) của các cụm chiến lược dương khác!**

2. **Cỗ máy Event-Driven Replay chuẩn quỹ BẮT BUỘC phải bao gồm:**
   - Dữ liệu nến M1/Tick, đo lường chính xác đường cong MFE/MAE thực tế.
   - Bóc tách nhân tố dẫn dắt vĩ mô: BTC Dominance, ATR BTC và hệ số Beta đối với Altcoin; QQQ/SPY, VIX và Giờ mở phiên Mỹ đối với Cổ phiếu TradFi.
   - Tái lập đầy đủ chi phí: Phí Maker/Taker, trượt giá (slippage), nấc cắt giảm tải 50% và Cushion SL.

---

## 💡 0.4. QUY TRÌNH PHÁP Y PHÂN LOẠI 6 NHÓM TÍN HIỆU THUA & MA TRẬN QUYẾT ĐỊNH (6-TIER LOSS FORENSICS & SMART DECISION MATRIX)

Khi người dùng yêu cầu phân tích một lệnh lỗ, AI BẮT BUỘC phải điều tra sâu 4 tầng và phân loại lệnh đó vào chính xác 1 trong 6 nhóm định lượng để đưa ra hành động chuẩn xác:

1. **🔄 Nhóm 1: Có thể Lật Ngược (Smart Inversion Candidates):**
   - *Đặc điểm:* Lệnh vào sai hướng khi cá mập đang bơm/xả thác đổ một chiều rõ ràng (ví dụ: Ép Short cản tàu khi JEV 4H đang BUY mạnh >= 70% và ADX >= 30).
   - *Hành động:* Lập phương án LẬT NGƯỢC (Invert) đi thuận theo cá mập (chuyển Short cản tàu thành Whale Momentum Ride BUY). Báo cáo rõ ràng cả 2 kịch bản: PnL khi Veto (0$) vs PnL khi Lật Ngược (+).

2. **📈 Nhóm 2: Vi phạm Xu Hướng Vĩ Mô (MTF Trend Violation):**
   - *Đặc điểm:* Lệnh vào ngược xu hướng khung lớn 4H/1H khi cấu trúc chưa hề có dấu hiệu đảo chiều hay kiệt sức.
   - *Hành động:* Khôi phục và siết chặt rào chắn `JEV MTF TREND SHIELD`, cấm bypass override khi thiếu râu xả đỉnh vật lý >= 35%.

3. **⏸️ Nhóm 3: Nên Đứng Ngoài (Veto / Stand Aside - Zero Edge):**
   - *Đặc điểm:* Thị trường sideway tích lũy nén biên độ hẹp (Chop/Consolidation), thanh khoản cạn kiệt, bẫy giá giả mạo cả 2 đầu. Lật ngược hay theo xu hướng đều bị quét râu Stop-loss (Edge ~ 0).
   - *Hành động:* ĐỨNG NGOÀI TUYỆT ĐỐI (Veto = 0$). Thà mất cơ hội còn hơn mất vốn.

4. **⚡ Nhóm 4: Phân tích Yếu / Tín hiệu Suy Kiệt Sớm (Weak Signal / Early Exhaustion):**
   - *Đặc điểm:* Tín hiệu ban đầu yếu hoặc dòng tiền đột ngột quay xe ngược lại sau 2 - 8 phút mở lệnh.
   - *Hành động:* Kích hoạt cơ chế Phá khóa Grace Period / Cứu hộ Cá mập (Whale Anchor) thoát hiểm khẩn cấp ở mức lỗ nhỏ (-0.3% -> -0.5%), triệt tiêu nguy cơ dính full SL.

5. **🐛 Nhóm 5: Lỗi Code / Lỗi Logic Ngầm (Semantic & Runtime Bugs):**
   - *Đặc điểm:* Tín hiệu thị trường phân tích đúng (giá chạy lãi MFE dương lớn >= +0.8%) nhưng bị lỗ do lỗi code: biến chưa khai báo (NameError), kẹt luồng, lệch tham số, crash module trailing stop hoặc đứt gãy kết nối đồng bộ SL/TP sàn.
   - *Hành động:* Pháp y vị trí dòng code, sửa dứt điểm lỗi logic ngầm, kiểm thử AST và Hard Constraints Gate 100%. Tuyệt đối KHÔNG đổ lỗi cho tín hiệu thị trường!

6. **🎲 Nhóm 6: Nhiễu Ngẫu Nhiên thuộc Cụm Chiến Thuật Sinh Lời (Statistical Noise of Net-Positive Cluster):**
   - *Đặc điểm:* Lệnh thua là chi phí rủi ro ngẫu nhiên bình thường của một chiến thuật có kỳ vọng toán học dương (Ví dụ: Chiến thuật Fading Short có Win Rate 54.7% và mang lại lợi nhuận ròng +4.7862$ qua 107 lệnh lịch sử; lệnh thua đơn lẻ chỉ là False Breakout ngẫu nhiên).
   - *Hành động:* **TUYỆT ĐỐI KHÔNG TÙY TIỆN XÓA BỎ HOẶC ĐẢO NGƯỢC CHIẾN THUẬT** chỉ vì 1 vài lệnh thua ngẫu nhiên này, tránh phá hủy cụm chiến lược đang đóng góp lợi nhuận ròng dương cho danh mục!


---

## ⚖️ 0.5. QUY CHUẨN TỔNG KẾT, CHẤM ĐIỂM & GIAO THỨC DỌN RÁC (SESSION TRUST AUDIT & WORKSPACE PURGE)

1. **Quy tắc bắt buộc khi Chấm điểm / Tổng kết phiên:** Khi người dùng yêu cầu "chấm điểm", "tổng kết", hoặc kết thúc phiên, AI bắt buộc phải:

   - **Tự tổng kết trung thực:** Bóc tách các lỗi phát sinh/ngầm trong phiên (không che giấu, không báo cáo sớm khi chưa đọc live runtime log).

   - **Chấm điểm khách quan:** Theo Rubric 100 tại `docs/AI_TRUST_SCORECARD.md` và cập nhật tiến trình đến ngưỡng >= 95%.

   - **TỰ ĐỘNG THỰC HIỆN GIAO THỨC DỌN RÁC TRONG NGÀY (`tools/clean_workspace.py`):**
     * Tự động quét và xóa sạch 100% các script kiểm thử tạm thời trong `d:\TRADE\scratch/`, các file nháp, file dump tạm (`.bak`, `.tmp`, dump db/log lẻ tẻ) trên cả PC1 và PC2.
     * Bảo đảm không gian làm việc luôn tinh gọn 100%, CHỈ CÒN LẠI các file mã nguồn và tài liệu SSOT chính thức được liệt kê trong `docs/FEATURE_MAP.md`.
     * Tác dụng tối thượng: Giúp người dùng nhìn vào cây thư mục là phân biệt được ngay code chạy thật, TUYỆT ĐỐI KHÔNG để lẫn lộn giữa script kiểm thử và code vận hành khiến người dùng lo sợ xóa nhầm code bot!

2. **CẢNH BÁO ĐỎ VỀ CHỈ SỐ TIN CẬY (AI TRUST: 30% — VÙNG KÉM HIỆU QUẢ, ĐANG BỊ GIÁM SÁT NGHIÊM NGẶT):**
   - AI đã quá nhiều lần tự khẳng định "hết lỗi / 100 điểm" nhưng khi người dùng treo máy trên PC2 thì vẫn phát sinh lỗi nghiêm trọng.
   - **BẮT BUỘC CHO MỌI PHIÊN MỚI:** AI phải xuất phát từ tâm thế mình đang kém hiệu quả, chưa đủ tin tưởng và chưa thể buông tay.
   - **LUÔN PHẢI KIỂM THỬ LẶP ĐI LẶP LẠI (ITERATIVE STRESS TESTING):** Cấm kết luận dựa trên lý thuyết hay script chạy thử 1 lần. Bắt buộc đối soát chéo trên log runtime thực tế, database, và chạy mô phỏng đo lường hiệu ứng lan tỏa (Ripple Effect) trước khi kết luận!



---


## 🏛️ 1. KIẾN TRÚC 2 MÁY TÍNH & MA TRẬN 3 LỚP TÀI SẢN

- **💻 PC1 (Máy Phát Triển - Dev Machine):** `d:\TRADE` (Python 3.14.7 64-bit venv, Antigravity IDE).

- **🖥️ PC2 (Máy Thử Nghiệm 24/7 - Live Daemon):** `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` (Binance Futures Live, Equity ~103.49 USDT, Ollama `qwen2.5:7b`).

- **Ma trận 3 Lớp Tài Sản (Three-Tier Asset Matrix):**

  1. **Major Crypto (`BTC`, `ETH`, `SOL`):** Thanh khoản dày, ATR 0.4% - 0.9%, không bị chặn bởi Weekend Shield.

  2. **TradFi Cổ Phiếu Mỹ (`NVDA`, `TSLA`, `MRVL`, `TQQQ`):** Đòn bẩy $\le 4x$, trần ký quỹ 20% NAV, đóng trước thứ 7 qua Weekend Shield, SL ngắn bám sát, cấm nới rộng.

  3. **Crypto Altcoins (`MOVR`, `WAL`, `PEPE`, `SKYAI`):** ATR biến động lớn (1.5% - 4.5%), cần vùng đệm Stop-Loss thích ứng theo ATR, cooldown 180m khi đóng lỗ.

  *⚠️ NGUYÊN TẮC BẮT BUỘC: Tuyệt đối không lấy kết quả của 1 coin Altcoin đơn lẻ để tự ý sửa đổi SL/TP toàn sàn khi chưa chạy mô phỏng đối chứng trên cả 3 lớp tài sản!*



---



## 🧭 2. QUY CHUẨN 3 PHIÊN CHAT MỚI TRÊN ANTIGRAVITY

*Khi người dùng mở một phiên chat mới, chỉ cần gõ tiền tố tương ứng:*



### 🟢 1. PHIÊN `[OPS]` — GIÁM SÁT THỰC CHIẾN HẰNG NGÀY

- **Nhiệm vụ:** Điểm danh sáng, check số dư, PnL ngày, đối soát vị thế mở, kiểm tra lệnh SL/TP sàn.

- **Lệnh mở màn:** `"Chạy kiểm toán ngày PC2"` (hoặc `"audit"`, hoặc chạy `CHECK_HE_THONG.bat`).

- **Hành động của AI:** Tự động chạy `python tools/daily_auditor.py`, đọc database PC2 qua LAN, chấm điểm Rubric 100. Tuyệt đối không chỉnh sửa code trong phiên này.



### 🔬 2. PHIÊN `[QUANT]` — PHÒNG THÍ NGHIỆM & MÔ PHỎNG TÍN HIỆU

- **Nhiệm vụ:** Phân tích pháp y các lệnh vừa đóng, giải phẫu nguyên nhân nến quét SL, chạy mô phỏng tái lập.

- **Lệnh mở màn:** `"Pháp y lệnh [Tên coin] và chạy true_signal_simulator đối soát."`

- **Hành động của AI:** Chạy `python tools/true_signal_simulator.py` trên các cụm tín hiệu log PC2, phân tích trên 3 lớp tài sản trước khi đưa ra bất kỳ kiến nghị thay đổi nào.



### 🛠️ 3. PHIÊN `[DEV]` — XƯỞNG SỬA CODE & NÂNG CẤP WEB

- **Nhiệm vụ:** Sửa lỗi logic ngầm, tối ưu hóa giao diện Web Dashboard, nâng cấp cơ chế chốt lời/cắt lỗ.

- **Lệnh mở màn:** `"Nâng cấp [Tính năng X]. Kiểm tra Hard Gate rồi deploy sang PC2."`

- **Hành động của AI:** Tham chiếu `docs/FEATURE_MAP.md`, sửa code, chạy `python tools/hard_constraints_gate.py` (vượt qua 100%), chạy `python deploy_web_client.py` (đồng bộ LAN PC2 và đẩy Git Cloudflare).



---



## 🛡️ 3. RÀO CHẮN CỨNG BẰNG CODE (HARD CONSTRAINTS GATE)

*Được thực thi tự động qua `tools/hard_constraints_gate.py` trước mỗi lần deploy:*

1. **Rào chắn 1:** Cấm bật lại `time_based_exits` trong `config/settings.yaml`.

2. **Rào chắn 2:** Cấm `pop('jev_agent')` thiếu khiên `JEV MTF TREND SHIELD` trong `ai/signal_aggregator.py`.

3. **Rào chắn 3:** Bảo đảm Stop-Loss luôn nằm trong khung an toàn định lượng `[1.0%, 3.5%]`.

4. **Rào chắn 4:** Endpoint `/api/stop` và `/api/pause` luôn trả về HTTP 200 idempotent, cấm báo lỗi `Bot chưa chạy`.

5. **Rào chắn 5:** `cloud_sync.py` bắt buộc có bộ đệm cache bản quyền 60s và gửi ACK tức thì cho Web.

6. **Rào chắn 6:** Cấm bypass MTF Trend Veto khi không có Whale Waterfall Breakdown trong `ai/signal_aggregator.py`.

7. **Rào chắn 7:** Altcoin biến động cao phải có biên độ Stop-Loss thích ứng ATR lên đến 3.5% trong `core/bot.py`.

8. **Rào chắn 8:** Cushion SL phải được bảo vệ bởi bộ lọc thời gian held_minutes >= 3.0 trong `core/bot.py`.

9. **Rào chắn 9:** Quét cú pháp AST chống biến chưa định nghĩa (NameError runtime) trong `tools/hard_constraints_gate.py`.



---



## 📚 4. BẢN ĐỒ TÀI LIỆU HỆ THỐNG

- **Bản đồ tính năng & 100 tệp code:** [`docs/FEATURE_MAP.md`](file:///d:/TRADE/docs/FEATURE_MAP.md)

- **Cẩm nang tác chiến hằng ngày:** [`docs/DAILY_PLAYBOOK.md`](file:///d:/TRADE/docs/DAILY_PLAYBOOK.md)

- **Kho lưu trữ 108 bài học lịch sử đầy đủ:** [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md)

