@echo off
setlocal
title TRADEMATRIX CLIENT v2.0 - Installer
cd /d "%~dp0"

echo.
echo  TRADEMATRIX CLIENT v2.0 - CAI DAT MOI TRUONG
echo  ==============================================
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Khong tim thay Python. Cai Python 3.11 tro len va chon Add Python to PATH.
    echo Tai: https://www.python.org/downloads/windows/
    pause
    exit /b 1
)

python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) and sys.maxsize > 2**32 else 1)"
if errorlevel 1 (
    echo [ERROR] Can Python 64-bit phien ban 3.11 tro len.
    python --version
    pause
    exit /b 1
)

echo [OK] Python du dieu kien:
python --version
echo.

if not exist "venv\Scripts\python.exe" (
    echo Dang tao virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Khong tao duoc venv. Kiem tra quyen ghi va ban cai Python.
        pause
        exit /b 1
    )
) else (
    echo [OK] Tim thay virtual environment hien co.
)

"venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) and sys.maxsize > 2**32 else 1)"
if errorlevel 1 (
    echo [ERROR] Venv cu khong dung Python 64-bit 3.11 tro len.
    echo Hay doi ten hoac xoa thu muc venv roi chay lai installer.
    pause
    exit /b 1
)

echo.
echo Dang nang cap pip...
"venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (
    echo [ERROR] Nang cap pip that bai. Kiem tra Internet va thu chay lai.
    pause
    exit /b 1
)

echo.
echo Dang cai dat thu vien tu requirements.txt...
"venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Cai thu vien that bai. Bot chua san sang chay.
    pause
    exit /b 1
)

echo.
echo Dang kiem tra cac goi Python...
"venv\Scripts\python.exe" -m pip check
if errorlevel 1 (
    echo [ERROR] Phat hien xung dot goi Python. Kiem tra log pip o phia tren.
    pause
    exit /b 1
)

if not exist "data" mkdir data
if not exist "data\historical" mkdir "data\historical"
if not exist "data\models" mkdir "data\models"
if not exist "logs" mkdir logs

if not exist ".env" (
    echo [WARNING] Chua co file .env. Dang tao file .env mau...
    (
        echo BINANCE_API_KEY=
        echo BINANCE_API_SECRET=
        echo TELEGRAM_BOT_TOKEN=
        echo TELEGRAM_CHAT_ID=
    ) > .env
    echo [INFO] Hay mo file .env de dien API key truoc khi bat LIVE.
) else (
    echo [OK] Tim thay file cau hinh .env.
)

echo.
echo =======================================================
echo KIEM TRA OLLAMA VA QUAN LY MODEL AI CHUAN CHO BOT
echo =======================================================
where ollama >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Chua cai dat Ollama.
    echo Hay cai Ollama tai https://ollama.com/download/windows roi chay lai install.bat.
    goto :ollama_done
)

echo [INFO] Dang kiem tra thu vien model trong Ollama...

REM 1. TU DONG XOA CAC MODEL CU / KHONG DUNG DE GIAI PHONG O DIA VA TRANH LON XON
for %%M in (qwen3:14b qwen2.5:14b deepseek-r1:14b llama3.2:3b llama3:latest) do (
    ollama list | findstr /i "%%M" >nul 2>&1
    if not errorlevel 1 (
        echo [XOA] Phat hien model %%M khong dung. Dang xoa de nhe o dia...
        ollama rm %%M
        echo [OK] Da xoa model %%M thanh cong!
    )
)

REM 2. KIEM TRA VA TAI MODEL CHINH DUY NHAT: qwen2.5:7b [Diem ngot chuan nhat cho card GTX 1060 6GB]
ollama list | findstr /i "qwen2.5:7b" >nul 2>&1
if errorlevel 1 (
    echo [TAI VE] Chua co model chinh qwen2.5:7b [4.7 GB]. Dang tu dong tai ve...
    ollama pull qwen2.5:7b
    if errorlevel 1 (
        echo [WARNING] Khong tai duoc qwen2.5:7b. Kiem tra ket noi Internet va thu lai.
    ) else (
        echo [OK] Da tai thanh cong model duy nhat qwen2.5:7b.
    )
) else (
    echo [OK] Model chuan duy nhat qwen2.5:7b [4.7 GB] da co san va san sang su dung.
)

:ollama_done

echo.
echo  =====================
echo  CAI DAT GOI PYTHON HOAN TAT
echo  =====================
echo  Chay START.bat de mo dashboard.
echo  Can may tinh co Internet va khong vao che do Sleep de treo lien tuc.
echo  Sau khi mo dashboard, mac dinh hay kiem tra DEMO truoc.
echo  Khong chuyen LIVE neu chua chu dong chap nhan giao dich bang tien that.
echo.
pause
exit /b 0
