@echo off
chcp 65001 > nul
echo ======================================================================
echo 🛡️  TRADEMATRIX DEEP SYSTEMIC & CROSS-TIER INTEGRITY AUDITOR
echo ======================================================================
if exist venv\Scripts\python.exe (
    venv\Scripts\python.exe tools\audit_system_integrity.py
) else (
    python tools\audit_system_integrity.py
)
echo.
pause
