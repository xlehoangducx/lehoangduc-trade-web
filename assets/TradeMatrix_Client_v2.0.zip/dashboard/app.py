from flask import Flask, render_template, jsonify, request, Response
import logging
import json
import math
import os
import shutil
import threading
import contextlib
import csv
import io
import ipaddress
from datetime import datetime
from urllib.parse import urlparse

try:
    import yaml
except Exception:  # pragma: no cover - yaml là dependency bắt buộc
    yaml = None

logger = logging.getLogger(__name__)

# Thread lock cho thread-safe access
_bot_lock = threading.Lock()
_bot_thread = None
# Khóa chống chạy 2 chu kỳ phân tích song song (loop chính + /api/run_cycle)
_cycle_lock = threading.Lock()
# Khóa chống chạy song song /api/optimize
_optimize_lock = threading.Lock()


def _as_finite_float(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _is_trusted_local_origin(origin: str) -> bool:
    """Origin có phải máy nội bộ (localhost hoặc IP LAN) hay không.

    Dùng cho CORS: chỉ cho phép chính máy này / mạng LAN nội bộ, chặn mọi website internet.
    """
    if not origin:
        return False
    try:
        host = (urlparse(origin).hostname or '').strip().lower()
    except Exception:
        return False
    if not host:
        return False
    if host in ('localhost', '::1', '127.0.0.1'):
        return True
    if host.endswith('.local'):
        return True
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return False
    return bool(addr.is_loopback or addr.is_private)


def _read_settings_for_write(settings_path):
    """Đọc settings.yaml cho thao tác GHI. Trả (dict, thông điệp lỗi).

    [SỬA LỖI GỐC RỄ - XOÁ SẠCH CẤU HÌNH]
    Trước đây /api/cloud_token đọc file và nuốt MỌI ngoại lệ thành {} rồi ghi đè bằng
    yaml.dump. Chỉ một lần đọc lỗi (file đang bị ghi dở hoặc antivirus khoá) là TOÀN BỘ
    settings.yaml (risk, trading, ai, exchange, quantum_gate, tradfi...) bị xoá sạch,
    chỉ còn lại đúng nhánh cloud. Hậu quả: sau lần khởi động kế tiếp bot chạy bằng
    cấu hình mặc định (risk 0.6%?, max_open_positions mặc định...) và mất hết tinh chỉnh.
    Nay: đọc lỗi thì TỪ CHỐI GHI, tuyệt đối không ghi đè mù.
    """
    try:
        with open(settings_path, 'r', encoding='utf-8') as f:
            loaded = yaml.safe_load(f) if yaml else None
    except FileNotFoundError:
        return {}, None
    except Exception as e:
        return None, (
            'Không đọc được settings.yaml nên TỪ CHỐI ghi để tránh xoá sạch cấu hình: '
            f'{e}'
        )
    if loaded is None:
        return {}, None
    if not isinstance(loaded, dict):
        return None, 'settings.yaml không phải mapping hợp lệ; từ chối ghi để bảo vệ cấu hình.'
    return loaded, None


def _atomic_write_settings(settings_path, settings):
    """Ghi settings.yaml NGUYÊN TỬ (tmp + os.replace) và giữ bản .bak."""
    from core.config_utils import REQUIRED_SETTINGS_SECTIONS, atomic_write_text

    if not isinstance(settings, dict):
        raise ValueError('settings không phải mapping; huỷ ghi để bảo vệ cấu hình.')
    missing_sections = [key for key in REQUIRED_SETTINGS_SECTIONS if key not in settings]
    if missing_sections:
        raise ValueError(f'Refuse to write incomplete settings.yaml; missing={missing_sections}')
    payload = yaml.dump(settings, default_flow_style=False, allow_unicode=True, sort_keys=False)
    if not payload or not payload.strip():
        raise ValueError('Nội dung settings rỗng; huỷ ghi để bảo vệ cấu hình.')
    return atomic_write_text(
        settings_path,
        payload,
        create_backup=True,
        verify_yaml=True,
        required_sections=REQUIRED_SETTINGS_SECTIONS,
    )


def _closed_position_outcomes(trades, mode, quote_asset, market_type='futures'):
    """Count completed position cycles, not individual exchange fills."""
    outcomes = {'wins': 0, 'losses': 0, 'breakeven': 0}
    completed_order_ids = set()

    def record(net_pnl):
        if net_pnl > 1e-8:
            outcomes['wins'] += 1
        elif net_pnl < -1e-8:
            outcomes['losses'] += 1
        else:
            outcomes['breakeven'] += 1

    if mode == 'live':
        fills = [trade for trade in trades if trade.get('exchange_trade_id') is not None]
        fills.sort(key=lambda trade: (
            _as_finite_float(trade.get('timestamp')),
            _as_finite_float(trade.get('id')),
        ))
        positions = {}
        for trade in fills:
            symbol = str(trade.get('symbol') or '').split(':')[0].strip()
            side = str(trade.get('side') or '').strip().lower()
            position_side = str(trade.get('position_side') or 'BOTH').strip().upper()
            quantity = abs(_as_finite_float(trade.get('amount')))
            if not symbol or side not in ('buy', 'sell') or quantity <= 0:
                continue

            # Represent BOTH positions as signed quantity. In hedge mode,
            # LONG and SHORT each use positive quantity in their own direction.
            direction = 1.0 if side == 'buy' else -1.0
            if position_side == 'SHORT':
                direction *= -1.0
            delta = direction * quantity
            key = (symbol, position_side)
            state = positions.get(key)
            gross_pnl = _as_finite_float(
                trade.get('realized_pnl') if trade.get('realized_pnl') is not None
                else trade.get('pnl')
            )
            fee = _as_finite_float(trade.get('fee'))
            fee_asset = str(trade.get('commission_asset') or quote_asset).upper()
            quote_fee = fee if fee_asset == str(quote_asset).upper() else 0.0
            is_spot = str(market_type or '').lower() == 'spot'
            price = _as_finite_float(trade.get('price'))
            if is_spot:
                gross_pnl = 0.0

            if state is None or abs(state['quantity']) <= 1e-12:
                # A nonzero realized PnL with no observed opening fill means
                # the local history starts mid-position; don't guess its result.
                if (is_spot and delta < 0) or (not is_spot and abs(gross_pnl) > 1e-8):
                    continue
                positions[key] = {
                    'quantity': delta,
                    'gross_pnl': gross_pnl,
                    'fee': quote_fee,
                    'cost': price * quantity if is_spot else 0.0,
                }
                continue

            current = state['quantity']
            if current * delta > 0:
                state['quantity'] = current + delta
                state['gross_pnl'] += gross_pnl
                state['fee'] += quote_fee
                if is_spot:
                    state['cost'] += price * quantity
                continue

            # The fill reduces or closes the current position. Assign its fee
            # to the closed size; if it reverses direction, the remainder opens
            # a new cycle and carries its proportional entry fee.
            closed_quantity = min(abs(current), abs(delta))
            close_ratio = closed_quantity / quantity
            if is_spot:
                average_entry = state['cost'] / abs(current) if abs(current) > 0 else 0.0
                state['gross_pnl'] += (price - average_entry) * closed_quantity
                state['cost'] = max(0.0, state['cost'] - average_entry * closed_quantity)
            else:
                state['gross_pnl'] += gross_pnl
            state['fee'] += quote_fee * close_ratio
            remaining_quantity = abs(delta) - closed_quantity
            new_quantity = current + delta
            if closed_quantity >= abs(current) - 1e-12:
                record(state['gross_pnl'] - state['fee'])
                if trade.get('order_id') is not None:
                    completed_order_ids.add(str(trade.get('order_id')))
                if remaining_quantity > 1e-12:
                    positions[key] = {
                        'quantity': math.copysign(remaining_quantity, delta),
                        'gross_pnl': 0.0,
                        'fee': quote_fee * (1.0 - close_ratio),
                        'cost': price * remaining_quantity if is_spot else 0.0,
                    }
                else:
                    positions.pop(key, None)
            else:
                state['quantity'] = new_quantity

    # Demo close summaries, and live closes without a matching exchange fill,
    # already store net position PnL. Matching live summaries are filtered by
    # get_trades because the fill replay above accounts for those orders.
    for trade in trades:
        if (trade.get('exchange_trade_id') is None
                and str(trade.get('status') or '').lower() == 'closed'
                and trade.get('pnl') is not None):
            if (mode == 'live' and trade.get('order_id') is not None
                    and str(trade.get('order_id')) in completed_order_ids):
                continue
            # [BOM #135 FIX]: Đọc cùng logic lọc entry row không close_reason cho cả DEMO lẫn LIVE
            if abs(_as_finite_float(trade.get('pnl'))) <= 1e-12 and not str(trade.get('close_reason') or '').strip():
                continue
            record(_as_finite_float(trade.get('pnl')))

    outcomes['closed_trade_count'] = sum(outcomes.values())
    return outcomes


def create_app(bot=None):
    app = Flask(__name__)
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.jinja_env.auto_reload = True
    app.bot = bot
    app._bot_starting = False
    
    @app.before_request
    def enforce_local_origin_csrf():
        # [BOM #126C FIX]: Chặn Cross-Origin simple POST/PUT/DELETE/PATCH (CSRF) từ trang web lạ trước khi thực thi route!
        if request.method in ('POST', 'PUT', 'DELETE', 'PATCH') and request.path.startswith('/api/'):
            origin = request.headers.get('Origin', '').strip()
            if origin and not _is_trusted_local_origin(origin):
                return jsonify({'success': False, 'error': 'Untrusted cross-origin request rejected'}), 403

    @app.after_request
    def add_cors_headers(response):
        # [SỬA LỖI GỐC RỄ - CORS MỞ TOANG TOÀN BỘ API NỘI BỘ]
        # Trước đây trả `Access-Control-Allow-Origin: *` cho MỌI route, kể cả POST
        # /api/stop, /api/start, /api/run_cycle, /api/cloud_token, /api/set_balance,
        # lại còn bật `Access-Control-Allow-Private-Network: true`. Nghĩa là BẤT KỲ
        # website nào người dùng mở cũng đọc được /api/config, /api/status, lấy user
        # token, đổi API key hoặc dừng bot đang gồng lệnh thật (CSRF + lộ dữ liệu).
        # Nay chỉ cấp CORS cho origin cùng máy / LAN nội bộ. Request same-origin của
        # chính dashboard không cần header này nên không bị ảnh hưởng.
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS, PUT, DELETE'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
        origin = request.headers.get('Origin', '')
        if origin and _is_trusted_local_origin(origin):
            response.headers['Access-Control-Allow-Origin'] = origin
            response.headers['Vary'] = 'Origin'
            response.headers['Access-Control-Allow-Private-Network'] = 'true'
        return response

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/so-do-dong')
    def so_do_dong():
        return render_template('pipeline_map.html')

    @app.route('/api/pipeline_live')
    def api_pipeline_live():
        try:
            from core.vietnamese_weapon_arsenal import build_live_pipeline_snapshot
            return jsonify(build_live_pipeline_snapshot(bot_instance=app.bot))
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/status')
    def api_status():
        if app.bot:
            st = app.bot.get_status()
            if isinstance(st, dict) and 'exchange' not in st:
                st['exchange'] = (app.bot.config.get('exchange') or {}).get('name', 'binance')
            try:
                from core.gate_telemetry import get_top_radar_candidates
                st['radar_candidates'] = get_top_radar_candidates(limit=6)
            except Exception:
                st['radar_candidates'] = []
            try:
                from core.quant_evolution_engine import load_position_tuning
                _pt_cls = (load_position_tuning().get('classes') or {})
                _alt_cfg = _pt_cls.get('ALTCOIN') or {}
                _en_alt_tps = [float(x.get('pct') or 1.35) for x in (_alt_cfg.get('tp_stages') or []) if x.get('enabled', True)]
                st['base_risk_pct'] = float(_alt_cfg.get('base_risk_pct') or 0.35)
                st['altcoin_max_leverage'] = int(_alt_cfg.get('max_leverage') or 5)
                st['altcoin_max_notional_pct'] = float(_alt_cfg.get('max_notional_pct') or 15.0)
                st['altcoin_sl_min_pct'] = float(_alt_cfg.get('sl_min_pct') or 1.5)
                st['altcoin_sl_max_pct'] = float(_alt_cfg.get('sl_max_pct') or 3.5)
                st['altcoin_sl_default_pct'] = float(_alt_cfg.get('sl_default_pct') or 2.5)
                st['altcoin_tp1_take_pct'] = int(50 if _alt_cfg.get('tp1_take_pct') is None else _alt_cfg.get('tp1_take_pct'))
                st['altcoin_tp1_pct'] = float(_en_alt_tps[0]) if _en_alt_tps else 1.35
                st['altcoin_tp2_pct'] = float(_en_alt_tps[-1]) if len(_en_alt_tps) >= 2 else 2.40
                st['altcoin_tp_enabled_count'] = len(_en_alt_tps)
            except Exception:
                st['base_risk_pct'] = 0.35
                st['altcoin_max_leverage'] = 5
                st['altcoin_max_notional_pct'] = 15.0
                st['altcoin_sl_min_pct'] = 1.5
                st['altcoin_sl_max_pct'] = 3.5
                st['altcoin_sl_default_pct'] = 2.5
                st['altcoin_tp1_take_pct'] = 50
                st['altcoin_tp1_pct'] = 1.35
                st['altcoin_tp2_pct'] = 2.40
                st['altcoin_tp_enabled_count'] = 2
            return jsonify(st)
        return jsonify({'error': 'Bot not initialized'}), 503

    @app.route('/api/radar')
    def api_radar():
        try:
            from core.gate_telemetry import get_top_radar_candidates
            return jsonify(get_top_radar_candidates(limit=6))
        except Exception as e:
            return jsonify({'error': str(e), 'candidates': []}), 500
    
    @app.route('/api/trades')
    def api_trades():
        if app.bot and app.bot.db:
            limit = max(1, min(request.args.get('limit', 100, type=int), 500))
            offset = max(0, min(request.args.get('offset', 0, type=int), 1_000_000))
            trades = app.bot.db.get_trades(mode=app.bot.mode, limit=limit, offset=offset)
            return jsonify(trades)
        return jsonify([])

    @app.route('/api/trades/export.csv')
    def api_trades_export():
        if not app.bot or not app.bot.db:
            return jsonify({'error': 'Bot not initialized'}), 503
        stream = io.StringIO(newline='')
        writer = csv.writer(stream)
        columns = [
            'timestamp', 'symbol', 'side', 'type', 'status', 'price', 'amount', 'cost',
            'fee', 'commission_asset', 'realized_pnl', 'order_id', 'exchange_trade_id',
            'client_order_id', 'position_side', 'maker', 'strategy', 'raw_json',
        ]
        writer.writerow(columns)
        offset = 0
        while True:
            page = app.bot.db.get_trades(mode=app.bot.mode, limit=1000, offset=offset)
            if not page:
                break
            for trade in page:
                writer.writerow([trade.get(column) for column in columns])
            offset += len(page)
            if len(page) < 1000:
                break
        return Response(
            '\ufeff' + stream.getvalue(),
            mimetype='text/csv; charset=utf-8',
            headers={'Content-Disposition': f'attachment; filename=trade-history-{app.bot.mode}.csv'},
        )
    
    @app.route('/api/trades/sync', methods=['POST'])
    def api_trades_sync():
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot chưa khởi tạo'}), 503
        sync_lock = getattr(app.bot, '_history_sync_lock', None)
        if sync_lock is not None and sync_lock.locked():
            return jsonify({
                'success': False,
                'error': 'Đang có tiến trình đồng bộ Binance chạy nền, vui lòng đợi vài giây rồi thử lại.',
            }), 409
        try:
            synced = 0
            if hasattr(app.bot, '_sync_exchange_trade_history'):
                try:
                    res = app.bot._sync_exchange_trade_history(force_discovery=True)
                except TypeError:
                    res = app.bot._sync_exchange_trade_history()
                synced = int(res or 0)
            return jsonify({
                'success': True,
                'synced': synced,
                'message': f'Đã đồng bộ thành công từ Binance API ({synced} fills mới)'
            })
        except Exception as e:
            logger.error(f'Lỗi đồng bộ giao dịch Binance: {e}')
            return jsonify({'success': False, 'error': str(e)}), 500

    import time as _perf_time
    _perf_cache = {'key': None, 'ts': 0.0, 'data': None}
    _perf_cache_lock = threading.Lock()

    @app.route('/api/performance')
    def api_performance():
        if app.bot and app.bot.db:
            try:
                mode_val = app.bot.mode
                wm = None
                if hasattr(app.bot.db, 'get_trade_watermark'):
                    wm = app.bot.db.get_trade_watermark(mode_val)
                cache_key = (id(app.bot.db), mode_val, wm)
                now_mono = _perf_time.monotonic()
                if wm is not None:
                    with _perf_cache_lock:
                        if (
                            _perf_cache.get('key') == cache_key
                            and _perf_cache.get('data') is not None
                            and (now_mono - float(_perf_cache.get('ts', 0.0))) < 8.0
                        ):
                            return jsonify(_perf_cache['data'])

                trades = []
                offset = 0
                while True:
                    page = app.bot.db.get_trades(mode=mode_val, limit=1000, offset=offset)
                    if not page:
                        break
                    trades.extend(page)
                    offset += len(page)
                    if len(page) < 1000:
                        break

                # A local order summary and its later Binance fill rows describe
                # the same order. Count the exchange fills once they are present.
                fill_order_ids = {
                    (str(t.get('symbol') or '').split(':')[0].strip(), str(t.get('order_id')))
                    for t in trades
                    if t.get('exchange_trade_id') is not None and t.get('order_id') is not None
                }
                if mode_val == 'live' and fill_order_ids:
                    trades = [
                        t for t in trades
                        if not (
                            t.get('exchange_trade_id') is None
                            and t.get('order_id') is not None
                            and (str(t.get('symbol') or '').split(':')[0].strip(), str(t.get('order_id'))) in fill_order_ids
                        )
                    ]

                quote = str(app.bot.config.get('trading', {}).get('base_currency', 'USDT') or 'USDT').upper()
                fees_by_asset = {}
                for trade in trades:
                    if trade.get('fee'):
                        asset = str(trade.get('commission_asset') or quote).upper()
                        fees_by_asset[asset] = fees_by_asset.get(asset, 0.0) + float(trade['fee'])
                position_outcomes = _closed_position_outcomes(
                    trades, mode_val, quote,
                    getattr(app.bot, 'market_type', 'futures'),
                )

                now_dt = datetime.now()
                today_start_dt = datetime(now_dt.year, now_dt.month, now_dt.day, 0, 0, 0)
                today_start_ms = int(today_start_dt.timestamp() * 1000)

                total_pnl = 0.0
                today_pnl = 0.0
                today_trades_count = 0
                today_fees = 0.0

                for trade in trades:
                    trade_ts = int(trade.get('timestamp') or 0)
                    fee = float(trade.get('fee') or 0) if str(trade.get('commission_asset') or quote).upper() == quote else 0.0
                    if trade.get('realized_pnl') is not None:
                        row_pnl = float(trade['realized_pnl']) - fee
                    elif trade.get('status') == 'open':
                        row_pnl = -fee
                    else:
                        # Local simulated/summary closing rows already store net PnL.
                        row_pnl = float(trade.get('pnl') or 0)
                    total_pnl += row_pnl

                    if trade_ts >= today_start_ms:
                        today_pnl += row_pnl
                        today_fees += fee
                        today_trades_count += 1

                payload = {
                    'winning_trades': position_outcomes['wins'],
                    'losing_trades': position_outcomes['losses'],
                    'breakeven_trades': position_outcomes['breakeven'],
                    'closed_trade_count': position_outcomes['closed_trade_count'],
                    'total_trades': position_outcomes['closed_trade_count'],
                    'win_rate': (
                        100.0 * position_outcomes['wins']
                        / (position_outcomes['wins'] + position_outcomes['losses'])
                        if position_outcomes['wins'] + position_outcomes['losses'] else None
                    ),
                    'quote_asset': quote,
                    'total_pnl': total_pnl,
                    'total_fees': fees_by_asset.get(quote, 0.0),
                    'fees_by_asset': fees_by_asset,
                    'today_pnl': today_pnl,
                    'today_trades_count': today_trades_count,
                    'today_fees': today_fees,
                }
                if wm is not None:
                    with _perf_cache_lock:
                        _perf_cache['key'] = cache_key
                        _perf_cache['ts'] = now_mono
                        _perf_cache['data'] = payload
                return jsonify(payload)
            except Exception as e:
                logger.error(f'Performance calc error: {e}')
        return jsonify({
            'winning_trades': 0, 'losing_trades': 0, 'breakeven_trades': 0,
            'closed_trade_count': 0, 'win_rate': None, 'total_pnl': 0,
            'total_fees': 0, 'today_pnl': 0, 'today_trades_count': 0, 'today_fees': 0,
        })
    
    @app.route('/api/daily_pnl')
    def api_daily_pnl():
        if app.bot and app.bot.db:
            days = request.args.get('days', 30, type=int)
            days = max(1, min(days, 365))  # Validate range
            quote = app.bot.config.get('trading', {}).get('base_currency', 'USDT')
            return jsonify(app.bot.db.get_daily_pnl(days=days, mode=app.bot.mode, quote_currency=quote))
        return jsonify([])
    
    @app.route('/api/positions')
    def api_positions():
        if app.bot:
            return jsonify(app.bot.get_dashboard_positions())
        return jsonify([])

    @app.route('/api/positions/close', methods=['POST'])
    def api_close_position():
        """Close one displayed position at market and notify the user."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        data = request.get_json(silent=True) or {}
        symbol = data.get('symbol')
        direction = data.get('direction')
        if not isinstance(symbol, str) or not symbol.strip():
            return jsonify({'success': False, 'error': 'Thiếu mã giao dịch.'}), 400
        if direction is not None and (not isinstance(direction, str) or direction.upper().strip() not in ('LONG', 'SHORT')):
            return jsonify({'success': False, 'error': 'Chiều vị thế không hợp lệ.'}), 400
        result = app.bot.close_position_manually(symbol.strip(), direction)
        return jsonify(result), (200 if result.get('success') else 409)
    
    _market_price_cache = {'ts': 0.0, 'data': {}}
    _market_price_cache_lock = threading.Lock()

    @app.route('/api/market')
    def api_market():
        if app.bot and app.bot.exchange:
            pairs = set(app.bot.config.get('trading', {}).get('pairs', ['BTC/USDT', 'ETH/USDT']))
            with app.bot._position_lock:
                open_pairs = {pos['symbol'] for pos in app.bot.open_positions if pos.get('symbol')}
            pairs.update(open_pairs)
            # [BOM #99 + #124A FIX]: Uu tien WS @bookTicker -> scanner ticker cache -> REST chi cho vi the mo!
            ws_mgr = getattr(app.bot, 'ws_manager', None)
            scanner_px = getattr(getattr(app.bot, 'scanner', None), 'last_all_ticker_prices', None) or {}
            prices = {}
            missing_pairs = []
            for p in pairs:
                px_ws = None
                if ws_mgr is not None and hasattr(ws_mgr, 'get_live_book_ticker'):
                    try:
                        bt = ws_mgr.get_live_book_ticker(p, max_age_seconds=15.0)
                        if isinstance(bt, dict):
                            px_candidate = bt.get('mid') or bt.get('last') or bt.get('close')
                            if not px_candidate:
                                _bid = _as_finite_float(bt.get('bid'), 0.0)
                                _ask = _as_finite_float(bt.get('ask'), 0.0)
                                if _bid > 0 and _ask > 0:
                                    px_candidate = (_bid + _ask) / 2.0
                            if px_candidate:
                                px_ws = float(px_candidate)
                    except Exception:
                        px_ws = None
                if px_ws and px_ws > 0:
                    prices[p] = px_ws
                else:
                    clean_p = str(p).split(':')[0].replace('/', '').upper()
                    cached_scan_px = _as_finite_float(scanner_px.get(clean_p) or scanner_px.get(p), 0.0)
                    if cached_scan_px > 0:
                        prices[p] = cached_scan_px
                    elif p in open_pairs:
                        missing_pairs.append(p)
            import time as _time_mkt
            now_m = _time_mkt.time()
            if missing_pairs:
                # [BOM #121K FIX]: Khoa cache + single-flight (chi 1 request goi REST moi 5s, khong giu lock khi goi mang)
                _should_fetch = False
                with _market_price_cache_lock:
                    if (now_m - float(_market_price_cache.get('ts', 0.0))) >= 5.0:
                        _market_price_cache['ts'] = now_m
                        _should_fetch = True
                    _cached_snapshot = dict(_market_price_cache.get('data', {}))
                if _should_fetch:
                    # [BOM #125D FIX]: Bắt ngoại lệ RateLimitExceeded/IP-Ban/Network để /api/market không trả HTTP 500 và giữ nguyên giá WS/scanner!
                    try:
                        fetched = app.bot.exchange.get_live_prices(missing_pairs) or {}
                    except Exception:
                        fetched = {}
                    with _market_price_cache_lock:
                        _merged = dict(_market_price_cache.get('data', {}))
                        _merged.update(fetched)
                        _market_price_cache['data'] = _merged
                    prices.update(fetched)
                    # [BOM #126C FIX]: Khi get_live_prices lỗi hoặc thiếu mã, giữ lại giá từ _cached_snapshot thay vì thả rơi về $0 PnL!
                    for mp in missing_pairs:
                        if mp not in prices and mp in _cached_snapshot:
                            prices[mp] = _cached_snapshot[mp]
                else:
                    for mp in missing_pairs:
                        if mp in _cached_snapshot:
                            prices[mp] = _cached_snapshot[mp]
            return jsonify(prices)
        return jsonify({})
    
    # ===== BOT CONTROL ENDPOINTS =====

    def _preflight_start_and_license_check():
        """[BOM #135 FIX]: Tiền kiểm prepare_to_start() + verify_license_tokens() dùng chung cho /api/start và /api/run_cycle."""
        start_error = app.bot.prepare_to_start()
        if start_error:
            return {'success': False, 'error': start_error}, 409

        try:
            from pathlib import Path
            from cloud_sync import parse_user_tokens, verify_license_tokens

            root_dir = Path(__file__).resolve().parent.parent
            settings_path = root_dir / 'config' / 'settings.yaml'
            cfg = {}
            if settings_path.exists() and yaml is not None:
                with open(settings_path, 'r', encoding='utf-8') as sf:
                    cfg = yaml.safe_load(sf) or {}
            cloud_cfg = (cfg.get('cloud') or {}) if isinstance(cfg, dict) else {}
            if not isinstance(cloud_cfg, dict) or not cloud_cfg:
                cloud_cfg = (getattr(app.bot, 'config', {}) or {}).get('cloud') or {}

            tokens = parse_user_tokens(cloud_cfg.get('user_token', ''))
            if cloud_cfg.get('enabled', True) and tokens:
                project_id = str(cloud_cfg.get('project_id') or 'trade-bot-platform')
                _ttl_raw = cloud_cfg.get('license_cache_ttl_days')
                try:
                    ttl_days = max(0.0, float(7.0 if (_ttl_raw is None or _ttl_raw == '') else _ttl_raw))
                except (TypeError, ValueError):
                    ttl_days = 7.0
                verdict = verify_license_tokens(
                    tokens, project_id=project_id, root_dir=root_dir, ttl_days=ttl_days
                )
                if verdict.get('revoked'):
                    return {'success': False, 'error': f"Bản quyền đã bị thu hồi: {verdict.get('reason', '')}"}, 403
                if verdict.get('explicit_refusal') or not verdict.get('approved'):
                    return {'success': False, 'error': f"Chưa được cấp phép chạy bot: {verdict.get('reason', 'Unlicensed')}"}, 403
        except Exception as le:
            logger.warning(f"Lỗi tiền kiểm bản quyền: {le}")
            return {'success': False, 'error': f'Lỗi kiểm tra bản quyền: {le}'}, 403

        return None, 200
    
    @app.route('/api/start', methods=['POST'])
    def api_start():
        """Khởi chạy bot trading trong background thread (có khóa _bot_lock chống 2 thread song song — BOM #93 FIX)."""
        global _bot_thread
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503

        with _bot_lock:
            if app.bot.is_running or (_bot_thread and _bot_thread.is_alive()):
                return jsonify({'success': True, 'message': 'Bot đã đang chạy.'})
            if getattr(app, '_bot_starting', False):
                return jsonify({'success': True, 'message': 'Bot đang trong quá trình khởi động...'})
            if _cycle_lock.locked():
                return jsonify({
                    'success': False,
                    'error': 'Đang có một chu kỳ phân tích thủ công chạy dở; chờ kết thúc rồi khởi động bot.',
                }), 409
            app._stop_requested = False
            app._bot_starting = True

        try:
            data = request.get_json(silent=True) or {}
            interval = int(data.get('interval', 60))
            if not 1 <= interval <= 86400:
                return jsonify({'success': False, 'error': 'Interval phải từ 1 đến 86400 giây'}), 400

            _pf_err_payload, _pf_err_code = _preflight_start_and_license_check()
            if _pf_err_payload:
                return jsonify(_pf_err_payload), _pf_err_code
            
            def run_bot():
                try:
                    app.bot.start(interval_seconds=interval, preflight_done=True)
                except Exception as e:
                    logger.error(f"Bot thread error: {e}")
            
            with _bot_lock:
                if getattr(app, '_stop_requested', False):
                    app._stop_requested = False
                    return jsonify({
                        'success': True,
                        'message': 'Đã hủy khởi động bot theo yêu cầu dừng trước đó.',
                    })
                if app.bot.is_running or (_bot_thread and _bot_thread.is_alive()):
                    return jsonify({'success': True, 'message': 'Bot đã đang chạy.'})
                if _cycle_lock.locked():
                    return jsonify({
                        'success': False,
                        'error': 'Đang có một chu kỳ phân tích thủ công chạy dở; chờ kết thúc rồi khởi động bot.',
                    }), 409
                _bot_thread = threading.Thread(target=run_bot, daemon=True)
                _bot_thread.start()
            
            return jsonify({'success': True, 'message': f'Bot đã bắt đầu chạy (interval: {interval}s)'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
        finally:
            app._bot_starting = False
    
    @app.route('/api/stop', methods=['POST'])
    def api_stop():
        """Dừng bot trading an toàn."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503

        with _bot_lock:
            _starting = bool(getattr(app, '_bot_starting', False))
            _thread = _bot_thread
            _thread_alive = bool(_thread and _thread.is_alive())
            _running = bool(app.bot.is_running)
            if _starting:
                app._stop_requested = True

        if not _running and not _starting and not _thread_alive:
            return jsonify({
                'success': True,
                'message': 'Bot đã ở trạng thái dừng; vị thế LIVE không bị tự đóng và lệnh bảo vệ Binance vẫn được giữ nếu đã đặt thành công.',
            })

        try:
            app.bot.stop()
            if _thread and _thread.is_alive() and _thread is not threading.current_thread():
                _thread.join(timeout=3.0)
            return jsonify({
                'success': True,
                'message': 'Bot đã dừng; vị thế LIVE không bị tự đóng và lệnh bảo vệ Binance vẫn được giữ nếu đã đặt thành công.',
            })
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @app.route('/api/pause', methods=['POST'])
    def api_pause():
        """Tạm dừng bot (dừng nhưng giữ trạng thái)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503

        with _bot_lock:
            _starting = bool(getattr(app, '_bot_starting', False))
            _thread = _bot_thread
            if _starting:
                app._stop_requested = True

        try:
            app.bot.stop()
            if _thread and _thread.is_alive() and _thread is not threading.current_thread():
                _thread.join(timeout=3.0)
            return jsonify({
                'success': True,
                'message': 'Bot đã dừng; vị thế LIVE không bị tự đóng và lệnh bảo vệ Binance được giữ nguyên nếu đã đặt thành công.',
            })
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
    
    @app.route('/api/run_cycle', methods=['POST'])
    def api_run_cycle():
        """Chạy 1 chu kỳ phân tích thủ công (không cần start liên tục)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503

        # [SỬA LỖI GỐC RỄ - CHẠY CHU KỲ SONG SONG]
        # Trước đây endpoint này gọi thẳng app.bot.run_cycle() không có bất kỳ khóa nào.
        # - Nếu bot đang chạy loop 60s, một cú POST (kể cả từ trang web khác nhờ CORS '*')
        #   sẽ chạy chu kỳ THỨ HAI song song: cả hai cùng thấy slot trống, cùng mở lệnh
        #   cho cùng cặp -> nhân đôi vị thế, vượt hạn mức rủi ro/đòn bẩy.
        # - Nếu bấm 2 lần liên tiếp, hai chu kỳ chồng nhau cũng gây hiệu ứng tương tự.
        # Nay: từ chối khi bot đang chạy, và chỉ cho phép 1 chu kỳ thủ công tại một thời điểm.
        if getattr(app, '_bot_starting', False) or getattr(app.bot, 'is_running', False) or (_bot_thread and _bot_thread.is_alive()):
            return jsonify({
                'success': False,
                'error': 'Bot đang chạy loop tự động; chu kỳ đã được xử lý tự động, không chạy chồng.',
            }), 409

        if not _cycle_lock.acquire(blocking=False):
            return jsonify({
                'success': False,
                'error': 'Đang có một chu kỳ thủ công chạy dở; chờ chu kỳ đó kết thúc.',
            }), 409

        try:
            with _bot_lock:
                if getattr(app, '_bot_starting', False) or getattr(app.bot, 'is_running', False) or (_bot_thread and _bot_thread.is_alive()):
                    return jsonify({
                        'success': False,
                        'error': 'Bot đang chạy hoặc đang khởi động; chu kỳ đã được xử lý tự động, không chạy chồng.',
                    }), 409
            # [BOM #135 + #137 FIX]: Tiền kiểm bản quyền + đối soát LIVE NGOÀI _bot_lock để không đóng băng /api/stop, /api/pause, /api/start!
            _pf_cyc_err, _pf_cyc_code = _preflight_start_and_license_check()
            if _pf_cyc_err:
                return jsonify(_pf_cyc_err), _pf_cyc_code
            with _bot_lock:
                if getattr(app, '_bot_starting', False) or getattr(app.bot, 'is_running', False) or (_bot_thread and _bot_thread.is_alive()):
                    return jsonify({
                        'success': False,
                        'error': 'Bot đang chạy hoặc đang khởi động; chu kỳ đã được xử lý tự động, không chạy chồng.',
                    }), 409
            app.bot.run_cycle()
            return jsonify({'success': True, 'message': 'Đã chạy xong 1 chu kỳ'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
        finally:
            _cycle_lock.release()
    
    @app.route('/api/set_balance', methods=['POST'])
    def api_set_balance():
        """Set demo balance - nhập số tiền muốn thử nghiệm."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        if app.bot.mode != 'demo':
            return jsonify({'success': False, 'error': 'Only in DEMO mode'}), 400
        pos_lock = getattr(app.bot, '_position_lock', None) or contextlib.nullcontext()
        try:
            with pos_lock:
                if app.bot.is_running:
                    return jsonify({'success': False, 'error': 'Dừng bot trước khi đổi vốn DEMO.'}), 409
                if app.bot.open_positions:
                    return jsonify({'success': False, 'error': 'Đóng các vị thế DEMO trước khi đổi vốn.'}), 409
                data = request.get_json(silent=True) or {}
                try:
                    new_balance = float(data.get('balance', 0))
                except (TypeError, ValueError):
                    return jsonify({'success': False, 'error': 'Invalid balance'}), 400
                if not math.isfinite(new_balance) or new_balance < 1:
                    return jsonify({'success': False, 'error': 'Min $1'}), 400
                if new_balance > 1000000:
                    return jsonify({'success': False, 'error': 'Max $1,000,000'}), 400
                if app.bot.db.get_trades(mode='demo', limit=1):
                    return jsonify({
                        'success': False,
                        'error': 'Xóa lịch sử DEMO trước khi đặt lại vốn để không trộn hai mốc vốn.'
                    }), 409
                app.bot.balance = new_balance
                app.bot.peak_balance = new_balance
                # [BOM #132 FIX]: Đồng bộ đặt lại _v61_peak_equity tránh kẹt vĩnh viễn Soft DD Tier 2 (0.40x) sau khi reset vốn!
                app.bot._v61_peak_equity = new_balance
                app.bot.config['trading']['initial_capital'] = new_balance
                app.bot._demo_initial_capital = new_balance
                app.bot.trade_count = 0
                app.bot._save_state()
                return jsonify({'success': True, 'balance': new_balance})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/clear_history', methods=['POST'])
    def api_clear_history():
        """Reset toàn bộ nhật ký và lịch sử trong chế độ hiện tại."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        
        mode = app.bot.mode
        pos_lock = getattr(app.bot, '_position_lock', None) or contextlib.nullcontext()
        try:
            with pos_lock:
                if app.bot.is_running:
                    return jsonify({
                        'success': False,
                        'error': 'Dừng bot trước khi xóa lịch sử để tránh ghi trạng thái mới đồng thời.'
                    }), 409
                if mode == 'live':
                    app.bot.sync_live_positions_with_exchange()
                    if app.bot.open_positions:
                        return jsonify({
                            'success': False,
                            'error': 'Không thể xóa lịch sử khi còn vị thế LIVE đang mở; hãy đóng hoặc đối soát vị thế trước.'
                        }), 409
                    if getattr(app.bot, 'market_type', 'spot') == 'futures':
                        bal = app.bot.exchange.get_futures_balance()
                        if not isinstance(bal, dict) or _as_finite_float(bal.get('total'), 0.0) <= 0:
                            return jsonify({
                                'success': False,
                                'error': 'Không đọc được số dư Futures hợp lệ từ Binance; từ chối xóa lịch sử/ghi đè balance=0.0.'
                            }), 502
                        live_free_balance = float(bal.get('free', 0) or 0)
                    else:
                        bal = app.bot.exchange.get_balance()
                        base_currency = app.bot.config['trading'].get('base_currency', 'USDT')
                        spot_entry = bal.get(base_currency, {}) if isinstance(bal, dict) else None
                        if not isinstance(bal, dict) or not isinstance(spot_entry, dict) or _as_finite_float(spot_entry.get('total'), 0.0) <= 0:
                            return jsonify({
                                'success': False,
                                'error': 'Không đọc được số dư Spot hợp lệ từ Binance; từ chối xóa lịch sử/ghi đè balance=0.0.'
                            }), 502
                        live_free_balance = float(spot_entry.get('free', 0) or 0)
                elif app.bot.open_positions:
                    return jsonify({
                        'success': False,
                        'error': 'Không thể xóa lịch sử khi còn vị thế DEMO đang mở; hãy đóng vị thế trước.'
                    }), 409

                # Xóa lịch sử trong sqlite cho mode hiện tại; lỗi DB không được trả success giả.
                if not app.bot.db.clear_history(mode):
                    return jsonify({'success': False, 'error': 'Không xóa được lịch sử trong database; không có dữ liệu nào được xác nhận xóa.'}), 500
                
                # Reset biến bộ nhớ
                if mode == 'demo':
                    app.bot.open_positions = []
                app.bot.trade_count = 0
                
                # Nếu là live thì lấy số dư thật đã xác thực, nếu demo thì lấy initial capital
                if mode == 'demo':
                    app.bot.balance = app.bot.config['trading']['initial_capital']
                else:
                    app.bot.balance = live_free_balance
                        
                app.bot.peak_balance = app.bot.balance
                # [BOM #132 FIX]: Đồng bộ đặt lại _v61_peak_equity khi xóa lịch sử / nạp số dư mới!
                app.bot._v61_peak_equity = float(app.bot.balance)
                app.bot._save_state()
                
                mode_str = "LIVE" if mode == 'live' else "Demo"
                return jsonify({'success': True, 'message': f'Đã xóa trắng lịch sử {mode_str}!'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/optimize', methods=['POST'])
    def api_optimize():
        """Chạy bộ optimizer ở local background (chống chạy chồng qua _optimize_lock)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        if not _optimize_lock.acquire(blocking=False):
            return jsonify({
                'success': False,
                'error': 'Tiến trình tối ưu hóa AI đang chạy; vui lòng đợi hoàn tất.',
            }), 409

        def run_opt():
            try:
                import sys
                from pathlib import Path
                root_dir = Path(__file__).parent.parent
                if str(root_dir) not in sys.path:
                    sys.path.insert(0, str(root_dir))
                
                # Gọi Ollama LLM Manager để tư duy trước
                try:
                    from ai.ollama_agent import OllamaManagerAgent
                    llm_agent = OllamaManagerAgent(str(root_dir))
                    result = llm_agent.analyze_and_tune()
                    if result and 'error' not in result:
                        logger.info("LLM Agent đã hoàn tất phiên giám sát.")
                    else:
                        logger.warning(f"LLM Agent lỗi hoặc không kết nối: {result.get('error')}. Chuyển sang AI Toán học truyền thống...")
                except ImportError:
                    logger.warning("Không tìm thấy OllamaManagerAgent.")
                
                # Sau đó chạy Optimizer Toán học
                from core.optimizer import StrategyOptimizer
                opt = StrategyOptimizer(str(root_dir / 'config' / 'settings.yaml'))
                opt.run_optimization()
                
                # Nạp lại config mới cho bot đang chạy + đồng bộ trọng số cho signal_aggregator
                new_strat_cfg = app.bot._load_config(str(root_dir / "config" / "strategies.yaml"))
                app.bot.strategy_config = new_strat_cfg
                sig_agg = getattr(app.bot, 'signal_aggregator', None)
                if sig_agg is not None and isinstance(new_strat_cfg, dict):
                    if isinstance(getattr(sig_agg, 'strategy_weights', None), dict):
                        for s_name, s_cfg in (new_strat_cfg.get('strategies') or {}).items():
                            if isinstance(s_cfg, dict) and 'weight' in s_cfg:
                                try:
                                    sig_agg.strategy_weights[s_name] = float(s_cfg['weight'])
                                except (TypeError, ValueError):
                                    pass
                # [BOM #126C FIX]: Nạp nóng trực tiếp strategy.params mới vào các instance chiến lược đang chạy trong RAM!
                if isinstance(new_strat_cfg, dict):
                    _strats_cfg_map = new_strat_cfg.get('strategies') or {}
                    _live_strats = getattr(app.bot, 'strategies', None)
                    if isinstance(_live_strats, dict):
                        for _sn, _inst in _live_strats.items():
                            _new_p = (_strats_cfg_map.get(_sn) or {}).get('params')
                            if isinstance(_new_p, dict) and isinstance(getattr(_inst, 'params', None), dict):
                                _inst.params.update(_new_p)
                    elif isinstance(_live_strats, (list, tuple)):
                        for _inst in _live_strats:
                            _sn = str(getattr(_inst, 'name', '') or '').strip().lower()
                            for _k_cfg, _v_cfg in _strats_cfg_map.items():
                                if _sn == str(_k_cfg).lower() or _sn.replace('_', '') == str(_k_cfg).lower().replace('_', ''):
                                    _new_p = (_v_cfg or {}).get('params')
                                    if isinstance(_new_p, dict) and isinstance(getattr(_inst, 'params', None), dict):
                                        _inst.params.update(_new_p)
                                    break
                logger.info("Đã nạp lại cấu hình (weight + params) trực tiếp vào Bot đang chạy.")
                
            except Exception as e:
                logger.error(f"Optimizer error: {e}")
            finally:
                try:
                    _optimize_lock.release()
                except RuntimeError:
                    pass
                
        try:
            threading.Thread(target=run_opt, daemon=True).start()
        except Exception as e:
            try:
                _optimize_lock.release()
            except RuntimeError:
                pass
            return jsonify({'success': False, 'error': str(e)}), 500
        return jsonify({'success': True, 'message': 'Đã khởi động tiến trình AI Local (Ollama + Math Optimizer) ở chạy ngầm!'})
        
    @app.route('/api/ollama/status')
    def api_ollama_status():
        """Kiểm tra trạng thái Ollama và lấy danh sách model."""
        import requests
        try:
            res = requests.get('http://localhost:11434/api/tags', timeout=2)
            if res.status_code == 200:
                models = [m['name'] for m in res.json().get('models', [])]
                # Đọc model đang chọn trong settings
                import yaml
                from pathlib import Path
                settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
                current_model = 'llama3'
                try:
                    with open(settings_path, 'r', encoding='utf-8') as f:
                        settings = yaml.safe_load(f)
                        current_model = settings.get('ai', {}).get('ollama_model', 'llama3')
                except Exception: pass
                
                return jsonify({'running': True, 'models': models, 'current': current_model})
        except Exception:
            pass
        return jsonify({'running': False, 'models': []})
        
    @app.route('/api/ollama/set_model', methods=['POST'])
    def api_ollama_set_model():
        """Lưu model được chọn vào config."""
        data = request.get_json(silent=True) or {}
        model_name = data.get('model')
        if model_name:
            from pathlib import Path
            from core.config_utils import update_yaml_section_key
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            try:
                update_yaml_section_key(settings_path, 'ai', {'ollama_model': model_name})
                if app.bot and hasattr(app.bot, 'config') and isinstance(app.bot.config, dict):
                    app.bot.config.setdefault('ai', {})['ollama_model'] = model_name
                if app.bot and getattr(app.bot, 'jev_agent', None) is not None:
                    app.bot.jev_agent.model_name = model_name
                return jsonify({'success': True})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500
        return jsonify({'success': False, 'error': 'Thiếu tên model'}), 400

    @app.route('/api/ai_status')
    def api_ai_status():
        """Trạng thái AI Brain hiện tại."""
        import yaml
        from pathlib import Path
        result = {'bias': 'NEUTRAL', 'reasoning': 'Chưa phân tích', 'target': 'ALL', 'last_updated': '--'}
        try:
            strat_path = Path(__file__).parent.parent / 'config' / 'strategies.yaml'
            with open(strat_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f)
                ai_bias = strat.get('ai_bias', {})
                if ai_bias:
                    result['bias'] = ai_bias.get('direction', 'NEUTRAL')
                    result['reasoning'] = ai_bias.get('reasoning', 'Chưa phân tích')
                    result['target'] = ai_bias.get('target_coin', 'ALL')
                    result['last_updated'] = ai_bias.get('last_updated', '--')
        except Exception as e:
            logger.debug(f'AI status: {e}')
        
        # Check Ollama connection
        import requests
        try:
            res = requests.get('http://localhost:11434/api/tags', timeout=2)
            result['ollama_online'] = res.status_code == 200
        except Exception:
            result['ollama_online'] = False
        
        return jsonify(result)

    @app.route('/api/equity_curve')
    def api_equity_curve():
        """Return a reliable account curve for LIVE and trade history for DEMO."""
        if app.bot and app.bot.db:
            try:
                if app.bot.mode == 'live' and getattr(app.bot, 'market_type', 'spot') == 'futures':
                    status = app.bot.get_status()
                    equity = status.get('equity')
                    if equity is None:
                        return jsonify([])
                    initial = float(
                        status.get('invested_basis')
                        or status.get('initial_capital')
                        or app.bot.config['trading']['initial_capital']
                    )
                    return jsonify([
                        {'label': 'Mốc vốn PnL', 'balance': initial},
                        {'label': 'Binance hiện tại', 'balance': float(equity)},
                    ])

                trades = app.bot.db.get_trades(mode=app.bot.mode, limit=500)
                closed_trades = [t for t in trades if t.get('status') == 'closed' and t.get('pnl') is not None]
                closed_trades.reverse()  # oldest first
                
                initial = app.bot.config['trading']['initial_capital']
                curve = [{'label': 'Bắt đầu', 'balance': initial}]
                running = initial
                for t in closed_trades:
                    pnl = float(t.get('pnl', 0))
                    running += pnl
                    quote = app.bot.config.get('trading', {}).get('base_currency', 'USDT')
                    sym = (t.get('symbol', '') or '').removesuffix('/' + quote)
                    time_str = ''
                    if t.get('timestamp'):
                        from datetime import datetime
                        try:
                            ts = int(t['timestamp'])
                            if ts > 1e12: ts = ts // 1000
                            time_str = datetime.fromtimestamp(ts).strftime('%H:%M')
                        except Exception: pass
                    curve.append({'label': f'{sym} {time_str}', 'balance': round(running, 2)})
                return jsonify(curve)
            except Exception as e:
                logger.error(f'Equity curve error: {e}')
        return jsonify([])

    @app.route('/api/switch_mode', methods=['POST'])
    def switch_mode():
        data = request.get_json(silent=True) or {}
        mode = data.get('mode', 'demo')
        if app.bot:
            try:
                if mode == 'live':
                    app.bot.switch_mode(mode, data.get('api_key'), data.get('api_secret'))
                else:
                    app.bot.switch_mode('demo')
                return jsonify({'success': True, 'mode': mode})
            except RuntimeError as e:
                return jsonify({'success': False, 'error': str(e)}), 409
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500
        return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
    
    @app.route('/api/sentiment')
    def api_sentiment():
        """Lấy AI sentiment analysis từ các nguồn miễn phí (BOM #99/#100 FIX: không gọi đúp + serialize dict regime chuẩn)."""
        try:
            from ai.news_sentiment import NewsSentimentAnalyzer
            analyzer = NewsSentimentAnalyzer()
            
            result = {}
            
            # Composite sentiment cho primary pair (đã bao gồm fear_greed + market_overview bên trong — tránh gọi đúp!)
            symbol = 'BTC'
            if app.bot and app.bot.config.get('trading', {}).get('pairs'):
                symbol = app.bot.config['trading']['pairs'][0].split('/')[0]
            comp = analyzer.get_composite_sentiment(symbol) or {}
            result['composite'] = comp
            result['fear_greed'] = comp.get('fear_greed') or analyzer.get_fear_greed_index()
            coin_map = {'BTC': 'bitcoin', 'ETH': 'ethereum'}
            result['market'] = comp.get('market') or analyzer.get_market_overview(coin_map.get(symbol, 'bitcoin'))
            
            # Market regime detection
            try:
                from ai.market_regime import MarketRegimeDetector
                detector = MarketRegimeDetector()
                if app.bot and app.bot.data_collector:
                    pair = app.bot.config['trading']['pairs'][0]
                    df = app.bot.data_collector.get_cached_data(pair, '1h')
                    if df is not None and len(df) > 100:
                        reg_obj = detector.detect_regime(df)
                        if isinstance(reg_obj, dict):
                            reg_clean = dict(reg_obj)
                            if hasattr(reg_clean.get('regime'), 'value'):
                                reg_clean['regime'] = reg_clean['regime'].value
                            result['regime'] = reg_clean
                        else:
                            result['regime'] = {'regime_name': reg_obj.value if hasattr(reg_obj, 'value') else str(reg_obj)}
            except Exception as e:
                logger.debug(f"Regime detection not available: {e}")
            
            # Thêm TradFi Macro vĩ mô Wall Street (S&P 500, Nasdaq, DXY, Vàng)
            try:
                result['tradfi_macro'] = analyzer.get_tradfi_macro()
            except Exception as te:
                logger.debug(f"TradFi macro not available: {te}")
            
            return jsonify(result)
        except ImportError:
            return jsonify({'error': 'AI modules not available yet'})
        except Exception as e:
            return jsonify({'error': str(e)})
    
    @app.route('/api/logs')
    def api_logs():
        """Lấy log gần nhất cho real-time viewer."""
        import os
        from pathlib import Path
        
        lines = request.args.get('lines', 30, type=int)
        lines = max(1, min(lines, 200))
        
        try:
            root_dir = Path(__file__).parent.parent
            log_dir = root_dir / 'logs'
            
            # Tìm file log đang hoạt động mới nhất theo mtime (hỗ trợ chạy 24/7 qua nửa đêm)
            log_files = sorted(log_dir.glob('bot_*.log'), key=lambda p: p.stat().st_mtime, reverse=True)
            if not log_files:
                return jsonify({'logs': ['No log files found']})
            
            latest_log = log_files[0]
            with open(latest_log, 'r', encoding='utf-8', errors='replace') as f:
                # Bo qua access log cua werkzeug de Live Console tren web chi hien thi log trade
                filtered = [line.strip() for line in f if line.strip() and 'werkzeug:' not in line]
                recent = filtered[-lines:] if len(filtered) > lines else filtered
                return jsonify({'logs': recent})
        except Exception as e:
            return jsonify({'logs': [f'Error reading logs: {e}']})
    
    @app.route('/api/keys', methods=['GET', 'POST', 'DELETE'])
    def api_keys():
        import os
        import yaml
        from dotenv import load_dotenv, set_key
        
        env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
        settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
        
        # Load settings to get Telegram config
        try:
            with open(settings_path, 'r', encoding='utf-8') as f:
                settings = yaml.safe_load(f) or {}
        except Exception:
            settings = {}
            
        if request.method == 'GET':
            load_dotenv(env_path, override=True)
            api_key = os.getenv('BINANCE_API_KEY', '')
            masked = api_key[:4] + '***' + api_key[-4:] if len(api_key) > 8 else ''
            
            notif_cfg = settings.get('notifications') or {}
            tele_token = os.getenv('TELEGRAM_BOT_TOKEN', '') or str(notif_cfg.get('telegram_token') or '')
            tele_chat = os.getenv('TELEGRAM_CHAT_ID', '') or str(notif_cfg.get('telegram_chat_id') or '')
            tele_masked = tele_token[:4] + '***' + tele_token[-4:] if len(tele_token) > 8 else ''
            
            return jsonify({
                'has_key': bool(api_key), 
                'masked_key': masked,
                'tele_token': tele_masked,
                'tele_chat': tele_chat
            })
            
        elif request.method == 'POST':
            data = request.get_json(silent=True) or {}
            key = data.get('api_key')
            secret = data.get('api_secret')
            tele_token = data.get('tele_token')
            tele_chat = data.get('tele_chat')
            
            if not os.path.exists(env_path):
                open(env_path, 'w').close()
                
            if key and secret:
                set_key(env_path, 'BINANCE_API_KEY', key)
                set_key(env_path, 'BINANCE_API_SECRET', secret)
                
            # Keep Telegram credentials in .env, and clear legacy settings.yaml values when deleted.
            if tele_token or tele_chat:
                yaml_tele_updates = {}
                if tele_token == "DELETE":
                    set_key(env_path, 'TELEGRAM_BOT_TOKEN', '')
                    yaml_tele_updates['telegram_token'] = ''
                elif tele_token:
                    set_key(env_path, 'TELEGRAM_BOT_TOKEN', tele_token)
                    
                if tele_chat == "DELETE":
                    set_key(env_path, 'TELEGRAM_CHAT_ID', '')
                    yaml_tele_updates['telegram_chat_id'] = ''
                elif tele_chat:
                    set_key(env_path, 'TELEGRAM_CHAT_ID', str(tele_chat))

                if yaml_tele_updates and os.path.exists(settings_path):
                    try:
                        from core.config_utils import update_yaml_section_key
                        update_yaml_section_key(settings_path, 'notifications', yaml_tele_updates)
                        if app.bot and isinstance(getattr(app.bot, 'config', None), dict):
                            notif_mem = app.bot.config.setdefault('notifications', {})
                            notif_mem.update(yaml_tele_updates)
                    except Exception as ye:
                        logger.warning(f"Không thể cập nhật notifications trong settings.yaml: {ye}")
                
                # Cập nhật bot trong memory
                if app.bot:
                    load_dotenv(env_path, override=True)
                
            load_dotenv(env_path, override=True)
            return jsonify({'success': True, 'msg': 'Đã lưu cấu hình thành công! (Telegram có hiệu lực ngay lập tức)'})
            
        elif request.method == 'DELETE':
            if os.path.exists(env_path):
                set_key(env_path, 'BINANCE_API_KEY', '')
                set_key(env_path, 'BINANCE_API_SECRET', '')
                load_dotenv(env_path, override=True)
            return jsonify({'success': True, 'msg': 'Đã xóa Binance API Key thành công!'})

    @app.route('/api/telegram/test', methods=['POST'])
    def api_telegram_test():
        import os
        import yaml
        from dotenv import load_dotenv
        load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'), override=True)
        token = os.getenv('TELEGRAM_BOT_TOKEN', '')
        chat_id = os.getenv('TELEGRAM_CHAT_ID', '')
        if not token or not chat_id:
            settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
            try:
                with open(settings_path, 'r', encoding='utf-8-sig') as f:
                    settings = yaml.safe_load(f) or {}
            except Exception:
                settings = {}
            notif_cfg = settings.get('notifications') or {}
            token = token or str(notif_cfg.get('telegram_token') or '')
            chat_id = chat_id or str(notif_cfg.get('telegram_chat_id') or '')
        if not token or not chat_id:
            return jsonify({'success': False, 'error': 'Chưa cấu hình Telegram bot token và chat ID.'}), 400
        from core.telegram_notifier import send_telegram_message
        if not send_telegram_message(token, chat_id, '✅ TRADE BOT: kiểm tra kết nối Telegram thành công.', async_send=False):
            return jsonify({'success': False, 'error': 'Telegram không nhận tin nhắn; kiểm tra token, chat ID và quyền gửi tin.'}), 502
        return jsonify({'success': True, 'message': 'Đã gửi tin nhắn kiểm tra đến Telegram.'})

    @app.route('/api/cloud_token', methods=['GET', 'POST', 'DELETE'])
    def api_cloud_token():
        from pathlib import Path
        from core.config_utils import get_yaml_lock
        settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'

        if request.method == 'GET':
            with get_yaml_lock(settings_path):
                settings, read_error = _read_settings_for_write(settings_path)
            if read_error:
                return jsonify({'success': False, 'error': read_error}), 500
            user_token = str(settings.get('cloud', {}).get('user_token', '') or '').strip()
            masked = (user_token[:6] + '...' + user_token[-4:]) if len(user_token) > 10 else user_token
            return jsonify({
                'has_token': bool(user_token),
                'user_token': '',  # [BOM #121K FIX]: KHONG tra token tho ra frontend (chi tra masked_token)
                'masked_token': masked
            })

        # POST/DELETE đều GHI file: giữ RLock suốt chu kỳ đọc-sửa-ghi atomic.
        with get_yaml_lock(settings_path):
            settings, read_error = _read_settings_for_write(settings_path)
            if read_error:
                logger.error('❌ [CLOUD TOKEN] %s', read_error)
                return jsonify({'success': False, 'error': read_error}), 500

            is_post = request.method == 'POST'
            if is_post:
                data = request.get_json(silent=True) or {}
                token = str(data.get('user_token', '') or '').strip()
                # [BOM #121K FIX]: Chan luu token rong hoac chuoi masked ('abc123...wxyz') de khong ghi de token that
                if not token or '...' in token:
                    return jsonify({'success': False, 'error': 'User Token không hợp lệ.'}), 400
                if 'cloud' not in settings or not isinstance(settings.get('cloud'), dict):
                    settings['cloud'] = {}
                settings['cloud']['user_token'] = token
                settings['cloud']['enabled'] = bool(token)
                success_msg = 'Đã lưu User Token thành công! Dữ liệu sẽ tự động đồng bộ lên Web TradeMatrix.'
            else:
                if isinstance(settings.get('cloud'), dict):
                    settings['cloud']['user_token'] = ''
                    settings['cloud']['enabled'] = False
                success_msg = 'Đã ngắt kết nối đồng bộ Web!'

            try:
                _atomic_write_settings(settings_path, settings)
            except Exception as e:
                logger.error('❌ [CLOUD TOKEN] Ghi settings.yaml thất bại: %s', e)
                return jsonify({'success': False, 'error': str(e)}), 500

            # Đọc lại để xác nhận file vẫn hợp lệ và đúng nội dung vừa ghi
            verified, verify_error = _read_settings_for_write(settings_path)
        if verify_error or not isinstance(verified, dict):
            return jsonify({
                'success': False,
                'error': f'File cấu hình không đọc lại được sau khi ghi ({verify_error}). '
                         f'Bản sao lưu: config/settings.yaml.bak',
            }), 500
        if 'risk' not in verified or 'trading' not in verified:
            logger.error('❌ [CLOUD TOKEN] settings.yaml sau khi ghi THIẾU nhánh gốc (risk/trading) - trả lỗi.')
            return jsonify({
                'success': False,
                'error': 'Cấu hình sau khi ghi thiếu nhánh gốc; đã giữ bản .bak để khôi phục.',
            }), 500

        if app.bot and isinstance(getattr(app.bot, 'config', None), dict):
            bot_cloud = app.bot.config.setdefault('cloud', {})
            if isinstance(bot_cloud, dict):
                bot_cloud['user_token'] = settings.get('cloud', {}).get('user_token', '')
                bot_cloud['enabled'] = settings.get('cloud', {}).get('enabled', False)

        return jsonify({'success': True, 'msg': success_msg})

    @app.route('/api/config')
    def api_config():
        """Lấy cấu hình hiện tại (không bao gồm secrets)."""
        if app.bot:
            config = dict(app.bot.config)
            # Ẩn toàn bộ API keys, user_token và Telegram credentials
            if isinstance(config.get('exchange'), dict):
                config['exchange'] = dict(config['exchange'])
                config['exchange']['api_key'] = '***' if config['exchange'].get('api_key') else ''
                config['exchange']['api_secret'] = '***' if config['exchange'].get('api_secret') else ''
            if isinstance(config.get('cloud'), dict):
                config['cloud'] = dict(config['cloud'])
                if config['cloud'].get('user_token'):
                    config['cloud']['user_token'] = '***'
            if isinstance(config.get('notifications'), dict):
                notif_cfg = dict(config['notifications'])
                for k, v in list(notif_cfg.items()):
                    kl = str(k).lower()
                    if any(tok in kl for tok in ('token', 'secret', 'password', 'chat_id')) and v:
                        notif_cfg[k] = '***'
                config['notifications'] = notif_cfg
            return jsonify(config)
        return jsonify({})

    @app.route('/api/leverage', methods=['POST'])
    def api_set_max_leverage():
        """Set and persist the dynamic leverage ceiling for demo and live."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            raw_value = float(data.get('max_leverage'))
            if not raw_value.is_integer() or not 1 <= raw_value <= 150:
                return jsonify({
                    'success': False,
                    'error': 'Giới hạn đòn bẩy phải là số nguyên từ 1x đến 150x.',
                }), 400
            max_leverage = int(raw_value)

            from pathlib import Path
            from core.config_utils import update_yaml_section_key
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            try:
                update_yaml_section_key(settings_path, 'trading', {'max_leverage': max_leverage})
            except ValueError as ve:
                return jsonify({'success': False, 'error': str(ve)}), 500

            app.bot.config.setdefault('trading', {})['max_leverage'] = max_leverage
            return jsonify({
                'success': True,
                'max_leverage': max_leverage,
                'message': f'Đã lưu trần đòn bẩy động: {max_leverage}x (áp dụng cho lệnh mới ở DEMO và LIVE).',
            })
        except (TypeError, ValueError, OverflowError):
            return jsonify({'success': False, 'error': 'Giá trị đòn bẩy không hợp lệ.'}), 400
        except Exception as e:
            logger.error('Could not save max leverage: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/risk_per_trade', methods=['GET', 'POST'])
    def api_risk_per_trade():
        """[BOM #122A]: Doc va luu muc rui ro chuan/vi the (% NAV) trong bien an toan [0.15%, 1.00%]."""
        try:
            from pathlib import Path
            from core.config_utils import update_yaml_section_key
            from core.quant_evolution_engine import load_position_tuning, save_position_tuning
            from core.vietnamese_weapon_arsenal import invalidate_arsenal_cache

            if request.method == 'GET':
                pt = load_position_tuning()
                cls_map = pt.get('classes') or {}
                return jsonify({
                    'success': True,
                    'base_risk_pct': float((cls_map.get('ALTCOIN') or {}).get('base_risk_pct') or 0.35),
                    'by_class': {k: float((v or {}).get('base_risk_pct') or 0.35) for k, v in cls_map.items()},
                })

            data = request.get_json(silent=True) or {}
            raw_val = data.get('base_risk_pct')
            risk_pct = round(float(raw_val), 2)
            if not math.isfinite(risk_pct) or not (0.15 <= risk_pct <= 1.00):
                return jsonify({
                    'success': False,
                    'error': 'Rủi ro chuẩn mỗi vị thế phải nằm trong [0.15%, 1.00%] NAV.',
                }), 400

            etf_risk = round(max(0.15, min(1.00, risk_pct * (0.30 / 0.35))), 2)
            saved_pt = save_position_tuning({
                'classes': {
                    'ALTCOIN': {'base_risk_pct': risk_pct},
                    'MAJOR': {'base_risk_pct': risk_pct},
                    'TRADFI_1X': {'base_risk_pct': risk_pct},
                    'TRADFI_ETF_3X': {'base_risk_pct': etf_risk},
                }
            })
            invalidate_arsenal_cache()

            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            max_risk_dec = round(risk_pct / 100.0, 5)
            try:
                update_yaml_section_key(settings_path, 'risk', {'max_risk_per_trade': max_risk_dec})
            except Exception as ye:
                logger.error('❌ Lưu max_risk_per_trade thất bại: %s', ye)
                return jsonify({'success': False, 'error': f'Lưu settings.yaml thất bại: {ye}'}), 500

            if app.bot and isinstance(getattr(app.bot, 'config', None), dict):
                app.bot.config.setdefault('risk', {})['max_risk_per_trade'] = max_risk_dec
                if getattr(app.bot, 'risk_manager', None) is not None:
                    app.bot.risk_manager.max_risk_per_trade = max_risk_dec

            return jsonify({
                'success': True,
                'base_risk_pct': float(((saved_pt.get('classes') or {}).get('ALTCOIN') or {}).get('base_risk_pct') or risk_pct),
                'etf_risk_pct': etf_risk,
                'message': f'Đã lưu rủi ro chuẩn: {risk_pct:.2f}% NAV (ETF 3x: {etf_risk:.2f}% · áp dụng cho lệnh MỚI).',
            })
        except (TypeError, ValueError, OverflowError):
            return jsonify({'success': False, 'error': 'Giá trị rủi ro % NAV không hợp lệ.'}), 400
        except Exception as e:
            logger.error('Could not save base_risk_pct: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/positions_limit', methods=['POST'])
    def api_set_positions_limit():
        """Set and persist the dynamic position limits (min and max) for demo and live."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            from pathlib import Path
            from core.config_utils import get_yaml_lock
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            with get_yaml_lock(settings_path):
                settings, load_error = _read_settings_for_write(settings_path)
                if load_error:
                    return jsonify({'success': False, 'error': load_error}), 500

                existing_trading = settings.get('trading') or {}
                default_min = int(existing_trading.get('min_open_trades', 1) or 1)
                default_max = int(existing_trading.get('max_open_trades', 5) or 5)
                raw_max = float(data['max_open_trades']) if data.get('max_open_trades') is not None else default_max
                if data.get('min_open_trades') is not None:
                    min_trades = max(1, min(20, int(float(data['min_open_trades']))))
                    max_trades = max(min_trades, min(20, int(raw_max)))
                else:
                    max_trades = max(1, min(20, int(raw_max)))
                    min_trades = max(1, min(max_trades, default_min))

                settings.setdefault('trading', {})['max_open_trades'] = max_trades
                settings['trading']['min_open_trades'] = min_trades
                # [BOM #152 P1-9 FIX]: Đồng bộ đúng max_open_positions == max_trades (không ép max(10, max_trades) làm vô hiệu trần người dùng đặt!)
                settings.setdefault('risk', {})['max_open_positions'] = max_trades
                _atomic_write_settings(settings_path, settings)

            app.bot.config.setdefault('trading', {})['max_open_trades'] = max_trades
            app.bot.config['trading']['min_open_trades'] = min_trades
            app.bot.config.setdefault('risk', {})['max_open_positions'] = settings['risk']['max_open_positions']
            if getattr(app.bot, 'risk_manager', None) is not None:
                app.bot.risk_manager.max_open_positions = int(settings['risk']['max_open_positions'])

            return jsonify({
                'success': True,
                'min_open_trades': min_trades,
                'max_open_trades': max_trades,
                'message': f'Đã lưu giới hạn vị thế tự điều phối: {min_trades} đến {max_trades} lệnh (áp dụng cho DEMO & LIVE).',
            })
        except (TypeError, ValueError, OverflowError):
            return jsonify({'success': False, 'error': 'Giá trị vị thế không hợp lệ.'}), 400
        except Exception as e:
            logger.error('Could not save positions limit: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/tradfi/toggle', methods=['POST'])
    def api_tradfi_toggle():
        """Bật / Tắt chế độ giao dịch Hợp đồng Cổ phiếu Mỹ (TradFi Stock Perps).
        Hỗ trợ 3 chế độ:
        1. Chỉ Crypto: enabled=False, only_tradfi=False
        2. Cả Hai (Crypto + Cổ phiếu): enabled=True, only_tradfi=False
        3. Chỉ Cổ phiếu: enabled=True, only_tradfi=True
        """
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            current_tradfi = app.bot.config.get('tradfi', {})
            
            has_enabled = 'enabled' in data
            has_only = 'only_tradfi' in data
            
            enabled = bool(data.get('enabled')) if has_enabled else bool(current_tradfi.get('enabled', False))
            only_tradfi = bool(data.get('only_tradfi')) if has_only else bool(current_tradfi.get('only_tradfi', False))
            
            # Ràng buộc trạng thái UI:
            if only_tradfi:
                enabled = True
            elif has_enabled and not enabled:
                only_tradfi = False

            from pathlib import Path
            from core.config_utils import update_yaml_section_key
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            try:
                update_yaml_section_key(
                    settings_path,
                    'tradfi',
                    {'enabled': enabled, 'only_tradfi': only_tradfi},
                )
            except Exception as ve:
                # [BOM #121K FIX]: Khong nuot loi luu file (truoc day UI bao thanh cong nhung restart lai mat cau hinh)
                logger.error('❌ Lưu tradfi settings thất bại: %s', ve)
                return jsonify({'success': False, 'error': f'Lưu settings.yaml thất bại: {ve}'}), 500

            app.bot.config.setdefault('tradfi', {})['enabled'] = enabled
            app.bot.config['tradfi']['only_tradfi'] = only_tradfi

            if only_tradfi:
                mode_desc = "CHỈ CỔ PHIẾU MỸ (TẮT CRYPTO)"
            elif enabled:
                mode_desc = "CẢ HAI (CRYPTO + CỔ PHIẾU MỸ)"
            else:
                mode_desc = "CHỈ CRYPTO (TẮT CỔ PHIẾU)"

            logger.info("Chế độ TradFi Stock Perps đã cập nhật: %s", mode_desc)
            return jsonify({
                'success': True,
                'enabled': enabled,
                'only_tradfi': only_tradfi,
                'mode_desc': mode_desc,
                'message': f"Đã chuyển sang chế độ: {mode_desc}."
            })
        except Exception as e:
            logger.error('Could not toggle TradFi: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/manual_adopt/toggle', methods=['POST'])
    def api_manual_adopt_toggle():
        """Bật / Tắt chế độ Tự động bảo hộ và quản lý lệnh tay (Auto-Adopt Manual Positions)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            current_val = getattr(app.bot, 'auto_adopt_manual_positions', False)
            enabled = bool(data.get('enabled')) if 'enabled' in data else not current_val
            
            from pathlib import Path
            from core.config_utils import update_yaml_section_key
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            try:
                update_yaml_section_key(
                    settings_path,
                    'trading',
                    {'auto_adopt_manual_positions': enabled},
                )
            except Exception as ve:
                # [BOM #121K FIX]: Luu file that bai -> KHONG doi trang thai RAM, bao loi 500
                logger.error('❌ Lưu auto_adopt_manual_positions thất bại: %s', ve)
                return jsonify({'success': False, 'error': f'Lưu settings.yaml thất bại: {ve}'}), 500
            app.bot.auto_adopt_manual_positions = enabled
            app.bot.config.setdefault('trading', {})['auto_adopt_manual_positions'] = enabled
            
            logger.info("Chế độ Tự Động Bảo Hộ & Quản Lý Lệnh Tay đã cập nhật: %s", "BẬT" if enabled else "TẮT")
            return jsonify({
                'success': True,
                'auto_adopt_manual_positions': enabled,
                'message': f"Đã {'BẬT' if enabled else 'TẮT'} chế độ Tự Động Bảo Hộ Lệnh Tay."
            })
        except Exception as e:
            logger.error('Could not toggle manual adopt: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/free_roll_recycling/toggle', methods=['POST'])
    def api_free_roll_recycling_toggle():
        """Bật / Tắt chế độ Gia Tăng Vị Thế Khi Bảo Toàn Vốn (Free-Roll Slot Recycling)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            current_val = getattr(app.bot, 'free_roll_recycling', True)
            enabled = bool(data.get('enabled')) if 'enabled' in data else not current_val
            
            from pathlib import Path
            from core.config_utils import update_yaml_section_key
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            try:
                update_yaml_section_key(
                    settings_path,
                    'trading',
                    {'free_roll_recycling': enabled},
                )
            except Exception as ve:
                # [BOM #121K FIX]: Luu file that bai -> KHONG doi trang thai RAM, bao loi 500
                logger.error('❌ Lưu free_roll_recycling thất bại: %s', ve)
                return jsonify({'success': False, 'error': f'Lưu settings.yaml thất bại: {ve}'}), 500
            app.bot.free_roll_recycling = enabled
            app.bot.config.setdefault('trading', {})['free_roll_recycling'] = enabled
            
            logger.info("Chế độ Gia Tăng Vị Thế Khi Bảo Toàn Vốn đã cập nhật: %s", "BẬT" if enabled else "TẮT")
            return jsonify({
                'success': True,
                'free_roll_recycling': enabled,
                'message': f"Đã {'BẬT' if enabled else 'TẮT'} chế độ Gia Tăng Vị Thế Khi Bảo Toàn Vốn."
            })
        except Exception as e:
            logger.error('Could not toggle free roll recycling: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/exchange', methods=['POST'])
    def api_set_exchange():
        """Lưu sàn giao dịch được chọn vào config/settings.yaml (áp dụng khi restart)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            ex_name = str(data.get('exchange') or '').strip().lower()
            supported = ('binance', 'okx', 'bybit')
            if ex_name not in supported:
                return jsonify({
                    'success': False,
                    'error': f"Sàn '{ex_name}' không hợp lệ. Chỉ hỗ trợ: {', '.join(s.upper() for s in supported)}",
                }), 400
            from pathlib import Path
            from core.config_utils import update_yaml_section_key
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            update_yaml_section_key(settings_path, 'exchange', {'name': ex_name})
            app.bot.config.setdefault('exchange', {})['name'] = ex_name
            return jsonify({
                'success': True,
                'exchange': ex_name,
                'message': f'Đã lưu sàn {ex_name.upper()} vào settings.yaml (khởi động lại bot để áp dụng).',
            })
        except Exception as e:
            logger.error('Could not update exchange setting: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    # ==============================================================================
    # V6.1 QUANT EVOLUTION & CONTROL CENTER APIs (PC1 ONLY)
    # ==============================================================================
    @app.route('/api/v61/weapon_lifecycle', methods=['POST'])
    def api_v61_weapon_lifecycle():
        """Quản trị vòng đời 2 chiều (LAB <-> THỬ NGHIỆM <-> CHÍNH THỨC <-> TẠM TẮT / XÓA MỀM / XÓA VĨNH VIỄN / XẾP GỌN)."""
        try:
            from pathlib import Path
            from core.quant_evolution_engine import (
                update_weapon_lifecycle_state,
                promote_lab_to_dynamic_weapon,
                hard_delete_dynamic_weapon,
                compact_dynamic_weapon_codes,
                invalidate_lab_optimizer_cache,
            )
            from core.vietnamese_weapon_arsenal import invalidate_arsenal_cache
            data = request.get_json(silent=True) or {}
            action = str(data.get('action') or 'set_state').strip().lower()
            if action == 'promote_lab':
                # [V6.1 BOM #72]: Server tu xac thuc 5 Tieu Chuan Cung Alpha truc tiep tu SQLite (khong tin payload client!)
                _db_p = getattr(getattr(app.bot, 'db', None), 'db_path', None) if app.bot else None
                ok, msg, dyn_obj = promote_lab_to_dynamic_weapon(data.get('lab') or {}, db_path=_db_p)
                invalidate_arsenal_cache()
                resp_body = {'success': ok, 'message': msg, 'weapon': dyn_obj}
                if not ok:
                    resp_body['error'] = msg
                return jsonify(resp_body), (200 if ok else 400)
            if action == 'compact_codes':
                lc = compact_dynamic_weapon_codes()
                invalidate_arsenal_cache()
                invalidate_lab_optimizer_cache()
                return jsonify({'success': True, 'message': '🔢 Đã sắp xếp và đánh số gọn lại các vũ khí động (VK11, VK12...) theo đúng thứ tự!', 'lifecycle': lc})
            wid = str(data.get('weapon_id') or '').strip()
            if action == 'hard_delete':
                if not wid:
                    return jsonify({'success': False, 'error': 'Thiếu weapon_id'}), 400
                lc = hard_delete_dynamic_weapon(wid)
                invalidate_arsenal_cache()
                invalidate_lab_optimizer_cache()
                return jsonify({'success': True, 'message': f'🗑️ Đã xóa vĩnh viễn {wid} khỏi Kho Vũ Khí Động.', 'lifecycle': lc})
            new_state = str(data.get('state') or '').strip().upper()
            if not wid or not new_state:
                return jsonify({'success': False, 'error': 'Thiếu weapon_id hoặc state'}), 400
            _db_p_st = getattr(getattr(app.bot, 'db', None), 'db_path', None) if app.bot else None
            lc = update_weapon_lifecycle_state(wid, new_state, db_path=_db_p_st)
            invalidate_arsenal_cache()
            return jsonify({'success': True, 'message': f'Đã chuyển {wid} sang trạng thái {new_state}.', 'lifecycle': lc})
        except ValueError as ve:
            return jsonify({'success': False, 'error': str(ve)}), 400
        except Exception as e:
            logger.error('V6.1 weapon_lifecycle error: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/v61/lab_action', methods=['POST'])
    def api_v61_lab_action():
        """Chuyển mẫu LAB sang bảng Không Đạt / Cấm Thăng Hạng, Khôi Phục lại, hoặc Quét Tối Ưu Lại 20 Thấu Kính."""
        try:
            from pathlib import Path
            from core.quant_evolution_engine import (
                reject_lab_cluster,
                restore_lab_cluster,
                invalidate_lab_optimizer_cache,
                run_auto_dna_lab_discovery_and_optimizer,
                run_8station_pre_promotion_dry_run,
            )
            from core.vietnamese_weapon_arsenal import invalidate_arsenal_cache
            data = request.get_json(silent=True) or {}
            action = str(data.get('action') or '').strip().lower()
            if action == 'rescan':
                invalidate_lab_optimizer_cache()
                invalidate_arsenal_cache()
                return jsonify({'success': True, 'message': '🔄 Đã quét lại toàn bộ 20 Thấu Kính Giảm SL + OOS 70/30!'})
            sig = str(data.get('signature') or '').strip()
            if not sig:
                return jsonify({'success': False, 'error': 'Thiếu signature của mẫu LAB'}), 400
            if action == 'dry_run_lab':
                _db_p_dry = getattr(getattr(app.bot, 'db', None), 'db_path', 'data/trade_bot.db') if app.bot else 'data/trade_bot.db'
                _scan_dry = run_auto_dna_lab_discovery_and_optimizer(db_path=_db_p_dry, ttl_sec=30.0)
                _cand_dry = next((x for x in (_scan_dry.get('active_labs') or []) if str(x.get('signature') or '') == sig), None)
                if _cand_dry is None:
                    return jsonify({'success': False, 'error': f"Không tìm thấy mẫu '{sig}' trong LAB hợp lệ."}), 404
                _dry_res = run_8station_pre_promotion_dry_run(_cand_dry, db_path=_db_p_dry)
                return jsonify({'success': True, 'dry_run': _dry_res})
            if action == 'reject':
                reg = reject_lab_cluster(sig, data.get('info') or {})
                invalidate_arsenal_cache()
                return jsonify({'success': True, 'message': 'Đã chuyển mẫu sang Tab Không Đạt / Cấm Thăng Hạng.', 'registry': reg})
            elif action == 'restore':
                reg = restore_lab_cluster(sig)
                invalidate_arsenal_cache()
                return jsonify({'success': True, 'message': 'Đã khôi phục mẫu về Phòng Thí Nghiệm LAB.', 'registry': reg})
            return jsonify({'success': False, 'error': f'Hành động không hợp lệ: {action}'}), 400
        except Exception as e:
            logger.error('V6.1 lab_action error: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/v61/simulate_tuning', methods=['POST'])
    def api_v61_simulate_tuning():
        """[V6.1 BOM #42]: Mô phỏng Tức Thì (Offline SQLite) tác động của thông số người dùng đang gõ tay."""
        try:
            from core.quant_evolution_engine import simulate_manual_position_tuning
            data = request.get_json(silent=True) or {}
            ac = str(data.get('asset_class') or 'ALTCOIN').upper()
            settings = data.get('settings') or {}
            db_p = getattr(getattr(app.bot, 'db', None), 'db_path', 'data/trade_bot.db') if app.bot else 'data/trade_bot.db'
            _bot_mode_st = getattr(app.bot, 'mode', 'demo') if app.bot else 'demo'
            _fut_snap = (getattr(app.bot, '_futures_account_snapshot', None) or {}) if (app.bot and _bot_mode_st == 'live') else {}
            _eq_raw_st = _fut_snap.get('margin_balance') if _bot_mode_st == 'live' else None
            if not _eq_raw_st and app.bot:
                _eq_raw_st = getattr(app.bot, 'balance', 0.0)
            eq = float(_eq_raw_st or 0.0)
            if eq <= 0:
                eq = 406.0
            res = simulate_manual_position_tuning(asset_class=ac, settings=settings, equity_usd=eq, db_path=db_p)
            return jsonify({'success': True, 'simulation': res})
        except Exception as e:
            logger.error('V6.1 simulate_tuning error: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/v61/position_tuning', methods=['GET', 'POST'])
    def api_v61_position_tuning():
        """Trung tâm tinh chỉnh 4 phân lớp tài sản (SL/Khoảng thở/BE/TP1..TP5/Auto Bayes/Reset Mặc Định)."""
        try:
            from pathlib import Path
            from core.quant_evolution_engine import (
                load_position_tuning,
                save_position_tuning,
                reset_position_tuning,
                compute_shadow_bayes_breathing_advisor,
                CONSTITUTION_BOUNDS,
            )
            from core.config_utils import update_yaml_section_key
            from core.vietnamese_weapon_arsenal import invalidate_arsenal_cache

            def _sync_risk_per_trade_from_cfg(pt_cfg: dict):
                alt_risk = float((((pt_cfg or {}).get('classes') or {}).get('ALTCOIN') or {}).get('base_risk_pct') or 0.35)
                max_risk_dec = round(max(0.0015, min(0.0100, alt_risk / 100.0)), 5)
                settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
                if settings_path.exists():
                    update_yaml_section_key(settings_path, 'risk', {'max_risk_per_trade': max_risk_dec})
                if app.bot and isinstance(getattr(app.bot, 'config', None), dict):
                    app.bot.config.setdefault('risk', {})['max_risk_per_trade'] = max_risk_dec
                    if getattr(app.bot, 'risk_manager', None) is not None:
                        app.bot.risk_manager.max_risk_per_trade = max_risk_dec

            db_p = getattr(getattr(app.bot, 'db', None), 'db_path', 'data/trade_bot.db') if app.bot else 'data/trade_bot.db'
            if request.method == 'GET':
                return jsonify({
                    'success': True,
                    'config': load_position_tuning(),
                    'advisor': compute_shadow_bayes_breathing_advisor(db_path=db_p).get('advisor_by_class') or {},
                    'bounds': CONSTITUTION_BOUNDS,
                })
            data = request.get_json(silent=True) or {}
            action = str(data.get('action') or 'save').strip().lower()
            if action == 'reset_default':
                ac_target = data.get('asset_class')
                cfg = reset_position_tuning(asset_class=ac_target)
                _sync_risk_per_trade_from_cfg(cfg)
                invalidate_arsenal_cache()
                return jsonify({'success': True, 'message': '🔄 Đã khôi phục thông số mặc định chuẩn V6.4 (Quán Quân C5 & Tam Tầng V4.1)!', 'config': cfg})
            elif action == 'apply_advisor':
                ac_target = str(data.get('asset_class') or 'ALTCOIN').upper()
                adv = (compute_shadow_bayes_breathing_advisor(db_path=db_p).get('advisor_by_class') or {}).get(ac_target) or {}
                if not adv:
                    return jsonify({'success': False, 'error': f'Không có dữ liệu Shadow cho {ac_target}'}), 400
                cur = load_position_tuning()
                cls_cfg = dict(cur['classes'].get(ac_target) or {})
                cls_cfg['sl_default_pct'] = float(adv.get('suggested_sl_pct') or cls_cfg.get('sl_default_pct', 2.0))
                cls_cfg['be_trigger_pct'] = float(adv.get('suggested_be_pct') or cls_cfg.get('be_trigger_pct', 0.85))
                cfg = save_position_tuning({'asset_class': ac_target, 'settings': cls_cfg})
                invalidate_arsenal_cache()
                return jsonify({'success': True, 'message': f'💡 Đã áp dụng gợi ý Shadow Bayes (SL={cls_cfg["sl_default_pct"]}%, BE={cls_cfg["be_trigger_pct"]}%) cho {ac_target}!', 'config': cfg})
            else:
                cfg = save_position_tuning(data)
                _sync_risk_per_trade_from_cfg(cfg)
                invalidate_arsenal_cache()
                return jsonify({'success': True, 'message': '✅ Đã lưu cấu hình vị thế (kẹp chặt trong Biên An Toàn Hiến Pháp, chỉ áp cho lệnh mới)!', 'config': cfg})
        except Exception as e:
            logger.error('V6.1 position_tuning error: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/health')
    def health():
        """Health check endpoint."""
        return jsonify({
            'status': 'ok',
            'bot_running': app.bot.is_running if app.bot else False,
            'market_type': app.bot.config.get('trading', {}).get('market_type', 'spot') if app.bot else 'unknown',
            'timestamp': datetime.now().isoformat()
        })
    
    return app

