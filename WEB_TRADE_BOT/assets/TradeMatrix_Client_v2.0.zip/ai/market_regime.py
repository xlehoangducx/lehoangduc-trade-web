import pandas as pd
import numpy as np
import ta
import logging
from typing import Dict, Optional
from enum import Enum

logger = logging.getLogger(__name__)

class MarketRegime(Enum):
    STRONG_UPTREND = 'strong_uptrend'
    UPTREND = 'uptrend'
    RANGING = 'ranging'
    DOWNTREND = 'downtrend'
    STRONG_DOWNTREND = 'strong_downtrend'
    HIGH_VOLATILITY = 'high_volatility'

class MarketRegimeDetector:
    """
    Detect current market regime to select appropriate strategy.
    - Trending markets -> use TrendFollowing
    - Ranging markets -> use MeanReversion
    - High volatility -> reduce position size or stay out
    - Strong downtrend -> enable DCA or go short (futures)
    """
    
    def __init__(self):
        pass
    
    def detect_regime(self, df: pd.DataFrame) -> Dict:
        """
        Analyze market data and determine current regime.
        Uses ADX, Bollinger Band Width, EMA alignment, and volatility.
        """
        if df is None or len(df) < 100:
            return {'regime': MarketRegime.RANGING, 'confidence': 0.0, 'adx': 0.0, 'atr_pct': 0.0, 'rsi': 50.0, 'details': {}}
        
        df = df.copy()
        
        # 1. ADX for trend strength
        adx_indicator = ta.trend.ADXIndicator(df['high'], df['low'], df['close'], window=14)
        df['adx'] = adx_indicator.adx()
        df['di_plus'] = adx_indicator.adx_pos()
        df['di_minus'] = adx_indicator.adx_neg()
        
        # 2. EMA alignment (dùng min(len(df), 200) + bfill để không sinh toàn NaN khi 100 <= len(df) < 200)
        df['ema_20'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
        df['ema_50'] = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator()
        w200 = max(50, min(len(df) - 1, 200))
        df['ema_200'] = ta.trend.EMAIndicator(df['close'], window=w200).ema_indicator().bfill()
        
        # 3. Bollinger Band Width (volatility)
        bb = ta.volatility.BollingerBands(df['close'], window=20, window_dev=2)
        df['bb_width'] = (bb.bollinger_hband() - bb.bollinger_lband()) / bb.bollinger_mavg() * 100
        
        # 4. ATR for volatility
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=14).average_true_range()
        df['atr_pct'] = df['atr'] / df['close'] * 100

        # 5. RSI for overbought/oversold detection
        rsi_series = ta.momentum.RSIIndicator(df['close'], window=14).rsi()
        rsi_clean = rsi_series.dropna()
        
        # QUY TẮC BẤT DI BẤT DỊCH: Nến iloc[-1] là nến đang chạy (chưa đóng cửa).
        # Bắt buộc neo vào nến đã đóng hoàn toàn (iloc[-2] nếu len >= 2) để chống bẫy râu giật tức thời!
        clean_df = df.dropna(subset=['adx', 'di_plus', 'di_minus', 'ema_20', 'ema_50', 'bb_width', 'atr_pct'])
        if len(clean_df) >= 2:
            latest = clean_df.iloc[-2]
            rsi_val = float(rsi_clean.iloc[-2]) if len(rsi_clean) >= 2 else (float(rsi_clean.iloc[-1]) if not rsi_clean.empty else 50.0)
        else:
            latest = clean_df.iloc[-1] if not clean_df.empty else None
            rsi_val = float(rsi_clean.iloc[-1]) if not rsi_clean.empty else 50.0

        if latest is None:
            return {'regime': MarketRegime.RANGING, 'confidence': 0.0, 'adx': 0.0, 'atr_pct': 0.0, 'rsi': 50.0, 'details': {}}
        
        adx_val = latest['adx']
        di_plus = latest['di_plus']
        di_minus = latest['di_minus']
        ema_20 = latest['ema_20']
        ema_50 = latest['ema_50']
        ema_200 = latest['ema_200'] if pd.notna(latest.get('ema_200')) else ema_50
        bb_width = latest['bb_width']
        atr_pct = latest['atr_pct']
        price = latest['close']
        
        # Determine regime
        ema_bullish = (ema_20 > ema_50) and (price > ema_50)
        ema_bullish_full = ema_20 > ema_50 > ema_200
        ema_bearish = (ema_20 < ema_50) and (price < ema_50)
        ema_bearish_full = ema_20 < ema_50 < ema_200
        trend_up = di_plus > di_minus
        trend_down = di_minus > di_plus
        is_high_vol = atr_pct > 5 or bb_width > 8
        
        # 1. STRONG DOWNTREND (Xả mạnh, cấm bắt dao rơi):
        if trend_down and (ema_bearish or ema_bearish_full) and (adx_val > 35 or is_high_vol):
            regime = MarketRegime.STRONG_DOWNTREND
            confidence = min(1.0, max(adx_val / 60, (atr_pct / 8) if is_high_vol else 0.7))
        # 2. STRONG UPTREND (Bão tăng mạnh):
        elif trend_up and (ema_bullish or ema_bullish_full) and (adx_val > 35 or is_high_vol):
            regime = MarketRegime.STRONG_UPTREND
            confidence = min(1.0, max(adx_val / 60, (atr_pct / 8) if is_high_vol else 0.7))
        # 3. DOWNTREND:
        elif adx_val > 25 and trend_down and (ema_bearish or price < ema_50):
            regime = MarketRegime.DOWNTREND
            confidence = min(1.0, adx_val / 50)
        # 4. UPTREND:
        elif adx_val > 25 and trend_up and (ema_bullish or price > ema_50):
            regime = MarketRegime.UPTREND
            confidence = min(1.0, adx_val / 50)
        # 5. HIGH VOLATILITY (Biến động giật hai chiều, không rõ xu hướng):
        elif is_high_vol:
            regime = MarketRegime.HIGH_VOLATILITY
            confidence = min(1.0, atr_pct / 8)
        # 6. RANGING (Đi ngang tích lũy):
        else:
            regime = MarketRegime.RANGING
            confidence = max(0.3, 1.0 - adx_val / 40)
        
        # Strategy recommendation
        strategy_rec = self._recommend_strategy(regime)
        
        return {
            'regime': regime,
            'regime_name': regime.value,
            'confidence': round(confidence, 4),
            'adx': round(adx_val, 2),
            'di_plus': round(di_plus, 2),
            'di_minus': round(di_minus, 2),
            'bb_width': round(bb_width, 2),
            'atr_pct': round(atr_pct, 4),
            'rsi': round(float(rsi_val), 2),
            'ema_alignment': 'bullish' if ema_bullish else ('bearish' if ema_bearish else 'mixed'),
            'recommended_strategy': strategy_rec,
            'risk_multiplier': self._risk_multiplier(regime)
        }
    
    def _recommend_strategy(self, regime: MarketRegime) -> Dict:
        recs = {
            MarketRegime.STRONG_UPTREND: {
                'primary': 'trend_following', 
                'secondary': 'smart_dca',
                'direction': 'LONG_ONLY',
                'note': 'Strong trend - ride it with trend following'
            },
            MarketRegime.UPTREND: {
                'primary': 'trend_following',
                'secondary': 'mean_reversion', 
                'direction': 'LONG_BIAS',
                'note': 'Moderate uptrend - trend following with pullback entries'
            },
            MarketRegime.RANGING: {
                'primary': 'mean_reversion',
                'secondary': 'smart_dca',
                'direction': 'NEUTRAL',
                'note': 'Range-bound - buy support, sell resistance'
            },
            MarketRegime.DOWNTREND: {
                'primary': 'smart_dca',
                'secondary': 'mean_reversion',
                'direction': 'SHORT_BIAS',
                'note': 'Downtrend - DCA cautiously or short (futures)'
            },
            MarketRegime.STRONG_DOWNTREND: {
                'primary': 'momentum_breakout',
                'secondary': 'trend_following',
                'direction': 'SHORT_ONLY',
                'note': 'Strong downtrend - prioritize breakdowns & shorting'
            },
            MarketRegime.HIGH_VOLATILITY: {
                'primary': 'momentum_breakout',
                'secondary': 'trend_following',
                'direction': 'MOMENTUM_EXPANSION',
                'note': 'High volatility - trade explosive breakouts/breakdowns, do not stay idle'
            }
        }
        return recs.get(regime, recs[MarketRegime.RANGING])
    
    def _risk_multiplier(self, regime: MarketRegime) -> float:
        """Adjust risk based on market regime."""
        multipliers = {
            MarketRegime.STRONG_UPTREND: 1.2,
            MarketRegime.UPTREND: 1.0,
            MarketRegime.RANGING: 0.8,
            MarketRegime.DOWNTREND: 0.6,
            MarketRegime.STRONG_DOWNTREND: 0.5,
            MarketRegime.HIGH_VOLATILITY: 0.7
        }
        return multipliers.get(regime, 0.5)
