"""Bộ điều phối dùng chung cho mọi request Ollama trong tiến trình.

Một GPU/model chỉ phục vụ một generation tại một thởi điểm. Pha 2 được đánh dấu
để tác vụ vĩ mô nền không chiếm hàng đợi trước JEV đang thẩm định ứng viên.
"""
import threading


OLLAMA_GPU_LOCK = threading.RLock()
_PHASE2_LOCK = threading.Lock()
_PHASE2_DEPTH = 0


def ollama_phase2_enter() -> None:
    global _PHASE2_DEPTH
    with _PHASE2_LOCK:
        _PHASE2_DEPTH += 1


def ollama_phase2_exit() -> None:
    global _PHASE2_DEPTH
    with _PHASE2_LOCK:
        _PHASE2_DEPTH = max(0, _PHASE2_DEPTH - 1)


def ollama_phase2_active() -> bool:
    with _PHASE2_LOCK:
        return _PHASE2_DEPTH > 0
