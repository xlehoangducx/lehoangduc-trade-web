import requests
import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)
_SHARED_REQUEST_CACHE = {}
_SHARED_RSS_CACHE = {'headlines': [], 'timestamp': 0.0}
_SHARED_CACHE_LOCK = threading.RLock()

class NewsSentimentAnalyzer:
    """
    Phân tích tin tức và sentiment thị trường crypto từ các nguồn miễn phí.
    Không cần API key.
    """
    
    def __init__(self, config: dict = None):
        self.config = config or {}
        # Shared within the process because dashboard and AI create analyzer
        # instances independently. This prevents duplicate calls and lets a
        # recent successful response bridge a temporary source outage.
        self.cache = _SHARED_REQUEST_CACHE
        self.cache_ttl = 300  # 5 minutes cache
        self.max_stale_seconds = 3600
        self.last_request_stale = {}
        self.news_cache_stale = False
    
    def _cached_request(self, url: str, cache_key: str) -> Optional[dict]:
        """GET request with simple caching."""
        now = datetime.now().timestamp()
        with _SHARED_CACHE_LOCK:
            cached = self.cache.get(cache_key)
        if cached:
            data, ts = cached
            if now - ts < self.cache_ttl:
                self.last_request_stale[cache_key] = False
                return data
        
        try:
            resp = requests.get(url, timeout=10, headers={'Accept': 'application/json'})
            if resp.status_code == 200:
                data = resp.json()
                with _SHARED_CACHE_LOCK:
                    self.cache[cache_key] = (data, now)
                self.last_request_stale[cache_key] = False
                return data
            logger.warning('API returned %s for %s', resp.status_code, url)
        except Exception as e:
            logger.warning('Request error for %s: %s', url, e)

        if cached and now - cached[1] <= self.max_stale_seconds:
            self.last_request_stale[cache_key] = True
            logger.warning('Using cached %s data after source failure.', cache_key)
            return cached[0]
        self.last_request_stale[cache_key] = False
        return None
    
    def get_fear_greed_index(self) -> Dict:
        """Get Fear & Greed Index (0=Extreme Fear, 100=Extreme Greed)."""
        data = self._cached_request(
            'https://api.alternative.me/fng/?limit=7',
            'fear_greed'
        )
        if data and 'data' in data:
            latest = data['data'][0]
            history = data['data']
            return {
                'value': int(latest['value']),
                'label': latest['value_classification'],
                'timestamp': latest['timestamp'],
                'trend': self._calculate_fng_trend(history),
                'signal': self._fng_to_signal(int(latest['value'])),
                'available': True,
            }
        return {
            'value': 50, 'label': 'Unavailable', 'signal': 'HOLD',
            'trend': 'stable', 'available': False,
        }
    
    def _fng_to_signal(self, value: int) -> str:
        """Convert Fear & Greed to trading signal."""
        if value <= 20:  # Extreme Fear = buying opportunity
            return 'STRONG_BUY'
        elif value <= 35:
            return 'BUY'
        elif value >= 80:  # Extreme Greed = selling opportunity
            return 'STRONG_SELL'
        elif value >= 65:
            return 'SELL'
        return 'HOLD'
    
    def _calculate_fng_trend(self, history: list) -> str:
        """Calculate FNG trend from history."""
        if len(history) < 2:
            return 'stable'
        values = [int(h['value']) for h in history]
        if values[0] > values[-1] + 10:
            return 'rising'  # Getting greedy
        elif values[0] < values[-1] - 10:
            return 'falling'  # Getting fearful
        return 'stable'
    
    def get_market_overview(self, coin_id: str = 'bitcoin') -> Dict:
        """Get market overview from CoinGecko."""
        data = self._cached_request(
            f'https://api.coingecko.com/api/v3/coins/{coin_id}?localization=false&tickers=false&community_data=false&developer_data=false',
            f'market_{coin_id}'
        )
        if data and 'market_data' in data:
            md = data['market_data']
            return {
                'price': md.get('current_price', {}).get('usd', 0),
                'change_24h': md.get('price_change_percentage_24h', 0),
                'change_7d': md.get('price_change_percentage_7d', 0),
                'change_30d': md.get('price_change_percentage_30d', 0),
                'market_cap_rank': data.get('market_cap_rank', 0),
                'ath_change_pct': md.get('ath_change_percentage', {}).get('usd', 0),
                'total_volume_24h': md.get('total_volume', {}).get('usd', 0),
                'signal': self._price_change_signal(md.get('price_change_percentage_24h', 0))
            }
        return {}
    
    def _price_change_signal(self, change_24h: float) -> str:
        if change_24h > 5:
            return 'OVERBOUGHT'
        elif change_24h < -5:
            return 'OVERSOLD'
        elif change_24h > 2:
            return 'BULLISH'
        elif change_24h < -2:
            return 'BEARISH'
        return 'NEUTRAL'
    
    def get_latest_news(self) -> List[str]:
        """Đọc tin tức mới nhất từ Cointelegraph RSS để LLM phân tích."""
        import xml.etree.ElementTree as ET
        now = datetime.now().timestamp()
        with _SHARED_CACHE_LOCK:
            cached_news = list(_SHARED_RSS_CACHE['headlines'])
            cached_news_timestamp = _SHARED_RSS_CACHE['timestamp']
        if cached_news and now - cached_news_timestamp < self.cache_ttl:
            self.news_cache_stale = False
            return cached_news
        try:
            resp = requests.get('https://cointelegraph.com/rss', timeout=10)
            if resp.status_code == 200:
                root = ET.fromstring(resp.content)
                headlines = []
                for item in root.findall('./channel/item')[:5]:
                    title_node = item.find('title')
                    title = (title_node.text or '').strip() if title_node is not None else ''
                    if title:
                        import re
                        safe_title = re.sub(r'[^\w\s.,!?''"-]', '', title).strip()
                        headlines.append(safe_title[:300])
                if headlines:
                    with _SHARED_CACHE_LOCK:
                        _SHARED_RSS_CACHE['headlines'] = list(headlines)
                        _SHARED_RSS_CACHE['timestamp'] = now
                    self.news_cache_stale = False
                return headlines
            logger.warning('RSS returned %s for Cointelegraph.', resp.status_code)
        except Exception as e:
            logger.warning('RSS request failed: %s', e)
        if cached_news and now - cached_news_timestamp <= self.max_stale_seconds:
            self.news_cache_stale = True
            logger.warning('Using cached RSS headlines after source failure.')
            return cached_news
        self.news_cache_stale = False
        return []

    def get_trending_coins(self) -> List[Dict]:
        """Get trending coins from CoinGecko."""
        data = self._cached_request(
            'https://api.coingecko.com/api/v3/search/trending',
            'trending'
        )
        if data and 'coins' in data:
            return [{
                'name': c['item']['name'],
                'symbol': c['item']['symbol'],
                'market_cap_rank': c['item'].get('market_cap_rank', 999),
                'score': c['item'].get('score', 0)
            } for c in data['coins'][:10]]
        return []
    
    def get_composite_sentiment(self, symbol: str = 'BTC') -> Dict:
        """
        Tổng hợp sentiment từ tất cả nguồn.
        Returns score from -1.0 (extreme bearish) to +1.0 (extreme bullish)
        """
        scores = []
        details = {}
        
        # 1. Fear & Greed Index
        fng = self.get_fear_greed_index()
        details['fear_greed'] = fng
        if fng.get('available'):
            fng_score = (fng['value'] - 50) / 50  # Normalize to [-1, 1]
            # Contrarian: extreme fear = bullish, extreme greed = bearish
            contrarian_fng = -fng_score  # Flip for contrarian
            scores.append(('fear_greed_contrarian', contrarian_fng, 0.4))
        
        # 2. Market data
        coin_map = {'BTC': 'bitcoin', 'ETH': 'ethereum', 'SOL': 'solana', 'BNB': 'binancecoin'}
        coin_id = coin_map.get(symbol.split('/')[0] if '/' in symbol else symbol, 'bitcoin')
        market = self.get_market_overview(coin_id)
        if market:
            # Momentum score based on price changes
            change_24h = market.get('change_24h', 0)
            momentum = max(-1.0, min(1.0, change_24h / 10))  # +-10% = +-1.0
            scores.append(('momentum_24h', momentum, 0.3))
            details['market'] = market
        
        # 3. Trending coins
        trending = self.get_trending_coins()
        coin_symbol = symbol.split('/')[0] if '/' in symbol else symbol
        is_trending = any(t['symbol'].upper() == coin_symbol.upper() for t in trending)
        trend_score = 0.3 if is_trending else 0.0
        scores.append(('trending', trend_score, 0.15))
        details['trending'] = trending[:5]
        
        # Calculate weighted composite score
        if not scores:
            return {'score': 0.0, 'signal': 'HOLD', 'confidence': 0.0, 'details': {}}
        
        total_weight = sum(w for _, _, w in scores)
        composite = sum(s * w for _, s, w in scores) / total_weight if total_weight > 0 else 0
        
        # Determine signal
        if composite > 0.3:
            signal = 'BUY'
        elif composite < -0.3:
            signal = 'SELL'
        else:
            signal = 'HOLD'
        
        confidence = min(1.0, abs(composite))
        
        return {
            'score': round(composite, 4),
            'signal': signal,
            'confidence': round(confidence, 4),
            'details': details,
            'components': {name: round(score, 4) for name, score, _ in scores},
            'timestamp': datetime.now().isoformat()
        }

    def get_binance_derivatives_data(self, symbol: str = 'BTCUSDT') -> Dict:
        """
        Lấy dữ liệu phái sinh trực tiếp từ Binance Futures hoàn toàn MIỄN PHÍ (không cần API key):
        - Giá, Biến động 24h, Khối lượng USDT
        - Tỷ lệ Long/Short đám đông (Retail)
        - Vị thế Top Trader / Smart Money
        - Funding Rate
        - Taker Buy/Sell Volume Ratio
        - Open Interest (OI)
        """
        clean_sym = symbol.replace('/', '').replace(':', '').upper()
        if not clean_sym.endswith('USDT'):
            clean_sym += 'USDT'
        cache_key = f"binance_deriv_{clean_sym}"
        now = datetime.now().timestamp()
        with _SHARED_CACHE_LOCK:
            cached = self.cache.get(cache_key)
        if cached and (now - cached[1] < self.cache_ttl):
            return cached[0]

        data = {'symbol': clean_sym, 'available': False}
        headers = {'User-Agent': 'Mozilla/5.0'}
        try:
            r = requests.get(f'https://fapi.binance.com/fapi/v1/ticker/24hr?symbol={clean_sym}', timeout=4, headers=headers)
            if r.status_code == 200:
                t = r.json()
                data['price'] = float(t.get('lastPrice', 0))
                data['change_24h'] = float(t.get('priceChangePercent', 0))
                data['high_24h'] = float(t.get('highPrice', 0))
                data['low_24h'] = float(t.get('lowPrice', 0))
                data['volume_usdt'] = float(t.get('quoteVolume', 0))
                data['available'] = True
        except Exception as e:
            logger.debug(f"Binance ticker failed for {clean_sym}: {e}")

        try:
            r = requests.get(f'https://fapi.binance.com/fapi/v1/openInterest?symbol={clean_sym}', timeout=4, headers=headers)
            if r.status_code == 200:
                data['open_interest'] = float(r.json().get('openInterest', 0))
        except Exception:
            pass

        try:
            r = requests.get(f'https://fapi.binance.com/fapi/v1/fundingRate?symbol={clean_sym}&limit=1', timeout=4, headers=headers)
            if r.status_code == 200 and r.json():
                data['funding_rate_pct'] = float(r.json()[0].get('fundingRate', 0)) * 100
        except Exception:
            pass

        try:
            r = requests.get(f'https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol={clean_sym}&period=5m&limit=1', timeout=4, headers=headers)
            if r.status_code == 200 and r.json():
                item = r.json()[0]
                data['retail_long_pct'] = float(item.get('longAccount', 0)) * 100
                data['retail_short_pct'] = float(item.get('shortAccount', 0)) * 100
                data['retail_ratio'] = float(item.get('longShortRatio', 1.0))
        except Exception:
            pass

        try:
            r = requests.get(f'https://fapi.binance.com/futures/data/topLongShortPositionRatio?symbol={clean_sym}&period=5m&limit=1', timeout=4, headers=headers)
            if r.status_code == 200 and r.json():
                item = r.json()[0]
                data['whale_long_pct'] = float(item.get('longAccount', 0)) * 100
                data['whale_short_pct'] = float(item.get('shortAccount', 0)) * 100
                data['whale_ratio'] = float(item.get('longShortRatio', 1.0))
        except Exception:
            pass

        try:
            r = requests.get(f'https://fapi.binance.com/futures/data/takerlongshortRatio?symbol={clean_sym}&period=5m&limit=1', timeout=4, headers=headers)
            if r.status_code == 200 and r.json():
                item = r.json()[0]
                data['taker_buy_sell_ratio'] = float(item.get('buySellRatio', 1.0))
        except Exception:
            pass

        if data.get('available'):
            with _SHARED_CACHE_LOCK:
                self.cache[cache_key] = (data, now)
        return data

    def get_tradfi_macro(self) -> Dict:
        """
        Lấy thông tin vĩ mô chứng khoán Mỹ & vàng từ Yahoo Finance hoàn toàn MIỄN PHÍ:
        - S&P 500 (^GSPC)
        - Nasdaq (^IXIC)
        - DXY - Chỉ số USD (DX-Y.NYB)
        - Vàng thế giới (GC=F)
        """
        cache_key = "tradfi_macro"
        now = datetime.now().timestamp()
        with _SHARED_CACHE_LOCK:
            cached = self.cache.get(cache_key)
        if cached and (now - cached[1] < self.cache_ttl):
            return cached[0]

        symbols = {'^GSPC': 'S&P 500', '^IXIC': 'Nasdaq', 'DX-Y.NYB': 'DXY (USD)', 'GC=F': 'Vang (Gold)'}
        results = {}
        headers = {'User-Agent': 'Mozilla/5.0'}
        for sym, name in symbols.items():
            try:
                url = f'https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=1d&range=2d'
                r = requests.get(url, headers=headers, timeout=4)
                if r.status_code == 200:
                    meta = r.json().get('chart', {}).get('result', [{}])[0].get('meta', {})
                    price = meta.get('regularMarketPrice', 0)
                    prev = meta.get('previousClose', price)
                    chg = ((price - prev) / prev * 100) if prev else 0.0
                    results[name] = {'price': price, 'change_pct': round(chg, 2)}
            except Exception:
                pass

        if results:
            with _SHARED_CACHE_LOCK:
                self.cache[cache_key] = (results, now)
        return results

