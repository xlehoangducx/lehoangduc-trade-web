from ai.order_flow_analyzer import OrderFlowAnalyzer
import logging

import re

import math

import statistics

import sys

import time

import threading

from typing import Dict, List, Optional, Tuple



if sys.platform == 'win32':

    try:

        sys.stdout.reconfigure(encoding='utf-8')

        sys.stderr.reconfigure(encoding='utf-8')

    except Exception:

        pass



from strategies.base_strategy import TradeSignal, Signal

from core.scanner import MarketScanner



logger = logging.getLogger(__name__)





def _chop_entry_is_measured(entry) -> bool:

    """True nếu bối cảnh BTC/ETH là số đo THẬT (không phải 0.0 do thiếu dữ liệu).



    MarketRegimeDetector.detect_regime() trả ``adx=0.0, atr_pct=0.0`` khi không đủ

    100 nến để tính chỉ báo. Nếu coi 0.0 là "đã đo và đang nén" thì CRYPTO CHOP

    SHIELD sẽ bật ở mọi chu kỳ và khóa 100% lệnh Altcoin vô thời hạn — đúng cái bẫy

    "Chop Shield vô hạn" của Bài học 11/39. Vì vậy 0.0 bị coi là CHƯA ĐO ĐƯỢC.

    """

    if not isinstance(entry, dict) or not entry:

        return False

    try:

        adx_val = float(entry.get('adx') or 0.0)

    except (TypeError, ValueError, OverflowError):

        adx_val = 0.0

    try:

        atr_val = float(entry.get('atr_pct') or 0.0)

    except (TypeError, ValueError, OverflowError):

        atr_val = 0.0

    return adx_val > 0.0 or atr_val > 0.0


def classify_symbol_tier(symbol_name: str, exchange=None) -> str:
    """Phân lớp tài sản SSOT: 'TIER1' (Major Crypto), 'TRADFI', hoặc 'ALTCOIN'."""
    clean_base = MarketScanner._clean_base(symbol_name)
    if clean_base in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'):
        return 'TIER1'
    is_stock = MarketScanner.is_tradfi_stock(symbol_name, exchange)
    is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol_name, exchange)
    if is_stock or is_commodity:
        return 'TRADFI'
    return 'ALTCOIN'


def compute_smart_flow_thresholds(asset_tier: str, atr_pct: float) -> Dict[str, float]:
    """Single Source of Truth cho toàn bộ ngưỡng Waterfall, Climax và Whale Pump Storm."""
    try:
        atr_val = float(atr_pct or 0.0)
    except (TypeError, ValueError):
        atr_val = 0.0
    # [BOM #132 FIX]: Mọi caller truyền tactical_atr_pct / atr_pct từ market_analysis (luôn ở đơn vị %, vd 0.05 = 0.05%, 1.50 = 1.50%) -> luôn chia 100.0!
    eff_atr = max(0.0, atr_val) / 100.0

    if asset_tier == 'TRADFI':
        min_wf = min(0.020, max(0.010, 1.10 * eff_atr)) if eff_atr > 0 else 0.010
        max_wf = max(0.045, min(0.065, 2.2 * eff_atr)) if eff_atr > 0 else 0.045
        wf_rvol_std = 1.25
        wp_rvol_std = 1.50
        return {
            'eff_atr': eff_atr,
            'min_trap_rvol': 0.85,
            'parabolic_thresh': 0.040,
            'parabolic_ext': 0.052,
            'min_waterfall_dump': min_wf,
            'max_waterfall_dump': max_wf,
            'wf_rvol_std': wf_rvol_std,
            'wf_rvol_low': max(1.15, wf_rvol_std - 0.10),
            'wf_rvol_high': wf_rvol_std + 0.20,
            'wf_shape_dump_floor': 0.018,
            'wf_shape_pump_cap': 0.006,
            'min_climax_wave': 0.010,
            'climax_rvol': 1.05,
            'min_whale_pump': min_wf,
            'wp_rvol_std': wp_rvol_std,
            'wp_rvol_high': wp_rvol_std + 0.50,
        }
    if asset_tier == 'TIER1':
        min_wf = min(0.022, max(0.010, 1.20 * eff_atr)) if eff_atr > 0 else 0.010
        max_wf = max(0.035, min(0.050, 2.3 * eff_atr)) if eff_atr > 0 else 0.035
        # [BOM #150 P1 FIX]: Nâng wf_rvol_std Major lên 2.20x khớp VK5_MAJOR_VBOTTOM_GUARD (bot.py)
        # để kèo Major Trend SELL RVol 1.20x..2.19x giữ nguyên VK8 thay vì bị cướp sang VK5 rồi bị giết oan!
        wf_rvol_std = 2.20
        wp_rvol_std = 1.60
        return {
            'eff_atr': eff_atr,
            'min_trap_rvol': 1.00,
            'parabolic_thresh': 0.032,
            'parabolic_ext': 0.042,
            'min_waterfall_dump': min_wf,
            'max_waterfall_dump': max_wf,
            'wf_rvol_std': wf_rvol_std,
            'wf_rvol_low': 2.20,
            'wf_rvol_high': 2.40,
            'wf_shape_dump_floor': 0.018,
            'wf_shape_pump_cap': 0.006,
            'min_climax_wave': 0.010,
            'climax_rvol': 1.05,
            'min_whale_pump': min_wf,
            'wp_rvol_std': wp_rvol_std,
            'wp_rvol_high': wp_rvol_std + 0.50,
        }
    # ALTCOIN
    min_wf = min(0.038, max(0.020, 1.25 * eff_atr)) if eff_atr > 0 else 0.020
    max_wf = max(0.055, min(0.080, 2.3 * eff_atr)) if eff_atr > 0 else 0.055
    wf_rvol_std = 1.30
    min_wp = min(0.035, max(0.025, 1.25 * eff_atr)) if eff_atr > 0 else 0.025
    wp_rvol_std = 2.00
    return {
        'eff_atr': eff_atr,
        'min_trap_rvol': 1.10,
        'parabolic_thresh': 0.055,
        'parabolic_ext': 0.070,
        'min_waterfall_dump': min_wf,
        'max_waterfall_dump': max_wf,
        'wf_rvol_std': wf_rvol_std,
        'wf_rvol_low': max(1.15, wf_rvol_std - 0.10),
        'wf_rvol_high': wf_rvol_std + 0.20,
        'wf_shape_dump_floor': 0.030,
        'wf_shape_pump_cap': 0.010,
        'min_climax_wave': 0.018,
        'climax_rvol': 1.25,
        'min_whale_pump': min_wp,
        'wp_rvol_std': wp_rvol_std,
        'wp_rvol_high': wp_rvol_std + 0.50,
    }





class SignalAggregator:

    """Combine strategy votes without letting HOLD signals dilute them."""



    _recent_chop_vetoes: Dict[str, float] = {}

    _crypto_market_chop_until: float = 0.0

    INVERSE_PAIRS: Dict[str, str] = {
        'SOXL/USDT': 'SOXS/USDT',
        'SOXS/USDT': 'SOXL/USDT',
        'TQQQ/USDT': 'SQQQ/USDT',
        'SQQQ/USDT': 'TQQQ/USDT',
        'UPRO/USDT': 'SPXU/USDT',
        'SPXU/USDT': 'UPRO/USDT',
        'NVDL/USDT': 'NVDD/USDT',
        'NVDD/USDT': 'NVDL/USDT',
        'TSLL/USDT': 'TSLS/USDT',
        'TSLS/USDT': 'TSLL/USDT',
        'MSTU/USDT': 'MSTZ/USDT',
        'MSTZ/USDT': 'MSTU/USDT',
    }



    def __init__(self, config: dict = None):

        config = config or {}
        self.config = config
        ai_config = config.get('ai', {})
        self.ai_config = ai_config
        self.consensus_require_technical = bool(ai_config.get('consensus_require_technical', True))

        self.confidence_threshold = float(ai_config.get('confidence_threshold', 0.6))

        # [NGƯỠNG CHẤT LƯỢNG TÍN HIỆU] Sàn điểm tối thiểu của |weighted score| để được cấp lệnh.

        # Tách RIÊNG khỏi confidence_threshold vì confidence_threshold còn được dùng cho ngưỡng

        # động của AI Ensemble và chất lượng đòn bẩy; nếu gộp chung sẽ làm lệch các tầng đó.

        # Hiệu lực = max(confidence_threshold, min_signal_score).

        self.min_signal_score = float(ai_config.get('min_signal_score', 0.80))

        if not (0.0 <= self.min_signal_score <= 1.0):

            self.min_signal_score = 0.80

        self.min_agreeing_strategies = max(

            1, int(ai_config.get('min_agreeing_strategies', 2))

        )

        self._agg_lock = threading.RLock()

        self._trap_contexts_by_symbol = {}
        self._last_veto_info: Dict[str, dict] = {}

        self._last_trap_context = {}

        # [P2] HTF CONFLICT VETO: chặn mở lệnh khi CÙNG MỘT chiến thuật báo ngược chiều

        # trên 2 khung thời gian khác nhau với độ tự tin >= ngưỡng. Trước đây

        # `_strategy_votes()` lấy trung bình cộng các khung (trap 1h SELL 67% + 15m BUY 70%

        # -> +0.015), xóa sạch thông tin xung đột và vẫn cho vào lệnh.

        self.htf_conflict_veto = bool(ai_config.get('htf_conflict_veto', True))

        try:

            self.htf_conflict_min_confidence = float(

                ai_config.get('htf_conflict_min_confidence', 0.60)

            )

        except (TypeError, ValueError, OverflowError):

            self.htf_conflict_min_confidence = 0.60

        if not (0.0 < self.htf_conflict_min_confidence <= 1.0):

            self.htf_conflict_min_confidence = 0.60



        self.strategy_weights = {}

        for name, strat_config in config.get('strategies', {}).items():

            if isinstance(strat_config, dict):

                self.strategy_weights[name] = float(strat_config.get('weight', 0.25))



        if not self.strategy_weights:

            self.strategy_weights = {

                'trend_following': 0.3,

                'mean_reversion': 0.25,

                'ai_ensemble': 0.2,

                'jev_agent': 0.3,

                'smart_dca': 0.15,

                'hft_scalping': 0.25,

                'trap_detector': 0.25,

                'momentum_breakout': 0.25,

            }

        self._recent_chop_vetoes = {}

        self._crypto_market_chop_until = 0.0
        try:
            self.order_flow_analyzer = OrderFlowAnalyzer()
        except Exception:
            self.order_flow_analyzer = None

    @staticmethod
    def _clear_stale_weapon_metadata(sig: TradeSignal) -> None:
        """[BOM #116D FIX]: Xóa sạch nhãn vũ khí/slot cũ khi Smart Inversion đảo chiều lệnh."""
        meta = getattr(sig, 'metadata', None)
        if not isinstance(meta, dict):
            return
        for _stale_inv_k in (
            'weapon_id', 'weapon_code', 'weapon_name_vi', 'weapon_icon',
            'm1_cks_urgency_k', 'm1_ofi_limit', 'quantum_archetype',
            'dyn_regime_mode', 'dyn_veto_gate_match', 'dyn_expected_ai_votes',
            'dyn_slot', 'dyn_pathway_family', 'dyn_dna_rules',
            'dyn_source_signature', 'dyn_pre_veto_gate', 'position_size_multiplier',
        ):
            meta.pop(_stale_inv_k, None)
        meta['is_dynamic_weapon'] = False
        meta['is_experimental_weapon'] = False
        meta['is_parabolic_long_inversion'] = False
        meta['is_parabolic_altcoin'] = False
        meta['is_vk9_climax_wick_short'] = False
        meta['is_vk10_tradfi_bottom_long'] = False
        meta['is_fading_short'] = False
        meta['is_waterfall_short'] = False
        meta['is_momentum_ride'] = False
        meta['is_oversold_bounce'] = False

    def _record_veto(self, symbol: str, gate: str, direction: str = '', reason: str = '', weapon_id: str = ''):
        """[BOM #97 FIX]: Luu thong tin cong Veto chinh xac de ShadowPathfinder ghi dung chieu & dung tram."""
        if not symbol:
            return
        info = {
            'gate': str(gate or ''),
            'direction': str(direction or '').upper(),
            'reason': str(reason or ''),
            'weapon_id': str(weapon_id or ''),
            'ts': time.time(),
        }
        clean_s = str(symbol).split(':')[0].strip().upper()
        with getattr(self, '_agg_lock', threading.RLock()):
            self._last_veto_info[symbol] = info
            self._last_veto_info[clean_s] = info
            self._last_veto_info[clean_s.replace('/', '')] = info

    def get_last_veto_info(self, symbol: str) -> Optional[dict]:
        if not symbol:
            return None
        clean_s = str(symbol).split(':')[0].strip().upper()
        with getattr(self, '_agg_lock', threading.RLock()):
            info = (
                self._last_veto_info.get(symbol)
                or self._last_veto_info.get(clean_s)
                or self._last_veto_info.get(clean_s.replace('/', ''))
            )
            if info and (time.time() - float(info.get('ts', 0.0))) <= 120.0:
                return dict(info)
        return None



    def _strategy_votes(

        self,

        signals: List[TradeSignal],

        apply_entry_vetoes: bool = True,

        log_vetoes: Optional[bool] = None,

        market_chop_context: Optional[Dict[str, Dict[str, float]]] = None,

    ) -> Dict[str, Tuple[float, float]]:

        """Return one weighted vote per strategy, combining its actionable timeframes."""

        if not signals:

            return {}

        if log_vetoes is None:

            log_vetoes = bool(apply_entry_vetoes)

        by_strategy: Dict[str, List[float]] = {}



        for sig in signals:

            if sig.signal == Signal.BUY:

                direction = 1.0

            elif sig.signal == Signal.SELL:

                direction = -1.0

            else:

                # Tuyệt đối không đưa Signal.HOLD (direction = 0.0) vào mẫu số tổng hợp để tránh làm loãng

                # 31% - 40% điểm raw_score khi giám sát vị thế mở (Cổng JEV HOLD Veto >= 0.70 đã xử lý riêng ở bước lọc vào lệnh).

                continue



            try:

                confidence = float(sig.confidence)

            except (TypeError, ValueError):

                continue

            if math.isnan(confidence) or not (0.0 <= confidence <= 1.0):

                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', sig.strategy).lower()

            by_strategy.setdefault(name, []).append(direction * confidence)



        votes: Dict[str, Tuple[float, float]] = {}



        symbol_name = str(getattr(signals[0], 'symbol', '') or '')
        clean_base = MarketScanner._clean_base(symbol_name)
        is_tier1 = any(clean_base == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
        _agg_ex = getattr(getattr(self, 'order_flow_analyzer', None), 'exchange', None)
        is_stock = MarketScanner.is_tradfi_stock(symbol_name, exchange=_agg_ex)
        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol_name, exchange=_agg_ex)
        is_tradfi = is_stock or is_commodity
        is_crypto_altcoin = (not is_tier1) and (not is_tradfi)



        # Trích xuất phân tích nến đóng iloc[-2] từ market_analysis để nhận diện sớm Buying/Selling Climax & Bão Volume

        macro_analysis_pre = next(

            (

                s.metadata.get('market_analysis')

                for s in signals

                if isinstance(getattr(s, 'metadata', None), dict)

                and isinstance(s.metadata.get('market_analysis'), dict)

            ),

            {},

        )

        c_upper_wick_pre = float(macro_analysis_pre.get('upper_wick_pct') or 0.0)

        c_lower_wick_pre = float(macro_analysis_pre.get('lower_wick_pct') or 0.0)

        _raw_c_vol_pre = macro_analysis_pre.get('candle_vol_ratio')
        if _raw_c_vol_pre is None:
            _raw_c_vol_pre = next(
                (
                    (s.metadata or {}).get('c_vol_ratio')
                    for s in signals
                    if isinstance(getattr(s, 'metadata', None), dict)
                    and (s.metadata or {}).get('c_vol_ratio') is not None
                ),
                None,
            )
        c_vol_ratio_pre = float(_raw_c_vol_pre) if _raw_c_vol_pre is not None else 1.0

        c_recent_pump_pre = float(macro_analysis_pre.get('recent_pump_pct') or 0.0)

        c_recent_dump_pre = float(macro_analysis_pre.get('recent_dump_pct') or 0.0)

        in_fading_short_wl_pre = bool(macro_analysis_pre.get('in_fading_short_watchlist', False))
        is_live_rebounding_pre = bool(macro_analysis_pre.get('is_live_rebounding', False))
        is_live_dumping_pre = bool(macro_analysis_pre.get('is_live_dumping', False))

        try:
            tactical_rsi_pre = float(macro_analysis_pre.get('tactical_rsi') or macro_analysis_pre.get('rsi') or 50.0)
        except (TypeError, ValueError):
            tactical_rsi_pre = 50.0

        # Fallback lấy trực tiếp từ metadata của các chiến thuật nếu market_analysis chưa nạp đầy đủ
        if c_upper_wick_pre <= 0.0:
            c_upper_wick_pre = max((float((s.metadata or {}).get('c_upper_wick_pct') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if c_lower_wick_pre <= 0.0:
            c_lower_wick_pre = max((float((s.metadata or {}).get('c_lower_wick_pct') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if c_recent_dump_pre <= 0.0:
            c_recent_dump_pre = max((float((s.metadata or {}).get('c_recent_dump_pct') or (s.metadata or {}).get('recent_dump_pct') or (s.metadata or {}).get('c_recent_dump') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if c_recent_pump_pre <= 0.0:
            c_recent_pump_pre = max((float((s.metadata or {}).get('c_recent_pump_pct') or (s.metadata or {}).get('recent_pump_pct') or (s.metadata or {}).get('c_recent_pump') or 0.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict)), default=0.0)
        if tactical_rsi_pre == 50.0:
            tactical_rsi_pre = next((float((s.metadata or {}).get('tactical_rsi') or 50.0) for s in signals if isinstance(getattr(s, 'metadata', None), dict) and (s.metadata or {}).get('tactical_rsi') is not None), 50.0)

        # [BÀI HỌC 78, 79, 82, 85 & 103]: Nhận diện chuẩn xác Lưỡng Pha Cá Mập Đối Xứng ngay từ đầu _strategy_votes()
        # Chuẩn hóa Ma trận 3 Lớp Tài Sản (Major Crypto, TradFi, Crypto Altcoins) và Đối xứng 2 Chiều (LONG / SHORT)
        is_altcoin_or_tradfi = True  # Mở khóa toàn bộ 3 lớp tài sản (bao gồm cả Major Crypto BTC, ETH, SOL, BNB, XRP)
        tactical_atr_pct_pre = float(macro_analysis_pre.get('tactical_atr_pct') or macro_analysis_pre.get('atr_pct') or 0.0)
        macro_rsi_pre = float(macro_analysis_pre.get('rsi') or 50.0)
        asset_tier_pre = 'TRADFI' if is_tradfi else ('TIER1' if is_tier1 else 'ALTCOIN')
        sf_pre = compute_smart_flow_thresholds(asset_tier_pre, tactical_atr_pct_pre)
        min_trap_rvol = 0.85 if is_tradfi else (1.10 if is_crypto_altcoin else 1.00)
        parabolic_thresh_pre = sf_pre['parabolic_thresh']
        parabolic_ext_pre = sf_pre['parabolic_ext']
        # [V5.5 EXTREME VOLUME STORM SHIELD]:
        # Bão Volume cá mập cực đại (RVol >= 6.0x Altcoin, >= 4.5x Major, >= 3.5x TradFi).
        # Tại ngưỡng bão cực đại này, nến bắt buộc phải có râu từ chối >= 55% mới được coi là đảo chiều.
        # Nếu râu < 55% (thân nến còn > 35-45%), tuyệt đối cấm đoán đỉnh/bắt dao rơi!
        # [BOM #141 FIX - C1]: Ràng buộc ưu thế chiều sóng (pump vs dump) cho Extreme Volume Storm
        # để nến xanh đặc không bị gắn đồng thời is_extreme_bear_storm (và ngược lại)!
        extreme_storm_rvol_pre = 3.5 if is_tradfi else (6.0 if is_crypto_altcoin else 4.5)
        is_extreme_bull_storm_pre = (
            c_vol_ratio_pre >= extreme_storm_rvol_pre
            and c_upper_wick_pre < 0.55
            and c_recent_pump_pre >= max(0.005, c_recent_dump_pre * 1.15)
        )
        is_extreme_bear_storm_pre = (
            c_vol_ratio_pre >= extreme_storm_rvol_pre
            and c_lower_wick_pre < 0.55
            and c_recent_dump_pre >= max(0.005, c_recent_pump_pre * 1.15)
        )

        # [KB5 CHUẨN HÓA XUNG ĐỘT 1 + BOM #119A FIX]: Bắt buộc phải có Râu nến vật lý (>= 30%, hoặc >= 25% khi biến động cực đại)
        # VÀ đạt sàn thanh khoản RVol 3 lớp tài sản (c_vol_ratio_pre >= min_trap_rvol, chặn nến chết thanh khoản PIEVERSE 0.15x)!
        is_panic_selling_climax_pre = (not is_extreme_bear_storm_pre) and (c_vol_ratio_pre >= min_trap_rvol) and (
            ((c_recent_dump_pre >= parabolic_thresh_pre and c_vol_ratio_pre >= 1.80 and c_lower_wick_pre >= 0.30)
             or (c_recent_dump_pre >= parabolic_ext_pre and c_lower_wick_pre >= 0.25))
        )
        # [V5.5 PARABOLIC ALTCOIN SHIELD]:
        min_uwick_para_pre = 0.40 if is_crypto_altcoin else 0.30
        min_uwick_ext_pre = 0.35 if is_crypto_altcoin else 0.25
        max_rvol_para_pre = 4.50 if is_crypto_altcoin else 999.0
        is_parabolic_pump_climax_pre = (not is_extreme_bull_storm_pre) and (c_vol_ratio_pre >= min_trap_rvol) and (c_vol_ratio_pre < max_rvol_para_pre) and (
            ((c_recent_pump_pre >= parabolic_thresh_pre and c_vol_ratio_pre >= 1.80 and c_upper_wick_pre >= min_uwick_para_pre)
             or (c_recent_pump_pre >= parabolic_ext_pre and c_upper_wick_pre >= min_uwick_ext_pre))
        )

        # 0. Thác đổ không râu đỡ (Waterfall Dump): Cá mập đang xả dốc không có lực hấp thụ đáy
        # [V3.7 SSOT FIX #5]: Dùng đúng ATR tác chiến 15M (tactical_atr_pct) thay vì ATR 4H để đồng bộ 100% với core/bot.py
        min_waterfall_dump_pre = sf_pre['min_waterfall_dump']
        max_waterfall_dump_pre = sf_pre['max_waterfall_dump']
        wf_rvol_std_pre = sf_pre['wf_rvol_std']

        is_waterfall_oversold_bottom_pre = (macro_rsi_pre <= 30.0 or tactical_rsi_pre <= 32.0)
        is_waterfall_dump_shape_pre = (c_upper_wick_pre < 0.28) and (
            c_recent_dump_pre >= max(min_waterfall_dump_pre, c_recent_pump_pre * 1.30)
            or c_recent_dump_pre >= sf_pre['wf_shape_dump_floor']
            or c_recent_pump_pre <= sf_pre['wf_shape_pump_cap']
        )
        is_waterfall_dump_pre = (
            (not is_live_rebounding_pre)
            and (not is_panic_selling_climax_pre)
            and (not is_waterfall_oversold_bottom_pre)
            and is_waterfall_dump_shape_pre
            and (tactical_rsi_pre <= 58.0 or c_recent_dump_pre >= c_recent_pump_pre * 1.5)
            and (
                (min_waterfall_dump_pre <= c_recent_dump_pre <= max_waterfall_dump_pre and c_lower_wick_pre < 0.25 and c_vol_ratio_pre >= wf_rvol_std_pre)
                or ((min_waterfall_dump_pre * 1.35) <= c_recent_dump_pre <= max_waterfall_dump_pre and c_lower_wick_pre < 0.30 and c_vol_ratio_pre >= sf_pre['wf_rvol_low'])
                or (min_waterfall_dump_pre <= c_recent_dump_pre <= max_waterfall_dump_pre and c_lower_wick_pre < 0.20 and c_vol_ratio_pre >= sf_pre['wf_rvol_high'])
            )
        )

        # 1. Nến kiệt sức mua phân phối đỉnh (Buying Climax) & Watchlist Pha 2: Bắt buộc có râu trên vật lý >= 30-35%!
        min_climax_wave_pre = sf_pre['min_climax_wave']
        climax_rvol_pre = sf_pre['climax_rvol']
        has_raw_bull_trap_sig = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and c_vol_ratio_pre >= min_trap_rvol
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
            for s in signals
        )
        min_climax_hard_pump_pre = 0.005 if is_tradfi else 0.007
        min_climax_hard_dump_pre = 0.005 if is_tradfi else 0.007
        is_buying_climax_candle = (not is_extreme_bull_storm_pre) and (
            (c_upper_wick_pre >= 0.45 and c_upper_wick_pre > c_lower_wick_pre * 1.3 and c_vol_ratio_pre >= climax_rvol_pre and c_recent_pump_pre >= min_climax_hard_pump_pre and (c_recent_pump_pre >= min_climax_wave_pre or tactical_rsi_pre >= 58.0))
            or (c_recent_pump_pre >= (0.035 if is_crypto_altcoin else 0.018) and c_upper_wick_pre >= 0.40 and c_vol_ratio_pre >= (1.20 if is_crypto_altcoin else 1.00))
            or (has_raw_bull_trap_sig and c_upper_wick_pre >= 0.35 and c_recent_pump_pre >= min_climax_hard_pump_pre and (c_recent_pump_pre >= min_climax_wave_pre or tactical_rsi_pre >= 58.0) and (c_vol_ratio_pre >= (max(0.85, min_trap_rvol) if tactical_rsi_pre >= 68.0 else 1.10)))
            or (in_fading_short_wl_pre and c_upper_wick_pre >= 0.35 and c_vol_ratio_pre >= 1.10 and c_recent_pump_pre >= min_climax_hard_pump_pre)
            or (is_parabolic_pump_climax_pre and c_upper_wick_pre >= (0.40 if is_crypto_altcoin else 0.30))
        )

        # 2. Nến kiệt sức bán gom hàng (Selling Climax): Bắt buộc có râu dưới vật lý >= 30-35%!
        has_raw_bear_trap_sig = any(
            isinstance(getattr(s, 'metadata', None), dict)
            and c_vol_ratio_pre >= min_trap_rvol
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
            for s in signals
        )
        is_selling_climax_candle = (not is_waterfall_dump_pre) and (not is_extreme_bear_storm_pre) and (
            (c_lower_wick_pre >= 0.45 and c_lower_wick_pre > c_upper_wick_pre * 1.3 and c_vol_ratio_pre >= climax_rvol_pre and c_recent_dump_pre >= min_climax_hard_dump_pre and (c_recent_dump_pre >= min_climax_wave_pre or tactical_rsi_pre <= 42.0))
            or (c_recent_dump_pre >= (0.035 if is_crypto_altcoin else 0.018) and c_lower_wick_pre >= 0.40 and c_vol_ratio_pre >= (1.20 if is_crypto_altcoin else 1.00))
            or (has_raw_bear_trap_sig and c_lower_wick_pre >= 0.35 and c_recent_dump_pre >= min_climax_hard_dump_pre and (c_recent_dump_pre >= min_climax_wave_pre or tactical_rsi_pre <= 42.0) and (c_vol_ratio_pre >= (max(0.85, min_trap_rvol) if tactical_rsi_pre <= 32.0 else 1.10)))
            or (is_panic_selling_climax_pre and c_lower_wick_pre >= 0.30)
        )

        # 3. Bão volume cá mập kéo dốc Pha 1 (Whale Pump Storm): Đối xứng hoàn toàn với Waterfall Dump cho 3 lớp tài sản
        min_whale_pump_pre = sf_pre['min_whale_pump']
        max_whale_pump_pre = max_waterfall_dump_pre
        wp_rvol_std_pre = sf_pre['wp_rvol_std']
        is_whale_pump_storm_pre = (
            not is_buying_climax_candle
            and not is_live_dumping_pre
            and not is_waterfall_dump_pre
            and not is_parabolic_pump_climax_pre
            and c_upper_wick_pre < 0.30
            and (c_recent_pump_pre >= max(min_whale_pump_pre, c_recent_dump_pre * 1.30) or c_recent_dump_pre <= sf_pre['wf_shape_pump_cap'])
            and (
                (min_whale_pump_pre <= c_recent_pump_pre <= max_whale_pump_pre and c_vol_ratio_pre >= wp_rvol_std_pre)
                or (c_vol_ratio_pre >= sf_pre['wp_rvol_high'] and (min_whale_pump_pre * 0.75) <= c_recent_pump_pre <= max_whale_pump_pre)
            )
        )

        # --- MUTUALLY EXCLUSIVE & TRAP OVERRIDE RULES (THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN) ---
        # [BÀI HỌC 82, 85 & 105]: Bẫy Bull Trap / Bear Trap chỉ được công nhận là BẪY THẬT (được quyền xóa phiếu ngược chiều)
        # khi có RÂU NẾN VẬT LÝ trên khung 15M (hoặc 1H được 15M đồng thuận râu >= 30%).
        # [BÀI HỌC 105 & FIX AVAX]: Bẫy Bull Trap chỉ có ý nghĩa ở vùng ĐỈNH / QUÁ MUA (RSI >= 45, không trong đợt xả mạnh).
        # Lưu ý: Khi coin vừa Pump mạnh (ví dụ AVAX Pump=5.2%, RSI=85.1, U_Wick=60.7%), giá đóng cửa rút xuống từ đỉnh râu
        # khiến c_recent_dump_pre >= 1.5% nhưng thực chất đang ở ĐỈNH QUÁ MUA (RSI >= 58 hoặc Pump > Dump).
        # Do đó chỉ coi là is_in_dump_or_oversold khi RSI < 58 và đà Dump thực sự lớn hơn đà Pump!
        is_in_dump_or_oversold = (
            (
                (tactical_rsi_pre <= 42.0)
                or (c_recent_dump_pre >= 0.015 and c_recent_dump_pre >= c_recent_pump_pre * 1.15)
                or is_selling_climax_candle
            )
            and (tactical_rsi_pre < 58.0 or is_selling_climax_candle)
            and not is_buying_climax_candle
        )
        is_in_pump_or_overbought = (
            (
                (tactical_rsi_pre >= 58.0)
                or (c_recent_pump_pre >= 0.015 and c_recent_pump_pre >= c_recent_dump_pre * 1.15)
                or is_buying_climax_candle
                or is_whale_pump_storm_pre
            )
            and (tactical_rsi_pre > 42.0 or is_buying_climax_candle or is_whale_pump_storm_pre)
            and not is_selling_climax_candle
        )

        has_15m_bull_trap = (not is_in_dump_or_oversold) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '15m'
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
            for s in signals
        )

        has_15m_bear_trap = (not is_waterfall_dump_pre) and (not is_in_pump_or_overbought) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '15m'
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
            for s in signals
        )

        has_1h_bull_trap_valid = (not is_in_dump_or_oversold) and (c_upper_wick_pre >= 0.30) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '1h'
            and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
            for s in signals
        )

        has_1h_bear_trap_valid = (not is_waterfall_dump_pre) and (not is_in_pump_or_overbought) and (c_lower_wick_pre >= 0.30) and any(
            isinstance(getattr(s, 'metadata', None), dict)
            and s.metadata.get('timeframe') == '1h'
            and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
            for s in signals
        )

        # [BOM #122A/C]: Xoa tinh lap du thua (min_trap_rvol da tinh tai L514)
        has_valid_trap_vol = (c_vol_ratio_pre >= min_trap_rvol) or is_buying_climax_candle or is_selling_climax_candle

        has_real_bull_trap_raw = (not is_in_dump_or_oversold) and has_valid_trap_vol and (
            has_15m_bull_trap
            or has_1h_bull_trap_valid
            or is_buying_climax_candle
        )

        has_real_bear_trap_raw = (not is_waterfall_dump_pre) and (not is_in_pump_or_overbought) and has_valid_trap_vol and (
            has_15m_bear_trap
            or has_1h_bear_trap_valid
            or is_selling_climax_candle
        )
        # [BOM #131C FIX]: Nếu đồng thời có cả Bull Trap và Bear Trap (nến 2 râu giằng co / 1H cũ đè 15M mới), ưu tiên nến 15M thuần hoặc triệt tiêu bẫy 2 đầu!
        if has_real_bull_trap_raw and has_real_bear_trap_raw:
            if has_15m_bull_trap and not has_15m_bear_trap:
                has_real_bear_trap_raw = False
            elif has_15m_bear_trap and not has_15m_bull_trap:
                has_real_bull_trap_raw = False
            else:
                has_real_bull_trap_raw = False
                has_real_bear_trap_raw = False

        trend_vote = sum(by_strategy.get('trend_following', [0.0])) / len(by_strategy.get('trend_following', [1.0])) if 'trend_following' in by_strategy else 0.0
        if abs(trend_vote) < 0.15:
            trend_vote = 0.0

        breakout_vote = sum(by_strategy.get('momentum_breakout', [0.0])) / len(by_strategy.get('momentum_breakout', [1.0])) if 'momentum_breakout' in by_strategy else 0.0
        if abs(breakout_vote) < 0.15:
            breakout_vote = 0.0

        jev_vote = sum(by_strategy.get('jev_agent', [0.0])) / len(by_strategy.get('jev_agent', [1.0])) if 'jev_agent' in by_strategy else 0.0
        orig_jev_vote = jev_vote

        ai_vote = sum(by_strategy.get('ai_ensemble', [0.0])) / len(by_strategy.get('ai_ensemble', [1.0])) if 'ai_ensemble' in by_strategy else 0.0

        mean_rev_vote = sum(by_strategy.get('mean_reversion', [0.0])) / len(by_strategy.get('mean_reversion', [1.0])) if 'mean_reversion' in by_strategy else 0.0
        if abs(mean_rev_vote) < 0.15:
            mean_rev_vote = 0.0

        trap_vote_raw = sum(by_strategy.get('trap_detector', [0.0])) / len(by_strategy.get('trap_detector', [1.0])) if 'trap_detector' in by_strategy else 0.0
        if abs(trap_vote_raw) < 0.15:
            trap_vote_raw = 0.0

        # [BÀI HỌC 105, 106 & 107 - SMART ABSORPTION REVERSAL & EXHAUSTION FADING RÂU 1 CHIỀU]:
        # Nhận diện khi cá mập gom hàng hấp thụ đáy / xả đỉnh phân phối và AI Ensemble có độ tự tin cao (>= 70%):
        # [BÀI HỌC 106]: Bắt buộc phải có râu nến vật lý 1 chiều (râu gom/xả >= 30% và râu cản ngược lại < 25%),
        # tuyệt đối cấm đảo ngược cản đầu xe lửa Waterfall Dump (nến đỏ đặc không râu) hay Whale Pump (nến xanh đặc không râu)!
        # [BÀI HỌC 107]: Bắt buộc phải có sóng Pump/Dump thực chất trên nến đóng (>= 1.80%), tránh kích hoạt nhầm khi Pump = 0.00%!
        # [VẤN ĐỀ 1 - SÀN LỌC RVol ĐA TẦNG CHO EXHAUSTION FADING & ABSORPTION REVERSAL]:
        # Phân biệt rõ Major Crypto (BTC/ETH/SOL), TradFi (SOXL/NVDA), và Altcoins (MERL/ACT).
        # Khi cản xu hướng (Fading Sell ngược Uptrend, hoặc Absorption Buy ngược Downtrend):
        # BẮT BUỘC RVol 15M phải đạt ngưỡng đột biến phân phối/hấp thụ thực sự.
        # Nếu RVol thấp (như MERL 0.64x), râu nến chỉ là bull flag tích lũy, cấm kích hoạt Fading cản tàu!
        macro_regime_str = str(macro_analysis_pre.get('regime', '')).lower()
        is_uptrend_ctx = ('uptrend' in macro_regime_str) or (trend_vote > 0.25) or (jev_vote > 0.25)
        is_downtrend_ctx = ('downtrend' in macro_regime_str) or (trend_vote < -0.25) or (jev_vote < -0.25)

        if is_crypto_altcoin:
            rvol_fading_floor = 1.50 if is_uptrend_ctx else 1.20
        elif is_tradfi:
            rvol_fading_floor = 0.55
        else: # Major Crypto (BTC, ETH, SOL...)
            rvol_fading_floor = 1.00

        # [SSOT PURGE + BOM #15 + BOM #150 P1 FIX]: Xóa sổ SMART_ABSORPTION_REVERSAL_BUY, chặn Exhaustion Fading Sell ở đáy quá bán,
        # và đồng bộ râu xả đỉnh >= 45% khớp DNA Shield VK6 (tránh gắn EXHAUSTION_FADING_SELL rồi bị VK6_UPPER_WICK_SHIELD giết oan!).
        is_ai_exhaustion_sell = (
            ai_vote <= -0.70
            and (c_vol_ratio_pre >= rvol_fading_floor or is_buying_climax_candle)
            and (c_recent_pump_pre >= min_climax_wave_pre or is_parabolic_pump_climax_pre)
            and (c_upper_wick_pre >= 0.45 or is_buying_climax_candle)
            and (c_lower_wick_pre < 0.25)
            and (tactical_rsi_pre >= 45.0)
            and (tactical_rsi_pre >= 55.0 or c_recent_pump_pre >= (0.040 if is_crypto_altcoin else 0.022) or is_parabolic_pump_climax_pre)
            and not (c_recent_dump_pre >= 0.015 and c_recent_pump_pre < min_climax_wave_pre)
            and not (c_recent_dump_pre > c_recent_pump_pre and tactical_rsi_pre < 55.0)
        )

        # [TÔN CHỈ SỐ 0 & KB5 CHUẨN HÓA XUNG ĐỘT 2 - ĐỒNG BỘ BREAKOUT, JEV 4H SHIELD & BẪY CÁ MẬP VẬT LÝ]:
        # 1) Chỉ chặn TrapDetector cản tàu khi nến 15M KHÔNG CÓ râu xả/gom đỉnh đáy thực sự (eff_wick < 35% & không phải Climax).
        # 2) Khi JEV 4H đang báo BUY mạnh (>= 70%) và nến chưa có râu xả đỉnh vật lý (< 35%), tuyệt đối bảo vệ đà BUY của Breakout/Trend!
        is_opposed_by_strong_breakout = (
            c_upper_wick_pre < 0.35
            and not is_buying_climax_candle
            and not is_ai_exhaustion_sell
            and (
                (breakout_vote >= 0.50 and ai_vote >= 0.0)
                or (jev_vote >= 0.70 and (breakout_vote > 0.0 or trend_vote > 0.0))
            )
        )
        is_bear_opposed_by_breakout = (
            c_lower_wick_pre < 0.35
            and not is_selling_climax_candle
            and (
                (breakout_vote <= -0.50 and ai_vote <= 0.0)
                or (jev_vote <= -0.70 and (breakout_vote < 0.0 or trend_vote < 0.0))
            )
        )

        has_real_bull_trap = has_real_bull_trap_raw and not is_opposed_by_strong_breakout
        has_real_bear_trap = has_real_bear_trap_raw and not is_bear_opposed_by_breakout

        # [BÀI HỌC 85 & FIX PHÁT HIỆN #10 - THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN ĐỐI XỨNG 2 CHIỀU]:
        # Tuyệt đối KHÔNG kích hoạt majority_wants_buy khi AI đang báo SELL (ai_vote < 0)
        # và KHÔNG kích hoạt majority_wants_sell khi AI đang báo BUY (ai_vote > 0)!
        bearish_vote_cnt = sum(1 for v in (ai_vote, trend_vote, breakout_vote, jev_vote) if v <= -0.25)
        bullish_vote_cnt = sum(1 for v in (ai_vote, trend_vote, breakout_vote, jev_vote) if v >= 0.25)
        total_core_vote = ai_vote + trend_vote + breakout_vote + jev_vote
        has_bearish_tech_core = (trend_vote <= -0.25 or breakout_vote <= -0.25)
        has_bullish_tech_core = (trend_vote >= 0.25 or breakout_vote >= 0.25)
        can_dual_brain_sell_only = (ai_vote <= -0.65 and jev_vote <= -0.65)
        can_dual_brain_buy_only = (ai_vote >= 0.65 and jev_vote >= 0.65)

        majority_wants_sell = (
            (ai_vote <= 0.0 or is_waterfall_dump_pre)
            and (has_bearish_tech_core or can_dual_brain_sell_only or is_waterfall_dump_pre)
            and (
                (bearish_vote_cnt >= 2 and total_core_vote <= -0.50)
                or is_waterfall_dump_pre
                or (ai_vote <= -0.72 and trend_vote <= 0.0 and jev_vote <= 0.0 and (trend_vote < 0.0 or jev_vote < 0.0 or breakout_vote < 0.0))
            )
            and not (trend_vote >= 0.35 and jev_vote >= 0.50)
            and not (jev_vote >= 0.70 and not is_waterfall_dump_pre)
        )
        if apply_entry_vetoes and majority_wants_sell:
            if trap_vote_raw > 0 and not has_real_bear_trap:
                by_strategy.pop('trap_detector', None)
                if log_vetoes:
                    logger.info(
                        "🌊 [TẦNG 3 - LẬT NGƯỢC SỐ ĐÔNG BÁN] %s: Loại bỏ phiếu Bẫy Giảm (Bear Trap) giả/trễ pha (Râu dưới 15m=%.1f%%) "
                        "để giữ nguyên phe BÁN của Số Đông & Cá Mập (AI=%+.2f, JEV=%+.2f, Trend=%+.2f, Breakout=%+.2f)!",
                        symbol_name, c_lower_wick_pre * 100, ai_vote, jev_vote, trend_vote, breakout_vote
                    )
            if mean_rev_vote > 0 and (ai_vote <= -0.68 or is_waterfall_dump_pre or c_lower_wick_pre < 0.25):
                by_strategy.pop('mean_reversion', None)
                if log_vetoes:
                    logger.info(
                        "🌊 [TẦNG 3 - LẬT NGƯỢC SỐ ĐÔNG BÁN] %s: Loại bỏ phiếu Mean Reversion bắt dao rơi "
                        "để giữ nguyên phe BÁN của Số Đông & Cá Mập (AI=%+.2f, JEV=%+.2f, Râu dưới=%.1f%%)!",
                        symbol_name, ai_vote, jev_vote, c_lower_wick_pre * 100
                    )

        # 2) Đối xứng: Khi TrapDetector báo SELL (trap_vote_raw < 0) nhưng KHÔNG ĐẠT chuẩn Bull Trap vật lý 15m
        # (not has_real_bull_trap) trong khi Số Đông / Bão Volume Cá Mập đang báo BUY: Loại bỏ phiếu Trap giả!
        majority_wants_buy = (
            (ai_vote >= 0.0 or is_whale_pump_storm_pre)
            and (has_bullish_tech_core or can_dual_brain_buy_only or is_whale_pump_storm_pre)
            and (
                (bullish_vote_cnt >= 2 and total_core_vote >= 0.50)
                or is_whale_pump_storm_pre
                or (ai_vote >= 0.72 and trend_vote >= 0.0 and jev_vote >= 0.0 and (trend_vote > 0.0 or jev_vote > 0.0 or breakout_vote > 0.0))
            )
            and not (trend_vote <= -0.35 and jev_vote <= -0.50)
            and not (jev_vote <= -0.70 and not is_whale_pump_storm_pre)
        )
        if apply_entry_vetoes and majority_wants_buy:
            if trap_vote_raw < 0 and not has_real_bull_trap:
                by_strategy.pop('trap_detector', None)
                if log_vetoes:
                    logger.info(
                        "🚀 [TẦNG 3 - LẬT NGƯỢC SỐ ĐÔNG MUA] %s: Loại bỏ phiếu Bẫy Tăng (Bull Trap) giả/trễ pha (Râu trên 15m=%.1f%%) "
                        "để giữ nguyên phe MUA của Số Đông & Cá Mập (AI=%+.2f, JEV=%+.2f, Trend=%+.2f, Breakout=%+.2f)!",
                        symbol_name, c_upper_wick_pre * 100, ai_vote, jev_vote, trend_vote, breakout_vote
                    )
            if mean_rev_vote < 0 and (ai_vote >= 0.68 or is_whale_pump_storm_pre or c_upper_wick_pre < 0.25):
                by_strategy.pop('mean_reversion', None)
                if log_vetoes:
                    logger.info(
                        "🚀 [TẦNG 3 - LẬT NGƯỢC SỐ ĐÔNG MUA] %s: Loại bỏ phiếu Mean Reversion cản tàu bão bơm "
                        "để giữ nguyên phe MUA của Số Đông & Cá Mập (AI=%+.2f, JEV=%+.2f, Râu trên=%.1f%%)!",
                        symbol_name, ai_vote, jev_vote, c_upper_wick_pre * 100
                    )

        # [BOM #126B + #134 FIX]: Tính sớm cờ _has_slot_a_exempt_votes (tín hiệu Vũ Khí Động SLOT_A / SKIP)
        # để bảo toàn phiếu TrapDetector tại vùng 1.05x <= RVol < 1.10x (an toàn tuyệt đối vì SLOT A DYN-GUARD L3316 + DNA L5867 khóa chặt).
        _has_slot_a_exempt_votes = any(
            isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('dyn_slot_a_exempt')
            for s in (signals or [])
        )
        is_solo_trap_only = (
            'trap_detector' in by_strategy
            and abs(trend_vote) < 0.15
            and abs(breakout_vote) < 0.15
            and abs(mean_rev_vote) < 0.15
        )
        if apply_entry_vetoes and is_solo_trap_only and not has_valid_trap_vol and not _has_slot_a_exempt_votes:
            by_strategy.pop('trap_detector', None)
            if log_vetoes:
                logger.info(
                    "🛡️ [LOW-VOL FAKE TRAP VETO] %s: Loại bỏ phiếu TrapDetector đơn độc thiếu thanh khoản (RVol=%.2fx < %.2fx)!",
                    symbol_name, c_vol_ratio_pre, min_trap_rvol
                )

        # Nếu khung 15m đang bứt phá mạnh (TrendFollowing/Breakout BUY) VÀ JEV Agent MTF xác nhận BUY (>= 0.70)
        # mà không có bẫy xả trên nến 15m (chỉ có tín hiệu TrapDetector 1H cũ từ giờ trước như AKT/USDT),
        # không cho phép tín hiệu 1H trễ pha xóa bỏ sóng tăng 15M hiện tại!
        if apply_entry_vetoes and has_real_bull_trap and not has_15m_bull_trap and not is_buying_climax_candle and (trend_vote >= 0.30 or breakout_vote >= 0.30) and jev_vote >= 0.70:

            has_real_bull_trap = False

            by_strategy.pop('trap_detector', None)



        if apply_entry_vetoes and has_real_bear_trap and not has_15m_bear_trap and not is_selling_climax_candle and (trend_vote <= -0.30 or breakout_vote <= -0.30) and jev_vote <= -0.70:

            has_real_bear_trap = False

            by_strategy.pop('trap_detector', None)



        # [BAI HOC 70] Khử triệt để bẫy pha loãng điểm (Bull Trap dilution & Bear Trap dilution):

        # Khi TrapDetector phát hiện rút râu xả hàng trên nến đóng (Bull Trap), cây nến xanh vừa tạo râu

        # thường đánh lừa các chỉ báo kỹ thuật khác và mô hình ML tưởng lầm là sóng tăng và bỏ phiếu BUY.

        # Các phiếu BUY này nằm trong mẫu số kéo điểm về gần 0 (ví dụ BTC 16:00:49 score=-0.0062) và kích

        # hoạt Opposing Veto giả tạo.

        # Vì vậy, khi có Bull Trap thật, vô hiệu hóa toàn bộ phiếu BUY đối kháng khỏi mẫu số.

        # Tương tự đối xứng: khi có Bear Trap thật, vô hiệu hóa toàn bộ phiếu SELL đối kháng khỏi mẫu số.

        # [KB5]: Đã đồng bộ is_opposed_by_strong_breakout và is_bear_opposed_by_breakout duy nhất từ đầu khối (tránh ghi đè mất JEV 4H Shield).

        neutralized_bull = []

        neutralized_bear = []

        if apply_entry_vetoes and has_real_bull_trap and not is_whale_pump_storm_pre and not is_opposed_by_strong_breakout:

            if trend_vote > 0.0 and 'trend_following' in by_strategy:

                by_strategy.pop('trend_following', None)

                neutralized_bull.append('TrendFollowing')

            if breakout_vote > 0.0 and 'momentum_breakout' in by_strategy:

                by_strategy.pop('momentum_breakout', None)

                neutralized_bull.append('Breakout')

            # [BÀI HỌC 97]: Tuyệt đối KHÔNG vô hiệu hóa AI Ensemble khi độ tự tin cao (ai_vote >= 0.70 / conf >= 70%)!
            if ai_vote > 0.0 and 'ai_ensemble' in by_strategy and ai_vote < 0.70 and not (trend_vote >= 0.25 and ai_vote >= 0.60):

                by_strategy.pop('ai_ensemble', None)

                neutralized_bull.append('AIEnsemble')

            # [BÀI HỌC 97 & 102]: Tuyệt đối KHÔNG vô hiệu hóa JEV Agent khi độ tự tin cao (jev_vote >= 0.70)!
            if jev_vote > 0.0 and 'jev_agent' in by_strategy and jev_vote < 0.70:

                by_strategy.pop('jev_agent', None)

                neutralized_bull.append('JEVAgent')

            if mean_rev_vote > 0.0 and 'mean_reversion' in by_strategy:

                by_strategy.pop('mean_reversion', None)

                neutralized_bull.append('MeanReversion')

            if neutralized_bull and log_vetoes:

                logger.info(

                    "🛡️ CẢNH BÁO BẪY GIÁ (BULL TRAP): TrapDetector phát hiện rút râu xả hàng! "

                    "Vô hiệu hóa đà BUY của %s để chống bẫy pha loãng điểm (Bull Trap dilution).",

                    ', '.join(neutralized_bull),

                )



        # 2. CHỐNG BẮT DAO RƠI KHI SẬP MẠNH (Downtrend crash) & KIỂM ĐỊNH BEAR TRAP THẬT TRƯỚC KHI XÓA PHIẾU SELL:
        # Chỉ coi JEV là bearish khi JEV thực sự ra lệnh SELL (jev_vote <= -0.20),
        # hoặc khi không có đà tăng kỹ thuật (trend_vote <= 0 và breakout_vote <= 0) mà JEV cảnh báo downtrend/dump.
        # Tuyệt đối không bắt chữ cảm tính khi TrendFollowing đang báo BUY dương (như AIO/USDT Trend +0.80)!
        jev_is_bearish = (jev_vote <= -0.20) or (
            trend_vote <= 0.0
            and breakout_vote <= 0.0
            and any(
                isinstance(getattr(s, 'metadata', None), dict)
                and any(w in str(s.metadata.get('reason', '')).lower() for w in ('bearish', 'downtrend', 'drop', 'dump', 'xả'))
                for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
            )
        )

        # Kiểm tra AI Bias hoặc Market Regime vĩ mô từ metadata (hoặc macro_regime_str đã trích từ market_analysis)
        macro_is_bearish = (
            macro_regime_str in ('downtrend', 'strong_downtrend', 'bearish')
            or any(
                isinstance(getattr(s, 'metadata', None), dict)
                and (
                    str(s.metadata.get('ai_bias', '')).upper() == 'BEARISH'
                    or str(s.metadata.get('market_regime', '')).lower() in ('downtrend', 'strong_downtrend', 'bearish')
                )
                for s in signals
            )
        )

        is_coin_technically_pumping = (trend_vote >= 0.20 or breakout_vote >= 0.20)

        has_strong_sell_momentum = (
            not is_coin_technically_pumping and (
                breakout_vote <= -0.20 or 
                trend_vote <= -0.20 or 
                macro_is_bearish
            )
        )

        has_strong_trap_reversal = (
            has_real_bear_trap
            and 'trap_detector' in by_strategy
            and any(
                getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and getattr(s, 'signal', None) == Signal.BUY
                and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                for s in signals
            )
        )

        # Chỉ vô hiệu hóa đà SELL của Số Đông khi Bear Trap hợp lệ (không phải hồi ảo Altcoin < 70% trong downtrend)
        # [BÀI HỌC 85 & 86 - KHẮC PHỤC TRIỆT ĐỂ BẪY BẮT DAO RƠI BEAR TRAP LONG]:
        # C1: Trap 1H SELL xung đột với 15M BUY (khung 1H xả dốc, 15M chỉ là râu nhiễu)
        has_1h_sell_trap = any(
            getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
            and getattr(s, 'signal', None) == Signal.SELL
            and str((getattr(s, 'metadata', None) or {}).get('timeframe') or '').lower() == '1h'
            for s in signals
        )
        has_15m_trap_buy = any(
            getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
            and getattr(s, 'signal', None) == Signal.BUY
            and str((getattr(s, 'metadata', None) or {}).get('timeframe') or '').lower() == '15m'
            for s in signals
        )
        # [BOM #150 P1 FIX]: Công nhận MeanReversion BUY mạnh kèm râu rút chân >= 35% là đồng thuận kỹ thuật,
        # đồng thời yêu cầu raw_trap_conf_pre > 0.0 để không giết nhầm Selling Climax (không có phiếu TrapDetector = 0.0) bằng c3/c5!
        has_other_tech_buy = (
            trend_vote >= 0.20
            or breakout_vote >= 0.20
            or (mean_rev_vote >= 0.60 and c_lower_wick_pre >= 0.35)
        )
        raw_trap_conf_pre = max(
            (
                float(getattr(s, 'confidence', 0.0) or 0.0)
                for s in signals
                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)
            ),
            default=0.0,
        )

        c1_trap_1h_conflict = has_1h_sell_trap
        c2_stale_1h_trap_only = (has_1h_bear_trap_valid and not has_15m_trap_buy and not has_other_tech_buy and (jev_vote <= 0 or ai_vote <= -0.75 or raw_trap_conf_pre <= 0.68))
        c3_jev_hold_weak_trap = (raw_trap_conf_pre > 0.0 and not has_other_tech_buy and jev_vote <= 0 and raw_trap_conf_pre <= 0.73)
        c4_unanimous_macro_sell = (ai_vote <= -0.55 and jev_vote <= -0.20)
        c5_weak_lone_trap = (raw_trap_conf_pre > 0.0 and raw_trap_conf_pre <= 0.68 and not has_other_tech_buy and not has_1h_bear_trap_valid)

        is_fake_altcoin_bear_trap = (
            has_real_bear_trap and (
                (is_crypto_altcoin and (
                    (has_strong_sell_momentum and not has_strong_trap_reversal)
                    or c1_trap_1h_conflict
                    or c2_stale_1h_trap_only
                    or c3_jev_hold_weak_trap
                    or c5_weak_lone_trap
                ))
                or c4_unanimous_macro_sell
            )
        )

        if apply_entry_vetoes and has_real_bear_trap and not is_fake_altcoin_bear_trap and not is_waterfall_dump_pre and not is_bear_opposed_by_breakout:

            if trend_vote < 0.0 and 'trend_following' in by_strategy:

                by_strategy.pop('trend_following', None)

                neutralized_bear.append('TrendFollowing')

            if breakout_vote < 0.0 and 'momentum_breakout' in by_strategy:

                by_strategy.pop('momentum_breakout', None)

                neutralized_bear.append('Breakout')

            # [BÀI HỌC 97 & SSOT DOCTRINE]: Tuyệt đối KHÔNG vô hiệu hóa AI Ensemble khi độ tự tin cao (ai_vote <= -0.60)!
            if ai_vote < 0.0 and 'ai_ensemble' in by_strategy and ai_vote > -0.60:

                by_strategy.pop('ai_ensemble', None)

                neutralized_bear.append('AIEnsemble')

            # [BÀI HỌC 97 & 102]: Tuyệt đối KHÔNG vô hiệu hóa JEV Agent khi độ tự tin cao (jev_vote <= -0.70)!
            if jev_vote < 0.0 and 'jev_agent' in by_strategy and jev_vote > -0.70:

                by_strategy.pop('jev_agent', None)

                neutralized_bear.append('JEVAgent')

            if mean_rev_vote < 0.0 and 'mean_reversion' in by_strategy:

                by_strategy.pop('mean_reversion', None)

                neutralized_bear.append('MeanReversion')

            if neutralized_bear and log_vetoes:

                logger.info(

                    "🛡️ CẢNH BÁO BẪY GIÁ (BEAR TRAP): TrapDetector phát hiện rút chân gom hàng! "

                    "Vô hiệu hóa đà SELL của %s để chống bẫy pha loãng điểm (Bear Trap dilution).",

                    ', '.join(neutralized_bear),

                )



        trap_ctx_data = {

            'has_real_bull_trap': has_real_bull_trap,

            'has_real_bear_trap': has_real_bear_trap and not is_fake_altcoin_bear_trap,

            'has_valid_trap_vol': bool(has_valid_trap_vol),

            'is_fake_altcoin_bear_trap': is_fake_altcoin_bear_trap,

            'is_true_climax_15m': (c_upper_wick_pre >= 0.45 or c_lower_wick_pre >= 0.45),

            'c_upper_wick_pct': float(c_upper_wick_pre),

            'c_lower_wick_pct': float(c_lower_wick_pre),

            'c_vol_ratio': float(c_vol_ratio_pre),

            'is_whale_pump_storm': is_whale_pump_storm_pre,

            'is_waterfall_dump': is_waterfall_dump_pre,

            'is_ai_exhaustion_sell': is_ai_exhaustion_sell,
            'orig_jev_vote': orig_jev_vote,
            'orig_ai_vote': float(ai_vote),
            'neutralized_bull': list(neutralized_bull),
            'neutralized_bear': list(neutralized_bear),
            'symbol': symbol_name,
        }

        if apply_entry_vetoes:
            # [BOM #100 + #116D FIX]: Chi cap nhat shared trap context khi apply_entry_vetoes=True va bao ve bang _agg_lock
            clean_name_short = symbol_name.split(':')[0].strip().upper()
            with getattr(self, '_agg_lock', threading.RLock()):
                self._last_trap_context = trap_ctx_data
                if not hasattr(self, '_trap_contexts_by_symbol'):
                    self._trap_contexts_by_symbol = {}
                self._trap_contexts_by_symbol[symbol_name] = trap_ctx_data
                self._trap_contexts_by_symbol[clean_name_short] = trap_ctx_data
                self._trap_contexts_by_symbol[symbol_name.replace('/', '').upper()] = trap_ctx_data
                self._trap_contexts_by_symbol[clean_name_short.replace('/', '').upper()] = trap_ctx_data



        if apply_entry_vetoes:

            # A. CẤM TUYỆT ĐỐI BẮT ĐÁY LONG TRÊN ALTCOIN KHI THỊ TRƯỜNG DOWNTREND (MIỄN TRỪ NẾU CÓ BẪY RÚT ĐÁY MẠNH >= 70% HOẶC SLOT_A VŨ KHÍ ĐỘNG ĐÃ KHỚP):
            # [BOM #126B + #134 FIX]: Đã tính sẵn _has_slot_a_exempt_votes ở trên L852 để bảo vệ đồng bộ cả L858 lẫn nhánh Downtrend.
            if has_strong_sell_momentum and is_crypto_altcoin and not _has_slot_a_exempt_votes:

                if not has_strong_trap_reversal:

                    removed_buy = False

                    for strat_k in list(by_strategy.keys()):

                        # [BOM #119B FIX]: Bảo vệ tuyệt đối phiếu jev_agent khi JEV 4H BUY >= 70% (Rule 0 & Hard Constraint #2)!
                        if strat_k in ('trap_detector', 'ai_ensemble') or (strat_k == 'jev_agent' and jev_vote >= 0.70):

                            continue

                        orig_len = len(by_strategy[strat_k])

                        filtered_v = [v for v in by_strategy[strat_k] if v <= 0]

                        if len(filtered_v) < orig_len:

                            removed_buy = True

                        if filtered_v:

                            by_strategy[strat_k] = filtered_v

                        else:

                            by_strategy.pop(strat_k, None)

                    if removed_buy and log_vetoes:

                        reason_str = "Toàn sàn/Vĩ mô Downtrend" if macro_is_bearish else f"Đà giảm cục bộ của coin (Trend: {trend_vote:+.2f}, Breakout: {breakout_vote:+.2f})"

                        logger.info("🚫 VETO BUY ALTCOIN (%s): %s, cấm bắt dao rơi Altcoin!", symbol_name, reason_str)



            # C. LỌC BẪY RÂU ĐÁY ALTCOIN YẾU (< 70%) TRONG DOWNTREND (GIỮ NGUYÊN PHIẾU SELL CỦA SỐ ĐÔNG):

            if is_fake_altcoin_bear_trap:

                has_real_bear_trap = False

                trap_ctx_data['has_real_bear_trap'] = False

                by_strategy.pop('trap_detector', None)

                if log_vetoes:

                    logger.info("🛡️ CHẶN BẪY RÂU ALTCOIN (%s): Bẫy rút đáy Altcoin bị phủ quyết trong downtrend vĩ mô để giữ đà SELL thuận theo cá mập!", symbol_name)



        # B. TĂNG LỰC CHO SHORT BẮT ĐỈNH (BULL TRAP SHORT) & ĐỒNG BỘ LƯỠNG PHA CÁ MẬP:

        # Khi xuất hiện Bull Trap thực sự, tăng mạnh trọng số SHORT.

        # [KB5]: Đã đồng bộ is_opposed_by_strong_breakout và is_bear_opposed_by_breakout duy nhất từ đầu khối (tránh ghi đè mất JEV 4H Shield).

        if apply_entry_vetoes and has_real_bull_trap and not is_whale_pump_storm_pre and not is_opposed_by_strong_breakout:
            by_strategy['trap_detector'] = [-0.85]
            if log_vetoes:
                logger.info("🎯 KÍCH HOẠT BULL TRAP SHORT (%s): TrapDetector/Buying Climax xác nhận râu xả đỉnh, ưu tiên SHORT!", symbol_name)

        if apply_entry_vetoes and has_real_bear_trap and not is_fake_altcoin_bear_trap and not is_waterfall_dump_pre and not is_bear_opposed_by_breakout:
            by_strategy['trap_detector'] = [0.85]
            if log_vetoes:
                logger.info("💎 KÍCH HOẠT BEAR TRAP LONG (%s): TrapDetector/Selling Climax xác nhận rút chân gom hàng, ưu tiên BUY!", symbol_name)




        # [BÀI HỌC 78, 82 & 85 + BOM #131C FIX]: Khơi thông dòng tiền cá mập Pha 1 (Whale Pump Storm) và Thác đổ (Waterfall Breakdown)
        # Đối xứng 2 chiều: Whale Pump Storm cũng bị chặn khi JEV 4H xả mạnh (<= -0.65) hoặc RSI quá mua (>= 75) không đồng thuận!
        if apply_entry_vetoes and is_whale_pump_storm_pre and not has_real_bull_trap and (tactical_rsi_pre < 75.0 or trend_vote >= 0.30 or breakout_vote >= 0.30) and jev_vote > -0.65 and majority_wants_buy:
            if mean_rev_vote < 0:
                by_strategy.pop('mean_reversion', None)
            if trap_vote_raw < 0:
                by_strategy.pop('trap_detector', None)
            by_strategy['momentum_breakout'] = [max(0.85, breakout_vote)]

        if apply_entry_vetoes and is_waterfall_dump_pre and not has_real_bear_trap and (tactical_rsi_pre > 32.0 or trend_vote <= -0.30 or breakout_vote <= -0.30) and jev_vote < 0.65 and majority_wants_sell:
            if mean_rev_vote > 0:
                by_strategy.pop('mean_reversion', None)
            if trap_vote_raw > 0:
                by_strategy.pop('trap_detector', None)
            by_strategy['momentum_breakout'] = [min(-0.85, breakout_vote)]

        # [BÀI HỌC 105, 107 & 108 - SMART INVERSION: EXHAUSTION FADING SELL]:
        # Khi cá mập xả kiệt sức đỉnh và AI Ensemble tự tin SELL <= -72%:
        # Bãi bỏ các phiếu BUY trễ pha của Breakout/Trend, NHƯNG TUYỆT ĐỐI KHÔNG BẮT ĐỈNH CẢN TÀU KHI JEV AGENT 4H ĐANG BƠM MẠNH (>= 0.70)!
        if apply_entry_vetoes and is_ai_exhaustion_sell:
            if jev_vote >= 0.70:
                if log_vetoes:
                    logger.info(
                        "🛡️ [JEV MTF TREND SHIELD (%s)]: Không kích hoạt Exhaustion Fading Sell vì JEV Agent MTF đang bơm mạnh 4H (%.2f%%)!",
                        symbol_name, jev_vote * 100
                    )
            else:
                if breakout_vote > 0:
                    by_strategy.pop('momentum_breakout', None)
                if trend_vote > 0:
                    by_strategy.pop('trend_following', None)
                if jev_vote > 0 and jev_vote < 0.70 and (ai_vote <= -0.72 or c_recent_pump_pre >= 0.035 or is_parabolic_pump_climax_pre):
                    by_strategy.pop('jev_agent', None)
                by_strategy['ai_ensemble'] = [min(-0.85, ai_vote)]
                if has_real_bull_trap or is_buying_climax_candle:
                    by_strategy['trap_detector'] = [-0.85] # Chỉ xác nhận khi TrapDetector thực sự có tín hiệu râu xả đỉnh!
                if log_vetoes:
                    logger.info(
                        "⚡ [SMART INVERSION: EXHAUSTION FADING SELL (%s)]: AI Ensemble (%.2f%%) xác nhận sóng bơm kiệt sức đỉnh (RSI: %.1f, Pump: %.2f%%). Loại bỏ phiếu BUY trễ pha, ưu tiên SHORT!",
                        symbol_name, abs(ai_vote) * 100, tactical_rsi_pre, c_recent_pump_pre * 100
                    )



        # D. GHI NHẬN CẢNH BÁO CONSOLIDATION CHO CẶP ETF ĐÒN BẨY & CHẶN BẪY RÂU ĐƠN LẺ TRONG VÙNG NÉN 15M (CHOP TRACKING)

        clean_sym = symbol_name.split(':')[0].strip().upper()

        jev_warns_consolidation = any(

            isinstance(getattr(s, 'metadata', None), dict)

            and any(w in (str(s.metadata.get('risk_factors', '')) + " " + str(s.metadata.get('reason', ''))).lower() 

                    for w in (

                        'consolidation with no clear breakout',

                        'consolidating without a clear direction',

                        'consolidating between ema',

                        'choppy consolidation',

                        'volume is not significantly expanded',

                        'volume is not significantly expanding',

                        'conflicting 4h and 15m trends with no clear direction',

                        'no clear break above ema',

                        'no clear break',

                        'no clear breakout',

                        'lacks clear directional momentum',

                        'risk of volume exhaustion',

                        'consolidation with no clear break',

                        'choppy consolidation with no clear',

                        'testing ema20 with low volume and choppy consolidation',

                    ))

            for s in signals if getattr(s, 'strategy', '') == 'jev_agent'

        )

        # BẢO VỆ ĐỒNG THUẬN KỸ THUẬT (TECHNICAL CONSENSUS SCOPE BẢO ĐẢM LUÔN KHỞI TẠO):

        # Tính toán trước để luôn sẵn sàng cho cả Rule D (JEV Veto) và Rule E2 (Chop Shield)

        tech_keys = [k for k in by_strategy if k not in ('jev_agent', 'ai_ensemble')]

        has_tech_signal = len(tech_keys) > 0

        raw_trap_conf = max(

            (

                float(getattr(s, 'confidence', 0.0) or 0.0)

                for s in signals

                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')

                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)

            ),

            default=0.0,

        )

        # Đếm các chiến thuật kỹ thuật độc lập (loại trừ JEV và AI Ensemble) có độ tự tin cao (>= 0.65)

        # và phải đồng pha cùng chiều với hướng áp đảo kỹ thuật (không đếm chiến thuật đối kháng)

        tech_votes_signed = [
            (k, sum(by_strategy[k]) / len(by_strategy[k]))
            for k in tech_keys if by_strategy.get(k) and len(by_strategy[k]) > 0
        ]

        dominant_tech_dir = 1.0 if sum(v for _, v in tech_votes_signed) >= 0 else -1.0

        agreeing_tech_count = sum(

            1 for _, v in tech_votes_signed

            if v * dominant_tech_dir > 0 and abs(v) >= 0.65

        )

        has_strong_consensus = (agreeing_tech_count >= 2) or (raw_trap_conf >= 0.78 and c_vol_ratio_pre >= 1.25)



        if apply_entry_vetoes and jev_warns_consolidation:

            now_ts = time.time()

            # [BOM #150 P1 FIX]: Cô lập trạng thái Chop theo từng instance SignalAggregator (cấm ghi đè class-global
            # khiến Cổng 6 Dry-Run Offline đầu độc bot Live!), và chỉ ghi _recent_chop_vetoes khi không có strong consensus!
            _canon_chop_key = MarketScanner._canonical_tradfi_base(clean_sym) if hasattr(MarketScanner, '_canonical_tradfi_base') else clean_sym
            if not has_strong_consensus:
                with getattr(self, '_agg_lock', threading.RLock()):
                    self._recent_chop_vetoes[clean_sym] = now_ts
                    if _canon_chop_key:
                        self._recent_chop_vetoes[_canon_chop_key] = now_ts

            if apply_entry_vetoes:

                ctx = market_chop_context if isinstance(market_chop_context, dict) else {}

                measured = [

                    c for c in (ctx.get('BTC'), ctx.get('ETH'))

                    if _chop_entry_is_measured(c)

                ]

                btc_adx_val = max(

                    (float(c.get('adx') or 0.0) for c in measured), default=0.0

                )

                btc_atr_val = max(

                    (float(c.get('atr_pct') or 0.0) for c in measured), default=0.0

                )

                btc_is_active_trend = bool(measured) and (

                    btc_adx_val >= 22.0 or btc_atr_val >= 0.45

                )

                last_chop_act = float(getattr(self, '_last_chop_shield_activated_at', 0.0) or 0.0)

                if measured and (not btc_is_active_trend) and (now_ts - last_chop_act >= 240.0):

                    with getattr(self, '_agg_lock', threading.RLock()):
                        self._crypto_market_chop_until = now_ts + 120.0
                        self._last_chop_shield_activated_at = now_ts

                    logger.warning(

                        "🛡️ [CRYPTO CHOP SHIELD KÍCH HOẠT] BTC/ETH đang nén sideway / volume cạn kiệt (ADX=%.1f, ATR=%.2f%%). Tạm khóa mở lệnh Breakout đơn lẻ trên Crypto Altcoin trong 2 phút!",

                        btc_adx_val, btc_atr_val

                    )

            is_lone_trap_in_chop = (

                tech_keys == ['trap_detector']

                and (raw_trap_conf < 0.72 or c_vol_ratio_pre < min_trap_rvol)

            )

            is_consolidation_chop_veto = (

                (is_crypto_altcoin or is_tradfi)

                and jev_warns_consolidation

                and not has_strong_consensus

            )

            if apply_entry_vetoes and (

                not has_tech_signal

                or is_lone_trap_in_chop

                or is_consolidation_chop_veto

            ):

                by_strategy.clear()
                self._record_veto(symbol_name, 'JEV_CONSOLIDATION_VETO', 'HOLD', 'JEV cảnh báo nén sideway/volume cạn')

                logger.warning("🛡️ JEV VETO CONSOLIDATION (%s): JEV Agent cảnh báo thị trường nén đi ngang / không có breakout / volume cạn kiệt, VETO toàn bộ tín hiệu!", symbol_name)

                try:

                    from core.gate_telemetry import record_gate_event

                    record_gate_event('JEV_CHOP_VETO', symbol_name, reason='JEV cảnh báo nén sideway/volume cạn')

                except Exception:

                    pass



        # E. CHẶN CHÉO CẶP ETF NGHỊCH ĐẢO (INVERSE ETF CROSS-VETO) — [BOM #134 + BOM #149 P2 FIX]:
        # Dùng SSOT MarketScanner.get_tradfi_inverse_pairs (hỗ trợ đủ nhóm đa nghịch đảo 2 chiều TZA<->IWM/TNA, MSTZ<->MSTU/MSTX, UPRO<->SPXU/SPCX, *B).
        counter_pairs_list = []
        if hasattr(MarketScanner, 'get_tradfi_inverse_pairs'):
            counter_pairs_list.extend(MarketScanner.get_tradfi_inverse_pairs(clean_sym) or [])
        elif hasattr(MarketScanner, 'get_tradfi_inverse_pair'):
            _cp_one = MarketScanner.get_tradfi_inverse_pair(clean_sym)
            if _cp_one:
                counter_pairs_list.append(_cp_one)
        _inv_fallback = SignalAggregator.INVERSE_PAIRS.get(clean_sym)
        if _inv_fallback and _inv_fallback not in counter_pairs_list:
            counter_pairs_list.append(_inv_fallback)
        counter_pair = counter_pairs_list[0] if counter_pairs_list else None

        with getattr(self, '_agg_lock', threading.RLock()):
            last_counter_chop = 0.0
            for _cp_item in counter_pairs_list:
                _cp_ts_1 = float(self._recent_chop_vetoes.get(_cp_item, 0.0) or 0.0)
                _cp_canon = (
                    MarketScanner._canonical_tradfi_base(_cp_item)
                    if hasattr(MarketScanner, '_canonical_tradfi_base')
                    else None
                )
                _cp_ts_2 = float(self._recent_chop_vetoes.get(_cp_canon, 0.0) or 0.0) if _cp_canon else 0.0
                _cp_ts_3 = float(self._recent_chop_vetoes.get(f"{_cp_canon}/USDT", 0.0) or 0.0) if _cp_canon else 0.0
                _cp_best = max(_cp_ts_1, _cp_ts_2, _cp_ts_3)
                if _cp_best > last_counter_chop:
                    last_counter_chop = _cp_best
                    counter_pair = _cp_item
            _has_counter_chop = bool(apply_entry_vetoes and counter_pair and last_counter_chop > 0.0)

        if _has_counter_chop:

            if (time.time() - last_counter_chop) < 3600:

                by_strategy.clear()
                self._record_veto(symbol_name, 'INVERSE_ETF_CROSS_VETO', 'HOLD', f'Đối ứng {counter_pair} đang Chop')

                logger.warning(

                    "🛡️ INVERSE ETF CROSS-VETO (%s): Mã đối ứng %s đang bị cảnh báo Sideway/Chop nén biên hẹp (cách đây %.1f phút), cấm mở vị thế bào mòn ETF!",

                    clean_sym, counter_pair, (time.time() - last_counter_chop) / 60.0

                )



        # E1.5. STAND-ASIDE VETO KHI THANH KHOẢN CẠN KIỆT & NÉN BIÊN ĐỘ HẸP (ZERO EDGE):
        # Tránh giao dịch khi thị trường đi ngang cạn kiệt dòng tiền, râu nến trôi dạt (Edge ~ 0).
        macro_adx_pre = float((macro_analysis_pre or {}).get('adx') or 0.0)
        macro_atr_pct_pre = float((macro_analysis_pre or {}).get('tactical_atr_pct') or (macro_analysis_pre or {}).get('atr_pct') or 0.0)
        min_active_rvol = 0.35 if is_tradfi else (0.70 if is_crypto_altcoin else 0.60)
        is_liquidity_dry = (c_vol_ratio_pre < min_active_rvol) and not (is_buying_climax_candle or is_selling_climax_candle or is_whale_pump_storm_pre or is_waterfall_dump_pre)
        is_chop_range = (macro_adx_pre > 0.0 and macro_adx_pre < 18.0) or (0.0 < macro_atr_pct_pre < 0.35)
        
        if apply_entry_vetoes and is_liquidity_dry and is_chop_range and not has_strong_consensus:
            by_strategy.clear()
            self._record_veto(symbol_name, 'STAND_ASIDE_VETO', 'HOLD', f'RVol={c_vol_ratio_pre:.2f}x<{min_active_rvol:.2f}x, ADX={macro_adx_pre:.1f}')
            if log_vetoes:
                logger.warning(
                    "⏸️ [STAND-ASIDE VETO - ZERO EDGE (%s)]: Thanh khoản cạn kiệt (RVol=%.2fx < %.2fx) và biên độ nén hẹp (ADX=%.1f, ATR=%.2f%%). Đứng ngoài bảo vệ vốn!",
                    symbol_name, c_vol_ratio_pre, min_active_rvol, macro_adx_pre, macro_atr_pct_pre
                )

        # E2. ÁP DỤNG CRYPTO MARKET-WIDE CHOP SHIELD (CHỈ CHO CRYPTO ALTCOIN, MIỄN TRỪ 100% TRADFI VÀ COIN MAJOR):

        chop_deadline = float(getattr(self, '_crypto_market_chop_until', 0.0) or 0.0)

        if apply_entry_vetoes and is_crypto_altcoin and (time.time() < chop_deadline):

            has_strong_trap = (

                any(

                    getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')

                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70

                    for s in signals

                )

                or (bool(by_strategy.get('trap_detector')) and abs(by_strategy['trap_detector'][0]) >= 0.70)

            )

            # Kịch Bản 2: Cho phép vượt rào Chop Shield nếu Altcoin có đồng thuận kỹ thuật độc lập mạnh mẽ (>= 2 chiến lược kỹ thuật >= 75% cùng chiều lệnh hoặc Trap >= 70%)

            has_strong_alt_momentum = agreeing_tech_count >= 2 and max(

                (

                    float(getattr(s, 'confidence', 0.0) or 0.0)

                    for s in signals

                    if getattr(s, 'strategy', '').lower() not in ('jev_agent', 'jevagent', 'ai_ensemble', 'aiensemble')

                    and (

                        (dominant_tech_dir > 0 and (getattr(s, 'signal', None) == Signal.BUY or getattr(s, 'direction', 0.0) > 0))

                        or (dominant_tech_dir < 0 and (getattr(s, 'signal', None) == Signal.SELL or getattr(s, 'direction', 0.0) < 0))

                    )

                ),

                default=0.0,

            ) >= 0.75

            if not (has_strong_trap or has_strong_alt_momentum):

                by_strategy.clear()
                self._record_veto(symbol_name, 'CRYPTO_CHOP_SHIELD_VETO', 'HOLD', 'Crypto Market-Wide Chop Shield active')

                if log_vetoes:

                    rem_m = max(0.0, (chop_deadline - time.time()) / 60.0)

                    logger.warning(

                        "🛡️ CRYPTO CHOP SHIELD VETO (%s): BTC/ETH đang trong vùng nén sideway cạn volume (còn %.1fm), cấm mở vị thế Altcoin trôi dạt!",

                        symbol_name, rem_m

                    )



        # F0. ĐỒNG BỘ BẢO VỆ LỆNH SELL KHI BULL TRAP + ĐA SỐ CHIẾN THUẬT (KỸ THUẬT/AI) XÁC NHẬN ĐỈNH XẢ HÀNG:
        # Khi xuất hiện Bull Trap thực sự (has_real_bull_trap) đồng thời có >= 2 chiến thuật khác (như TrendFollowing 15m SELL + AI Ensemble SELL,
        # hoặc >= 2 chiến thuật kỹ thuật độc lập SELL >= 60%) đồng thuận SELL tuyệt đối, nhưng JEV Agent nhìn xu hướng 4H/1H cũ vẫn báo BUY trễ pha:
        # [RULE 0 - JEV MTF TREND SHIELD]: TUYỆT ĐỐI CẤM pop('jev_agent') khi JEV Agent 4H đang BUY mạnh (jev_vote >= 0.70)!
        if apply_entry_vetoes and has_real_bull_trap and 'jev_agent' in by_strategy and jev_vote > 0:
            if jev_vote >= 0.70:
                if log_vetoes:
                    logger.info(
                        "🛡️ [TẦNG 3 - KHIÊN BẢO VỆ XU HƯỚNG 4H (%s)]: Giữ nguyên bảo trợ Xu hướng 4H MUA (%.1f%% >= 70%%); CẤM BÁN CẢN TÀU để bảo vệ tài khoản!",
                        symbol_name, jev_vote * 100
                    )
            else:
                non_jev_strats = {k: sum(v) / len(v) for k, v in by_strategy.items() if k != 'jev_agent' and v}
                non_ai_sell_count = sum(1 for k, v in non_jev_strats.items() if k != 'ai_ensemble' and v <= -0.60)
                if len(non_jev_strats) >= 2 and all(v <= -0.60 for v in non_jev_strats.values()) and non_ai_sell_count >= 2:
                    by_strategy.pop('jev_agent', None)



        # F. CHỐNG TRỄ PHA KHUNG 4H CỦA AI ENSEMBLE KHI ĐA SỐ CHIẾN THUẬT (KỸ THUẬT 15M + JEV AGENT >= 80%) ĐỒNG THUẬN TUYỆT ĐỐI:

        # Ví dụ METIS/USDT (Trend 15m BUY 80% + Trap 15m BUY 67% + JEV BUY 85%, ADX=32.0) hay ELSA/USDT (Trend 15m BUY 75% + JEV BUY 82%, ADX=31.0)

        # bị duy nhất phiếu SELL trễ pha trên khung 4H của AI Ensemble kéo điểm xuống.

        # BẮT BUỘC: Chỉ được bỏ qua phiếu ngược chiều của AI Ensemble khi chỉ số vĩ mô đạt chuẩn Tầng 4:

        # ADX >= 30.0 và ATR < 5.0% (chặn đứng BLUAI ADX=17.0, VELODROME ADX=28.7, RSR#2 ADX=26.6 ATR=5.16%)!

        if apply_entry_vetoes and 'ai_ensemble' in by_strategy and 'jev_agent' in by_strategy:

            ma_vote = next(

                (

                    s.metadata.get('market_analysis')

                    for s in signals

                    if isinstance(getattr(s, 'metadata', None), dict)

                    and isinstance(s.metadata.get('market_analysis'), dict)

                ),

                {},

            )

            try:

                vote_adx = float((ma_vote or {}).get('adx') or 0.0)

            except (TypeError, ValueError):

                vote_adx = 0.0

            try:

                vote_atr = float((ma_vote or {}).get('tactical_atr_pct') or (ma_vote or {}).get('atr_pct') or 0.0)

            except (TypeError, ValueError):

                vote_atr = 0.0

            macro_ok_for_rule_f = (vote_adx <= 0.0 or vote_adx >= 30.0) and (vote_atr <= 0.0 or vote_atr < 5.0)



            ai_v = (sum(by_strategy['ai_ensemble']) / len(by_strategy['ai_ensemble'])) if by_strategy.get('ai_ensemble') else 0.0
            other_strats = {k: sum(v) / len(v) for k, v in by_strategy.items() if k != 'ai_ensemble' and v and len(v) > 0}

            tech_strats = {k: v for k, v in other_strats.items() if k != 'jev_agent'}

            tech_max = max(abs(v) for v in tech_strats.values()) if tech_strats else 0.0



            # =========================================================================

            # QUY TẮC PHỦ QUYẾT XUNG ĐỘT AI TUYỆT ĐỐI (AI HARD CONSENSUS VETO)

            # KIỂM CHỨNG ĐỊNH LƯỢNG TRÊN 274 LỆNH LỊCH SỬ THỰC TẾ & MÔ PHỎNG NẾN 15M:

            # -------------------------------------------------------------------------

            # [LÝ DO BẮT BUỘC KHÔNG ĐƯỢC PHÉP THAY ĐỔI CÔNG THỨC / THAM SỐ NÀY]:

            # Trong lịch sử thực chiến, các lệnh lỗ nặng nhất (BOT/USDT, LAB/USDT, ERA/USDT,

            # GTC/USDT, AIOT/USDT, và gần đây nhất là KGEN/USDT -0.13$, 1000PEPE/USDT -0.06$,

            # ID/USDT -0.07$) đều xảy ra do cùng 1 nguyên nhân:

            # - Chỉ báo kỹ thuật (trend_following / momentum) và LLM thấy nến vừa pump mạnh

            #   nên ADX vọt lên >= 35 và hô BUY (> 85%).

            # - Nhưng mô hình Machine Learning (AI Ensemble 91 đặc trưng) nhận diện Order Flow

            #   kiệt sức (Volume Exhaustion) và RSI quá mua nên cảnh báo SELL cực mạnh (79% - 87%).

            # - Quy tắc cũ cố tình "bỏ qua phiếu trễ pha của AI Ensemble" để đu đỉnh, dẫn tới

            #   mua đúng râu nến cao trào và dính Stop-Loss 100% các lần!

            #

            # KẾT QUẢ MÔ PHỎNG THỰC NGHIỆM:

            # - Khi TUYỆT ĐỐI KHÔNG BỎ QUA AI ENSEMBLE đối kháng mạnh (conf >= 0.70), 12 lệnh

            #   đu đỉnh lớn nhất lịch sử bị triệt tiêu 100%.

            # - Tỷ lệ thắng (Win Rate) tăng từ 61.7% lên 64.5%.

            # - Profit Factor nhảy vọt từ 1.39 lên 1.84 (và đạt 2.36 khi kết hợp Payoff Floor).

            # - BẤT KỲ AI ASSISTANT NÀO TRONG TƯƠNG LAI NẾU MUỐN THAY ĐỔI ĐOẠN CODE NÀY BẮT BUỘC

            #   PHẢI CHẠY LẠI MÔ PHỎNG scratch_full_historical_simulation.py ĐỂ KIỂM CHỨNG!

            # =========================================================================

            is_extreme_ai_conflict = (

                (all(v >= 0.60 for v in other_strats.values()) and ai_v <= -0.70) or

                (all(v <= -0.60 for v in other_strats.values()) and ai_v >= 0.70)

            )

            is_major_or_tradfi = is_tier1 or is_tradfi
            tactical_adx_pre_val = float((ma_vote or {}).get('tactical_adx') or (macro_analysis_pre or {}).get('tactical_adx') or 0.0)
            macro_adx_pre_val = float((ma_vote or {}).get('adx') or (macro_analysis_pre or {}).get('adx') or 0.0)
            regime_pre_val = str((ma_vote or {}).get('regime') or (macro_analysis_pre or {}).get('regime') or '').lower()
            min_climax_wave_pre = 0.018 if is_crypto_altcoin else 0.010
            # [BOM #95E FIX]: Chan VK6/PHA 2 xoa trang AI BUY >=70% khi:
            # (1) chop chet macro_adx < 20 hoac tactical_adx < 19 (ca JCT ADX=17.6!),
            # (2) co rau duoi >= 22%,
            # (3) trong strong_downtrend nhung chua co song bom thuc su (Pump < 1.8% & RSI < 65 — ca BEAT!),
            # (4) hoac < 2 chien thuat ky thuat khi dump/RSI/RVol yeu.
            is_weak_climax_ai_buy_conflict = (
                jev_vote <= -0.70
                and ai_v >= 0.70
                and (
                    (0.0 < tactical_adx_pre_val < 19.0)
                    or (0.0 < macro_adx_pre_val < 20.0)
                    or (c_lower_wick_pre >= 0.22)
                    or (('downtrend' in regime_pre_val or 'high_volatility' in regime_pre_val) and c_recent_pump_pre < min_climax_wave_pre and 0.0 < tactical_rsi_pre < 65.0)
                    or (len(tech_strats) < 2 and c_recent_dump_pre < 0.010 and 0.0 < tactical_rsi_pre < 70.0 and 0.0 < c_vol_ratio_pre < 2.0)
                )
            )
            # Doi xung 100% cho chieu LONG (chan xoa trang AI SELL <= -70% trong chop chet / rau tren >= 22% / uptrend-high_vol chua xa du!)
            is_weak_climax_ai_sell_conflict = (
                jev_vote >= 0.70
                and ai_v <= -0.70
                and (
                    (0.0 < tactical_adx_pre_val < 19.0)
                    or (0.0 < macro_adx_pre_val < 20.0)
                    or (c_upper_wick_pre >= 0.22)
                    or (('uptrend' in regime_pre_val or 'high_volatility' in regime_pre_val) and c_recent_dump_pre < min_climax_wave_pre and tactical_rsi_pre > 35.0)
                    or (len(tech_strats) < 2 and c_recent_pump_pre < 0.010 and tactical_rsi_pre > 30.0 and 0.0 < c_vol_ratio_pre < 2.0)
                )
            )
            # [BOM #141 + BOM #145 FIX]: Đọc cảnh báo rủi ro 5M từ JEV LLM TRƯỚC khi xét cả Macro Dual-Brain lẫn Altcoin Override
            _jev_risk_txt_pre = " ".join(
                str((getattr(s, 'metadata', None) or {}).get('risk_factors') or '').lower()
                for s in signals if str(getattr(s, 'strategy', '')).lower() == 'jev_agent'
            )
            _jev_warns_5m_bear_pre = any(k in _jev_risk_txt_pre for k in ('5m bearish', '5m red', '5m waterfall', '5m selling'))
            _jev_warns_5m_bull_pre = any(k in _jev_risk_txt_pre for k in ('5m bullish', '5m green', '5m buying', '5m pump'))
            _macro_5m_conflict_pre = (
                (jev_vote > 0 and ai_v <= -0.78 and _jev_warns_5m_bear_pre)
                or (jev_vote < 0 and ai_v >= 0.78 and _jev_warns_5m_bull_pre)
            )
            has_macro_dual_brain = (
                is_major_or_tradfi
                and not _macro_5m_conflict_pre
                and len(other_strats) >= 2
                and abs(jev_vote) >= 0.70
                and (ai_v * jev_vote < 0)
                and all(v * jev_vote > 0 and abs(v) >= 0.60 for v in other_strats.values())
            )
            # [BÀI HỌC 108 & RULE 0 - SMART EXHAUSTION DUAL-PHASE ALIGNMENT CHO ALTCOINS]:
            # Chiều Short: Khi JEV 4H (<= -70%) và các chiến thuật kỹ thuật/bẫy giá đều đồng thuận SELL trên nến kiệt sức
            # có râu trên vật lý >= 35% hoặc Climax, hạ quyền biểu quyết của AI Ensemble trễ pha xuống mức tư vấn!
            has_strong_bull_trap_reversal = (
                has_real_bull_trap
                and 'trap_detector' in by_strategy
                and any(
                    getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                    and getattr(s, 'signal', None) == Signal.SELL
                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                    for s in signals
                )
            )
            has_alt_exhaustion_short_override = (
                not is_major_or_tradfi
                and not is_weak_climax_ai_buy_conflict
                and not (ai_v >= 0.78 and _jev_warns_5m_bull_pre)
                and len(other_strats) >= 2
                and jev_vote <= -0.70
                and ai_v >= 0.70
                and all(v <= -0.60 for v in other_strats.values())
                and (c_upper_wick_pre >= 0.35 or is_buying_climax_candle or has_strong_bull_trap_reversal)
            )
            # Chiều Long (Đối xứng 100%): Khi JEV 4H (>= +70%) và các chiến thuật kỹ thuật/bẫy giá đều đồng thuận BUY
            # trên nến rút chân gom đáy có râu dưới vật lý >= 35% hoặc Selling Climax, hạ quyền biểu quyết của AI Ensemble trễ pha!
            has_alt_exhaustion_bounce_long_override = (
                not is_major_or_tradfi
                and not is_weak_climax_ai_sell_conflict
                and not (ai_v <= -0.78 and _jev_warns_5m_bear_pre)
                and len(other_strats) >= 2
                and jev_vote >= 0.70
                and ai_v <= -0.70
                and all(v >= 0.60 for v in other_strats.values())
                and (c_lower_wick_pre >= 0.35 or is_selling_climax_candle or has_strong_trap_reversal)
            )

            if is_extreme_ai_conflict and not (has_macro_dual_brain or has_alt_exhaustion_short_override or has_alt_exhaustion_bounce_long_override):
                # [BOM #95D FIX]: Chi danh dau is_extreme_ai_conflict trong trap_ctx khi co >= 2 chien thuat khac dong thuan (nhu HUMA: Trap SELL + JEV SELL vs AI BUY 82.3%),
                # KHONG danh dau khi chi co duy nhat 1 JEV don le can 1 lenh ky thuat+AI nguoc chieu (do la cong T3_JEV_SHIELD_NEED_2_STRATS cua VK11!).
                if len(other_strats) >= 2:
                    trap_ctx_data['is_extreme_ai_conflict'] = True

                # Tuyệt đối giữ nguyên phiếu của AI Ensemble để triệt tiêu điểm số và kích hoạt Micro Consensus Veto trên Altcoins

                logger.warning(

                    "⚠️ [XUNG ĐỘT AI CỰC ĐỘ - BẢO VỆ TỐI THƯỢNG] (%s): Các chiến thuật khác đồng thuận (%s) nhưng AI Ensemble kiên quyết đối kháng (%s %.1f%%)! Tuyệt đối KHÔNG bỏ qua phiếu AI Ensemble để tránh bẫy đu đỉnh cao trào!",

                    symbol_name, "BUY" if ai_v < 0 else "SELL", "SELL" if ai_v < 0 else "BUY", abs(ai_v) * 100

                )

            elif has_macro_dual_brain:

                # Với Major Crypto & TradFi: Khi JEV LLM 4H & Trend đã chỉ huy xu hướng (>= 70%),
                # hạ quyền biểu quyết của Não Tĩnh ML xuống mức tư vấn để bảo toàn xu hướng vĩ mô,
                # chuyển sang rình Limit Maker ở nhịp retest M1 Sniper!
                by_strategy.pop('ai_ensemble', None)
                trap_ctx_data['ai_popped_by_macro_dual_brain'] = True
                logger.info(
                    "⚡ [KB 10 DUAL-BRAIN ALIGNMENT] %s (%s): JEV LLM 4H & Trend (%.0f%%) chỉ huy xu hướng vĩ mô, hạ trọng số ML từ 1.2 xuống mức tư vấn đón nhịp retest M1 Sniper!",
                    symbol_name, "Major Crypto" if is_tier1 else "TradFi", abs(jev_vote) * 100
                )

            elif has_alt_exhaustion_short_override:

                # Với Altcoins: Khi JEV 4H và kỹ thuật xác nhận đỉnh xả có râu >= 35%,
                # hạ phiếu ML trễ pha xuống mức tư vấn để bắt nhịp sập Pha 2 thuận dòng tiền cá mập
                by_strategy.pop('ai_ensemble', None)
                trap_ctx_data['ai_popped_by_fading_short'] = True
                logger.info(
                    "⚡ [PHA 2 EXHAUSTION FADING SHORT] %s: JEV 4H & Kỹ thuật (%.0f%% SELL) xác nhận xả đỉnh có râu trên (%.1f%% >= 35%%), hạ trọng số ML trễ pha từ 1.2 xuống mức tư vấn!",
                    symbol_name, abs(jev_vote) * 100, c_upper_wick_pre * 100
                )

            elif has_alt_exhaustion_bounce_long_override:

                by_strategy.pop('ai_ensemble', None)
                trap_ctx_data['ai_popped_by_exhaustion_long'] = True
                logger.info(
                    "⚡ [PHA 3 EXHAUSTION BOUNCE LONG] %s: JEV 4H & Kỹ thuật (%.0f%% BUY) xác nhận rút chân gom đáy có râu dưới (%.1f%% >= 35%%), hạ trọng số ML trễ pha từ 1.2 xuống mức tư vấn!",
                    symbol_name, abs(jev_vote) * 100, c_lower_wick_pre * 100
                )

            elif len(other_strats) >= 2 and len(tech_strats) >= 1 and macro_ok_for_rule_f:

                # Chỉ cho phép bỏ qua AI Ensemble khi AI Ensemble chỉ lưỡng lự nhẹ (|ai_v| < 0.50)

                # và kỹ thuật thực sự có đồng thuận vĩ mô, tuyệt đối không bỏ qua khi AI Ensemble phản kháng mạnh.

                if all(v >= 0.60 for v in other_strats.values()) and jev_vote >= 0.80 and -0.50 < ai_v < 0:

                    by_strategy.pop('ai_ensemble', None)

                    logger.info(

                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận BUY mạnh, bỏ qua phiếu lưỡng lự nhẹ của AI Ensemble (%.1f%% < 50%%)!",

                        symbol_name, len(other_strats), jev_vote * 100, abs(ai_v) * 100

                    )

                elif all(v <= -0.60 for v in other_strats.values()) and jev_vote <= -0.80 and 0 < ai_v < 0.50:

                    by_strategy.pop('ai_ensemble', None)

                    logger.info(

                        "⚡ ĐỒNG THUẬN ĐA SỐ MTF (%s): %d chiến thuật Kỹ thuật + JEV Agent (%.0f%%) đồng thuận SELL mạnh, bỏ qua phiếu lưỡng lự nhẹ của AI Ensemble (%.1f%% < 50%%)!",

                        symbol_name, len(other_strats), abs(jev_vote) * 100, abs(ai_v) * 100

                    )



        for name, strategy_signals in by_strategy.items():
            if not strategy_signals:
                continue
            # Conflicting timeframes from the same strategy cancel each other.
            vote = sum(strategy_signals) / max(1, len(strategy_signals))
            weight = self.strategy_weights.get(name, 0.1)
            if weight > 0:
                votes[name] = (vote, weight)
        return votes



    def _htf_conflicting_frames(
        self,
        signals: List[TradeSignal],
        active_votes: Optional[Dict[str, Tuple[float, float]]] = None,
    ) -> List[dict]:

        """[P2] Tìm các chiến thuật báo NGƯỢC CHIỀU trên nhiều khung thời gian.



        Chỉ xét khung thời gian có thật trong ``signal.metadata['timeframe']`` (do

        ``core/bot.py`` gắn khi chạy chiến thuật đa khung) và giữ tín hiệu tự tin nhất

        cho mỗi cặp (chiến thuật, khung). Một chiến thuật bị coi là xung đột khi tồn tại

        đồng thời một khung BUY và một khung SELL, cả hai đều >= ngưỡng tự tin.

        Nếu ``active_votes`` được truyền vào, bỏ qua các chiến thuật đã bị vô hiệu hóa

        hoặc loại bỏ hợp lệ trong ``_strategy_votes()`` (như Bull/Bear Trap dilution

        hoặc Smart Inversion loại bỏ Trap giả không râu).

        """

        frames: Dict[str, Dict[str, Tuple[float, float]]] = {}

        sym_chk = signals[0].symbol if signals else ''

        trap_ctx = {}

        with getattr(self, '_agg_lock', threading.RLock()):
            if hasattr(self, '_trap_contexts_by_symbol') and sym_chk:
                clean_s1 = sym_chk.split(':')[0].strip().upper()
                trap_ctx = (
                    self._trap_contexts_by_symbol.get(sym_chk, {})
                    or self._trap_contexts_by_symbol.get(clean_s1, {})
                    or self._trap_contexts_by_symbol.get(sym_chk.replace('/', '').upper(), {})
                    or self._trap_contexts_by_symbol.get(clean_s1.replace('/', '').upper(), {})
                )
            if not trap_ctx:
                last_ctx = getattr(self, '_last_trap_context', {}) if isinstance(getattr(self, '_last_trap_context', None), dict) else {}
                if not sym_chk or last_ctx.get('symbol') in (sym_chk, sym_chk.split(':')[0].strip().upper()):
                    trap_ctx = last_ctx

        has_confirmed_15m_override = bool(
            active_votes is not None
            and (
                trap_ctx.get('has_real_bull_trap')
                or trap_ctx.get('has_real_bear_trap')
                or trap_ctx.get('is_waterfall_dump')
                or trap_ctx.get('is_whale_pump_storm')
            )
        )

        for sig in signals or []:

            if sig.signal == Signal.BUY:

                direction = 1.0

            elif sig.signal == Signal.SELL:

                direction = -1.0

            else:

                continue

            metadata = getattr(sig, 'metadata', None)

            timeframe = str((metadata or {}).get('timeframe') or '').strip().lower()

            if not timeframe:

                continue

            try:

                confidence = float(sig.confidence)

            except (TypeError, ValueError):

                continue

            if not math.isfinite(confidence) or not (0.0 <= confidence <= 1.0):

                continue

            name = re.sub(r'(?<!^)(?=[A-Z])', '_', sig.strategy).lower()

            if active_votes is not None and name not in active_votes:

                continue

            if has_confirmed_15m_override and timeframe == '1h':

                # [BOM #140 FIX]: Chỉ miễn trừ chân 1H khi Climax/Whale/Waterfall 15M KHỚP ĐÚNG CHIỀU với active_dir
                # và đã đạt ngưỡng volume tối thiểu (không dùng selling climax miễn cho lệnh SHORT hoặc ngược lại!).
                active_dir = active_votes.get(name, (0.0, 0.0))[0] if active_votes else 0.0
                _clx_uw_htf = float(trap_ctx.get('c_upper_wick_pct') or 0.0)
                _clx_lw_htf = float(trap_ctx.get('c_lower_wick_pct') or 0.0)
                _clx_rv_htf = float(trap_ctx.get('c_vol_ratio') or 0.0)
                is_climax_or_whale_aligned = (
                    (active_dir > 0 and (
                        bool(trap_ctx.get('is_whale_pump_storm'))
                        or (bool(trap_ctx.get('is_true_climax_15m')) and _clx_lw_htf >= 0.40 and _clx_rv_htf >= 0.85)
                    ))
                    or (active_dir < 0 and (
                        bool(trap_ctx.get('is_waterfall_dump'))
                        or (bool(trap_ctx.get('is_true_climax_15m')) and _clx_uw_htf >= 0.40 and _clx_rv_htf >= 0.85)
                    ))
                )
                # [BOM #150 P2 FIX]: Đồng bộ công bằng tất cả chiến thuật — CHỈ bỏ qua chân 1H ngược chiều khi Climax/Whale/Waterfall 15M thực sự khớp chiều!
                if is_climax_or_whale_aligned and active_dir * direction < 0:
                    continue

            per_tf = frames.setdefault(name, {})

            prev = per_tf.get(timeframe)

            if prev is None or confidence > prev[1]:

                per_tf[timeframe] = (direction, confidence)



        try:

            threshold = float(getattr(self, 'htf_conflict_min_confidence', 0.60) or 0.60)

        except (TypeError, ValueError, OverflowError):

            threshold = 0.60



        conflicts: List[dict] = []

        for name, per_tf in frames.items():

            long_legs = [(tf, conf) for tf, (d, conf) in per_tf.items() if d > 0 and conf >= threshold]

            short_legs = [(tf, conf) for tf, (d, conf) in per_tf.items() if d < 0 and conf >= threshold]

            if long_legs and short_legs:

                conflicts.append({

                    'strategy': name,

                    'long': sorted(long_legs, key=lambda item: -item[1]),

                    'short': sorted(short_legs, key=lambda item: -item[1]),

                })

        return conflicts



    def calculate_weighted_score(self, signals: List[TradeSignal], votes: Optional[Dict[str, Tuple[float, float]]] = None, apply_entry_vetoes: bool = True, market_chop_context: Optional[Dict[str, Dict[str, float]]] = None) -> float:

        """Return the weighted mean of active strategy votes, in [-1, 1].
        Loại bỏ các chiến thuật tự triệt tiêu đa khung thời gian (|vote| < 0.15)
        để không làm pha loãng mẫu số total_weight của các chiến thuật có tín hiệu thật.
        """

        if votes is None:

            votes = self._strategy_votes(signals, apply_entry_vetoes=apply_entry_vetoes, market_chop_context=market_chop_context)

        active_votes = [(vote, weight) for vote, weight in votes.values() if abs(vote) >= 0.15]
        if not active_votes:
            active_votes = list(votes.values())

        total_weight = sum(weight for _, weight in active_votes)

        if total_weight <= 0:

            return 0.0

        return sum(vote * weight for vote, weight in active_votes) / total_weight



    def _entry_threshold(self, agreeing: int = 0) -> float:

        """Ngưỡng điểm tối thiểu thực tế để cấp lệnh = max(confidence_threshold, min_signal_score)."""

        try:

            floor = float(getattr(self, 'min_signal_score', 0.0) or 0.0)

        except (TypeError, ValueError):

            floor = 0.0

        base_threshold = max(float(self.confidence_threshold), floor)

        # Nếu có từ 3 chiến thuật trở lên đồng thuận tuyệt đối (agreeing >= 3) và ngưỡng gốc >= 0.80,

        # cho phép hạ sàn xuống 0.75 để không bỏ lỡ các siêu sóng bùng nổ (như LSK +33.6%, SPK -5.2%).

        if agreeing >= 3 and base_threshold >= 0.75:

            return 0.72

        return base_threshold



    def determine_final_signal(self, score: float, symbol: str, price: float, threshold: Optional[float] = None) -> TradeSignal:

        abs_score = abs(score)

        eff_threshold = threshold if threshold is not None else self._entry_threshold()

        if abs_score >= eff_threshold:

            direction = Signal.BUY if score > 0 else Signal.SELL

        else:

            direction = Signal.HOLD



        return TradeSignal(

            signal=direction,

            symbol=symbol,

            confidence=abs_score,

            strategy='aggregated',

            price=price,

        )



    def _aggregate_protection_level(

        self, signals: List[TradeSignal], final_signal: Signal, price: float, field: str,

    ) -> Optional[float]:

        """Carry a robust, directionally valid strategy SL/TP into the final vote.



        Aggregate percentage distances rather than absolute prices because each

        timeframe can report a slightly different last price. First collapse a

        strategy's timeframes with a median, then take a strategy-weighted median

        so one unusually wide stop/target cannot dominate the result.

        """

        if final_signal not in (Signal.BUY, Signal.SELL):

            return None

        try:

            reference_price = float(price)

        except (TypeError, ValueError, OverflowError):

            return None

        if not math.isfinite(reference_price) or reference_price <= 0:

            return None



        distances_by_strategy: Dict[str, List[float]] = {}

        for signal in signals:

            if signal.signal != final_signal:

                continue

            try:

                signal_price = float(signal.price)

                level = float(getattr(signal, field))

            except (TypeError, ValueError, OverflowError):

                continue

            if not math.isfinite(signal_price) or signal_price <= 0 or not math.isfinite(level) or level <= 0:

                continue



            if field == 'stop_loss':

                distance = (signal_price - level) / signal_price if final_signal == Signal.BUY else (level - signal_price) / signal_price

            else:

                distance = (level - signal_price) / signal_price if final_signal == Signal.BUY else (signal_price - level) / signal_price

            if not math.isfinite(distance) or distance <= 0:

                continue



            name = re.sub(r'(?<!^)(?=[A-Z])', '_', signal.strategy).lower()

            distances_by_strategy.setdefault(name, []).append(distance)



        weighted_distances = []

        for name, distances in distances_by_strategy.items():

            weight = self.strategy_weights.get(name, 0.1)

            if weight > 0:

                weighted_distances.append((statistics.median(distances), weight))

        if not weighted_distances:

            return None



        weighted_distances.sort(key=lambda item: item[0])

        half_weight = sum(weight for _, weight in weighted_distances) / 2.0

        cumulative = 0.0

        distance = weighted_distances[-1][0]

        for candidate, weight in weighted_distances:

            cumulative += weight

            if cumulative >= half_weight:

                distance = candidate

                break



        if final_signal == Signal.BUY:

            level = reference_price * (1.0 - distance) if field == 'stop_loss' else reference_price * (1.0 + distance)

        else:

            level = reference_price * (1.0 + distance) if field == 'stop_loss' else reference_price * (1.0 - distance)

        return level if math.isfinite(level) and level > 0 else None



    def aggregate(self, signals: List[TradeSignal], market_chop_context: Optional[Dict[str, Dict[str, float]]] = None) -> Optional[TradeSignal]:

        if not signals:

            return None

        if isinstance(signals, dict):
            signals = list(signals.values())
            if not signals:
                return None

        symbol = signals[0].symbol
        _raw_ai_votes = []
        for _s_ai_r in signals:
            if str(getattr(_s_ai_r, 'strategy', '')).lower() in ('ai_ensemble', 'aiensemble'):
                _s_val_r = getattr(_s_ai_r, 'signal', None)
                _c_val_r = float(getattr(_s_ai_r, 'confidence', 0.0) or 0.0)
                if _s_val_r == Signal.BUY:
                    _raw_ai_votes.append(_c_val_r)
                elif _s_val_r == Signal.SELL:
                    _raw_ai_votes.append(-_c_val_r)
        _raw_orig_ai_vote = (sum(_raw_ai_votes) / len(_raw_ai_votes)) if _raw_ai_votes else 0.0
        if hasattr(self, '_last_veto_info'):
            _clean_init_s = str(symbol).split(':')[0].strip().upper()
            with getattr(self, '_agg_lock', threading.RLock()):
                self._last_veto_info.pop(symbol, None)
                self._last_veto_info.pop(_clean_init_s, None)
                self._last_veto_info.pop(_clean_init_s.replace('/', ''), None)

        pre_llm_veto = next(

            (

                s for s in signals

                if isinstance(getattr(s, 'metadata', None), dict)

                and isinstance(s.metadata.get('pre_llm_entry_veto'), dict)

            ),

            None,

        )

        # [V6.1 BOM #39]: Kiem tra co mien Fast-Skip (SLOT_A) cho Vu Khi Dong dang bat hay khong
        dyn_slot_a_exempt_sig = next(
            (
                s for s in signals
                if isinstance(getattr(s, 'metadata', None), dict)
                and s.metadata.get('dyn_slot_a_exempt')
            ),
            None,
        )

        if pre_llm_veto and not dyn_slot_a_exempt_sig:

            veto_data = pre_llm_veto.metadata['pre_llm_entry_veto']

            logger.info(

                '🛡️ [TẦNG 3 - TỪ CHỐI CẤU TRÚC] Hủy mở lệnh %s: Thiếu xác nhận cấu trúc xu hướng 4H (%s); đứng ngoài bảo vệ vốn.',

                symbol, veto_data.get('reason', veto_data.get('status', 'unknown')),

            )

            return None



        jev_signals = [

            s for s in signals

            if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')

        ]

        if not jev_signals and not dyn_slot_a_exempt_sig:

            logger.warning(

                '🛡️ [JEV AVAILABILITY VETO] Hủy ứng viên %s: không có kết quả JEV/MTF; không cấp lệnh khi tầng này chưa chạy.',

                symbol,

            )

            return None



        unavailable_jev = next(

            (

                s for s in signals

                if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')

                and isinstance(getattr(s, 'metadata', None), dict)

                and s.metadata.get('availability_status') not in (None, '', 'ok')

            ),

            None,

        )

        if unavailable_jev:

            status = unavailable_jev.metadata.get('availability_status', 'unavailable')

            logger.warning(

                '🛡️ [JEV AVAILABILITY VETO] Hủy ứng viên %s: Ollama/JEV đang ở trạng thái %s; tiếp tục quét coin kế tiếp.',

                symbol, status,

            )

            return None



        price = signals[0].price

        clean_sym_agg = symbol.split(':')[0].strip().upper()

        clean_base_agg = MarketScanner._clean_base(symbol)

        is_tier1 = any(clean_base_agg == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))

        _agg_ex_main = getattr(getattr(self, 'order_flow_analyzer', None), 'exchange', None)
        is_stock = MarketScanner.is_tradfi_stock(symbol, exchange=_agg_ex_main)

        is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol, exchange=_agg_ex_main)

        is_tradfi = is_stock or is_commodity

        is_crypto_altcoin = (not is_tier1) and (not is_tradfi)



        has_cold_start = any(

            isinstance(getattr(s, 'metadata', None), dict)

            and s.metadata.get('status') == 'cold_start_warmup'

            for s in signals

        )



        votes = self._strategy_votes(signals, market_chop_context=market_chop_context)
        if not votes:
            # [BOM #110B FIX]: Nếu _strategy_votes() đã xóa sạch phiếu (JEV VETO CONSOLIDATION,
            # INVERSE ETF CROSS-VETO, STAND-ASIDE VETO, CRYPTO CHOP SHIELD), tuyệt đối dừng ngay
            # để VK10 / Dynamic Weapons (VK11..14) không "hồi sinh xác sống" từ signals thô!
            return None

        score = self.calculate_weighted_score(signals, votes=votes)

        agreeing = sum(1 for vote, _ in votes.values() if abs(vote) >= 0.15 and vote * score > 0)

        # [BÀI HỌC 102 - TÁCH ĐỒNG THUẬN KỸ THUẬT VÀ MÔ HÌNH AI/LLM]:
        # AI Ensemble và JEV Agent là hai mô hình tương quan (AI học từ đặc trưng kỹ thuật; JEV đọc các khung nến).
        # Tách agreeing_tech để kiểm soát cổng đồng thuận tối thiểu (min_agreeing_strategies) và Opposing Veto,
        # tránh trường hợp 1 kỹ thuật + AI + JEV = 3 tự thổi phồng số lượng chiến thuật kỹ thuật.
        # Đồng thời yêu cầu abs(vote) >= 0.15 để chiến thuật tự triệt tiêu (15m BUY + 1h SELL -> -0.005) không bị đếm ảo là 1 phiếu đồng thuận!
        _non_technical_voters = ('ai_ensemble', 'jev_agent')
        agreeing_tech = sum(
            1 for name, (vote, _) in votes.items()
            if abs(vote) >= 0.15 and vote * score > 0 and name not in _non_technical_voters
        )
        require_tech_consensus = bool(getattr(self, 'consensus_require_technical', True))
        consensus_count = agreeing_tech if require_tech_consensus else agreeing

        entry_threshold = self._entry_threshold(agreeing)

        logger.info(

            '📊 [TẦNG 3 - HỘI ĐỒNG] Aggregated score for %s: %+.4f (threshold=%.2f, agreeing strategies=%d/%d, tech=%d)',

            symbol, score, entry_threshold, agreeing, len(votes), agreeing_tech,

        )



        # [P2] HTF CONFLICT VETO (chỉ áp dụng cho luồng MỞ LỆNH MỚI).

        # `_strategy_votes()` gộp các khung của cùng một chiến thuật bằng TRUNG BÌNH CỘNG

        # nên hai khung ngược chiều triệt tiêu nhau và xóa sạch cảnh báo (trap 1h SELL 67%

        # + 15m BUY 70% -> +0.015, vẫn "đồng thuận 3/3"). Một chiến thuật tự mâu thuẫn giữa

        # các khung là bất định thật sự -> không được cấp lệnh, bất kể `agreeing` bao nhiêu.

        if getattr(self, 'htf_conflict_veto', True):

            htf_conflicts = self._htf_conflicting_frames(signals, active_votes=votes)

            if htf_conflicts:

                detail_parts = []

                for conflict in htf_conflicts:

                    legs = (

                        [(tf, 'BUY', conf) for tf, conf in conflict['long']]

                        + [(tf, 'SELL', conf) for tf, conf in conflict['short']]

                    )

                    legs.sort(key=lambda item: item[0])

                    detail_parts.append(

                        conflict['strategy'] + ' ['

                        + ', '.join(f"{tf} {side} {conf * 100:.0f}%" for tf, side, conf in legs)

                        + ']'

                    )

                logger.warning(

                    '🛡️ [HTF CONFLICT VETO] Hủy mở lệnh %s: cùng một chiến thuật báo ngược chiều trên nhiều khung thời gian (ngưỡng %.0f%%), điểm tổng hợp %+.4f bị pha loãng bởi trung bình cộng: %s',

                    symbol, float(getattr(self, 'htf_conflict_min_confidence', 0.60)) * 100,

                    score, ' | '.join(detail_parts),

                )

                return None



        # Thu thập macro ADX và ATR từ market_analysis (nếu có) để chống bẫy Breakout giả & thẩm định vi mô

        macro_analysis = next(

            (

                s.metadata.get('market_analysis')

                for s in signals

                if isinstance(getattr(s, 'metadata', None), dict)

                and isinstance(s.metadata.get('market_analysis'), dict)

            ),

            {},

        )

        try:

            macro_adx = float((macro_analysis or {}).get('adx') or 0.0)

        except (TypeError, ValueError):

            macro_adx = 0.0

        try:

            tactical_adx = float((macro_analysis or {}).get('tactical_adx') or 0.0)

        except (TypeError, ValueError):

            tactical_adx = 0.0

        effective_adx = max(macro_adx, tactical_adx)

        try:

            macro_atr_pre = float((macro_analysis or {}).get('tactical_atr_pct') or (macro_analysis or {}).get('atr_pct') or 0.0)

        except (TypeError, ValueError):

            macro_atr_pre = 0.0



        # 0. COLD-START WARMUP VETO:

        # Nếu AI Ensemble vừa train mới (Cold-start Warmup), chỉ cho phép mở lệnh nếu:

        # - Model AI vừa train phải đạt Mean CV Accuracy >= 0.58 (tránh model học vẹt/nhiễu chỉ ngang tung đồng xu 53% như BABY/USDT).

        # - JEV Agent KHÔNG khuyến nghị HOLD (tránh thị trường nhiễu/lưỡng lự như PHA/USDT)

        # - Có >= 2 chiến thuật độc lập đồng thuận VÀ xu hướng vĩ mô mạnh (ADX >= 24.0, như INIT/USDT ADX=29.9 hay DOGE ADX=51.1).

        # Nếu JEV khuyến nghị HOLD hoặc ADX < 24.0 hoặc < 2 chiến thuật (như TIA/USDT ADX=19.1, FOGO 1/1, PHA 1/1), chặn 100%!

        _cold_start_veto_msg = None
        if has_cold_start:

            cs_sig = next((s for s in signals if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('status') == 'cold_start_warmup'), None)

            trained_cv = float((cs_sig.metadata.get('mean_cv_accuracy') or 0.0) if cs_sig else 0.0)

            if trained_cv < 0.58:
                # [BOM #122C FIX]: Hoan quyet dinh chan CV yeu toi sau evaluate_active_dynamic_weapons (L3242)
                # de Vu Khi Dong ai_votes=['NONE'] (VK14) duoc danh gia thuc su thay vi bi giet som!
                _cold_start_veto_msg = (
                    f"Model AI vừa train có độ chính xác CV yếu ({trained_cv * 100:.2f}% < 58.0%), không đủ tin cậy để cấp lệnh!"
                )
            else:
                cs_pred_str = str((cs_sig.metadata.get('prediction') or '') if cs_sig else '').strip().lower()
                cs_pred_conf = float((cs_sig.metadata.get('model_confidence') or 0.0) if cs_sig else 0.0)
                cs_pred_dir = 1.0 if cs_pred_str == 'up' else (-1.0 if cs_pred_str == 'down' else 0.0)
                if cs_pred_dir * score < 0 and cs_pred_conf >= 0.60:
                    logger.warning(
                        '⏳ [COLD-START OPPOSING VETO] Hủy mở lệnh %s: Model AI vừa khởi tạo mới dự báo ngược chiều (%s %.1f%% >= 60%%) trong chu kỳ Warm-up!',
                        symbol, 'BUY' if cs_pred_dir > 0 else 'SELL', cs_pred_conf * 100,
                    )
                    return None

                jev_sig_cs = next((s for s in signals if s.strategy.lower() in ('jev_agent', 'jevagent')), None)

                if jev_sig_cs and jev_sig_cs.signal == Signal.HOLD and not (macro_adx >= 40.0 and abs(score) >= 0.84 and agreeing >= 2):
                    _cold_start_veto_msg = (
                        'AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi JEV Agent phân tích MTF khuyến nghị HOLD!'
                    )
                elif agreeing < self.min_agreeing_strategies or macro_adx < 24.0:
                    _cold_start_veto_msg = (
                        f'AI Model vừa khởi tạo mới (Cold-start Warmup) trong khi ADX={macro_adx:.1f} < 24.0 '
                        f'hoặc đồng thuận={agreeing}/{self.min_agreeing_strategies} chưa đủ mạnh!'
                    )



        # [BÀI HỌC 101 - JEV HOLD VETO TOÀN DIỆN CHO MỌI ỨNG VIÊN]:
        # Khi JEV Agent MTF phân tích sâu (4H, 1H, 15M, 5M) và xác định thị trường lưỡng lự / tích lũy đi ngang / rủi ro
        # ra quyết định HOLD (confidence >= 0.55): BẮT BUỘC tôn trọng phán quyết của Master AI!
        # Tuyệt đối cấm để 1-2 chỉ báo kỹ thuật trễ pha (như 1H cũ) cướp quyền mở lệnh cản tàu (như thảm họa AXTI).
        # Miễn trừ duy nhất: Khi có Bão Volume Cá Mập (Whale Pump Storm / Waterfall Dump / Climax) HOẶC Siêu Đồng Thuận Số Đông (>= 3 kỹ thuật cùng chiều điểm >= 0.82).
        jev_sig_gen = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)
        if jev_sig_gen and getattr(jev_sig_gen, 'signal', None) == Signal.HOLD:
            jev_conf_hold = float(getattr(jev_sig_gen, 'confidence', 0.0) or 0.0)
            if jev_conf_hold >= 0.55:
                c_dump_h = float((macro_analysis or {}).get('recent_dump_pct') or 0.0)
                c_pump_h = float((macro_analysis or {}).get('recent_pump_pct') or 0.0)
                _raw_c_vol_h = (macro_analysis or {}).get('candle_vol_ratio')
                c_vol_h = float(_raw_c_vol_h) if _raw_c_vol_h is not None else 1.0
                c_uwick_h = float((macro_analysis or {}).get('upper_wick_pct') or 0.0)
                c_lwick_h = float((macro_analysis or {}).get('lower_wick_pct') or 0.0)
                
                jev_hold_txt = (
                    str(getattr(jev_sig_gen, 'metadata', {}).get('reason', '') or '')
                    + ' '
                    + str(getattr(jev_sig_gen, 'metadata', {}).get('risk_factors', '') or '')
                ).lower()
                is_jev_bearish_warning_for_short = (
                    score < 0
                    and agreeing >= 2
                    and not any(w in jev_hold_txt for w in ('choppy consolidation', 'flat sideways', 'support bounce', 'lower absorption wick', 'oversold'))
                    and any(
                        w in jev_hold_txt
                        for w in (
                            'heavy bearish', 'strong bearish', 'active dumping', 'active selling',
                            'no absorption wick', 'top rejection', 'upper rejection wick',
                            'bull trap', 'bull exhaustion', 'upside exhaustion', 'high-volume red'
                        )
                    )
                )
                # CHỈ CÓ THỰC LỰC CỦA DÒNG TIỀN CÁ MẬP THẬT SỰ (Vol bùng nổ >= 2.0x hoặc râu quét cực đại >= 45%)
                # HOẶC KHI JEV CẢNH BÁO XẢ ĐỈNH/DUMP KHÔNG RÂU THUẬN CHIỀU SHORT (score < 0, agreeing >= 2)
                # MỚI ĐƯỢC PHÉP OVERRIDE JEV HOLD! TUYỆT ĐỐI CẤM SỰ ĐỒNG THUẬN KỸ THUẬT DANH NGHĨA
                # (abs(score) >= 0.82) CƯỚP QUYỀN MỞ LỆNH KHI JEV CẢNH BÁO CẢN HOẶC TÍCH LŨY (như INTC/USDT)!
                has_whale_override = (
                    (c_vol_h >= 2.0 and (c_pump_h >= 0.025 or c_dump_h >= 0.025))
                    or (c_lwick_h >= 0.45 and c_vol_h >= 1.60 and c_dump_h >= 0.015)
                    or (c_uwick_h >= 0.45 and c_vol_h >= 1.60 and c_pump_h >= 0.015)
                    or is_jev_bearish_warning_for_short
                )
                if not has_whale_override:
                    _jev_guard_downgraded_h = bool((getattr(jev_sig_gen, 'metadata', None) or {}).get('guard_downgraded'))
                    _has_dyn_jev_hold_candidate = False
                    if not _jev_guard_downgraded_h:
                        try:
                            from core.quant_evolution_engine import evaluate_active_dynamic_weapons
                            _ac_h = 'TRADFI' if is_tradfi else ('MAJOR' if is_tier1 else 'ALTCOIN')
                            _ai_sig_h = next((s for s in (signals or []) if str(getattr(s, 'strategy', '')).lower() in ('ai_ensemble', 'aiensemble')), None)
                            _ai_v_h = 'NONE'
                            if _ai_sig_h is not None:
                                _is_cs_weak_h = bool(
                                    isinstance(getattr(_ai_sig_h, 'metadata', None), dict)
                                    and _ai_sig_h.metadata.get('status') == 'cold_start_warmup'
                                    and float(_ai_sig_h.metadata.get('mean_cv_accuracy') or 0.0) < 0.58
                                )
                                _avh_val = getattr(_ai_sig_h, 'signal', None)
                                _avh_conf = float(getattr(_ai_sig_h, 'confidence', 0.0) or 0.0)
                                if _is_cs_weak_h:
                                    _ai_v_h = 'NONE'
                                elif _avh_val == Signal.BUY and _avh_conf >= 0.58:
                                    _ai_v_h = 'BUY'
                                elif _avh_val == Signal.SELL and _avh_conf >= 0.58:
                                    _ai_v_h = 'SELL'
                                else:
                                    _ai_v_h = 'HOLD'
                            # [BOM #132 FIX]: Đọc hướng kỹ thuật từ signals gốc (không bị mất do votes.pop() trước đó) & không nhân 100 khi macro_atr_pre < 0.08!
                            _tb_h = sum(
                                1 for _sh in (signals or [])
                                if str(getattr(_sh, 'strategy', '')).lower() not in ('ai_ensemble', 'aiensemble', 'jev_agent', 'jevagent', 'market_analysis')
                                and getattr(_sh, 'signal', None) == Signal.BUY
                            )
                            _ts_h = sum(
                                1 for _sh in (signals or [])
                                if str(getattr(_sh, 'strategy', '')).lower() not in ('ai_ensemble', 'aiensemble', 'jev_agent', 'jevagent', 'market_analysis')
                                and getattr(_sh, 'signal', None) == Signal.SELL
                            )
                            _blk_h = 'LONG' if _tb_h > _ts_h else ('SHORT' if _ts_h > _tb_h else ('LONG' if score > 0 else ('SHORT' if score < 0 else '')))
                            _atr_pct_h = max(0.0, float(macro_atr_pre or 0.0))
                            _rsi_h = float((macro_analysis or {}).get('tactical_rsi') or (macro_analysis or {}).get('rsi') or 50.0)
                            # [BOM #125C FIX]: Dùng 4H macro_adx đồng bộ 100% với Pre-LLM & Shadow/LAB!
                            _adx_h = float(macro_adx if macro_adx > 0 else effective_adx)
                            _reg_h = str((macro_analysis or {}).get('regime') or '').lower()
                            _by_strat_h = {f"{str(getattr(s, 'strategy', '')).lower()}@{i_h}": s for i_h, s in enumerate(signals or [])}
                            _pref_wid_h = next(
                                (str(s.metadata.get('dyn_slot_a_exempt') or '') for s in (signals or []) if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('dyn_slot_a_exempt')),
                                '',
                            )
                            _dna_h = {
                                'atr_pct': _atr_pct_h, 'adx': _adx_h, 'rsi': _rsi_h, 'rvol': c_vol_h,
                                'u_wick_pct': c_uwick_h * 100.0, 'l_wick_pct': c_lwick_h * 100.0,
                                'pump_pct': c_pump_h * 100.0, 'dump_pct': c_dump_h * 100.0, 'regime': _reg_h,
                            }
                            for _vg_probe_h in ('', 'T3_JEV_SHIELD_NEED_2_STRATS', 'T3_AGGREGATOR_VETO', 'T2_FAST_SKIP_TWIN_WICK', 'T2_FAST_SKIP_COUNTER_TREND'):
                                _cand_h = evaluate_active_dynamic_weapons(
                                    symbol=symbol, asset_class=_ac_h, by_strategy=_by_strat_h,
                                    ai_vote=_ai_v_h, jev_vote='HOLD', candle_dna=_dna_h,
                                    veto_gate=_vg_probe_h, blocked_direction=_blk_h, preferred_weapon_id=_pref_wid_h,
                                )
                                if _cand_h is not None:
                                    _bp_h = _cand_h.get('blueprint') or {}
                                    _jv_h = {str(j).upper() for j in (_bp_h.get('jev_votes') or []) if j}
                                    _exp_j_single = str(_bp_h.get('jev_vote') or '').upper()
                                    if ('HOLD' in _jv_h or 'SKIP' in _jv_h or 'NONE' in _jv_h or 'ANY' in _jv_h) or (_exp_j_single in ('HOLD', 'SKIP', 'NONE', 'ANY', 'MULTI', '')):
                                        _has_dyn_jev_hold_candidate = True
                                        break
                        except Exception:
                            _has_dyn_jev_hold_candidate = False
                    jev_hold_reason = str(getattr(jev_sig_gen, 'metadata', {}).get('reason', '') or 'Thị trường lưỡng lự/nhiễu vi mô')
                    if not _has_dyn_jev_hold_candidate:
                        logger.warning(
                            f"🛡️ [JEV HOLD VETO] Hủy mở lệnh {symbol}: JEV Agent MTF (Ollama LLM) khuyến nghị HOLD (Conf: {jev_conf_hold:.1%}) - {jev_hold_reason}! Cấm mở lệnh khi Master AI cảnh báo rủi ro."
                        )
                        return None
                    # [BOM #126B FIX]: Ghi cờ cưỡng chế hoãn — nếu xuống cuối KHÔNG mở khóa Vũ Khí Động (dyn_vk_unlocked=False)
                    # thì BẮT BUỘC phải áp dụng lại JEV HOLD VETO, cấm vũ khí thường (VK1..VK8) lọt lưới!
                    _jev_hold_veto_deferred_msg = f"JEV Agent MTF khuyến nghị HOLD (Conf: {jev_conf_hold:.1%}) - {jev_hold_reason}"

        # [BOM #140 FIX]: Nạp trap_ctx TRƯỚC WEAK-ADX BREAKOUT VETO để miễn trừ Whale Pump Storm & Waterfall Dump
        # (tránh phiếu tổng hợp momentum_breakout tự hủy sóng cá mập khi ADX 4H < 22!).
        trap_ctx = {}

        with getattr(self, '_agg_lock', threading.RLock()):
            if hasattr(self, '_trap_contexts_by_symbol'):
                trap_ctx = (
                    self._trap_contexts_by_symbol.get(symbol, {})
                    or self._trap_contexts_by_symbol.get(clean_sym_agg, {})
                    or self._trap_contexts_by_symbol.get(symbol.replace('/', '').upper(), {})
                    or self._trap_contexts_by_symbol.get(clean_sym_agg.replace('/', '').upper(), {})
                )
            if not trap_ctx:
                last_ctx = getattr(self, '_last_trap_context', {}) or {}
                if not symbol or last_ctx.get('symbol') in (symbol, clean_sym_agg):
                    trap_ctx = last_ctx

        _is_whale_or_wf_brk_exempt = bool(trap_ctx.get('is_whale_pump_storm') or trap_ctx.get('is_waterfall_dump'))
        has_breakout_vote = 'momentum_breakout' in votes and (votes['momentum_breakout'][0] * score > 0)

        has_trend_support = 'trend_following' in votes and (votes['trend_following'][0] * score > 0)

        has_trend_or_trap_support = has_trend_support or ('trap_detector' in votes and (votes['trap_detector'][0] * score > 0))

        if has_breakout_vote and 0.0 < macro_adx < 22.0 and not has_trend_or_trap_support and not _is_whale_or_wf_brk_exempt:

            logger.warning(

                '🛡️ [WEAK-ADX BREAKOUT VETO] Hủy lệnh %s: MomentumBreakout phát tín hiệu khi ADX vĩ mô quá yếu (ADX=%.1f < 22.0) và thiếu xác nhận Trend/Trap!',

                symbol, macro_adx,

            )

            return None

        # Yêu cầu bắt buộc đủ số chiến thuật đồng thuận (tối thiểu >= min_agreeing_strategies, cấm 1 chiến thuật đơn lẻ tự vượt rào như FOGO/USDT)

        has_real_bull_trap_ctx = bool(trap_ctx.get('has_real_bull_trap'))

        has_real_bear_trap_ctx = bool(trap_ctx.get('has_real_bear_trap'))

        has_valid_trap_vol_ctx = bool(trap_ctx.get('has_valid_trap_vol', False))

        is_whale_pump_ctx = bool(trap_ctx.get('is_whale_pump_storm'))

        is_waterfall_ctx = bool(trap_ctx.get('is_waterfall_dump'))

        neutralized_bull_ctx = trap_ctx.get('neutralized_bull', [])

        neutralized_bear_ctx = trap_ctx.get('neutralized_bear', [])

        raw_trap_conf = max(

            (

                float(getattr(s, 'confidence', 0.0) or 0.0)

                for s in signals

                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')

                and getattr(s, 'signal', None) in (Signal.BUY, Signal.SELL)

            ),

            default=0.0,

        )

        

        # [BÀI HỌC 86 - SỬA LỖI NGHỊCH LÝ ĐỒNG THUẬN BẪY]:

        # Khi CẢ 3 CHIẾN THUẬT ĐỒNG THUẬN (agreeing >= 2), không có chiến thuật nào bị vô hiệu hóa (len == 0).

        # Bổ sung 'or agreeing >= 2' để setup đồng thuận tuyệt đối của Cá Mập không bị đánh rớt!

        # [BOM #126B FIX]: Khóa bẫy ma / mù chiều — CHỈ tính TrapDetector còn sống trong `votes` (cùng chiều score) + đạt vol hợp lệ,
        # và tách riêng dòng tiền cá mập khỏi is_confirmed_trap_reversal để KHÔNG đóng dấu giả has_real_bear_trap/has_real_bull_trap!
        _trap_vote_alive = ('trap_detector' in votes) and (votes['trap_detector'][0] * score > 0) and bool(has_valid_trap_vol_ctx)
        trap_sig_obj = next(
            (
                s for s in signals
                if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and ((s.signal == Signal.BUY and score > 0) or (s.signal == Signal.SELL and score < 0))
            ),
            None,
        ) if _trap_vote_alive else None
        trap_aligned_with_score = (trap_sig_obj is not None)
        _aligned_trap_conf = float(getattr(trap_sig_obj, 'confidence', 0.0) or 0.0) if trap_sig_obj is not None else 0.0
        is_confirmed_bull_trap_rev = (
            (has_real_bull_trap_ctx and (len(neutralized_bull_ctx) > 0 or agreeing >= 2) and score < 0)
            or (bool(trap_ctx.get('is_ai_exhaustion_sell')) and score < 0)
            or (_trap_vote_alive and _aligned_trap_conf >= 0.75 and trap_aligned_with_score and score <= -0.50 and (has_breakout_vote or has_trend_support or agreeing >= 2))
        )
        is_confirmed_bear_trap_rev = (
            (has_real_bear_trap_ctx and (len(neutralized_bear_ctx) > 0 or agreeing >= 2) and score > 0)
            or (_trap_vote_alive and _aligned_trap_conf >= 0.75 and trap_aligned_with_score and score >= 0.50 and (has_breakout_vote or has_trend_support or agreeing >= 2))
        )
        is_confirmed_trap_reversal = is_confirmed_bull_trap_rev or is_confirmed_bear_trap_rev
        # [BOM #125C FIX]: Tách riêng đồng thuận MomentumBreakout khỏi is_confirmed_trap_reversal
        # để Breakout 0% râu KHÔNG bao giờ bị đóng dấu giả has_real_bull_trap/has_real_bear_trap chọc thủng KB5 & MTF 4H!
        has_strong_breakout_consensus = bool(has_breakout_vote and agreeing >= 3 and effective_adx >= 25.0)



        # [BÀI HỌC 109 & V3.6 - ĐỒNG THUẬN 3 TRỤ CỘT & 2 TRỤ CỘT HỘI TỤ CAO (DUAL-PILLAR HIGH-CONVICTION & UNOPPOSED WHALE GATE)]:
        # 1. is_multi_pillar_triad: 3 Trụ cột (Tech + AI Ensemble + JEV Agent) đồng thuận |score| >= 0.72.
        # 2. is_dual_pillar_high_conviction: Khi KB10 Dual-Brain đã rút gọn phiếu phụ còn 2 Trụ cột (1 Tech + JEV >= 70% hoặc AI >= 75%)
        #    nhưng điểm hội tụ rất cao (|score| >= 0.78) và 0 phiếu chống (như XRP/USDT -0.8144, US/USDT -0.8233).
        # 3. is_unopposed_whale_flow_gate: Khi có sóng cá mập (Whale Pump Storm / Waterfall Dump) với >= 1 Tech đồng thuận (|score| >= 0.42)
        #    và KHÔNG bị JEV 4H (>= 70%) hay AI Ensemble (>= 70%) đối kháng ngược chiều, cho phép đi tiếp tới cổng Smart Inversion.
        jev_vote_agg = float(votes.get('jev_agent', (0.0, 0.0))[0])
        ai_vote_agg = float(votes.get('ai_ensemble', (0.0, 0.0))[0])
        has_jev_strong_opposing = any(
            getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')
            and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)
            and ((1.0 if s.signal == Signal.BUY else -1.0) * score < 0)
            and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
            for s in signals
        )
        # [TRIỆT TIÊU LỖI NGẦM - ZOMBIE AI RESURRECTED]:
        # Nếu AI Ensemble đã được _strategy_votes() chủ động hạ phiếu / loại bỏ (pop('ai_ensemble'))
        # do Phân lớp vĩ mô (has_macro_dual_brain), Xả đỉnh kiệt sức (has_alt_exhaustion_short_override)
        # hoặc Bẫy giá (neutralized_bull/bear), thì AI Ensemble KHÔNG CÒN nằm trong votes.
        # Tuyệt đối không quét lại signals thô để hồi sinh quyền phủ quyết của phiếu đã bị hạ xuống mức tư vấn!
        has_ai_strong_opposing = (
            'ai_ensemble' in votes
            and (ai_vote_agg * score < 0)
            and abs(ai_vote_agg) >= 0.70
        )
        is_multi_pillar_triad = (
            agreeing >= 3
            and agreeing_tech >= 1
            and abs(score) >= 0.72
            and not any(v * score < 0 and abs(v) >= 0.70 for _, (v, _) in votes.items())
        )
        is_dual_pillar_high_conviction = (
            agreeing >= 2
            and agreeing_tech >= 1
            and abs(score) >= 0.68
            and not any(v * score < 0 and abs(v) >= 0.60 for _, (v, _) in votes.items())
            and not has_jev_strong_opposing
            and not has_ai_strong_opposing
            and (
                (jev_vote_agg * score > 0 and abs(jev_vote_agg) >= 0.65)
                or (ai_vote_agg * score > 0 and abs(ai_vote_agg) >= 0.65)
            )
        )
        is_dual_brain_ai_consensus = (
            agreeing >= 2
            and (jev_vote_agg * score > 0 and abs(jev_vote_agg) >= 0.65)
            and (ai_vote_agg * score > 0 and abs(ai_vote_agg) >= 0.65)
            and abs(score) >= 0.68
            and not has_jev_strong_opposing
            and not has_ai_strong_opposing
            and not any(v * score < 0 and abs(v) >= 0.60 for _, (v, _) in votes.items())
        )
        is_unopposed_whale_flow_gate = (
            (is_whale_pump_ctx or is_waterfall_ctx)
            and (agreeing_tech >= 1 or (agreeing >= 2 and not has_jev_strong_opposing and not has_ai_strong_opposing))
            and abs(score) >= 0.42
            and not has_jev_strong_opposing
            and not has_ai_strong_opposing
            and not any(v * score < 0 and abs(v) >= 0.70 for _, (v, _) in votes.items())
        )

        # [SLOT B2 - CỤM ALPHA #2 (3C-KB10): PARABOLIC LONG INVERSION ENGINE]:
        # Đường đi: T1: trap_detector=SELL + T2: AI=SELL + T3: JEV 4H=BUY (>= 70%) trên CRYPTO_ALTCOIN
        # Bộ lọc DNA Nến 15M: RSI >= 65.0, 1.10x <= RVol <= 3.50x + Vượt qua 4 Tử huyệt Đầu vào (F1, F2, F3, F4)
        c2_rsi_pre = float((macro_analysis or {}).get('tactical_rsi') or (macro_analysis or {}).get('rsi') or 50.0)
        _raw_c2_rvol = (macro_analysis or {}).get('candle_vol_ratio')
        c2_rvol_pre = float(_raw_c2_rvol) if _raw_c2_rvol is not None else 1.0
        c2_uwick_pre = float((macro_analysis or {}).get('upper_wick_pct') or 0.0)
        c2_lwick_pre = float((macro_analysis or {}).get('lower_wick_pct') or 0.0)
        c2_pump_pre = float((macro_analysis or {}).get('recent_pump_pct') or 0.0)
        c2_dump_pre = float((macro_analysis or {}).get('recent_dump_pct') or 0.0)
        c2_adx_pre = float(effective_adx if effective_adx > 0 else macro_adx)

        has_trap_sell_c2 = ('trap_detector' in votes and votes['trap_detector'][0] < 0)
        has_mr_sell_c2 = ('mean_reversion' in votes and votes['mean_reversion'][0] < 0)
        has_any_buy_tech_c2 = any(
            k not in ('jev_agent', 'ai_ensemble') and v[0] > 0
            for k, v in votes.items()
        )
        c2_f1_dead_adx_no_support = (0.0 < c2_adx_pre < 18.0 and c2_lwick_pre < 0.40 and c2_dump_pre < 0.040)
        c2_f2_double_sell_dist = (has_mr_sell_c2 and (not has_any_buy_tech_c2) and c2_uwick_pre >= 0.50 and c2_rvol_pre <= 2.20)
        c2_f3_weak_pump_reject = (c2_pump_pre < 0.015 and c2_uwick_pre >= 0.60 and c2_lwick_pre < 0.18)
        c2_f4_unretraced_top = (c2_pump_pre >= 0.095 and (c2_dump_pre < 0.035 or c2_lwick_pre < 0.05))
        is_c2_clean_dna = not (
            c2_f1_dead_adx_no_support
            or c2_f2_double_sell_dist
            or c2_f3_weak_pump_reject
            or c2_f4_unretraced_top
        )
        try:
            from core.quant_evolution_engine import is_weapon_enabled_for_live as _is_vk_en
        except Exception:
            def _is_vk_en(_wid: str) -> bool:
                return True
        _orig_jev_pre = float(trap_ctx.get('orig_jev_vote', jev_vote_agg) or 0.0)
        _orig_ai_pre = float(trap_ctx.get('orig_ai_vote', (_raw_orig_ai_vote if _raw_ai_votes else ai_vote_agg)) or 0.0)

        is_c2_parabolic_long_inversion = (
            _is_vk_en("VK2_LONG_LAT_NGUOC_SONG_PARABOL")
            and is_crypto_altcoin
            and score < 0
            and consensus_count < self.min_agreeing_strategies
            and has_trap_sell_c2
            and _orig_ai_pre < 0
            and _orig_jev_pre >= 0.70
            and c2_rsi_pre >= 65.0
            and (1.10 <= c2_rvol_pre <= 3.50)
            and is_c2_clean_dna
        )
        c2_slot_b2_unlocked = False

        # [SLOT B1 - VK9 (THỬ NGHIỆM): BÁN ĐỈNH RÂU CỰC ĐẠI — GIAO ĐIỂM LAB-1 ∩ ALPHA_4]:
        # Lớp tài sản: ALTCOIN · trap_detector:SELL + trend_following:BUY + AI:SELL + JEV 4H:BUY
        # DNA tinh khiết: U_Wick >= 65%, L_Wick < 25%, RSI < 65, RVol >= 1.33x, ADX >= 20 (85.7% Strict TP / 0% SL)
        # Lưu ý: Bull Trap dilution có thể đã pop('trend_following') khỏi votes vào neutralized_bull_ctx -> kiểm tra cả votes, neutralized_bull_ctx và raw signals!
        has_trend_buy_vk9 = (
            ('trend_following' in votes and votes['trend_following'][0] > 0)
            or ('TrendFollowing' in neutralized_bull_ctx)
            or any(
                getattr(s, 'strategy', '').lower() == 'trend_following'
                and getattr(s, 'signal', None) == Signal.BUY
                for s in signals
            )
        )
        is_vk9_climax_wick_short = (
            _is_vk_en("VK9_SHORT_BAN_DINH_RAU_CUC_DAI")
            and is_crypto_altcoin
            and has_trap_sell_c2
            and has_trend_buy_vk9
            and _orig_ai_pre < 0
            and _orig_jev_pre >= 0.70
            and c2_uwick_pre >= 0.65
            and c2_lwick_pre < 0.25
            and c2_rsi_pre < 65.0
            and c2_rvol_pre >= 1.33
            and (macro_adx if macro_adx > 0 else c2_adx_pre) >= 20.0
        )

        # [SLOT B1 - VK10 (THỬ NGHIỆM): MUA ĐÁY RÚT CHÂN TRADFI — CHUẨN S13 LOẠI TIMEOUT_60M]:
        # Lớp tài sản: TRADFI (Cổ phiếu / Hàng hóa / ETF) · trap_detector:BUY + AI:BUY + JEV 4H:SELL
        # DNA S13: ATR_15M >= 0.38%, ADX <= 30, regime != strong_downtrend, L_Wick >= 38%, RSI >= 33, RVol >= 0.85x (85.7% Strict TP / 0% SL)
        has_trap_buy_vk10 = (
            ('trap_detector' in votes and votes['trap_detector'][0] > 0)
            or any(
                getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                and getattr(s, 'signal', None) == Signal.BUY
                for s in signals
            )
        )
        # [BOM #131B FIX]: market_analysis['tactical_atr_pct']/'atr_pct' luôn ở đơn vị % -> không nhân 100 khi < 0.08!
        c10_atr_pct_pre = float((macro_analysis or {}).get('tactical_atr_pct') or (macro_analysis or {}).get('atr_pct') or 0.0)
        c10_regime_pre = str((macro_analysis or {}).get('regime') or '').lower()
        is_vk10_tradfi_bottom_long = (
            _is_vk_en("VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI")
            and is_tradfi
            and (not MarketScanner.is_bear_inverse_etf(symbol))
            and has_trap_buy_vk10
            and _orig_ai_pre > 0
            and _orig_jev_pre <= -0.50
            and c10_atr_pct_pre >= 0.38
            and (0.0 < (macro_adx if macro_adx > 0 else c2_adx_pre) <= 30.0)
            and ('strong_downtrend' not in c10_regime_pre)
            and c2_lwick_pre >= 0.38
            and c2_rsi_pre >= 33.0
            and c2_rvol_pre >= 0.85
        )
        vk9_slot_b1_unlocked = False
        vk10_slot_b1_unlocked = False
        dyn_vk_matched = None
        dyn_vk_unlocked = False
        is_extreme_ai_conflict_ctx = bool((trap_ctx or {}).get('is_extreme_ai_conflict', False))
        try:
            from core.quant_evolution_engine import evaluate_active_dynamic_weapons
            _dyn_ac_str = 'TRADFI' if is_tradfi else ('MAJOR' if is_tier1 else 'ALTCOIN')
            _ai_sig_dyn_s = next((s for s in (signals or []) if str(getattr(s, 'strategy', '')).lower() in ('ai_ensemble', 'aiensemble')), None)
            _is_cs_weak_dyn = bool(
                _ai_sig_dyn_s is not None
                and isinstance(getattr(_ai_sig_dyn_s, 'metadata', None), dict)
                and _ai_sig_dyn_s.metadata.get('status') == 'cold_start_warmup'
                and float(_ai_sig_dyn_s.metadata.get('mean_cv_accuracy') or 0.0) < 0.58
            )
            # [BOM #122C + #131B FIX]: Đồng bộ 100% ngưỡng 0.58 với core/bot.py:1461 (SLOT_A) & JEV HOLD probe!
            if _ai_sig_dyn_s is None or _is_cs_weak_dyn:
                _dyn_ai_v = 'NONE'
            elif _orig_ai_pre >= 0.58:
                _dyn_ai_v = 'BUY'
            elif _orig_ai_pre <= -0.58:
                _dyn_ai_v = 'SELL'
            else:
                _dyn_ai_v = 'HOLD'
            _jev_sigs_pre = [s for s in (signals or []) if str(getattr(s, 'strategy', '')).lower() == 'jev_agent']
            _has_jev_sig_pre = bool(_jev_sigs_pre)
            _jev_guard_dg_pre = any(bool((getattr(s, 'metadata', None) or {}).get('guard_downgraded')) for s in _jev_sigs_pre)
            _dyn_jev_v = (
                'GUARD_BLOCKED' if _jev_guard_dg_pre else (
                    'BUY' if _orig_jev_pre > 0 else ('SELL' if _orig_jev_pre < 0 else ('HOLD' if _has_jev_sig_pre else 'SKIP'))
                )
            )
            _pre_gate_meta = next(
                (str(s.metadata.get('dyn_pre_veto_gate')) for s in (signals or []) if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('dyn_pre_veto_gate')),
                ""
            )
            # [V6.3 BOM #95D + BOM #131B FIX]: Tính _blocked_dir_dyn từ RAW technical signals đã dedup (không bị hỏng khi votes bị pop),
            # và LUÔN gắn T3_EXTREME_AI_CONFLICT khi is_extreme_ai_conflict_ctx=True (kể cả khi consensus_count >= 2)!
            _raw_tech_best_dyn = {}
            for _sr_d in (signals or []):
                _sn_d = str(getattr(_sr_d, 'strategy', '')).lower()
                if _sn_d in ('ai_ensemble', 'aiensemble', 'jev_agent', 'jevagent', 'market_analysis'):
                    continue
                _sv_d = str(getattr(getattr(_sr_d, 'signal', None), 'value', '') or '').upper()
                _sc_d = float(getattr(_sr_d, 'confidence', 0.0) or 0.0)
                _dm_d = 'LONG' if 'BUY' in _sv_d else ('SHORT' if 'SELL' in _sv_d else '')
                if _dm_d and _sc_d >= float(_raw_tech_best_dyn.get(_sn_d, ('', -1.0))[1]):
                    _raw_tech_best_dyn[_sn_d] = (_dm_d, _sc_d)
            _tech_buys_pre = sum(1 for v in _raw_tech_best_dyn.values() if v[0] == 'LONG')
            _tech_sells_pre = sum(1 for v in _raw_tech_best_dyn.values() if v[0] == 'SHORT')
            _blocked_dir_dyn = (
                'LONG' if _tech_buys_pre > _tech_sells_pre else (
                    'SHORT' if _tech_sells_pre > _tech_buys_pre else (
                        'LONG' if score > 0 else ('SHORT' if score < 0 else '')
                    )
                )
            )
            _dyn_veto_gate = _pre_gate_meta
            if (not _dyn_veto_gate) and is_extreme_ai_conflict_ctx:
                _dyn_veto_gate = "T3_EXTREME_AI_CONFLICT"
            elif not _dyn_veto_gate and consensus_count < self.min_agreeing_strategies:
                _jev_opposes_tech = (
                    (_orig_jev_pre >= 0.65 and _blocked_dir_dyn == 'SHORT')
                    or (_orig_jev_pre <= -0.65 and _blocked_dir_dyn == 'LONG')
                )
                if _jev_opposes_tech:
                    _dyn_veto_gate = "T3_JEV_SHIELD_NEED_2_STRATS"
                elif c2_uwick_pre >= 0.28 and c2_lwick_pre >= 0.28:
                    _dyn_veto_gate = "T2_FAST_SKIP_TWIN_WICK"
                else:
                    _dyn_veto_gate = "T3_AGGREGATOR_VETO"
            _by_strat_dyn = {f"{str(getattr(s, 'strategy', '')).lower()}@{idx_s}": s for idx_s, s in enumerate(signals or [])}
            _pref_dyn_wid = ''
            if dyn_slot_a_exempt_sig is not None and isinstance(getattr(dyn_slot_a_exempt_sig, 'metadata', None), dict):
                _pref_dyn_wid = str(dyn_slot_a_exempt_sig.metadata.get('dyn_slot_a_exempt') or '')
            # [BOM #118C FIX]: Luon danh gia evaluate_active_dynamic_weapons (VK13 TRAP_SELL+AI_BUY+JEV_SELL duoc kiem soat boi _dyn_veto_gate=T3_EXTREME_AI_CONFLICT & ai_votes=['BUY'])!
            dyn_vk_matched = evaluate_active_dynamic_weapons(
                symbol=symbol,
                asset_class=_dyn_ac_str,
                by_strategy=_by_strat_dyn,
                ai_vote=_dyn_ai_v,
                jev_vote=_dyn_jev_v,
                candle_dna={
                    'atr_pct': c10_atr_pct_pre,
                    'adx': float(macro_adx if macro_adx > 0 else c2_adx_pre),
                    'rsi': c2_rsi_pre,
                    'rvol': c2_rvol_pre,
                    'u_wick_pct': c2_uwick_pre * 100.0,
                    'l_wick_pct': c2_lwick_pre * 100.0,
                    'pump_pct': float((macro_analysis or {}).get('recent_pump_pct') or 0.0) * 100.0,
                    'dump_pct': float((macro_analysis or {}).get('recent_dump_pct') or 0.0) * 100.0,
                    'regime': c10_regime_pre,
                },
                veto_gate=_dyn_veto_gate,
                blocked_direction=_blocked_dir_dyn,
                preferred_weapon_id=_pref_dyn_wid,
            )
        except Exception:
            dyn_vk_matched = None

        _dyn_bp_pre = (dyn_vk_matched.get('blueprint') or {}) if dyn_vk_matched else {}
        _dyn_side_pre = str((dyn_vk_matched or {}).get('_resolved_side') or (dyn_vk_matched or {}).get('side') or '').upper()
        _dyn_opposes_score = (dyn_vk_matched is not None) and (
            (_dyn_side_pre == 'LONG' and score < 0) or (_dyn_side_pre == 'SHORT' and score > 0)
        )
        _is_dyn_priority_inversion = (dyn_vk_matched is not None) and _dyn_opposes_score and (
            str(_dyn_bp_pre.get('slot') or '') == 'SLOT_B2'
            or bool(_dyn_bp_pre.get('veto_gate_match'))
            or bool(dyn_slot_a_exempt_sig)
        )

        _is_dyn_explicit_b2 = (
            _is_dyn_priority_inversion
            and (bool(_dyn_bp_pre.get('pathway_families')) or str(_dyn_bp_pre.get('pathway_family') or '') not in ('', 'ANY', 'BOTH_2WAY'))
            and (bool(_dyn_bp_pre.get('ai_votes')) or bool(_dyn_bp_pre.get('jev_votes')))
        )

        if consensus_count < self.min_agreeing_strategies:

            if dyn_vk_matched is not None and dyn_slot_a_exempt_sig:

                dyn_vk_unlocked = True
                _dyn_side = str(dyn_vk_matched.get('_resolved_side') or dyn_vk_matched.get('side') or 'LONG').upper()
                _aligned_ai_abs = abs(ai_vote_agg) if ((_dyn_side == 'LONG' and ai_vote_agg > 0) or (_dyn_side == 'SHORT' and ai_vote_agg < 0)) else 0.0
                score = max(0.82, _aligned_ai_abs) if _dyn_side == 'LONG' else -max(0.82, _aligned_ai_abs)
                logger.info(
                    '🧪 [VŨ KHÍ ĐỘNG SLOT_A - %s] %s: Mở khóa %s (%s)!',
                    dyn_vk_matched.get('code'), symbol, dyn_vk_matched.get('short_name'),
                    _dyn_bp_pre.get('m1_profile_vi', ''),
                )

            elif is_multi_pillar_triad:

                logger.info(

                    '⚡ [MULTI-PILLAR TRIAD CONSENSUS] Cho phép lệnh %s thông qua: Đồng thuận 3 trụ cột thực chất (Tech=%d + AI Ensemble + JEV Agent, score=%+.4f, total=%d)!',

                    symbol, agreeing_tech, score, agreeing,

                )

            elif _is_dyn_explicit_b2 and agreeing_tech < 2:

                dyn_vk_unlocked = True
                _dyn_side = str(dyn_vk_matched.get('_resolved_side') or dyn_vk_matched.get('side') or 'LONG').upper()
                _aligned_ai_abs = abs(ai_vote_agg) if ((_dyn_side == 'LONG' and ai_vote_agg > 0) or (_dyn_side == 'SHORT' and ai_vote_agg < 0)) else 0.0
                score = max(0.82, _aligned_ai_abs) if _dyn_side == 'LONG' else -max(0.82, _aligned_ai_abs)
                logger.info(
                    '🧪 [VŨ KHÍ ĐỘNG ƯU TIÊN LẬT NGƯỢC SLOT_B2 - %s] %s: Mở khóa %s (%s)!',
                    dyn_vk_matched.get('code'), symbol, dyn_vk_matched.get('short_name'),
                    _dyn_bp_pre.get('m1_profile_vi', ''),
                )

            elif is_dual_pillar_high_conviction:

                logger.info(

                    '⚡ [DUAL-PILLAR HIGH-CONVICTION V3.6] Cho phép lệnh %s thông qua: Đồng thuận 2 trụ cột hội tụ cao không đối kháng (Tech=%d, JEV=%+.2f, AI=%+.2f, score=%+.4f, total=%d)!',

                    symbol, agreeing_tech, jev_vote_agg, ai_vote_agg, score, agreeing,

                )

            elif is_unopposed_whale_flow_gate:

                logger.info(

                    '🌊 [UNOPPOSED WHALE FLOW GATE V3.6] Cho phép ứng viên dòng tiền cá mập %s thông qua tới cổng Smart Inversion (Tech=%d, score=%+.4f, WhalePump=%s, Waterfall=%s)!',

                    symbol, agreeing_tech, score, is_whale_pump_ctx, is_waterfall_ctx,

                )

            elif dyn_vk_matched is not None and _is_dyn_priority_inversion:

                dyn_vk_unlocked = True
                _dyn_side = str(dyn_vk_matched.get('_resolved_side') or dyn_vk_matched.get('side') or 'LONG').upper()
                _aligned_ai_abs = abs(ai_vote_agg) if ((_dyn_side == 'LONG' and ai_vote_agg > 0) or (_dyn_side == 'SHORT' and ai_vote_agg < 0)) else 0.0
                score = max(0.82, _aligned_ai_abs) if _dyn_side == 'LONG' else -max(0.82, _aligned_ai_abs)
                logger.info(
                    '🧪 [VŨ KHÍ ĐỘNG ƯU TIÊN LẬT NGƯỢC - %s] %s: Mở khóa %s (%s)!',
                    dyn_vk_matched.get('code'), symbol, dyn_vk_matched.get('short_name'),
                    _dyn_bp_pre.get('m1_profile_vi', ''),
                )

            elif is_dual_brain_ai_consensus:

                logger.info(

                    '🧠 [DUAL-BRAIN AI CONSENSUS] Cho phép lệnh %s thông qua: Đồng thuận Song Não AI cao cấp (AI ML=%+.2f + JEV LLM=%+.2f, score=%+.4f, total=%d)!',

                    symbol, ai_vote_agg, jev_vote_agg, score, agreeing,

                )

            elif (
                is_confirmed_trap_reversal
                and agreeing >= 2
                and (agreeing_tech >= 1 or is_dual_brain_ai_consensus)
                and (agreeing >= 3 or (not has_jev_strong_opposing and not has_ai_strong_opposing))
            ):

                logger.info(

                    '⚡ [TRAP SETUP MULTI-CONSENSUS] Cho phép lệnh %s thông qua: Bẫy cá mập được xác nhận đa tầng (Đồng thuận: %s, tech=%d, total=%d)!',

                    symbol,
                    ', '.join(neutralized_bull_ctx if score < 0 else neutralized_bear_ctx)
                    if (neutralized_bull_ctx or neutralized_bear_ctx)
                    else ', '.join(k for k, (v, _) in votes.items() if v * score > 0),

                    agreeing_tech, agreeing,

                )

            elif is_c2_parabolic_long_inversion:

                c2_slot_b2_unlocked = True
                score = max(0.82, abs(jev_vote_agg))
                logger.info(
                    '🚀 [SLOT B2 - VK2 THỬ NGHIỆM (3C-KB10)] %s: Mở khóa & Lật ngược Trap+AI SELL -> PARABOLIC LONG theo JEV 4H '
                    '(JEV=%+.2f, RSI=%.1f, RVol=%.2fx, ADX=%.1f, Pump=%.2f%%, 4-Gate F1..F4 Clean)!',
                    symbol, jev_vote_agg, c2_rsi_pre, c2_rvol_pre, c2_adx_pre, c2_pump_pre * 100,
                )

            elif is_vk9_climax_wick_short:

                vk9_slot_b1_unlocked = True
                score = -max(0.82, abs(ai_vote_agg))
                logger.info(
                    '🧪 [SLOT B1 - VK9 THỬ NGHIỆM (L1∩A4)] %s: Mở khóa Bán Đỉnh Râu Cực Đại ALTCOIN '
                    '(U_Wick=%.1f%% >= 65%%, RSI=%.1f < 65, RVol=%.2fx >= 1.33x, ADX=%.1f >= 20, AI=%+.2f, JEV=%+.2f)!',
                    symbol, c2_uwick_pre * 100, c2_rsi_pre, c2_rvol_pre, c2_adx_pre, ai_vote_agg, jev_vote_agg,
                )

            elif is_vk10_tradfi_bottom_long:

                vk10_slot_b1_unlocked = True
                score = max(0.82, abs(ai_vote_agg))
                logger.info(
                    '🧪 [SLOT B1 - VK10 THỬ NGHIỆM (TRADFI S13)] %s: Mở khóa Mua Đáy Rút Chân TRADFI '
                    '(ATR=%.2f%% >= 0.38%%, ADX=%.1f <= 30, L_Wick=%.1f%% >= 38%%, RSI=%.1f >= 33, RVol=%.2fx, AI=%+.2f)!',
                    symbol, c10_atr_pct_pre, c2_adx_pre, c2_lwick_pre * 100, c2_rsi_pre, c2_rvol_pre, ai_vote_agg,
                )

            elif dyn_vk_matched is not None:

                dyn_vk_unlocked = True
                _dyn_side = str(dyn_vk_matched.get('_resolved_side') or dyn_vk_matched.get('side') or 'LONG').upper()
                _aligned_ai_abs = abs(ai_vote_agg) if ((_dyn_side == 'LONG' and ai_vote_agg > 0) or (_dyn_side == 'SHORT' and ai_vote_agg < 0)) else 0.0
                score = max(0.82, _aligned_ai_abs) if _dyn_side == 'LONG' else -max(0.82, _aligned_ai_abs)
                logger.info(
                    '🧪 [VŨ KHÍ ĐỘNG V6.1 - %s] %s: Mở khóa %s (%s)!',
                    dyn_vk_matched.get('code'), symbol, dyn_vk_matched.get('short_name'),
                    (dyn_vk_matched.get('blueprint') or {}).get('m1_profile_vi', ''),
                )

            else:

                logger.info(

                    '⏳ [TẦNG 3 - CHƯA ĐỦ ĐỒNG THUẬN] %s: Cần tối thiểu %d chiến thuật cùng phe, hiện tại có %d (Kỹ thuật=%d, Tổng=%d) -> ĐỨNG NGOÀI (Veto = 0$)',

                    symbol, self.min_agreeing_strategies, consensus_count, agreeing_tech, agreeing,

                )
                self._record_veto(
                    symbol,
                    gate=(_dyn_veto_gate or 'T3_NEED_2_STRATS_GOT_1'),
                    direction=(_blocked_dir_dyn or ('LONG' if score > 0 else 'SHORT')),
                    reason='Chưa đủ đồng thuận tại Tầng 3',
                )

                return None

        # [BOM #95D + BOM #103D FIX]: Chi cho phep VK9/VK10/COMBO khop o nhanh thu 2 khi KHONG cuop lenh nguoc chieu da duoc duyet o L2962!
        if not c2_slot_b2_unlocked:
            if is_vk9_climax_wick_short and not vk9_slot_b1_unlocked and score <= 0:
                vk9_slot_b1_unlocked = True
                score = -max(0.82, abs(score), abs(ai_vote_agg) if ai_vote_agg < 0 else 0.0)
                logger.info(
                    '🧪 [SLOT B1 - VK9 THỬ NGHIỆM (L1∩A4)] %s: Xác nhận Bán Đỉnh Râu Cực Đại ALTCOIN '
                    '(U_Wick=%.1f%% >= 65%%, RSI=%.1f < 65, RVol=%.2fx, ADX=%.1f)!',
                    symbol, c2_uwick_pre * 100, c2_rsi_pre, c2_rvol_pre, c2_adx_pre,
                )
            elif is_vk10_tradfi_bottom_long and not vk10_slot_b1_unlocked and score >= 0:
                vk10_slot_b1_unlocked = True
                score = max(0.82, abs(score), abs(ai_vote_agg) if ai_vote_agg > 0 else 0.0)
                logger.info(
                    '🧪 [SLOT B1 - VK10 THỬ NGHIỆM (TRADFI S13)] %s: Xác nhận Mua Đáy Rút Chân TRADFI '
                    '(ATR=%.2f%%, ADX=%.1f, L_Wick=%.1f%%, RSI=%.1f, RVol=%.2fx)!',
                    symbol, c10_atr_pct_pre, c2_adx_pre, c2_lwick_pre * 100, c2_rsi_pre, c2_rvol_pre,
                )
            elif dyn_vk_matched is not None and not dyn_vk_unlocked:
                # [BOM #87, #94, #95D & #103D FIX]:
                # - Vu Khi Dong GATE_INV (veto_gate_match != '') chi chay qua dyn_slot_a_exempt_sig hoac nhanh < min_agreeing.
                # - Vu Khi COMBO DNA cu the KHONG duoc cuop/lat nguoc lenh da duoc duyet nguoc chieu!
                _dyn_bp2 = dyn_vk_matched.get('blueprint') or {}
                _dyn_side2 = str(dyn_vk_matched.get('_resolved_side') or dyn_vk_matched.get('side') or 'LONG').upper()
                _is_gate_inv_2 = bool(_dyn_bp2.get('veto_gate_match'))
                _has_explicit_dna_2 = bool(_dyn_bp2.get('pathway_families')) or str(_dyn_bp2.get('pathway_family') or '') not in ('', 'ANY', 'BOTH_2WAY')
                _vk_cons_floor = min(self.min_signal_score, 0.68)
                _has_strong_vk_consensus = (
                    is_multi_pillar_triad
                    or is_dual_pillar_high_conviction
                    or is_dual_brain_ai_consensus
                    or (agreeing_tech >= 2 and abs(score) >= _vk_cons_floor)
                    or (abs(score) >= _vk_cons_floor and ((_dyn_side2 == 'LONG' and score < 0) or (_dyn_side2 == 'SHORT' and score > 0)))
                )
                # [BOM #122C + #125C FIX]:
                # - SLOT_A đã miễn Fast-Skip (dyn_slot_a_exempt_sig) BẮT BUỘC mở khóa đúng Vũ Khí Động đã khớp (như VK12 lật ngược MEANREV_BUY+AI_BUY)
                #   thay vì bị _has_strong_vk_consensus chặn rồi tự hủy ở SLOT A DYN-GUARD!
                # - SLOT_B2 thường vẫn tôn trọng (not _has_strong_vk_consensus) để không cướp lệnh đồng thuận mạnh!
                if dyn_slot_a_exempt_sig or ((not _has_strong_vk_consensus) and (_is_dyn_priority_inversion or ((not _is_gate_inv_2) and _has_explicit_dna_2))):
                    dyn_vk_unlocked = True
                    _aligned_ai_abs2 = abs(ai_vote_agg) if ((_dyn_side2 == 'LONG' and ai_vote_agg > 0) or (_dyn_side2 == 'SHORT' and ai_vote_agg < 0)) else 0.0
                    score = max(0.82, _aligned_ai_abs2) if _dyn_side2 == 'LONG' else -max(0.82, _aligned_ai_abs2)
                    logger.info(
                        '🧪 [VŨ KHÍ ĐỘNG V6.1 - %s] %s: Xác nhận %s (%s)!',
                        dyn_vk_matched.get('code'), symbol, dyn_vk_matched.get('short_name'),
                        _dyn_bp2.get('m1_profile_vi', ''),
                    )

        # [V6.1 BOM #39 AN TOAN]: Neu vao day nho dyn_slot_a_exempt (khong co JEV 4H) ma khong khop Vu Khi Dong -> CHAN NGAY!
        if dyn_slot_a_exempt_sig and not dyn_vk_unlocked:
            logger.info('🛡️ [SLOT A DYN-GUARD] %s không còn khớp Vũ Khí Động tại Tầng 3 -> Hủy an toàn.', symbol)
            return None

        # [BOM #126B FIX]: Thực thi lại JEV HOLD VETO nếu đã hoãn cho Vũ Khí Động nhưng cuối cùng KHÔNG khớp Vũ Khí Động!
        if locals().get('_jev_hold_veto_deferred_msg') and not dyn_vk_unlocked:
            logger.warning(
                "🛡️ [JEV HOLD VETO - DEFERRED] Hủy mở lệnh %s: %s (không khớp Vũ Khí Động -> cấm vũ khí thường lọt lưới)!",
                symbol, _jev_hold_veto_deferred_msg,
            )
            self._record_veto(symbol, 'JEV_HOLD_VETO', 'LONG' if score > 0 else 'SHORT', _jev_hold_veto_deferred_msg)
            return None

        if _cold_start_veto_msg:
            _cs_dyn_ais = {str(a).upper() for a in (((dyn_vk_matched or {}).get('blueprint') or {}).get('ai_votes') or []) if a} if dyn_vk_unlocked else set()
            if not (dyn_vk_unlocked and 'NONE' in _cs_dyn_ais):
                logger.warning('⏳ [COLD-START VETO] Hủy mở lệnh %s: %s', symbol, _cold_start_veto_msg)
                return None



        # PHƯƠNG ÁN A+: PHỦ QUYẾT CHIẾN LƯỢC ĐỐI KHÁNG KHI ĐỒNG THUẬN YẾU (<= 2)

        # Nếu chỉ có 2 chiến thuật đồng thuận (mức sàn tối thiểu) mà có bất kỳ chiến thuật nào

        # (như TrapDetector, AI Ensemble, hoặc Momentum) đối kháng ngược chiều (confidence >= 0.60):

        # Lập tức VETO để triệt tiêu các lệnh đu đỉnh râu nến (như ZEREBRO, SOL, ETH, DUSK)!

        exempt_ai_opposing = False

        if consensus_count <= self.min_agreeing_strategies and not (is_multi_pillar_triad or is_dual_pillar_high_conviction or is_dual_brain_ai_consensus or c2_slot_b2_unlocked or vk9_slot_b1_unlocked or vk10_slot_b1_unlocked or dyn_vk_unlocked):

            opposing_strats = [

                f"{s_name} ({v:+.2f})" for s_name, (v, _) in votes.items()

                if v * score < 0 and abs(v) >= 0.60

            ]

            if opposing_strats:

                # Kịch Bản 2: Miễn trừ nếu duy nhất AI Ensemble trễ pha 4H đối kháng vừa phải (<70%) trong khi nến 15M có Trap/Reversal mạnh (>= 75%) và ADX >= 25.0

                only_ai_opposing = all('ai_ensemble' in s for s in opposing_strats)

                # Tuyệt đối KHÔNG miễn trừ khi AI Ensemble đối kháng cực độ (>= 70%) trên Altcoins để né đu đỉnh
                ai_opposing_extreme = any(

                    getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')

                    and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)

                    and ((1.0 if s.signal == Signal.BUY else -1.0) * score < 0)

                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70

                    for s in signals

                )

                # Chỉ tính các chiến thuật kỹ thuật độc lập (non-AI) đồng pha cùng chiều với score (không tính HOLD hay ngược chiều)

                agreeing_non_ai_signals = [

                    s for s in signals

                    if getattr(s, 'strategy', '').lower() not in ('jev_agent', 'jevagent', 'ai_ensemble', 'aiensemble')

                    and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)

                    and ((1.0 if s.signal == Signal.BUY else -1.0) * score > 0)

                ]

                has_strong_reversal = (

                    any(

                        getattr(s, 'strategy', '').lower() in ('trap_detector', 'mean_reversion')

                        and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70

                        for s in agreeing_non_ai_signals

                    )

                    or max((float(getattr(s, 'confidence', 0.0) or 0.0) for s in agreeing_non_ai_signals), default=0.0) >= 0.75

                )

                # [TRIỂN KHAI KB 10 CHÍNH THỨC - PHÂN TẦNG LỚP TÀI SẢN & MIỄN TRỪ OPPOSING VETO CHO MAJOR / TRADFI]
                is_major = is_tier1
                is_exempt_asset_class = (is_major or is_tradfi)

                has_macro_trend_support = (
                    any(float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70 for s in agreeing_non_ai_signals)
                    or any(
                        getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')
                        and getattr(s, 'signal', Signal.HOLD) in (Signal.BUY, Signal.SELL)
                        and ((1.0 if s.signal == Signal.BUY else -1.0) * score > 0)
                        and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.70
                        for s in signals
                    )
                )

                if only_ai_opposing and is_exempt_asset_class and has_macro_trend_support:
                    # 1. MAJOR CRYPTO & TRADFI: Bãi bỏ điều kiện ai_opposing_extreme, miễn trừ Veto để đi cùng
                    #    xu hướng vĩ mô JEV LLM 4H & TrendFollowing, sau đó vào M1 Sniper Limit Maker đón retest!
                    exempt_ai_opposing = True
                    logger.info(
                        "⚡ [KB 10 DUAL-BRAIN EXEMPTION] %s (%s): Ưu tiên tuyệt đối xu hướng vĩ mô JEV LLM 4H & TrendFollowing (>=70%%), bãi bỏ Veto vi mô của AI Ensemble!",
                        symbol, "Major Crypto" if is_major else "TradFi",
                    )
                elif only_ai_opposing and not ai_opposing_extreme and has_strong_reversal and (macro_adx <= 0.0 or macro_adx >= 25.0):
                    # 2. ALTCOINS: BẮT BUỘC GIỮ NGUYÊN 100% VETO của Não Tĩnh khi ai_opposing_extreme (>=70%)
                    #    để chặn đứng 628 cú xả đỉnh rác như đã chứng minh ở KB 2!
                    exempt_ai_opposing = True
                    logger.info(
                        "⚡ [MIỄN TRỪ OPPOSING VETO ALTCOIN] %s: Kỹ thuật 15M đảo chiều mạnh (>=75%%, ADX=%.1f >= 25.0), bỏ qua phiếu đối kháng 4H của AI Ensemble!",
                        symbol, macro_adx,
                    )
                else:
                    logger.info(
                        '🚫 [OPPOSING STRATEGY VETO] Hủy mở lệnh %s: Đồng thuận yếu (%d/%d chiến thuật kỹ thuật/tổng) trong khi có chiến thuật đối kháng mạnh: %s!',
                        symbol, consensus_count, agreeing, ", ".join(opposing_strats),
                    )
                    return None



        # Yêu cầu bắt buộc ít nhất 1 chiến thuật kỹ thuật độc lập (Trend, Breakout, MR, Trap) đồng thuận,
        # NGOẠI TRỪ khi đạt chuẩn Song Não AI cấp cao (Dual-Brain AI Consensus) hoặc Dòng Tiền Cá Mập (Unopposed Whale Flow / Smart Inversion)
        non_ai_agreeing = sum(
            1 for s_name, (v, _) in votes.items()
            if s_name not in ('jev_agent', 'ai_ensemble') and v * score > 0
        )
        if non_ai_agreeing < 1 and not (is_dual_brain_ai_consensus or is_unopposed_whale_flow_gate or c2_slot_b2_unlocked or vk9_slot_b1_unlocked or vk10_slot_b1_unlocked or dyn_vk_unlocked):
            logger.info(
                'No trade for %s: cần ít nhất 1 chiến thuật kỹ thuật độc lập (non-AI) đồng thuận, hiện có %d',
                symbol, non_ai_agreeing,
            )
            return None



        # SÀN ĐỒNG THUẬN VI MÔ (ADAPTIVE MICRO CONSENSUS):

        # Đối với Altcoin và Cổ phiếu (ngoài BTC/ETH):

        # Nếu AI Ensemble có độ tự tin thấp/vừa phải (< 60%),

        # thì BẮT BUỘC phải có xu hướng thực chất (ADX >= 30.0, không biến động hỗn loạn ATR < 5.0%) kèm đồng thuận mạnh:

        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 2 chiến thuật kỹ thuật (như CYS ADX=52.8)

        # - Hoặc có >= 3 chiến thuật đồng thuận VÀ >= 1 kỹ thuật + JEV Agent khẳng định mạnh (Conf >= 80%, như INIT ADX=31.6, AVAX ADX=32.2)!

        # Quy tắc này triệt tiêu 100% lệnh thua yếu lực (TAO ADX=26.0, AERO ADX=20.1, WLD ADX=26.4, ON ATR=5.58%)

        # trong khi bảo toàn trọn vẹn 100% các lệnh thắng đa đồng thuận (CYS, INIT, AVAX)!

        # [BOM #122C]: Xoa gan lai is_tier1 du thua (da tinh tai L2378)
        ai_sig = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')), None)

        jev_sig_pre = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)

        jev_conf_pre = 0.0

        if jev_sig_pre:

            try:

                jev_conf_pre = float(jev_sig_pre.confidence)

            except (TypeError, ValueError):

                jev_conf_pre = 0.0



        # Nhận diện đảo chiều Trap mạnh để miễn trừ Dead ADX và hỗ trợ Micro Consensus

        # [BÀI HỌC 86 + BOM #126B FIX]: Chuẩn hóa ngưỡng Trap đảo chiều 0.68 — BẮT BUỘC còn sống trong `votes`, đạt vol hợp lệ và ĐÚNG CHIỀU `score`!
        has_strong_trap_reversal = (
            bool(is_confirmed_trap_reversal)
            or bool(has_real_bull_trap_ctx and score < 0)
            or bool(has_real_bear_trap_ctx and score > 0)
            or bool(is_whale_pump_ctx and score > 0)
            or bool(is_waterfall_ctx and score < 0)
            or (
                ('trap_detector' in votes)
                and (votes['trap_detector'][0] * score > 0)
                and bool(has_valid_trap_vol_ctx)
                and any(
                    getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                    and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.68
                    and ((s.signal == Signal.BUY and score > 0) or (s.signal == Signal.SELL and score < 0))
                    for s in signals
                )
            )
        )



        # DEAD ADX VETO: Thị trường cạn kiệt xung lực (cả ADX 4H và ADX 15M đều < 20.0)

        # Bắt buộc VETO toàn bộ tín hiệu TrendFollowing / Breakout trên Altcoin khi effective_adx < 20.0

        # (chặn đứng DASH ADX=13.1), trừ khi có Trap/Reversal, Whale Pump, Waterfall, hoặc đồng thuận kỹ thuật mạnh (agreeing >= 3)!

        if is_crypto_altcoin and (0.0 < effective_adx < 20.0):

            if not (has_strong_trap_reversal or agreeing >= 3 or c2_slot_b2_unlocked or dyn_vk_unlocked):

                logger.warning(

                    '🛡️ [DEAD ADX VETO] Hủy mở lệnh %s: Thị trường hoàn toàn đi ngang/cạn kiệt xung lực (ADX_4H=%.1f, ADX_15M=%.1f < 20.0)! Cấm mở lệnh theo xu hướng để tránh chôn vốn!',

                    symbol, macro_adx, tactical_adx

                )

                return None



        # [SỬA LỖI GỐC RỄ - ML FAIL-OPEN] Nếu _ai_analysis() ném ngoại lệ (model chưa train, thiếu

        # feature, lỗi suy luận), bot KHÔNG sinh ra tín hiệu ai_ensemble nào. Trước đây khối sàn

        # đồng thuận vi mô bên dưới được bảo vệ bằng `if ai_sig and ...`, nên khi AI vắng mặt thì

        # toàn bộ tầng thẩm định vi mô bị bỏ qua và lệnh được cấp chỉ với 1 chiến thuật kỹ thuật.

        # Nay AI vắng mặt được coi tương đương "AI Ensemble 0%": bắt buộc phải đạt chuẩn vi mô.

        ai_missing = ai_sig is None and not has_cold_start

        ai_gate_applies = (

            ai_missing

            or (

                ('ai_ensemble' in votes)

                or (ai_sig is not None and ai_sig.signal == Signal.HOLD and not has_cold_start)

            )

        )

        if ai_gate_applies and not is_tier1 and not c2_slot_b2_unlocked and not vk9_slot_b1_unlocked and not vk10_slot_b1_unlocked and not dyn_vk_unlocked:

            if ai_missing:
                _fb_orig_ai = float((trap_ctx or {}).get('orig_ai_vote', _raw_orig_ai_vote) or 0.0)
                ai_c = abs(_fb_orig_ai)
                ai_pred_dir = 'up' if _fb_orig_ai > 0 else ('down' if _fb_orig_ai < 0 else '')

            else:

                try:
                    ai_meta_raw = getattr(ai_sig, 'metadata', None) if isinstance(getattr(ai_sig, 'metadata', None), dict) else {}
                    ai_pred_dir = str(ai_meta_raw.get('prediction') or '').strip().lower()
                    ai_raw_conf = float(ai_meta_raw.get('model_confidence') or getattr(ai_sig, 'confidence', 0.0) or 0.0)
                    ai_hold_opp_conf = 0.0
                    if ai_sig.signal == Signal.HOLD:
                        # [BOM #125C FIX]: HOLD từ dynamic_threshold CHỈ dùng cho ai_is_opposing, KHÔNG cho ai_c >= 0.60 để vượt cổng Micro Consensus!
                        ai_c = 0.0
                        ai_hold_opp_conf = ai_raw_conf if ai_raw_conf >= 0.65 else 0.0
                    else:
                        ai_c = float(ai_sig.confidence)

                except (TypeError, ValueError):

                    ai_c = 0.0
                    ai_hold_opp_conf = 0.0
                    ai_pred_dir = ''

            ai_is_opposing = bool(

                ai_sig is not None

                and (

                    (ai_sig.signal == Signal.BUY and score < 0)

                    or (ai_sig.signal == Signal.SELL and score > 0)

                    or (ai_sig.signal == Signal.HOLD and locals().get('ai_hold_opp_conf', 0.0) >= 0.65 and ((ai_pred_dir == 'up' and score < 0) or (ai_pred_dir == 'down' and score > 0)))

                )

            )

            adx_floor = 25.0 if exempt_ai_opposing else 30.0

            adx_ok_micro = (macro_adx <= 0.0) or (macro_adx >= adx_floor)

            atr_ok_micro = (macro_atr_pre <= 0.0) or (macro_atr_pre < 5.0)

            if ai_is_opposing or ai_c < 0.60:

                # Phân nhánh Tầng 4 (bắt buộc thỏa mãn đồng thời ADX >= 30.0, ATR < 5.0% và không bị AI phản bác

                # hoặc được miễn trừ chính thức do kỹ thuật 15M đảo chiều mạnh):

                # Khi AI Ensemble yếu (< 60%) hoặc KHÔNG KHẢ DỤNG, bắt buộc phải có ít nhất 2 chiến thuật

                # kỹ thuật độc lập đồng thuận HOẶC 1 kỹ thuật độc lập + JEV Agent khẳng định mạnh (>= 80%):

                # [BÀI HỌC 95 - OPPOSING PILLAR VETO & WHALE SOLO ANCHOR PROTECTION]:
                # 1) Chỉ VETO lệnh Solo (agreeing < 2) khi có Trụ Cột lớn (AI Ensemble hoặc JEV) đối kháng cực đoan (>= 70%).
                # 2) Bảo toàn trọn vẹn 100% các lệnh Solo có Dòng tiền Cá Mập bảo trợ (FOGO, CBRS, BLESS, Smart Inversion) khi AI/JEV không đối kháng mạnh!
                ai_strong_opposing = (
                    ('ai_ensemble' in votes)
                    and (not exempt_ai_opposing)
                    and ai_is_opposing
                    and (ai_c >= 0.70)
                )
                jev_is_buy = getattr(jev_sig_pre, 'signal', None) in (Signal.BUY, 'BUY', 'buy')
                jev_is_sell = getattr(jev_sig_pre, 'signal', None) in (Signal.SELL, 'SELL', 'sell')
                jev_strong_opposing = bool(jev_sig_pre is not None and ((jev_is_buy and score < 0) or (jev_is_sell and score > 0)) and (jev_conf_pre >= 0.70))
                
                has_whale_anchor_solo = (agreeing >= 1) and (
                    has_strong_trap_reversal or bool(is_whale_pump_ctx) or bool(is_waterfall_ctx) or bool(is_confirmed_trap_reversal)
                )
                jev_aligned_pre = bool(jev_sig_pre is not None and ((jev_is_buy and score > 0) or (jev_is_sell and score < 0)))
                has_tech_support = (
                    (non_ai_agreeing >= 2)
                    or (non_ai_agreeing >= 1 and jev_aligned_pre and jev_conf_pre >= 0.80)
                    or (exempt_ai_opposing and non_ai_agreeing >= 1)
                    or is_confirmed_trap_reversal
                    or has_strong_breakout_consensus
                    or has_strong_trap_reversal
                    or is_multi_pillar_triad
                    or is_dual_pillar_high_conviction
                    or is_dual_brain_ai_consensus
                )

                is_high_conviction_entry = bool(is_multi_pillar_triad or is_dual_pillar_high_conviction or is_dual_brain_ai_consensus or is_confirmed_trap_reversal)
                atr_ok_effective = atr_ok_micro or is_high_conviction_entry

                is_strong_consensus = (
                    (not (ai_strong_opposing or jev_strong_opposing))
                    and (has_tech_support or (has_whale_anchor_solo and not ai_is_opposing))
                    and (adx_ok_micro or is_confirmed_trap_reversal or has_strong_trap_reversal)
                    and atr_ok_effective
                )

                if not is_strong_consensus:

                    logger.info(

                        '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble %s (%.2f%%) và cấu trúc vi mô (agree=%d, non_ai=%d, jev=%.2f, ADX=%.1f, ATR=%.2f%%) chưa đạt chuẩn!',

                        symbol,

                        'KHÔNG KHẢ DỤNG' if ai_missing else ('NGƯỢC CHIỀU' if ai_is_opposing else 'yếu (<60%)'),

                        ai_c * 100, agreeing, non_ai_agreeing, jev_conf_pre, macro_adx, macro_atr_pre

                    )

                    return None

            elif (
                ai_c < 0.70
                and not is_multi_pillar_triad
                and not is_dual_pillar_high_conviction
                and not is_dual_brain_ai_consensus
                and not has_strong_trap_reversal
                and not is_confirmed_trap_reversal
                and not is_unopposed_whale_flow_gate
                and ((0.0 < macro_adx < 22.0) or (not adx_ok_micro and macro_atr_pre >= 3.0))
            ):

                logger.info(

                    '🛡️ [MICRO CONSENSUS VETO] Hủy mở lệnh %s: AI Ensemble trung bình (%.2f%% < 70%%) nhưng xung lượng vĩ mô yếu hoặc biến động cao (ADX=%.1f, ATR=%.2f%%)!',

                    symbol, ai_c * 100, macro_adx, macro_atr_pre

                )

                return None



        # [ĐỒNG BỘ SSOT NGƯỠNG ĐIỂM ENTRY_THRESHOLD THEO CƠ CHẾ ĐỒNG THUẬN CAO]:
        # Triệt tiêu hoàn toàn sự đá nhau khi DUAL-PILLAR (>= 0.68) hoặc DUAL-BRAIN (>= 0.68)
        # đã cho phép thông qua nhưng determine_final_signal lại dùng threshold cứng 0.80 để chặn (đặc trị ZIL/USDT)
        if is_unopposed_whale_flow_gate:
            entry_threshold = min(entry_threshold, 0.42)
        elif is_dual_pillar_high_conviction or is_dual_brain_ai_consensus or c2_slot_b2_unlocked or vk9_slot_b1_unlocked or vk10_slot_b1_unlocked or dyn_vk_unlocked:
            entry_threshold = min(entry_threshold, 0.68)
        elif is_multi_pillar_triad:
            entry_threshold = min(entry_threshold, 0.70)
        elif is_confirmed_trap_reversal and agreeing >= 2 and (agreeing_tech >= 1 or is_dual_brain_ai_consensus):
            entry_threshold = min(entry_threshold, 0.68)

        final_signal = self.determine_final_signal(score, symbol, price, threshold=entry_threshold)
        c_upper_wick_pct = 0.0
        c_lower_wick_pct = 0.0
        c_vol_ratio = 1.0
        c_recent_pump = 0.0
        c_recent_dump = 0.0
        is_uptrend = False
        is_downtrend = False

        if final_signal.signal != Signal.HOLD:

            # Thu thập market analysis từ tín hiệu 4H và nến đóng hoàn chỉnh sớm nhất để sẵn sàng cho mọi tầng

            market_analysis = next(

                (

                    signal.metadata.get('market_analysis')

                    for signal in signals

                    if isinstance(getattr(signal, 'metadata', None), dict)

                    and isinstance(signal.metadata.get('market_analysis'), dict)

                ),

                {},

            )

            has_bear_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] > 0
                and has_valid_trap_vol_ctx
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
                    for s in signals
                )
            )
            has_bull_trap_wick = (
                'trap_detector' in votes
                and votes['trap_detector'][0] < 0
                and has_valid_trap_vol_ctx
                and any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
                    for s in signals
                )
            )
            # [BOM #131B FIX]: Dùng cờ đảo chiều ràng buộc hướng (is_confirmed_bull_trap_rev / is_confirmed_bear_trap_rev)
            # để khi VK2/VK14/VK15/VK11 lật ngược score không bao giờ gắn nhầm has_real_bear_trap lên Bull Trap (hay ngược lại)!
            has_real_bull_trap = has_bull_trap_wick or bool(has_real_bull_trap_ctx and score < 0) or bool(is_confirmed_bull_trap_rev and score < 0)
            has_real_bear_trap = has_bear_trap_wick or bool(has_real_bear_trap_ctx and score > 0) or bool(is_confirmed_bear_trap_rev and score > 0)
            jev_sig = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)

            # --- BỘ LỌC CỰC HẠN & BẢO VỆ ĐỈNH ĐÁY (CLIMAX & SMART INVERSION GATE) ---
            # [BÀI HỌC 78, 79, 80 & 82]: Thực hiện chuyển hóa Lưỡng Pha thông minh TRƯỚC MTF Trend Filter
            # để hướng lệnh cuối cùng (thực tế tác chiến) được thẩm định chính xác thay vì đánh giá trên hướng nến bứt phá ban đầu.
            try:
                macro_atr_pct = float(market_analysis.get('atr_pct') or 0.0)
                tactical_atr_15m_pct = float(market_analysis.get('tactical_atr_pct') or macro_atr_pct or 0.0)
            except (TypeError, ValueError):
                macro_atr_pct = 0.0
                tactical_atr_15m_pct = 0.0
            try:
                current_rsi = float(market_analysis.get('tactical_rsi') or market_analysis.get('rsi') or 50.0)
            except (TypeError, ValueError):
                current_rsi = 50.0

            # Candlestick Anatomy Metrics từ nến đã đóng iloc[-2] (chống bẫy kiệt sức mua/bán cá mập)
            c_upper_wick_pct = float(market_analysis.get('upper_wick_pct') or 0.0)
            c_lower_wick_pct = float(market_analysis.get('lower_wick_pct') or 0.0)
            _raw_c_vol_agg = market_analysis.get('candle_vol_ratio')
            c_vol_ratio = float(_raw_c_vol_agg) if _raw_c_vol_agg is not None else 1.0
            c_recent_pump = float(market_analysis.get('recent_pump_pct') or 0.0)
            c_recent_dump = float(market_analysis.get('recent_dump_pct') or 0.0)
            in_fading_short_watchlist = bool(market_analysis.get('in_fading_short_watchlist', False))

            original_signal = final_signal.signal

            # [BÀI HỌC 78, 79, 80, 82 & 92] KIẾN TRÚC LƯỠNG PHA & CHUYỂN HÓA BẮT ĐỈNH/ĐÁY TOÀN DIỆN
            # 0. BỘ LỌC THÁC ĐỔ (WATERFALL DUMP PROTECTION):
            # Khi Altcoin đang rơi tự do (Dump >= 2.5% hoặc rơi mạnh >= 3.5%) mà thiếu râu gom hàng (< 30%),
            # TUYỆT ĐỐI KHÔNG bắt dao rơi (chặn đứng thảm họa ZAMA: nến râu dưới 1.4%, rvol 0.59x)!
            # [BÀI HỌC 92]: Cấm nhận diện WaterfallDump nếu nến hiện tại đang bật tăng xanh mạnh (is_live_rebounding)!
            is_live_rebounding = bool(market_analysis.get('is_live_rebounding', False))
            is_live_dumping = bool(market_analysis.get('is_live_dumping', False))

            # [BÀI HỌC 103 & KB5 CHUẨN HÓA XUNG ĐỘT 1 - ĐỐI XỨNG LƯỠNG CỰC CÓ RÂU VẬT LÝ CHO CẢ 3 LỚP TÀI SẢN]:
            # Mở khóa toàn bộ 3 lớp tài sản (Major Crypto, TradFi, Crypto Altcoins) và phân tầng ngưỡng theo ATR thực tế.
            is_altcoin_or_tradfi = True
            macro_rsi = float(market_analysis.get('rsi') or 50.0)
            asset_tier_agg = 'TRADFI' if is_tradfi else ('TIER1' if is_tier1 else 'ALTCOIN')
            sf_agg = compute_smart_flow_thresholds(asset_tier_agg, tactical_atr_15m_pct)
            eff_atr_dec = sf_agg['eff_atr']
            parabolic_thresh = sf_agg['parabolic_thresh']
            parabolic_ext = sf_agg['parabolic_ext']
            # [V5.5 + BOM #141 C1 FIX - EXTREME VOLUME STORM SHIELD]: Ràng buộc ưu thế chiều sóng (pump vs dump)
            extreme_storm_rvol = 3.5 if is_tradfi else (6.0 if is_crypto_altcoin else 4.5)
            is_extreme_bull_storm = (
                c_vol_ratio >= extreme_storm_rvol
                and c_upper_wick_pct < 0.55
                and c_recent_pump >= max(0.005, c_recent_dump * 1.15)
            )
            is_extreme_bear_storm = (
                c_vol_ratio >= extreme_storm_rvol
                and c_lower_wick_pct < 0.55
                and c_recent_dump >= max(0.005, c_recent_pump * 1.15)
            )

            # [BOM #119A FIX]: Bat buoc c_vol_ratio >= sf_agg['min_trap_rvol'] cho ca nhanh parabolic_ext (chan nen chet thanh khoan PIEVERSE 0.15x!)
            _min_clx_rv_3662 = sf_agg['min_trap_rvol']
            is_panic_selling_climax = (not is_extreme_bear_storm) and (c_vol_ratio >= _min_clx_rv_3662) and (
                ((c_recent_dump >= parabolic_thresh and c_vol_ratio >= 1.80 and c_lower_wick_pct >= 0.30)
                 or (c_recent_dump >= parabolic_ext and c_lower_wick_pct >= 0.25))
            )
            # [V5.5 PARABOLIC ALTCOIN SHIELD]:
            min_uwick_para = 0.40 if is_crypto_altcoin else 0.30
            min_uwick_ext = 0.35 if is_crypto_altcoin else 0.25
            max_rvol_para = 4.50 if is_crypto_altcoin else 999.0
            is_parabolic_pump_climax = (not is_extreme_bull_storm) and (c_vol_ratio >= _min_clx_rv_3662) and (c_vol_ratio < max_rvol_para) and (
                ((c_recent_pump >= parabolic_thresh and c_vol_ratio >= 1.80 and c_upper_wick_pct >= min_uwick_para)
                 or (c_recent_pump >= parabolic_ext and c_upper_wick_pct >= min_uwick_ext))
            )

            # 0. BỘ LỌC THÁC ĐỔ (WATERFALL DUMP PROTECTION - CHUẨN HÓA 3 LỚP TÀI SẢN):
            # [V3.7 SSOT FIX #5]: Dùng đúng ATR tác chiến 15M đồng bộ 100% với core/bot.py
            min_waterfall_dump = sf_agg['min_waterfall_dump']
            max_wf_dump = sf_agg['max_waterfall_dump']
            wf_rvol_std = sf_agg['wf_rvol_std']

            is_waterfall_oversold_bottom = (macro_rsi <= 30.0 or current_rsi <= 32.0)
            is_waterfall_dump_shape = (c_upper_wick_pct < 0.28) and (
                c_recent_dump >= max(min_waterfall_dump, c_recent_pump * 1.30)
                or c_recent_dump >= sf_agg['wf_shape_dump_floor']
                or c_recent_pump <= sf_agg['wf_shape_pump_cap']
            )
            is_waterfall_dump = (
                (not is_live_rebounding)
                and (not is_panic_selling_climax)
                and (not is_waterfall_oversold_bottom)
                and is_waterfall_dump_shape
                and (current_rsi <= 58.0 or c_recent_dump >= c_recent_pump * 1.5)
                and (
                    (min_waterfall_dump <= c_recent_dump <= max_wf_dump and c_lower_wick_pct < 0.25 and c_vol_ratio >= wf_rvol_std)
                    or ((min_waterfall_dump * 1.35) <= c_recent_dump <= max_wf_dump and c_lower_wick_pct < 0.30 and c_vol_ratio >= sf_agg['wf_rvol_low'])
                    or (min_waterfall_dump <= c_recent_dump <= max_wf_dump and c_lower_wick_pct < 0.20 and c_vol_ratio >= sf_agg['wf_rvol_high'])
                )
            )

            # Nến kiệt sức mua phân phối đỉnh (Buying Climax): Ép buộc có râu trên vật lý >= 30-35%!
            min_climax_rvol = sf_agg['min_trap_rvol']
            min_climax_wave = sf_agg['min_climax_wave']
            climax_rvol = sf_agg['climax_rvol']
            # [KỊCH BẢN 10 SSOT - SÀN SÓNG BƠM THÍCH ỨNG 0.7%]:
            # Đã kiểm chứng đối soát trên 573 vị thế: Sàn 0.7% chặn sạch nhiễu đi ngang (< 0.6%),
            # đồng thời đón trọn 7 siêu sóng lớn (XRP +0.44$, BASED +0.80$, SOL +0.54$, ASTER +0.45$, MEGA +0.37$).
            # Climax bắt buộc phải có sóng bơm kiệt sức trước đó, không được bắt đỉnh một cây nến đi ngang lờ đờ!
            min_climax_hard_pump = 0.005 if is_tradfi else 0.007
            is_buying_climax_candle = (not is_extreme_bull_storm) and (
                (c_upper_wick_pct >= 0.45 and c_upper_wick_pct > c_lower_wick_pct * 1.3 and c_vol_ratio >= climax_rvol and c_recent_pump >= min_climax_hard_pump and (c_recent_pump >= min_climax_wave or current_rsi >= 58.0))
                or (c_recent_pump >= (0.035 if is_crypto_altcoin else 0.018) and c_upper_wick_pct >= 0.40 and c_vol_ratio >= (1.20 if is_crypto_altcoin else 1.00))
                or (has_real_bull_trap and c_upper_wick_pct >= 0.35 and c_recent_pump >= min_climax_hard_pump and (c_recent_pump >= min_climax_wave or current_rsi >= 58.0) and (c_vol_ratio >= (max(0.85, min_climax_rvol) if current_rsi >= 68.0 else 1.10)))
                or (in_fading_short_watchlist and c_upper_wick_pct >= 0.35 and c_vol_ratio >= 1.10 and c_recent_pump >= min_climax_hard_pump)
                or (is_parabolic_pump_climax and c_upper_wick_pct >= (0.40 if is_crypto_altcoin else 0.30))
            )

            # Nến kiệt sức bán rút chân gom hàng (Selling Climax): Ép buộc có râu dưới vật lý >= 30-35% và không phải bẫy xả giả 1h/15m!
            is_fake_bear_dump = bool(trap_ctx.get('is_fake_altcoin_bear_trap'))
            min_climax_hard_dump = 0.005 if is_tradfi else 0.007
            is_selling_climax_candle = (not is_fake_bear_dump) and (not is_waterfall_dump) and (not is_extreme_bear_storm) and (
                (c_lower_wick_pct >= 0.45 and c_lower_wick_pct > c_upper_wick_pct * 1.3 and c_vol_ratio >= climax_rvol and c_recent_dump >= min_climax_hard_dump and (c_recent_dump >= min_climax_wave or current_rsi <= 42.0))
                or (c_recent_dump >= (0.035 if is_crypto_altcoin else 0.018) and c_lower_wick_pct >= 0.40 and c_vol_ratio >= (1.20 if is_crypto_altcoin else 1.00))
                or (has_real_bear_trap and c_lower_wick_pct >= 0.35 and c_recent_dump >= min_climax_hard_dump and (c_recent_dump >= min_climax_wave or current_rsi <= 42.0) and (c_vol_ratio >= (max(0.85, min_climax_rvol) if current_rsi <= 32.0 else 1.10)))
                or (is_panic_selling_climax and c_lower_wick_pct >= 0.30)
            )

            # Bão volume cá mập kéo dốc (Whale Pump Storm): Thuận theo kẻ có tiền (Chuẩn hóa 3 lớp tài sản)
            min_whale_pump = sf_agg['min_whale_pump']
            wp_rvol_std = sf_agg['wp_rvol_std']
            is_whale_pump_storm = (
                not is_buying_climax_candle
                and not is_live_dumping
                and not is_waterfall_dump
                and not is_parabolic_pump_climax
                and c_upper_wick_pct < 0.30
                and (c_recent_pump >= max(min_whale_pump, c_recent_dump * 1.30) or c_recent_dump <= sf_agg['wf_shape_pump_cap'])
                and (
                    (min_whale_pump <= c_recent_pump <= max_wf_dump and c_vol_ratio >= wp_rvol_std)
                    or (c_vol_ratio >= sf_agg['wp_rvol_high'] and (min_whale_pump * 0.75) <= c_recent_pump <= max_wf_dump)
                )
            )

            # [QUY TẮC MỞ KHÓA TRADFI OPENING BELL]: TradFi phiên mở cửa Mỹ dùng bão Volume + RVol >= 1.8x
            is_opening_bell = False
            try:
                from ai.market_regime import MarketRegimeDetector
                is_opening_bell = MarketRegimeDetector.is_tradfi_opening_bell()
            except Exception:
                pass

            is_tradfi_opening_pump = (
                is_stock
                and is_opening_bell
                and c_vol_ratio >= 1.8
                and c_upper_wick_pct < 0.30
                and c_lower_wick_pct < 0.30
                and c_recent_pump >= 0.010
                and c_recent_pump <= 0.060
                and c_recent_pump >= c_recent_dump
                and current_rsi < 78.0
            )
            is_tradfi_opening_dump = (
                is_stock
                and is_opening_bell
                and c_vol_ratio >= 1.8
                and c_lower_wick_pct < 0.30
                and c_upper_wick_pct < 0.30
                and c_recent_dump >= 0.010
                and c_recent_dump <= 0.060
                and c_recent_dump >= c_recent_pump
                and current_rsi > 28.0
            )

            # -----------------------------------------------------------------------------------------
            # THỨ TỰ ƯU TIÊN LƯỠNG PHA (SMART DUAL-PHASE MATRIX & SMART INVERSION - KB5 UNIFIED)
            # TÔN CHỈ TỐI THƯỢNG: THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN - LẬT NGƯỢC THẾ CỜ KIẾM LỢI NHUẬN!
            # -----------------------------------------------------------------------------------------
            ai_vote_agg = votes.get('ai_ensemble', (0.0, 0.0))[0] if 'ai_ensemble' in votes else 0.0
            trend_vote_agg = votes.get('trend_following', (0.0, 0.0))[0] if 'trend_following' in votes else 0.0
            breakout_vote_agg = votes.get('momentum_breakout', (0.0, 0.0))[0] if 'momentum_breakout' in votes else 0.0
            mean_vote_agg = votes.get('mean_reversion', (0.0, 0.0))[0] if 'mean_reversion' in votes else 0.0
            jev_vote_agg = votes.get('jev_agent', (0.0, 0.0))[0] if 'jev_agent' in votes else 0.0
            orig_jev_vote = float(trap_ctx.get('orig_jev_vote', jev_vote_agg) or 0.0)
            orig_ai_vote = float(trap_ctx.get('orig_ai_vote', (_raw_orig_ai_vote if _raw_ai_votes else ai_vote_agg)) or 0.0)
            regime_pre_str = str(market_analysis.get('regime', 'ranging')).lower()

            # [RULE 0 SSOT & BOM #92 FIX]: Chi dung orig_jev_vote (tranh JEV SELL/BUY bi pop ve 0.0 kich nham khien nguoc!)
            # va bo `c_recent_pump >= 0.020` khoi shield de khong giet Buying Climax / Parabolic Short khi JEV=HOLD!
            is_jev_uptrend_shield_active = (orig_jev_vote >= 0.70) or (
                (orig_jev_vote >= 0.50)
                and (('uptrend' in regime_pre_str and macro_adx >= 28.0) or (c_upper_wick_pct < 0.30))
            )
            is_jev_downtrend_shield_active = (orig_jev_vote <= -0.70) or (
                (orig_jev_vote <= -0.50)
                and (('downtrend' in regime_pre_str and macro_adx >= 28.0) or (c_lower_wick_pct < 0.35))
            )

            smart_money_supports_sell = (
                original_signal == Signal.SELL
                or ai_vote_agg <= -0.55
                or trend_vote_agg < 0
                or breakout_vote_agg < 0
                or jev_vote_agg < 0
            )

            # [BOM #150 P2 FIX]: Cờ bảo vệ cực hạn ADX >= 55 / RSI cho các nhánh Trend Fallthrough
            _trend_fallthrough_climax_check = False

            # [BOM #140 + #141 C1 + #142 M1 FIX - HOISTED V5.5 EXTREME VOLUME STORM SHIELD]:
            # Đẩy Khiên Bão Volume Cực Đại lên cấp cao nhất trước nhánh KB5; chỉ miễn trừ nhánh Smart Inversion
            # thuận chiều bão khi nhánh L4370 thực sự có thể kích hoạt (not has_real_bull_trap cho bull storm)!
            if is_altcoin_or_tradfi and (not c2_slot_b2_unlocked) and (not vk9_slot_b1_unlocked) and (not vk10_slot_b1_unlocked) and (not dyn_vk_unlocked):
                if is_extreme_bull_storm and original_signal == Signal.SELL and not (is_waterfall_dump or ((is_whale_pump_storm or is_tradfi_opening_pump) and not has_real_bull_trap)):
                    logger.warning(
                        "🛡️ [EXTREME BULL STORM VETO] Hủy mở lệnh SHORT %s: Bão Volume cá mập cực đại (RVol=%.2fx >= %.1fx) "
                        "kèm râu trên chưa đủ từ chối (Râu=%.1f%% < 55%%)! Cá mập đang bơm bão cực đoan, tuyệt đối cấm Short cản tàu.",
                        symbol, c_vol_ratio, extreme_storm_rvol, c_upper_wick_pct * 100
                    )
                    self._record_veto(symbol, 'EXTREME_BULL_STORM_VETO', 'SHORT', f'RVol={c_vol_ratio:.2f}x, UW={c_upper_wick_pct*100:.1f}%')
                    return None
                if is_extreme_bear_storm and original_signal == Signal.BUY and not (is_whale_pump_storm or is_waterfall_dump or is_tradfi_opening_dump):
                    logger.warning(
                        "🛡️ [EXTREME BEAR STORM VETO] Hủy mở lệnh BUY %s: Bão Volume xả cực đại (RVol=%.2fx >= %.1fx) "
                        "kèm râu dưới chưa đủ gom hàng (Râu=%.1f%% < 55%%)! Cá mập đang xả tháo cống cực đoan, tuyệt đối cấm bắt dao rơi.",
                        symbol, c_vol_ratio, extreme_storm_rvol, c_lower_wick_pct * 100
                    )
                    self._record_veto(symbol, 'EXTREME_BEAR_STORM_VETO', 'LONG', f'RVol={c_vol_ratio:.2f}x, LW={c_lower_wick_pct*100:.1f}%')
                    return None

            # 0. [SLOT B2 - VK2 THỬ NGHIỆM (3C-KB10): PARABOLIC LONG INVERSION ENGINE]:
            if c2_slot_b2_unlocked:
                final_signal.signal = Signal.BUY
                final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.82)), 0.85)
                final_signal.metadata['is_fading_short'] = False
                final_signal.metadata['is_waterfall_short'] = False
                final_signal.metadata['is_momentum_ride'] = True
                final_signal.metadata['is_parabolic_long_inversion'] = True
                final_signal.metadata['is_experimental_weapon'] = True
                final_signal.metadata['is_trap_candidate'] = True
                final_signal.metadata['is_trap_entry'] = True
                final_signal.metadata['type'] = 'PARABOLIC_LONG_INVERSION_ALPHA2'
                final_signal.metadata['weapon_id'] = 'VK2_LONG_LAT_NGUOC_SONG_PARABOL'
                final_signal.metadata['weapon_code'] = 'VK2'
                final_signal.metadata['target_tp_pct'] = 0.025
                final_signal.metadata['be_trigger_pct'] = 0.0085
                final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                logger.info(
                    "🚀 [SLOT B2 - VK2 THỬ NGHIỆM (3C-KB10): PARABOLIC LONG INVERSION] %s: "
                    "Xác nhận LỆNH BUY thuận sóng bơm Parabolic JEV 4H (JEV=%+.2f, RSI=%.1f, RVol=%.2fx, ADX=%.1f, Pump=%.2f%%)!",
                    symbol, orig_jev_vote, current_rsi, c_vol_ratio, macro_adx, c_recent_pump * 100
                )

            # 0B. [SLOT B1 - VK9 THỬ NGHIỆM (L1∩A4): BÁN ĐỈNH RÂU CỰC ĐẠI ALTCOIN]:
            elif vk9_slot_b1_unlocked:
                if is_extreme_bull_storm:
                    logger.warning(
                        "🛡️ [EXTREME BULL STORM VETO - VK9] Hủy mở lệnh SHORT %s: Bão Volume cá mập cực đại (RVol=%.2fx >= %.1fx) "
                        "kèm râu trên chưa đủ xả (Râu=%.1f%% < 55%%)! Giữ an toàn chống cản tàu.",
                        symbol, c_vol_ratio, extreme_storm_rvol, c_upper_wick_pct * 100
                    )
                    return None
                final_signal.signal = Signal.SELL
                final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.82)), 0.85)
                final_signal.metadata['is_fading_short'] = True
                final_signal.metadata['is_waterfall_short'] = False
                final_signal.metadata['is_momentum_ride'] = False
                final_signal.metadata['is_oversold_bounce'] = False
                final_signal.metadata['is_vk9_climax_wick_short'] = True
                final_signal.metadata['is_experimental_weapon'] = True
                final_signal.metadata['is_trap_candidate'] = True
                final_signal.metadata['is_trap_entry'] = True
                final_signal.metadata['type'] = 'VK9_CLIMAX_WICK_SHORT'
                final_signal.metadata['weapon_id'] = 'VK9_SHORT_BAN_DINH_RAU_CUC_DAI'
                final_signal.metadata['weapon_code'] = 'VK9'
                final_signal.metadata['target_tp_pct'] = 0.025
                final_signal.metadata['be_trigger_pct'] = 0.0085
                final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                logger.info(
                    "🧪 [SLOT B1 - VK9 THỬ NGHIỆM (L1∩A4): BÁN ĐỈNH RÂU CỰC ĐẠI] %s: "
                    "Xác nhận LỆNH SHORT Altcoin (U_Wick=%.1f%% >= 65%%, RSI=%.1f < 65, RVol=%.2fx >= 1.33x, ADX=%.1f >= 20, AI=%+.2f)!",
                    symbol, c_upper_wick_pct * 100, current_rsi, c_vol_ratio, macro_adx, ai_vote_agg
                )

            # 0C. [SLOT B1 - VK10 THỬ NGHIỆM (TRADFI S13): MUA ĐÁY RÚT CHÂN TRADFI]:
            elif vk10_slot_b1_unlocked:
                # [BOM #27 FIX]: Đồng bộ với L4048 & RiskManager L127 — Opening Bell NYSE/NASDAQ chỉ áp dụng cho Cổ phiếu (`is_stock`),
                # KHÔNG chặn oan Hàng hóa 24/5 CME Globex (Vàng XAU, Bạc XAG, Dầu thô CL/BZ) vào khung thanh khoản mạnh nhất!
                if bool(is_stock and is_opening_bell):
                    logger.warning(
                        "🛡️ [OPENING BELL TRADFI VETO - VK10] Hủy mở lệnh BUY bắt đáy cổ phiếu %s: Cấm bắt dao rơi Cổ phiếu Mỹ trong giờ mở phiên Wall Street (Rule 0.7 #3)!",
                        symbol
                    )
                    return None
                if is_extreme_bear_storm:
                    logger.warning(
                        "🛡️ [EXTREME BEAR STORM VETO - VK10] Hủy mở lệnh BUY %s: Bão Volume xả cực đại (RVol=%.2fx >= %.1fx) chưa có râu đỡ >= 55%%!",
                        symbol, c_vol_ratio, extreme_storm_rvol
                    )
                    return None
                _is_etf_vk10 = hasattr(MarketScanner, 'is_leveraged_etf') and MarketScanner.is_leveraged_etf(symbol)
                final_signal.signal = Signal.BUY
                final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.82)), 0.85)
                final_signal.metadata['is_fading_short'] = False
                final_signal.metadata['is_waterfall_short'] = False
                final_signal.metadata['is_momentum_ride'] = False
                final_signal.metadata['is_oversold_bounce'] = True
                final_signal.metadata['is_vk10_tradfi_bottom_long'] = True
                final_signal.metadata['is_experimental_weapon'] = True
                final_signal.metadata['is_trap_candidate'] = True
                final_signal.metadata['is_trap_entry'] = True
                final_signal.metadata['type'] = 'VK10_TRADFI_BOTTOM_WICK_LONG'
                final_signal.metadata['weapon_id'] = 'VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI'
                final_signal.metadata['weapon_code'] = 'VK10'
                final_signal.metadata['target_tp_pct'] = 0.030 if _is_etf_vk10 else 0.018
                final_signal.metadata['be_trigger_pct'] = 0.0085
                final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                logger.info(
                    "🧪 [SLOT B1 - VK10 THỬ NGHIỆM (TRADFI S13): MUA ĐÁY RÚT CHÂN TRADFI] %s: "
                    "Xác nhận LỆNH BUY TradFi (ATR=%.2f%% >= 0.38%%, ADX=%.1f <= 30, L_Wick=%.1f%% >= 38%%, RSI=%.1f >= 33, RVol=%.2fx, AI=%+.2f)!",
                    symbol, tactical_atr_15m_pct, macro_adx, c_lower_wick_pct * 100, current_rsi, c_vol_ratio, ai_vote_agg
                )

            # 0D. [VŨ KHÍ ĐỘNG V6.1 (DYN-VK11..14) — ĐỦ KHỚP NỐI 8 TRẠM & CÔNG THỨC M1 CKS (BOM #53 & #95D FIX)]:
            elif dyn_vk_unlocked and dyn_vk_matched is not None:
                _bp_dyn = dyn_vk_matched.get('blueprint') or {}
                _dyn_side_u = str(dyn_vk_matched.get('_resolved_side') or dyn_vk_matched.get('side') or 'LONG').upper()
                if bool(is_stock and is_opening_bell):
                    logger.warning("🛡️ [OPENING BELL VETO - %s] Chặn cổ phiếu %s trong giờ mở phiên Mỹ.", dyn_vk_matched.get('code'), symbol)
                    self._record_veto(symbol, 'OPENING_BELL_VETO', _dyn_side_u, 'Chặn cổ phiếu mở phiên Mỹ', dyn_vk_matched.get('id', ''))
                    return None
                if _dyn_side_u == 'SHORT' and is_extreme_bull_storm:
                    logger.warning("🛡️ [EXTREME BULL STORM VETO - %s] Chặn SHORT %s giữa bão bơm cực đại (RVol=%.2fx, U_Wick=%.1f%%).", dyn_vk_matched.get('code'), symbol, c_vol_ratio, c_upper_wick_pct * 100)
                    self._record_veto(symbol, 'EXTREME_BULL_STORM_VETO', 'SHORT', 'Bão bơm cực đại', dyn_vk_matched.get('id', ''))
                    return None
                if _dyn_side_u == 'LONG' and is_extreme_bear_storm:
                    logger.warning("🛡️ [EXTREME BEAR STORM VETO - %s] Chặn LONG %s giữa bão xả cực đại (RVol=%.2fx, L_Wick=%.1f%%).", dyn_vk_matched.get('code'), symbol, c_vol_ratio, c_lower_wick_pct * 100)
                    self._record_veto(symbol, 'EXTREME_BEAR_STORM_VETO', 'LONG', 'Bão xả cực đại', dyn_vk_matched.get('id', ''))
                    return None
                final_signal.signal = Signal.BUY if _dyn_side_u == 'LONG' else Signal.SELL
                final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.82)
                # [BOM #53 FIX]: Reset cờ ngược chiều + đồng bộ dấu weighted_score (SL/TP tính chuẩn 1 lần ở _aggregate_protection_level + L4839!)
                final_signal.metadata['is_fading_short'] = False
                final_signal.metadata['is_waterfall_short'] = False
                final_signal.metadata['is_momentum_ride'] = False
                final_signal.metadata['is_oversold_bounce'] = False
                final_signal.metadata['is_vk9_climax_wick_short'] = False
                final_signal.metadata['is_vk10_tradfi_bottom_long'] = False
                final_signal.metadata['is_parabolic_long_inversion'] = False
                final_signal.metadata['is_dynamic_weapon'] = True
                final_signal.metadata['is_experimental_weapon'] = bool(dyn_vk_matched.get('is_experimental', True))
                final_signal.metadata['is_trap_candidate'] = True
                final_signal.metadata['is_trap_entry'] = True
                final_signal.metadata['weapon_id'] = dyn_vk_matched['id']
                final_signal.metadata['weapon_code'] = dyn_vk_matched['code']
                final_signal.metadata['weapon_name_vi'] = dyn_vk_matched['short_name']
                final_signal.metadata['type'] = f"DYN_{dyn_vk_matched['code']}_{_dyn_side_u}"
                _active_leg_bp = (_bp_dyn.get('legs') or {}).get(_dyn_side_u) if isinstance(_bp_dyn.get('legs'), dict) else None
                _eff_dna_rules = dict((_active_leg_bp or _bp_dyn).get('dna_rules') or {})
                _has_wick_rule_dyn = ('uw_min' in _eff_dna_rules) or ('lw_min' in _eff_dna_rules)
                _resolved_q_arch = str((_active_leg_bp or _bp_dyn).get('quantum_archetype') or _bp_dyn.get('quantum_archetype') or 'CLIMAX_REVERSAL')
                _resolved_cks_k = float((_active_leg_bp or _bp_dyn).get('m1_cks_urgency_k') or _bp_dyn.get('m1_cks_urgency_k') or 0.18)
                if _has_wick_rule_dyn and _resolved_q_arch == 'TREND_MOMENTUM':
                    _resolved_q_arch = 'OVERSOLD_BOUNCE' if _dyn_side_u == 'LONG' else 'CLIMAX_REVERSAL'
                    _resolved_cks_k = max(_resolved_cks_k, 0.18)
                final_signal.metadata['m1_cks_urgency_k'] = _resolved_cks_k
                final_signal.metadata['m1_ofi_limit'] = float((_active_leg_bp or _bp_dyn).get('m1_ofi_limit') or _bp_dyn.get('m1_ofi_limit') or 0.75)
                final_signal.metadata['dyn_slot'] = str((_active_leg_bp or _bp_dyn).get('slot') or _bp_dyn.get('slot') or '')
                final_signal.metadata['dyn_regime_mode'] = str((_active_leg_bp or _bp_dyn).get('regime_mode') or _bp_dyn.get('regime_mode') or 'CRYPTO_CLIMAX_TIER1')
                final_signal.metadata['dyn_veto_gate_match'] = str((_active_leg_bp or _bp_dyn).get('veto_gate_match') or _bp_dyn.get('veto_gate_match') or '')
                final_signal.metadata['dyn_pre_veto_gate'] = str(_bp_dyn.get('pre_veto_gate') or _bp_dyn.get('veto_gate_match') or _dyn_veto_gate or '')
                final_signal.metadata['dyn_expected_ai_votes'] = [str(v).upper() for v in (_bp_dyn.get('ai_votes') or []) if v]
                final_signal.metadata['dyn_pathway_family'] = str((_active_leg_bp or _bp_dyn).get('pathway_family') or _bp_dyn.get('pathway_family') or '').upper()
                final_signal.metadata['dyn_dna_rules'] = _eff_dna_rules
                final_signal.metadata['dyn_source_signature'] = str(dyn_vk_matched.get('source_signature') or '').upper()
                final_signal.metadata['quantum_archetype'] = _resolved_q_arch
                final_signal.metadata['be_trigger_pct'] = 0.0085
                _dyn_abs_sc = max(abs(float(score or 0.0)), 0.82)
                score = _dyn_abs_sc if _dyn_side_u == 'LONG' else -_dyn_abs_sc
                final_signal.metadata['weighted_score'] = score
                final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                logger.info(
                    "🧪 [VŨ KHÍ ĐỘNG %s - 8 TRẠM] %s (%s): %s | M1=%s",
                    dyn_vk_matched['code'], symbol, _dyn_side_u, dyn_vk_matched['short_name'], _bp_dyn.get('m1_profile_vi', ''),
                )

            # 1. CHUYỂN HÓA THÁC ĐỔ CÁ MẬP XẢ (SMART WATERFALL BREAKDOWN SHORT VS BẢO VỆ ĐÁY V4):
            elif is_altcoin_or_tradfi and (is_waterfall_dump or is_tradfi_opening_dump or (is_fake_bear_dump and smart_money_supports_sell and c_lower_wick_pct < 0.28 and c_vol_ratio >= 1.25)):
                has_real_bearish_tech = (trend_vote_agg <= -0.30) or (breakout_vote_agg <= -0.30) or (orig_jev_vote <= 0.0) or is_tradfi_opening_dump
                # [KB5 V4]: Cấm Short đuổi ở cuối sóng thác đổ khi cả AI & JEV đều đã SELL sâu ở đáy (chống Short Squeeze)
                late_wf_dump_th = 0.042 if is_crypto_altcoin else 0.028
                is_late_waterfall_exhausted = (ai_vote_agg <= -0.60 and orig_jev_vote <= -0.60 and (c_recent_dump >= late_wf_dump_th or current_rsi <= 38.0))
                # [RULE 0 - JEV MTF TREND SHIELD]: CẤM TUYỆT ĐỐI Short cản tàu khi JEV Agent 4H đang BUY mạnh (>= 70%)!
                is_jev_counter_trend = (orig_jev_vote >= 0.70)
                if is_late_waterfall_exhausted:
                    logger.warning(
                        "🛡️ [KB5 WATERFALL BOTTOM VETO (V4)] Hủy mở lệnh SHORT %s: Thác đổ đã ở cuối sóng (Dump=%.1f%%, RSI=%.1f, AI=%+.2f, JEV=%+.2f)! "
                        "Đứng ngoài né nhịp giật hồi Short Squeeze.",
                        symbol, c_recent_dump * 100, current_rsi, ai_vote_agg, orig_jev_vote
                    )
                    return None
                elif is_jev_counter_trend:
                    logger.warning(
                        "🛡️ [JEV MTF TREND SHIELD (WATERFALL SHORT VETO)] Hủy mở lệnh SHORT %s: JEV Agent 4H đang BUY mạnh (%.1f%% >= 70%%)! "
                        "Cấm Short cản tàu ngược dòng tiền cá mập vĩ mô!",
                        symbol, orig_jev_vote * 100
                    )
                    return None
                elif (current_rsi >= 42.0 or has_real_bearish_tech) and current_rsi > 32.0 and macro_rsi > 30.0 and c_recent_dump <= (max(max_wf_dump, 0.060) if is_tradfi_opening_dump else max_wf_dump) and (smart_money_supports_sell or is_tradfi_opening_dump) and (jev_vote_agg <= 0.0) and orig_jev_vote < 0.65:
                    final_signal.signal = Signal.SELL
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_fading_short'] = False  # [BÀI HỌC 92]: Waterfall không phải Fading Short đỉnh
                    final_signal.metadata['is_waterfall_short'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'WATERFALL_BREAKDOWN_SHORT'
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.0085
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                    final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                    logger.info(
                        "🌊 [SMART WATERFALL INVERSION: THUẬN ĐÀ CÁ MẬP XẢ] %s: Phát hiện thác đổ không râu đỡ "
                        "(Dump=%.1f%%, Râu dưới=%.1f%% < 30%%, RVol=%.2fx, RSI=%.1f)! Xác nhận LỆNH SELL THUẬN DÒNG TIỀN CÁ MẬP!",
                        symbol, c_recent_dump * 100, c_lower_wick_pct * 100, c_vol_ratio, current_rsi
                    )
                elif c_recent_dump > (max(max_wf_dump, 0.060) if is_tradfi_opening_dump else max_wf_dump) or current_rsi <= 30.0 or (orig_jev_vote >= 0.65 and current_rsi < 45.0):
                    logger.warning(
                        "🛡️ [WATERFALL EXTENDED VETO] Hủy mở lệnh SHORT %s: Nến đã xả sâu hoặc JEV báo gom đáy (Dump=%.1f%%, RSI=%.1f, JEV=%+.2f)! "
                        "Cấm Short đu đáy để né bẫy ép Short Squeeze!",
                        symbol, c_recent_dump * 100, current_rsi, orig_jev_vote
                    )
                    return None
                elif original_signal == Signal.BUY or is_selling_climax_candle or is_whale_pump_storm:
                    logger.warning(
                        "🛡️ [WATERFALL DUMP VETO] Hủy mở lệnh BUY %s: Đang xả dốc (Dump=%.1f%%, RSI=%.1f) và thiếu râu gom hàng "
                        "(Râu dưới=%.1f%% < 30%%, RVol=%.2fx)! Tuyệt đối KHÔNG bắt dao rơi.",
                        symbol, c_recent_dump * 100, current_rsi, c_lower_wick_pct * 100, c_vol_ratio
                    )
                    return None
                else:
                    logger.warning(
                        "🛡️ [WATERFALL GREY-ZONE VETO] Hủy mở lệnh %s (%s): Đang xả thác đổ (Dump=%.1f%%, RSI=%.1f, JEV=%+.2f, RVol=%.2fx) "
                        "nhưng chưa đủ đồng thuận kỹ thuật/dòng tiền để mở lệnh an toàn.",
                        symbol, original_signal.value, c_recent_dump * 100, current_rsi, orig_jev_vote, c_vol_ratio
                    )
                    return None

            # 2. PHA 2 (CHỈ KHI CÓ RÂU XẢ ĐỈNH VẬT LÝ >= 30-35% VÀ KHÔNG CHỐNG STRONG UPTREND JEV >= 70%): BẮT ĐỈNH KIỆT SỨC MUA
            # [BOM #26 + #131B FIX]: Bắt buộc sàn bơm tối thiểu KB10 (min_climax_hard_pump = 0.7% Alt / 0.5% TradFi) cả cho nhánh watchlist!
            elif is_altcoin_or_tradfi and (is_buying_climax_candle or is_parabolic_pump_climax or (in_fading_short_watchlist and c_upper_wick_pct >= 0.35 and c_vol_ratio >= 1.20 and c_recent_pump >= min_climax_hard_pump)):
                # [KB5 XUNG ĐỘT 3 & NHÓM LẬT NGƯỢC I1]: Cờ is_jev_uptrend_shield_active toàn cục đã bảo vệ tuyệt đối (orig_jev_vote >= 0.70)
                # Tuyệt đối CẤM Fading Short cản tàu khi Uptrend Shield đang bật!
                has_super_climax = (not is_jev_uptrend_shield_active) and (
                    (c_vol_ratio >= (3.0 if is_crypto_altcoin else 2.2) and c_recent_pump >= (0.035 if is_crypto_altcoin else 0.018) and c_upper_wick_pct >= 0.40) or is_parabolic_pump_climax
                )
                # [BOM #95E + #131B + #134 FIX]: Đối xứng PHA 3 LONG (L4330) — chỉ miễn AI BUY mạnh khi tầng _strategy_votes
                # THỰC SỰ đã pop ai_ensemble (ai_popped_by_macro_dual_brain / ai_popped_by_fading_short), bỏ fallback orig_jev_vote <= -0.70!
                _ai_popped_short_ok = bool(trap_ctx.get('ai_popped_by_macro_dual_brain')) or bool(trap_ctx.get('ai_popped_by_fading_short'))
                # [BOM #148 P1-2 FIX]: Đối xứng Pha 3 LONG (L4442) — tôn trọng _ai_popped_short_ok khi Dual-Brain/Fading đã gỡ phiếu AI BUY!
                _ai_blocks_weak_fade = (orig_ai_vote >= 0.70 and not _ai_popped_short_ok and c_recent_pump < min_climax_wave and not is_parabolic_pump_climax)
                can_fade_short = (
                    (not is_jev_uptrend_shield_active)
                    and (not _ai_blocks_weak_fade)
                    and (orig_ai_vote < 0.70 or _ai_popped_short_ok)
                    and (ai_vote_agg < 0.60 or _ai_popped_short_ok)
                    and (has_super_climax or (jev_vote_agg <= 0.0 and ai_vote_agg <= 0.60))
                    and (c_recent_pump >= min_climax_wave or is_parabolic_pump_climax or (orig_jev_vote <= 0.0 and (orig_ai_vote < 0.70 or _ai_popped_short_ok)))
                )

                if is_extreme_bull_storm:
                    logger.warning(
                        "🛡️ [EXTREME BULL STORM VETO] Hủy mở lệnh SHORT %s: Bão Volume cá mập cực đại (RVol=%.2fx >= %.1fx) "
                        "kèm râu trên chưa đủ từ chối (Râu=%.1f%% < 55%%)! Cá mập đang bơm bão cực đoan, tuyệt đối cấm Short cản tàu.",
                        symbol, c_vol_ratio, extreme_storm_rvol, c_upper_wick_pct * 100
                    )
                    self._record_veto(symbol, 'EXTREME_BULL_STORM_VETO', 'SHORT', f'RVol={c_vol_ratio:.2f}x, UW={c_upper_wick_pct*100:.1f}%')
                    return None

                _has_primary_trend_short_4325 = (
                    original_signal == Signal.SELL
                    and any(votes.get(k, (0.0, 0.0))[0] < 0 for k in ('trend_following', 'momentum_breakout'))
                    and ((ai_vote_agg < 0.0 or _ai_popped_short_ok) and jev_vote_agg <= 0.0)
                )
                if can_fade_short:
                    # [BOM #147 P0-1 + BOM #148 P1-2/P2-2 + BOM #150 P1 FIX]: Khi lệnh gốc ĐÃ LÀ SELL thuận xu hướng đa trụ (kể cả khi Dual-Brain đã gỡ phiếu AI),
                    # KHÔNG để phiếu phụ BULL_TRAP_WICK cướp lệnh sang VK7 (PAUSED) hoặc ép sang VK6 rồi bị giết oan bởi VK6 DNA Shield!
                    _has_raw_bull_trap_wick = any(
                        'BULL_TRAP' in str((getattr(s, 'metadata', None) or {}).get('type') or '').upper()
                        and 'BUYING_CLIMAX' not in str((getattr(s, 'metadata', None) or {}).get('type') or '').upper()
                        for s in (signals or [])
                    )
                    _would_die_in_vk6_dna = (
                        c_upper_wick_pct < 0.45
                        or c_lower_wick_pct >= 0.25
                        or current_rsi < 40.0
                        or current_rsi >= 68.0
                        or (is_crypto_altcoin and c_recent_pump >= 0.060 and c_upper_wick_pct < 0.65)
                        or (c_recent_dump >= max(0.035, c_recent_pump * 1.50) and current_rsi < 45.0)
                    )
                    if _has_primary_trend_short_4325 and (_has_raw_bull_trap_wick or _would_die_in_vk6_dna):
                        _trend_fallthrough_climax_check = True
                        logger.info(
                            "🛡️ [BOM #147/150/152 ANTI-HIJACK SHORT] %s: Bảo toàn lệnh SELL thuận xu hướng đa trụ (Trend/BO + AI + JEV), không cho cướp sang VK6/VK7!",
                            symbol,
                        )
                    elif _would_die_in_vk6_dna and (not (is_crypto_altcoin and c_recent_pump >= 0.060 and c_upper_wick_pct < 0.65)):
                        # [BOM #152 P0-7 FIX]: Không duyệt sớm FADING SHORT nếu chắc chắn chết DNA VK6 (giữ nhánh Parabolic Altcoin đi tới VK6 DNA để ghi đúng mã lý do BOM #130)!
                        logger.warning(
                            "🛡️ [BOM #152 PHA 2 PRE-DNA VETO] Hủy FADING/PARABOLIC SHORT %s: Không đạt chuẩn DNA VK6 (UW=%.1f%%, LW=%.1f%%, RSI=%.1f, Pump=%.1f%%).",
                            symbol, c_upper_wick_pct * 100.0, c_lower_wick_pct * 100.0, current_rsi, c_recent_pump * 100.0,
                        )
                        self._record_veto(symbol, 'PHA2_PRE_VK6_DNA_VETO', 'SHORT', f'UW={c_upper_wick_pct*100:.0f}% RSI={current_rsi:.1f} Pump={c_recent_pump*100:.1f}%')
                        return None
                    else:
                        final_signal.signal = Signal.SELL
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        final_signal.metadata['is_fading_short'] = True
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        if is_parabolic_pump_climax:
                            final_signal.metadata['type'] = 'PARABOLIC_EXHAUSTION_SHORT'
                        elif _has_raw_bull_trap_wick and has_real_bull_trap:
                            final_signal.metadata['type'] = 'BULL_TRAP_WICK'
                        elif is_buying_climax_candle:
                            final_signal.metadata['type'] = 'BUYING_CLIMAX'
                        else:
                            final_signal.metadata['type'] = 'FADING_SHORT_PHASE2'
                        if is_parabolic_pump_climax and is_crypto_altcoin:
                            # [BOM #125A FIX]: Xóa bản sao sót position_size_multiplier=0.50 (BOM #122A đã bỏ phạt kép Parabolic trên Risk Parity)
                            final_signal.metadata['is_parabolic_altcoin'] = True
                        final_signal.metadata['target_tp_pct'] = 0.030
                        final_signal.metadata['be_trigger_pct'] = 0.010
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                        final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                        logger.info(
                            "⚡ [EXHAUSTION FADING SHORT: BẮT ĐỈNH CÁ MẬP] %s: Nến kiệt sức mua phân phối đỉnh "
                            "(Râu trên=%.1f%%, RVol=%.2fx, Pump=%.1f%%, Parabolic=%s, BullTrap=%s, Watchlist=%s)! Xác nhận LỆNH SELL ĐÓN SẬP!",
                            symbol, c_upper_wick_pct * 100, c_vol_ratio, c_recent_pump * 100, is_parabolic_pump_climax, has_real_bull_trap, in_fading_short_watchlist
                        )
                elif _has_primary_trend_short_4325 and (not is_jev_uptrend_shield_active):
                    # [BOM #149 P1-6 + BOM #150 P2 FIX]: Đối xứng TREND HAMMER FALLTHROUGH LONG — bảo toàn kèo SELL 4 trụ thuận xu hướng nhưng vẫn qua kiểm định ADX>=55/RSI<=32!
                    _trend_fallthrough_climax_check = True
                    logger.info(
                        "🛡️ [BOM #149 TREND HAMMER FALLTHROUGH SHORT] %s: Bảo toàn lệnh SELL thuận xu hướng đa trụ (Trend/BO + AI + JEV) đi tiếp sang VK8 thay vì FADING SHORT VETO!",
                        symbol,
                    )
                else:
                    if original_signal == Signal.SELL:
                        logger.warning(
                            "🛡️ [FADING SHORT VETO] Hủy mở lệnh SHORT %s: Thiếu xung lượng bơm đỉnh (Pump=%.2f%% < %.2f%%) hoặc JEV đối kháng mạnh (JEV=%+.2f)!",
                            symbol, c_recent_pump * 100, min_climax_wave * 100, orig_jev_vote
                        )
                        self._record_veto(symbol, 'FADING_SHORT_VETO', 'SHORT', f'Pump={c_recent_pump*100:.2f}%, JEV={orig_jev_vote:+.2f}')
                    else:
                        logger.warning(
                            "🛡️ [BUYING CLIMAX BUY VETO] Hủy mở lệnh BUY %s: Nến có râu xả đỉnh phân phối (Râu trên=%.1f%% >= 30%%), cấm đu đỉnh râu!",
                            symbol, c_upper_wick_pct * 100
                        )
                        self._record_veto(symbol, 'BUYING_CLIMAX_BUY_VETO', 'LONG', f'UW={c_upper_wick_pct*100:.1f}%')
                    return None

            # 3. PHA 1: THUẬN KẺ CÓ TIỀN - BÃO VOLUME CÁ MẬP (SMART MOMENTUM RIDE BUY - SỬA XUNG ĐỘT 5 + BOM #26):
            # Khi nến xanh đặc (râu trên < 25%-30%), RVol >= wp_rvol_std (hoặc bão mở phiên Mỹ is_tradfi_opening_pump) và JEV ủng hộ (>= 0)!
            elif is_altcoin_or_tradfi and (is_whale_pump_storm or is_tradfi_opening_pump) and c_upper_wick_pct < 0.30 and not has_real_bull_trap and not is_waterfall_dump and not is_parabolic_pump_climax:
                is_jev_warning_exhaustion = any(
                    isinstance(getattr(s, 'metadata', None), dict)
                    and any(w in str(s.metadata.get('reason', '')).lower() for w in ('exhaustion', 'overheated', 'absorption', 'rejection'))
                    for s in signals if getattr(s, 'strategy', '') == 'jev_agent'
                )
                # [BOM #141 FIX - PHÁP Y DODOX/USDT -$0.50]: Siết trần RSI Altcoin VK1 từ 75.0 xuống 71.0 (khớp VK15 72.0) để chặn mua đuổi quá mua (DODOX RSI=73.3) nhưng giữ trọn sóng khỏe (SPACE RSI=70.0)!
                _alt_mom_rsi_hi = 71.0 if is_crypto_altcoin else 75.0
                rsi_mom_cap = _alt_mom_rsi_hi if (c_upper_wick_pct < 0.25 and c_vol_ratio >= wp_rvol_std and orig_jev_vote >= 0.0) else 68.0
                _max_mom_pump_cap = max(max_wf_dump, 0.060) if is_tradfi_opening_pump else max_wf_dump
                if c_recent_pump > _max_mom_pump_cap or current_rsi >= rsi_mom_cap:
                    logger.warning(
                        "🛡️ [PUMP EXTENDED VETO] Hủy mở lệnh BUY %s: Nến đã pump quá dốc (Pump=%.1f%%/trần %.1f%%, RSI=%.1f/trần %.1f)! "
                        "Cấm mua đu đỉnh rướn kiệt sức (đặc trị bài học BEAMX, SHAZ).",
                        symbol, c_recent_pump * 100, _max_mom_pump_cap * 100, current_rsi, rsi_mom_cap
                    )
                    return None
                elif not is_jev_warning_exhaustion and jev_vote_agg >= 0.0:
                    final_signal.signal = Signal.BUY
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    final_signal.metadata['is_momentum_ride'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'MOMENTUM_RIDE'
                    final_signal.metadata['target_tp_pct'] = 0.025
                    final_signal.metadata['be_trigger_pct'] = 0.0085
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                    final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                    logger.info(
                        "🚀 [SMART MOMENTUM RIDE: THUẬN KẺ CÓ TIỀN] %s: Bão volume cá mập (RVol=%.2fx, Pump=%.2f%%, Râu trên=%.1f%% < 30%%)! "
                        "Ưu tiên Pha 1: LỆNH BUY LƯỚT SÓNG ăn nhịp rướn cá mập (Cấm cản tàu)!",
                        symbol, c_vol_ratio, c_recent_pump * 100, c_upper_wick_pct * 100
                    )
                else:
                    logger.warning(
                        "🛡️ [MOMENTUM RIDE VETO] Hủy mở lệnh BUY %s: JEV cảnh báo kiệt sức lực mua hoặc JEV đối kháng (JEV=%+.2f)! Cấm đu đỉnh.",
                        symbol, jev_vote_agg
                    )
                    return None

            # 4. PHA 3: BẮT ĐÁY RÚT CHÂN GOM HÀNG (OVERSOLD BOUNCE LONG) HOẶC SMART WATERFALL INVERSION SHORT:
            # Kích hoạt khi có râu dưới hấp thụ vật lý HOẶC nến xả hoảng loạn kiệt sức bán (Panic Selling Climax)!
            elif is_altcoin_or_tradfi and (is_selling_climax_candle or is_panic_selling_climax) and not is_waterfall_dump:
                # [QUY TẮC RÀO CHẮN TRADFI PHIÊN MỸ & BOM #27/#92]: Chi chan Co Phieu My (is_stock), mien Hang Hoa 24/5 (XAU/XAG/CL/BZ)!
                is_tradfi_bell_blocked = bool(is_stock and is_opening_bell)

                # [KB5 XUNG ĐỘT 3 & NHÓM LẬT NGƯỢC I2 - DOWNTREND SHIELD]: is_jev_downtrend_shield_active da tinh tai L3868-3871
                has_super_climax_buy = (not is_jev_downtrend_shield_active) and (
                    (c_vol_ratio >= (3.0 if is_crypto_altcoin else 2.2) and c_recent_dump >= (0.035 if is_crypto_altcoin else 0.018) and c_lower_wick_pct >= 0.40) or (is_panic_selling_climax and c_lower_wick_pct >= 0.35)
                )
                # Bắt buộc orig_ai_vote > -0.60 (hoặc đã được Dual-Brain/Exhaustion hạ phiếu hợp lệ), KHÔNG bị bẫy giả 1h/15m, và RSI thật sự đã hạ nhiệt
                _ai_popped_long_ok = bool(trap_ctx.get('ai_popped_by_macro_dual_brain')) or bool(trap_ctx.get('ai_popped_by_exhaustion_long'))
                _ai_blocks_weak_bounce = (orig_ai_vote <= -0.70 and not _ai_popped_long_ok and c_recent_dump < min_climax_wave and not is_panic_selling_climax)
                has_valid_dump = (c_recent_dump >= min_climax_wave or is_panic_selling_climax)
                can_bounce_buy = (
                    (not is_tradfi_bell_blocked)
                    and (not is_fake_bear_dump)
                    and (current_rsi <= 50.0)
                    and (c_upper_wick_pct < 0.25)
                    and (not is_jev_downtrend_shield_active)
                    and (not _ai_blocks_weak_bounce)
                    and ((orig_ai_vote > -0.60 or _ai_popped_long_ok) and ai_vote_agg > -0.60)
                    and (has_super_climax_buy or (jev_vote_agg >= 0.0 and ai_vote_agg >= -0.60))
                    and has_valid_dump
                    and c_lower_wick_pct >= (0.40 if is_crypto_altcoin else 0.35)
                )

                _has_primary_trend_long_4443 = (
                    original_signal == Signal.BUY
                    and any(votes.get(k, (0.0, 0.0))[0] > 0 for k in ('trend_following', 'momentum_breakout'))
                    and ((ai_vote_agg > 0.0 or _ai_popped_long_ok) and jev_vote_agg >= 0.0)
                )
                if can_bounce_buy:
                    if is_extreme_bear_storm:
                        logger.warning(
                            "🛡️ [EXTREME BEAR STORM VETO] Hủy mở lệnh BUY %s: Bão Volume xả cực đại (RVol=%.2fx >= %.1fx) "
                            "kèm râu dưới chưa đủ gom hàng (Râu=%.1f%% < 55%%)! Cá mập đang xả tháo cống cực đoan, tuyệt đối cấm bắt dao rơi.",
                            symbol, c_vol_ratio, extreme_storm_rvol, c_lower_wick_pct * 100
                        )
                        self._record_veto(symbol, 'EXTREME_BEAR_STORM_VETO', 'LONG', f'RVol={c_vol_ratio:.2f}x, LW={c_lower_wick_pct*100:.1f}%')
                        return None
                    # [BOM #147 P0-1 FIX]: Khi kèo gốc ĐÃ LÀ 4 trụ thuận xu hướng BUY (Trend/BO + AI + JEV) có kèm BEAR_TRAP_WICK phụ,
                    # KHÔNG để Pha 3 gắn type=BEAR_TRAP_WICK đẩy vào VK3 (PAUSED) gây giết oan lệnh thuận xu hướng!
                    _raw_trap_types_4148 = [
                        str((getattr(s, 'metadata', None) or {}).get('type') or '').upper()
                        for s in (signals or [])
                    ]
                    _has_raw_selling_climax = any('SELLING_CLIMAX' in _t for _t in _raw_trap_types_4148)
                    _has_raw_bear_trap = any('BEAR_TRAP' in _t for _t in _raw_trap_types_4148)
                    _orig_t_4148 = str(final_signal.metadata.get('type') or '').upper()
                    _would_be_bear_trap_vk3 = (
                        'BEAR_TRAP' in _orig_t_4148
                        or (_has_raw_bear_trap and not _has_raw_selling_climax and not is_panic_selling_climax)
                    )
                    # [BOM #147 P0-1 + BOM #149 P1-7 FIX]: Bảo toàn kèo BUY 4 trụ thuận xu hướng (Trend/BO + AI + JEV)
                    # khỏi bị cướp sang VK3 (PAUSED) HOẶC bị ép sang VK4 rồi giết oan bởi VK4_UPPER_REJECT_WICK (UW >= 25%)!
                    _would_die_in_vk4_wick = (not _has_raw_selling_climax and not is_panic_selling_climax and c_upper_wick_pct >= 0.25)
                    if _has_primary_trend_long_4443 and (_would_be_bear_trap_vk3 or _would_die_in_vk4_wick):
                        _trend_fallthrough_climax_check = True
                        logger.info(
                            "🛡️ [BOM #147/149 ANTI-HIJACK LONG] %s: Bảo toàn lệnh BUY thuận xu hướng đa trụ (Trend/BO + AI + JEV), không cho cướp sang VK3/VK4!",
                            symbol,
                        )
                    else:
                        final_signal.signal = Signal.BUY
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        final_signal.metadata['is_oversold_bounce'] = True
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        # [BOM #103N + BOM #110B FIX]: Bảo toàn 'BEAR_TRAP_WICK' (VK3) VÀ 'SELLING_CLIMAX' (VK4) từ raw signals!
                        if _would_be_bear_trap_vk3:
                            final_signal.metadata['type'] = 'BEAR_TRAP_WICK'
                        elif 'SELLING_CLIMAX' in _orig_t_4148 or (_has_raw_selling_climax and not is_panic_selling_climax):
                            final_signal.metadata['type'] = 'SELLING_CLIMAX'
                        else:
                            # [BOM #148 P0-1 FIX]: Khi TrapDetector KHÔNG phát BEAR_TRAP, TUYỆT ĐỐI không tự chế 'BEAR_TRAP_WICK'
                            # (tránh đẩy nhầm kèo Trend/Oversold Bounce hợp lệ sang VK3 PAUSED và bị giết oan tại WEAPON_PAUSED_LIFECYCLE)!
                            final_signal.metadata['type'] = 'PANIC_CLIMAX_BOUNCE' if is_panic_selling_climax else ('SELLING_CLIMAX' if (c_lower_wick_pct >= 0.45 and current_rsi <= 45.0) else 'OVERSOLD_BOUNCE')
                        final_signal.metadata['target_tp_pct'] = 0.025
                        final_signal.metadata['be_trigger_pct'] = 0.0085
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                        final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                        logger.info(
                            "💎 [OVERSOLD BOUNCE LONG: BẮT ĐÁY RÚT CHÂN] %s: Nến kiệt sức bán rút chân gom hàng "
                            "(Râu dưới=%.1f%%, RVol=%.2fx, Dump=%.1f%%, PanicClimax=%s, BearTrap=%s)! Xác nhận LỆNH BUY ĐÓN NHỊP HỒI!",
                            symbol, c_lower_wick_pct * 100, c_vol_ratio, c_recent_dump * 100, is_panic_selling_climax, has_real_bear_trap
                        )
                else:
                    if is_tradfi_bell_blocked and original_signal == Signal.BUY:
                        logger.warning(
                            "🛡️ [OPENING BELL TRADFI VETO] Hủy mở lệnh BUY bắt đáy %s: Cấm bắt dao rơi cổ phiếu TradFi trong giờ mở phiên Mỹ (Rule 0.7 #3)!",
                            symbol
                        )
                        self._record_veto(symbol, 'OPENING_BELL_TRADFI_VETO', 'LONG', 'Cấm bắt dao rơi TradFi đầu phiên Mỹ')
                        return None
                    elif is_jev_downtrend_shield_active and original_signal == Signal.BUY:
                        _wick_note = (
                            f"Râu dưới={c_lower_wick_pct * 100:.1f}% < 35%"
                            if c_lower_wick_pct < 0.35
                            else f"Râu dưới={c_lower_wick_pct * 100:.1f}% nhưng chưa đủ điều kiện đảo chiều 4H"
                        )
                        logger.warning(
                            "🛡️ [JEV DOWNTREND SHIELD VETO] Hủy mở lệnh BUY bắt đáy %s: Khung lớn 4H dốc xuống (ADX=%.1f, JEV=%+.2f, %s)! Cấm đỡ dao rơi.",
                            symbol, macro_adx, orig_jev_vote, _wick_note
                        )
                        self._record_veto(symbol, 'JEV_DOWNTREND_SHIELD_VETO', 'LONG', f'ADX={macro_adx:.1f}, JEV={orig_jev_vote:+.2f}')
                        return None
                    elif _has_primary_trend_long_4443 and (not is_extreme_bear_storm) and (not is_fake_bear_dump):
                        # [BOM #147 P0-2 + BOM #150 P2 FIX]: Lệnh 4 trụ TrendFollowing/Breakout + AI + JEV BUY đi tiếp nhưng vẫn qua kiểm định ADX>=55/RSI>=68!
                        _trend_fallthrough_climax_check = True
                        logger.info(
                            "🛡️ [BOM #147 TREND HAMMER FALLTHROUGH] %s: Cho phép lệnh BUY thuận xu hướng đa trụ (Trend/BO + AI=%+.2f + JEV=%+.2f, RSI=%.1f) đi tiếp thay vì ép chuẩn bắt đáy!",
                            symbol, ai_vote_agg, jev_vote_agg, current_rsi,
                        )
                    elif original_signal == Signal.BUY:
                        _req_lw_pct = 40.0 if is_crypto_altcoin else 35.0
                        logger.warning(
                            "🛡️ [OVERSOLD BOUNCE VETO] Hủy mở lệnh BUY %s: Không đạt chuẩn bắt đáy "
                            "(AI=%+.2f, RSI=%.1f [cần <= 48], L_Wick=%.1f%% [cần >= %.0f%%], Dump=%.2f%%, JEV=%+.2f)!",
                            symbol, ai_vote_agg, current_rsi, c_lower_wick_pct * 100, _req_lw_pct, c_recent_dump * 100, orig_jev_vote
                        )
                        self._record_veto(symbol, 'OVERSOLD_BOUNCE_VETO', 'LONG', f'AI={ai_vote_agg:+.2f}, RSI={current_rsi:.1f}, LW={c_lower_wick_pct*100:.1f}%')
                        return None
                    else:
                        req_wick_pct = 25 if (is_panic_selling_climax and c_recent_dump >= parabolic_ext) else 30
                        logger.warning(
                            "🛡️ [SELLING CLIMAX SHORT VETO] Hủy mở lệnh SELL %s: Nến có râu dưới gom hàng (Râu dưới=%.1f%% >= %d%%, RVol=%.2fx), cấm Short đu đáy râu!",
                            symbol, c_lower_wick_pct * 100, req_wick_pct, c_vol_ratio
                        )
                        self._record_veto(symbol, 'SELLING_CLIMAX_SHORT_VETO', 'SHORT', f'LW={c_lower_wick_pct*100:.1f}%>={req_wick_pct}%, RVol={c_vol_ratio:.2f}x')
                        return None
    
                # 5. BỘ LỌC BẢO VỆ CỰC HẠN ĐỐI XỨNG 2 CHIỀU CHO CÁC LỆNH XU HƯỚNG BÌNH THƯỜNG:
    
            elif original_signal == Signal.BUY and (not is_tradfi):
                if is_crypto_altcoin and macro_adx >= 55.0:
                    climax_reason = f"Altcoin bơm xả cực hạn (ADX={macro_adx:.1f})"
                    logger.warning(
                        "🛡️ [BUYING CLIMAX VETO] Hủy lệnh BUY %s: %s! Cấm đu đỉnh mua đuổi.",
                        symbol, climax_reason
                    )
                    return None
                elif current_rsi >= 68.0 and not has_bear_trap_wick:
                    logger.warning(
                        "🛡️ [OVERBOUGHT BUY VETO] Hủy lệnh BUY %s: RSI 15m quá mua (RSI=%.1f >= 68.0) và thiếu Bear Trap! Cấm đu đỉnh mua đuổi.",
                        symbol, current_rsi,
                    )
                    return None
            elif original_signal == Signal.SELL and (not is_tradfi):
                if is_crypto_altcoin and macro_adx >= 55.0:
                    climax_reason = f"Altcoin xả cực hạn (ADX={macro_adx:.1f})"
                    logger.warning(
                        "🛡️ [SELLING CLIMAX VETO] Hủy lệnh SELL %s: %s! Cấm bán đuổi đáy.",
                        symbol, climax_reason
                    )
                    return None
                elif current_rsi <= 32.0 and not has_bull_trap_wick:
                    logger.warning(
                        "🛡️ [OVERSOLD SELL VETO] Hủy lệnh SELL %s: RSI 15m quá bán (RSI=%.1f <= 32.0) và thiếu Bull Trap! Cấm bán tháo đáy nến.",
                        symbol, current_rsi,
                    )
                    return None

            # [BOM #150 P2 FIX]: Áp dụng kiểm định cực hạn ADX >= 55 / RSI cho cả 4 nhánh Trend Fallthrough để không lách qua Branch 5!
            if _trend_fallthrough_climax_check and (not is_tradfi):
                if final_signal.signal == Signal.BUY:
                    if is_crypto_altcoin and macro_adx >= 55.0:
                        logger.warning("🛡️ [BUYING CLIMAX VETO - FALLTHROUGH] Hủy lệnh BUY %s: Altcoin bơm xả cực hạn (ADX=%.1f)!", symbol, macro_adx)
                        self._record_veto(symbol, 'BUYING_CLIMAX_VETO', 'LONG', f'Fallthrough ADX={macro_adx:.1f}>=55')
                        return None
                    if current_rsi >= 68.0 and not has_bear_trap_wick:
                        logger.warning("🛡️ [OVERBOUGHT BUY VETO - FALLTHROUGH] Hủy lệnh BUY %s: RSI 15m quá mua (RSI=%.1f >= 68.0)!", symbol, current_rsi)
                        self._record_veto(symbol, 'OVERBOUGHT_BUY_VETO', 'LONG', f'Fallthrough RSI={current_rsi:.1f}>=68')
                        return None
                elif final_signal.signal == Signal.SELL:
                    if is_crypto_altcoin and macro_adx >= 55.0:
                        logger.warning("🛡️ [SELLING CLIMAX VETO - FALLTHROUGH] Hủy lệnh SELL %s: Altcoin xả cực hạn (ADX=%.1f)!", symbol, macro_adx)
                        self._record_veto(symbol, 'SELLING_CLIMAX_VETO', 'SHORT', f'Fallthrough ADX={macro_adx:.1f}>=55')
                        return None
                    if current_rsi <= 32.0 and not has_bull_trap_wick:
                        logger.warning("🛡️ [OVERSOLD SELL VETO - FALLTHROUGH] Hủy lệnh SELL %s: RSI 15m quá bán (RSI=%.1f <= 32.0)!", symbol, current_rsi)
                        self._record_veto(symbol, 'OVERSOLD_SELL_VETO', 'SHORT', f'Fallthrough RSI={current_rsi:.1f}<=32')
                        return None

            # --- MTF TREND FILTER (Cấm lướt sóng ngược bão dựa trên HƯỚNG TÁC CHIẾN THỰC TẾ) ---

            regime = str(market_analysis.get('regime', 'ranging')).lower()

            ema = str(market_analysis.get('ema_alignment', '')).lower()

            is_downtrend = 'downtrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bearish')

            is_uptrend = 'uptrend' in regime or (regime not in ('high_volatility', 'ranging') and ema == 'bullish')

            # [BÀI HỌC 95, 97 & KB5 UNIFIED MATRIX - PHÂN NHÓM ĐI THEO / LẬT NGƯỢC / ĐỨNG IM]:
            ai_sig_mtf = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('ai_ensemble', 'aiensemble')), None)
            ai_conf_mtf = float(getattr(ai_sig_mtf, 'confidence', 0.0) or 0.0) if ai_sig_mtf else 0.0
            ai_dir_mtf = getattr(ai_sig_mtf, 'signal', None)

            jev_sig_mtf = next((s for s in signals if getattr(s, 'strategy', '').lower() in ('jev_agent', 'jevagent')), None)
            jev_conf_mtf = float(getattr(jev_sig_mtf, 'confidence', 0.0) or 0.0) if jev_sig_mtf else 0.0
            jev_dir_mtf = getattr(jev_sig_mtf, 'signal', None)
            is_jev_strong_buy = (jev_dir_mtf in (Signal.BUY, 'BUY', 'buy') and jev_conf_mtf >= 0.70)
            is_jev_strong_sell = (jev_dir_mtf in (Signal.SELL, 'SELL', 'sell') and jev_conf_mtf >= 0.70)

            # [BAO VE TUONG QUAN VI MO BTC & TRADFI - 4 GOC DOI XUNG 100% (BOM #51 FIX: TRIỆT TIÊU DEADLOCK 2 CHIỀU)]:
            btc_ctx = (market_chop_context or {}).get('BTC') or {}
            btc_recent_pump = float(btc_ctx.get('recent_pump', 0.0) or 0.0)
            btc_recent_dump = float(btc_ctx.get('recent_dump', 0.0) or 0.0)
            btc_vol_ratio = float(1.0 if btc_ctx.get('vol_ratio') is None else btc_ctx.get('vol_ratio'))
            btc_is_bull_c = bool(btc_ctx.get('is_bullish_candle', btc_recent_pump > btc_recent_dump))
            btc_is_bear_c = bool(btc_ctx.get('is_bearish_candle', btc_recent_dump > btc_recent_pump))
            btc_macro_down = bool(btc_ctx.get('is_strong_downtrend')) or (bool(btc_ctx.get('is_downtrend')) and float(btc_ctx.get('adx', 0.0) or 0.0) >= 28.0)
            btc_macro_up = bool(btc_ctx.get('is_strong_uptrend')) or (bool(btc_ctx.get('is_uptrend')) and float(btc_ctx.get('adx', 0.0) or 0.0) >= 28.0)
            btc_imp_dump = (btc_recent_dump >= 0.005 and btc_vol_ratio >= 1.30 and btc_recent_dump >= btc_recent_pump and not btc_is_bull_c)
            btc_imp_pump = (btc_recent_pump >= 0.005 and btc_vol_ratio >= 1.30 and btc_recent_pump >= btc_recent_dump and not btc_is_bear_c)
            # Tuyệt đối loại trừ lẫn nhau: không bao giờ để btc_is_dumping và btc_is_pumping cùng True!
            # [V6.1 BOM #79 FIX]: Phân biệt BTC 1H downtrend đang xả thật vs BTC 15M đã ngừng rơi (Dump15m < 0.15% + nến xanh hồi >= +0.30%)
            if btc_macro_down and not btc_macro_up:
                if btc_recent_pump >= 0.015 and btc_vol_ratio >= 1.50 and btc_is_bull_c and btc_recent_pump >= 2.0 * max(0.001, btc_recent_dump):
                    btc_is_dumping, btc_is_pumping = False, True
                elif btc_recent_dump < 0.0015 and btc_is_bull_c and btc_recent_pump >= 0.003:
                    btc_is_dumping, btc_is_pumping = False, False
                else:
                    btc_is_dumping, btc_is_pumping = True, False
            elif btc_macro_up and not btc_macro_down:
                if btc_recent_dump >= 0.015 and btc_vol_ratio >= 1.50 and btc_is_bear_c and btc_recent_dump >= 2.0 * max(0.001, btc_recent_pump):
                    btc_is_dumping, btc_is_pumping = True, False
                elif btc_recent_pump < 0.0015 and btc_is_bear_c and btc_recent_dump >= 0.003:
                    btc_is_dumping, btc_is_pumping = False, False
                else:
                    btc_is_dumping, btc_is_pumping = False, True
            else:
                btc_is_dumping = btc_imp_dump
                btc_is_pumping = btc_imp_pump and not btc_imp_dump
            is_crypto_market = not is_tradfi

            # [KB5 NHÓM ĐỨNG IM V3 - ALTCOIN SIDEWAY CHOP FILTER (ADX < 25) ĐỐI XỨNG 2 CHIỀU]:
            # Miễn trừ khi có bão Volume (RVol >= 3.0x), Waterfall Short, Momentum Ride Buy, Exhaustion Fading Short / Oversold Bounce, Vũ Khí Động, hoặc đi thuận nhịp dẫn sóng tức thời của BTC!
            if is_crypto_altcoin and 0.0 < macro_adx < 25.0 and not (
                c_vol_ratio >= 3.0
                or is_waterfall_dump
                or is_whale_pump_storm
                or bool(final_signal.metadata.get('is_waterfall_short'))
                or bool(final_signal.metadata.get('is_momentum_ride'))
                or bool(final_signal.metadata.get('is_fading_short'))
                or (bool(final_signal.metadata.get('is_oversold_bounce')) and macro_adx >= 20.0)
                or bool(final_signal.metadata.get('is_vk9_climax_wick_short'))
                or bool(final_signal.metadata.get('is_dynamic_weapon'))
                or (final_signal.signal == Signal.SELL and btc_is_dumping and c_vol_ratio >= 1.35)
                or (final_signal.signal == Signal.BUY and btc_is_pumping and c_vol_ratio >= 1.35)
            ):
                logger.warning(
                    f"🛡️ [KB5 CHOP STAND-ASIDE VETO (V3)] Hủy mở lệnh {final_signal.signal.value.upper()} {symbol}: "
                    f"Thị trường Altcoin đi ngang thiếu xung lượng (ADX={macro_adx:.1f} < 25.0, RVol={c_vol_ratio:.2f}x)! Đứng ngoài bảo toàn vốn."
                )
                self._record_veto(symbol, 'KB5_CHOP_STAND_ASIDE_VETO', 'LONG' if final_signal.signal == Signal.BUY else 'SHORT', f'ADX={macro_adx:.1f}<25')
                return None

            # 1. GÓC 1: CẤM LONG CRYPTO (ALTCOIN + MAJOR NGOÀI BTC) KHI BTC ĐANG SẬP MẠNH (ĐỐI XỨNG 100% VỚI GÓC 2)
            clean_sym_base_btc = symbol.split('/')[0].split('USDT')[0].split(':')[0].strip().upper()
            is_non_btc_crypto = is_crypto_market and clean_sym_base_btc != 'BTC'
            if is_non_btc_crypto and final_signal.signal == Signal.BUY and btc_is_dumping:
                is_standalone_whale_pump = (is_whale_pump_storm or bool(final_signal.metadata.get('is_momentum_ride'))) and c_vol_ratio >= wp_rvol_std
                is_extreme_climax_bounce = (c_lower_wick_pct >= 0.35 or is_selling_climax_candle) and c_vol_ratio >= wp_rvol_std and has_real_bear_trap
                is_dyn_reversal_buy_152 = bool(final_signal.metadata.get('is_dynamic_weapon')) and str(final_signal.metadata.get('weapon_code') or '').upper() in ('VK11', 'VK14', 'VK15')
                if not (is_standalone_whale_pump or is_extreme_climax_bounce or is_dyn_reversal_buy_152):
                    logger.warning(
                        f"🛡️ [BTC MACRO DOWNTREND VETO] Hủy mở lệnh BUY {symbol}: "
                        f"BTC khung 1H giảm mạnh ({btc_ctx.get('regime', 'downtrend')}, ADX={float(btc_ctx.get('adx') or 0.0):.1f}, Dump15m={btc_recent_dump*100:.2f}%)! "
                        f"Cấm mở Long Crypto cản tàu dòng tiền vĩ mô (cần râu gom đáy >= 35% + RVol >= {wp_rvol_std:.2f}x hoặc bão bơm RVol >= {wp_rvol_std:.2f}x)."
                    )
                    self._record_veto(symbol, 'BTC_MACRO_DOWNTREND_VETO', 'LONG', 'BTC khung 1H giảm mạnh', str(final_signal.metadata.get('weapon_id') or ''))
                    return None

            # 2. GÓC 2: CẤM SHORT CRYPTO (ALTCOIN + MAJOR NGOÀI BTC) KHI BTC ĐANG BƠM MẠNH (SHORT SQUEEZE SHIELD)
            if is_non_btc_crypto and final_signal.signal == Signal.SELL and btc_is_pumping:
                is_extreme_exhaustion_short = (c_upper_wick_pct >= 0.35 or is_buying_climax_candle) and c_vol_ratio >= wp_rvol_std
                is_standalone_waterfall_dump = (is_waterfall_dump or bool(final_signal.metadata.get('is_waterfall_short'))) and c_vol_ratio >= wf_rvol_std
                if not (is_extreme_exhaustion_short or is_standalone_waterfall_dump):
                    logger.warning(
                        f"🛡️ [BTC MACRO UPTREND VETO] Hủy mở lệnh SHORT {symbol}: "
                        f"Vua thị trường BTC đang bơm mạnh ({btc_ctx.get('regime', 'uptrend')}, ADX={float(btc_ctx.get('adx') or 0.0):.1f}, Pump={btc_recent_pump*100:.2f}%)! "
                        f"Cấm mở Short cản tàu dòng tiền vĩ mô tránh bão Short Squeeze (cần râu xả đỉnh >= 35% + RVol >= {wp_rvol_std:.2f}x hoặc thác đổ riêng lẻ RVol >= {wf_rvol_std:.2f}x)."
                    )
                    self._record_veto(symbol, 'BTC_MACRO_UPTREND_VETO', 'SHORT', 'BTC đang bơm mạnh', str(final_signal.metadata.get('weapon_id') or ''))
                    return None

            # 3. GÓC 3 & 4: ĐỒNG BỘ TRADFI PRE-ENTRY TƯƠNG QUAN 4 GÓC ĐỐI XỨNG (LONG & SHORT)
            if is_tradfi:
                # [KB10 - TRADFI DEAD ZONE GATE]: Giờ đóng cửa Phố Wall (16:00 - 04:00 ET) thanh khoản cạn kiệt
                if is_stock:
                    is_dead_zone = False
                    try:
                        from ai.market_regime import MarketRegimeDetector
                        is_dead_zone = MarketRegimeDetector.is_tradfi_dead_zone()
                    except Exception:
                        pass
                    if is_dead_zone and c_vol_ratio < 0.50:
                        logger.warning(
                            f"🛡️ [TRADFI DEAD ZONE VETO] Hủy mở lệnh {final_signal.signal.value} {symbol}: "
                            f"Cổ phiếu Mỹ rơi vào giờ đóng cửa Phố Wall (16:00 - 04:00 ET) "
                            f"với RVol={c_vol_ratio:.2f}x < 0.50x! Cấm vào lệnh để tránh trôi giá và dính bẫy thanh khoản."
                        )
                        return None

                # [KB10 - TRADFI OPENING BELL GATE & 2-WAY SMART INVERSION (RULE 0.7 #3) + BOM #132/#135 FIX]: 09:30 - 10:30 ET (miễn ghi đè Vũ khí Động đã qua DNA)
                if is_stock and is_opening_bell and not dyn_vk_unlocked:
                    if final_signal.signal == Signal.BUY and c_recent_dump >= 0.010 and c_recent_dump > c_recent_pump:
                        if c_vol_ratio >= 1.80 and c_lower_wick_pct < 0.30 and orig_jev_vote <= 0.0 and current_rsi > 32.0:
                            final_signal.signal = Signal.SELL
                            final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                            self._clear_stale_weapon_metadata(final_signal)
                            final_signal.metadata['is_fading_short'] = False
                            final_signal.metadata['is_waterfall_short'] = True
                            final_signal.metadata['is_oversold_bounce'] = False
                            final_signal.metadata['is_momentum_ride'] = False
                            final_signal.metadata['type'] = 'OPENING_BELL_WATERFALL_INVERSION_SHORT'
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.0085
                            final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                            final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                            logger.info(
                                f"🔄 [OPENING BELL SMART INVERSION -> SHORT] {symbol}: "
                                f"Phố Wall mở phiên xả bão Volume (Dump={c_recent_dump*100:.2f}%, RVol={c_vol_ratio:.2f}x >= 1.8x, Râu dưới={c_lower_wick_pct*100:.1f}% < 30%)! "
                                f"Lật ngược BUY bắt dao rơi thành SHORT thuận cá mập Wall Street!"
                            )
                        else:
                            logger.warning(
                                f"🛡️ [OPENING BELL KNIFE-CATCHING VETO] Hủy mở lệnh BUY {symbol}: "
                                f"Trong 60m đầu phiên Mỹ đang có nhịp xả hoảng loạn (Dump={c_recent_dump*100:.2f}% >= 1.0%)! "
                                f"Cấm mua bắt dao rơi trong giờ rung lắc mở phiên Wall Street."
                            )
                            return None
                    # [BOM #134 FIX]: Đối xứng 100% với nhánh BUY (L4599) — bắt buộc c_recent_pump >= 0.010 & c_recent_pump > c_recent_dump
                    # để KHÔNG tự sát 100% lệnh SHORT mở phiên Mỹ (is_tradfi_opening_dump) có nến đỏ đặc RVol >= 1.8x, U_Wick < 30%!
                    elif final_signal.signal == Signal.SELL and c_recent_pump >= 0.010 and c_recent_pump > c_recent_dump and c_vol_ratio >= 1.80 and c_upper_wick_pct < 0.30:
                        if orig_jev_vote >= 0.0 and current_rsi < 78.0:
                            final_signal.signal = Signal.BUY
                            final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                            self._clear_stale_weapon_metadata(final_signal)
                            final_signal.metadata['is_fading_short'] = False
                            final_signal.metadata['is_waterfall_short'] = False
                            final_signal.metadata['is_momentum_ride'] = True
                            final_signal.metadata['type'] = 'OPENING_BELL_MOMENTUM_INVERSION_BUY'
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.0085
                            final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                            final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                            logger.info(
                                f"🔄 [OPENING BELL SMART INVERSION -> BUY] {symbol}: "
                                f"Phố Wall mở phiên bơm bão Volume (Pump={c_recent_pump*100:.2f}%, RVol={c_vol_ratio:.2f}x >= 1.8x, Râu trên={c_upper_wick_pct*100:.1f}% < 30%)! "
                                f"Lật ngược SHORT cản tàu thành MOMENTUM RIDE BUY thuận cá mập Wall Street!"
                            )
                        else:
                            logger.warning(
                                f"🛡️ [OPENING BELL SHORT VETO] Hủy mở lệnh SHORT {symbol}: "
                                f"Trong 60m đầu phiên Mỹ đang có sóng bão Volume Wall Street (RVol={c_vol_ratio:.2f}x >= 1.8x, "
                                f"Râu trên={c_upper_wick_pct*100:.1f}% < 30%)! Cấm Short cản tàu cá mập mở phiên."
                            )
                            return None

                lead_sym = MarketScanner.get_lead_asset(symbol) if hasattr(MarketScanner, 'get_lead_asset') else None
                lead_base = MarketScanner._clean_base(lead_sym) if lead_sym else None
                lead_ctx = (market_chop_context or {}).get(lead_base) or {}
                # [BOM #148 P1-4 + BOM #149 P2 + BOM #150 P1 FIX]: Chỉ fallback sang BENCHMARK_LEADERS khi symbol CÓ lead_sym (không ép benchmark gốc tự fallback)
                # và loại trừ nhóm tự thẩm định UNCORRELATED_SELF_BENCHMARK_BASES (TMF/BOIL/YINN/NATGAS...) + Bear ETF tương ứng!
                _bm_uncorr_149 = set(getattr(MarketScanner, 'UNCORRELATED_SELF_BENCHMARK_BASES', ())) | {'TBT', 'KOLD', 'YANG'}
                _sym_canon_149 = MarketScanner._canonical_tradfi_base(symbol) if hasattr(MarketScanner, '_canonical_tradfi_base') else ''
                if not lead_ctx and lead_sym is not None and _sym_canon_149 not in _bm_uncorr_149 and hasattr(MarketScanner, 'get_tradfi_sector'):
                    _sec_148 = MarketScanner.get_tradfi_sector(symbol)
                    _sec_bm_148 = (getattr(MarketScanner, 'BENCHMARK_LEADERS', {}) or {}).get(_sec_148)
                    if _sec_bm_148 and MarketScanner._clean_base(_sec_bm_148) != _sym_canon_149:
                        _sec_bm_base = MarketScanner._clean_base(_sec_bm_148)
                        lead_ctx = (market_chop_context or {}).get(_sec_bm_base) or {}
                        if lead_ctx:
                            lead_sym = _sec_bm_148
                            lead_base = _sec_bm_base
                lead_is_uptrend = bool(lead_ctx.get('is_uptrend'))
                lead_is_strong_uptrend = bool(lead_ctx.get('is_strong_uptrend'))
                lead_adx = float(lead_ctx.get('adx') or 0.0)
                lead_is_downtrend = bool(lead_ctx.get('is_downtrend'))
                lead_is_strong_downtrend = bool(lead_ctx.get('is_strong_downtrend'))
                is_bear_etf_sym = hasattr(MarketScanner, 'is_bear_inverse_etf') and MarketScanner.is_bear_inverse_etf(symbol)

                # Góc 3A: Chặn mua Bear ETF (SOXS, SQQQ, SPXU, TZA, NVDD, TSLS, MSTZ) khi Benchmark ngành đang Uptrend (Rào chắn 3)
                # [BOM #125C FIX]: Không coi HIGH_VOLATILITY/RANGING (ADX>=25) là Uptrend/Downtrend đồng thời!
                if final_signal.signal == Signal.BUY and is_bear_etf_sym:
                    lead_bullish = bool(lead_is_uptrend or lead_is_strong_uptrend)
                    if not lead_ctx and is_downtrend and macro_adx >= 25.0:
                        lead_bullish = True
                    if lead_bullish:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [BEAR ETF TRAP VETO] Hủy mở BUY {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Uptrend (ADX={eff_adx:.1f})! Cấm mua Bear ETF bắt đáy."
                        )
                        return None

                # Góc 3B: Đối xứng - Chặn Short Bear ETF khi Benchmark ngành đang Downtrend mạnh
                if final_signal.signal == Signal.SELL and is_bear_etf_sym:
                    lead_bearish = bool(lead_is_downtrend or lead_is_strong_downtrend)
                    if not lead_ctx and is_uptrend and macro_adx >= 25.0:
                        lead_bearish = True
                    if lead_bearish and c_upper_wick_pct < 0.30:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [BEAR ETF SHORT VETO] Hủy mở SHORT {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Downtrend (ADX={eff_adx:.1f}) khiến Bear ETF tăng mạnh! Cấm Short cản tàu."
                        )
                        return None

                # Góc 4A: Chặn Short cổ phiếu / Bull ETF khi Benchmark ngành đang Uptrend mạnh (đối xứng 1-1 với Góc 4B!)
                if final_signal.signal == Signal.SELL and not is_bear_etf_sym:
                    bench_uptrend = (lead_is_uptrend and (lead_is_strong_uptrend or lead_adx >= 28.0)) if lead_ctx else (is_uptrend and macro_adx >= 28.0)
                    if bench_uptrend and c_upper_wick_pct < 0.30:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [TRADFI BENCHMARK PUMP VETO] Hủy mở SHORT {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Uptrend mạnh (ADX={eff_adx:.1f})! Cấm Short cản tàu."
                        )
                        return None

                # Góc 4B: Đối xứng - Chặn BUY cổ phiếu / Bull ETF khi Benchmark ngành đang Downtrend mạnh mà chưa có râu rút chân
                if final_signal.signal == Signal.BUY and not is_bear_etf_sym:
                    bench_downtrend = (lead_is_downtrend and (lead_is_strong_downtrend or lead_adx >= 28.0)) if lead_ctx else (is_downtrend and macro_adx >= 28.0)
                    if bench_downtrend and c_lower_wick_pct < 0.30:
                        eff_adx = lead_adx if lead_ctx else macro_adx
                        logger.warning(
                            f"🛡️ [TRADFI BENCHMARK DUMP VETO] Hủy mở BUY {symbol}: "
                            f"Benchmark ngành {lead_sym or 'dẫn dắt'} đang Downtrend mạnh (ADX={eff_adx:.1f}, Râu dưới={c_lower_wick_pct*100:.1f}% < 30%)! Cấm bắt dao rơi cổ phiếu ngược ngành."
                        )
                        return None

            # [BOM #131B + #132 FIX]: Chụp hướng lệnh ngay SAU tầng Opening Bell & TradFi Benchmark Shields và TRƯỚC KB10 2A-2B / KB5
            # để tránh lỗ hổng đảo chiều kép (Opening Bell BUY->SELL rồi KB5 SELL->BUY làm BUY != BUY == False lách POST-KB5)!
            _pre_kb5_signal_dir = final_signal.signal

            # [KB10 - ĐỐI XỨNG 2 CHIỀU KHIÊN CHỐNG CẢN TÀU & RÂU HẤP THỤ CHO 3 LỚP TÀI SẢN]:
            strong_impulse_th = 0.014 if is_crypto_altcoin else 0.010
            retrace_cap_th = 0.005 if is_crypto_altcoin else 0.0035
            wick_filter_move_th = 0.010 if is_crypto_altcoin else 0.007

            # 1A. Cấm Long khi nến có râu trên dập đầu xả ngược cực đại (LIT/USDT) — Miễn trừ Cụm Alpha #2 & Vũ khí Động SLOT_B2 / có uw_max riêng
            _is_dyn_slot_b2_long = bool(
                dyn_vk_unlocked
                and (
                    str(final_signal.metadata.get('dyn_slot') or '') == 'SLOT_B2'
                    or 'uw_max' in (final_signal.metadata.get('dyn_dna_rules') or {})
                )
            )
            if final_signal.signal == Signal.BUY and c_upper_wick_pct >= 0.60 and not c2_slot_b2_unlocked and not _is_dyn_slot_b2_long:
                logger.warning(
                    f"🛡️ [LONG KNIFE-CATCHING VETO] Hủy mở lệnh BUY {symbol}: "
                    f"Nến có râu trên xả ngược cực đại (UpperWick={c_upper_wick_pct*100:.1f}% >= 60.0%)! "
                    f"Phe bán đang đè xả dập đầu, cấm mua bắt đáy nến rụt cổ."
                )
                return None

            # 1B. Đối xứng: Cấm Short khi nến có râu dưới rút chân gom hàng cực đại (>= 60%) — Chỉ miễn trừ Vũ khí Động SHORT ở SLOT_B2 hoặc có lw_max riêng
            _dyn_side_lw = str((dyn_vk_matched or {}).get('_resolved_side') or (dyn_vk_matched or {}).get('side') or '').upper() if dyn_vk_unlocked else ''
            _is_dyn_short_lw_ok = bool(
                dyn_vk_unlocked
                and _dyn_side_lw == 'SHORT'
                and (
                    str(final_signal.metadata.get('dyn_slot') or '') == 'SLOT_B2'
                    or 'lw_max' in (final_signal.metadata.get('dyn_dna_rules') or {})
                )
            )
            if final_signal.signal == Signal.SELL and c_lower_wick_pct >= 0.60 and not _is_dyn_short_lw_ok:
                logger.warning(
                    f"🛡️ [SHORT SQUEEZE WICK VETO] Hủy mở lệnh SHORT {symbol}: "
                    f"Nến có râu dưới rút chân gom hàng cực đại (LowerWick={c_lower_wick_pct*100:.1f}% >= 60.0%)! "
                    f"Phe mua đang đỡ giá quyết liệt, cấm Short đuổi đáy râu."
                )
                return None

            # 2A. [KB10 - SHORT STRONG PUMP SHIELD & SMART INVERSION PHA 1]: Cấm Short khi coin đang bơm dốc đứng (INJ, HYPE)
            # [BOM #113C FIX]: Vũ khí Động đã qua EXTREME BULL STORM VETO riêng tại L3877 -> không cho lật ngược mất weapon_id!
            if final_signal.signal == Signal.SELL and not is_live_dumping and not bool(final_signal.metadata.get('is_dynamic_weapon')) and c_recent_pump >= strong_impulse_th and c_recent_dump < retrace_cap_th and c_upper_wick_pct < 0.30:
                if not (is_waterfall_dump or bool(final_signal.metadata.get('is_waterfall_short'))):
                    _kb10_pump_rsi_cap = 71.0 if is_crypto_altcoin else 75.0
                    can_smart_inversion_pump = (c_vol_ratio >= wp_rvol_std and c_upper_wick_pct < 0.25 and orig_jev_vote >= 0.0 and current_rsi < _kb10_pump_rsi_cap)
                    if can_smart_inversion_pump:
                        final_signal.signal = Signal.BUY
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        # [BOM #103E + #116D FIX]: Xoa sach nhan vu khi dong/cu khi lat chieu sang Momentum Ride BUY
                        self._clear_stale_weapon_metadata(final_signal)
                        final_signal.metadata['is_fading_short'] = False
                        final_signal.metadata['is_momentum_ride'] = True
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        final_signal.metadata['type'] = 'MOMENTUM_RIDE_INVERSION_PUMP_STORM'
                        final_signal.metadata['target_tp_pct'] = 0.025
                        final_signal.metadata['be_trigger_pct'] = 0.0085
                        final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                        final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        logger.info(
                            f"🔄 [KB10 SMART INVERSION: LẬT NGƯỢC PUMP SHORT -> MOMENTUM RIDE BUY] {symbol}: "
                            f"Phát hiện bão Volume cá mập (RVol={c_vol_ratio:.2f}x >= {wp_rvol_std:.2f}x, Pump={c_recent_pump*100:.2f}%, Râu trên={c_upper_wick_pct*100:.1f}% < 25%)! "
                            f"Lật ngược Short thành LỆNH BUY thuận cá mập!"
                        )
                    else:
                        logger.warning(
                            f"🛡️ [SHORT STRONG PUMP VETO] Hủy mở lệnh SHORT {symbol}: "
                            f"Coin đang có xung lượng bơm bão (Pump={c_recent_pump*100:.2f}% >= {strong_impulse_th*100:.2f}%, Dump={c_recent_dump*100:.2f}% < {retrace_cap_th*100:.2f}%, "
                            f"Râu trên={c_upper_wick_pct*100:.1f}% < 30%)! Cấm Short cản tàu khi chưa có râu xả đỉnh."
                        )
                        return None

            # 2B. Đối xứng: [KB10 - LONG STRONG DUMP SHIELD & SMART INVERSION WATERFALL SHORT]: Cấm Long khi coin đang xả dốc đứng
            if final_signal.signal == Signal.BUY and not is_live_rebounding and not bool(final_signal.metadata.get('is_dynamic_weapon')) and c_recent_dump >= strong_impulse_th and c_recent_pump < retrace_cap_th and c_lower_wick_pct < 0.30:
                if not (is_whale_pump_storm or bool(final_signal.metadata.get('is_momentum_ride'))):
                    can_smart_inversion_dump = (c_vol_ratio >= wf_rvol_std and c_lower_wick_pct < 0.25 and orig_jev_vote <= 0.0 and current_rsi > 32.0 and macro_rsi > 30.0)
                    if can_smart_inversion_dump:
                        final_signal.signal = Signal.SELL
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        # [BOM #103E + #116D FIX]: Xoa sach nhan vu khi dong/VK2/VK10 cu khi lat chieu sang Waterfall SHORT
                        self._clear_stale_weapon_metadata(final_signal)
                        final_signal.metadata['is_fading_short'] = False
                        final_signal.metadata['is_waterfall_short'] = True
                        final_signal.metadata['is_oversold_bounce'] = False
                        final_signal.metadata['is_momentum_ride'] = False
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        final_signal.metadata['type'] = 'WATERFALL_INVERSION_DUMP_STORM'
                        final_signal.metadata['target_tp_pct'] = 0.025
                        final_signal.metadata['be_trigger_pct'] = 0.0085
                        final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                        final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        logger.info(
                            f"🔄 [KB10 SMART INVERSION: LẬT NGƯỢC DUMP BUY -> WATERFALL SHORT] {symbol}: "
                            f"Phát hiện thác đổ cá mập (RVol={c_vol_ratio:.2f}x >= {wf_rvol_std:.2f}x, Dump={c_recent_dump*100:.2f}%, Râu dưới={c_lower_wick_pct*100:.1f}% < 25%)! "
                            f"Lật ngược Buy bắt dao rơi thành LỆNH SHORT thuận cá mập xả!"
                        )
                    else:
                        logger.warning(
                            f"🛡️ [LONG STRONG DUMP VETO] Hủy mở lệnh BUY {symbol}: "
                            f"Coin đang có xung lượng xả dốc (Dump={c_recent_dump*100:.2f}% >= {strong_impulse_th*100:.2f}%, Pump={c_recent_pump*100:.2f}% < {retrace_cap_th*100:.2f}%, "
                            f"Râu dưới={c_lower_wick_pct*100:.1f}% < 30%)! Cấm Buy bắt dao rơi khi chưa có râu rút chân."
                        )
                        return None

            # 3A. [KB10 - SHORT ABSORPTION WICK SHIELD]: Cấm Short khi có râu gom hàng đáy và volume thấp (BERA/USDT)
            # Nến rút chân gom hàng đáy (c_lower_wick_pct >= 0.30) hình thành sau nhịp giá giảm (dump), điều kiện sóng phải là c_recent_dump (hoặc max pump/dump).
            eff_dump_for_wick = max(c_recent_dump, c_recent_pump)
            if final_signal.signal == Signal.SELL and c_lower_wick_pct >= 0.30 and eff_dump_for_wick >= wick_filter_move_th and c_vol_ratio < min_climax_rvol and not dyn_vk_unlocked:
                logger.warning(
                    f"🛡️ [SHORT ABSORPTION WICK VETO] Hủy mở lệnh SHORT {symbol}: "
                    f"Nến xuất hiện râu dưới gom hàng (LowerWick={c_lower_wick_pct*100:.1f}% >= 30.0%, Dump/Move={eff_dump_for_wick*100:.2f}%) "
                    f"nhưng volume kiệt (RVol={c_vol_ratio:.2f}x < {min_climax_rvol:.2f}x)! Cấm Short vào bẫy gom hàng cá mập."
                )
                return None

            # 3B. Đối xứng: [KB10 - LONG DISTRIBUTION WICK SHIELD]: Cấm Buy khi có râu xả hàng đỉnh và volume thấp
            # Nến xả hàng đỉnh (c_upper_wick_pct >= 0.30) hình thành sau nhịp giá tăng (pump), điều kiện sóng phải là c_recent_pump (hoặc max pump/dump).
            eff_pump_for_wick = max(c_recent_pump, c_recent_dump)
            if final_signal.signal == Signal.BUY and c_upper_wick_pct >= 0.30 and eff_pump_for_wick >= wick_filter_move_th and c_vol_ratio < min_climax_rvol and not c2_slot_b2_unlocked and not dyn_vk_unlocked:
                logger.warning(
                    f"🛡️ [LONG DISTRIBUTION WICK VETO] Hủy mở lệnh BUY {symbol}: "
                    f"Nến xuất hiện râu trên phân phối đỉnh (UpperWick={c_upper_wick_pct*100:.1f}% >= 30.0%, Pump/Move={eff_pump_for_wick*100:.2f}%) "
                    f"nhưng volume kiệt (RVol={c_vol_ratio:.2f}x < {min_climax_rvol:.2f}x)! Cấm Buy vào bẫy xả hàng cạn cầu."
                )
                return None

            # [KB5 NHÓM LẬT NGƯỢC I2/I1 & ĐỨNG IM V2 + V1 ĐỐI XỨNG 2 CHIỀU TRÊN ALTCOIN & TRADFI]:
            # [BOM #131B FIX]: _pre_kb5_signal_dir đã được chụp TRƯỚC KB10 2A/2B tại cổng BTC Macro nên KHÔNG ghi đè lại tại đây!
            is_active_target_asset = is_crypto_altcoin or is_tradfi
            if is_active_target_asset and final_signal.signal == Signal.BUY:
                is_bottom_absorption_long = bool(final_signal.metadata.get('is_oversold_bounce')) or has_real_bear_trap or (mean_vote_agg > 0.0 and c_lower_wick_pct >= 0.28)
                is_clean_whale_ride = bool(final_signal.metadata.get('is_momentum_ride'))

                # [BOM #150 P1 FIX]: Không hồi sinh phiếu AI SELL đã bị Dual-Brain loại bỏ!
                _ai_active_kb5_buy = ('ai_ensemble' in votes) and not bool(trap_ctx.get('ai_popped_by_macro_dual_brain'))
                ai_truly_selling = _ai_active_kb5_buy and ((ai_dir_mtf in (Signal.SELL, 'SELL', 'sell') and ai_conf_mtf >= 0.60) or (ai_vote_agg <= -0.60) or (orig_ai_vote <= -0.60)) and not has_real_bear_trap and (ai_vote_agg <= -0.50 or orig_ai_vote <= -0.50)
                jev_truly_selling = ((jev_dir_mtf in (Signal.SELL, 'SELL', 'sell') and jev_conf_mtf >= 0.65) or (orig_jev_vote <= -0.65)) and orig_jev_vote <= -0.65

                # 1. CỤM MEAN REVERSION INVERSION (I_MR_BUY -> SHORT): Bắt bẫy dao rơi bám dải Bollinger sập (Band Walking)
                # [BOM #135 + BOM #150 P0 FIX]: Cấm chặn oan kèo Momentum Ride / Uptrend / TrendFollowing / Breakout BUY chỉ vì MeanReversion phụ báo BUY + ADX >= 25!
                if (
                    (not c2_slot_b2_unlocked)
                    and (not vk10_slot_b1_unlocked)
                    and (not dyn_vk_unlocked)
                    and (not is_clean_whale_ride)
                    and (not is_uptrend)
                    and trend_vote_agg <= 0.0
                    and breakout_vote_agg <= 0.0
                    and mean_vote_agg > 0.0
                    and (is_downtrend or (macro_adx >= 25.0 and c_recent_dump >= c_recent_pump) or c_recent_dump >= min_waterfall_dump)
                    and c_lower_wick_pct < 0.28
                ):
                    if (
                        (ai_truly_selling or orig_jev_vote <= -0.50)
                        and orig_ai_vote <= 0.0
                        and orig_jev_vote <= 0.0
                        and c_vol_ratio >= wf_rvol_std
                        and current_rsi > 32.0
                        and c_recent_dump <= max_wf_dump
                    ):
                        final_signal.signal = Signal.SELL
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        self._clear_stale_weapon_metadata(final_signal)
                        final_signal.metadata['is_fading_short'] = False
                        final_signal.metadata['is_waterfall_short'] = True
                        final_signal.metadata['is_momentum_ride'] = False
                        final_signal.metadata['is_oversold_bounce'] = False
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        final_signal.metadata['type'] = 'BAND_WALKING_RIDE_SHORT'
                        final_signal.metadata['target_tp_pct'] = 0.025
                        final_signal.metadata['be_trigger_pct'] = 0.0085
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                        final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                        logger.info(
                            f"🔄 [SMART INVERSION (MR): MEAN REVERSION -> BAND WALKING SHORT] {symbol}: "
                            f"Bắt bẫy dao rơi bám dải dưới (ADX={macro_adx:.1f}, Dump={c_recent_dump*100:.1f}%, Râu dưới={c_lower_wick_pct*100:.1f}% < 28%)! Lật sang SHORT thuận đà xả!"
                        )
                    else:
                        logger.warning(
                            f"🛡️ [MEAN REVERSION FALLING KNIFE VETO] Hủy mở lệnh BUY {symbol}: Bắt dao rơi dải dưới trong xu hướng giảm (ADX={macro_adx:.1f}, Dump={c_recent_dump*100:.1f}%)!"
                        )
                        self._record_veto(symbol, 'MEAN_REVERSION_FALLING_KNIFE_VETO', 'LONG', f'ADX={macro_adx:.1f}, Dump={c_recent_dump*100:.1f}%')
                        return None

                # 2. CỤM MOMENTUM BREAKOUT INVERSION (I_BRK_BUY -> SHORT): Bắt bẫy quét thanh khoản đỉnh (khớp ngưỡng VK6 DNA Shield BOM #101B + #126B + #131B + #140: sàn bơm KB10, RVol 3 lớp, U_Wick >= 45%, L_Wick < 25%, RSI 40..68)
                elif (not c2_slot_b2_unlocked) and (not vk10_slot_b1_unlocked) and (not dyn_vk_unlocked) and breakout_vote_agg > 0.0 and c_recent_pump >= min_climax_hard_pump and c_upper_wick_pct >= 0.45 and c_lower_wick_pct < 0.25 and (40.0 <= current_rsi <= 68.0) and c_vol_ratio >= min_climax_rvol and not is_jev_uptrend_shield_active and not is_extreme_bull_storm and orig_jev_vote < 0.70 and orig_ai_vote < 0.60 and ai_vote_agg < 0.60:
                    final_signal.signal = Signal.SELL
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    self._clear_stale_weapon_metadata(final_signal)
                    final_signal.metadata['is_fading_short'] = True
                    final_signal.metadata['is_waterfall_short'] = False
                    final_signal.metadata['is_momentum_ride'] = False
                    final_signal.metadata['is_oversold_bounce'] = False
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'LIQUIDITY_SWEEP_FADING_SHORT'
                    final_signal.metadata['target_tp_pct'] = 0.028
                    final_signal.metadata['be_trigger_pct'] = 0.0085
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                    final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                    logger.info(
                        f"⚡ [SMART INVERSION (BRK): BREAKOUT -> LIQUIDITY SWEEP SHORT] {symbol}: "
                        f"Phá cản bị xả dập đầu bẫy râu (UpperWick={c_upper_wick_pct*100:.1f}% >= 35%, RVol={c_vol_ratio:.2f}x)! Lật sang SHORT bắt đỉnh quét thanh khoản!"
                    )

                # 3. CỤM TREND FOLLOWING INVERSION (I_TF_BUY -> SHORT): Bắt đỉnh kiệt sức xu hướng bơm rướn (khớp ngưỡng VK6 DNA Shield + BOM #140 RVol 3 lớp)
                elif (not c2_slot_b2_unlocked) and (not vk10_slot_b1_unlocked) and (not dyn_vk_unlocked) and trend_vote_agg > 0.0 and c_upper_wick_pct >= 0.45 and c_lower_wick_pct < 0.25 and (40.0 <= current_rsi <= 68.0) and c_recent_pump >= min_climax_wave and c_vol_ratio >= min_climax_rvol and not is_jev_uptrend_shield_active and not is_extreme_bull_storm and orig_jev_vote < 0.70 and orig_ai_vote < 0.60 and ai_vote_agg < 0.60:
                    final_signal.signal = Signal.SELL
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    self._clear_stale_weapon_metadata(final_signal)
                    final_signal.metadata['is_fading_short'] = True
                    final_signal.metadata['is_waterfall_short'] = False
                    final_signal.metadata['is_momentum_ride'] = False
                    final_signal.metadata['is_oversold_bounce'] = False
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'TREND_EXHAUSTION_FADING_SHORT'
                    final_signal.metadata['target_tp_pct'] = 0.028
                    final_signal.metadata['be_trigger_pct'] = 0.0085
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                    final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                    logger.info(
                        f"⚡ [SMART INVERSION (TF): TREND FOLLOWING -> EXHAUSTION SHORT] {symbol}: "
                        f"Bơm rướn kiệt sức xu hướng dãn biên (UpperWick={c_upper_wick_pct*100:.1f}% >= 35%, Pump={c_recent_pump*100:.1f}%, RSI={current_rsi:.1f})! Lật sang SHORT bắt đỉnh!"
                    )

                # [BOM #145 HARD PURGE]: Đã xóa sổ nhánh legacy SMART_DOWNTREND_INVERSION_SHORT_I2 (thiếu lọc RVol/Dump/Storm) — rơi thẳng vào KB5 FALLING KNIFE VETO (V2)!
                elif (not c2_slot_b2_unlocked) and (not vk10_slot_b1_unlocked) and (not dyn_vk_unlocked) and is_downtrend and not is_clean_whale_ride and not is_bottom_absorption_long and (c_lower_wick_pct < 0.30 or ai_truly_selling or jev_truly_selling):
                    logger.warning(
                        f"🛡️ [KB5 FALLING KNIFE VETO (V2)] Hủy mở lệnh BUY {symbol}: Cấm bắt dao rơi Altcoin trong Downtrend khi thiếu râu đỡ hoặc AI/JEV báo SELL "
                        f"(Regime={regime.upper()}, LowerWick={c_lower_wick_pct*100:.1f}%, AI={orig_ai_vote:+.2f}, JEV={orig_jev_vote:+.2f})!"
                    )
                    return None
                else:
                    # [KB5 V1 - CHẶN MUA ĐUỔI ĐỈNH ALTCOIN THEO TRENDFOLLOWING EMA TRỄ PHA]:
                    is_valid_breakout_long = (breakout_vote_agg > 0.0 and c_vol_ratio >= 1.20 and c_upper_wick_pct < 0.30)
                    is_low_atr_aligned_uptrend = (0.0 < tactical_atr_15m_pct < 2.5 and is_uptrend and (ai_vote_agg > 0.0 or orig_ai_vote > 0.0) and orig_jev_vote > 0.0)
                    if (not c2_slot_b2_unlocked) and (not vk10_slot_b1_unlocked) and (not dyn_vk_unlocked) and (trend_vote_agg > 0.0 and tactical_atr_15m_pct >= 2.5 and current_rsi >= 62.0) and not (is_valid_breakout_long or is_clean_whale_ride or is_bottom_absorption_long or is_low_atr_aligned_uptrend):
                        logger.warning(
                            f"🛡️ [KB5 LAGGING EMA TOP-CHASE VETO (V1)] Hủy mở lệnh BUY {symbol}: "
                            f"Chặn mua đuổi đỉnh Altcoin biến động cao theo chỉ báo EMA trễ pha (TrendVote={trend_vote_agg:+.2f}, BreakoutVote={breakout_vote_agg:+.2f}, ATR={tactical_atr_15m_pct:.2f}%)!"
                        )
                        return None
            elif is_active_target_asset and final_signal.signal == Signal.SELL:
                is_top_exhaustion_short = bool(final_signal.metadata.get('is_fading_short')) or has_real_bull_trap or (mean_vote_agg < 0.0 and c_upper_wick_pct >= 0.28)
                is_clean_waterfall_short = bool(final_signal.metadata.get('is_waterfall_short')) or is_waterfall_dump

                # [BOM #150 P1 FIX]: Không hồi sinh phiếu AI BUY đã bị Dual-Brain loại bỏ!
                _ai_active_kb5_sell = ('ai_ensemble' in votes) and not bool(trap_ctx.get('ai_popped_by_macro_dual_brain'))
                ai_truly_buying = _ai_active_kb5_sell and ((ai_dir_mtf in (Signal.BUY, 'BUY', 'buy') and ai_conf_mtf >= 0.60) or (ai_vote_agg >= 0.60) or (orig_ai_vote >= 0.60)) and not has_real_bull_trap and (ai_vote_agg >= 0.50 or orig_ai_vote >= 0.50)
                jev_truly_buying = ((jev_dir_mtf in (Signal.BUY, 'BUY', 'buy') and jev_conf_mtf >= 0.65) or (orig_jev_vote >= 0.65)) and orig_jev_vote >= 0.65

                # 1. CỤM MEAN REVERSION INVERSION (I_MR_SELL -> BUY): Bắt bẫy cản tàu dải Bollinger bung nóc (Band Walking)
                # [BOM #135 + BOM #150 P0 FIX]: Cấm chặn oan kèo Waterfall / Downtrend / TrendFollowing / Breakout SELL chỉ vì MeanReversion phụ báo SELL + ADX >= 25!
                if (
                    (not vk9_slot_b1_unlocked)
                    and (not dyn_vk_unlocked)
                    and (not is_clean_waterfall_short)
                    and (not is_downtrend)
                    and trend_vote_agg >= 0.0
                    and breakout_vote_agg >= 0.0
                    and mean_vote_agg < 0.0
                    and (is_uptrend or (macro_adx >= 25.0 and c_recent_pump >= c_recent_dump) or c_recent_pump >= min_whale_pump)
                    and c_upper_wick_pct < 0.28
                ):
                    if (
                        (ai_truly_buying or orig_jev_vote >= 0.50)
                        and orig_ai_vote >= 0.0
                        and orig_jev_vote >= 0.0
                        and c_vol_ratio >= wp_rvol_std
                        and current_rsi < (71.0 if is_crypto_altcoin else 74.0)
                        and c_recent_pump <= max_wf_dump
                    ):
                        final_signal.signal = Signal.BUY
                        final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                        self._clear_stale_weapon_metadata(final_signal)
                        final_signal.metadata['is_fading_short'] = False
                        final_signal.metadata['is_waterfall_short'] = False
                        final_signal.metadata['is_momentum_ride'] = True
                        final_signal.metadata['is_oversold_bounce'] = False
                        final_signal.metadata['is_trap_candidate'] = True
                        final_signal.metadata['is_trap_entry'] = True
                        final_signal.metadata['type'] = 'BAND_WALKING_RIDE_BUY'
                        final_signal.metadata['target_tp_pct'] = 0.025
                        final_signal.metadata['be_trigger_pct'] = 0.0085
                        final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                        final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                        final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                        final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                        final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                        logger.info(
                            f"🚀 [SMART INVERSION (MR): MEAN REVERSION -> BAND WALKING BUY] {symbol}: "
                            f"Bắt bẫy cản tàu dải trên bung nóc (ADX={macro_adx:.1f}, Pump={c_recent_pump*100:.1f}%, Râu trên={c_upper_wick_pct*100:.1f}% < 28%)! Lật sang BUY thuận đà bơm!"
                        )
                    else:
                        logger.warning(
                            f"🛡️ [MEAN REVERSION BULL TRAIN VETO] Hủy mở lệnh SELL {symbol}: Bán cản tàu dải trên trong xu hướng tăng mạnh (ADX={macro_adx:.1f}, Pump={c_recent_pump*100:.1f}%)!"
                        )
                        self._record_veto(symbol, 'MEAN_REVERSION_BULL_TRAIN_VETO', 'SHORT', f'ADX={macro_adx:.1f}, Pump={c_recent_pump*100:.1f}%')
                        return None

                # 2. CỤM MOMENTUM BREAKOUT INVERSION (I_BRK_SELL -> BUY): Bắt bẫy quét thanh khoản đáy (khớp ngưỡng VK4 DNA Shield BOM #101B + #140: sàn xả KB10, RVol 3 lớp, RSI <= 50, U_Wick < 25%)
                elif (not vk9_slot_b1_unlocked) and (not dyn_vk_unlocked) and breakout_vote_agg < 0.0 and c_recent_dump >= min_climax_hard_dump and c_lower_wick_pct >= 0.35 and c_upper_wick_pct < 0.25 and current_rsi <= 50.0 and c_vol_ratio >= min_climax_rvol and not is_jev_downtrend_shield_active and not is_extreme_bear_storm and orig_jev_vote > -0.70 and orig_ai_vote > -0.60 and ai_vote_agg > -0.60:
                    final_signal.signal = Signal.BUY
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    self._clear_stale_weapon_metadata(final_signal)
                    final_signal.metadata['is_fading_short'] = False
                    final_signal.metadata['is_waterfall_short'] = False
                    final_signal.metadata['is_momentum_ride'] = False
                    final_signal.metadata['is_oversold_bounce'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'LIQUIDITY_SWEEP_BOUNCE_LONG'
                    final_signal.metadata['target_tp_pct'] = 0.028
                    final_signal.metadata['be_trigger_pct'] = 0.0085
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                    final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                    logger.info(
                        f"⚡ [SMART INVERSION (BRK): BREAKDOWN -> LIQUIDITY SWEEP BUY] {symbol}: "
                        f"Thủng đáy bị rút chân gom hàng bẫy râu (LowerWick={c_lower_wick_pct*100:.1f}% >= 35%, RVol={c_vol_ratio:.2f}x)! Lật sang BUY bắt đáy quét thanh khoản!"
                    )

                # 3. CỤM TREND FOLLOWING INVERSION (I_TF_SELL -> BUY): Bắt đáy kiệt sức xu hướng xả sâu (khớp ngưỡng VK4 DNA Shield BOM #126B + #140 RVol 3 lớp)
                elif (not vk9_slot_b1_unlocked) and (not dyn_vk_unlocked) and trend_vote_agg < 0.0 and c_lower_wick_pct >= 0.35 and c_upper_wick_pct < 0.25 and current_rsi <= 50.0 and c_vol_ratio >= min_climax_rvol and (c_recent_dump >= min_climax_wave or current_rsi <= 32.0) and not is_jev_downtrend_shield_active and not is_extreme_bear_storm and orig_jev_vote > -0.70 and orig_ai_vote > -0.60 and ai_vote_agg > -0.60:
                    final_signal.signal = Signal.BUY
                    final_signal.confidence = max(float(getattr(final_signal, 'confidence', 0.80)), 0.85)
                    self._clear_stale_weapon_metadata(final_signal)
                    final_signal.metadata['is_fading_short'] = False
                    final_signal.metadata['is_waterfall_short'] = False
                    final_signal.metadata['is_momentum_ride'] = False
                    final_signal.metadata['is_oversold_bounce'] = True
                    final_signal.metadata['is_trap_candidate'] = True
                    final_signal.metadata['is_trap_entry'] = True
                    final_signal.metadata['type'] = 'TREND_EXHAUSTION_BOUNCE_LONG'
                    final_signal.metadata['target_tp_pct'] = 0.028
                    final_signal.metadata['be_trigger_pct'] = 0.0085
                    final_signal.metadata['c_lower_wick_pct'] = c_lower_wick_pct
                    final_signal.metadata['c_upper_wick_pct'] = c_upper_wick_pct
                    final_signal.metadata['c_vol_ratio'] = c_vol_ratio
                    final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                    final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                    logger.info(
                        f"⚡ [SMART INVERSION (TF): TREND FOLLOWING -> EXHAUSTION BUY] {symbol}: "
                        f"Xả kiệt sức xu hướng dãn biên (LowerWick={c_lower_wick_pct*100:.1f}% >= 35%, Dump={c_recent_dump*100:.1f}%, RSI={current_rsi:.1f})! Lật sang BUY bắt đáy!"
                    )
                elif (not vk9_slot_b1_unlocked) and (not dyn_vk_unlocked) and is_uptrend and not is_clean_waterfall_short and not is_top_exhaustion_short and (c_upper_wick_pct < 0.30 or ai_truly_buying or jev_truly_buying):
                    logger.warning(
                        f"🛡️ [KB5 BULL TRAIN VETO (V2_SHORT)] Hủy mở lệnh SELL {symbol}: Cấm Short cản tàu Altcoin trong Uptrend khi thiếu râu xả đỉnh hoặc AI/JEV báo BUY "
                        f"(Regime={regime.upper()}, UpperWick={c_upper_wick_pct*100:.1f}%, AI={orig_ai_vote:+.2f}, JEV={orig_jev_vote:+.2f})!"
                    )
                    return None
                else:
                    # [KB5 V1_SHORT - ĐỐI XỨNG CHẶN BÁN ĐUỔI ĐÁY ALTCOIN THEO EMA TRỄ PHA]:
                    is_valid_breakdown_short = (breakout_vote_agg < 0.0 and c_vol_ratio >= 1.20 and c_lower_wick_pct < 0.30)
                    is_low_atr_aligned_downtrend = (0.0 < tactical_atr_15m_pct < 2.5 and is_downtrend and (ai_vote_agg < 0.0 or orig_ai_vote < 0.0) and orig_jev_vote < 0.0)
                    if (not vk9_slot_b1_unlocked) and (not dyn_vk_unlocked) and (trend_vote_agg < 0.0 and tactical_atr_15m_pct >= 2.5 and current_rsi <= 38.0) and not (is_valid_breakdown_short or is_clean_waterfall_short or is_top_exhaustion_short or is_low_atr_aligned_downtrend):
                        logger.warning(
                            f"🛡️ [KB5 LAGGING EMA BOTTOM-CHASE VETO (V1_SHORT)] Hủy mở lệnh SELL {symbol}: "
                            f"Chặn bán đuổi đáy Altcoin biến động cao theo chỉ báo EMA trễ pha (TrendVote={trend_vote_agg:+.2f}, RSI={current_rsi:.1f}, ATR={tactical_atr_15m_pct:.2f}%)!"
                        )
                        return None

            # [BOM #126B + #131B + #136 A2 + #149 P1-8 FIX - POST-KB5 RE-VALIDATION SHIELD]: Đóng gói helper tái dùng cho CẢ KB5 & OrderFlow Smart Inversion!
            def _post_kb5_macro_recheck(_sig_pchk) -> bool:
                if _sig_pchk.signal == Signal.HOLD:
                    return True
                _wid_pchk = str((_sig_pchk.metadata or {}).get('weapon_id') or '')
                if is_non_btc_crypto and _sig_pchk.signal == Signal.BUY and btc_is_dumping:
                    _post_wp = (is_whale_pump_storm or bool(_sig_pchk.metadata.get('is_momentum_ride'))) and c_vol_ratio >= wp_rvol_std
                    _post_clx = ((c_lower_wick_pct >= 0.35 and has_real_bear_trap) or is_selling_climax_candle) and c_vol_ratio >= wp_rvol_std
                    if not (_post_wp or _post_clx):
                        logger.warning(
                            f"🛡️ [POST-KB5 BTC MACRO DOWNTREND VETO] Hủy lệnh BUY sau lật chiều {symbol}: BTC 1H đang xả mạnh!"
                        )
                        self._record_veto(symbol, 'BTC_MACRO_DOWNTREND_VETO', 'LONG', 'Post-KB5 BTC 1H giảm mạnh', weapon_id=_wid_pchk)
                        return False
                elif is_non_btc_crypto and _sig_pchk.signal == Signal.SELL and btc_is_pumping:
                    _post_exh = (c_upper_wick_pct >= 0.35 or is_buying_climax_candle) and c_vol_ratio >= wp_rvol_std
                    _post_wf = (is_waterfall_dump or bool(_sig_pchk.metadata.get('is_waterfall_short'))) and c_vol_ratio >= wf_rvol_std
                    if not (_post_exh or _post_wf):
                        logger.warning(
                            f"🛡️ [POST-KB5 BTC MACRO UPTREND VETO] Hủy lệnh SHORT sau lật chiều {symbol}: BTC đang bơm mạnh!"
                        )
                        self._record_veto(symbol, 'BTC_MACRO_UPTREND_VETO', 'SHORT', 'Post-KB5 BTC đang bơm mạnh', weapon_id=_wid_pchk)
                        return False
                if is_tradfi:
                    # [BOM #149 P1-8 FIX]: Tái kiểm tra US Opening Bell sau khi KB5/OrderFlow vừa lật chiều trên cổ phiếu Mỹ!
                    if is_stock and is_opening_bell and not dyn_vk_unlocked:
                        if _sig_pchk.signal == Signal.BUY and c_recent_dump >= 0.010 and c_recent_dump > c_recent_pump:
                            logger.warning(f"🛡️ [POST-KB5 OPENING BELL BUY VETO] Hủy BUY {symbol} sau lật chiều: Nến mở phiên Mỹ đang xả mạnh ({c_recent_dump*100:.2f}%)!")
                            self._record_veto(symbol, 'OPENING_BELL_BUY_VETO', 'LONG', 'Post-KB5 mở phiên Mỹ đang xả mạnh', weapon_id=_wid_pchk)
                            return False
                        elif _sig_pchk.signal == Signal.SELL and c_recent_pump >= 0.010 and c_recent_pump > c_recent_dump and c_vol_ratio >= 1.80 and c_upper_wick_pct < 0.30:
                            logger.warning(f"🛡️ [POST-KB5 OPENING BELL SHORT VETO] Hủy SHORT {symbol} sau lật chiều: Nến mở phiên Mỹ bơm bão ({c_recent_pump*100:.2f}%, RVol={c_vol_ratio:.2f}x)!")
                            self._record_veto(symbol, 'OPENING_BELL_SHORT_VETO', 'SHORT', 'Post-KB5 mở phiên Mỹ bơm bão xanh đặc', weapon_id=_wid_pchk)
                            return False
                    _is_bear_post = hasattr(MarketScanner, 'is_bear_inverse_etf') and MarketScanner.is_bear_inverse_etf(symbol)
                    _lead_sym_post = MarketScanner.get_lead_asset(symbol) if hasattr(MarketScanner, 'get_lead_asset') else None
                    _lead_base_post = MarketScanner._clean_base(_lead_sym_post) if _lead_sym_post else None
                    _lead_ctx_post = (market_chop_context or {}).get(_lead_base_post) or {}
                    _sym_canon_p149 = MarketScanner._canonical_tradfi_base(symbol) if hasattr(MarketScanner, '_canonical_tradfi_base') else ''
                    _bm_uncorr_p150 = set(getattr(MarketScanner, 'UNCORRELATED_SELF_BENCHMARK_BASES', ())) | {'TBT', 'KOLD', 'YANG'}
                    if not _lead_ctx_post and _lead_sym_post is not None and _sym_canon_p149 not in _bm_uncorr_p150 and hasattr(MarketScanner, 'get_tradfi_sector'):
                        _sec_p148 = MarketScanner.get_tradfi_sector(symbol)
                        _sec_bm_p148 = (getattr(MarketScanner, 'BENCHMARK_LEADERS', {}) or {}).get(_sec_p148)
                        if _sec_bm_p148 and MarketScanner._clean_base(_sec_bm_p148) != _sym_canon_p149:
                            _lead_ctx_post = (market_chop_context or {}).get(MarketScanner._clean_base(_sec_bm_p148)) or {}
                            if _lead_ctx_post:
                                _lead_sym_post = _sec_bm_p148
                    _l_up = bool(_lead_ctx_post.get('is_uptrend') or _lead_ctx_post.get('is_strong_uptrend'))
                    _l_dn = bool(_lead_ctx_post.get('is_downtrend') or _lead_ctx_post.get('is_strong_downtrend'))
                    _l_adx = float(_lead_ctx_post.get('adx') or 0.0)
                    if _sig_pchk.signal == Signal.BUY and _is_bear_post:
                        if _l_up or (not _lead_ctx_post and is_downtrend and macro_adx >= 25.0):
                            logger.warning(f"🛡️ [POST-KB5 BEAR ETF TRAP VETO] Hủy BUY {symbol} sau lật chiều: Benchmark {_lead_sym_post or 'ngành'} đang Uptrend!")
                            self._record_veto(symbol, 'BEAR_ETF_TRAP_VETO', 'LONG', 'Post-KB5 Bear ETF ngược Benchmark Uptrend', weapon_id=_wid_pchk)
                            return False
                    elif _sig_pchk.signal == Signal.SELL and _is_bear_post and c_upper_wick_pct < 0.30:
                        if _l_dn or (not _lead_ctx_post and is_uptrend and macro_adx >= 25.0):
                            logger.warning(f"🛡️ [POST-KB5 BEAR ETF SHORT VETO] Hủy SHORT {symbol} sau lật chiều: Benchmark {_lead_sym_post or 'ngành'} đang Downtrend!")
                            self._record_veto(symbol, 'BEAR_ETF_SHORT_VETO', 'SHORT', 'Post-KB5 Bear ETF Short cản tàu', weapon_id=_wid_pchk)
                            return False
                    elif _sig_pchk.signal == Signal.SELL and not _is_bear_post and c_upper_wick_pct < 0.30:
                        if (_l_up and (bool(_lead_ctx_post.get('is_strong_uptrend')) or _l_adx >= 28.0)) if _lead_ctx_post else (is_uptrend and macro_adx >= 28.0):
                            logger.warning(f"🛡️ [POST-KB5 TRADFI BENCHMARK PUMP VETO] Hủy SHORT {symbol} sau lật chiều: Benchmark đang Uptrend mạnh!")
                            self._record_veto(symbol, 'TRADFI_BENCHMARK_PUMP_VETO', 'SHORT', 'Post-KB5 TradFi Short cản Benchmark Uptrend', weapon_id=_wid_pchk)
                            return False
                    elif _sig_pchk.signal == Signal.BUY and not _is_bear_post and c_lower_wick_pct < 0.30:
                        if (_l_dn and (bool(_lead_ctx_post.get('is_strong_downtrend')) or _l_adx >= 28.0)) if _lead_ctx_post else (is_downtrend and macro_adx >= 28.0):
                            logger.warning(f"🛡️ [POST-KB5 TRADFI BENCHMARK DUMP VETO] Hủy BUY {symbol} sau lật chiều: Benchmark đang Downtrend mạnh!")
                            self._record_veto(symbol, 'TRADFI_BENCHMARK_DUMP_VETO', 'LONG', 'Post-KB5 TradFi Buy bắt dao rơi ngược Benchmark', weapon_id=_wid_pchk)
                            return False
                return True

            if final_signal.signal != _pre_kb5_signal_dir:
                if not _post_kb5_macro_recheck(final_signal):
                    return None

            macro_bear_dominant = (
                is_downtrend
                and (macro_adx >= 28.0 or 'strong_downtrend' in regime)
                and (('ai_ensemble' in votes and ai_dir_mtf == Signal.SELL and ai_conf_mtf >= 0.70) or is_jev_strong_sell)
            )
            macro_bull_dominant = (
                is_uptrend
                and (macro_adx >= 28.0 or 'strong_uptrend' in regime)
                and (('ai_ensemble' in votes and ai_dir_mtf == Signal.BUY and ai_conf_mtf >= 0.70) or is_jev_strong_buy)
            )
            is_strong_uptrend_regime = (is_uptrend and (macro_adx >= 28.0 or 'strong_uptrend' in regime))

            if final_signal.signal == Signal.BUY and is_downtrend:
                # [BÀI HỌC 95, 97, 108 & CONSECUTIVE LOSS GATE]: Tuyệt đối CẤM để râu nến giả hoặc thỏa hiệp chỉ báo trễ pha
                # bypass Veto MTF khi xu hướng vĩ mô giảm mạnh (ADX >= 28.0 hoặc strong_downtrend) và AI/JEV kiên quyết SELL >= 70%!
                is_whale_momentum_ride_valid = (
                    bool(final_signal.metadata.get('is_momentum_ride'))
                    and c_vol_ratio >= wp_rvol_std
                )
                if macro_bear_dominant and not is_whale_momentum_ride_valid and not vk10_slot_b1_unlocked and not dyn_vk_unlocked and not c2_slot_b2_unlocked:
                    _ai_dir_lbl = getattr(ai_dir_mtf, 'value', str(ai_dir_mtf or 'HOLD'))
                    _jev_dir_lbl = getattr(jev_dir_mtf, 'value', str(jev_dir_mtf or 'HOLD'))
                    logger.warning(
                        f"🛡️ [VETO MTF STRONG DOWNTREND] Hủy mở lệnh BUY {symbol}: Xu hướng giảm mạnh ({regime.upper()}, ADX={macro_adx:.1f} >= 28.0) "
                        f"và AI/JEV báo SELL mạnh (AI: {_ai_dir_lbl} {ai_conf_mtf:.1%}, JEV: {_jev_dir_lbl} {jev_conf_mtf:.1%})! Cấm bắt dao rơi cản tàu cá mập."
                    )
                    return None

                # [BOM #125C FIX]: Đối xứng 1-1 với khối 4H strong_uptrend bên dưới + đọc max(meta, c_lower_wick_pct) tránh metadata rỗng trước L5290!
                is_strong_downtrend_regime = (macro_adx >= 28.0 or 'strong_downtrend' in regime)
                c_dump_pct_mtf = max(float(final_signal.metadata.get('c_recent_dump_pct', 0.0) or 0.0), c_recent_dump)
                c_l_wick_mtf = max(float(final_signal.metadata.get('c_lower_wick_pct', 0.0) or 0.0), c_lower_wick_pct)
                req_dump_bounce = 0.006 if is_tradfi else 0.018
                is_verified_whale_bottom_climax = (
                    (bool(final_signal.metadata.get('is_oversold_bounce')) or has_real_bear_trap or is_selling_climax_candle)
                    and c_dump_pct_mtf >= req_dump_bounce
                    and c_l_wick_mtf >= 0.35
                )
                if is_strong_downtrend_regime and not (is_whale_momentum_ride_valid or is_verified_whale_bottom_climax or vk10_slot_b1_unlocked or dyn_vk_unlocked or c2_slot_b2_unlocked):
                    logger.warning(
                        f"🛡️ [VETO MTF STRONG DOWNTREND] Hủy mở lệnh BUY {symbol}: Xu hướng vĩ mô 4H giảm mạnh "
                        f"({regime.upper()}, ADX={macro_adx:.1f} >= 28.0)! Thiếu cấu trúc gom đáy cá mập "
                        f"(Cần Momentum Ride RVol >= {wp_rvol_std:.1f}x hoặc Oversold Bounce Dump >= {req_dump_bounce*100:.1f}% + Râu dưới >= 35%)."
                    )
                    return None

                has_physical_buy_wick = (
                    has_bear_trap_wick
                    or has_real_bear_trap
                    or (final_signal.metadata.get('is_oversold_bounce') and c_l_wick_mtf >= 0.30)
                    or (is_selling_climax_candle and c_l_wick_mtf >= 0.35)
                    or final_signal.metadata.get('is_momentum_ride')
                    or bool(dyn_vk_unlocked)
                )

                if has_physical_buy_wick:
                    logger.info(f"⚡ MTF Trap Override: Cho phép BUY {symbol} ngược 4H do phát hiện Quét thanh khoản gom hàng/Oversold Bounce/Momentum Ride/Số Đông Đồng Thuận (Score: {score:+.2f})!")
                else:
                    ema_str = f", EMA {ema.upper()}" if ema else ""
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh BUY {symbol} do ngược Trend 4H ({regime.upper()}{ema_str})! Cấm bắt dao rơi khi không có bẫy gấu rút chân gom hàng.")
                    return None

            if final_signal.signal == Signal.SELL and is_uptrend:
                # [BÀI HỌC 95, 97, 108 & CONSECUTIVE LOSS GATE]: Tuyệt đối CẤM để râu nến giả hoặc thỏa hiệp chỉ báo trễ pha
                # bypass Veto MTF khi xu hướng vĩ mô tăng mạnh (ADX >= 28.0 hoặc strong_uptrend) và AI/JEV kiên quyết BUY >= 70% (như ACT/USDT)!
                is_whale_waterfall_breakdown = (
                    (is_waterfall_dump or bool(final_signal.metadata.get('is_waterfall_short')))
                    and c_vol_ratio >= wf_rvol_std
                )
                macro_bull_dominant = (
                    (macro_adx >= 28.0 or 'strong_uptrend' in regime)
                    and (('ai_ensemble' in votes and ai_dir_mtf == Signal.BUY and ai_conf_mtf >= 0.70) or is_jev_strong_buy)
                )
                if macro_bull_dominant and not is_whale_waterfall_breakdown and not vk9_slot_b1_unlocked and not dyn_vk_unlocked:
                    _ai_dir_lbl = getattr(ai_dir_mtf, 'value', str(ai_dir_mtf or 'HOLD'))
                    _jev_dir_lbl = getattr(jev_dir_mtf, 'value', str(jev_dir_mtf or 'HOLD'))
                    logger.warning(
                        f"🛡️ [VETO MTF STRONG UPTREND] Hủy mở lệnh SELL {symbol}: Xu hướng tăng mạnh ({regime.upper()}, ADX={macro_adx:.1f} >= 28.0) "
                        f"và AI/JEV báo BUY mạnh (AI: {_ai_dir_lbl} {ai_conf_mtf:.1%}, JEV: {_jev_dir_lbl} {jev_conf_mtf:.1%})! Cấm Short cản tàu cá mập đang bơm khi không có Waterfall xả bão Volume."
                    )
                    return None

                # [CHUẨN QUỸ RULE 0 - SIẾT RÀO CHẮN 4H STRONG UPTREND]:
                # Khi 4H là strong_uptrend và ADX >= 28.0, cấm tuyệt đối Short đón đầu trừ khi là:
                # (1) Waterfall Breakdown Short (xả bão volume RVol >= 1.6x); HOẶC
                # (2) True Exhaustion Fading Short: Sóng bơm trước đó đạt chuẩn (TradFi >= 0.6%, Crypto >= 1.8%) VÀ Râu xả đỉnh >= 35%.
                is_strong_uptrend_regime = (macro_adx >= 28.0 or 'strong_uptrend' in regime)
                c_pump_pct = max(float(final_signal.metadata.get('c_recent_pump_pct', 0.0) or 0.0), c_recent_pump)
                c_u_wick = max(float(final_signal.metadata.get('c_upper_wick_pct', 0.0) or 0.0), c_upper_wick_pct)
                req_pump_fading = 0.006 if is_tradfi else 0.018
                is_verified_whale_fading_climax = (
                    (bool(final_signal.metadata.get('is_fading_short')) or has_real_bull_trap or is_buying_climax_candle)
                    and c_pump_pct >= req_pump_fading
                    and c_u_wick >= 0.35
                )
                if is_strong_uptrend_regime and not (is_whale_waterfall_breakdown or is_verified_whale_fading_climax or vk9_slot_b1_unlocked or dyn_vk_unlocked):
                    logger.warning(
                        f"🛡️ [VETO MTF STRONG UPTREND] Hủy mở lệnh SELL {symbol}: Xu hướng vĩ mô 4H tăng mạnh "
                        f"({regime.upper()}, ADX={macro_adx:.1f} >= 28.0)! Thiếu cấu trúc xả đỉnh cá mập "
                        f"(Cần Waterfall RVol >= {wf_rvol_std:.1f}x hoặc Fading Short Pump >= {req_pump_fading*100:.1f}% + Râu >= 35%). Cấm Short cản tàu."
                    )
                    return None

                has_physical_sell_wick = (
                    has_bull_trap_wick
                    or has_real_bull_trap
                    or (final_signal.metadata.get('is_fading_short') and c_u_wick >= 0.35)
                    or (is_buying_climax_candle and c_u_wick >= 0.35)
                    or is_waterfall_dump
                    or bool(final_signal.metadata.get('is_waterfall_short'))
                    or bool(dyn_vk_unlocked)
                )

                if has_physical_sell_wick:
                    logger.info(f"⚡ MTF Trap Override: Cho phép SELL {symbol} ngược 4H do phát hiện Bẫy tăng xả hàng/Buying Climax/Waterfall (Score: {score:+.2f})")
                else:
                    ema_str = f", EMA {ema.upper()}" if ema else ""
                    logger.warning(f"🛡️ VETO MTF: Hủy lệnh SELL {symbol} do ngược Trend 4H ({regime.upper()}{ema_str})! Không có xác nhận bẫy tăng xả hàng.")
                    return None

            final_signal.stop_loss = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'stop_loss'
            )

            final_signal.take_profit = self._aggregate_protection_level(
                signals, final_signal.signal, price, 'take_profit'
            )

            # [CHUẨN HÓA SL/TP THÍCH ỨNG ATR THEO 3 LỚP TÀI SẢN CHO CÁC LỆNH CHUYỂN HÓA ĐẶC BIỆT]:
            # [BOM #125C + BOM #145 SSOT]: Ưu tiên MarketScanner.is_leveraged_etf(symbol), fallback đủ bộ ETF 2x/3x (NVDD/TSLS/MSTZ/MUU...)
            clean_sym_base = symbol.split('/')[0].split('USDT')[0].split(':')[0].strip().upper()
            is_lev_etf_sym = (
                bool(hasattr(MarketScanner, 'is_leveraged_etf') and MarketScanner.is_leveraged_etf(symbol))
                or clean_sym_base in (
                    'SOXL', 'SOXS', 'TQQQ', 'SQQQ', 'UPRO', 'SPXU', 'SPCX', 'TZA', 'KORU',
                    'NVDL', 'NVDD', 'TSLL', 'TSLS', 'MSTU', 'MSTX', 'MSTZ', 'CONL',
                    'MUU', 'MVLL', 'SNXX', 'SKUU', 'SKDD', 'UVXY',
                )
            )
            if is_tier1:
                # [BOM #147 P2 FIX]: Đồng bộ trần SL Major = 2.2% khớp 100% với core/bot.py & vietnamese_weapon_arsenal.py
                sl_min_b, sl_max_b = 0.010, 0.022
            elif is_tradfi:
                sl_min_b, sl_max_b = (0.018, 0.035) if is_lev_etf_sym else (0.010, 0.018)
            else:
                is_momentum_or_impulse = bool(final_signal.metadata.get('is_momentum_ride')) or max(c_recent_pump, c_recent_dump) >= 0.025
                sl_min_b = 0.020 if is_momentum_or_impulse else 0.015
                sl_max_b = 0.035
            eff_atr_for_sl = max(
                eff_atr_dec if eff_atr_dec > 0 else 0.012,
                c_recent_pump * 0.42,
                c_recent_dump * 0.42,
            )
            adaptive_sl_dist = min(sl_max_b, max(sl_min_b, 1.5 * eff_atr_for_sl))

            if final_signal.metadata.get('is_momentum_ride') or final_signal.metadata.get('is_oversold_bounce'):
                base_tp = float(final_signal.metadata.get('target_tp_pct') or 0.025)
                target_tp = max(base_tp, round(adaptive_sl_dist * 1.8, 4))
                final_signal.take_profit = price * (1.0 + target_tp)
                final_signal.stop_loss = price * (1.0 - adaptive_sl_dist)
            elif final_signal.metadata.get('is_fading_short') or final_signal.metadata.get('is_waterfall_short'):
                base_tp = float(final_signal.metadata.get('target_tp_pct') or (0.030 if final_signal.metadata.get('is_fading_short') else 0.025))
                sl_dist_short = min(sl_max_b, max(adaptive_sl_dist, 0.018 if (final_signal.metadata.get('is_fading_short') and not (is_tradfi and not is_lev_etf_sym)) else adaptive_sl_dist))
                target_tp = max(base_tp, round(sl_dist_short * 1.8, 4))
                final_signal.take_profit = price * (1.0 - target_tp)
                final_signal.stop_loss = price * (1.0 + sl_dist_short)
            elif final_signal.metadata.get('is_dynamic_weapon'):
                # [BOM #87 FIX]: Bao toan SL/TP chuan 3 lop tai san cho Vu Khi Dong (DYN-VK11..14) sau _aggregate_protection_level (tranh bi ghi de thanh None!)
                _dyn_tp_dist_f = max(0.015, round(adaptive_sl_dist * 1.8, 4))
                if final_signal.signal == Signal.BUY:
                    final_signal.stop_loss = price * (1.0 - adaptive_sl_dist)
                    final_signal.take_profit = price * (1.0 + _dyn_tp_dist_f)
                else:
                    final_signal.stop_loss = price * (1.0 + adaptive_sl_dist)
                    final_signal.take_profit = price * (1.0 - _dyn_tp_dist_f)

            # Bảo toàn đầy đủ metadata hạ nguồn (dfs cho Pre-Trade Gate & M1 Sniper, type của TrapDetector, reason/risk_factors của JEV)
            shared_dfs = next(
                (
                    s.metadata.get('dfs')
                    for s in signals
                    if isinstance(getattr(s, 'metadata', None), dict) and s.metadata.get('dfs') is not None
                ),
                None,
            )

            eff_dir_sign = 1.0 if final_signal.signal == Signal.BUY else (-1.0 if final_signal.signal == Signal.SELL else 0.0)
            contrib_strats_all = sorted(
                name for name, (vote, _weight) in votes.items() if vote * eff_dir_sign > 0
            )
            contrib_strats = list(contrib_strats_all)
            # [BOM #145 + #147 P1-5 + BOM #150 P1 FIX]: Khi lệnh thuận xu hướng (TrendFollowing/MomentumBreakout) đã đạt đa trụ đồng thuận,
            # KHÔNG cho phiếu phụ TrapDetector hay cờ is_ai_exhaustion_sell ghi đè metadata['type'] cướp lệnh VK8/VK1/VK5 sang VK3/VK6/VK7!
            _has_primary_trend_or_bo = any(
                s_n in ('trend_following', 'momentum_breakout') for s_n in contrib_strats
            ) and not (
                bool(final_signal.metadata.get('is_oversold_bounce'))
                or bool(final_signal.metadata.get('is_fading_short'))
                or bool(final_signal.metadata.get('is_vk9_climax_wick_short'))
                or bool(final_signal.metadata.get('is_vk10_tradfi_bottom_long'))
                or bool(final_signal.metadata.get('is_dynamic_weapon'))
            )

            if _has_primary_trend_or_bo:
                trap_type_val = None
                contrib_strats = [s_n for s_n in contrib_strats if s_n != 'trap_detector']
            elif trap_ctx.get('is_ai_exhaustion_sell') and final_signal.signal == Signal.SELL:
                trap_type_val = 'EXHAUSTION_FADING_SELL'
            else:
                trap_sigs_matching = [
                    s for s in signals
                    if getattr(s, 'strategy', '').lower() in ('trap_detector', 'trapdetector')
                    and getattr(s, 'signal', None) == final_signal.signal
                    and isinstance(getattr(s, 'metadata', None), dict)
                    and s.metadata.get('type')
                ]
                trap_type_val = next(
                    (s.metadata.get('type') for s in trap_sigs_matching if s.metadata.get('timeframe') == '15m'),
                    next((s.metadata.get('type') for s in trap_sigs_matching), None)
                )

            jev_meta = getattr(jev_sig, 'metadata', {}) if (jev_sig and isinstance(getattr(jev_sig, 'metadata', None), dict)) else {}

            if not contrib_strats and final_signal.metadata.get('type'):
                contrib_strats = [str(final_signal.metadata.get('type')).lower()]

            resolved_final_type = str(final_signal.metadata.get('type') or trap_type_val or '')
            if final_signal.signal == Signal.SELL:
                tac_adx_final = float((market_analysis or {}).get('tactical_adx') or 0.0)
                # [BOM #131B FIX]: Áp dụng đủ 4 chốt an toàn BUYING_CLIMAX cho TẤT CẢ nhánh Fading Short (trừ VK9 râu cực đại riêng)!
                _is_fading_climax_check = (
                    (not bool(final_signal.metadata.get('is_vk9_climax_wick_short')))
                    and (not bool(final_signal.metadata.get('is_dynamic_weapon')))
                    and (
                        resolved_final_type in (
                            'BUYING_CLIMAX', 'FADING_SHORT_PHASE2', 'PARABOLIC_EXHAUSTION_SHORT',
                            'EXHAUSTION_FADING_SELL', 'LIQUIDITY_SWEEP_FADING_SHORT', 'TREND_EXHAUSTION_FADING_SHORT'
                        )
                        or bool(final_signal.metadata.get('is_fading_short'))
                    )
                )
                if _is_fading_climax_check:
                    if regime_pre_str in ('strong_uptrend', 'uptrend') and macro_adx >= 28.0 and tac_adx_final >= 35.0 and 0.0 < current_rsi < 52.0 and c_recent_dump < 0.020:
                        logger.warning(
                            "🛡️ [TẦNG 3 - TỪ CHỐI AN TOÀN] Hủy mở lệnh BÁN %s: Bẫy đỉnh ảo tại đáy nhịp chỉnh trong sóng tăng kép (Trạng thái=%s, Lực Trend=%.1f, RSI=%.1f < 52.0)! Cấm bán cản tàu!",
                            symbol, regime_pre_str, macro_adx, current_rsi
                        )
                        self._record_veto(symbol, 'BUYING_CLIMAX_PULLBACK_TRAP_VETO', 'SHORT', f'Regime={regime_pre_str}, ADX={macro_adx:.1f}, RSI={current_rsi:.1f}')
                        return None
                    _min_clx_pump_gate = 0.005 if is_tradfi else 0.007
                    # [BOM #137 FIX]: Cưỡng chế sàn cứng KB10 (_min_clx_pump_gate) kể cả khi râu >= 45%, tránh BULL_TRAP_WICK lách qua trên nến đi ngang lờ đờ!
                    if c_recent_pump < _min_clx_pump_gate or (c_recent_pump < 0.010 and c_vol_ratio < 1.55 and c_upper_wick_pct < 0.45):
                        logger.warning(
                            "🛡️ [TẦNG 3 - TỪ CHỐI AN TOÀN] Hủy mở lệnh BÁN %s: Sóng tăng quá nhỏ (Tăng nến=%.2f%% < %.1f%%, Bội số Vol=%.2fx, Râu trên=%.1f%%)! Chưa đủ điều kiện Sóng Bơm Kiệt Sức!",
                            symbol, c_recent_pump * 100, _min_clx_pump_gate * 100, c_vol_ratio, c_upper_wick_pct * 100
                        )
                        self._record_veto(symbol, 'BUYING_CLIMAX_SMALL_WAVE_VETO', 'SHORT', f'Pump={c_recent_pump*100:.2f}%, RVol={c_vol_ratio:.2f}x, UW={c_upper_wick_pct*100:.1f}%')
                        return None
                    # [BOM #150 P1 FIX]: Không hồi sinh orig_ai_vote >= 0.70 sau khi Dual-Brain đã gỡ phiếu AI BUY!
                    _ai_not_popped_db = not bool(trap_ctx.get('ai_popped_by_macro_dual_brain'))
                    _eff_ai_buy_conflict = _ai_not_popped_db and (orig_ai_vote >= 0.70)
                    if (_eff_ai_buy_conflict and (0.0 < tac_adx_final < 19.0 or 0.0 < macro_adx < 20.0 or c_lower_wick_pct >= 0.22)) or (
                        (_eff_ai_buy_conflict or ('ai_ensemble' not in contrib_strats and _ai_not_popped_db and len(contrib_strats) <= 2 and 0.0 < macro_adx < 20.0))
                        and len(contrib_strats) <= 2 and c_recent_dump < 0.010 and 0.0 < current_rsi < 70.0 and c_vol_ratio < 2.0
                    ):
                        # [BOM #102E FIX]: Phân biệt rõ log khi AI thực sự báo MUA (>= 0.70) vs khi thiếu phiếu AI (orig_ai_vote == 0.0)
                        _ai_conflict_lbl = (
                            f"Trọng tài AI xác nhận MUA (Điểm AI={orig_ai_vote:+.2f}) đối kháng"
                            if _eff_ai_buy_conflict
                            else f"Thiếu xác nhận từ Trọng tài AI (Điểm AI={orig_ai_vote:+.2f}) trên nền đi ngang yếu"
                        )
                        logger.warning(
                            "🛡️ [TẦNG 3 - TỪ CHỐI AN TOÀN] Hủy mở lệnh BÁN %s: %s trên nến yếu/rút chân (Lực Trend=%.1f, Râu dưới=%.1f%%, Giảm nến=%.2f%%, RSI=%.1f, Bội số Vol=%.2fx)! Đứng ngoài bảo vệ vốn!",
                            symbol, _ai_conflict_lbl, macro_adx, c_lower_wick_pct * 100, c_recent_dump * 100, current_rsi, c_vol_ratio
                        )
                        self._record_veto(symbol, 'BUYING_CLIMAX_AI_CONFLICT_VETO', 'SHORT', f'AI={orig_ai_vote:+.2f}, ADX={macro_adx:.1f}')
                        return None
                    if regime_pre_str == 'high_volatility' and macro_adx >= 38.0 and 0.0 < tac_adx_final < 22.0 and c_lower_wick_pct >= 0.24 and 0.0 < c_vol_ratio < 2.0:
                        logger.warning(
                            "🛡️ [TẦNG 3 - TỪ CHỐI AN TOÀN] Hủy mở lệnh BÁN %s: Biến động giật 2 đầu suy yếu xung lượng nến 15M (Lực Trend=%.1f, Râu dưới=%.1f%% >= 24%%, Bội số Vol=%.2fx)! Tránh bẫy quét 2 đầu!",
                            symbol, macro_adx, c_lower_wick_pct * 100, c_vol_ratio
                        )
                        self._record_veto(symbol, 'BUYING_CLIMAX_TWIN_WHIPSAW_VETO', 'SHORT', f'ADX={macro_adx:.1f}, LW={c_lower_wick_pct*100:.1f}%, RVol={c_vol_ratio:.2f}x')
                        return None
                else:
                    # [BOM #150 P2 FIX]: Phân tầng ngưỡng OVERSOLD_BOTTOM_SELL_VETO theo lớp tài sản (TradFi 0.7% / 1.15x vs Crypto 1.3% / 1.90x)
                    _obs_dump_th = 0.007 if is_tradfi else 0.013
                    _obs_rvol_th = 1.15 if is_tradfi else 1.90
                    if resolved_final_type in ('', 'None') and 0.0 < current_rsi < 39.5 and c_recent_dump < _obs_dump_th and c_vol_ratio < _obs_rvol_th:
                        logger.warning(
                            "🛡️ [TẦNG 3 - TỪ CHỐI AN TOÀN] Hủy mở lệnh BÁN %s: Cấm bán đuổi ở đáy quá bán (RSI=%.1f < 39.5) khi xung lực xả đã cạn (Giảm nến=%.2f%% < %.1f%%, Bội số Vol=%.2fx < %.2fx)! Tránh dính bẫy bật tăng!",
                            symbol, current_rsi, c_recent_dump * 100, _obs_dump_th * 100, c_vol_ratio, _obs_rvol_th
                        )
                        self._record_veto(symbol, 'OVERSOLD_BOTTOM_SELL_VETO', 'SHORT', f'RSI={current_rsi:.1f}, Dump={c_recent_dump*100:.2f}%')
                        return None

            _agree_cnt_for_ratio = len(contrib_strats_all) if contrib_strats_all else agreeing
            raw_agree_ratio = (_agree_cnt_for_ratio / len(votes)) if (votes and _agree_cnt_for_ratio) else 0.0
            eff_agreeing = _agree_cnt_for_ratio
            eff_agree_ratio = raw_agree_ratio
            is_smart_inversion_signal = (
                final_signal.signal != Signal.HOLD
                and (
                    bool(final_signal.metadata.get('is_momentum_ride'))
                    or bool(final_signal.metadata.get('is_waterfall_short'))
                    or bool(final_signal.metadata.get('is_fading_short'))
                    or bool(final_signal.metadata.get('is_oversold_bounce'))
                    or bool(final_signal.metadata.get('is_parabolic_long_inversion'))
                    or bool(final_signal.metadata.get('is_vk9_climax_wick_short'))
                    or bool(final_signal.metadata.get('is_vk10_tradfi_bottom_long'))
                    or bool(final_signal.metadata.get('is_dynamic_weapon'))
                )
                and (
                    original_signal != final_signal.signal
                    or bool(final_signal.metadata.get('is_parabolic_long_inversion'))
                    or bool(final_signal.metadata.get('is_vk9_climax_wick_short'))
                    or bool(final_signal.metadata.get('is_vk10_tradfi_bottom_long'))
                    or bool(final_signal.metadata.get('is_dynamic_weapon'))
                )
            )
            if is_smart_inversion_signal:
                eff_agree_ratio = max(raw_agree_ratio, 0.65 if float(getattr(final_signal, 'confidence', 0.0) or 0.0) >= 0.80 else 0.55)
                eff_agreeing = max(eff_agreeing, int(round(eff_agree_ratio * max(1, len(votes)))))

            # [BOM #95D & #100 FIX]: Dong bo dau `score` theo chieu final_signal sau Smart Inversion,
            # va CAM ghi de is_fading_short/is_oversold_bounce/is_ai_exhaustion_sell len Vu Khi Dong (is_dynamic_weapon)!
            if final_signal.signal == Signal.BUY and score < 0:
                score = abs(score)
            elif final_signal.signal == Signal.SELL and score > 0:
                score = -abs(score)
            _is_dyn_final = bool(final_signal.metadata.get('is_dynamic_weapon', False))

            final_signal.metadata.update({
                'contributing_strategies': contrib_strats,
                'weighted_score': score,
                'ai_ensemble_vote': float(ai_vote_agg),
                'orig_ai_vote': float(orig_ai_vote if 'orig_ai_vote' in locals() else ai_vote_agg),
                'orig_jev_vote': float(orig_jev_vote if 'orig_jev_vote' in locals() else jev_vote_agg),
                'agreeing_strategies': eff_agreeing,
                'strategy_count': len(votes),
                'agreement_ratio': eff_agree_ratio,
                'market_analysis': market_analysis,
                'dfs': shared_dfs,
                'type': final_signal.metadata.get('type') or trap_type_val,
                'is_dual_brain_ai_consensus': bool(is_dual_brain_ai_consensus),
                'is_dual_pillar_high_conviction': bool(is_dual_pillar_high_conviction),
                'is_ai_exhaustion_sell': (False if _is_dyn_final else (bool(trap_ctx.get('is_ai_exhaustion_sell', False)) and final_signal.signal == Signal.SELL)),
                'is_fading_short': (
                    False if _is_dyn_final else (
                        bool(final_signal.metadata.get('is_fading_short', False))
                        or (
                            (not final_signal.metadata.get('is_waterfall_short'))
                            and (trap_type_val in ('EXHAUSTION_FADING_SELL', 'BULL_TRAP_WICK', 'BUYING_CLIMAX') or any(k in str(trap_type_val or '').upper() for k in ('FADING', 'EXHAUSTION', 'BULL_TRAP')))
                            and final_signal.signal == Signal.SELL
                            and (c_upper_wick_pct >= 0.28 and c_lower_wick_pct < 0.28)
                        )
                    )
                ),
                'is_oversold_bounce': (
                    False if _is_dyn_final else (
                        bool(final_signal.metadata.get('is_oversold_bounce', False))
                        or (
                            (not final_signal.metadata.get('is_momentum_ride'))
                            and (not final_signal.metadata.get('is_parabolic_long_inversion'))
                            and (trap_type_val in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX', 'PANIC_CLIMAX_BOUNCE') or any(k in str(trap_type_val or '').upper() for k in ('BOUNCE', 'OVERSOLD', 'BEAR_TRAP')))
                            and final_signal.signal == Signal.BUY
                            and (c_lower_wick_pct >= 0.28 and c_upper_wick_pct < 0.28)
                        )
                    )
                ),
                'c_upper_wick_pct': float(final_signal.metadata.get('c_upper_wick_pct', c_upper_wick_pct) or c_upper_wick_pct),
                'c_lower_wick_pct': float(final_signal.metadata.get('c_lower_wick_pct', c_lower_wick_pct) or c_lower_wick_pct),
                'c_recent_pump_pct': float(c_recent_pump),
                'c_recent_dump_pct': float(c_recent_dump),
                'c_vol_ratio': float(final_signal.metadata.get('c_vol_ratio', c_vol_ratio) or c_vol_ratio),
                'jev_decision': jev_sig.signal.value.upper() if (jev_sig and hasattr(jev_sig, 'signal') and hasattr(jev_sig.signal, 'value')) else 'NONE',
                'reason': jev_meta.get('reason', ''),
                'risk_factors': (
                    ', '.join(jev_meta['risk_factors'])
                    if isinstance(jev_meta.get('risk_factors'), list)
                    else (jev_meta.get('risk_factors') or 'none')
                ),
            })

        if final_signal.signal == Signal.HOLD and abs(score) < entry_threshold:
            logger.warning(
                '🛡️ [SIGNAL SCORE VETO] %s: |weighted score| %.4f < %.2f; chưa đủ chuẩn cấp lệnh mới.',
                symbol, abs(score), entry_threshold,
            )

        # [BOM #110B FIX]: Kiểm tra vòng đời PAUSED TRƯỚC khi gọi OrderFlowAnalyzer Live REST API
        # để không đốt API weight và ngăn OrderFlow lật một vũ khí đang TẠM TẮT thành VK1/VK5 đang BẬT!
        if final_signal.signal != Signal.HOLD:
            _pre_of_side = getattr(final_signal.signal, 'value', str(final_signal.signal)).upper()
            _pre_of_dir = 'LONG' if _pre_of_side == 'BUY' else 'SHORT'
            try:
                from core.vietnamese_weapon_arsenal import classify_signal_weapon as _pre_cls_w
                from core.quant_evolution_engine import is_weapon_enabled_for_live as _pre_live_w
                _pre_w_info = _pre_cls_w(signal_obj=final_signal, meta=final_signal.metadata, direction=_pre_of_dir)
                if isinstance(_pre_w_info, dict) and _pre_w_info.get('id'):
                    _pre_wid = str(_pre_w_info['id'])
                    if not _pre_live_w(_pre_wid):
                        logger.info(
                            f"⏸️ [VÒNG ĐỜI VŨ KHÍ - CHẶN SỚM TRƯỚC ORDER FLOW] Hủy mở lệnh {symbol} ({_pre_of_dir}): "
                            f"Vũ khí {_pre_w_info.get('short_name', _pre_wid)} đang PAUSED/LAB_DEMOTED!"
                        )
                        self._record_veto(symbol, 'WEAPON_PAUSED_LIFECYCLE', _pre_of_dir, f"Vũ khí {_pre_w_info.get('code', '')} ({_pre_wid}) đang PAUSED/LAB_DEMOTED", weapon_id=_pre_wid)
                        return None
            except Exception as _pre_w_err:
                logger.warning(f"⚠️ [BOM #110B FAIL-CLOSED] Lỗi kiểm tra vòng đời vũ khí trước OrderFlow cho {symbol}: {_pre_w_err}")
                return None

        # [ORDER FLOW & TAPE READING GATE]: Thẩm định Ma trận Dòng Lệnh Khớp Thực Tế (CVD + Price Action)
        # Bắt buộc tuân thủ Rào chắn Vĩ mô BTC / MTF 4H / KB10 và tính SL/TP chuẩn 3 lớp tài sản khi lật chiều!
        if final_signal.signal != Signal.HOLD and getattr(self, 'enable_live_order_flow', True) and hasattr(self, 'order_flow_analyzer') and self.order_flow_analyzer and '/' in symbol:
            sig_side_val = getattr(final_signal.signal, 'value', str(final_signal.signal)).upper()
            _of_ex = getattr(getattr(self, 'order_flow_analyzer', None), 'exchange', None)
            is_tradfi_sym = MarketScanner.is_tradfi_stock(symbol, exchange=_of_ex) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol, exchange=_of_ex))
            if not is_tradfi_sym:
                try:
                    pa_meta = {
                        'adx': macro_adx,
                        'rvol': c_vol_ratio,
                        'upper_wick_pct': c_upper_wick_pct,
                        'lower_wick_pct': c_lower_wick_pct,
                    'is_uptrend': is_uptrend,
                    'is_downtrend': is_downtrend,
                    # [BOM #126B FIX]: Khóa chiều cho trap_ctx khi truyền vào OrderFlowAnalyzer (không gán whale_pump cho SHORT hay waterfall cho BUY!)
                    'is_momentum_ride': (final_signal.signal == Signal.BUY) and (bool(final_signal.metadata.get('is_momentum_ride')) or bool(trap_ctx.get('is_whale_pump_storm'))),
                    'is_waterfall_short': (final_signal.signal == Signal.SELL) and (bool(final_signal.metadata.get('is_waterfall_short')) or bool(trap_ctx.get('is_waterfall_dump'))),
                    'is_fading_short': bool(final_signal.metadata.get('is_fading_short')),
                    }
                    of_res = self.order_flow_analyzer.evaluate_order_flow_matrix(
                        symbol=symbol,
                        side=sig_side_val,
                        price_action_meta=pa_meta,
                        limit=100
                    )
                    if of_res and not of_res.get('allowed', True):
                        of_action = str(of_res.get('action') or '')
                        # [BOM #113C FIX]: KHONG cho OrderFlow ghi de / xoa weapon_id cua Vu Khi Dong (VK11/VK12)!
                        _is_dyn_of_gate = bool(final_signal.metadata.get('is_dynamic_weapon'))
                        # [BOM #134 FIX]: Cấm OrderFlow Smart Inversion lật ngược đâm thẳng vào AI Ensemble đối kháng mạnh (>= 60%)
                        # hoặc đuổi đỉnh/đáy Altcoin khi ADX >= 55 (tránh xuyên thủng AI Hard Consensus & Climax Shield)!
                        can_of_invert_buy = (
                            (not _is_dyn_of_gate)
                            and (not is_extreme_bear_storm)
                            and of_action == 'INVERT_TO_BUY'
                            and (orig_jev_vote >= 0.70 or (ai_vote_agg >= 0.65 and orig_jev_vote >= 0.0))
                            and orig_ai_vote > -0.60
                            and ai_vote_agg > -0.60
                            and not (is_crypto_altcoin and macro_adx >= 55.0)
                            and c_upper_wick_pct < 0.30
                            and current_rsi < (71.0 if is_crypto_altcoin else 72.0)
                            and not btc_is_dumping
                            and not macro_bear_dominant
                            and c_vol_ratio >= wp_rvol_std
                            and c_recent_pump <= max_wf_dump
                            and not (is_downtrend and macro_adx >= 28.0 and is_jev_strong_sell)
                            and not (c_recent_dump >= strong_impulse_th and c_recent_pump < retrace_cap_th and c_lower_wick_pct < 0.30)
                        )
                        # [BOM #145 FIX]: Gắn khóa KB5 V4 (chống Short Squeeze đáy sập) cho OrderFlow INVERT_TO_SHORT
                        _of_kb5_v4_blocked = (
                            ai_vote_agg <= -0.60
                            and orig_jev_vote <= -0.60
                            and (c_recent_dump >= (0.042 if is_crypto_altcoin else 0.028) or current_rsi <= 38.0)
                        )
                        can_of_invert_short = (
                            (not _is_dyn_of_gate)
                            and (not _of_kb5_v4_blocked)
                            and (not is_extreme_bull_storm)
                            and of_action == 'INVERT_TO_SHORT'
                            and (orig_jev_vote <= -0.70 or (ai_vote_agg <= -0.65 and orig_jev_vote <= 0.0))
                            and orig_ai_vote < 0.60
                            and ai_vote_agg < 0.60
                            and not (is_crypto_altcoin and macro_adx >= 55.0)
                            and c_lower_wick_pct < 0.30
                            and current_rsi > 32.0
                            and not btc_is_pumping
                            and not macro_bull_dominant
                            and c_vol_ratio >= wf_rvol_std
                            and c_recent_dump <= max_wf_dump
                            and not (is_uptrend and macro_adx >= 28.0 and is_jev_strong_buy)
                            and not (c_recent_pump >= strong_impulse_th and c_recent_dump < retrace_cap_th and c_upper_wick_pct < 0.30)
                        )
                        if can_of_invert_buy:
                            logger.warning(
                                f"🚀 [ORDER FLOW SMART INVERSION -> BUY] Lật ngược {sig_side_val} -> BUY cho {symbol} thuận dòng tiền cá mập: "
                                f"{of_res.get('reason')} (JEV={orig_jev_vote:+.2f}, AI={ai_vote_agg:+.2f})"
                            )
                            self._clear_stale_weapon_metadata(final_signal)
                            final_signal.metadata['is_ai_exhaustion_sell'] = False
                            final_signal.signal = Signal.BUY
                            final_signal.confidence = max(float(final_signal.confidence or 0.80), 0.85)
                            final_signal.metadata['type'] = 'MOMENTUM_RIDE'
                            final_signal.metadata['is_momentum_ride'] = True
                            final_signal.metadata['weighted_score'] = abs(float(final_signal.metadata.get('weighted_score', 0.0) or 0.85))
                            final_signal.metadata['is_trap_candidate'] = True
                            final_signal.metadata['is_trap_entry'] = True
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.0085
                            final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                            final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                            final_signal.metadata['order_flow_scenario'] = of_res.get('scenario')
                            new_contrib = sorted(name for name, (vote, _w) in votes.items() if vote > 0) or ['order_flow_momentum_ride']
                            final_signal.metadata['contributing_strategies'] = new_contrib
                            final_signal.metadata['agreeing_strategies'] = len(new_contrib)
                            final_signal.metadata['agreement_ratio'] = round(len(new_contrib) / max(1, len(votes)), 4)
                            if final_signal.price and final_signal.price > 0:
                                of_sl_buy = max(adaptive_sl_dist, 0.020 if is_crypto_altcoin else adaptive_sl_dist)
                                of_tp_dist = max(0.025, round(of_sl_buy * 1.8, 4))
                                final_signal.stop_loss = final_signal.price * (1.0 - of_sl_buy)
                                final_signal.take_profit = final_signal.price * (1.0 + of_tp_dist)
                        elif can_of_invert_short:
                            logger.warning(
                                f"🌊 [ORDER FLOW SMART INVERSION -> SHORT] Lật ngược {sig_side_val} -> SELL cho {symbol} thuận dòng tiền cá mập xả lũ: "
                                f"{of_res.get('reason')} (JEV={orig_jev_vote:+.2f}, AI={ai_vote_agg:+.2f})"
                            )
                            self._clear_stale_weapon_metadata(final_signal)
                            final_signal.metadata['is_ai_exhaustion_sell'] = False
                            final_signal.signal = Signal.SELL
                            final_signal.confidence = max(float(final_signal.confidence or 0.80), 0.85)
                            final_signal.metadata['type'] = 'WATERFALL_BREAKDOWN_SHORT'
                            final_signal.metadata['is_waterfall_short'] = True
                            final_signal.metadata['weighted_score'] = -abs(float(final_signal.metadata.get('weighted_score', 0.0) or 0.85))
                            final_signal.metadata['is_trap_candidate'] = True
                            final_signal.metadata['is_trap_entry'] = True
                            final_signal.metadata['target_tp_pct'] = 0.025
                            final_signal.metadata['be_trigger_pct'] = 0.0085
                            final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)
                            final_signal.metadata['c_recent_dump_pct'] = float(c_recent_dump)
                            final_signal.metadata['order_flow_scenario'] = of_res.get('scenario')
                            new_contrib = sorted(name for name, (vote, _w) in votes.items() if vote < 0) or ['order_flow_waterfall_short']
                            final_signal.metadata['contributing_strategies'] = new_contrib
                            final_signal.metadata['agreeing_strategies'] = len(new_contrib)
                            final_signal.metadata['agreement_ratio'] = round(len(new_contrib) / max(1, len(votes)), 4)
                            if final_signal.price and final_signal.price > 0:
                                of_tp_dist = max(0.025, round(adaptive_sl_dist * 1.8, 4))
                                final_signal.stop_loss = final_signal.price * (1.0 + adaptive_sl_dist)
                                final_signal.take_profit = final_signal.price * (1.0 - of_tp_dist)
                        if can_of_invert_buy or can_of_invert_short:
                            # [BOM #136 A2 FIX]: Tái kiểm tra POST-KB5 BTC/Benchmark/Bear-ETF sau khi OrderFlow vừa đảo chiều!
                            if not _post_kb5_macro_recheck(final_signal):
                                return None
                        else:
                            # [BOM #126B FIX]: Chỉ miễn trừ STAND_ASIDE khi chiều lệnh khớp hướng bão mua/thác đổ!
                            is_wp_meta = (final_signal.signal == Signal.BUY) and (bool(final_signal.metadata.get('is_momentum_ride')) or bool(trap_ctx.get('is_whale_pump_storm')))
                            is_wf_meta = (final_signal.signal == Signal.SELL) and (bool(final_signal.metadata.get('is_waterfall_short')) or bool(trap_ctx.get('is_waterfall_dump')))
                            is_vk9_meta = bool(final_signal.metadata.get('is_vk9_climax_wick_short')) and c_upper_wick_pct >= 0.65
                            is_dyn_meta = bool(final_signal.metadata.get('is_dynamic_weapon'))
                            if is_wp_meta and of_action == 'STAND_ASIDE':
                                logger.info(
                                    f"🚀 [ORDER FLOW EXEMPTION: MOMENTUM RIDE] Bỏ qua Veto dòng lệnh cho {symbol}: "
                                    f"Sóng bơm cá mập đã được xác nhận bởi JEV/Multi-Strategy, ưu tiên đi thuận trend!"
                                )
                            elif is_wf_meta and of_action == 'STAND_ASIDE':
                                logger.info(
                                    f"🌊 [ORDER FLOW EXEMPTION: WATERFALL SHORT] Bỏ qua Veto dòng lệnh cho {symbol}: "
                                    f"Thác đổ đã được xác nhận bởi JEV/Multi-Strategy, ưu tiên đi thuận đà xả!"
                                )
                            elif is_vk9_meta and of_action == 'STAND_ASIDE':
                                logger.info(
                                    f"🧪 [ORDER FLOW EXEMPTION: VK9 CLIMAX WICK] Bỏ qua STAND_ASIDE dòng lệnh cho {symbol}: "
                                    f"Bán Đỉnh Râu Cực Đại (U_Wick={c_upper_wick_pct*100:.1f}% >= 65%, RVol={c_vol_ratio:.2f}x) đã đạt chuẩn L1∩A4!"
                                )
                            elif is_dyn_meta and of_action == 'STAND_ASIDE':
                                # [BOM #113C FIX]: VK11/VK12 co rao chan EXTREME STORM + M1 OFI 75% rieng, mien STAND_ASIDE OrderFlow 15M!
                                logger.info(
                                    f"🧪 [ORDER FLOW EXEMPTION: VŨ KHÍ ĐỘNG] Bỏ qua STAND_ASIDE dòng lệnh cho {symbol} "
                                    f"({final_signal.metadata.get('weapon_code', 'DYN')} — dùng khiên M1 OFI 75%% riêng)."
                                )
                            else:
                                logger.warning(
                                    f"🛡️ [ORDER FLOW VETO] Hủy mở lệnh {sig_side_val} {symbol}: "
                                    f"{of_res.get('reason')} (Scenario: {of_res.get('scenario')})"
                                )
                                self._record_veto(
                                    symbol,
                                    'ORDER_FLOW_VETO',
                                    'LONG' if sig_side_val == 'BUY' else 'SHORT',
                                    f"{of_res.get('scenario')}: {of_res.get('reason')}",
                                    weapon_id=str(final_signal.metadata.get('weapon_id') or ''),
                                )
                                return None
                    elif of_res and of_res.get('scenario') in (
                        'BEARISH_ABSORPTION_FADING', 'BULLISH_ABSORPTION_BOUNCE',
                        'WATERFALL_DUMP_CONFIRMED', 'MOMENTUM_RIDE_CONFIRMED',
                        'MOMENTUM_RIDE_CONTINUATION', 'WATERFALL_DUMP_CONTINUATION'
                    ):
                        scen = of_res.get('scenario')
                        final_signal.metadata['order_flow_scenario'] = scen
                        # [BOM #103C FIX]: KHONG de Order Flow Confirmed ghi de is_fading_short / is_oversold_bounce
                        # len Vu Khi Dong (VK11 - vi pham BOM #100) hoac danh trao VK8 TrendFollowing thanh VK4/VK6!
                        _cur_t_of = str(final_signal.metadata.get('type') or '').upper()
                        _is_dyn_of = bool(final_signal.metadata.get('is_dynamic_weapon'))
                        _is_rev_ctx_of = any(k in _cur_t_of for k in ('TRAP', 'CLIMAX', 'FADING', 'BOUNCE', 'EXHAUSTION'))
                        if not _is_dyn_of and _is_rev_ctx_of:
                            if scen == 'BEARISH_ABSORPTION_FADING' and 'BULL_TRAP' not in _cur_t_of:
                                final_signal.metadata['is_fading_short'] = True
                                final_signal.metadata['type'] = final_signal.metadata.get('type') or 'BEARISH_ABSORPTION_FADING'
                            elif scen == 'BULLISH_ABSORPTION_BOUNCE' and 'BEAR_TRAP' not in _cur_t_of:
                                final_signal.metadata['is_oversold_bounce'] = True
                                final_signal.metadata['type'] = final_signal.metadata.get('type') or 'BULLISH_ABSORPTION_BOUNCE'
                        logger.info(f"🌊 [ORDER FLOW CONFIRMED] {symbol} {sig_side_val}: {of_res.get('reason')}")
                except Exception as of_err:
                    logger.debug(f"Bỏ qua Order Flow Matrix cho {symbol}: {of_err}")

        # [V5.5 FALLBACK METADATA VI CẤU TRÚC ĐỒNG BỘ 100% CHO CÁC TẦNG DƯỚI]:
        if final_signal and isinstance(getattr(final_signal, 'metadata', None), dict):
            final_signal.metadata.setdefault('c_recent_pump_pct', float(c_recent_pump))
            final_signal.metadata.setdefault('c_recent_dump_pct', float(c_recent_dump))
            final_signal.metadata.setdefault('c_upper_wick_pct', float(c_upper_wick_pct))
            final_signal.metadata.setdefault('c_lower_wick_pct', float(c_lower_wick_pct))
            final_signal.metadata.setdefault('c_vol_ratio', float(c_vol_ratio))

        # [ĐỒNG BỘ SSOT VỚI M1 SNIPER]: Chặn sớm các lệnh quá bán (SELL khi RSI 15M <= 30.0)
        # hoặc quá mua (BUY khi RSI 15M >= 70.0) ngay tại Aggregator, tránh lọt qua Quantum Gate
        # và gọi API set leverage thừa lên sàn Binance.
        if final_signal and final_signal.signal in (Signal.BUY, Signal.SELL):
            sig_side = 'BUY' if final_signal.signal == Signal.BUY else 'SELL'
            curr_rsi_15m = float((macro_analysis or {}).get('tactical_rsi') or (macro_analysis or {}).get('rsi_15m') or (macro_analysis or {}).get('rsi') or 50.0)
            is_wf_short = bool(final_signal.metadata.get('is_waterfall_short') or (trap_ctx and trap_ctx.get('is_waterfall_dump')))
            # [BOM #131B FIX]: Tách cờ dòng tiền cá mập VẬT LÝ (_is_true_wp_storm / _is_true_wf_dump) khỏi nhãn archetype vũ khí động
            # để BOM #127D (RSI > 72 mua đuổi) hoạt động thật 100% trên VK11/VK14/VK15 thay vì bị is_wp_buy=True vô hiệu hóa!
            _is_true_wp_storm = bool(
                final_signal.metadata.get('is_momentum_ride')
                or final_signal.metadata.get('is_parabolic_long_inversion')
                or final_signal.metadata.get('is_whale_pump_buy')
                or (trap_ctx and trap_ctx.get('is_whale_pump_storm'))
            )
            _is_true_wf_dump = is_wf_short
            has_trap_sell = bool(
                final_signal.metadata.get('type') in ('BULL_TRAP_WICK', 'BUYING_CLIMAX')
                or final_signal.metadata.get('is_fading_short')
                or final_signal.metadata.get('is_vk9_climax_wick_short')
            )
            is_wp_buy = _is_true_wp_storm
            has_trap_buy = bool(
                final_signal.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
                or final_signal.metadata.get('is_oversold_bounce')
                or final_signal.metadata.get('is_vk10_tradfi_bottom_long')
            )
            
            # [BOM #134 FIX]: Không hardcode mã động biến đổi `VK12`; dùng thuộc tính bất biến `dyn_pathway_family == 'MEANREV_BUY'`!
            _is_dyn_meanrev_short_inv = (
                bool(final_signal.metadata.get('is_dynamic_weapon'))
                and (
                    str(final_signal.metadata.get('dyn_pathway_family') or '').upper() == 'MEANREV_BUY'
                    or 'MEANREV_BUY' in str(final_signal.metadata.get('dyn_source_signature') or '').upper()
                )
            )
            if sig_side == 'SELL' and curr_rsi_15m <= 30.0 and not (_is_true_wf_dump or has_trap_sell or _is_dyn_meanrev_short_inv):
                logger.warning(
                    f"🛡️ [TẦNG 3 - TỪ CHỐI AN TOÀN] Hủy mở lệnh BÁN {symbol}: "
                    f"RSI 15M ({curr_rsi_15m:.1f} <= 30.0) đang quá bán! Cấm bán đáy cản tàu."
                )
                self._record_veto(symbol, 'RSI_OVERSOLD_VETO', 'SHORT', f'RSI={curr_rsi_15m:.1f}<=30', weapon_id=str(final_signal.metadata.get('weapon_id') or ''))
                return None
            elif sig_side == 'BUY' and curr_rsi_15m >= 70.0 and not (_is_true_wp_storm or has_trap_buy or bool(final_signal.metadata.get('is_dynamic_weapon'))):
                logger.warning(
                    f"🛡️ [TẦNG 3 - TỪ CHỐI AN TOÀN] Hủy mở lệnh MUA {symbol}: "
                    f"RSI 15M ({curr_rsi_15m:.1f} >= 70.0) đang quá mua! Cấm mua đỉnh FOMO."
                )
                self._record_veto(symbol, 'RSI_OVERBOUGHT_VETO', 'LONG', f'RSI={curr_rsi_15m:.1f}>=70', weapon_id=str(final_signal.metadata.get('weapon_id') or ''))
                return None

            # [BOM #101F + #101B + #103A/C]: ĐỊNH DANH VŨ KHÍ + KHÓA VÒNG ĐỜI PAUSED/LAB + KHIÊN DNA GIẢM SL OOS-VERIFIED
            # Tách biệt cổng vòng đời (is_weapon_enabled_for_live) & Khiên DNA ra khỏi khối telemetry; fail-closed nếu lỗi phân loại!
            w_dir = 'LONG' if sig_side == 'BUY' else 'SHORT'
            w_info = None
            try:
                from core.vietnamese_weapon_arsenal import (
                    classify_signal_weapon, get_weapon_priority_profile, record_pipeline_step
                )
                w_info = classify_signal_weapon(signal_obj=final_signal, meta=final_signal.metadata, direction=w_dir)
            except Exception as _w_cls_err:
                logger.warning(f"⚠️ [BOM #103C FAIL-CLOSED] Lỗi định danh vũ khí cho {symbol} ({w_dir}): {_w_cls_err} -> Hủy an toàn!")
                return None

            if isinstance(w_info, dict) and w_info.get('id'):
                _w_id_curr = str(w_info['id'])
                _w_code_curr = str(w_info.get('code') or '')
                try:
                    from core.quant_evolution_engine import is_weapon_enabled_for_live
                    _w_live_ok = is_weapon_enabled_for_live(_w_id_curr)
                except Exception as _lc_err:
                    logger.warning(f"⚠️ [BOM #103C] Không đọc được vòng đời vũ khí {_w_id_curr}: {_lc_err} -> Fail-closed!")
                    _w_live_ok = False

                if not _w_live_ok:
                    logger.info(
                        f"⏸️ [VÒNG ĐỜI VŨ KHÍ - TẠM TẮT/HẠ LAB] Hủy mở lệnh {symbol} ({w_dir}): "
                        f"Vũ khí {w_info.get('short_name', _w_id_curr)} đang được người dùng tạm tắt hoặc hạ về phòng thí nghiệm!"
                    )
                    self._record_veto(
                        symbol,
                        'WEAPON_PAUSED_LIFECYCLE',
                        w_dir,
                        f"Vũ khí {_w_code_curr} ({_w_id_curr}) đang PAUSED/LAB_DEMOTED",
                        weapon_id=_w_id_curr,
                    )
                    return None

                # [BOM #101B + #103A FIX — KHIÊN DNA GIẢM SL OOS 70/30 + FALSE EXITS = 0 TRÊN TỪNG VŨ KHÍ]:
                # Fix triệt để 3 lỗi đơn vị/khung giờ: (1) _dna_atr ưu tiên tactical_atr_pct 15M & chia 100 khi >= 0.08 (đóng dead-zone 0.0085..0.50);
                # (2) _dna_adx fallback tactical_adx cho coin mới; (3) _dna_rvol dùng `is not None` chống ép 0.0 -> 1.0!
                _dna_macro = macro_analysis if isinstance(macro_analysis, dict) else {}
                _dna_meta = final_signal.metadata if isinstance(final_signal.metadata, dict) else {}
                _dna_uw = float(_dna_meta.get('c_upper_wick_pct') if _dna_meta.get('c_upper_wick_pct') is not None else (_dna_macro.get('upper_wick_pct') if _dna_macro.get('upper_wick_pct') is not None else (c_upper_wick_pct or 0.0)))
                _dna_lw = float(_dna_meta.get('c_lower_wick_pct') if _dna_meta.get('c_lower_wick_pct') is not None else (_dna_macro.get('lower_wick_pct') if _dna_macro.get('lower_wick_pct') is not None else (c_lower_wick_pct or 0.0)))
                if _dna_uw > 1.0:
                    _dna_uw /= 100.0
                if _dna_lw > 1.0:
                    _dna_lw /= 100.0
                _dna_adx = float(_dna_macro.get('adx') or _dna_macro.get('tactical_adx') or _dna_meta.get('adx') or 0.0)
                # [BOM #131B + BOM #145 FIX]: Ưu tiên tuyệt đối tactical_atr_pct (15m, đơn vị %) để KHÔNG bị 4H atr_pct che mù TRADFI_DEAD_ATR (<0.32%);
                # chỉ fallback sang atr_pct của metadata khi thiếu tactical_atr_pct (và loại bỏ dead-zone < 0.08)!
                _dna_atr_15m_raw = _dna_macro.get('tactical_atr_pct')
                if _dna_atr_15m_raw is not None and float(_dna_atr_15m_raw or 0.0) > 0:
                    _dna_atr = float(_dna_atr_15m_raw) / 100.0
                elif _dna_meta.get('tactical_atr_pct') is not None and float(_dna_meta.get('tactical_atr_pct') or 0.0) > 0:
                    _dna_atr = float(_dna_meta.get('tactical_atr_pct')) / 100.0
                elif _dna_meta.get('atr_pct') is not None and float(_dna_meta.get('atr_pct') or 0.0) > 0:
                    _dna_atr = float(_dna_meta.get('atr_pct'))
                    if _dna_atr >= 0.08:
                        _dna_atr /= 100.0
                elif _dna_macro.get('atr_pct') is not None and float(_dna_macro.get('atr_pct') or 0.0) > 0:
                    _dna_atr = float(_dna_macro.get('atr_pct')) / 100.0
                else:
                    _dna_atr = 0.0
                _rv_raw_103 = _dna_meta.get('c_vol_ratio')
                if _rv_raw_103 is None:
                    _rv_raw_103 = _dna_macro.get('candle_vol_ratio')
                if _rv_raw_103 is None:
                    _rv_raw_103 = next(
                        (
                            (getattr(s, 'metadata', None) or {}).get('c_vol_ratio')
                            for s in (signals or [])
                            if isinstance(getattr(s, 'metadata', None), dict)
                            and (getattr(s, 'metadata', None) or {}).get('c_vol_ratio') is not None
                        ),
                        None,
                    )
                if _rv_raw_103 is None:
                    _rv_raw_103 = c_vol_ratio
                _dna_rvol = float(_rv_raw_103) if _rv_raw_103 is not None else 1.0
                _dna_jev = float((trap_ctx or {}).get('orig_jev_vote') or _dna_meta.get('orig_jev_vote') or 0.0)
                _dna_ai = float((trap_ctx or {}).get('orig_ai_vote') or _dna_meta.get('orig_ai_vote') or ai_vote_agg or 0.0)
                _dna_ac = str(_dna_meta.get('asset_class') or ('TRADFI' if is_tradfi else ('ALTCOIN' if is_crypto_altcoin else 'MAJOR'))).upper()
                if any(tok in _dna_ac for tok in ('TRADFI', 'STOCK', 'ETF', 'COMMODITY', 'GOLD', 'OIL')):
                    _dna_ac = 'TRADFI'
                elif 'MAJOR' in _dna_ac or 'TIER1' in _dna_ac:
                    _dna_ac = 'MAJOR'
                else:
                    _dna_ac = 'ALTCOIN'
                _dna_veto_reason = None

                if _w_id_curr == 'VK1_LONG_THUAN_SONG_CA_MAP':
                    # OOS 30%: SL% 12.0% -> 0.0%, Net +37.14$ (PF 1.68), khớp SSOT T1 ĐK 1.4 ADX>=20
                    # [BOM #140 FIX - PHÁP Y AIOT/USDT -$1.03]: Chặn VK1 mua đuổi đỉnh blow-off Altcoin (Pump>=10% & RSI>=70) hoặc nến râu dưới bất thường >=40%!
                    _dna_pump_vk1 = float(_dna_meta.get('c_recent_pump_pct') or _dna_macro.get('recent_pump_pct') or c_recent_pump or 0.0)
                    if _dna_pump_vk1 > 1.0:
                        _dna_pump_vk1 /= 100.0
                    _dna_rsi_vk1 = float(_dna_macro.get('tactical_rsi') or _dna_macro.get('rsi_15m') or _dna_macro.get('rsi') or current_rsi or 50.0)
                    if _dna_adx > 0.0 and _dna_adx < 20.0:
                        _dna_veto_reason = f"VK1_ADX_DEAD_CHOP (ADX={_dna_adx:.1f} < 20.0)"
                    elif _dna_ac == 'ALTCOIN' and _dna_rsi_vk1 >= 71.0:
                        _dna_veto_reason = f"VK1_ALT_RSI_OVERBOUGHT (RSI={_dna_rsi_vk1:.1f} >= 71.0)"
                    elif _dna_ac == 'ALTCOIN' and _dna_pump_vk1 >= 0.10 and _dna_rsi_vk1 >= 70.0:
                        _dna_veto_reason = f"VK1_PARABOLIC_BLOWOFF (Pump={_dna_pump_vk1*100:.1f}%, RSI={_dna_rsi_vk1:.1f})"
                    elif _dna_lw >= 0.40:
                        _dna_veto_reason = f"VK1_EXCESS_LOWER_WICK (LW={_dna_lw*100:.1f}% >= 40%)"
                elif _w_id_curr == 'VK2_LONG_LAT_NGUOC_SONG_PARABOL':
                    # OOS 30%: SL% 28.6% -> 25.0%, giảm 50% lỗ, khớp SSOT T1 ADX>=20
                    if _dna_adx > 0.0 and _dna_adx < 20.0:
                        _dna_veto_reason = f"VK2_ADX_DEAD_CHOP (ADX={_dna_adx:.1f} < 20.0)"
                elif _w_id_curr == 'VK3_LONG_SAN_RU_GOM_DAY':
                    # Full History PC1+PC2: SL 34.8% -> 15.9% (-33 SLs), Net -45.30$ -> +6.39$ (PF 1.30), 0 live False Exits
                    if _dna_jev <= -0.70:
                        _dna_veto_reason = f"VK3_COUNTER_JEV4H_SELL (JEV={_dna_jev:+.2f})"
                    elif _dna_uw >= 0.28 and _dna_lw >= 0.28:
                        _dna_veto_reason = f"VK3_TWIN_WICK_TRAP (U={_dna_uw*100:.0f}%, L={_dna_lw*100:.0f}%)"
                    elif _dna_adx > 0.0 and _dna_adx < 18.0:
                        _dna_veto_reason = f"VK3_ADX_WEAK (ADX={_dna_adx:.1f} < 18.0)"
                    elif _dna_ac == 'ALTCOIN' and _dna_atr > 0.0 and _dna_atr < 0.0085:
                        _dna_veto_reason = f"VK3_ALT_DEAD_ATR (ATR={_dna_atr*100:.2f}% < 0.85%)"
                elif _w_id_curr == 'VK4_LONG_BAT_NAY_QUA_BAN':
                    # Full History PC1+PC2 + BOM #119A + BOM #120C + BOM #121H: Miễn AI SELL khi đã qua cổng Macro Dual-Brain / ExhaustionBounce hợp lệ, giữ chặn cứng VK4 thường (PUMP/AGT)
                    _vk4_rvol_min = 0.85 if 'TRADFI' in _dna_ac else (1.00 if 'MAJOR' in _dna_ac else 1.10)
                    _vk4_ai_popped_ok = bool((trap_ctx or {}).get('ai_popped_by_macro_dual_brain')) or bool((trap_ctx or {}).get('ai_popped_by_exhaustion_long'))
                    if _dna_rvol < _vk4_rvol_min:
                        _dna_veto_reason = f"VK4_LOW_RVOL (RVol={_dna_rvol:.2f}x < {_vk4_rvol_min:.2f}x)"
                    elif _dna_lw < 0.35:
                        _dna_veto_reason = f"VK4_FALLING_KNIFE_NO_WICK (L_Wick={_dna_lw*100:.1f}% < 35%)"
                    elif _dna_uw >= 0.25:
                        _dna_veto_reason = f"VK4_UPPER_REJECT_WICK (U_Wick={_dna_uw*100:.1f}% >= 25%)"
                    elif _dna_ai <= -0.60 and not _vk4_ai_popped_ok:
                        _dna_veto_reason = f"VK4_COUNTER_AI_SELL (AI={_dna_ai:+.2f} <= -0.60)"
                    elif _dna_jev <= -0.70:
                        _dna_veto_reason = f"VK4_COUNTER_JEV4H_SELL (JEV={_dna_jev:+.2f} <= -0.70)"
                    elif curr_rsi_15m > 50.0:
                        _dna_veto_reason = f"VK4_NOT_OVERSOLD_RSI (RSI={curr_rsi_15m:.1f} > 50.0)"
                    elif _dna_adx > 0.0 and _dna_adx < 20.0:
                        _dna_veto_reason = f"VK4_ADX_WEAK (ADX={_dna_adx:.1f} < 20.0)"
                elif _w_id_curr == 'VK5_SHORT_THAC_DO_CA_MAP_XA':
                    # [BOM #102G FIX]: VK5 trên MAJOR (BTC/ETH/SOL/BNB/XRP) hay bị kéo V-bottom (WR 16.7%, SL 41.7%, Net -6.53$)
                    # -> Chỉ cho phép VK5 MAJOR khi hội tụ cực mạnh (RVol >= 2.2x + JEV SELL + AI SELL); giữ nguyên ALTCOIN & TRADFI (+5.0$ PF 1.84)!
                    if _dna_ac == 'MAJOR' and not (_dna_rvol >= 2.20 and _dna_jev <= -0.70 and _dna_ai <= -0.50):
                        _dna_veto_reason = f"VK5_MAJOR_VBOTTOM_GUARD (RVol={_dna_rvol:.2f}x, JEV={_dna_jev:+.2f}, AI={_dna_ai:+.2f})"
                elif _w_id_curr == 'VK6_SHORT_BAT_DINH_KIET_SUC':
                    # Full History PC1+PC2 + BOM #102G + BOM #119A + BOM #141 (Pháp y OPG/USDT):
                    # Chặn bán đáy nhịp chỉnh (Dump >= 3.5% & Dump >= 1.5x Pump & RSI < 45) mang nhãn nhầm "Bán Đỉnh Sóng Bơm"!
                    _vk6_rvol_min = 0.85 if 'TRADFI' in _dna_ac else (1.00 if 'MAJOR' in _dna_ac else 1.10)
                    _dna_pump_vk6 = float(_dna_meta.get('c_recent_pump_pct') or _dna_macro.get('recent_pump_pct') or c_recent_pump or 0.0)
                    _dna_dump_vk6 = float(_dna_meta.get('c_recent_dump_pct') or _dna_macro.get('recent_dump_pct') or c_recent_dump or 0.0)
                    if _dna_pump_vk6 > 1.0:
                        _dna_pump_vk6 /= 100.0
                    if _dna_dump_vk6 > 1.0:
                        _dna_dump_vk6 /= 100.0
                    if _dna_rvol < _vk6_rvol_min:
                        _dna_veto_reason = f"VK6_LOW_RVOL (RVol={_dna_rvol:.2f}x < {_vk6_rvol_min:.2f}x)"
                    elif _dna_uw < 0.45:
                        _dna_veto_reason = f"VK6_WEAK_UPPER_WICK (U_Wick={_dna_uw*100:.1f}% < 45%)"
                    elif _dna_lw >= 0.25:
                        _dna_veto_reason = f"VK6_TWIN_WICK_SUPPORT (L_Wick={_dna_lw*100:.1f}% >= 25%)"
                    elif curr_rsi_15m < 40.0 or curr_rsi_15m > 68.0:
                        _dna_veto_reason = f"VK6_RSI_OUT_OF_BAND (RSI={curr_rsi_15m:.1f} ngoài [40..68])"
                    elif _dna_dump_vk6 >= max(0.035, _dna_pump_vk6 * 1.50) and curr_rsi_15m < 45.0:
                        _dna_veto_reason = f"VK6_PULLBACK_BOTTOM_SHORT (Dump={_dna_dump_vk6*100:.1f}% vs Pump={_dna_pump_vk6*100:.1f}%, RSI={curr_rsi_15m:.1f})"
                    elif _dna_adx > 0.0 and _dna_adx < 18.0:
                        _dna_veto_reason = f"VK6_ADX_WEAK (ADX={_dna_adx:.1f} < 18.0)"
                    elif _dna_ac == 'ALTCOIN' and _dna_jev >= 0.70:
                        _dna_veto_reason = f"VK6_ALT_COUNTER_JEV4H_BUY (JEV={_dna_jev:+.2f})"
                elif _w_id_curr == 'VK7_SHORT_BAY_TANG_GIA_RAU_XA':
                    # [BOM #102G + BOM #119A FIX]: Phân tách 3 lớp tài sản + sàn RVol 3 lớp tài sản
                    _vk7_rvol_min = 0.85 if 'TRADFI' in _dna_ac else (1.00 if 'MAJOR' in _dna_ac else 1.10)
                    if _dna_rvol < _vk7_rvol_min:
                        _dna_veto_reason = f"VK7_LOW_RVOL (RVol={_dna_rvol:.2f}x < {_vk7_rvol_min:.2f}x)"
                    elif _dna_ac == 'MAJOR' and not (_dna_uw >= 0.55 and _dna_lw < 0.20 and _dna_jev <= -0.70 and _dna_ai <= -0.50):
                        _dna_veto_reason = f"VK7_MAJOR_STOPHUNT_GUARD (UW={_dna_uw*100:.0f}%, LW={_dna_lw*100:.0f}%, JEV={_dna_jev:+.2f}, AI={_dna_ai:+.2f})"
                    elif _dna_ac == 'ALTCOIN' and _dna_jev >= 0.70:
                        _dna_veto_reason = f"VK7_ALT_COUNTER_JEV4H_BUY (JEV={_dna_jev:+.2f})"
                elif _w_id_curr == 'VK8_THUAN_XU_HUONG_DA_KHUNG':
                    # Gia cố sẵn nếu người dùng mở lại VK8 sau này: SL 18.0%->15.5% (-23 SLs), Net -33.55$ -> +3.93$ (PF 1.17)
                    _vk8_rvol_min = 0.85 if 'TRADFI' in _dna_ac else (1.00 if 'MAJOR' in _dna_ac else 1.25)
                    if _dna_rvol < _vk8_rvol_min:
                        _dna_veto_reason = f"VK8_LOW_RVOL (RVol={_dna_rvol:.2f}x < {_vk8_rvol_min:.2f}x)"
                    elif curr_rsi_15m < 33.0 or curr_rsi_15m > 68.0:
                        _dna_veto_reason = f"VK8_RSI_EXTREME (RSI={curr_rsi_15m:.1f} ngoài [33..68])"
                    elif (w_dir == 'LONG' and _dna_jev <= -0.70) or (w_dir == 'SHORT' and _dna_jev >= 0.70):
                        _dna_veto_reason = f"VK8_COUNTER_JEV4H (dir={w_dir}, JEV={_dna_jev:+.2f})"
                elif bool(_dna_meta.get('is_dynamic_weapon')) or (_w_code_curr.startswith('VK') and _w_code_curr[2:].isdigit() and int(_w_code_curr[2:]) >= 11):
                    # [BOM #127D + #134 + #138 FIX]: Sàn an toàn DNA phổ quát cho mọi Vũ Khí Động (VK11..VK15+),
                    # thay toàn bộ hardcode mã biến đổi bằng thuộc tính bất biến (pathway_family + side + archetype),
                    # chặn Twin-Wick 2 chiều (LONG & SHORT) và chặn đảo ngược TRAP_SELL->LONG khi râu xả đỉnh >= 50% hoặc strong_downtrend + UW >= 40%!
                    _dyn_rvol_min = 0.85 if 'TRADFI' in _dna_ac else (1.00 if 'MAJOR' in _dna_ac else 1.05)
                    _dyn_fam_dna = str(_dna_meta.get('dyn_pathway_family') or '').upper()
                    _dyn_sig_dna = str(_dna_meta.get('dyn_source_signature') or '').upper()
                    _dyn_arch_dna = str(_dna_meta.get('quantum_archetype') or '').upper()
                    _dyn_regime_dna = str(_dna_macro.get('regime') or '').lower()
                    _is_dyn_meanrev_short_dna = (w_dir == 'SHORT') and (_dyn_fam_dna == 'MEANREV_BUY' or 'MEANREV_BUY' in _dyn_sig_dna)
                    _is_dyn_trap_clx_short_dna = (w_dir == 'SHORT') and (_dyn_fam_dna == 'TRAP_SELL' or 'TRAP_SELL' in _dyn_sig_dna) and (_dyn_arch_dna == 'CLIMAX_REVERSAL')
                    _is_dyn_trap_sell_long_dna = (w_dir == 'LONG') and (_dyn_fam_dna == 'TRAP_SELL' or 'TRAP_SELL' in _dyn_sig_dna)
                    if _dna_ac == 'ALTCOIN' and _dna_adx > 0.0 and _dna_adx < 18.0:
                        _dna_veto_reason = f"{_w_code_curr}_ADX_DEAD_CHOP (ADX={_dna_adx:.1f} < 18.0)"
                    elif _dna_rvol < _dyn_rvol_min:
                        _dna_veto_reason = f"{_w_code_curr}_LOW_RVOL (RVol={_dna_rvol:.2f}x < {_dyn_rvol_min:.2f}x)"
                    elif _dna_uw >= 0.28 and _dna_lw >= 0.28:
                        _dna_veto_reason = f"{_w_code_curr}_TWIN_WICK_TRAP (U={_dna_uw*100:.0f}%, L={_dna_lw*100:.0f}%)"
                    elif _is_dyn_trap_sell_long_dna and (_dna_uw >= 0.50 or (_dyn_regime_dna == 'strong_downtrend' and _dna_uw >= 0.40)):
                        _dna_veto_reason = f"{_w_code_curr}_LONG_INTO_DISTRIBUTION_WICK (UW={_dna_uw*100:.1f}%, Regime={_dyn_regime_dna or 'unknown'})"
                    elif w_dir == 'SHORT' and curr_rsi_15m < (20.0 if _is_dyn_meanrev_short_dna else 40.0) and not _is_true_wf_dump:
                        _dna_veto_reason = f"{_w_code_curr}_SHORT_OVERSOLD_CHASE (RSI={curr_rsi_15m:.1f} < {'20.0' if _is_dyn_meanrev_short_dna else '40.0'})"
                    elif w_dir == 'LONG' and curr_rsi_15m > 72.0 and not _is_true_wp_storm:
                        _dna_veto_reason = f"{_w_code_curr}_LONG_OVERBOUGHT_CHASE (RSI={curr_rsi_15m:.1f} > 72.0)"
                    elif _is_dyn_trap_clx_short_dna and (_dna_uw < 0.40 or _dna_lw >= 0.25):
                        _dna_veto_reason = f"{_w_code_curr}_WEAK_REJECTION_DNA (UW={_dna_uw*100:.1f}%, LW={_dna_lw*100:.1f}%)"

                # [BOM #130 FIX — R4 FULL-HISTORY 4,929-SAMPLE ALTCOIN SHORT SHIELD]:
                # Chứng minh trên 100% lịch sử (596 lệnh đóng thực tế + 4,929 bản ghi Full-History):
                # Chặn 2 hố đen lỗ Altcoin SHORT trên MỌI vũ khí (VK5/VK6/VK7/VK8/VK9/VK11..VK15+):
                # (1) Quá mua RSI 15M >= 68.0 -> cứu +13.49$ (596 lệnh đóng) / +191.16$ (4,929 mẫu)
                # (2) Cản tàu siêu bơm Pump >= 6.0% nhưng thiếu râu xả cực đại (U_Wick < 65%) -> giữ nguyên đỉnh kiệt sức cực đại UW >= 65% (VK9) & vùng ngon VK6 (3.5%..6.0%)
                # Kết hợp R4: lật Altcoin SHORT vị thế đóng từ -14.30$ -> +11.63$ (+25.94$, WR 66.5%) & cắt -91.8% lỗ (-282.61$ -> -23.05$, cứu +259.56$) trên 4,929 mẫu!
                if (not _dna_veto_reason) and _dna_ac == 'ALTCOIN' and w_dir == 'SHORT':
                    _dna_pump_candidates = []
                    for _p_raw_130 in (_dna_meta.get('c_recent_pump_pct'), _dna_macro.get('recent_pump_pct'), c_recent_pump):
                        if _p_raw_130 is not None:
                            try:
                                _p_val_130 = float(_p_raw_130)
                                if _p_val_130 > 1.0:
                                    _p_val_130 /= 100.0
                                _dna_pump_candidates.append(_p_val_130)
                            except Exception:
                                pass
                    _dna_pump = max(_dna_pump_candidates) if _dna_pump_candidates else 0.0
                    if curr_rsi_15m >= 68.0:
                        _dna_veto_reason = f"{_w_code_curr}_ALT_SHORT_OVERBOUGHT_RSI (RSI={curr_rsi_15m:.1f} >= 68.0)"
                    elif _dna_pump >= 0.060 and _dna_uw < 0.65:
                        _dna_veto_reason = f"{_w_code_curr}_ALT_SHORT_PARABOLIC_PUMP (Pump={_dna_pump*100:.1f}% >= 6.0%, U_Wick={_dna_uw*100:.1f}% < 65%)"

                # [BOM #144-TINY FIX — ZERO-FALSE-BLOCK SURGICAL GUARDS (135 LIVE POSITIONS + 6-TF VERIFIED)]:
                # 1. ALTCOIN LONG Blow-Off Exhaustion (RVol >= 8.0x & RSI >= 71.0): 0/75 lệnh thắng LIVE bị mất, chặn ca AIOT (-$1.03) trên mọi vũ khí kể cả khi lọt qua Bear Trap Wick!
                # 2. TRADFI Dead-ATR Floor (0 < ATR 15M < 0.32%): 0/12 lệnh thắng TradFi bị mất (giữ nguyên XAG 0.335%, CL 0.37%, ETF 3x), chặn biên độ chết BZ (0.28%-0.305%)!
                if (not _dna_veto_reason) and _dna_ac == 'ALTCOIN' and w_dir == 'LONG':
                    if _dna_rvol >= 8.0 and curr_rsi_15m >= 71.0:
                        _dna_veto_reason = (
                            f"{_w_code_curr}_ALT_LONG_BLOWOFF_EXHAUSTION "
                            f"(RVol={_dna_rvol:.2f}x >= 8.0x, RSI={curr_rsi_15m:.1f} >= 71.0)"
                        )
                if (not _dna_veto_reason) and _dna_ac == 'TRADFI':
                    if 0.0 < _dna_atr < 0.0032:
                        _dna_veto_reason = (
                            f"{_w_code_curr}_TRADFI_DEAD_ATR "
                            f"(ATR={_dna_atr*100:.2f}% < 0.32%)"
                        )

                if _dna_veto_reason:
                    logger.warning(
                        f"🛡️ [BOM #101B KHIÊN DNA GIẢM SL - {_w_code_curr}] Hủy mở lệnh {symbol} ({w_dir}): {_dna_veto_reason}"
                    )
                    # [BOM #126B FIX]: Truyền weapon_id=_w_id_curr để Shadow Pathfinder không phân loại nhầm (ca IRYS VK6->VK8)!
                    self._record_veto(symbol, f"BOM101_WEAPON_DNA_{_w_code_curr}", w_dir, _dna_veto_reason, weapon_id=_w_id_curr)
                    return None

                # [BOM #103C FIX]: Ghi ngay weapon_id/code/name TRƯỚC khi gọi get_weapon_priority_profile (SQLite)
                # để lỗi khóa DB thoáng qua KHÔNG BAO GIỜ làm mất weapon_id trên lệnh rình M1 (BOM #101F)!
                final_signal.metadata['weapon_id'] = _w_id_curr
                final_signal.metadata['weapon_code'] = _w_code_curr
                final_signal.metadata['weapon_name_vi'] = w_info['short_name']
                final_signal.metadata['weapon_icon'] = w_info['icon']
                try:
                    w_prio = get_weapon_priority_profile(_w_id_curr)
                    w_mult = float(w_prio['adaptive_weight_mult']) if w_prio.get('adaptive_weight_mult') is not None else 1.0
                    w_mode = str(w_prio.get('adaptive_mode') or 'SAN_SANG_MAC_DINH')

                    final_signal.metadata['weapon_priority_mult'] = w_mult
                    final_signal.metadata['weapon_adaptive_mode'] = w_mode
                    logger.info(
                        f"⚔️ [TẦNG 3 - RÚT VŨ KHÍ] {symbol} ({w_dir}): {w_info['icon']} {w_info['short_name']} "
                        f"[{w_prio.get('adaptive_badge_vi')} | Độ tự tin={final_signal.confidence*100:.1f}%]"
                    )
                    # [BOM #149 P1-14 FIX]: Bỏ qua ghi live_pipeline_trace.json khi đang chạy Cổng 6 Dry-Run Offline!
                    from core.quant_evolution_engine import is_dry_run_telemetry_suppressed
                    if not is_dry_run_telemetry_suppressed():
                        record_pipeline_step(
                            stage_num=3,
                            symbol=symbol,
                            status='PASSED',
                            title_vi=f"Duyệt {w_info['short_name']}",
                            detail_vi=w_info['target_goal_vi'],
                            direction=w_dir,
                            weapon_id=_w_id_curr,
                            branch_vi=w_info['group_vi'],
                        )
                except Exception:
                    pass

        return final_signal if final_signal.signal != Signal.HOLD else None



