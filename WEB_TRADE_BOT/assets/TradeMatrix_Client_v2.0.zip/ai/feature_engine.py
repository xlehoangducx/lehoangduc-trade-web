import pandas as pd
import ta
import numpy as np
from sklearn.preprocessing import StandardScaler
import logging
from typing import Tuple

logger = logging.getLogger(__name__)

class FeatureEngine:
    """
    Tạo các đặc trưng (features) từ dữ liệu OHLCV để huấn luyện mô hình ML.
    (Generates features from OHLCV data for ML model training)
    """
    def __init__(self):
        self.scaler = StandardScaler()
        self.is_fitted = False
        
    def generate_features(self, df: pd.DataFrame, is_training: bool = True) -> pd.DataFrame:
        """
        Tạo 30+ chỉ báo kỹ thuật và chuẩn hóa dữ liệu.
        (Generate 30+ technical indicators and scale data)
        """
        try:
            # Tạo bản sao để không ảnh hưởng dữ liệu gốc
            df_feat = df.copy()
            
            # --- Technical Indicators ---
            # Không điền NaN warm-up trước dropna: SMA/EMA 200 từ vài nến đầu
            # không tương đương chỉ báo đủ 200 nến và sẽ làm bẩn train/CV.
            df_feat = ta.add_all_ta_features(df_feat, open='open', high='high', low='low', close='close', volume='volume', fillna=False)
            
            df_feat['volume_sma_20'] = df_feat['volume'].rolling(window=20).mean()
            
            # Khối lượng trung bình có trọng số theo giá (VWAP approximation)
            typical_price = (df_feat['high'] + df_feat['low'] + df_feat['close']) / 3
            df_feat['vwap_approx'] = (typical_price * df_feat['volume']).cumsum() / df_feat['volume'].cumsum()
            
            # --- Custom Price Features ---
            df_feat['price_change_pct'] = df_feat['close'].pct_change()
            df_feat['high_low_range'] = (df_feat['high'] - df_feat['low']) / df_feat['close']
            
            # Tính tỷ lệ thân nến (candle body ratio)
            candle_body = abs(df_feat['close'] - df_feat['open'])
            candle_range = df_feat['high'] - df_feat['low']
            # Tránh chia cho 0
            df_feat['candle_body_ratio'] = np.where(candle_range == 0, 0, candle_body / candle_range)
            
            # Chỉ bắt buộc đủ dữ liệu cho các chỉ báo lõi. Một số cột phụ của TA
            # (PSAR...) có thể NaN trên toàn bộ series; dropna() trên MỌI cột sẽ
            # xóa sạch cả dataset 500 nến hợp lệ.
            warmup_cols = [
                col for col in (
                    'trend_ema_long', 'trend_ema_medium', 'trend_sma_slow',
                    'momentum_rsi', 'volatility_atr', 'volume_sma_20',
                ) if col in df_feat.columns
            ]
            if warmup_cols:
                df_feat.dropna(subset=warmup_cols, inplace=True)
            # Bảo đảm vùng warm-up dài nhất (200 nến) không lọt vào train/CV,
            # kể cả khi phiên bản TA không tạo cột EMA200 riêng.
            if len(df_feat) >= 200:
                df_feat = df_feat.iloc[200:].copy()
            
            if df_feat.empty:
                logger.warning("Data is empty after dropping NaNs. Need more historical data.")
                return df_feat
                
            # Tách biệt features để chuẩn hóa (không chuẩn hóa open, high, low, close, volume nguyên gốc)
            # Chỉ lấy các cột do pandas_ta và custom features tạo ra
            feature_cols = [col for col in df_feat.columns if col not in ['open', 'high', 'low', 'close', 'volume', 'timestamp', 'datetime', 'date']]
            
            X = df_feat[feature_cols]
            
            # Thay thế các giá trị vô cùng bằng NaN rồi fill
            X = X.replace([np.inf, -np.inf], np.nan)
            # fillna thay cho inplace b/c behavior depends on pandas version
            X = X.ffill().fillna(0)
            
            # Data đã được điền NaN, trả về nguyên bản (chuẩn hóa sẽ thực hiện trong ml_model.py Pipeline)
            result_df = pd.concat([df_feat[['open', 'high', 'low', 'close', 'volume']], X], axis=1)
                

            
            logger.info(f"Generated {len(feature_cols)} features successfully.")
            return result_df
            
        except Exception as e:
            logger.error(f"Error generating features: {e}")
            raise
