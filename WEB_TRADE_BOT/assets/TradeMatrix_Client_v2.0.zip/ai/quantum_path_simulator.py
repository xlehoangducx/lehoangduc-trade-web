"""

Quantum-Inspired Dual-Engine Path Simulator for Algorithmic Trade Validation (v2.0).



Kiến trúc Lượng tử Kép (Dual-Engine Quantum Matrix):

1. NHÁNH CRYPTO PERPETUALS:

   - Mô phỏng Quantum Random Walk 2.500 đường đi giá trong 40 nến tương lai (Hệ quy chiếu Thuận chiều Lệnh).

   - Vướng víu Lượng tử với Bitcoin (BTC Quantum Entanglement Coupling): Phản xạ ngoại lực BTC lên Altcoin chuẩn dấu cho cả LONG và SHORT.

   - Bất đối xứng Thanh khoản & Squeeze (Funding Rate Skew & Liquidity Jump): Mô phỏng rủi ro Short Squeeze / Long Flush.

   - Phễu Biến động Nở rộng (Dynamic Volatility Expansion): Nở rộng ATR khi bứt phá xu hướng.



2. NHÁNH CHỨNG KHOÁN MỸ & ETF TRADFI (223 mã trên Binance):

   - Nhận diện tự động mã Cổ phiếu / ETF Mỹ (NVDA, TSLA, SOXL, SOXS, SNDK...).

   - Bào mòn Toán học Đòn bẩy Đảo chiều (Leveraged ETF Volatility Drag): Trừ hệ số suy giảm cơ học

     khi thị trường sideway (đặc trị bẫy thua lỗ SOXS).

   - Hệ số Phiên Wall Street (Off-Hours Liquidity & Spread Penalty): Phạt râu nến ảo ngoài giờ 20:30 - 03:00 VN.

   - Mô phỏng Nhảy Gap Qua Đêm & Cuối Tuần (Overnight & Weekend Gap Jump Risk).



Đo lường đầu ra:

- P(Win): Xác suất chạm Take-Profit trước khi chạm Stop-Loss.

- P(Loss): Xác suất chạm Stop-Loss trước (hoặc cùng bước nến) khi chạm Take-Profit.

- P(DOA): Xác suất ứ đọng vốn không chạm cả hai (Dead-on-Arrival / Capital Stagnation).

- E[EV]: Kỳ vọng lợi nhuận thuần túy sau phí sàn 2 đầu.

- Leverage Multiplier: Đề xuất đòn bẩy động dựa trên độ chắc chắn lượng tử.

"""



import math

import time

import zlib

from typing import Dict, Any, Optional, List

import numpy as np



try:

    from core.scanner import MarketScanner

except ImportError:

    MarketScanner = None





def _safe_float(val: Any, default: float = 0.0) -> float:

    """Chuyển đổi float an toàn, chống NaN / Inf."""

    try:

        f = float(val)

        return f if math.isfinite(f) else default

    except (TypeError, ValueError):

        return default





class QuantumPathSimulator:

    """Quantum-Inspired Monte Carlo & Quantum Walk Path Simulator for High-Frequency Pre-Trade Validation (Dual-Engine v2.0)."""



    KNOWN_INVERSE_ETFS = {"SOXS", "SQQQ", "SPXU", "SDOW", "YANG", "KOLD", "DUST", "FAZ", "TECS", "LABD"}

    KNOWN_BULL_ETFS = {

        "SOXL", "TQQQ", "UPRO", "UDOW", "YINN", "BOIL", "NUGT", "FAS", "TECL", "LABU",

        "NVDL", "TSLL", "MSTU", "MSTX", "CONL", "KORU",

    }



    def __init__(

        self,

        n_paths: int = 2500,

        n_steps: int = 40,

        min_win_prob: float = 0.0,

        max_doa_prob: float = 0.40,

        min_ev_pct: float = 0.0,

        edge_margin: float = 0.10,

    ):

        """

        Args:

            n_paths: Số lượng đường đi mô phỏng đồng thời (vectorized qua NumPy).

            n_steps: Số nến dự phóng tương lai (40 nến 15m ~ 10 giờ tác chiến).

            min_win_prob: Sàn cứng P(Win) tối thiểu (0.0 = tắt; cổng chính dùng EV).

            max_doa_prob: Ngưỡng rủi ro ứ đọng vốn tối đa cho phép (40%).

            min_ev_pct: Kỳ vọng lợi nhuận thuần tối thiểu (tỷ lệ, 0.0 = phải dương sau phí).

            edge_margin: Biên lợi thế yêu cầu so với điểm hòa vốn (0.10 = +10%).

        """

        self.n_paths = int(n_paths)

        self.n_steps = int(n_steps)

        self.min_win_prob = float(min_win_prob)

        self.max_doa_prob = float(max_doa_prob)

        raw_min_ev = float(min_ev_pct)

        # [B?I H?C 102]: Kh?c ph?c ?i?m bi?n >= 0.05 kh?ng b? ?p nh?m th?nh 5%
        if raw_min_ev > 1.0:
            self.min_ev_pct = raw_min_ev / 100.0
        elif raw_min_ev >= 0.05:
            self.min_ev_pct = raw_min_ev / 100.0
        else:
            self.min_ev_pct = raw_min_ev

        self.edge_margin = max(0.0, float(edge_margin))



    @classmethod

    def classify_asset(cls, symbol: str, exchange=None) -> str:

        """Phân loại tài sản: TRADFI_LEVERAGED_ETF, TRADFI_STOCK, TRADFI_COMMODITY, CRYPTO_MAJOR, hoặc CRYPTO_PERPETUAL."""

        if not symbol:

            return "CRYPTO_PERPETUAL"

        clean = str(symbol).split(":")[0].upper().replace("/", "")

        base = clean

        for quote in ("USDT", "USDC", "BUSD", "USD"):

            if base.endswith(quote) and len(base) > len(quote):

                base = base[: -len(quote)]

                break



        if base in cls.KNOWN_INVERSE_ETFS or base in cls.KNOWN_BULL_ETFS:

            return "TRADFI_LEVERAGED_ETF"



        if MarketScanner is not None and hasattr(MarketScanner, "is_tradfi_commodity"):

            try:

                if MarketScanner.is_tradfi_commodity(symbol, exchange):

                    return "TRADFI_COMMODITY"

            except Exception:

                pass



        if MarketScanner is not None and hasattr(MarketScanner, "is_tradfi_stock"):

            try:

                if MarketScanner.is_tradfi_stock(symbol, exchange):

                    return "TRADFI_STOCK"

            except Exception:

                pass



        if MarketScanner is not None and hasattr(MarketScanner, "KNOWN_TRADFI_BASES"):

            if base in MarketScanner.KNOWN_TRADFI_BASES and (not hasattr(MarketScanner, 'KNOWN_COMMODITY_BASES') or base not in MarketScanner.KNOWN_COMMODITY_BASES):

                return "TRADFI_STOCK"



        known_stocks = {

            "NVDA", "TSLA", "AAPL", "MSFT", "AMZN", "GOOGL", "SNDK",

            "AMD", "PLTR", "COIN", "MSTR", "INTC", "META", "NFLX", "BABA",

            "ON", "MU", "SNXX", "MRVL", "SKHY", "CRWD", "ARM", "DELL",

        }

        if base in known_stocks:

            return "TRADFI_STOCK"



        if base in ("BTC", "ETH", "SOL", "BNB", "XRP"):

            return "CRYPTO_MAJOR"



        return "CRYPTO_PERPETUAL"



    def _classify_asset(self, symbol: str, exchange=None) -> str:

        return self.classify_asset(symbol, exchange)



    @staticmethod

    def _analytical_barrier_first_passage(mu: float, sigma: float, sl_dist: float, tp_dist: float) -> float:

        """

        [BÀI HỌC 98 - NGHIỆM ĐÓNG BLACK-SCHOLES DOUBLE-BARRIER FIRST PASSAGE TIME]

        Giải tích chính xác xác suất P(T_TP < T_SL) cho vi phân ngẫu nhiên dX_t = mu*dt + sigma*dW_t.

        Triệt tiêu hoàn toàn sai số mẫu ngẫu nhiên (sampling variance) của Monte Carlo trên các tài sản biến động cao.

        """

        if abs(mu) < 1e-7:

            return sl_dist / (tp_dist + sl_dist) if (tp_dist + sl_dist) > 0 else 0.5

        gamma = 2.0 * mu / (sigma ** 2) if sigma > 1e-6 else 0.0

        gamma = float(np.clip(gamma, -35.0, 35.0))

        num = 1.0 - math.exp(-gamma * sl_dist)

        den = 1.0 - math.exp(-gamma * (tp_dist + sl_dist))

        if abs(den) < 1e-9:

            return sl_dist / (tp_dist + sl_dist) if (tp_dist + sl_dist) > 0 else 0.5

        return float(np.clip(num / den, 0.01, 0.99))



    @staticmethod

    def _calculate_delta(mu: float, sigma: float, n_steps: int = 40) -> float:

        """

        [BÀI HỌC 98 - HỆ SỐ DELTA N(d1) ĐỊNH GIÁ QUYỀN CHỌN ĐỘNG LƯỢNG]

        Tính độ nhạy Delta N(d1) của vị thế (xác suất động lượng tiến sâu vào vùng In-The-Money).

        Dùng để định quy mô vốn động (Dynamic Delta Sizing Multiplier).

        """

        t = n_steps * (15.0 / 1440.0)

        vol = max(1e-5, sigma * math.sqrt(n_steps))

        d1 = (mu * t + 0.5 * (vol ** 2)) / vol

        return float(0.5 * (1.0 + math.erf(d1 / math.sqrt(2.0))))



    def simulate(

        self,

        symbol: str,

        side: str,

        entry_price: float,

        stop_loss: float,

        take_profit: float,

        atr_pct: float,

        adx: float = 30.0,

        score: float = 0.70,

        regime: str = "uptrend",

        fee_rate: float = 0.0005,

        btc_bias: str = "NEUTRAL",

        funding_rate: float = 0.0,

        is_us_open: Optional[bool] = None,

        is_weekend_gap: Optional[bool] = None,

        jev_verdict: Optional[str] = None,

        jev_risk: Optional[str] = None,

        jev_reason: Optional[str] = None,

        exchange: Any = None,

        metadata: Optional[Dict[str, Any]] = None,

    ) -> Dict[str, Any]:

        """Chạy mô phỏng lượng tử đường đi giá trong tương lai với kiến trúc Dual-Engine.



        Toàn bộ phép toán dịch chuyển được chuẩn hóa trên Hệ Quy Chiếu Thuận Chiều Lệnh (Trade-Relative Frame):

        - Chiều dương (+): Giá đi về phía Take-Profit (có lợi cho vị thế, bất kể LONG hay SHORT).

        - Chiều âm (-): Giá đi về phía Stop-Loss (bất lợi cho vị thế).

        """

        t0 = time.perf_counter()



        entry_price = _safe_float(entry_price, 0.0)

        if entry_price <= 0:

            return {

                "symbol": symbol,

                "side": side,

                "asset_class": "UNKNOWN",

                "p_win": 0.0,

                "p_loss": 1.0,

                "p_doa": 0.0,

                "expected_ev_pct": -100.0,

                "reward_risk_ratio": 0.0,

                "pass_gate": False,

                "confidence_tier": "QUANTUM_VETO",

                "leverage_multiplier": 0.0,

                "veto_reasons": ["LỖI_GIÁ_VÀO_KHÔNG_HỢP_LỆ"],

                "time_taken_ms": 0.0,

                "paths_simulated": self.n_paths,

            }



        is_buy = str(side).upper() in ("BUY", "LONG")

        default_sl = entry_price * (0.97 if is_buy else 1.03)

        default_tp = entry_price * (1.06 if is_buy else 0.94)



        stop_loss = _safe_float(stop_loss, default_sl)

        if stop_loss <= 0:

            stop_loss = default_sl

        take_profit = _safe_float(take_profit, default_tp)

        if take_profit <= 0:

            take_profit = default_tp



        atr_pct = _safe_float(atr_pct, 2.5)

        if atr_pct <= 0:

            atr_pct = 2.5

        adx = _safe_float(adx, 25.0)

        if adx <= 0:

            adx = 25.0

        # Độ tự tin (confidence) luôn chuẩn hóa dương trong hệ quy chiếu thuận chiều lệnh

        confidence = abs(_safe_float(score, 0.70))

        fee_rate = max(0.0, _safe_float(fee_rate, 0.0005))

        funding_rate = _safe_float(funding_rate, 0.0)



        asset_class = self._classify_asset(symbol, exchange)

        clean_base = str(symbol).split(":")[0].upper().replace("/", "")

        for q_suffix in ("USDT", "USDC", "BUSD", "USD"):

            if clean_base.endswith(q_suffix) and len(clean_base) > len(q_suffix):

                clean_base = clean_base[: -len(q_suffix)]

                break



        # Khoảng cách tương đối (%) đến TP và SL

        if is_buy:

            tp_dist = max(0.002, (take_profit - entry_price) / entry_price)

            sl_dist = max(0.002, (entry_price - stop_loss) / entry_price)

        else:

            tp_dist = max(0.002, (entry_price - take_profit) / entry_price)

            sl_dist = max(0.002, (stop_loss - entry_price) / entry_price)



        # 1. THIẾT LẬP PHA LƯỢNG TỬ (QUANTUM PHASE ANGLE θ TRONG HỆ QUY CHIẾU THUẬN CHIỀU LỆNH)

        # θ > pi/4: Giao thoa tăng cường về phía Take-Profit

        # θ < pi/4: Giao thoa triệt tiêu về phía Stop-Loss

        adx_factor = float(np.clip(adx / 35.0, 0.4, 2.0))

        theta = (math.pi / 4.0) + (confidence * 0.28 * min(1.5, adx_factor))



        veto_reasons: List[str] = []

        context_notes: List[str] = []

        favorable_drift_bias = 0.0



        # =========================================================================

        # A. NHÁNH CRYPTO: VƯỚNG VÍU BTC & LỆCH PHA FUNDING RATE

        # =========================================================================

        if asset_class in ("CRYPTO_PERPETUAL", "CRYPTO_MAJOR"):

            is_btc = "BTC" in clean_base

            if not is_btc and btc_bias:

                bias_upper = str(btc_bias).upper()

                if bias_upper == "BULLISH":

                    if is_buy:

                        theta += 0.08  # LONG Altcoin thuận nhịp BTC Bullish -> Tăng cường

                    else:

                        # Nếu là tín hiệu Smart Inversion / Buying Climax độ tự tin cao (>= 82%), giảm một nửa mức phạt ngược nhịp BTC

                        theta -= 0.08 if confidence >= 0.82 else 0.16

                elif bias_upper == "BEARISH":

                    if not is_buy:

                        theta += 0.08  # SHORT Altcoin thuận nhịp BTC Bearish -> Tăng cường

                    else:

                        theta -= 0.09 if confidence >= 0.82 else 0.18  # LONG Altcoin bắt đáy ngược nhịp BTC Bearish



            # Lệch pha Funding Rate (Chuẩn dấu cho cả LONG và SHORT):

            if funding_rate < -0.0003:  # Funding âm sâu -> Phe Short quá đông -> Áp lực Short Squeeze bật tăng

                if is_buy:

                    theta += 0.06

                    favorable_drift_bias += 0.0008

                else:

                    theta -= 0.10

                    favorable_drift_bias -= 0.0012

            elif funding_rate > 0.0005:  # Funding dương cao -> Phe Long quá đông -> Áp lực Long Flush sập râu

                if is_buy:

                    theta -= 0.10

                    favorable_drift_bias -= 0.0012

                else:

                    theta += 0.06

                    favorable_drift_bias += 0.0008



        # =========================================================================

        # B. NHÁNH TRADFI CHỨNG KHOÁN MỸ & ETF: BÀO MÒN DECAY, PHIÊN MỸ & NHẢY GAP

        # =========================================================================

        session_vol_mult = 1.0

        jump_prob = 0.06

        jump_scale = 1.6



        if asset_class in ("TRADFI_STOCK", "TRADFI_LEVERAGED_ETF", "TRADFI_COMMODITY"):

            # 1. Kiểm tra trạng thái phiên Wall Street (20:30 - 03:00 VN) - chỉ áp dụng cho Cổ phiếu & ETF

            if asset_class in ("TRADFI_STOCK", "TRADFI_LEVERAGED_ETF"):

                if is_us_open is None:

                    if MarketScanner is not None and hasattr(MarketScanner, "is_us_market_open"):

                        try:

                            is_us_open = MarketScanner.is_us_market_open()

                        except Exception:

                            is_us_open = False

                    else:

                        is_us_open = False



                if not is_us_open:

                    # Ngoài giờ phiên Mỹ: Thanh khoản mỏng, spread giãn, râu nến ảo dễ quét SL

                    session_vol_mult = 1.35

                    jump_prob = 0.09



            # 2. Kiểm tra Rủi ro Nhảy Gap Cuối Tuần / Qua Đêm (Weekend & Overnight Gap Jump) cho cả Cổ phiếu, ETF & Hàng hóa

            if is_weekend_gap is None:

                if MarketScanner is not None and hasattr(MarketScanner, "is_weekend_gap_risk_window"):

                    try:

                        is_weekend_gap = MarketScanner.is_weekend_gap_risk_window(symbol=symbol)

                    except Exception:

                        is_weekend_gap = False

                else:

                    is_weekend_gap = False



            if is_weekend_gap:

                # Sát giờ đóng cửa phiên Thứ 6 hoặc trong cuối tuần: Rủi ro nhảy Gap mở phiên Thứ 2

                session_vol_mult *= 1.25

                jump_prob = max(jump_prob, 0.14)

                jump_scale = 2.2

                theta -= 0.08



            # 3. Xử lý Bào mòn Toán học ETF (Leveraged ETF Volatility Drag):

            if asset_class == "TRADFI_LEVERAGED_ETF":

                is_inverse = clean_base in self.KNOWN_INVERSE_ETFS

                beta = -3.0 if is_inverse else 3.0

                sigma_est = (atr_pct / 100.0) / math.sqrt(4.0)



                # Khi thị trường đi ngang (ADX < 32) hoặc tín hiệu yếu (confidence < 0.65):

                # Giá trị nội tại của ETF đòn bẩy tự suy giảm theo phương sai: mu_drag = -0.5 * (beta^2 - |beta|) * sigma^2

                if adx < 32.0 or confidence < 0.65:

                    drag_magnitude = 0.5 * (beta ** 2 - abs(beta)) * (sigma_est ** 2) * 2.5

                    if is_buy:

                        # Mua nắm giữ ETF đòn bẩy khi thị trường cù cưa sẽ bị bào mòn giá trực tiếp về phía SL

                        favorable_drift_bias -= drag_magnitude

                        theta -= 0.15

                        if is_inverse:

                            veto_reasons.append(f"BÀO_MÒN_ETF_ĐẢO_CHIỀU_{clean_base}(ADX={adx:.1f}<32)")

                    else:

                        # Short ETF đảo chiều vẫn chịu rủi ro giật râu cao nếu ADX yếu

                        if is_inverse and adx < 25.0:

                            theta -= 0.08



        # =========================================================================

        # C. HIỆU ỨNG MARKET REGIME & XUNG LỰC ĐA KHUNG (MARKET REGIME QUANTUM COUPLING)

        # =========================================================================

        regime_norm = str(regime or '').lower()

        if regime_norm in ('ranging', 'consolidation', 'choppy', 'sideway'):

            # Thị trường đi ngang/nén biên độ: Triệt tiêu gia tốc thuận chiều, tăng xác suất quét 2 đầu

            theta -= 0.14

            favorable_drift_bias -= 0.0012

            context_notes.append(f"THỊ_TRƯỜNG_RANGING_ĐI_NGANG({regime_norm.upper()})")

            if adx < 25.0:

                theta -= 0.06

                favorable_drift_bias -= 0.0006

        elif regime_norm in ('strong_downtrend', 'downtrend'):

            if is_buy:

                # Đánh ngược sóng giảm mạnh: Nếu là tín hiệu Smart Inversion / Climax độ tự tin cao (>= 82%),

                # giảm một nửa mức phạt trễ pha 4H để khơi thông lệnh bắt đáy Selling Climax / Momentum Ride!

                if confidence >= 0.82:

                    theta -= 0.08

                    favorable_drift_bias -= 0.0006

                else:

                    theta -= 0.18

                    favorable_drift_bias -= 0.0015

                context_notes.append(f"NGƯỢC_XU_HƯỚNG_GIẢM({regime_norm.upper()})")

            else:

                # Thuận sóng giảm mạnh: Tăng cường pha lượng tử

                theta += 0.06

                favorable_drift_bias += 0.0005

        elif regime_norm in ('strong_uptrend', 'uptrend'):

            if not is_buy:

                # Đánh ngược sóng tăng mạnh: Nếu là tín hiệu Smart Inversion / Buying Climax Pha 2 (>= 82%),

                # giảm một nửa mức phạt trễ pha 4H để khơi thông lệnh SHORT đỉnh cá mập (như EVAA/USDT)!

                if confidence >= 0.82:

                    theta -= 0.08

                    favorable_drift_bias -= 0.0006

                else:

                    theta -= 0.18

                    favorable_drift_bias -= 0.0015

                context_notes.append(f"NGƯỢC_XU_HƯỚNG_TĂNG({regime_norm.upper()})")

            else:

                # Thuận sóng tăng mạnh: Tăng cường pha lượng tử

                theta += 0.06

                favorable_drift_bias += 0.0005



        # =========================================================================

        # D. TÍCH HỢP BẢO VỆ AI JEV AGENT (JEV MULTI-TIMEFRAME RISK COUPLING)

        # =========================================================================

        if jev_verdict and str(jev_verdict).upper() == 'HOLD':

            j_risk = (str(jev_risk or '') + " " + str(jev_reason or '')).lower()

            if any(w in j_risk for w in ('consolidation', 'choppy', 'volume exhaustion', 'conflicting', 'no clear breakout', 'overbought')):

                theta -= 0.12

                favorable_drift_bias -= 0.0010

                context_notes.append("JEV_AI_CẢNH_BÁO_RỦI_RO_NÉN_GIÁ")



        # Kẹp góc pha theta an toàn trong khoảng (0.10, pi/2 - 0.10)

        theta = float(np.clip(theta, 0.10, math.pi / 2.0 - 0.10))



        # Biên độ xác suất lượng tử thuận chiều (forward) và ngược chiều (adverse)

        p_forward = math.sin(theta) ** 2

        p_adverse = math.cos(theta) ** 2



        # Chuẩn hóa biến động 15m với hệ số phiên giao dịch

        sigma_step = ((atr_pct / 100.0) / math.sqrt(4.0)) * session_vol_mult



        # Lực đẩy định hướng kỳ vọng thuận chiều lệnh (Trade-Favorable Quantum Drift).

        #

        # [SỬA LỖI GỐC RỄ] Trước đây drift được cộng vào TỪNG nến trong n_steps nến mà không

        # chuẩn hóa, nên TỔNG drift tích lũy = n_steps × drift_mỗi_nến. Với ATR 1% - 6% và

        # confidence 0.5 - 0.9, tổng drift đạt 6.4% - 38.2%, tức gấp 1.4 - 5.5 lần khoảng cách

        # TP. Hệ quả: mọi đường đi Monte Carlo đều chạm TP, P(Win) bị bão hòa theo score,

        # P(DOA) luôn bằng 0 -> cổng thẩm định mất hoàn toàn năng lực phân biệt.

        # Nay chuẩn hóa bằng 1/sqrt(n_steps) để TỔNG drift cùng bậc với TỔNG sigma.

        drift_normalizer = 1.0 / math.sqrt(max(1, self.n_steps))

        favorable_quantum_drift = (

            ((p_forward - p_adverse) * sigma_step * 0.85) + favorable_drift_bias

        ) * drift_normalizer



        # 2. KHUẾCH TÁN LƯỢNG TỬ ĐỒNG THỜI (VECTORIZED QUANTUM JUMP-DIFFUSION)

        # Tạo seed tất định bằng CRC32 tránh va chạm ở các đồng coin mệnh giá nhỏ (PEPE, SHIB, BONK...)

        seed_str = f"{clean_base}:{is_buy}:{entry_price:.8f}:{adx:.2f}:{confidence:.4f}"

        seed_val = zlib.crc32(seed_str.encode("utf-8")) & 0x7FFFFFFF

        rng = np.random.RandomState(seed_val)



        random_shocks = rng.standard_normal((self.n_paths, self.n_steps))



        # Phễu biến động nở rộng (Dynamic Volatility Expansion): nếu ADX > 35, 8 nến đầu bung biên độ +25%

        if adx > 35.0:

            step_weights = np.ones((1, self.n_steps))

            step_weights[:, : min(8, self.n_steps)] = 1.25

            scaled_sigma = sigma_step * step_weights

        else:

            scaled_sigma = sigma_step



        # Bước dịch chuyển thuận chiều lệnh trên từng nến

        favorable_step_returns = favorable_quantum_drift + (scaled_sigma * random_shocks)



        # Cú nhảy quét thanh khoản Poisson Jump Process

        jump_mask = rng.random_sample((self.n_paths, self.n_steps)) < jump_prob

        jump_magnitudes = rng.standard_normal((self.n_paths, self.n_steps)) * (scaled_sigma * jump_scale)

        favorable_step_returns = np.where(jump_mask, favorable_step_returns + jump_magnitudes, favorable_step_returns)



        # Tích lũy đường đi (Cumulative Returns thuận chiều lệnh: + là tiến tới TP, - là lùi về SL)

        cum_returns = np.cumsum(favorable_step_returns, axis=1)



        # 3. XÁC ĐỊNH SỰ KIỆN CHẠM TP, SL VÀ DOA

        hit_tp_mask = cum_returns >= tp_dist

        hit_sl_mask = cum_returns <= -sl_dist



        has_hit_tp = np.any(hit_tp_mask, axis=1)

        has_hit_sl = np.any(hit_sl_mask, axis=1)



        first_tp_step = np.where(has_hit_tp, np.argmax(hit_tp_mask, axis=1), self.n_steps + 1)

        first_sl_step = np.where(has_hit_sl, np.argmax(hit_sl_mask, axis=1), self.n_steps + 1)



        # Thắng nếu chạm TP trước khi chạm SL

        win_paths = has_hit_tp & (first_tp_step < first_sl_step)

        # Thua nếu chạm SL trước hoặc cùng bước nến với TP (nguyên tắc quản trị rủi ro thận trọng, bảo toàn tổng xác suất = 1.0)

        loss_paths = has_hit_sl & (first_sl_step <= first_tp_step)

        # Cù cưa / Ứ đọng vốn (DOA) nếu không chạm cả 2 trong suốt n_steps

        doa_paths = (~has_hit_tp) & (~has_hit_sl)



        p_win = float(np.sum(win_paths) / self.n_paths)

        p_loss = float(np.sum(loss_paths) / self.n_paths)

        p_doa = float(np.sum(doa_paths) / self.n_paths)



        # 4. KỲ VỌNG LỢI NHUẬN THUẦN TÚY (EXPECTED MONTE CARLO EV)

        total_fee_pct = fee_rate * 2.0

        expected_ev_pct = (p_win * tp_dist) - (p_loss * sl_dist) - total_fee_pct

        reward_risk_ratio = tp_dist / sl_dist if sl_dist > 0 else 1.0



        # [BÀI HỌC 95 - CHUẨN HÓA TOÁN HỌC QUANTUM RESOLVED WINRATE]:

        # Phân định rõ giữa xác suất thô (bị pha loãng bởi DOA) và xác suất phân định kết quả (Resolved Paths).

        # Tỷ lệ hòa vốn breakeven_win_prob chỉ có ý nghĩa trên không gian mẫu đã chạm TP hoặc SL.

        resolved_paths = p_win + p_loss

        p_win_resolved = (p_win / resolved_paths) if resolved_paths > 1e-6 else p_win



        # Điểm hòa vốn lý thuyết (win rate tối thiểu để EV = 0 trước phí) và mức yêu cầu

        # có biên lợi thế. Đây là ngưỡng THẬT SỰ có ý nghĩa kinh tế, thay cho mốc P(Win)

        # tuyệt đối 68% vốn chỉ đạt được nhờ drift bị thổi phồng.

        breakeven_win_prob = sl_dist / (tp_dist + sl_dist) if (tp_dist + sl_dist) > 0 else 0.5

        min_win_required = breakeven_win_prob * (1.0 + self.edge_margin)



        sigma_total_pct = sigma_step * math.sqrt(max(1, self.n_steps)) * 100.0

        drift_total_pct = favorable_quantum_drift * math.sqrt(max(1, self.n_steps)) * 100.0



        # [BÀI HỌC 98 - GIA CỐ LÕI SDE NGHIỆM ĐÓNG BLACK-SCHOLES & DYNAMIC DELTA SIZING]

        p_analytical = self._analytical_barrier_first_passage(

            favorable_quantum_drift, sigma_step, sl_dist, tp_dist

        )

        delta_factor = self._calculate_delta(favorable_quantum_drift, sigma_step, self.n_steps)

        p_win_dual = 0.50 * p_win_resolved + 0.50 * p_analytical



        # Tính delta_multiplier điều chỉnh quy mô Notional (0.75x đến 1.25x)

        if delta_factor >= 0.68:

            delta_multiplier = 1.25

        elif delta_factor <= 0.48:

            delta_multiplier = 0.75

        else:

            delta_multiplier = 1.00



        # 5. QUYẾT ĐỊNH CỔNG THẨM ĐỊNH LƯỢNG TỬ (TUÂN THỦ TÔN CHỈ THUẬN CÁ MẬP & EV DƯƠNG):

        # Bộ lọc SDE Barrier: Ngăn chặn bẫy sai số mẫu ngẫu nhiên (sampling variance) của Monte Carlo

        # trên các coin biến động cực lớn (như BOME sigma=3.66% P_analytical chỉ 33.17%)

        analytical_min_req = breakeven_win_prob * 1.025

        if p_analytical < analytical_min_req:

            gamma_ratio = (2.0 * favorable_quantum_drift) / ((sigma_step ** 2) + 1e-12)

            veto_reasons.append(

                f"SDE_BARRIER_EV_ÂM(P_analytical={p_analytical:.1%}<{analytical_min_req:.1%},gamma={gamma_ratio:.2f})"

            )



        if self.min_win_prob > 0.0 and p_win_resolved < self.min_win_prob:

            veto_reasons.append(f"XÁC_SUẤT_WIN_THẤP(P_resolved={p_win_resolved:.1%}<{self.min_win_prob:.1%})")

        _ev_pass = expected_ev_pct > self.min_ev_pct

        if p_win_resolved < min_win_required:

            if _ev_pass:

                context_notes.append(

                    f"X?C_SU?T_D??I_NG??NG_H?A_V?N({p_win_resolved:.1%}<{min_win_required:.1%})_NH?NG_EV_D??NG({expected_ev_pct*100:+.2f}%)"

                )

            else:

                veto_reasons.append(

                    f"X?C_SU?T_D??I_NG??NG_H?A_V?N(P_resolved={p_win_resolved:.1%}<{min_win_required:.1%})"

                )

        if not _ev_pass:

            veto_reasons.append(

                f"K?_V?NG_EV_KH?NG_??({expected_ev_pct*100:+.2f}%<={self.min_ev_pct*100:+.2f}%)"

            )

        # Chỉ VETO DOA khi rủi ro ứ đọng thực sự nghiêm trọng (> 60%) HOẶC khi EV không đủ bù rủi ro;

        # Nếu EV dương sau phí và p_win >= p_loss, DOA 40-50% đã được quản trị an toàn bởi DOA Watchdog (25m/120m).

        if p_doa > max(0.60, self.max_doa_prob * 1.5) or (expected_ev_pct <= self.min_ev_pct and p_doa > self.max_doa_prob):

            veto_reasons.append(f"RỦI_RO_Ứ_ĐỌNG_VỐN_DOA(P={p_doa:.1%}>{self.max_doa_prob:.1%})")




        # [BÀI HỌC 101 - CHỐT CHẶN BẤT ĐỐI XỨNG RỦI RO THUA LỖ (ASYMMETRIC LOSS VETO)]:
        # Chặn đứng bẫy toán học: Khi P(Loss) áp đảo P(Win) (như AXTI P_loss=53.6% gấp đôi P_win=25.2%),
        # dù R:R cao kéo EV hơi dương danh nghĩa, nhưng xác suất dính SL do nhiễu thị trường là áp đảo.
        # Cho phép nới lỏng nhẹ cho setup cá mập độ tự tin cao (confidence >= 0.85 & có JEV đồng thuận),
        # nhưng tuyệt đối VETO các lệnh có P(Loss) vượt trội và P(Win) thô quá thấp!
        # [BÀI HỌC 101, 106 & 107 - SMART QUANTUM FLOOR 40% & VERIFIED WHALE CLIMAX EXEMPTION]:
        # Phân biệt rõ:
        # 1. Với lệnh Trend Following / Breakout hoặc tín hiệu thiếu râu/xung lượng Climax vật lý:
        #    Bắt buộc P(Win) >= 40.0% (min_win_floor = 0.40) để triệt tiêu các lệnh đu đỉnh/đu đáy muộn
        #    hoặc đảo chiều non thiếu xác nhận (IDOL, AXTI, NEAR, ENA, PIEVERSE 32.3%, ICNT 37.9%, CAP#3 37.8%).
        # 2. Với lệnh Bắt Đỉnh/Đáy Cá Mập đã xác minh vật lý (Pha 2 Exhaustion Fading Short / Pha 1 Absorption Reversal
        #    có Râu thuận chiều >= 35% hoặc sóng Climax Pump/Dump >= 2.00% hoặc EV >= +0.40% QUANTUM_CONFIRMED):
        #    Miễn trừ sàn 40%, áp dụng min_win_floor = 0.28 bảo toàn 100% các lệnh thắng lớn FOGO, MON, BR, LA, CAP#1, ARIA, CAP#2!
        _md = metadata if isinstance(metadata, dict) else {}
        _u_wick = float(_md.get('c_upper_wick_pct', 0.0) or 0.0)
        _l_wick = float(_md.get('c_lower_wick_pct', 0.0) or 0.0)
        _pump_pct = float(_md.get('c_recent_pump_pct', 0.0) or 0.0)
        _dump_pct = float(_md.get('c_recent_dump_pct', 0.0) or 0.0)
        has_verified_physical_climax = (
            (_l_wick >= 0.35 or _dump_pct >= 0.020 or bool(_md.get('is_momentum_ride')))
            if is_buy
            else (_u_wick >= 0.35 or _pump_pct >= 0.020 or bool(_md.get('is_waterfall_short')))
        )
        is_whale_climax = has_verified_physical_climax and (
            bool(_md.get('is_fading_short'))
            or bool(_md.get('is_oversold_bounce'))
            or bool(_md.get('is_waterfall_short'))
            or bool(_md.get('is_momentum_ride'))
            or bool(_md.get('is_ai_absorption_buy'))
            or str(_md.get('type', '')).upper() in (
                'EXHAUSTION_FADING_SELL', 'PARABOLIC_EXHAUSTION_SHORT',
                'SMART_ABSORPTION_REVERSAL_BUY', 'PANIC_CLIMAX_BOUNCE',
                'BULL_TRAP_PUMP', 'BEAR_TRAP_DIP', 'BULL_TRAP_WICK', 'BEAR_TRAP_WICK'
            )
            or _u_wick >= 0.35
            or _l_wick >= 0.35
        )
        jev_agrees_dir = str(jev_verdict or '').upper() == ('BUY' if is_buy else 'SELL')
        is_high_conviction_whale = (confidence >= 0.85 and jev_agrees_dir and expected_ev_pct >= 0.0035)
        is_exempt_climax = is_high_conviction_whale or is_whale_climax
        max_loss_ratio = 1.85 if is_exempt_climax else 1.35
        min_win_floor = 0.28 if is_exempt_climax else 0.40

        if p_loss > p_win * max_loss_ratio:
            veto_reasons.append(
                f"RỦI_RO_THUA_ÁP_ĐẢO(P_loss={p_loss:.1%}>{max_loss_ratio:.2f}x P_win={p_win:.1%})"
            )
        if p_win < min_win_floor:
            veto_reasons.append(
                f"XÁC_SUẤT_WIN_THÔ_QUÁ_THẤP(P_win={p_win:.1%}<{min_win_floor:.1%})"
            )

        pass_gate = len(veto_reasons) == 0



        # Đề xuất đòn bẩy động: xếp hạng theo KỲ VỌNG EV sau phí (không dùng P(Win) bão hòa)

        ev_pct_rank = expected_ev_pct * 100.0

        if not pass_gate:

            leverage_mult = 0.00

            conf_tier = "QUANTUM_VETO"

        elif ev_pct_rank >= 1.50:

            leverage_mult = 1.25

            conf_tier = "QUANTUM_EXCELLENT"

        elif ev_pct_rank >= 0.50:

            leverage_mult = 1.00

            conf_tier = "QUANTUM_CONFIRMED"

        else:

            leverage_mult = 0.75

            conf_tier = "QUANTUM_MARGINAL"



        time_taken_ms = (time.perf_counter() - t0) * 1000.0



        return {

            "symbol": symbol,

            "side": side,

            "asset_class": asset_class,

            "p_win": round(p_win, 4),

            "p_win_resolved": round(p_win_resolved, 4),

            "p_analytical": round(p_analytical, 4),

            "p_win_dual": round(p_win_dual, 4),

            "delta_factor": round(delta_factor, 4),

            "delta_multiplier": delta_multiplier,

            "p_loss": round(p_loss, 4),

            "p_doa": round(p_doa, 4),

            "expected_ev_pct": round(expected_ev_pct * 100.0, 3),

            "reward_risk_ratio": round(reward_risk_ratio, 2),

            "breakeven_win_prob": round(breakeven_win_prob, 4),

            "min_win_required": round(min_win_required, 4),

            "sigma_total_pct": round(sigma_total_pct, 3),

            "drift_total_pct": round(drift_total_pct, 3),

            "pass_gate": pass_gate,

            "confidence_tier": conf_tier,

            "leverage_multiplier": leverage_mult,

            "veto_reasons": veto_reasons,

            "context_notes": context_notes,

            "time_taken_ms": round(time_taken_ms, 2),

            "paths_simulated": self.n_paths,

        }

