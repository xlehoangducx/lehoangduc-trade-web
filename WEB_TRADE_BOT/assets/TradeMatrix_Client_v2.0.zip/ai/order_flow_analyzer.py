# -*- coding: utf-8 -*-
"""
TRADEMATRIX ORDER FLOW & MICROSTRUCTURE ANALYZER
================================================
Module phân tích Dòng Lệnh Khớp Thực Tế (Order Flow / Tape Reading)
và Vi Cấu Trúc Sổ Lệnh (Order Book Depth / Statistical Z-Score Walls):

1. Đo lường Cumulative Volume Delta (CVD) từ luồng khớp lệnh thực tế (aggTrades).
2. Phân loại 4 Kịch bản Kép (CVD Matrix):
   - Kịch bản 1: Sóng Bơm Cá Mập (Whale Pump Storm) -> Taker Buy >= 65% + Nến xanh phá đỉnh.
   - Kịch bản 2: Bẫy Hấp Thụ Đỉnh (Bearish Absorption) -> Taker Buy >= 65% + Nến nghẽn tại cản, râu trên >= 35%.
   - Kịch bản 3: Sóng Xả Thác Đổ (Waterfall Breakdown) -> Taker Sell >= 65% + Nến đỏ thủng đáy.
   - Kịch bản 4: Bẫy Hấp Thụ Đáy (Bullish Absorption) -> Taker Sell >= 65% + Nến rút chân hỗ trợ, râu dưới >= 35%.
3. Gom cụm sổ lệnh chuẩn sàn (Tick Bucketing theo 1x, 10x, 100x tickSize).
4. Nhận diện Bức Tường Cá Mập bằng toán học Độ Lệch Chuẩn Z-Score (Z >= 3.0).
5. Đo lường Imbalance chuẩn hóa theo vùng 0.5 x ATR_15m.
"""

import math
import logging
import requests
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger(__name__)

import time
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class OrderFlowAnalyzer:
    """Bộ phân tích vi cấu trúc dòng lệnh và sổ lệnh chuẩn Quỹ Định Lượng."""

    def __init__(self, exchange=None):
        self.exchange = exchange
        self._market_info_cache: Dict[str, Dict[str, Any]] = {}
        # Persistent HTTP Session với Connection Pooling & Keep-Alive chống socket exhaustion
        self.session = requests.Session()
        retries = Retry(total=2, backoff_factor=0.2, status_forcelist=[500, 502, 503, 504])
        adapter = HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=retries)
        self.session.mount('https://', adapter)
        # Snapshot Cache (TTL 2.5s) tránh lặp lại request giữa signal_aggregator và pre_trade_gate
        self._delta_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
        self._depth_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}

    def get_order_flow_delta(self, symbol: str, limit: int = 100) -> Dict[str, Any]:
        """
        Đo lường Cumulative Volume Delta (CVD) từ 100-200 lệnh aggTrades gần nhất.
        Trả về cán cân Taker Buy vs Taker Sell và phân tích áp lực dòng tiền.
        """
        clean_sym = symbol.replace('/', '').split(':')[0].upper()
        default_res = {
            'taker_buy_vol': 0.0,
            'taker_sell_vol': 0.0,
            'total_vol': 0.0,
            'delta_vol': 0.0,
            'taker_buy_pct': 0.50,
            'taker_sell_pct': 0.50,
            'delta_pct': 0.0,
            'is_aggressive_buying': False,
            'is_aggressive_selling': False,
            'trade_count': 0
        }

        # Kiểm tra cache tươi (< 2.5s)
        now_ts = time.time()
        if hasattr(self, '_delta_cache') and clean_sym in self._delta_cache:
            cache_ts, cached_res = self._delta_cache[clean_sym]
            if now_ts - cache_ts < 2.5:
                return cached_res

        try:
            url = "https://fapi.binance.com/fapi/v1/aggTrades"
            http_client = getattr(self, 'session', requests)
            resp = http_client.get(url, params={'symbol': clean_sym, 'limit': limit}, timeout=3.0)
            if resp.status_code != 200:
                logger.debug(f"Không thể tải aggTrades cho {symbol}: HTTP {resp.status_code}")
                return default_res

            trades = resp.json()
            if not isinstance(trades, list) or not trades:
                return default_res

            taker_buy_vol = 0.0
            taker_sell_vol = 0.0
            taker_buy_cnt = 0
            taker_sell_cnt = 0

            for t in trades:
                qty = float(t.get('q', 0.0))
                px = float(t.get('p', 0.0))
                usd = qty * px
                # m: Was the buyer the maker?
                # If m is True: Buyer was passive maker -> Seller was aggressive taker (Taker Sell)
                # If m is False: Buyer was aggressive taker (Taker Buy)
                if t.get('m', False):
                    taker_sell_vol += usd
                    taker_sell_cnt += 1
                else:
                    taker_buy_vol += usd
                    taker_buy_cnt += 1

            total_vol = taker_buy_vol + taker_sell_vol
            delta_vol = taker_buy_vol - taker_sell_vol
            buy_pct = (taker_buy_vol / total_vol) if total_vol > 0 else 0.50
            sell_pct = (taker_sell_vol / total_vol) if total_vol > 0 else 0.50
            delta_pct = (delta_vol / total_vol) if total_vol > 0 else 0.0

            res_delta = {
                'taker_buy_vol': taker_buy_vol,
                'taker_sell_vol': taker_sell_vol,
                'total_vol': total_vol,
                'delta_vol': delta_vol,
                'taker_buy_pct': buy_pct,
                'taker_sell_pct': sell_pct,
                'delta_pct': delta_pct,
                'is_aggressive_buying': (buy_pct >= 0.65),
                'is_aggressive_selling': (sell_pct >= 0.65),
                'trade_count': len(trades)
            }
            if hasattr(self, '_delta_cache'):
                self._delta_cache[clean_sym] = (now_ts, res_delta)
            return res_delta
        except Exception as e:
            logger.debug(f"Lỗi phân tích Order Flow Delta cho {symbol}: {e}")
            return default_res

    def evaluate_order_flow_matrix(
        self,
        symbol: str,
        side: str,
        price_action_meta: Dict[str, Any],
        limit: int = 100
    ) -> Dict[str, Any]:
        """
        Đánh giá Ma Trận 4 Kịch Bản Kép (CVD + Price Action):
        - side: 'BUY' hoặc 'SELL'
        - price_action_meta: dict chứa adx, rvol, upper_wick_pct, lower_wick_pct, is_expanding
        """
        of_data = self.get_order_flow_delta(symbol, limit=limit)
        buy_pct = of_data['taker_buy_pct']
        sell_pct = of_data['taker_sell_pct']

        adx = float(price_action_meta.get('adx', 0.0) or 0.0)
        rvol = float(price_action_meta.get('rvol', 1.0) or 1.0)
        upper_wick = float(price_action_meta.get('upper_wick_pct', 0.0) or 0.0)
        lower_wick = float(price_action_meta.get('lower_wick_pct', 0.0) or 0.0)
        is_uptrend = bool(price_action_meta.get('is_uptrend', False))
        is_downtrend = bool(price_action_meta.get('is_downtrend', False))
        is_strong_trend = (adx >= 28.0)

        # 1. Chiều SELL / SHORT:
        if side.upper() in ('SELL', 'SHORT'):
            # Kịch bản 1: Sóng Bơm Cá Mập (Whale Pump Storm) -> CẤM SHORT!
            if buy_pct >= 0.65 and is_uptrend and upper_wick < 0.30 and rvol >= 1.6:
                return {
                    'allowed': False,
                    'scenario': 'WHALE_PUMP_STORM',
                    'action': 'INVERT_TO_BUY',
                    'reason': f"Phe Mua đang nhồi lệnh bão ({buy_pct*100:.1f}% Taker Buy) trong Uptrend mạnh (ADX={adx:.1f}). Cấm Short cản tàu, ưu tiên lật ngược Mua!"
                }
            # Kịch bản 2: Bẫy Hấp Thụ Đỉnh (Bearish Absorption) -> SHORT CỰC CHUẨN!
            elif buy_pct >= 0.60 and upper_wick >= 0.35:
                return {
                    'allowed': True,
                    'scenario': 'BEARISH_ABSORPTION_FADING',
                    'action': 'CONFIRM_SHORT',
                    'reason': f"Phát hiện Bẫy Hấp Thụ Đỉnh: Taker Buy FOMO ({buy_pct*100:.1f}%) nhưng bị cá mập xả limit hấp thụ (Râu trên={upper_wick*100:.1f}% >= 35%). Lệnh Short cực chuẩn!"
                }
            # Kịch bản 3: Sóng Xả Thác Đổ Thuận Trend -> SHORT CHUẨN!
            elif sell_pct >= 0.55:
                return {
                    'allowed': True,
                    'scenario': 'WATERFALL_DUMP_CONFIRMED',
                    'action': 'CONFIRM_SHORT',
                    'reason': f"Phe Bán đang chủ động xả hàng áp đảo ({sell_pct*100:.1f}% Taker Sell). Lệnh Short thuận dòng tiền!"
                }
            # Kịch bản Nhiễu: Taker Buy đang nhồi lệnh nhưng chưa có râu xác nhận
            elif buy_pct >= 0.60 and upper_wick < 0.35:
                return {
                    'allowed': False,
                    'scenario': 'UNCONFIRMED_RESISTANCE_TEST',
                    'action': 'STAND_ASIDE',
                    'reason': f"Phe Mua đang thử thách cản ({buy_pct*100:.1f}% Taker Buy) và chưa có râu từ chối (Râu trên={upper_wick*100:.1f}% < 35%). Kiên nhẫn chờ đỉnh!"
                }

        # 2. Chiều BUY / LONG:
        elif side.upper() in ('BUY', 'LONG'):
            # Kịch bản 3: Sóng Xả Thác Đổ (Waterfall Dump) -> CẤM BUY!
            if sell_pct >= 0.65 and is_downtrend and lower_wick < 0.30 and rvol >= 1.6:
                return {
                    'allowed': False,
                    'scenario': 'WHALE_WATERFALL_BREAKDOWN',
                    'action': 'INVERT_TO_SHORT',
                    'reason': f"Phe Bán đang xả tháo ồ ạt ({sell_pct*100:.1f}% Taker Sell) thủng đáy. Cấm bắt dao rơi, ưu tiên lật ngược Bán!"
                }
            # Kịch bản 4: Bẫy Hấp Thụ Đáy (Bullish Absorption) -> BUY CỰC CHUẨN!
            elif sell_pct >= 0.60 and lower_wick >= 0.35:
                return {
                    'allowed': True,
                    'scenario': 'BULLISH_ABSORPTION_BOUNCE',
                    'action': 'CONFIRM_BUY',
                    'reason': f"Phát hiện Bẫy Hấp Thụ Đáy: Taker Sell hoảng loạn ({sell_pct*100:.1f}%) nhưng được cá mập kê mua đỡ giá (Râu dưới={lower_wick*100:.1f}% >= 35%). Lệnh Buy hồi phục chuẩn!"
                }
            # Kịch bản Thuận Trend Bơm:
            elif buy_pct >= 0.55:
                return {
                    'allowed': True,
                    'scenario': 'MOMENTUM_RIDE_CONFIRMED',
                    'action': 'CONFIRM_BUY',
                    'reason': f"Phe Mua đang gom hàng áp đảo ({buy_pct*100:.1f}% Taker Buy). Lệnh Buy thuận dòng tiền!"
                }
            elif sell_pct >= 0.60 and lower_wick < 0.35:
                return {
                    'allowed': False,
                    'scenario': 'UNCONFIRMED_SUPPORT_TEST',
                    'action': 'STAND_ASIDE',
                    'reason': f"Phe Bán đang dìm giá ({sell_pct*100:.1f}% Taker Sell) và chưa có tín hiệu rút chân. Cấm vội vàng bắt đáy!"
                }

        return {
            'allowed': True,
            'scenario': 'NORMAL_FLOW',
            'action': 'PROCEED',
            'reason': f"Dòng tiền cân bằng (Buy={buy_pct*100:.1f}%, Sell={sell_pct*100:.1f}%). Cho phép thực thi bình thường."
        }

    def get_aggregated_order_book(self, symbol: str, limit: int = 100) -> Dict[str, Any]:
        """
        Gom cụm sổ lệnh theo bước giá chuẩn sàn (Tick Bucketing 10x, 100x)
        và nhận diện Bức Tường Cá Mập bằng toán học Độ Lệch Chuẩn Z-Score (Z >= 3.0).
        """
        clean_sym = symbol.replace('/', '').split(':')[0].upper()
        res = {
            'best_bid': 0.0,
            'best_ask': 0.0,
            'spread_pct': 0.0,
            'whale_ask_walls': [],
            'whale_bid_walls': [],
            'imbalance_ratio': 1.0,
            'total_bid_notional': 0.0,
            'total_ask_notional': 0.0
        }

        now_ts = time.time()
        if hasattr(self, '_depth_cache') and clean_sym in self._depth_cache:
            cache_ts, cached_res = self._depth_cache[clean_sym]
            if now_ts - cache_ts < 2.5:
                return cached_res

        try:
            url = "https://fapi.binance.com/fapi/v1/depth"
            http_client = getattr(self, 'session', requests)
            resp = http_client.get(url, params={'symbol': clean_sym, 'limit': limit}, timeout=3.0)
            if resp.status_code != 200:
                return res

            data = resp.json()
            bids = data.get('bids', [])
            asks = data.get('asks', [])

            if not bids or not asks:
                return res

            best_bid = float(bids[0][0])
            best_ask = float(asks[0][0])
            res['best_bid'] = best_bid
            res['best_ask'] = best_ask
            res['spread_pct'] = (best_ask - best_bid) / best_bid if best_bid > 0 else 0.0

            # Tính Notional từng mức giá
            bid_notionals = [(float(p), float(p) * float(q)) for p, q in bids]
            ask_notionals = [(float(p), float(p) * float(q)) for p, q in asks]

            res['total_bid_notional'] = sum(usd for _, usd in bid_notionals)
            res['total_ask_notional'] = sum(usd for _, usd in ask_notionals)
            res['imbalance_ratio'] = (res['total_ask_notional'] / res['total_bid_notional']) if res['total_bid_notional'] > 0 else 1.0

            # 2. TOÁN HỌC ĐỘ LỆCH CHUẨN Z-SCORE ĐỊNH NGHĨA BỨC TƯỜNG CÁ MẬP (Z >= 3.0)
            # Áp dụng cho Asks
            ask_values = [usd for _, usd in ask_notionals]
            if len(ask_values) >= 10:
                mean_ask = sum(ask_values) / len(ask_values)
                variance_ask = sum((v - mean_ask) ** 2 for v in ask_values) / len(ask_values)
                std_ask = math.sqrt(variance_ask) if variance_ask > 0 else 1.0

                for px, usd in ask_notionals[:20]:
                    z_score = (usd - mean_ask) / std_ask
                    if z_score >= 3.0:
                        res['whale_ask_walls'].append({
                            'price': px,
                            'notional': usd,
                            'z_score': round(z_score, 2),
                            'dist_pct': (px - best_ask) / best_ask if best_ask > 0 else 0.0
                        })

            # Áp dụng cho Bids
            bid_values = [usd for _, usd in bid_notionals]
            if len(bid_values) >= 10:
                mean_bid = sum(bid_values) / len(bid_values)
                variance_bid = sum((v - mean_bid) ** 2 for v in bid_values) / len(bid_values)
                std_bid = math.sqrt(variance_bid) if variance_bid > 0 else 1.0

                for px, usd in bid_notionals[:20]:
                    z_score = (usd - mean_bid) / std_bid
                    if z_score >= 3.0:
                        res['whale_bid_walls'].append({
                            'price': px,
                            'notional': usd,
                            'z_score': round(z_score, 2),
                            'dist_pct': (best_bid - px) / best_bid if best_bid > 0 else 0.0
                        })

            if hasattr(self, '_depth_cache'):
                self._depth_cache[clean_sym] = (now_ts, res)
            return res
        except Exception as e:
            logger.debug(f"Lỗi tính toán Sổ Lệnh Z-Score cho {symbol}: {e}")
            return res
