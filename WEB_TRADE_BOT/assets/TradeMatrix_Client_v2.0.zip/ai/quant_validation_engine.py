"""
Quantum & Institutional Quantitative Strategy Validation Engine (v2.0).
Implements the 4-Tier Institutional Quant Verification Framework:
1. In-Sample Bar-by-Bar Return & Pain Profile (Bar Sharpe, Sortino, MAE/MFE, Ulcer Index).
2. In-Sample Monte Carlo Permutation Test (David Aronson / Marcos López de Prado null hypothesis significance testing & p-value).
3. Walk-Forward Rolling Analysis (Robert Pardo WFO & Walk-Forward Efficiency Ratio).
4. Walk-Forward Monte Carlo Permutation Test (Sequence Risk, VaR, CVaR, Tail Drawdown Probability).
"""

import os
import sys
import math
import json
import random
import sqlite3
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any

# Ensure UTF-8 output
if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass


class QuantValidationEngine:
    """
    Động cơ Thẩm định Định lượng Cấp Quỹ (Institutional Quant Validation Engine).
    Khắc phục triệt để rủi ro Overfitting (Tối ưu hóa quá mức) và Data Mining Bias (Ảo tưởng ăn may).
    """

    def __init__(self, db_path: Optional[str] = None, historical_dir: Optional[str] = None):
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.db_path = db_path or os.path.join(self.base_dir, 'data', 'trade_bot.db')
        self.historical_dir = historical_dir or os.path.join(self.base_dir, 'data', 'historical')
        self.annual_bars_15m = 365.25 * 24 * 4  # 35,064 bars per year for 15m

    # =========================================================================
    # TẦNG 1: HIỆU SUẤT TRONG MẪU THEO TỪNG THANH NẾN (BAR-BY-BAR RETURN & PAIN)
    # =========================================================================

    def calculate_bar_by_bar_metrics(self, trades: List[Dict[str, Any]], ohlcv_cache: Optional[Dict[str, pd.DataFrame]] = None) -> Dict[str, Any]:
        """
        Tính toán chuỗi lợi nhuận theo từng thanh nến (Bar-by-Bar Returns) thay vì chỉ nhìn PnL lúc đóng lệnh.
        Đo lường:
          - Bar-by-bar Sharpe Ratio (Chuẩn hóa hàng năm)
          - Bar-by-bar Sortino Ratio (Chỉ phạt biến động giảm)
          - Maximum Adverse Excursion (MAE - Mức sụt giảm tạm thời sâu nhất trong lúc gồng lệnh)
          - Maximum Favorable Excursion (MFE - Mức lãi cực đại chạm tới trước khi chốt)
          - Ulcer Index (Chỉ số đo lường mức độ đau đớn / stress của tài khoản)
        """
        all_bar_returns = []
        maes = []
        mfes = []
        trade_hold_bars = []

        for t in trades:
            sym = t.get('symbol', '')
            direction = 1.0 if str(t.get('side', t.get('direction', 'buy'))).lower() in ('buy', 'long') else -1.0
            entry_p = float(t.get('entry_price', t.get('price', 0.0)) or 0.0)
            exit_p = float(t.get('exit_price', 0.0) or 0.0)
            pnl = float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0)

            if entry_p <= 0:
                continue

            # Nếu có nến lịch sử thực tế trong cache, tính toán từng thanh nến chính xác
            bars_df = None
            if ohlcv_cache and sym in ohlcv_cache:
                bars_df = ohlcv_cache[sym]

            entry_time = t.get('entry_time')
            exit_time = t.get('exit_time')

            if bars_df is not None and entry_time and exit_time and 'close' in bars_df.columns:
                try:
                    mask = (bars_df.index >= entry_time) & (bars_df.index <= exit_time)
                    sub_df = bars_df.loc[mask]
                    if len(sub_df) >= 2:
                        closes = sub_df['close'].values
                        highs = sub_df['high'].values if 'high' in sub_df.columns else closes
                        lows = sub_df['low'].values if 'low' in sub_df.columns else closes

                        # Chuỗi Bar-by-bar return
                        bar_rets = (closes[1:] - closes[:-1]) / closes[:-1] * direction
                        all_bar_returns.extend(bar_rets.tolist())
                        trade_hold_bars.append(len(sub_df))

                        # MAE & MFE
                        if direction > 0:
                            mae = (np.min(lows) - entry_p) / entry_p
                            mfe = (np.max(highs) - entry_p) / entry_p
                        else:
                            mae = (entry_p - np.max(highs)) / entry_p
                            mfe = (entry_p - np.min(lows)) / entry_p

                        maes.append(float(mae))
                        mfes.append(float(mfe))
                        continue
                except Exception:
                    pass

            # Dự toán gần đúng dựa trên Trade PnL nếu không có mảng nến đầy đủ
            cost = float(t.get('entry_cost', t.get('cost', 10.0)) or 10.0)
            trade_ret = pnl / cost if cost > 0 else 0.0
            approx_bars = max(1, int(t.get('held_minutes', 15) / 15))
            trade_hold_bars.append(approx_bars)
            bar_ret = trade_ret / approx_bars
            all_bar_returns.extend([bar_ret] * approx_bars)
            maes.append(min(0.0, trade_ret * 0.8 if trade_ret < 0 else -0.002))
            mfes.append(max(0.0, trade_ret * 1.2 if trade_ret > 0 else 0.003))

        bar_returns_arr = np.array(all_bar_returns) if all_bar_returns else np.array([0.0])
        mean_ret = float(np.mean(bar_returns_arr))
        std_ret = float(np.std(bar_returns_arr, ddof=1)) if len(bar_returns_arr) > 1 else 1e-6
        std_ret = max(std_ret, 1e-8)

        # Downside deviation cho Sortino
        neg_returns = bar_returns_arr[bar_returns_arr < 0]
        downside_std = float(np.std(neg_returns, ddof=1)) if len(neg_returns) > 1 else std_ret
        downside_std = max(downside_std, 1e-8)

        # Chuẩn hóa hàng năm (Annualization)
        sqrt_annual = math.sqrt(self.annual_bars_15m)
        bar_sharpe = (mean_ret / std_ret) * sqrt_annual
        bar_sortino = (mean_ret / downside_std) * sqrt_annual

        # Ulcer Index (Độ đau đớn sụt giảm)
        cumulative = np.cumprod(1.0 + np.clip(bar_returns_arr, -0.99, 1.0))
        running_max = np.maximum.accumulate(cumulative)
        drawdowns = (cumulative - running_max) / running_max
        ulcer_index = float(np.sqrt(np.mean(drawdowns ** 2)) * 100.0) if len(drawdowns) > 0 else 0.0

        return {
            "total_bars_evaluated": int(len(bar_returns_arr)),
            "mean_bar_return_pct": float(mean_ret * 100.0),
            "bar_volatility_pct": float(std_ret * 100.0),
            "annualized_bar_sharpe": float(bar_sharpe),
            "annualized_bar_sortino": float(bar_sortino),
            "avg_mae_pct": float(np.mean(maes) * 100.0) if maes else 0.0,
            "avg_mfe_pct": float(np.mean(mfes) * 100.0) if mfes else 0.0,
            "ulcer_index": float(ulcer_index),
            "avg_hold_bars": float(np.mean(trade_hold_bars)) if trade_hold_bars else 0.0,
        }

    # =========================================================================
    # TẦNG 2: KIỂM ĐỊNH HOÁN VỊ MONTE CARLO (IN-SAMPLE PERMUTATION TEST)
    # =========================================================================

    def monte_carlo_permutation_test(
        self,
        trades: List[Dict[str, Any]],
        num_permutations: int = 1000,
        seed: int = 42
    ) -> Dict[str, Any]:
        """
        Kiểm tra hoán vị Monte Carlo trong mẫu (David Aronson / Marcos López de Prado Test).
        Xáo trộn ngẫu nhiên (permutation) chuỗi lợi nhuận và đảo dấu ngẫu nhiên (sign-flip permutation)
        để phá vỡ tính xu hướng và quy luật cấu trúc nến, tạo ra Phân Phối Vô Hiệu (Null Hypothesis Distribution H0).

        Đo lường:
          - Empirical p-value: Xác suất mà một chiến lược ngẫu nhiên ăn may đạt được kết quả >= kết quả thực tế.
          - Null Distribution Percentiles (5%, 50%, 95%, 99%).
          - Kết luận khoa học: TRUE EDGE (Lợi thế thực sự) vs OVERFITTING / DATA MINING BIAS.
        """
        if not trades:
            return {"status": "error", "message": "Không có dữ liệu vị thế để kiểm định."}

        random.seed(seed)
        np.random.seed(seed)

        real_pnls = [float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) for t in trades]
        real_total_pnl = sum(real_pnls)
        real_wins = sum(1 for p in real_pnls if p > 0)
        real_losses = sum(1 for p in real_pnls if p <= 0)
        real_win_rate = real_wins / max(1, len(real_pnls))
        gross_win = sum(p for p in real_pnls if p > 0)
        gross_loss = abs(sum(p for p in real_pnls if p < 0))
        real_pf = (gross_win / gross_loss) if gross_loss > 0 else (10.0 if gross_win > 0 else 1.0)

        # Tạo Phân Phối Vô Hiệu (Null Distribution H0) qua Permutation Shuffling
        perm_total_pnls = []
        perm_pfs = []
        perm_win_rates = []

        n_trades = len(real_pnls)
        pnls_array = np.array(real_pnls)

        for _ in range(num_permutations):
            # Phương pháp Hoán vị Đảo Dấu & Xáo Trộn Thứ Tự (Sign-Flip & Order Permutation)
            # Giữ nguyên độ biến động thực tế của từng cú trade, nhưng triệt tiêu hoàn toàn kỹ năng chọn hướng (Edge)
            signs = np.random.choice([-1.0, 1.0], size=n_trades)
            shuffled_pnls = np.random.permutation(pnls_array) * signs

            sim_pnl = float(np.sum(shuffled_pnls))
            sim_wins = np.sum(shuffled_pnls > 0)
            sim_wr = sim_wins / n_trades
            sim_gross_win = np.sum(shuffled_pnls[shuffled_pnls > 0])
            sim_gross_loss = np.abs(np.sum(shuffled_pnls[shuffled_pnls < 0]))
            sim_pf = (sim_gross_win / sim_gross_loss) if sim_gross_loss > 0 else (10.0 if sim_gross_win > 0 else 1.0)

            perm_total_pnls.append(sim_pnl)
            perm_pfs.append(sim_pf)
            perm_win_rates.append(sim_wr)

        # Tính toán giá trị p-value thực nghiệm
        # p-value = (Số lần ngẫu nhiên có kết quả >= thực tế + 1) / (Tổng số lần lặp + 1)
        count_better_pnl = sum(1 for p in perm_total_pnls if p >= real_total_pnl)
        count_better_pf = sum(1 for pf in perm_pfs if pf >= real_pf)
        p_val_pnl = (count_better_pnl + 1) / (num_permutations + 1)
        p_val_pf = (count_better_pf + 1) / (num_permutations + 1)

        perm_pnls_sorted = np.sort(perm_total_pnls)
        perm_pfs_sorted = np.sort(perm_pfs)

        # Đánh giá kết luận
        if p_val_pnl < 0.01:
            verdict = "💎 TRUE QUANT EDGE (Độ tin cậy > 99% - Vượt trội tuyệt đối so với ngẫu nhiên)"
        elif p_val_pnl < 0.05:
            verdict = "✅ STATISTICALLY SIGNIFICANT (Độ tin cậy > 95% - Lợi thế thực sự có ý nghĩa thống kê)"
        elif p_val_pnl < 0.10:
            verdict = "⚠️ MARGINAL EDGE (Độ tin cậy ~ 90% - Cần theo dõi thêm, ranh giới ăn may nhẹ)"
        else:
            verdict = "🚨 HIGH OVERFITTING RISK / DATA MINING BIAS (p-value >= 0.10 - Hiệu suất có khả năng cao là do ngẫu nhiên/curve-fitting)"

        return {
            "num_permutations": num_permutations,
            "real_metrics": {
                "total_trades": n_trades,
                "net_pnl_usdt": float(real_total_pnl),
                "profit_factor": float(real_pf),
                "win_rate_pct": float(real_win_rate * 100.0)
            },
            "p_value_pnl": float(p_val_pnl),
            "p_value_pf": float(p_val_pf),
            "null_distribution_pnl": {
                "min": float(np.min(perm_pnls_sorted)),
                "p5": float(np.percentile(perm_pnls_sorted, 5)),
                "median": float(np.percentile(perm_pnls_sorted, 50)),
                "p95": float(np.percentile(perm_pnls_sorted, 95)),
                "max": float(np.max(perm_pnls_sorted))
            },
            "null_distribution_pf": {
                "median": float(np.percentile(perm_pfs_sorted, 50)),
                "p95": float(np.percentile(perm_pfs_sorted, 95))
            },
            "verdict": verdict
        }

    # =========================================================================
    # TẦNG 3: KIỂM TRA BƯỚC ĐI TIẾP (WALK-FORWARD ANALYSIS - WFO)
    # =========================================================================

    def walk_forward_analysis(
        self,
        trades: List[Dict[str, Any]],
        train_window_days: int = 14,
        test_window_days: int = 7,
        step_days: int = 7
    ) -> Dict[str, Any]:
        """
        Kiểm tra bước đi tiếp cuốn chiếu (Robert Pardo Walk-Forward Optimization Engine).
        Chia chuỗi thời gian thành các khối Rolling Window:
          - In-Sample (IS): Giai đoạn "học" và thiết lập quy tắc trong quá khứ.
          - Out-of-Sample (OOS): Giai đoạn "bước đi tiếp" mà thuật toán chưa từng nhìn thấy trước đó.

        Đo lường:
          - Walk-Forward Efficiency Ratio (WFE = Annualized Return OOS / Annualized Return IS).
          - OOS Consistency (% số chu kỳ OOS đạt lợi nhuận dương).
          - Ghép nối đường cong vốn Walk-Forward thực tế.
        """
        if not trades:
            return {"status": "error", "message": "Không có dữ liệu vị thế."}

        dated_trades = []
        for t in trades:
            et = t.get('entry_time')
            if isinstance(et, (int, float)):
                et = datetime.fromtimestamp(et / 1000 if et > 1e11 else et)
            elif isinstance(et, str):
                try:
                    et = datetime.fromisoformat(et.replace('Z', ''))
                except Exception:
                    continue
            if et:
                dated_trades.append({**t, 'parsed_time': et})

        dated_trades.sort(key=lambda x: x['parsed_time'])
        if len(dated_trades) < 10:
            return {"status": "error", "message": "Cần tối thiểu 10 vị thế để chạy Walk-Forward."}

        start_time = dated_trades[0]['parsed_time']
        end_time = dated_trades[-1]['parsed_time']
        total_span_days = (end_time - start_time).total_seconds() / 86400.0

        windows = []
        current_train_start = start_time
        oos_all_trades = []
        is_all_trades = []

        while True:
            current_train_end = current_train_start + timedelta(days=train_window_days)
            current_test_end = current_train_end + timedelta(days=test_window_days)

            if current_train_end >= end_time:
                break

            is_trades = [t for t in dated_trades if current_train_start <= t['parsed_time'] < current_train_end]
            oos_trades = [t for t in dated_trades if current_train_end <= t['parsed_time'] < current_test_end]

            if is_trades and oos_trades:
                is_pnl = sum(float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) for t in is_trades)
                oos_pnl = sum(float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) for t in oos_trades)
                is_wr = sum(1 for t in is_trades if float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) > 0) / len(is_trades)
                oos_wr = sum(1 for t in oos_trades if float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) > 0) / len(oos_trades)

                windows.append({
                    "window_idx": len(windows) + 1,
                    "train_range": f"{current_train_start.strftime('%d/%m')} -> {current_train_end.strftime('%d/%m')}",
                    "test_range": f"{current_train_end.strftime('%d/%m')} -> {min(current_test_end, end_time).strftime('%d/%m')}",
                    "is_trades_count": len(is_trades),
                    "oos_trades_count": len(oos_trades),
                    "is_pnl_usdt": float(is_pnl),
                    "oos_pnl_usdt": float(oos_pnl),
                    "is_win_rate_pct": float(is_wr * 100.0),
                    "oos_win_rate_pct": float(oos_wr * 100.0),
                })
                oos_all_trades.extend(oos_trades)
                is_all_trades.extend(is_trades)

            current_train_start += timedelta(days=step_days)

        if not windows:
            # Fallback nếu khoảng thời gian ngắn: Chia 70% In-Sample, 30% Out-of-Sample
            split_idx = int(len(dated_trades) * 0.70)
            is_trades = dated_trades[:split_idx]
            oos_trades = dated_trades[split_idx:]
            is_pnl = sum(float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) for t in is_trades)
            oos_pnl = sum(float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) for t in oos_trades)
            windows.append({
                "window_idx": 1,
                "train_range": f"{is_trades[0]['parsed_time'].strftime('%d/%m')} -> {is_trades[-1]['parsed_time'].strftime('%d/%m')}",
                "test_range": f"{oos_trades[0]['parsed_time'].strftime('%d/%m')} -> {oos_trades[-1]['parsed_time'].strftime('%d/%m')}",
                "is_trades_count": len(is_trades),
                "oos_trades_count": len(oos_trades),
                "is_pnl_usdt": float(is_pnl),
                "oos_pnl_usdt": float(oos_pnl),
                "is_win_rate_pct": float(sum(1 for t in is_trades if float(t.get('net_pnl', 0) or 0) > 0) / len(is_trades) * 100.0),
                "oos_win_rate_pct": float(sum(1 for t in oos_trades if float(t.get('net_pnl', 0) or 0) > 0) / len(oos_trades) * 100.0),
            })
            oos_all_trades = oos_trades
            is_all_trades = is_trades

        total_is_pnl = sum(w['is_pnl_usdt'] for w in windows)
        total_oos_pnl = sum(w['oos_pnl_usdt'] for w in windows)
        positive_oos_windows = sum(1 for w in windows if w['oos_pnl_usdt'] > 0)
        consistency_pct = (positive_oos_windows / len(windows)) * 100.0

        # Walk-Forward Efficiency (WFE Ratio)
        avg_is_pnl_per_window = total_is_pnl / len(windows) if windows else 0.0
        avg_oos_pnl_per_window = total_oos_pnl / len(windows) if windows else 0.0
        wfe_ratio = (avg_oos_pnl_per_window / avg_is_pnl_per_window) if avg_is_pnl_per_window > 0 else (1.0 if avg_oos_pnl_per_window > 0 else 0.0)

        if wfe_ratio >= 0.60 and consistency_pct >= 60.0:
            wf_verdict = "🛡️ ROBUST WALK-FORWARD RESILIENCE (WFE >= 60% - Chiến lược hoạt động vững chắc khi gặp dữ liệu tương lai)"
        elif wfe_ratio >= 0.35:
            wf_verdict = "🟡 MODERATE WALK-FORWARD RESILIENCE (Hệ thống có độ suy thoái nhẹ nhưng vẫn bảo toàn khả năng sinh lời)"
        else:
            wf_verdict = "🚨 DEGRADED OUT-OF-SAMPLE PERFORMANCE (WFE < 35% - Hệ thống bị sụt giảm hiệu suất nặng khi bước vào tương lai)"

        return {
            "total_span_days": float(total_span_days),
            "num_windows": len(windows),
            "walk_forward_efficiency_ratio": float(wfe_ratio),
            "oos_consistency_pct": float(consistency_pct),
            "total_is_pnl": float(total_is_pnl),
            "total_oos_pnl": float(total_oos_pnl),
            "windows": windows,
            "verdict": wf_verdict,
            "oos_trades_count": len(oos_all_trades)
        }

    # =========================================================================
    # TẦNG 4: WALK-FORWARD MONTE CARLO PERMUTATION TEST
    # =========================================================================

    def walk_forward_monte_carlo_permutation(
        self,
        trades: List[Dict[str, Any]],
        num_simulations: int = 1000
    ) -> Dict[str, Any]:
        """
        Kiểm tra hoán vị Monte Carlo bước đi tiếp (Walk-Forward Monte Carlo Permutation Test).
        Đánh giá chuỗi rủi ro (Sequence Risk) trên tập Out-of-Sample:
          - Value-at-Risk (95% VaR)
          - Conditional VaR (CVaR / Expected Shortfall - mức lỗ kỳ vọng trong 5% trường hợp xấu nhất)
          - Xác suất sụt giảm tài khoản vượt ngưỡng an toàn (P(Drawdown > 10%))
        """
        pnls = [float(t.get('net_pnl', t.get('pnl', 0.0)) or 0.0) for t in trades]
        if not pnls:
            return {"status": "error", "message": "Không có dữ liệu vị thế."}

        n_trades = len(pnls)
        simulated_max_dds = []
        simulated_end_equities = []
        start_equity = 100.0  # Chuẩn hóa vốn 100 USDT thực tế PC2

        for _ in range(num_simulations):
            # Xáo trộn ngẫu nhiên thứ tự các lệnh Out-of-sample (Sequence Shuffling)
            shuffled = np.random.choice(pnls, size=n_trades, replace=True)
            equity_curve = start_equity + np.cumsum(shuffled)
            running_max = np.maximum.accumulate(equity_curve)
            drawdowns = (running_max - equity_curve) / running_max * 100.0
            simulated_max_dds.append(float(np.max(drawdowns)))
            simulated_end_equities.append(float(equity_curve[-1]))

        dds_sorted = np.sort(simulated_max_dds)
        var_95_dd = float(np.percentile(dds_sorted, 95))
        cvar_95_dd = float(np.mean(dds_sorted[dds_sorted >= var_95_dd]))
        prob_dd_over_10pct = float(np.sum(dds_sorted > 10.0) / num_simulations * 100.0)

        return {
            "num_simulations": num_simulations,
            "simulated_start_equity": start_equity,
            "max_drawdown_percentiles": {
                "median": float(np.percentile(dds_sorted, 50)),
                "p95_var": var_95_dd,
                "cvar_95_expected_shortfall": cvar_95_dd,
                "worst_case": float(np.max(dds_sorted))
            },
            "prob_drawdown_exceeding_10pct": prob_dd_over_10pct,
            "projected_median_equity": float(np.percentile(simulated_end_equities, 50))
        }

    # =========================================================================
    # BỘ ĐIỀU PHỐI TỔNG THỂ & XUẤT BÁO CÁO (MASTER ORCHESTRATOR)
    # =========================================================================

    def load_positions_from_db(
        self,
        db_path: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """Đọc và tái dựng toàn bộ chu kỳ vị thế từ SQLite database với bộ lọc thời gian."""
        target_db = db_path or self.db_path
        if not os.path.exists(target_db):
            return []

        conn = sqlite3.connect(target_db)
        c = conn.cursor()
        c.execute("""
            SELECT id, timestamp, symbol, side, type, price, amount, cost, fee, pnl, strategy, close_reason 
            FROM trades 
            ORDER BY timestamp ASC, id ASC
        """)
        rows = c.fetchall()
        conn.close()

        open_positions = {}
        all_positions = []

        for r in rows:
            tid, ts_ms, sym, side, ord_type, price, amount, cost, fee, pnl, strat, close_reason = r
            if not ts_ms:
                continue
            dt = datetime.fromtimestamp(ts_ms / 1000)
            if start_date and dt < start_date:
                continue
            if end_date and dt > end_date:
                continue

            pnl = pnl or 0.0
            fee = fee or 0.0
            side_lower = side.lower()

            if sym not in open_positions:
                open_positions[sym] = {
                    "id": tid, "symbol": sym, "entry_time": dt, "entry_side": side_lower,
                    "entry_price": price, "entry_amount": amount, "entry_cost": cost,
                    "entry_fee": fee, "closed_amount": 0.0, "closed_pnl": 0.0, "exit_fees": 0.0, "exits": [], "strat": strat
                }
            else:
                pos = open_positions[sym]
                is_exit = (pos["entry_side"] == "buy" and side_lower == "sell") or (pos["entry_side"] == "sell" and side_lower == "buy")
                if is_exit:
                    pos["closed_amount"] += amount
                    pos["closed_pnl"] += pnl
                    pos["exit_fees"] += fee
                    pos["exits"].append({"time": dt, "pnl": pnl, "fee": fee, "reason": close_reason, "price": price})
                    if pos["closed_amount"] >= pos["entry_amount"] * 0.90:
                        pos["exit_time"] = dt
                        pos["net_pnl"] = pos["closed_pnl"] - pos["entry_fee"] - pos["exit_fees"]
                        pos["held_minutes"] = max(1.0, (pos["exit_time"] - pos["entry_time"]).total_seconds() / 60.0)
                        all_positions.append(pos)
                        del open_positions[sym]
                else:
                    pos["entry_amount"] += amount
                    pos["entry_cost"] += cost
                    pos["entry_fee"] += fee

        return all_positions

    def run_full_validation_suite(
        self,
        db_path: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        filter_label: str = "Tất cả lịch sử"
    ) -> Dict[str, Any]:
        """Thực thi trọn bộ 4 tầng kiểm định định lượng chuẩn mực."""
        trades = self.load_positions_from_db(db_path, start_date=start_date, end_date=end_date)
        if not trades:
            return {"status": "error", "message": f"Không tìm thấy vị thế trong cơ sở dữ liệu: {db_path or self.db_path}"}

        print(f"🚀 [QUANT VALIDATION ENGINE] Khởi động kiểm định 4 tầng ({filter_label}: {len(trades)} vị thế)...")

        # 1. Bar-by-bar
        print("  ⏳ [1/4] Đang tính toán Bar-by-Bar Return & Pain Profile (Sharpe, Sortino, Ulcer Index)...")
        bar_metrics = self.calculate_bar_by_bar_metrics(trades)

        # 2. In-sample Permutation
        print("  ⏳ [2/4] Đang chạy In-Sample Monte Carlo Permutation Test (1,000 vòng lặp xáo trộn Null H0)...")
        permutation_results = self.monte_carlo_permutation_test(trades, num_permutations=1000)

        # 3. Walk-forward
        print("  ⏳ [3/4] Đang thực thi Walk-Forward Rolling Analysis (WFO & Walk-Forward Efficiency)...")
        wf_results = self.walk_forward_analysis(trades, train_window_days=14, test_window_days=7, step_days=7)

        # 4. Walk-forward Permutation
        print("  ⏳ [4/4] Đang kiểm tra Walk-Forward Monte Carlo Permutation (VaR, CVaR, Sequence Risk)...")
        wf_perm_results = self.walk_forward_monte_carlo_permutation(trades, num_simulations=1000)

        report = {
            "timestamp": datetime.now().isoformat(),
            "total_trades_analyzed": len(trades),
            "tier_1_bar_by_bar_metrics": bar_metrics,
            "tier_2_in_sample_permutation": permutation_results,
            "tier_3_walk_forward_analysis": wf_results,
            "tier_4_walk_forward_monte_carlo_permutation": wf_perm_results,
            "overall_system_rating": self._generate_overall_rating(permutation_results, wf_results, wf_perm_results)
        }

        # Lưu báo cáo vào file JSON
        out_path = os.path.join(self.base_dir, 'data', 'quant_validation_report.json')
        try:
            with open(out_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            print(f"✅ Đã lưu báo cáo thẩm định định lượng vào: {out_path}")
        except Exception as e:
            print(f"⚠️ Không thể ghi file báo cáo: {e}")

        return report

    def _generate_overall_rating(self, perm: Dict, wf: Dict, wf_perm: Dict) -> Dict[str, Any]:
        """Tổng hợp điểm số và xếp hạng độ tin cậy của thuật toán."""
        p_val = perm.get('p_value_pnl', 1.0)
        wfe = wf.get('walk_forward_efficiency_ratio', 0.0)
        prob_dd = wf_perm.get('prob_drawdown_exceeding_10pct', 100.0)

        score = 100.0
        # Phạt nếu p-value cao (dễ bị ăn may)
        if p_val >= 0.10: score -= 35.0
        elif p_val >= 0.05: score -= 15.0
        elif p_val >= 0.01: score -= 5.0

        # Phạt nếu WFE thấp (suy thoái khi bước vào tương lai)
        if wfe < 0.35: score -= 25.0
        elif wfe < 0.50: score -= 10.0

        # Phạt nếu rủi ro sụt giảm > 10% cao
        if prob_dd > 30.0: score -= 20.0
        elif prob_dd > 15.0: score -= 10.0

        grade = "AAA (Cấp Quỹ Định Lượng)" if score >= 85 else ("A (Vững Chắc)" if score >= 70 else ("B (Khá - Cần Theo Dõi)" if score >= 55 else "C (Cảnh Báo Overfitting)"))

        return {
            "robustness_score": round(max(0.0, score), 1),
            "institutional_grade": grade,
            "summary_verdict": f"Hệ thống đạt điểm kiểm định {score:.1f}/100 ({grade}) - p-value={p_val:.4f}, WFE={wfe:.2f}, Rủi ro Max DD>10%={prob_dd:.1f}%"
        }
