import json
import logging
import requests
import pandas as pd
import threading
import time
from typing import Dict, Any, Optional
import ta
from core.scanner import MarketScanner

logger = logging.getLogger(__name__)

class JevAgent:
    def __init__(self, model_name: str = "qwen3:14b", endpoint: str = "http://localhost:11434/api/generate"):
        self.model_name = model_name
        self.endpoint = endpoint
        self.format = "json"
        self._cooldown_until = 0.0
        self._cooldown_lock = threading.Lock()
        self._failure_cooldown_seconds = 60.0
        self._read_timeout_seconds = 20.0

    def _cooldown_remaining(self) -> float:
        with self._cooldown_lock:
            return max(0.0, self._cooldown_until - time.monotonic())

    def _start_failure_cooldown(self, seconds: Optional[float] = None) -> None:
        duration = self._failure_cooldown_seconds if seconds is None else max(0.0, float(seconds))
        with self._cooldown_lock:
            self._cooldown_until = max(self._cooldown_until, time.monotonic() + duration)

    @staticmethod
    def _unavailable_result(status: str, detail: str) -> Dict[str, Any]:
        return {
            "decision": "HOLD",
            "confidence": 0.0,
            "reason": f"JEV unavailable ({status}): {str(detail)[:180]}",
            "risk_factors": "JEV/Ollama unavailable; candidate must fail closed",
            "availability_status": status,
        }

    def _extract_tf_metrics(self, df: Optional[pd.DataFrame], tf_label: str) -> Dict[str, Any]:
        """Tính toán nhanh các chỉ báo cốt lõi của khung thời gian phụ (4H hoặc 1H) dựa trên nến đã đóng."""
        if df is None or len(df) < 25:
            return {"status": f"{tf_label} data not available"}
        try:
            closed_tf = df.iloc[:-1] if len(df) > 2 else df
            c = closed_tf['close']
            ema20_s = ta.trend.EMAIndicator(c, window=min(len(c), 20)).ema_indicator()
            ema20 = float(ema20_s.dropna().iloc[-1]) if not ema20_s.dropna().empty else float(c.iloc[-1])
            
            w50 = 50 if len(c) >= 50 else min(len(c), 20)
            ema50_s = ta.trend.EMAIndicator(c, window=w50).ema_indicator()
            ema50 = float(ema50_s.dropna().iloc[-1]) if not ema50_s.dropna().empty else ema20
            
            curr_c = float(c.iloc[-1])
            rsi_s = ta.momentum.RSIIndicator(c, window=min(len(c)-1, 14)).rsi()
            rsi_val = float(rsi_s.dropna().iloc[-1]) if not rsi_s.dropna().empty else 50.0

            # Đánh giá xu hướng
            if curr_c > ema20 > ema50:
                trend = "BULLISH (Price > EMA20 > EMA50)"
            elif curr_c < ema20 < ema50:
                trend = "BEARISH (Price < EMA20 < EMA50)"
            elif curr_c > ema50:
                trend = "MODERATELY BULLISH (Above EMA50, Testing EMA20)"
            elif curr_c < ema50:
                trend = "MODERATELY BEARISH (Below EMA50, Testing EMA20)"
            else:
                trend = "NEUTRAL / CHOPPY"

            return {
                "trend": trend,
                "price": curr_c,
                "ema20": ema20,
                "ema50": ema50,
                "rsi": rsi_val
            }
        except Exception:
            return {"status": f"{tf_label} calculation error"}

    def analyze_klines(
        self,
        df: pd.DataFrame,
        symbol: str,
        df_1h: Optional[pd.DataFrame] = None,
        df_4h: Optional[pd.DataFrame] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Phân tích đa khung thời gian (Multi-Timeframe):
        - Khung tác chiến chính (df): 15M (20 nến Price Action, EMA20/50, Volume, RSI, MACD).
        - Khung trung (df_1h): 1H (Cấu trúc sóng & RSI).
        - Khung lớn (df_4h): 4H (La bàn xu hướng lớn EMA20/50, Trend Filter).
        """
        if df is None or len(df) < 25:
            return None

        cooldown_remaining = self._cooldown_remaining()
        if cooldown_remaining > 0:
            logger.info(
                "[JEV COOLDOWN FAIL-CLOSED] Bỏ qua Ollama cho %s trong %.1fs còn lại; không dùng tín hiệu JEV cũ.",
                symbol, cooldown_remaining,
            )
            return self._unavailable_result("cooldown", f"Ollama đang nghỉ sau lỗi; còn {cooldown_remaining:.1f}s")

        try:
            df = df.copy()
            df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=14).rsi()
            macd_ind = ta.trend.MACD(df['close'])
            df['macd'] = macd_ind.macd()
            df['macd_diff'] = macd_ind.macd_diff()
            df['ema_20'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
            df['ema_50'] = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator()
            df['vol_ma'] = df['volume'].rolling(window=20).mean()

            # QUY TẮC BẤT DI BẤT DỊCH: Nến iloc[-1] là nến đang chạy (chưa đóng cửa), chỉ mới mở vài giây/phút nên volume rất nhỏ (0.01x - 0.20x).
            # Bắt buộc lấy 8 nến ĐÃ ĐÓNG CỬA HOÀN CHỈNH (iloc[:-1], trong đó nến tín hiệu vừa đóng là iloc[-2]) để tính Volume Ratio và cấu trúc nến!
            closed_df = df.iloc[:-1] if len(df) > 2 else df
            recent_df = closed_df.tail(8)
            
            swing_high = float(recent_df['high'].max())
            swing_low = float(recent_df['low'].min())
            last_vol = float(recent_df['volume'].iloc[-1])
            vol_hist_20 = df['volume'].iloc[:-2].tail(20) if len(df) > 3 else recent_df['volume']
            last_vol_ma = float(vol_hist_20.mean() or recent_df['vol_ma'].iloc[-1] or 1.0)
            vol_ratio = (last_vol / last_vol_ma) if last_vol_ma > 0 else 1.0

            price_data = []
            for idx, row in recent_df.iterrows():
                rsi = row.get('rsi', 50.0)
                macd_d = row.get('macd_diff', 0.0)
                ema20 = row.get('ema_20', row['close'])
                ema50 = row.get('ema_50', row['close'])
                c = row['close']
                v = row['volume']
                price_data.append(f"C:{c:.5f} V:{v:.0f} RSI:{rsi:.1f} E20:{ema20:.5f} E50:{ema50:.5f} MD:{macd_d:.5f}")
            
            data_str = "\n".join(price_data)

            curr_close = float(recent_df['close'].iloc[-1])
            curr_ema20 = float(recent_df['ema_20'].iloc[-1])
            curr_ema50 = float(recent_df['ema_50'].iloc[-1])

            # Tính toán bối cảnh 4H và 1H
            m4h = self._extract_tf_metrics(df_4h, "4H")
            m1h = self._extract_tf_metrics(df_1h, "1H")

            if "trend" in m4h:
                ctx_4h = f"- 4H Macro Trend: {m4h['trend']} | Price: {m4h['price']:.5f} | EMA20: {m4h['ema20']:.5f} | EMA50: {m4h['ema50']:.5f} | RSI: {m4h['rsi']:.1f}"
            else:
                ctx_4h = "- 4H Macro Trend: Not Available"

            if "trend" in m1h:
                ctx_1h = f"- 1H Wave Structure: {m1h['trend']} | Price: {m1h['price']:.5f} | RSI: {m1h['rsi']:.1f} | EMA20: {m1h['ema20']:.5f}"
            else:
                ctx_1h = "- 1H Wave Structure: Not Available"

            # Phân loại tài sản: Cổ phiếu Mỹ / Hàng hóa (TradFi) vs Tiền điện tử (Crypto)
            is_tradfi = MarketScanner.is_tradfi_stock(symbol) or (
                hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol)
            )

            if is_tradfi:
                role_desc = "You are a Wall Street Quantitative Portfolio Manager specializing in US Equities, Commodities & Stock Perps."
                asset_ctx = f"=== ASSET TYPE: TRADFI EQUITIES / COMMODITIES PERPETUAL ({symbol}) ===\n- Independent TradFi Market: Do NOT link or anchor this asset to Bitcoin or Crypto trends. Evaluate purely based on price action, volume liquidity, and trend continuation."
            else:
                role_desc = "You are a Quantitative Portfolio Manager specializing in Crypto Assets."
                asset_ctx = f"=== ASSET TYPE: CRYPTO FUTURES ({symbol}) ==="

            prompt = f"""{role_desc} Analyze multi-timeframe structure for {symbol} to output BUY, SELL, or HOLD.

{asset_ctx}

=== LAYER 1: 4H MACRO STRATEGY ===
{ctx_4h}

=== LAYER 2: 1H MARKET STRUCTURE ===
{ctx_1h}

=== LAYER 3: 15M TACTICAL EXECUTION ===
- Price: {curr_close:.6f} | Range 8-candles: [{swing_low:.6f} - {swing_high:.6f}]
- EMA20: {curr_ema20:.6f} | EMA50: {curr_ema50:.6f} | Volume Ratio: {vol_ratio:.2f}x
- 15M Recent 8 Candles:
{data_str}

DECISION RULES & DEVIL'S ADVOCATE RISK AUDIT:
1. DEVIL'S ADVOCATE AUDIT: Before declaring BUY or SELL, rigorously scrutinize at least 2 potential risk factors (e.g., overextended RSI > 70, volume exhaustion / falling volume, overhead 4H resistance, long upper rejection wicks). If severe risk or exhaustion is present, you MUST downgrade decision to HOLD.
2. BUY: 4H not Bearish AND 15M cleanly breaks above EMA20/50 with expanding volume (>1.2x) AND no volume exhaustion or overbought trap.
3. SELL: 4H not Bullish AND 15M cleanly breaks below EMA20/50 with accelerating volume.
4. Invalidation: Close position immediately if 15M structure breaks below EMA20/50.
5. HOLD: Conflicting timeframes, volume exhaustion, choppy consolidation, or risk factors outweigh reward.

CRITICAL: Keep your internal thinking concise (under 80 words), then immediately output STRICTLY a JSON object matching:
{{
    "decision": "BUY" | "SELL" | "HOLD",
    "confidence": float (0.0 to 1.0),
    "risk_factors": "1-sentence noting any observed risk or exhaustion factors (or 'none')",
    "reason": "precise 1-sentence technical justification"
}}"""

            payload = {
                "model": self.model_name,
                "prompt": prompt,
                "format": "json",
                "think": False,
                "stream": False,
                "options": {
                    "temperature": 0.0,
                    "num_predict": 350,
                    "top_k": 1,
                    "num_ctx": 2048,
                },
            }

            try:
                response = requests.post(
                    self.endpoint,
                    json=payload,
                    timeout=(5.0, self._read_timeout_seconds),
                )
            except requests.exceptions.Timeout as e:
                self._start_failure_cooldown()
                logger.error(
                    "[JEV TIMEOUT FAIL-CLOSED] Ollama vượt %.0fs cho %s; bỏ ứng viên này và nghỉ %.0fs để Pha 2 tiếp tục: %s",
                    self._read_timeout_seconds, symbol, self._failure_cooldown_seconds, e,
                )
                return self._unavailable_result("timeout", str(e))
            except requests.exceptions.RequestException as e:
                self._start_failure_cooldown(30.0)
                logger.error("[JEV REQUEST FAIL-CLOSED] Ollama request lỗi cho %s; nghỉ 30s: %s", symbol, e)
                return self._unavailable_result("request_error", str(e))

            if response.status_code != 200:
                self._start_failure_cooldown(30.0)
                logger.error("Ollama API Error cho %s: HTTP %s", symbol, response.status_code)
                return self._unavailable_result("http_error", f"HTTP {response.status_code}")

            try:
                result = response.json()
            except ValueError:
                self._start_failure_cooldown(30.0)
                logger.error("Ollama trả payload không phải JSON cho %s.", symbol)
                return self._unavailable_result("invalid_response", "API response is not valid JSON")
            if not isinstance(result, dict) or not isinstance(result.get("response"), str):
                self._start_failure_cooldown(30.0)
                logger.error("Ollama trả sai cấu trúc response cho %s.", symbol)
                return self._unavailable_result("invalid_response", "API response has an invalid schema")
            response_text = result["response"].strip()
            import re
            clean_text = re.sub(r'<think>[\s\S]*?</think>', '', response_text).strip()
            json_match = re.search(r'\{[\s\S]*\}', clean_text)
            if json_match:
                clean_text = json_match.group(0)
            try:
                data = json.loads(clean_text)
            except json.JSONDecodeError:
                self._start_failure_cooldown(30.0)
                logger.error("JEV Agent trả JSON không hợp lệ cho %s.", symbol)
                return self._unavailable_result("invalid_response", "model output is not valid JSON")

            if not all(key in data for key in ("decision", "confidence", "reason")):
                self._start_failure_cooldown(30.0)
                logger.warning("JEV Agent trả sai schema cho %s.", symbol)
                return self._unavailable_result("invalid_response", "model output has an invalid schema")

            decision = str(data["decision"]).upper()
            if decision not in ["BUY", "SELL", "HOLD"]:
                decision = "HOLD"
            try:
                confidence = float(data["confidence"])
            except (TypeError, ValueError):
                self._start_failure_cooldown(30.0)
                logger.warning("JEV Agent trả confidence sai định dạng cho %s.", symbol)
                return self._unavailable_result("invalid_response", "confidence is not numeric")
            if not 0.0 <= confidence <= 1.0:
                self._start_failure_cooldown(30.0)
                logger.warning("JEV Agent trả confidence ngoài [0, 1] cho %s.", symbol)
                return self._unavailable_result("invalid_response", "confidence is outside [0, 1]")

            risk_factors = str(data.get("risk_factors", "none"))
            logger.info(f"[JEV Agent - {self.model_name}] {symbol} -> {decision} ({confidence}) - {data['reason']} | Risk: {risk_factors}")
            return {
                "decision": decision,
                "confidence": confidence,
                "reason": str(data["reason"]),
                "risk_factors": risk_factors,
                "availability_status": "ok",
            }
        except Exception as e:
            logger.error(f"Loi phan tich JEV Agent cho {symbol}: {e}")

        return None
