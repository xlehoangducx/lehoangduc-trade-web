@echo off
reg add "HKCU\Console" /f /v "FaceName" /t REG_SZ /d "Consolas" >nul 2>&1
reg add "HKCU\Console" /f /v "CodePage" /t REG_DWORD /d 65001 >nul 2>&1
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONWARNINGS=ignore
title TRADEMATRIX - KIEM DINH QUANT 4 TANG

cd /d "%~dp0"

echo.
echo ===============================================================================
echo   TRADEMATRIX INSTITUTIONAL QUANT VALIDATION SUITE v2.0
echo   Kiem dinh Dinh luong 4 Tang: Triet tieu Overfitting va Data Mining Bias
echo ===============================================================================
echo.

set "PY_CMD="
if exist "venv\Scripts\python.exe" (
    set "PY_CMD=venv\Scripts\python.exe"
) else (
    where python >nul 2>&1
    if not errorlevel 1 (
        set "PY_CMD=python"
    )
)

if "%PY_CMD%"=="" (
    echo [ERROR] Khong tim thay Python! Vui long chay install.bat truoc.
    echo.
    pause
    exit /b 1
)

echo Dang su dung moi truong Python: %PY_CMD%
echo.

"%PY_CMD%" -X utf8 run_quant_validation.py

echo.
echo ===============================================================================
echo  Kiem dinh hoan tat! Bao cao chi tiet da luu tai: data\quant_validation_report.json
echo ===============================================================================
echo.
pause
