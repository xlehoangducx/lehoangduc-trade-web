import pandas as pd
import ta
import numpy as np
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal

class MeanReversionStrategy(BaseStrategy):
    """
    Chiến lược giao dịch đảo chiều trung bình (Mean Reversion).
    Sử dụng dải Bollinger (Bollinger Bands) và RSI để tìm điểm quá mua/quá bán.
    """
    def __init__(self, name: str = "MeanReversion", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'rsi_period': 14,
                    'rsi_oversold': 30,
                    'rsi_overbought': 70,
                    'atr_period': 14,
                    'atr_multiplier_sl': 1.5,
                    'atr_multiplier_tp': 2.0
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Tính toán Bollinger Bands, RSI và ATR.
        """
        bb_p = int(self.params.get('bb_period', 20))
        rsi_p = int(self.params.get('rsi_period', 14))
        bb_s = float(self.params.get('bb_std', 2.0))
        atr_p = int(self.params.get('atr_period', 14))

        if df is None or len(df) < max(bb_p, rsi_p, 50) or not {'high', 'low', 'close'}.issubset(df.columns):
            return df
            
        df = df.copy()
        
        # Tính toán Bollinger Bands
        bb = ta.volatility.BollingerBands(df['close'], window=bb_p, window_dev=bb_s)
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_middle'] = bb.bollinger_mavg()
        df['bb_upper'] = bb.bollinger_hband()
            
        # Tính toán RSI
        df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=rsi_p).rsi()
        
        # Tính toán ATR cho stop loss tự động
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=atr_p).average_true_range()
        
        # Trend EMAs để xác định xu hướng lớn, chống bắt dao rơi
        df['ema_20'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
        df['ema_50'] = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        """
        Tạo tín hiệu Mua/Bán dựa trên sự chạm dải Bollinger và điều kiện RSI.
        BUY: Giá chạm hoặc dưới dải BB dưới VÀ RSI < 30
        SELL: Giá chạm hoặc trên dải BB trên VÀ RSI > 70
        """
        if df is None or len(df) < 3 or not {'open', 'high', 'low', 'close'}.issubset(df.columns):
            return None

        df = self.get_indicators(df)
        required_columns = {'atr', 'bb_lower', 'bb_upper', 'rsi', 'ema_20', 'ema_50'}
        if (
            df is None or len(df) < 3 or not required_columns.issubset(df.columns)
            or df['atr'].isna().iloc[-2] or df['bb_lower'].isna().iloc[-2]
        ):
            return None
            
        prev = df.iloc[-3]
        current = df.iloc[-2]
        price = df.iloc[-1]['close']
        atr = current['atr']
        
        # Trend check chống bắt dao rơi (falling knife) và bán khống vào bão tăng
        ema_20 = current.get('ema_20')
        ema_50 = current.get('ema_50')
        is_strong_downtrend = False
        is_strong_uptrend = False
        if pd.notna(ema_20) and pd.notna(ema_50):
            is_strong_downtrend = current['close'] < ema_50 and ema_20 < ema_50
            is_strong_uptrend = current['close'] > ema_50 and ema_20 > ema_50

        # MUA (LONG): Chờ nến đảo chiều hoặc RSI móc lên từ vùng quá bán
        # 1. Nến trước đó chạm dải dưới VÀ RSI quá bán
        # 2. Nến hiện tại (đã đóng) là nến xanh (close > open)
        # 3. RSI đang ngóc đầu lên
        # 4. KHÔNG PHẢI trong sóng xả dốc đứng (chống bắt dao rơi)
        rsi_os = float(self.params.get('rsi_oversold', 30))
        rsi_ob = float(self.params.get('rsi_overbought', 70))
        sl_mult = float(self.params.get('atr_multiplier_sl', 1.5))
        tp_mult = float(self.params.get('atr_multiplier_tp', 2.0))

        is_oversold = prev['close'] <= prev['bb_lower'] and prev['rsi'] < rsi_os
        is_bullish_reversal = current['close'] > current['open'] and current['rsi'] > prev['rsi']
        buy_condition = is_oversold and is_bullish_reversal and not is_strong_downtrend
        
        # BÁN (SHORT): Chờ nến đảo chiều VÀ RSI chúi xuống từ vùng quá mua
        # 1. Nến trước đó chạm dải trên VÀ RSI quá mua
        # 2. Nến hiện tại là nến đỏ (close < open)
        # 3. RSI đang chúi xuống
        # 4. KHÔNG PHẢI trong bão tăng dốc đứng
        is_overbought = prev['close'] >= prev['bb_upper'] and prev['rsi'] > rsi_ob
        is_bearish_reversal = current['close'] < current['open'] and current['rsi'] < prev['rsi']
        sell_condition = is_overbought and is_bearish_reversal and not is_strong_uptrend

        # Tính confidence động theo độ lệch chuẩn RSI tại cực trị (nến quá bán/quá mua prev) từ trung vị 50
        # Tránh việc dùng current['rsi'] sau khi nến đảo chiều mạnh làm confidence bị giảm ngược!
        curr_rsi = float(current.get('rsi', 50.0) or 50.0)
        prev_rsi = float(prev.get('rsi', curr_rsi) or curr_rsi)
        if buy_condition:
            rsi_val = min(prev_rsi, curr_rsi)
        elif sell_condition:
            rsi_val = max(prev_rsi, curr_rsi)
        else:
            rsi_val = curr_rsi
        rsi_distance = abs(rsi_val - 50.0) / 50.0
        dynamic_conf = min(0.88, max(0.68, 0.68 + 0.20 * rsi_distance))
        calc_conf = round(dynamic_conf, 2)
        
        if buy_condition:
            stop_loss = price - (atr * sl_mult)
            # Take-Profit đảm bảo luôn cao hơn giá vào tối thiểu tp_mult * ATR hoặc dải BB trên
            take_profit = max(price + (atr * tp_mult), current['bb_upper'])
            
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=calc_conf,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'rsi': current['rsi'], 'bb_lower': current['bb_lower']}
            )
            
        elif sell_condition:
            stop_loss = price + (atr * sl_mult)
            # Take-Profit đảm bảo luôn thấp hơn giá vào tối thiểu tp_mult * ATR hoặc dải BB dưới
            take_profit = min(price - (atr * tp_mult), current['bb_lower'])
            
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=calc_conf,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'rsi': current['rsi'], 'bb_upper': current['bb_upper']}
            )
            
        return TradeSignal(
            signal=Signal.HOLD,
            symbol=symbol,
            confidence=0.0,
            strategy=self.name,
            price=price
        )
