import pandas as pd
import ta
import numpy as np
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal

class HFTScalpingStrategy(BaseStrategy):
    """
    Chiến lược High-Frequency Scalping (Giao dịch tần suất cao).
    Mục tiêu: Đánh siêu ngắn trên khung 1m hoặc 5m, ăn lợi nhuận siêu nhỏ nhưng liên tục.
    Được cộng đồng mạng (GitHub/TradingView) đánh giá cao cho bot HFT.
    Sử dụng: EMA 200 (Xác định trend lớn) + Stochastic RSI (Bắt sóng nhỏ) + Bollinger Bands.
    """
    def __init__(self, name: str = "HFTScalping", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'ema_period': 200,          # Trend chính
                    'stoch_rsi_period': 14,
                    'stoch_rsi_k': 3,
                    'stoch_rsi_d': 3,
                    'stoch_oversold': 20,       # Vùng quá bán siêu nhạy
                    'stoch_overbought': 80,     # Vùng quá mua siêu nhạy
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'atr_period': 14,
                    'profit_target_pct': 0.005, # Chốt lời siêu ngắn 0.5% giá trị thực (x10 = 5% ROE)
                    'stop_loss_pct': 0.005      # Cắt lỗ 0.5%
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        ema_p = int(self.params.get('ema_period', 200))
        stoch_p = int(self.params.get('stoch_rsi_period', 14))
        stoch_k = int(self.params.get('stoch_rsi_k', 3))
        stoch_d = int(self.params.get('stoch_rsi_d', 3))
        bb_p = int(self.params.get('bb_period', 20))
        bb_s = float(self.params.get('bb_std', 2.0))
        atr_p = int(self.params.get('atr_period', 14))

        if df is None or len(df) < ema_p:
            return df
            
        df = df.copy()
        
        # EMA 200 để xác định xu hướng lớn
        df['ema_200'] = ta.trend.EMAIndicator(df['close'], window=ema_p).ema_indicator()
        
        # Stochastic RSI siêu nhạy cho sóng ngắn
        stoch_rsi = ta.momentum.StochRSIIndicator(
            close=df['close'], 
            window=stoch_p,
            smooth1=stoch_k,
            smooth2=stoch_d
        )
        df['stoch_k'] = stoch_rsi.stochrsi_k() * 100
        df['stoch_d'] = stoch_rsi.stochrsi_d() * 100
        
        # Bollinger Bands để tìm điểm xả nén
        bb = ta.volatility.BollingerBands(df['close'], window=bb_p, window_dev=bb_s)
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_upper'] = bb.bollinger_hband()
        df['bb_middle'] = bb.bollinger_mavg()
        
        # ATR để tính biến động chớp nhoáng
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=atr_p).average_true_range()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        df = self.get_indicators(df)
        if df is None or df.empty or df['ema_200'].isna().iloc[-2] or df['stoch_k'].isna().iloc[-2]:
            return None
            
        current = df.iloc[-2]
        previous = df.iloc[-3]
        price = df.iloc[-1]['close']
        
        # Phân tích xu hướng chính
        is_uptrend = price > current['ema_200']
        is_downtrend = price < current['ema_200']
        
        # Phân tích giao cắt Stochastic RSI
        stoch_cross_up = previous['stoch_k'] <= previous['stoch_d'] and current['stoch_k'] > current['stoch_d']
        stoch_cross_down = previous['stoch_k'] >= previous['stoch_d'] and current['stoch_k'] < current['stoch_d']
        
        # Điều kiện Scalping MUA (LONG)
        # 1. Đang uptrend
        # 2. StochRSI K vừa cắt lên D ở vùng quá bán (<20)
        # 3. Giá chạm hoặc đâm thủng dải Bollinger dưới
        long_condition = (
            is_uptrend and 
            stoch_cross_up and 
            current['stoch_k'] < self.params['stoch_oversold'] and
            price <= current['bb_lower'] * 1.001  # Nhích 0.1% cho dễ khớp
        )
        
        # Điều kiện Scalping BÁN (SHORT)
        # 1. Đang downtrend
        # 2. StochRSI K vừa cắt xuống D ở vùng quá mua (>80)
        # 3. Giá chạm hoặc đâm thủng dải Bollinger trên
        short_condition = (
            is_downtrend and 
            stoch_cross_down and 
            current['stoch_k'] > self.params['stoch_overbought'] and
            price >= current['bb_upper'] * 0.999
        )
        
        # Ưu tiên đánh du kích, nếu đang sideway (Bollinger bóp nghẹt) cũng có thể quất
        bb_width = (current['bb_upper'] - current['bb_lower']) / current['bb_middle']
        is_sideway = bb_width < 0.02 # Biên độ dải BB dưới 2%
        
        if is_sideway:
            # Trong sideway, chỉ cần StochRSI cắt là phang, không cần EMA200
            if stoch_cross_up and current['stoch_k'] < 30:
                long_condition = True
            elif stoch_cross_down and current['stoch_k'] > 70:
                short_condition = True
        
        # === ÁP DỤNG LLM MARKET BIAS ===
        try:
            import yaml
            from pathlib import Path
            strat_path = Path(__file__).parent.parent / 'config' / 'strategies.yaml'
            with open(strat_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f)
                bias_dir = strat.get('ai_bias', {}).get('direction', 'NONE')
                bias_target = strat.get('ai_bias', {}).get('target_coin', 'ALL')
                
                # Bắt buộc chờ AI phân tích trước khi vào lệnh
                if bias_dir == 'NONE':
                    return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
                
                # Nếu có chỉ định đồng coin cụ thể (so sánh chính xác base_coin)
                clean_sym = symbol.split(':')[0].strip().upper()
                base_coin = clean_sym.split('/')[0] if '/' in clean_sym else clean_sym
                if bias_target != 'ALL' and bias_target.upper() != base_coin:
                    return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
                
                # Lọc hướng đánh
                if bias_dir == 'BULLISH':
                    short_condition = False  # Cấm SHORT khi đang BULLISH
                elif bias_dir == 'BEARISH':
                    long_condition = False   # Cấm LONG khi đang BEARISH
                elif bias_dir == 'HIGH_RISK':
                    return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
        except Exception:
            # Nếu AI chưa ghi file hoặc lỗi, tạm HOLD để an toàn
            return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
            
        pt_pct = float(self.params.get('profit_target_pct', 0.005))
        sl_pct = float(self.params.get('stop_loss_pct', 0.005))

        if long_condition:
            # TP/SL cứng cho scalping
            take_profit = price * (1 + pt_pct)
            stop_loss = price * (1 - sl_pct)
            
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=0.9,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'Scalping_Long', 'stoch_k': current['stoch_k'], 'sideway': is_sideway}
            )
            
        elif short_condition:
            take_profit = price * (1 - pt_pct)
            stop_loss = price * (1 + sl_pct)
            
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=0.9,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'Scalping_Short', 'stoch_k': current['stoch_k'], 'sideway': is_sideway}
            )
            
        return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)

