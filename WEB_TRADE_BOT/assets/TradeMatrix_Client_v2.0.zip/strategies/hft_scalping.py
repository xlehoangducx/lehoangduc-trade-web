import pandas as pd
import ta
import numpy as np
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal

class HFTScalpingStrategy(BaseStrategy):
    """
    Chiến lược High-Frequency Scalping (Giao dịch tần suất cao).
    Mục tiêu: Đánh siêu ngắn trên khung 1m hoặc 5m, ăn lợi nhuận siêu nhỏ nhưng liên tục.
    Được cộng đồng mạng (GitHub/TradingView) đánh giá cao cho bot HFT.
    Sử dụng: EMA 200 (Xác định trend lớn) + Stochastic RSI (Bắt sóng nhỏ) + Bollinger Bands.
    """
    _strat_yaml_mtime: float = -1.0
    _strat_yaml_cache: Optional[dict] = None

    def __init__(self, name: str = "HFTScalping", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'ema_period': 200,          # Trend chính
                    'stoch_rsi_period': 14,
                    'stoch_rsi_k': 3,
                    'stoch_rsi_d': 3,
                    'stoch_oversold': 20,       # Vùng quá bán siêu nhạy
                    'stoch_overbought': 80,     # Vùng quá mua siêu nhạy
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'atr_period': 14,
                    'profit_target_pct': 0.005, # Chốt lời siêu ngắn 0.5% giá trị thực (x10 = 5% ROE)
                    'stop_loss_pct': 0.005      # Cắt lỗ 0.5%
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        ema_p = int(self.params.get('ema_period', 200))
        stoch_p = int(self.params.get('stoch_rsi_period', 14))
        stoch_k = int(self.params.get('stoch_rsi_k', 3))
        stoch_d = int(self.params.get('stoch_rsi_d', 3))
        bb_p = int(self.params.get('bb_period', 20))
        bb_s = float(self.params.get('bb_std', 2.0))
        atr_p = int(self.params.get('atr_period', 14))

        if df is None or len(df) < ema_p:
            return df
            
        df = df.copy()
        
        # EMA 200 để xác định xu hướng lớn
        df['ema_200'] = ta.trend.EMAIndicator(df['close'], window=ema_p).ema_indicator()
        
        # Stochastic RSI siêu nhạy cho sóng ngắn
        stoch_rsi = ta.momentum.StochRSIIndicator(
            close=df['close'], 
            window=stoch_p,
            smooth1=stoch_k,
            smooth2=stoch_d
        )
        df['stoch_k'] = stoch_rsi.stochrsi_k() * 100
        df['stoch_d'] = stoch_rsi.stochrsi_d() * 100
        
        # Bollinger Bands để tìm điểm xả nén
        bb = ta.volatility.BollingerBands(df['close'], window=bb_p, window_dev=bb_s)
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_upper'] = bb.bollinger_hband()
        df['bb_middle'] = bb.bollinger_mavg()
        
        # ATR để tính biến động chớp nhoáng
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=atr_p).average_true_range()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        df = self.get_indicators(df)
        if df is None or df.empty or df['ema_200'].isna().iloc[-2] or df['stoch_k'].isna().iloc[-2]:
            return None
            
        current = df.iloc[-2]
        previous = df.iloc[-3]
        closed_price = float(current['close'])
        price = float(df.iloc[-1]['close'])
        
        # Phân tích xu hướng chính dựa trên nến đã đóng hoàn chỉnh (iloc[-2]) chống nhiễu râu nến chưa đóng
        is_uptrend = closed_price > current['ema_200']
        is_downtrend = closed_price < current['ema_200']
        
        # Phân tích giao cắt Stochastic RSI
        stoch_cross_up = previous['stoch_k'] <= previous['stoch_d'] and current['stoch_k'] > current['stoch_d']
        stoch_cross_down = previous['stoch_k'] >= previous['stoch_d'] and current['stoch_k'] < current['stoch_d']
        
        # Điều kiện Scalping MUA (LONG) neo trên nến đã đóng (current = iloc[-2])
        long_condition = (
            is_uptrend and 
            stoch_cross_up and 
            current['stoch_k'] < self.params['stoch_oversold'] and
            (closed_price <= current['bb_lower'] * 1.001 or float(current['low']) <= current['bb_lower'] * 1.001)
        )
        
        # Điều kiện Scalping BÁN (SHORT) neo trên nến đã đóng (current = iloc[-2])
        short_condition = (
            is_downtrend and 
            stoch_cross_down and 
            current['stoch_k'] > self.params['stoch_overbought'] and
            (closed_price >= current['bb_upper'] * 0.999 or float(current['high']) >= current['bb_upper'] * 0.999)
        )
        
        # Ưu tiên đánh du kích, nếu đang sideway (Bollinger bóp nghẹt) cũng có thể quất
        bb_width = (current['bb_upper'] - current['bb_lower']) / current['bb_middle'] if current['bb_middle'] > 0 else 0.0
        is_sideway = bb_width < 0.02 # Biên độ dải BB dưới 2%
        
        if is_sideway:
            if stoch_cross_up and current['stoch_k'] < 30 and float(current['low']) <= current['bb_lower'] * 1.002:
                long_condition = True
            elif stoch_cross_down and current['stoch_k'] > 70 and float(current['high']) >= current['bb_upper'] * 0.998:
                short_condition = True
        
        # === ÁP DỤNG LLM MARKET BIAS (CÓ CACHE RAM CHỐNG NGHẼN I/O ĐA LUỒNG) ===
        try:
            import yaml
            from pathlib import Path
            strat_path = Path(__file__).parent.parent / 'config' / 'strategies.yaml'
            mtime = strat_path.stat().st_mtime if strat_path.exists() else 0.0
            if HFTScalpingStrategy._strat_yaml_cache is None or mtime != HFTScalpingStrategy._strat_yaml_mtime:
                with open(strat_path, 'r', encoding='utf-8') as f:
                    HFTScalpingStrategy._strat_yaml_cache = yaml.safe_load(f) or {}
                HFTScalpingStrategy._strat_yaml_mtime = mtime
            strat = HFTScalpingStrategy._strat_yaml_cache or {}
            bias_dir = strat.get('ai_bias', {}).get('direction', 'NONE')
            bias_target = strat.get('ai_bias', {}).get('target_coin', 'ALL')
            
            if bias_dir == 'NONE':
                return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
            
            clean_sym = symbol.split(':')[0].strip().upper()
            base_coin = clean_sym.split('/')[0] if '/' in clean_sym else clean_sym
            if bias_target != 'ALL' and bias_target.upper() != base_coin:
                return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
            
            if bias_dir == 'BULLISH':
                short_condition = False
            elif bias_dir == 'BEARISH':
                long_condition = False
            elif bias_dir == 'HIGH_RISK':
                return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
        except Exception:
            return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
            
        atr_val = float(current.get('atr', 0.0) or 0.0)
        atr_pct = (atr_val / price) if (price > 0 and atr_val > 0) else 0.01
        sl_pct = min(0.035, max(0.015, float(self.params.get('stop_loss_pct', 0.015)), 1.2 * atr_pct))
        pt_pct = max(sl_pct * 1.8, float(self.params.get('profit_target_pct', 0.027)))

        if long_condition:
            take_profit = price * (1 + pt_pct)
            stop_loss = price * (1 - sl_pct)
            
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=0.9,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'Scalping_Long', 'stoch_k': current['stoch_k'], 'sideway': is_sideway}
            )
            
        elif short_condition:
            take_profit = price * (1 - pt_pct)
            stop_loss = price * (1 + sl_pct)
            
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=0.9,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'Scalping_Short', 'stoch_k': current['stoch_k'], 'sideway': is_sideway}
            )
            
        return TradeSignal(signal=Signal.HOLD, symbol=symbol, confidence=0.0, strategy=self.name, price=price)
