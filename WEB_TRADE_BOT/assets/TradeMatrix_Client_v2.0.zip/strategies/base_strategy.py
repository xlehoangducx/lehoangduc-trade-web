from abc import ABC, abstractmethod
import pandas as pd
from typing import Dict, Optional
from enum import Enum

class Signal(Enum):
    BUY = 'buy'
    SELL = 'sell'
    HOLD = 'hold'

class TradeSignal:
    def __init__(self, signal: Signal, symbol: str, confidence: float, 
                 strategy: str, price: float, stop_loss: float = None,
                 take_profit: float = None, metadata: dict = None):
        # Store all attributes
        self.signal = signal
        self.symbol = symbol
        self.confidence = confidence
        self.strategy = strategy
        self.price = price
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.metadata = metadata or {}
        self.timestamp = pd.Timestamp.now()

class BaseStrategy(ABC):
    def __init__(self, name: str, config: dict):
        self.name = name
        self.config = config
        self.params = config.get('params', {})
        self.weight = config.get('weight', 0.25)
        self.enabled = config.get('enabled', True)
    
    @abstractmethod
    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        pass
    
    @abstractmethod
    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        pass
