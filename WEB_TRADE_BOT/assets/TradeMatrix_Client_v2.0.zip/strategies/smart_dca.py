import pandas as pd
from typing import Optional, List, Dict, Any
from .base_strategy import BaseStrategy, TradeSignal, Signal

class SmartDCAStrategy(BaseStrategy):
    """
    Chiến lược Trung bình giá thông minh (Smart DCA).
    Mua khi giá giảm mạnh từ đỉnh gần nhất và tiếp tục DCA nếu giá giảm qua các mốc.
    Bán khi trung bình vị thế đạt phần trăm chốt lời kỳ vọng.
    """
    def __init__(self, name: str = "SmartDCA", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'dip_threshold': 1.5, # Mua khi giảm 1.5% từ đỉnh cao nhất gần đây
                    'local_high_window': 12, # Rút ngắn cửa sổ tìm đỉnh gần nhất (nhạy hơn)
                    'dca_drop_steps': [1.0, 2.5, 5.0, 10.0], # Phần trăm giảm từ trung bình giá mua để DCA
                    'take_profit_pct': 1.5 # Chốt lời tổng thể khi lãi 1.5%
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Tìm đỉnh cao cục bộ để tính toán độ sâu của cú giảm giá (dip).
        """
        local_high_window = self.params.get('local_high_window', 24)
        if df is None or len(df) < local_high_window:
            return df
            
        df = df.copy()
        
        # Tìm đỉnh cao nhất trong khung thời gian local_high_window
        df['local_high'] = df['close'].rolling(window=local_high_window, min_periods=1).max()
        
        # Tính phần trăm giảm giá từ đỉnh
        df['dip_pct'] = ((df['local_high'] - df['close']) / df['local_high']) * 100
        
        return df
        
    def calculate_dca_levels(self, current_price: float, avg_entry: float) -> List[float]:
        """
        Tính toán các mức giá mục tiêu cho các lần mua trung bình giá (DCA).
        """
        levels = []
        drop_steps = self.params.get('dca_drop_steps', [2.0, 5.0, 10.0, 15.0])
        for drop in drop_steps:
            level_price = avg_entry * (1 - drop / 100.0)
            levels.append(level_price)
        return levels
        
    def should_dca(self, current_price: float, positions: Dict[str, Any]) -> bool:
        """
        Kiểm tra xem có thỏa mãn điều kiện để DCA tiếp theo hay không.
        """
        avg_entry = positions.get('avg_entry_price', 0.0)
        dca_count = positions.get('dca_count', 0)
        
        if avg_entry <= 0:
            return False
            
        dca_levels = self.calculate_dca_levels(current_price, avg_entry)
        
        # Chỉ DCA nếu chưa vượt quá số lần DCA tối đa
        if dca_count < len(dca_levels):
            next_target = dca_levels[dca_count]
            if current_price <= next_target:
                return True
                
        return False

    def analyze(self, df: pd.DataFrame, symbol: str, positions: dict = None) -> Optional[TradeSignal]:
        """
        Tạo tín hiệu mua (Bắt đáy/DCA) hoặc bán (Chốt lời toàn bộ).
        Cần truyền current_positions thông qua argument positions để theo dõi vị thế.
        """
        if positions is None:
            positions = {}
            
        df = self.get_indicators(df)
        
        if df is None or df.empty or 'dip_pct' not in df.columns or pd.isna(df['dip_pct'].iloc[-2]):
            return None
            
        current = df.iloc[-2]
        price = float(df.iloc[-1]['close'])
        
        avg_entry = positions.get('avg_entry_price', 0.0)
        amount = positions.get('amount', 0.0)
        
        # Đã có vị thế hiện tại (đang ôm đồng coin này)
        if amount > 0 and avg_entry > 0:
            current_profit_pct = ((price - avg_entry) / avg_entry) * 100
            
            # Kiểm tra xem đã đạt lợi nhuận chốt lời chưa
            if current_profit_pct >= float(self.params.get('take_profit_pct', 1.5)):
                return TradeSignal(
                    signal=Signal.SELL,
                    symbol=symbol,
                    confidence=0.9,
                    strategy=self.name,
                    price=price,
                    metadata={'profit_pct': current_profit_pct, 'action': 'Take Profit'}
                )
                
            # Kiểm tra cắt lỗ (Hard Stop Loss)
            max_loss_pct = float(self.params.get('max_loss_pct', 2.5))
            if current_profit_pct <= -max_loss_pct:
                return TradeSignal(
                    signal=Signal.SELL,
                    symbol=symbol,
                    confidence=1.0,
                    strategy=self.name,
                    price=price,
                    metadata={'profit_pct': current_profit_pct, 'action': 'Stop Loss'}
                )
                
            # Không DCA xuyên qua Hard Stop của vị thế LONG.
            sl_pct = min(0.035, max(0.015, float(self.params.get('max_loss_pct', 2.5)) / 100.0))
            stop_loss = avg_entry * (1.0 - sl_pct)
            if price <= stop_loss:
                return TradeSignal(
                    signal=Signal.SELL,
                    symbol=symbol,
                    confidence=1.0,
                    strategy=self.name,
                    price=price,
                    metadata={'profit_pct': current_profit_pct, 'action': 'Stop Loss'}
                )

            # Kiểm tra xem giá có giảm đủ sâu để kích hoạt mốc DCA kế tiếp không
            if self.should_dca(price, positions):
                return TradeSignal(
                    signal=Signal.BUY,
                    symbol=symbol,
                    confidence=0.8,
                    strategy=self.name,
                    price=price,
                    stop_loss=stop_loss,
                    metadata={'action': 'DCA Buy', 'avg_entry': avg_entry, 'dca_count': positions.get('dca_count', 0)}
                )
        else:
            # Chưa có vị thế, tìm điểm vào lệnh ban đầu khi giá điều chỉnh (Dip) trên nến đã đóng
            dip_thresh = float(self.params.get('dip_threshold', 1.5))
            local_high_val = float(current.get('local_high') or price)
            live_dip_pct = ((local_high_val - price) / local_high_val * 100.0) if local_high_val > 0 else 0.0
            # Đảm bảo cả nến đóng iloc[-2] và giá hiện tại vẫn đang ở vùng chiết khấu (chưa bật tăng phá đỉnh)
            if current['dip_pct'] >= dip_thresh and live_dip_pct >= (dip_thresh * 0.7):
                sl_pct = min(0.035, max(0.015, float(self.params.get('max_loss_pct', 2.5)) / 100.0))
                stop_loss = price * (1.0 - sl_pct)
                take_profit = price * (1.0 + max(sl_pct * 1.8, float(self.params.get('take_profit_pct', 2.7)) / 100.0))
                return TradeSignal(
                    signal=Signal.BUY,
                    symbol=symbol,
                    confidence=0.7,
                    strategy=self.name,
                    price=price,
                    stop_loss=stop_loss,
                    take_profit=take_profit,
                    metadata={'action': 'Initial Dip Buy', 'dip_pct': current['dip_pct']}
                )
                
        return TradeSignal(
            signal=Signal.HOLD,
            symbol=symbol,
            confidence=0.0,
            strategy=self.name,
            price=price
        )
