import numpy as np
import pandas as pd
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal

class MomentumBreakoutStrategy(BaseStrategy):
    """
    Chiến thuật Momentum & Breakout.
    Phát hiện các cú sập (Breakdown) hoặc bứt phá (Breakout) mạnh mẽ với khối lượng lớn.
    Giúp bot không bỏ lỡ các đợt bão (như cú sập BTC) khi RSI đã quá bán.
    """
    def __init__(self, name: str = "MomentumBreakout", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'adx_threshold': 25,
                    'vol_multiplier': 1.5,
                    'atr_multiplier_sl': 1.5,
                    'atr_multiplier_tp': 3.0
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        import ta
        if df is None or len(df) < max(self.params.get('bb_period', 20), 50):
            return df
            
        df = df.copy()
        
        # Bollinger Bands
        bb = ta.volatility.BollingerBands(
            df['close'], 
            window=self.params.get('bb_period', 20), 
            window_dev=self.params.get('bb_std', 2.0)
        )
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_upper'] = bb.bollinger_hband()
        
        # Volume SMA
        df['vol_sma'] = df['volume'].rolling(window=self.params.get('bb_period', 20)).mean()
        
        # ATR
        df['atr'] = ta.volatility.AverageTrueRange(
            df['high'], df['low'], df['close'], window=14
        ).average_true_range()
        
        # ADX
        adx_indicator = ta.trend.ADXIndicator(
            df['high'], df['low'], df['close'], window=14
        )
        df['adx'] = adx_indicator.adx()

        # RSI (dùng để chặn bẫy quá bán/quá mua khi breakout/breakdown)
        df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=14).rsi()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        if df is None or len(df) < 50:
            return None
        df = self.get_indicators(df)
        if (
            df is None
            or len(df) < 50
            or 'atr' not in df.columns
            or 'vol_sma' not in df.columns
            or 'bb_lower' not in df.columns
            or pd.isna(df['atr'].iloc[-2])
            or pd.isna(df['vol_sma'].iloc[-2])
        ):
            return None
            
        # Kiểm tra Breakout & Volume trên nến ĐÃ ĐÓNG CỬA HOÀN CHỈNH (iloc[-2]) so với nến trước đó (iloc[-3])
        current = df.iloc[-2]
        previous = df.iloc[-3]
        
        price = float(df.iloc[-1]['close'])
        atr = float(current['atr'])
        
        # Điều kiện Động lượng (Momentum) & Thanh khoản
        strong_momentum = current['adx'] > self.params.get('adx_threshold', 25)
        high_volume = current['volume'] > current['vol_sma'] * self.params.get('vol_multiplier', 1.5)
        
        # Lọc bẫy RSI & Hình thái nến (Candlestick Anatomy):
        # Không SHORT khi RSI quá bán (< 32) hoặc nến rút chân dưới mạnh (>= 35%);
        # Không BUY khi nến bị xả râu trên mạnh (>= 35%), nhưng cho phép RSI lên tới 74.0 nếu là nến xanh đặc bão volume (uwick < 25%, vol >= 2.0x)
        candle_rng = max(1e-8, float(current['high'] - current['low']))
        upper_wick_pct = float(current['high'] - max(current['open'], current['close'])) / candle_rng
        lower_wick_pct = float(min(current['open'], current['close']) - current['low']) / candle_rng
        vol_curr = float(current.get('volume', 1.0) or 1.0)
        vol_sma_val = float(current.get('vol_sma', 1.0) or 1.0)
        vol_ratio = vol_curr / max(1e-6, vol_sma_val)

        rsi_val = float(current.get('rsi', 50.0) if 'rsi' in current and pd.notna(current['rsi']) else 50.0)
        rsi_breakdown_ok = rsi_val >= 32.0 or (lower_wick_pct < 0.20 and vol_ratio >= 2.0 and rsi_val >= 28.0)
        rsi_breakout_ok = rsi_val <= 68.0 or (upper_wick_pct < 0.25 and vol_ratio >= 2.0 and rsi_val <= 74.0)

        # 1. BREAKDOWN (Sập mạnh xuyên thủng dải Bollinger dưới, nến đỏ không rút chân mạnh) -> BÁN (SHORT)
        is_breakdown = (
            current['close'] < current['bb_lower'] and
            previous['close'] >= previous['bb_lower'] and
            current['close'] < current['open'] and
            lower_wick_pct < 0.35 and
            strong_momentum and high_volume and rsi_breakdown_ok
        )
        
        # 2. BREAKOUT (Bơm mạnh xuyên thủng dải Bollinger trên, nến xanh không bị xả râu đỉnh) -> MUA (LONG)
        is_breakout = (
            current['close'] > current['bb_upper'] and
            previous['close'] <= previous['bb_upper'] and
            current['close'] > current['open'] and
            upper_wick_pct < 0.35 and
            strong_momentum and high_volume and rsi_breakout_ok
        )

        # Confidence động theo ADX và Volume thay vì hardcode 0.90
        adx_raw = current.get('adx')
        adx_val = float(adx_raw) if (adx_raw is not None and pd.notna(adx_raw)) else 0.0
        dynamic_conf = min(0.92, max(0.68, 0.72 + 0.10 * min(2.0, max(0.0, (adx_val - 25.0) / 20.0)) + 0.10 * min(2.0, max(0.0, (vol_ratio - 1.5) / 1.5))))
        calc_confidence = round(dynamic_conf, 2)
        
        if is_breakdown:
            stop_loss = price + atr * self.params.get('atr_multiplier_sl', 1.5)
            take_profit = price - atr * self.params.get('atr_multiplier_tp', 3.0)
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'BREAKDOWN', 'adx': current['adx'], 'rsi': rsi_val}
            )
            
        elif is_breakout:
            stop_loss = price - atr * self.params.get('atr_multiplier_sl', 1.5)
            take_profit = price + atr * self.params.get('atr_multiplier_tp', 3.0)
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=calc_confidence,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'BREAKOUT', 'adx': current['adx'], 'rsi': rsi_val}
            )
            
        return None
