@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONWARNINGS=ignore
title TRADEMATRIX - KHOI DONG LAI

cd /d "%~dp0"

echo.
echo ======================================================
echo   TRADEMATRIX QUANT CLIENT v2.0 - RESTART BOT
echo ======================================================
echo.
echo [1/3] Dang dong cac tien trinh cu tren Port 5000...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }" >nul 2>&1
timeout /t 2 /nobreak >nul

echo [2/3] Kiem tra dong bo thoi gian may tinh...
w32tm /resync /nowait >nul 2>&1

echo [3/3] Khoi dong moi Trade Bot...
start "" "%~dp0START.bat"
exit /b 0
