# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & LEAN CONSTITUTION
> **Single Source of Truth (SSOT) Tinh Gọn — Nạp Tự Động 100% Không Bị Cắt Cụt (Zero Truncation Guarantee < 21 KB)**
> *Dành riêng cho mọi phiên làm việc mới trên Antigravity IDE. Tự động liên kết thư viện chuyên biệt trong `docs/`.*

---

## ⚡ 0.0. GIAO THỨC KHỞI ĐỘNG BẮT BUỘC (MANDATORY BOOTSTRAP DIRECTIVE)
> [!IMPORTANT]
> **MỌI PHIÊN AI MỚI KHI KHỞI TẠO BẮT BUỘC THỰC THI NGAY:**
> Trước khi đưa ra bất kỳ kết luận hay sửa code, AI BẮT BUỘC dùng `read_file` nạp 5 file SSOT cốt lõi:
> 1. [`docs/LESSONS_LEARNED_SESSION_16_AND_V64_BOM126.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_16_AND_V64_BOM126.md): Bản **MỚI NHẤT V6.4 (`BOM #30 → #126A–D`, commit `50bc5ec`)** — **15 Vũ Khí (`VK1..VK15`)**, 9 mâu thuẫn đã khóa, 6 nguyên nhân gây hồi quy, Bản đồ 10 Điểm Nóng Liên Kết Chéo, trạng thái **PC1=DEV Offline (`0 bot`), PC2=LIVE duy nhất (`83/83 SHA-256`)**.
> 2. [`docs/LESSONS_LEARNED_SESSION_15_AND_V60.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_15_AND_V60.md): Nền tảng **V6.0** (`BOM #12–#29`, Quét 10 Trục `tools/exhaustive_10axis_audit.py`, Checklist 8 Trạm thêm tín hiệu mới).
> 3. [`docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md`](file:///d:/TRADE/docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md): SSOT Shadow Đa Tầng 2 Chiều, 3 Slot cấy ghép (`SLOT A/B1/B2`), Ma trận 3 Lớp Tài Sản (`ALTCOIN/MAJOR/TRADFI`) & Thang vốn (`\$25 -> \$20,000`).
> 4. [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md): Bảng điểm tin cậy thực tế (Hiện tại: **10% — Báo động đỏ tối thượng**).
> 5. [`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md): SSOT Quản lý vốn, MFE Ratchet & Tam Tầng SL V4.1.
> - **CẢNH BÁO API BAN:** TUYỆT ĐỐI KHÔNG chạy `tools/report_shadow_alpha.py` hoặc script gọi REST Binance trên máy đang chạy Live (nguy cơ IP Ban `418/-1003`); chỉ kiểm toán Offline bằng `tools/exhaustive_10axis_audit.py`, bản sao `trade_bot.db` (`PRAGMA query_only=ON`) và `tools/full_historical_signal_and_position_simulator.py`.

---

## 👑 0. TÔN CHỈ TỐI THƯỢNG (SUPREME QUANT DOCTRINE)
### **"THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN (SMART INVERSION & WHALE FLOW ALIGNMENT)"**
1. **Mục tiêu cốt lõi:** Kiếm lợi nhuận bền vững cùng phe Số Đông Chiến Lược và Dòng Tiền Cá Mập (Whale Flow). KHÔNG phòng thủ thụ động mù quáng (`Veto = 0$`).
2. **Phân tích Ngược lại (Inversion Analysis):**
   - **Cá mập xả thác đổ / Số đông SELL:** Xác nhận SHORT (`🌊 SMART WATERFALL BREAKDOWN SHORT`).
   - **Cá mập bơm bão Volume (nến xanh đặc râu < 30%, RVol >= 1.8x):** Cấm Short cản tàu, kích hoạt `🚀 SMART MOMENTUM RIDE BUY` (Pha 1).
   - **Sóng bơm kiệt sức râu xả đỉnh >= 35%:** Ưu tiên Pha 2 (`⚡ EXHAUSTION FADING SHORT`).
   - **Khiên JEV Đa Khung (`JEV MTF TREND SHIELD`):** Cấm xóa phiếu JEV Agent hoặc ép ngược trend khi JEV 4H BUY/SELL $\ge 70\%$.

---

## 🛑 0.1. DANH MỤC 8 CƠ CHẾ ĐÃ BỊ ĐÀO THẢI VĨNH VIỄN (PURGED ANTI-PATTERNS)
*CẤM BẬT LẠI HOẶC TÁI ĐỀ XUẤT 8 CƠ CHẾ NÀY:*
1. **CẮT THEO THỜI GIAN MÙ QUÁNG (`doa_15m, 25m, 35m`, `idle_120m`):** Xóa sổ. Thay bằng Mode 7 Telemetry Gate (xả khi dump $\ge 1.6x$).
2. **KHÓA HÒA VỐN NON TRƯỚC TP1 (< +0.65% MFE hoặc < 4.5 phút đầu):** Thay bằng Tam Tầng SL V4.1 ([`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md)):
   - *Dưới +0.85%:* ChoCH Early Profit Lock (+0.12% -> +0.80% khi ChoCH đối kháng RVol $\ge 1.5x$); Cushion SL (-0.25% tại MFE +0.80% hoặc +0.55% râu $\ge 35\%$); Cầu dao liên tài sản.
   - *Từ +0.85% trở lên:* Flash Hard BE (+0.22% Net BE khi MFE $\ge +1.15\%$ hoặc $\max(0.85\%, 0.85 \times \text{ATR})$). CẤM xóa mốc +0.85%.
3. **DE-RISKING SỚM KHÔNG LỌC THỜI GIAN (0.40 ATR):** Thay bằng 0.65 ATR + giữ $\ge 1.0$ phút.
4. **CHOP SHIELD VÔ HẠN (ATR BTC $\ge 1.2\%$ trên 15M):** Thay bằng ADX/ATR kèm giãn cách 120s.
5. **ĐẨY `Signal.HOLD` VÀO `by_strategy`:** Kéo tụt 31% raw_score. HOLD chỉ làm Veto độc lập.
6. **BỎ RƠI SIÊU SÓNG BẰNG FAST-SKIP PRE-LLM:** Whale Pump Storm được miễn trừ Fast-Skip để mở Pha 1.
7. **TỰ Ý LẬT CHIỀU LỆNH TẠI EXECUTION (`M1 Inversion` trong `_execute_order`):** Quyền Invert chỉ thuộc Aggregator + Quantum Gate.
8. **SHADOW OVERWRITE TRIỆT TIÊU BỘ LỌC VOLUME BẪY ĐÁY:** Bắt buộc kiểm tra `has_valid_trap_vol_ctx` (`RVol >= min_trap_rvol`).

---

## 🛑 0.2. GIAO THỨC BÁO ĐỘNG ĐỎ KHI CHUỖI THUA LIÊN TIẾP (CONSECUTIVE LOSS FORENSIC GATE)
* Ghi nhận $\ge 2$ lệnh thua liên tiếp trên Live: BẮT BUỘC kích hoạt Pháp y 4 Tầng: (1) Tín hiệu M1/15M $\to$ (2) AI/LLM $\to$ (3) Aggregator $\to$ (4) Siết SL/thoát lệnh. Rà soát toàn diện code & chạy mô phỏng hồi quy trước khi can thiệp.

---

## 🔬 0.3. TIÊU CHUẨN MÔ PHỎNG CHUẨN QUỸ ĐỊNH LƯỢNG (INSTITUTIONAL REPLAY STANDARD)
* BẮT BUỘC chạy `tools/full_historical_signal_and_position_simulator.py` (100% Offline) trước mọi đề xuất sửa code.
* **False Exits (lệnh thắng bị mất) BẮT BUỘC = 0!** Tái lập đầy đủ M1/Tick, MFE/MAE, phí Maker 0.02%, Taker 0.05%, Slippage 0.02%, 50% TP1 và Cushion SL.

---

## 💡 0.4. QUY TRÌNH PHÁP Y PHÂN LOẠI 6 NHÓM TÍN HIỆU THUA
1. **🔄 Nhóm 1 (Smart Inversion):** Đánh giá PnL Veto (0$) vs Invert (+).
2. **📈 Nhóm 2 (MTF Trend Violation):** Ngược 4H/1H chưa đảo chiều $\to$ siết `JEV MTF TREND SHIELD`.
3. **⏸️ Nhóm 3 (Veto / Stand Aside):** Sideway nén biên, bẫy 2 đầu, $RVol_{15M} < 0.8x$.
4. **⚡ Nhóm 4 (Early Exhaustion):** Thoát hiểm lỗ nhỏ qua Shock Rescue / ChoCH Choke SL.
5. **🐛 Nhóm 5 (Semantic & Runtime Bugs):** Sửa dứt điểm, kiểm thử AST 100%.
6. **🎲 Nhóm 6 (Statistical Noise):** Nhiễu thống kê bình thường của EV > 0. Cấm xóa bỏ.

---

## ⚖️ 0.5. QUY CHUẨN TỔNG KẾT, CHẤM ĐIỂM & DỌN RÁC
1. **Chỉ số tin cậy AI ([`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md)): `10%` (Báo động đỏ tối thượng).**
   - **Live Profit Invariant:** CẤM tự cộng điểm chỉ vì Simulator/AST đẹp! Chỉ cộng khi vị thế Live mở mới THỰC TẾ CÓ LỢI NHUẬN (`Net PnL > 0`) và `False Exits = 0`.
   - **Phạt lũy kế:** Tái phạm lỗi Timer cấm, sót code cũ đè code mới, hoặc lỗi tín hiệu đầu vào $\implies$ Trừ -5đ đến -15đ/lần.
2. **Dọn rác cuối phiên:** Chạy `python tools/clean_workspace.py` đảm bảo 0 file nháp trong `d:\TRADE`.

---

## 🛑 0.6. BỘ QUY TẮC BẤT BIẾN SÀN BINANCE & BẢNG PHÒNG TRỪ LỖI
1. **5 Bộ Lọc Sàn Cứng:** `LOT_SIZE` (`amount_to_precision`); `MIN_NOTIONAL` $\ge 5.0\text{ USDT}$ (`max(6.0, notional)`); `PRICE_FILTER`; `PERCENT_PRICE` ($\le 2\%$ Mark); `MAX_NUM_ALGO_ORDERS` $\le 10$.
2. **Mã lỗi Binance:** `-1013`, `-2011`, `-2019` (Ký quỹ $\le 50\%$ NAV), `-2021`, `-2022`, `-4116`, `-4181`, `-1021` (Clock lệch > 1000ms $\to$ chạy `Fix_Time.bat`), `-4411`, `-5022`, `418/-1003` (Cầu dao IP Ban trong `core/exchange.py`).
3. **Top 3 Lỗi Cấm Tuyệt Đối:** NameError/UnboundLocalError (AST 100%); Unpack thừa `get_ohlcv`; AttributeError (`aggregator.config`).

---

## 🏛️ 0.7. MA TRẬN 10 PHÂN LỚP TRADFI & SMART INVERSION PHIÊN MỸ
*Chi tiết 238 mã xem [`docs/QUANT_WORKFLOW_PLAYBOOK.md`](file:///d:/TRADE/docs/QUANT_WORKFLOW_PLAYBOOK.md):*
1. **10 Phân Lớp:** `SEMICONDUCTOR` (`SOXL/SOXS`), `NASDAQ_TECH` (`TQQQ/SQQQ`), `ASIAN_TECH`, `AI_INFRA_ENERGY`, `CRYPTO_PROXY` (`MSTU/CONL`), `EV_AEROSPACE` (`TSLL`), `COMMODITY_METALS`, `COMMODITY_ENERGY`, `BROAD_INDEX` (`UPRO/SPXU`), `TRADITIONAL_VALUE`.
2. **4 Rào Chắn:** (1) Khóa đối nghịch; (2) Khóa cùng gốc; (3) Chặn bắt đáy Bear ETF khi Benchmark Uptrend (`EMA20 > EMA50, ADX >= 25`); (4) Tối đa 1 vị thế rủi ro/ngành.
3. **Mở Phiên Mỹ (21:30–22:30 VN):** Nến 60m đầu $RVol \ge 1.8x$, xanh đặc râu xả $< 30\%$ $\implies$ Invert Short thành Momentum Ride Buy.
4. **Sandbox Mã Mới (< 72h) *(CHƯA triển khai code — quy tắc thiết kế)*:** Đòn bẩy $\le 3x$ (TradFi $2x$), ký quỹ $\le 10\%$ NAV. Thua $\ge 2$ lệnh $\to$ Cooldown 24h.

---

## 🔬 0.8. QUY TRÌNH PHÁT TRIỂN & ĐỐI SOÁT ĐỊNH LƯỢNG 7 BƯỚC
1. Phân lập nguyên nhân gốc rễ. 2. Mô phỏng toàn phần Zero-Timer. 3. Đối soát lịch sử (**False Exits = 0**). 4. Exhaustive Branch Coverage (LONG vs SHORT, 3 lớp tài sản). 5. Kiểm tra tuần hoàn 8 trạm (theo Checklist V6.0). 6. Chạy đủ **3 Cổng Cứng Offline**: `tools/exhaustive_10axis_audit.py` (**10/10 PASS**) + `tools/hard_constraints_gate.py` (**11/11**) + `tools/audit_system_integrity.py` (**6/6**). 7. `deploy_web_client.py` (chỉ khi người dùng duyệt) + `clean_workspace.py` + kiểm tra `StartTime >= ModifiedTime`.

---

## 🚫 0.9. MA TRẬN 30 BẤT BIẾN THỰC CHIẾN (PRODUCTION INVARIANTS)
1. **Zero-Timer Sniper:** Xóa `timeout_sec`. Hủy rình khi giá chạy mất ($> 1.5\text{ ATR}$) hoặc M1 gãy ($RVol_{M1} \ge 2.0x$).
2. **Win Rate vs Payoff:** Chấp nhận WR 37–55% khi Payoff $\ge 4.0x$ và lỗ trung bình giảm $> 70\%$.
3. **Dynamic Peak MFE:** Tính Fresh MFE từ nến M1 thực tế, cấm đọc giá trị tĩnh RAM.
4. **Timestamp Nến M1:** ChoCH bắt buộc $ts_{\text{candle}} \ge ts_{\text{entry}} - 10s$ (giữ đồng hồ Windows lệch $< 1s$ qua `Fix_Time.bat`).
5. **Mute Telegram Săn Rình:** Chỉ bắn Telegram khi ĐÃ KHỚP vị thế mở.
6. **Dọn Rác Workspace:** Chạy `tools/clean_workspace.py` cuối phiên.
7. **Khung SL ETF 3x:** `SOXL, TQQQ, UPRO` dùng $[1.8\%, 3.5\%]$, cấm ép trần $1.5\%$.
8. **Bức Tường Lửa Tâm Lý:** Cấm FOMO đánh tay 20x. Im lặng là bảo toàn vốn (`Veto = 0$`).
9. **Auto-Disaster Backup PC2:** Sao lưu vào `\\192.168.1.10\trade-web\BACKUP_MASTER_TRADE_AND_WEB`.
10. **4 Anti-Blindspots:** Quét 100% nhánh rẽ; rào chắn fallback; sàn ATR 1H; kiểm toán RAM vs Disk (`StartTime >= ModifiedTime`).
11. **Tam Tầng V4.1 & Flash BE:** Đóng BE tại $+0.85\%$ là thắng bảo toàn vốn ([`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md)).
12. **Zero-Timer Chu Kỳ Nến Đóng:** Thay timer giây/phút bằng `closed_m1_count >= 2`.
13. **Sàn Nhiễu Sub-0.50%:** Cấm hạ MFE Ratchet $< +0.40\%$. Chặn lỗ cắm thẳng từ Entry.
14. **Lỗi -2021 Immediate Exit:** Nâng SL dính `-2021` $\implies$ BẮT BUỘC đóng Market ngay (`_close_position_locked`).
15. **Three-Tier Audit:** Sửa ngay lỗi logic; cấm đổi ẩu tên biến; cache TTL 20–30s + `PRAGMA query_only=ON` cho UI/SQLite.
16. **Breathing Room vs Ratchet:** Khoảng thở săn TP1 Altcoin $\ge 0.50 \times \text{ATR}$.
17. **Sàn Climax KB10:** Altcoin `0.7%`, TradFi `0.5%` đồng bộ 3 tầng.
18. **Benchmark Thích Ứng Đòn Bẩy (V5.3):** ETF 3x `>= 2.50%`; 2x `>= 1.70%`; 1x `0.85%`.
19. **Exhaustive Branch Coverage (V5.3):** Xóa sạch tham số cũ (`mfe_trigger_th = 0.0035`) ở hàm trên.
20. **Zero-Timer Bar-Close (V5.3):** `closed_m1_count == 0`, $|\text{pnl}| \le 0.25\%$ được bảo vệ.
21. **Hard Purge vs Veto (V5.4):** Xóa sạch tín hiệu cản tàu khỏi code.
22. **Toán Tử Logic RVol 3 Lớp (V5.4):** Bắt buộc `AND c_vol_ratio >= min_trap_rvol` (`TradFi 0.85x / Major 1.00x / Altcoin 1.10x`).
23. **Pre-Fill Proximity Gate (V5.4):** Rút Maker khi Taker đối kháng $\ge 75\%$ và giá cận khớp $\le 0.35\%$.
24. **Xóa Cắt Market Non `is_mfe_ratchet_breached` (V5.8):** MFE Ratchet chỉ nâng SL Stop-Market lên sàn.
25. **Shadow Pathfinder 2 Chiều & 3 Slot (V5.8):** Chỉ cấy vào `SLOT A/B1/B2` khi đạt đủ 5 Tiêu Chuẩn Cứng ($N \ge 15$, $WR \ge 75\%$, $SL \le 20\%$, Net $> +5\$$, `False Exits = 0`). Kẹp biên SL/TP chuẩn 3 lớp tài sản (BOM #5).
26. **Đa Luồng WebSocket `@bookTicker` 2.0s & Chống Ban API (Gói A — V5.9):** Kéo SL/TP nhịp nhanh `2.0s` qua RAM WebSocket `@bookTicker` (0 REST weight), đối soát sàn `10–15s`, Pha 1 `max_workers=8`, kích hoạt cầu dao IP `418/-1003` (`core/exchange.py`).
27. **Shadow 2-Tier Regime `M21/M22` Không Gò Bó & Freshness 6h (Gói B — V5.9):** Cấm đột biến `confidence` ($\pm 0.04$) khi gắn nhãn Vũ Khí; dùng `Slow80 / Fast24` tươi trong **6 giờ gần nhất** (`BOM #10`) để xếp hạng ưu tiên Pha 2 (+8%) & Chứng Thực Kép 2 tầng (giữ tự do 100% 8 Vũ Khí khi Cân bằng). Không chặn vĩnh viễn model ML `CV < 58%` (91.9% coin có CV 40%–56%).
28. **Bảo Toàn Regex Song Ngữ, `protection_status` & Manifest Đồng Bộ (V5.9):** Mọi log Việt hóa BẮT BUỘC giữ thẻ gốc (`[MarketAnalysis]`, `[FAST-SKIP PRE-LLM]`, `[JEV Agent MTF]`, `Aggregated score for`); Free-Roll bắt buộc kiểm tra `protection_status in ('exchange_stop', 'exchange_stop_verified')` (BOM #6); `deploy_web_client.py` bắt buộc gồm `core/vietnamese_weapon_arsenal.py` & `dashboard/templates/pipeline_map.html` (BOM #9).
29. **Quét Tự Động 10 Trục Toàn Kho Code (`tools/exhaustive_10axis_audit.py`, V6.0):** BẮT BUỘC chạy đạt **10/10 PASS (0 err)** sau mọi lần thêm tín hiệu/vũ khí mới hay sửa code — chặn vĩnh viễn lỗi "bóng ma `hasattr`" (`MarketScanner.is_leveraged_etf` BOM #28), cửa hậu bỏ qua Cầu dao IP Ban (`ai/news_sentiment.py` BOM #29, `OrderFlowAnalyzer` BOM #24), lệch `sigma_step` TradFi (BOM #19), sót nhánh cũ `Opening Bell` (BOM #26/#27) và SQLite thiếu `PRAGMA query_only=ON`.
30. **15 Vũ Khí V6.4 & Kỷ Luật Chống Hồi Quy (`BOM #126A–D`):** Kho **15 Vũ Khí (`VK1..VK15`)** (`VK1/4/5/6/8` OFFICIAL, `VK2/3/7` PAUSED, `VK9/10` + `VK11..VK15` EXPERIMENTAL); bảo toàn `asyncio.Event` (`binance_ws`), `POST-KB5` macro re-check + `weapon_id` veto + đồng bộ `SLOT_A` (`bot`/`aggregator`), `AND→OR` JEV Guard 4H (`jev_agent`), không trừ phí 2 lần, `cloud_sync` multi-token & UI LIVE fail-closed. Kiểm tra đủ 10 Điểm Nóng trong `SESSION_16` trước mọi lần sửa code.

---

## 🛑 0.10. TÔN CHỈ TRIỆT TIÊU LỖI ĐẦU-CUỐI (ZERO-BUG CONSTITUTION)
*SSOT: [`docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md`](file:///d:/TRADE/docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md):*
1. **3 Nguyên Tắc Thép:** (1) Trace vòng đời 8 trạm; (2) Exhaustive Branch Coverage (LONG vs SHORT, 3 lớp tài sản); (3) Live Runtime & RAM Verification (`StartTime >= ModifiedTime`).

---

## 💡 0.11. GIAO THỨC SHADOW PATHFINDER & PHÒNG LAB TỰ CHỦ (`BOM #133`)
* **SSOT:** [`docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md`](file:///d:/TRADE/docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md) (mục **§§5–9**).
  1. **6 Cổng Thăng Hạng `EXPERIMENTAL`:** Đủ 5 Tiêu Chuẩn Cứng ($N \ge 15$, $WR \ge 75\%$, $SL \le 20\%$, Net $> +5\$$, `False Exits = 0`) **+** **Cổng 6 Dry-Run 8 Trạm (`BOM #133`)**: `hijacked_opposite == 0`, `T3 khớp >= 60%`, `T3+T4 qua >= 45%`. Lên `OFFICIAL` phải qua **Graduation Guard** (`N_live >= 15`, `Net > 0$`, `WR >= 55%` hoặc `PF >= 1.50`, `SL <= 30%`).
  2. **3 Slot Cố Định:** `SLOT A` (`bot.py`), `SLOT B1` (`signal_aggregator.py` thuận chiều), `SLOT B2` (`signal_aggregator.py` lật ngược theo JEV 4H). Dài hạn giới hạn **10–14 Vũ Khí cốt lõi**.

---

## 🏛️ 1. HẠ TẦNG 2 MÁY TÍNH & 4 LOẠI PHIÊN LÀM VIỆC
- **PC1 (`d:\TRADE` — DEV & QUANT Offline, `PC1_BOT_PROCS=0`):** Python 3.14.7 venv, kho nguồn V6.4 (**15 Vũ Khí `VK1..VK15`**, `BOM #1–#126D`, 250 mã TradFi, Risk Parity 4 lớp), nơi chạy 5–6 cổng kiểm toán Offline. Cấm chạy bot Live hoặc REST Binance scan trên PC1.
- **PC2 (`\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` — LIVE Duy Nhất):** Đã đồng bộ **83/83 file SHA-256** (`50bc5ec`). Sau deploy, luôn chạy `Fix_Time.bat` + `RESTART.bat` trên PC2 để đồng hồ lệch `< 1s` & nạp RAM mới.
- **4 Loại Phiên:** `[OPS]` Giám sát Live | `[QUANT]` Mô phỏng Offline | `[DEV]` Sửa Code & Web | `[RESTORE]` Khôi phục Thảm họa từ PC2 / Ổ cứng rời.

---

## 🛡️ 2. RÀO CHẮN CỨNG BẰNG CODE (HARD CONSTRAINTS GATE 11/11 + 10-AXIS AUDIT 10/10)
*Kiểm toán tự động qua `python tools/exhaustive_10axis_audit.py` (**10/10**) & `python tools/hard_constraints_gate.py` (**11/11**):*
1. Cấm `time_based_exits`. 2. Cấm `pop('jev_agent')` thiếu MTF Shield. 3. SL `[1.0%, 3.5%]`. 4. `/api/stop` idempotent. 5. Cache bản quyền 60s. 6. Cấm bypass MTF Trend Veto thiếu Waterfall. 7. SL Altcoin ATR đến 3.5%. 8. Cushion SL held_minutes >= 3.0. 9. AST 0 NameError. 10. Đồng bộ SSOT KB5. 11. Bộ lọc sàn Binance (-2011, -2021, Min Notional).

---

## 📚 3. BẢN ĐỒ TÀI LIỆU HỆ THỐNG (SSOT POINTERS)
- **Bài học V6.4 MỚI NHẤT (`BOM #30 → #126A–D`, 15 Vũ Khí, 9 Mâu Thuẫn, 6 Root Causes & 10 Điểm Nóng Liên Kết Chéo):** [`docs/LESSONS_LEARNED_SESSION_16_AND_V64_BOM126.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_16_AND_V64_BOM126.md)
- **Bài học V6.0 (`BOM #12–#29`, Quét 10 Trục `tools/exhaustive_10axis_audit.py`, Checklist 8 Trạm):** [`docs/LESSONS_LEARNED_SESSION_15_AND_V60.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_15_AND_V60.md)
- **Bài học V5.9 (Việt hóa `/so-do-dong`, `BOM #1–#11`, Gói A WS 2.0s, Gói B `M21/M22` 22 mô hình, 6 Cụm Alpha):** [`docs/LESSONS_LEARNED_SESSION_14_AND_V59.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_14_AND_V59.md)
- **Playbook Shadow Pathfinder 2 Chiều & 3 Slot Cấy Ghép:** [`docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md`](file:///d:/TRADE/docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md)
- **Bài học V5.8 (`PRE_V56 Surgical Release`, Pháp y SOPH/LYN/AKT):** [`docs/LESSONS_LEARNED_SESSION_13_AND_V58.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_13_AND_V58.md)
- **Bảng điểm tin cậy AI Trust (Hiện tại: 10%):** [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md)
- **Ma trận Tam Tầng Bảo Vệ Vốn V4.1:** [`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md)
- **Quy trình kiểm toán vòng đời tín hiệu đầu-cuối:** [`docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md`](file:///d:/TRADE/docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md)
- **Bài học V5.4 (Pháp y NVDA & ETH, RVol 3 lớp tài sản):** [`docs/LESSONS_LEARNED_SESSION_12_AND_V54.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_12_AND_V54.md)
- **Bài học thực chiến V5.0 (Phiên 9) & V3.7 (Phiên 4):** [`docs/LESSONS_LEARNED_SESSION_9_AND_V50.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_9_AND_V50.md) | [`docs/LESSONS_LEARNED_SESSION_4_AND_V37.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_4_AND_V37.md)
- **Ma trận 238 mã TradFi & Playbook chuẩn quỹ:** [`docs/QUANT_WORKFLOW_PLAYBOOK.md`](file:///d:/TRADE/docs/QUANT_WORKFLOW_PLAYBOOK.md)
- **Bản đồ tính năng hệ thống:** [`docs/FEATURE_MAP.md`](file:///d:/TRADE/docs/FEATURE_MAP.md)
- **Kho lưu trữ 112 bài học lịch sử:** [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md)
