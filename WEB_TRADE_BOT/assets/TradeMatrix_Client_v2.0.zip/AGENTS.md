# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & LEAN CONSTITUTION

> **Single Source of Truth (SSOT) Tinh Gọn — Nạp Tự Động 100% Không Bị Cắt Cụt (Zero Truncation)**

> *Dành riêng cho mọi phiên làm việc mới trên Antigravity IDE. Người dùng KHÔNG CẦN copy-paste prompt dài.*



---



## 👑 0. TÔN CHỈ TỐI THƯỢNG (SUPREME QUANT DOCTRINE)

### **"THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN (SMART INVERSION & WHALE FLOW ALIGNMENT)"**

1. **Mục tiêu cốt lõi:** Kiếm lợi nhuận bền vững bằng cách đi cùng phe Số Đông Chiến Lược và Dòng Tiền Cá Mập (Smart Money / Whale Flow). TUYỆT ĐỐI KHÔNG rơi vào tư duy phòng thủ thụ động / chỉ né tránh (`return None` / Veto = 0$).

2. **Phân tích Ngược lại (Inversion Analysis):** Trước mọi lệnh thua hoặc xung đột tín hiệu, câu hỏi bắt buộc phải là: *"Làm thế nào để LẬT NGƯỢC (Invert) lệnh thua đó thành LỆNH THẮNG đi thuận dòng tiền cá mập?"*:

   - **Cá mập xả thác đổ / Số đông báo SELL:** Loại bỏ bẫy đáy giả, xác nhận lệnh SHORT (`🌊 SMART WATERFALL BREAKDOWN SHORT`).

   - **Cá mập bơm bão Volume (nến xanh đặc râu < 30%, RVol >= 1.8x):** Cấm Short cản tàu, kích hoạt `🚀 SMART MOMENTUM RIDE BUY` (Pha 1).

   - **Sóng bơm kiệt sức xuất hiện râu xả đỉnh >= 35%:** Ưu tiên Pha 2 (`⚡ EXHAUSTION FADING SHORT`) bắt đỉnh ăn trọn nhịp sập.

   - **Bảo vệ JEV Đa Khung Thời Gian (`JEV MTF TREND SHIELD`):** Tuyệt đối cấm xóa phiếu của JEV Agent (`pop('jev_agent')`) hoặc ép Short ngược trend khi JEV 4H đang báo BUY mạnh $\ge 70\%$.



---



## 🛑 0.1. DANH MỤC 6 CƠ CHẾ ĐÃ BỊ ĐÀO THẢI VĨNH VIỄN (PURGED ANTI-PATTERNS)

*CẤM BẬT LẠI HOẶC TÁI ĐỀ XUẤT 6 CƠ CHẾ ĐÃ CHỨNG MINH GÂY THIỆT HẠI NẶNG NÀY:*

1. **CẮT THEO THỜI GIAN MÙ QUÁNG (`doa_15m`, `doa_25m`, `doa_35m`, `idle_120m`):** Đã xóa sổ vĩnh viễn (gây lỗ -3.63 USDT, cắt đúng đáy 87.5%). Thay bằng Mode 7 Telemetry Gate (xả khi volume dump $\ge 1.6x$).

2. **KHÓA HÒA VỐN NON TRƯỚC TP1 (dưới +0.65% MFE hoặc dưới 4.5 phút đầu):** Làm 82% lệnh bị quét văng siêu sóng. Thay bằng Tam Tầng Bảo Vệ Vốn V3.0 (Cushion SL -0.25% tại MFE +0.80%, Hard BE +0.22% tại MFE +1.15%).

3. **DE-RISKING SỚM KHÔNG LỌC THỜI GIAN (0.40 ATR):** Cắt non ở râu giật 12s đầu. Thay bằng 0.65 ATR + ép giữ $\ge 1.0$ phút.

4. **CHOP SHIELD VÔ HẠN (ATR BTC $\ge 1.2\%$ trên 15M):** Khóa cứng Altcoin suốt 3 tiếng. Thay bằng ADX/ATR kèm giãn cách 120s.

5. **ĐẨY `Signal.HOLD` VÀO `by_strategy`:** Kéo tụt 31% điểm raw_score của phe đa số. HOLD chỉ làm Veto độc lập.

6. **BỎ RƠI SIÊU SÓNG BẰNG FAST-SKIP PRE-LLM:** Bỏ rơi coin tăng dựng đứng. Whale Pump Storm được miễn trừ Fast-Skip để mở Pha 1.



---



## 🛑 0.2. GIAO THỨC BÁO ĐỘNG ĐỎ KHI CHUỖI THUA LIÊN TIẾP (CONSECUTIVE LOSS FORENSIC GATE)

1. **Quy tắc kích hoạt:** Khi hệ thống ghi nhận >= 2 lệnh thua liên tiếp trên Live:

   - NGHIÊM CẤM coi đây là "nhiễu ngẫu nhiên". BẮT BUỘC coi đây là dấu hiệu tiềm ẩn LỖI HỆ THỐNG / LỖI LOGIC NGẦM (Semantic Bug).

   - TỰ ĐỘNG KÍCH HOẠT quy trình Pháp y 4 Tầng: (1) Nguồn tín hiệu M1/15M -> (2) Phán đoán của LLM/AI -> (3) Bộ lọc Aggregator -> (4) Quá trình siết SL/thoát lệnh.

   - BẮT BUỘC rà soát toàn diện code, chạy mô phỏng chuẩn quỹ đối chứng trước khi đưa ra bất kỳ kết luận hay can thiệp nào.



---



## 🔬 0.3. TIÊU CHUẨN MÔ PHỎNG CHUẨN QUỸ ĐỊNH LƯỢNG (INSTITUTIONAL REPLAY & PRE-PROPOSAL REGRESSION STANDARD)

1. **BẮT BUỘC MÔ PHỎNG TOÀN BỘ LỊCH SỬ TRƯỚC MỌI ĐỀ XUẤT (Pre-Proposal Full Regression Simulation):**
   - TUYỆT ĐỐI CẤM tự ý đề xuất hoặc áp dụng bất kỳ thay đổi nào vào bộ quy tắc/tín hiệu khi **CHƯA CHẠY MÔ PHỎNG HỒI QUY ĐỐI SOÁT TRÊN TOÀN BỘ DỮ LIỆU LỊCH SỬ** (`trade_bot.db` và log PC2) qua `tools/true_signal_simulator.py` hoặc `tools/full_spectrum_impact_simulator.py`.
   - BẮT BUỘC phải đo lường chính xác **Hiệu ứng Lan tỏa (Side-effect / Ripple Effect)** lên các vị thế lịch sử cũ:
     - Thay đổi này sẽ làm LỜI THÊM bao nhiêu $ trên các vị thế tương tự?
     - Có làm mất (hoặc đảo chiều sai) các lệnh vốn dĩ đang THẮNG trong lịch sử không?
     - Tác động chéo giữa 3 lớp tài sản (Major Crypto, TradFi Cổ phiếu Mỹ, Altcoins) ra sao?
   - Chỉ được phép đề xuất thay đổi khi kết quả mô phỏng định lượng chứng minh: **Tổng Net PnL tăng lên VÀ không làm suy giảm tỷ lệ thắng (Win Rate) của các cụm chiến lược dương khác!**

2. **Cỗ máy Event-Driven Replay chuẩn quỹ BẮT BUỘC phải bao gồm:**
   - Dữ liệu nến M1/Tick, đo lường chính xác đường cong MFE/MAE thực tế.
   - Bóc tách nhân tố dẫn dắt vĩ mô: BTC Dominance, ATR BTC và hệ số Beta đối với Altcoin; QQQ/SPY, VIX và Giờ mở phiên Mỹ đối với Cổ phiếu TradFi.
   - Tái lập đầy đủ chi phí: Phí Maker/Taker, trượt giá (slippage), nấc cắt giảm tải 50% và Cushion SL.

---

## 💡 0.4. QUY TRÌNH PHÁP Y PHÂN LOẠI 6 NHÓM TÍN HIỆU THUA & MA TRẬN QUYẾT ĐỊNH (6-TIER LOSS FORENSICS & SMART DECISION MATRIX)

Khi người dùng yêu cầu phân tích một lệnh lỗ, AI BẮT BUỘC phải điều tra sâu 4 tầng và phân loại lệnh đó vào chính xác 1 trong 6 nhóm định lượng để đưa ra hành động chuẩn xác:

1. **🔄 Nhóm 1: Có thể Lật Ngược (Smart Inversion Candidates):**
   - *Đặc điểm:* Lệnh vào sai hướng khi cá mập đang bơm/xả thác đổ một chiều rõ ràng (ví dụ: Ép Short cản tàu khi JEV 4H đang BUY mạnh >= 70% và ADX >= 30).
   - *Hành động:* Lập phương án LẬT NGƯỢC (Invert) đi thuận theo cá mập (chuyển Short cản tàu thành Whale Momentum Ride BUY). Báo cáo rõ ràng cả 2 kịch bản: PnL khi Veto (0$) vs PnL khi Lật Ngược (+).

2. **📈 Nhóm 2: Vi phạm Xu Hướng Vĩ Mô (MTF Trend Violation):**
   - *Đặc điểm:* Lệnh vào ngược xu hướng khung lớn 4H/1H khi cấu trúc chưa hề có dấu hiệu đảo chiều hay kiệt sức.
   - *Hành động:* Khôi phục và siết chặt rào chắn `JEV MTF TREND SHIELD`, cấm bypass override khi thiếu râu xả đỉnh vật lý >= 35%.

3. **⏸️ Nhóm 3: Nên Đứng Ngoài (Veto / Stand Aside - Zero Edge):**
   - *Đặc điểm:* Thị trường sideway tích lũy nén biên độ hẹp (Chop/Consolidation), thanh khoản cạn kiệt, bẫy giá giả mạo cả 2 đầu. Lật ngược hay theo xu hướng đều bị quét râu Stop-loss (Edge ~ 0).
   - *Hành động:* ĐỨNG NGOÀI TUYỆT ĐỐI (Veto = 0$). Thà mất cơ hội còn hơn mất vốn.

4. **⚡ Nhóm 4: Phân tích Yếu / Tín hiệu Suy Kiệt Sớm (Weak Signal / Early Exhaustion):**
   - *Đặc điểm:* Tín hiệu ban đầu yếu hoặc dòng tiền đột ngột quay xe ngược lại sau 2 - 8 phút mở lệnh.
   - *Hành động:* Kích hoạt cơ chế Phá khóa Grace Period / Cứu hộ Cá mập (Whale Anchor) thoát hiểm khẩn cấp ở mức lỗ nhỏ (-0.3% -> -0.5%), triệt tiêu nguy cơ dính full SL.

5. **🐛 Nhóm 5: Lỗi Code / Lỗi Logic Ngầm (Semantic & Runtime Bugs):**
   - *Đặc điểm:* Tín hiệu thị trường phân tích đúng (giá chạy lãi MFE dương lớn >= +0.8%) nhưng bị lỗ do lỗi code: biến chưa khai báo (NameError), kẹt luồng, lệch tham số, crash module trailing stop hoặc đứt gãy kết nối đồng bộ SL/TP sàn.
   - *Hành động:* Pháp y vị trí dòng code, sửa dứt điểm lỗi logic ngầm, kiểm thử AST và Hard Constraints Gate 100%. Tuyệt đối KHÔNG đổ lỗi cho tín hiệu thị trường!

6. **🎲 Nhóm 6: Nhiễu Ngẫu Nhiên thuộc Cụm Chiến Thuật Sinh Lời (Statistical Noise of Net-Positive Cluster):**
   - *Đặc điểm:* Lệnh thua là chi phí rủi ro ngẫu nhiên bình thường của một chiến thuật có kỳ vọng toán học dương (Ví dụ: Chiến thuật Fading Short có Win Rate 54.7% và mang lại lợi nhuận ròng +4.7862$ qua 107 lệnh lịch sử; lệnh thua đơn lẻ chỉ là False Breakout ngẫu nhiên).
   - *Hành động:* **TUYỆT ĐỐI KHÔNG TÙY TIỆN XÓA BỎ HOẶC ĐẢO NGƯỢC CHIẾN THUẬT** chỉ vì 1 vài lệnh thua ngẫu nhiên này, tránh phá hủy cụm chiến lược đang đóng góp lợi nhuận ròng dương cho danh mục!


---

## ⚖️ 0.5. QUY CHUẨN TỔNG KẾT, CHẤM ĐIỂM & GIAO THỨC DỌN RÁC (SESSION TRUST AUDIT & WORKSPACE PURGE)

1. **Quy tắc bắt buộc khi Chấm điểm / Tổng kết phiên:** Khi người dùng yêu cầu "chấm điểm", "tổng kết", hoặc kết thúc phiên, AI bắt buộc phải:

   - **Tự tổng kết trung thực:** Bóc tách các lỗi phát sinh/ngầm trong phiên (không che giấu, không báo cáo sớm khi chưa đọc live runtime log).

   - **Chấm điểm khách quan:** Theo Rubric 100 tại `docs/AI_TRUST_SCORECARD.md` và cập nhật tiến trình đến ngưỡng >= 95%.

   - **TỰ ĐỘNG THỰC HIỆN GIAO THỨC DỌN RÁC TRONG NGÀY (`tools/clean_workspace.py`):**
     * Tự động quét và xóa sạch 100% các script kiểm thử tạm thời trong `d:\TRADE\scratch/`, các file nháp, file dump tạm (`.bak`, `.tmp`, dump db/log lẻ tẻ) trên cả PC1 và PC2.
     * Bảo đảm không gian làm việc luôn tinh gọn 100%, CHỈ CÒN LẠI các file mã nguồn và tài liệu SSOT chính thức được liệt kê trong `docs/FEATURE_MAP.md`.
     * Tác dụng tối thượng: Giúp người dùng nhìn vào cây thư mục là phân biệt được ngay code chạy thật, TUYỆT ĐỐI KHÔNG để lẫn lộn giữa script kiểm thử và code vận hành khiến người dùng lo sợ xóa nhầm code bot!

2. **CẢNH BÁO VỀ CHỈ SỐ TIN CẬY (AI TRUST: 45% — VÙNG CẢNH GIÁC, ĐANG TRONG GIAI ĐOẠN THỬ THÁCH VÀ GIÁM SÁT):**
   - AI đã quá nhiều lần tự khẳng định "hết lỗi / 100 điểm" nhưng khi người dùng treo máy trên PC2 thì vẫn phát sinh lỗi nghiêm trọng.
   - **BẮT BUỘC CHO MỌI PHIÊN MỚI:** AI phải xuất phát từ tâm thế mình đang kém hiệu quả, chưa đủ tin tưởng và chưa thể buông tay.
   - **LUÔN PHẢI KIỂM THỬ LẶP ĐI LẶP LẠI (ITERATIVE STRESS TESTING):** Cấm kết luận dựa trên lý thuyết hay script chạy thử 1 lần. Bắt buộc đối soát chéo trên log runtime thực tế, database, và chạy mô phỏng đo lường hiệu ứng lan tỏa (Ripple Effect) trước khi kết luận!



---


---

## 🛑 0.6. BỘ QUY TẮC BẤT BIẾN SÀN BINANCE & BẢNG PHÒNG TRỪ 13 LỖI THỰC CHIẾN (BINANCE INVARIANTS & RUNTIME SAFEGUARDS)

*Tự động nạp vào 100% phiên làm việc mới trên Antigravity IDE để AI không bao giờ được phép quên hoặc sửa code làm tái phát:*

1. **5 Bộ Lọc Sàn Cứng (Binance Order Filters Invariants):**
   - **`LOT_SIZE`**: BTC tối thiểu `0.001 BTC`, ETH `0.01 ETH`, SOL `0.1 SOL`. Mọi khối lượng đặt bắt buộc format qua `amount_to_precision()`. Nếu vốn nhỏ không đủ mở 0.001 BTC (cần ~17$ ký quỹ), bot bắt buộc skip an toàn, cấm ép lệnh gây lỗi `-1013`.
   - **`MIN_NOTIONAL`**: Lệnh mở mới bắt buộc có giá trị danh nghĩa >= 5.00 USDT (`notional = max(6.0, notional)`). Binance miễn trừ bộ lọc này cho lệnh đóng / cắt lỗ (`reduceOnly=True`).
   - **`PRICE_FILTER`**: Mọi mức giá Limit bắt buộc format qua `price_to_precision()`.
   - **`PERCENT_PRICE`**: Giá Limit không được lệch quá 2% so với giá Mark hiện tại.
   - **`MAX_NUM_ALGO_ORDERS`**: Tối đa 10 lệnh điều kiện (SL/TP) đồng thời.

2. **Bảng Pháp Y 13 Mã Lỗi Binance Futures & Biện Pháp Khắc Phục:**
   - **`-1013 Filter failure: LOT_SIZE / MIN_NOTIONAL / PRICE_FILTER`**: Thiếu format precision hoặc notional < 5.0$.
   - **`-2011 Unknown order sent`**: Tra cứu/hủy Algo Order ID `30000...` qua endpoint thường. Bắt buộc dùng `params={'trigger': True}` hoặc tra cứu `/fapi/v1/userTrades`.
   - **`-2019 Margin is insufficient`**: Thiếu ký quỹ. Khống chế trần sử dụng ký quỹ <= 50% NAV.
   - **`-2021 Order would immediately trigger`**: Stop price đặt sai chiều so với giá hiện tại (Long SL phải < giá hiện tại; Short SL phải > giá hiện tại). Nếu giá đã vượt qua, đóng bằng Market thông thường.
   - **`-2022 ReduceOnly Order is rejected`**: Đặt reduceOnly khi không có vị thế mở hoặc sai chiều.
   - **`-4116 ClientOrderId duplicated`**: Sàn đã nhận lệnh thành công từ lần gửi trước. Dùng lại bản ghi gốc, cấm đặt thêm.
   - **`-4181 Invalid start time`**: startTime > endTime hoặc âm khi đồng bộ userTrades.
   - **`-1021 Timestamp outside recvWindow`**: Lệch đồng hồ Windows > 1000ms. Bù trừ `load_time_difference()` và gọi `w32tm /resync`.
   - **`-4411 TradFi-Perps agreement required`**: Ký tự động qua `/fapi/v1/stock/contract`.
   - **`-5022 Post Only order will be rejected`**: Đặt Limit Maker khi giá đã chạy qua. Chuyển sang cơ chế tái rình mồi (Smart Re-stalking) hoặc hủy an toàn, cấm crash.
   - **`-1111 Precision over maximum`**: Format float chuẩn `f"{val:.{prec}f}"`.

3. **Top 3 Lỗi Logic Ngầm Từng Làm Treo Tool PC2 (Cấm Tuyệt Đối):**
   - **Biến chưa khai báo (NameError / UnboundLocalError):** Đã có 3,313 lỗi `is_tradfi_pair`, 914 lỗi `trap_ctx`, 160 lỗi `has_real_bull_trap`. BẮT BUỘC chạy Rào chắn 9 (AST SymTable) kiểm tra 100% trước khi deploy!
   - **Lỗi Unpack dữ liệu nến (get_ohlcv unpack error):** Đã xóa bỏ unpack thừa, trả về DataFrame chuẩn.
   - **AttributeError trên AI / Aggregator:** Cấm truy cập thuộc tính chưa khởi tạo như `aggregator.config`.

---


## 🏛️ 0.7. MA TRẬN 7 PHÂN LỚP MÃ NGÀNH TRADFI, QUY TẮC MÃ MỚI LIST & SMART INVERSION PHIÊN MỸ

*Tự động nạp vào 100% phiên làm việc mới để AI không bao giờ bị lẫn lộn giữa các mã ngành TradFi, cặp đối nghịch hoặc mã mới niêm yết:*

1. **Ma Trận 10 Phân Lớp Toàn Diện 100% Mã TradFi Trên Binance (SSOT Exhaustive 238/238 Mã - Zero Ellipsis & Zero Missing):**
   - **`SEMICONDUCTOR` (Bán dẫn, Chip & Thiết bị quang học - 53 mã 100%):**
     * Benchmark dẫn dắt: `SOXL` (Bull 3x) & `NVDA`.
     * Mã đối nghịch 1-1: `SOXL` <---> `SOXS` (Bear 3x).
     * Mã đòn bẩy đơn: `NVDL` (2x) <---> `NVDA` (1x).
     * ETF Ngành: `SMH`.
     * TOÀN BỘ 50 cổ phiếu thành viên trên Binance: `NVDA`, `NVDL`, `AMD`, `AVGO`, `ASML`, `AMAT`, `MU`, `MUU`, `INTC`, `MRVL`, `MVLL`, `TSM`, `QCOM`, `LRCX`, `ARM`, `SMCI`, `STM`, `TER`, `TXN`, `WDC`, `KLAC`, `ALAB`, `APLD`, `AXTI`, `COHR`, `CRDO`, `GIGADEV`, `MP`, `ONDS`, `SNDK`, `SNPS`, `SNXX`, `SKHYNIX`, `SKHY`, `SKUU`, `SKDD`, `SAMSUNG`, `SAMSUNGEM`, `CSOPSAMSUNG2L`, `CSOPSKHYNIX2L`, `HANMI`, `DRAM`, `CXMT`, `SECZ`, `AAOI`, `ZHONGJI`, `GLW`, `CIEN`, `FLEX`, `AGPU`.
   - **`NASDAQ_TECH` (Công nghệ Phần mềm, Cloud, AI & Mega-Cap Mỹ - 55 mã 100%):**
     * Benchmark dẫn dắt: `QQQ` & `TQQQ` (Bull 3x).
     * Mã đối nghịch 1-1: `TQQQ` <---> `SQQQ` (Bear 3x).
     * TOÀN BỘ 52 cổ phiếu thành viên trên Binance: `AAPL`, `MSFT`, `AMZN`, `GOOGL`, `META`, `NFLX`, `PLTR`, `CRM`, `ORCL`, `ADBE`, `PANW`, `CRWD`, `SNOW`, `DDOG`, `CSCO`, `IBM`, `NOW`, `TEAM`, `PATH`, `MDB`, `NET`, `ZS`, `ZM`, `SHOP`, `UBER`, `RDDT`, `OPENAI`, `ANTHROPIC`, `MINIMAX`, `MOONSHOT`, `ZHIPU`, `ANET`, `AKAM`, `GTLB`, `TTWO`, `CYPH`, `APP`, `MELI`, `EBAY`, `PYPL`, `PAYP`, `TWST`, `CRWV`, `CRML`, `RAM`, `SHAZ`, `ACN`, `INTW`, `TEM`, `IONQ`, `RUM`.
   - **`ASIAN_TECH` (Công nghệ & Thương mại điện tử Châu Á - 13 mã 100%):**
     * TOÀN BỘ cổ phiếu thành viên: `BABA`, `PDD`, `MEITUAN`, `TENCENT`, `KUAISHOU`, `HK0700`, `HK1810`, `HK0992`, `HK0625`, `NAVER`, `LGELECTRONICS`, `SONY`, `KSTR`.
   - **`AI_INFRA_ENERGY` (Hạ tầng AI, Điện toán & Năng lượng Hạt nhân - 8 mã 100%):**
     * TOÀN BỘ cổ phiếu thành viên: `VST`, `CEG`, `OKLO`, `SMR`, `VRT`, `BE`, `FLNC`, `URNM`.
   - **`CRYPTO_PROXY` (Cổ phiếu liên kết Tiền mã hóa & Đào coin - 13 mã 100%):**
     * Benchmark dẫn dắt: `BTC` & `MSTR`.
     * Mã đòn bẩy đơn: `MSTU` / `MSTX` (2x) <---> `MSTR` (1x); `CONL` (2x) <---> `COIN` (1x).
     * TOÀN BỘ cổ phiếu thành viên: `MSTR`, `MSTU`, `COIN`, `CONL`, `BITO`, `MARA`, `IREN`, `HUT`, `BMNR`, `BTCDOM`, `DEFI`, `CBRS`, `CRCL`.
   - **`EV_AEROSPACE` (Xe điện, Tự hành & Hàng không Vũ trụ - 11 mã 100%):**
     * Benchmark dẫn dắt: `TSLA`.
     * Mã đòn bẩy đơn: `TSLL` (2x) <---> `TSLA` (1x).
     * TOÀN BỘ cổ phiếu thành viên: `TSLA`, `TSLL`, `RIVN`, `BYD`, `NIO`, `HYUNDAI`, `UNITREE`, `RKLB`, `ASTS`, `RDW`, `BOT`.
   - **`COMMODITY_METALS` (Kim loại quý & Công nghiệp - Giao dịch 24/5 CME Globex - 8 mã 100%):**
     * TOÀN BỘ mã hàng hóa: `XAU` (Vàng), `XAG` (Bạc), `PAXG`, `PLAT` / `XPT` (Bạch kim), `PALL` / `XPD` (Palladium), `COPPER` (Đồng), `GDX` (Thợ mỏ vàng). *(Miễn trừ session filter phiên Mỹ)*.
   - **`COMMODITY_ENERGY` (Năng lượng Hóa thạch, Dầu khí & Khí đốt - Giao dịch 24/5 CME Globex - 7 mã 100%):**
     * TOÀN BỘ mã năng lượng: `CL` (Dầu WTI), `BZ` (Dầu Brent), `NATGAS` (Khí tự nhiên), `XOM`, `OXY`, `XLE`, `EQT`. *(Cặp tương quan cùng gốc CL <---> BZ)*.
   - **`BROAD_INDEX` (Chỉ số Thị trường S&P 500, Russell 2000, VIX & Vĩ mô - 21 mã 100%):**
     * Mã đối nghịch 1-1: `UPRO` (Bull 3x) <---> `SPXU` / `SPCX` (Bear 3x); `IWM` (Bull Smallcap) <---> `TZA` (Bear 3x); `UVXY` (Biến động VIX).
     * Chỉ số & Vĩ mô: `SPY`, `TBT`, `TMF`, `USDEX`, `USDBRL`, `ALL`, `EWJ`, `EWT`, `EWY`, `EWZ`, `EWZS`, `EIDO`, `KORU`, `KODEX200`, `STXX`, `PREDICT`.
   - **`TRADITIONAL_VALUE` (Tài chính, Y tế & Tiêu dùng Truyền thống - 49 mã 100%):**
     * Y tế / Dược phẩm: `LLY`, `NVO`, `PFE`, `ABBV`, `AMGN`, `MRNA`, `VKTX`, `HIMS`, `MDT`, `XBI`, `UNH`, `MRK`.
     * Tài chính / Ngân hàng: `JPM`, `GS`, `BAC`, `V`, `HOOD`, `IBKR`, `BX`, `BRKB`, `SOFI`, `CAT`, `GEV`, `DELL`, `HPE`.
     * Bán lẻ, Tiêu dùng & Khác: `WMT`, `COST`, `KO`, `MCD`, `DIS`, `NKE`, `LITE`, `POPMART`, `DJT`, `AMC`, `GME`, `WEN`, `HD`, `CVNA`, `DKNG`, `GPRO`, `NOK`, `BBX`, `BNC`, `BSP`, `BWET`, `FWDI`, `LYTE`, `NBIS`, `OURA`, `PENG`, `QNTX`, `STRC`, `USAR`, `ZCSH`.

2. **Bốn Rào Chắn Tương Hỗ Bất Biến (Mutual Exclusion Invariants):**
   - **Rào chắn 1 (Khóa Đối Nghịch Tuyệt Đối):** Đang giữ LONG `SOXL`, CẤM TUYỆT ĐỐI mở LONG `SOXS` (hoặc SHORT `SOXL`). Tương tự với `TQQQ`/`SQQQ` và `UPRO`/`SPXU`.
   - **Rào chắn 2 (Khóa Cổ Phiếu Cùng Gốc):** CẤM mở đồng thời cổ phiếu cơ sở và ETF đòn bẩy đơn của chính công ty đó (`NVDA` + `NVDL`, `TSLA` + `TSLL`, `MSTR` + `MSTU`).
   - **Rào chắn 3 (Chặn Bắt Đáy Bear ETF):** Khi benchmark ngành đang Uptrend (EMA20 > EMA50, ADX >= 25), CẤM MUA BẮT ĐÁY `SOXS`, `SQQQ`, `SPXU`, `TZA` chỉ vì nến rút râu oversold.
   - **Rào chắn 4 (Khống Chế Đơn Ngành):** Tối đa 1 vị thế rủi ro cho mỗi nhóm ngành (Sector). Nếu đã giữ 1 mã Bán dẫn (`SOXL`, `NVDA`), lệnh TradFi tiếp theo bắt buộc phải thuộc nhóm khác (`XAU`, `CL`, `TSLA`).

3. **Mở Khóa Smart Inversion Giờ Mở Phiên Mỹ (Wall Street Opening Bell 21:30 - 22:30 VN):**
   - Thừa kế trọn vẹn cỗ máy Smart Inversion I1: Trong 60m đầu phiên Mỹ, nếu có sóng đẩy volume bão ($RVol \ge 1.8x$) và nến xanh đặc râu xả đỉnh $< 30\%$, **LẬT NGƯỢC TOÀN BỘ TÍN HIỆU SHORT CẢN TÀU THÀNH MOMENTUM RIDE BUY** đi thuận cùng cá mập Wall Street!

4. **Giao Thức Sandbox Cho Mã Mới Niêm Yết Chưa Rõ Tương Quan (New Listing Sandbox Protocol):**
   - Khi Binance Futures niêm yết một mã mới (< 72 giờ) chưa rõ tương quan giá chạy theo con nào:
     * **Truy vấn Metadata:** Lấy `underlyingType` và `underlyingSubType` từ sàn để phân loại sơ bộ (Equity vs Commodity vs Coin).
     * **Chế độ Sandbox Bảo vệ Vốn (< 72h):** Khống chế đòn bẩy tối đa 3x (TradFi 2x), trần ký quỹ <= 10% NAV, ép Stop-loss thích ứng ATR (cấm nới rộng SL), TUYỆT ĐỐI KHÔNG dự đoán cặp đối nghịch mò.
     * **Đo Tương Quan Động (Dynamic Pearson Discovery):** Sau 48 nến M15, bot tự động tính hệ số tương quan Pearson $r$ với các Benchmark (`BTC`, `SOXL`, `QQQ`, `SPY`). Nếu $|r| \ge 0.70$, tự động gán mã vào nhóm ngành có tương quan cao nhất.
     * **Cầu Dao Cách Ly Khi Thua Lỗ (Loss Quarantine Gate):** Nếu mã mới niêm yết bị thua >= 2 lệnh liên tiếp, LẬP TỨC kích hoạt Cooldown Cách Ly 24h (`quarantine_cooldown = 86400s`), cấm giao dịch mã này cho đến khi hình thành cấu trúc xu hướng ổn định!

5. **Giao Thức Khóa Lệnh, Báo Động Telegram & Tự Động Đối Soát Kiểm Toán Ngày (Unmapped TradFi Guard & Daily Audit Invariant):**
   - **Khóa Tuyệt Đối (Zero Blind Entry):** Khi bot chạy 24/7 trên PC2 phát hiện bất kỳ mã cổ phiếu/ETF Mỹ nào có tín hiệu nhưng **CHƯA ĐƯỢC XÁC NHẬN TRONG MA TRẬN NGÀNH**:
     * **CẤM TUYỆT ĐỐI MỞ LỆNH TỰ ĐỘNG (AUTO-ENTRY VETO)** dù tín hiệu có điểm cao đến đâu!
     * **Bắn Cảnh Báo Telegram Ngay Lập Tức:** `"🔔 [PHÁT HIỆN MÃ CHỨNG KHOÁN MỚI] Mã {symbol} có tín hiệu nhưng CHƯA NẰM TRONG MA TRẬN NGÀNH! Bot TẠM DỪNG VÀO LỆNH để bảo vệ vốn. Hãy kiểm tra tương quan!"`
   - **Tự Động Báo Cáo Trong Phiên Mới (`daily_auditor.py` Invariant):**
     * Kể cả người dùng không xem Telegram: Khi mở phiên chat mới và chạy kiểm toán ngày PC2 (`python tools/daily_auditor.py`), cỗ máy kiểm toán **BẮT BUỘC TỰ ĐỘNG QUÉT VÀ BÁO CÁO NGAY TRÊN MÀN HÌNH**:
       `"🔔 [PHÁT HIỆN MÃ CHỨNG KHOÁN MỚI TRÊN PC2 HÔM NAY]: Mã {symbol} xuất hiện nhưng chưa được phân loại! Đã tạm khóa mở lệnh. Cần đo tương quan Pearson r để cập nhật code!"`
     * AI phiên mới bắt buộc đọc báo cáo này, đo tương quan Pearson $r$ với các Benchmark (`BTC`, `SOXL`, `QQQ`, `SPY`), xác định rõ mã này chạy cùng giá hay đối nghịch với con nào, cập nhật code và kiểm thử 100% rồi mới cho bot giao dịch!

---

## 🏛️ 1. KIẾN TRÚC 2 MÁY TÍNH & MA TRẬN 3 LỚP TÀI SẢN

- **💻 PC1 (Máy Phát Triển - Dev Machine):** `d:\TRADE` (Python 3.14.7 64-bit venv, Antigravity IDE).

- **🖥️ PC2 (Máy Thử Nghiệm 24/7 - Live Daemon):** `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` (Binance Futures Live, Equity ~103.68 USDT, Ollama `qwen2.5:7b`).

- **Ma trận 3 Lớp Tài Sản (Three-Tier Asset Matrix):**

  1. **Major Crypto (`BTC`, `ETH`, `SOL`):** Thanh khoản dày, ATR 0.4% - 0.9%, không bị chặn bởi Weekend Shield.

  2. **TradFi Cổ Phiếu Mỹ (`NVDA`, `TSLA`, `MRVL`, `TQQQ`):** Đòn bẩy $\le 4x$, trần ký quỹ 20% NAV, đóng trước thứ 7 qua Weekend Shield, SL ngắn bám sát, cấm nới rộng.

  3. **Crypto Altcoins (`MOVR`, `WAL`, `PEPE`, `SKYAI`):** ATR biến động lớn (1.5% - 4.5%), cần vùng đệm Stop-Loss thích ứng theo ATR, cooldown 180m khi đóng lỗ.

  *⚠️ NGUYÊN TẮC BẮT BUỘC: Tuyệt đối không lấy kết quả của 1 coin Altcoin đơn lẻ để tự ý sửa đổi SL/TP toàn sàn khi chưa chạy mô phỏng đối chứng trên cả 3 lớp tài sản!*



---



## 🧭 2. QUY CHUẨN 3 PHIÊN CHAT MỚI TRÊN ANTIGRAVITY

*Khi người dùng mở một phiên chat mới, chỉ cần gõ tiền tố tương ứng:*



### 🟢 1. PHIÊN `[OPS]` — GIÁM SÁT THỰC CHIẾN HẰNG NGÀY

- **Nhiệm vụ:** Điểm danh sáng, check số dư, PnL ngày, đối soát vị thế mở, kiểm tra lệnh SL/TP sàn.

- **Lệnh mở màn:** `"Chạy kiểm toán ngày PC2"` (hoặc `"audit"`, hoặc chạy `CHECK_HE_THONG.bat`).

- **Hành động của AI:** Tự động chạy `python tools/daily_auditor.py`, đọc database PC2 qua LAN, chấm điểm Rubric 100. Tuyệt đối không chỉnh sửa code trong phiên này.



### 🔬 2. PHIÊN `[QUANT]` — PHÒNG THÍ NGHIỆM & MÔ PHỎNG TÍN HIỆU

- **Nhiệm vụ:** Phân tích pháp y các lệnh vừa đóng, giải phẫu nguyên nhân nến quét SL, chạy mô phỏng tái lập.

- **Lệnh mở màn:** `"Pháp y lệnh [Tên coin] và chạy true_signal_simulator đối soát."`

- **Hành động của AI:** Chạy `python tools/true_signal_simulator.py` trên các cụm tín hiệu log PC2, phân tích trên 3 lớp tài sản trước khi đưa ra bất kỳ kiến nghị thay đổi nào.



### 🛠️ 3. PHIÊN `[DEV]` — XƯỞNG SỬA CODE & NÂNG CẤP WEB

- **Nhiệm vụ:** Sửa lỗi logic ngầm, tối ưu hóa giao diện Web Dashboard, nâng cấp cơ chế chốt lời/cắt lỗ.

- **Lệnh mở màn:** `"Nâng cấp [Tính năng X]. Kiểm tra Hard Gate rồi deploy sang PC2."`

- **Hành động của AI:** Tham chiếu `docs/FEATURE_MAP.md`, sửa code, chạy `python tools/hard_constraints_gate.py` (vượt qua 100%), chạy `python deploy_web_client.py` (đồng bộ LAN PC2 và đẩy Git Cloudflare).



---



## 🛡️ 3. RÀO CHẮN CỨNG BẰNG CODE (HARD CONSTRAINTS GATE)

*Được thực thi tự động qua `tools/hard_constraints_gate.py` trước mỗi lần deploy:*

1. **Rào chắn 1:** Cấm bật lại `time_based_exits` trong `config/settings.yaml`.

2. **Rào chắn 2:** Cấm `pop('jev_agent')` thiếu khiên `JEV MTF TREND SHIELD` trong `ai/signal_aggregator.py`.

3. **Rào chắn 3:** Bảo đảm Stop-Loss luôn nằm trong khung an toàn định lượng `[1.0%, 3.5%]`.

4. **Rào chắn 4:** Endpoint `/api/stop` và `/api/pause` luôn trả về HTTP 200 idempotent, cấm báo lỗi `Bot chưa chạy`.

5. **Rào chắn 5:** `cloud_sync.py` bắt buộc có bộ đệm cache bản quyền 60s và gửi ACK tức thì cho Web.

6. **Rào chắn 6:** Cấm bypass MTF Trend Veto khi không có Whale Waterfall Breakdown trong `ai/signal_aggregator.py`.

7. **Rào chắn 7:** Altcoin biến động cao phải có biên độ Stop-Loss thích ứng ATR lên đến 3.5% trong `core/bot.py`.

8. **Rào chắn 8:** Cushion SL phải được bảo vệ bởi bộ lọc thời gian held_minutes >= 3.0 trong `core/bot.py`.

9. **Rào chắn 9:** Quét cú pháp AST chống biến chưa định nghĩa (NameError runtime) trong `tools/hard_constraints_gate.py`.

10. **Rào chắn 10:** Ma trận KB5 đồng bộ SSOT xuyên suốt giữa `core/bot.py` và `ai/signal_aggregator.py`.

11. **Rào chắn 11:** Kiểm toán bộ lọc sàn Binance Futures (-2011, -2021, -4181, -1021, -4411, -4116, Min Notional).



---



## 📚 4. BẢN ĐỒ TÀI LIỆU HỆ THỐNG

- **Bản đồ tính năng & 100 tệp code:** [`docs/FEATURE_MAP.md`](file:///d:/TRADE/docs/FEATURE_MAP.md)

- **Cẩm nang tác chiến hằng ngày:** [`docs/DAILY_PLAYBOOK.md`](file:///d:/TRADE/docs/DAILY_PLAYBOOK.md)

- **Kho lưu trữ 108 bài học lịch sử đầy đủ:** [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md)

