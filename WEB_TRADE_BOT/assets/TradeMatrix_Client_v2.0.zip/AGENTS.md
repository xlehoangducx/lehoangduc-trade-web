# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & GROUND TRUTH
> **Single Source of Truth (SSOT) cho Mọi Phiên Chat Mới Trong Project `TRADE`**  
> *Antigravity sẽ tự động nạp tệp này vào bộ nhớ ngữ cảnh của AI mỗi khi mở phiên hội thoại mới.*

---

## 1. BỐI CẢNH VẬN HÀNH 2 MÁY TÍNH (DUAL-PC ARCHITECTURE)
Hệ thống vận hành theo mô hình phân tán 2 máy tính qua mạng LAN:
* **💻 PC1 (Máy Phát Triển - Dev Machine):**
  * Thư mục code: `D:\TRADE` (và `D:\WEB_TRADE_BOT`).
  * Môi trường: Google Antigravity IDE, Python 3.14.7 64-bit Virtual Environment.
  * Nhiệm vụ: Lập trình, phân tích nến, kiểm toán code, đóng gói `TradeMatrix_Client_v2.0_clean.zip`, đồng bộ mã sạch sang PC2 qua mạng LAN và đẩy Git lên Cloudflare Pages.
* **🖥️ PC2 (Máy Thử Nghiệm Chạy Treo 24/24 - Live Daemon):**
  * Thư mục nhận mã qua LAN: `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0`.
  * Trạng thái: Treo thực chiến 24/7 trên Binance Futures với tiền thật (Equity ~50.43 USDT).
  * Trí tuệ nhân tạo: Ollama local chạy card GTX 1060 với model duy nhất `qwen2.5:7b`.
  * Điều khiển: Khởi chạy bằng `START.bat`, khởi động lại bằng `RESTART.bat`.

---

## 2. LỊCH SỬ THIẾT KẾ & 8 CĂN NGUYÊN GỐC RỄ (BẮT BUỘC NẮM RÕ)
Mọi quyết định chỉnh sửa code đều xuất phát từ các bài học thực chiến xương máu:
1. **Lệch giờ API Binance (-1021):** Đồng hồ Windows lệch vài giây làm lệnh bị từ chối `Timestamp outside recvWindow` -> Có [`Fix_Time.bat`](file:///d:/TRADE/Fix_Time.bat) ép đồng bộ w32tm và tự động resync khi chạy [`START.bat`](file:///d:/TRADE/START.bat).
2. **Căn bệnh "Ăn hạt cát, thua cả tảng đá" (Payoff 0.44):** Trailing stop siết non `+0.16%` (+0.02$), nhưng SL thả trôi `-5%` đến `-10%` -> Chuẩn hóa Fixed Fractional Risk 0.6% NAV, SL tối đa 1.5 ATR.
3. **Thảm họa TradFi `BOT/USDT` (-1.24 USDT):** Mã cổ phiếu Mỹ phái sinh trên Binance bị nhận diện nhầm là Altcoin nên cấp vốn 55% NAV -> Nhận diện động CCXT metadata, giới hạn Notional TradFi tối đa 20% NAV và đòn bẩy $\le 4x$.
4. **Bẫy nến chưa đóng (Unfinished Candle):** Quét nến `iloc[-1]` thấy xanh nhảy vào, vài phút sau nến đóng rút râu đỏ -> Pre-Trade Safety Gate neo vào nến đã đóng hoàn toàn `iloc[-2]`.
5. **Rào cản sàn Binance MIN_NOTIONAL 5.00 USDT:** Vốn nhỏ (~50 USDT), vị thế ~10 USDT không thể chia thành 3-5 nấc chốt lời vì mỗi nấc sẽ dưới 5 USDT -> Phát minh Dynamic Adaptive K-Stages tự động chia 1 đến 5 nấc tùy Notional.
6. **Đọng vốn SOL/USDT gồng 200m:** Gồng lãi `+0.43%` rồi dính SL ngược -> Thoát vốn đọng sau 120 phút (8 nến 15m), nâng buffer hòa vốn từ `0.03%` lên `0.12%` để luôn vượt phí Taker sàn 2 đầu `0.10%`.
7. **Bẫy xả ZEREBRO (-0.218 USDT) do kẹt Grace Period:** TrapDetector thấy râu xả nhưng bị Grace Period khóa tay -> Phá khóa Grace Period khẩn cấp khi Trap ngược chiều $\ge 65\%$.
8. **M1 Sniper Retest Stalking (Lệnh Rình Ảo Trong RAM):** Bot rình nến 1m thoái lui để khớp lệnh Maker 0.02% (tiết kiệm 60% phí); nếu nến 1m gãy cấu trúc xả mạnh thì tự hủy trong RAM để né sập sâu. (Lưu ý: Khi đang rình, bot CHƯA gửi lệnh lên Binance để tránh khóa ký quỹ).

---

## 3. BẢN ĐỒ 44 FILE LÀM VIỆC CỐT LÕI
* **Lõi (Core):** `core/bot.py` (bộ não chính), `core/scanner.py` (quét đa luồng 50 coin), `core/exchange.py` (CCXT pool 100), `core/order_manager.py`, `core/data_collector.py` (tải nến MTF song song), `core/telegram_notifier.py` (Queue async, ép IPv4), `core/firebase_telemetry.py`, `core/gate_telemetry.py`, `core/optimizer.py`.
* **Chiến thuật (Strategies):** `strategies/trend_following.py`, `trap_detector.py`, `momentum_breakout.py`, `mean_reversion.py`, `hft_scalping.py`, `smart_dca.py`, `base_strategy.py`.
* **Trí tuệ nhân tạo (AI):** `ai/signal_aggregator.py` (Consensus Veto & Chop Shield), `ai/jev_agent.py` (Ollama qwen2.5:7b), `ai/ml_model.py` (XGBoost 91 features), `ai/feature_engine.py`, `ai/quantum_path_simulator.py`, `ai/market_regime.py`, `ai/news_sentiment.py`, `ai/ollama_agent.py`.
* **Rủi ro & DB (Risk/DB):** `risk/risk_manager.py`, `risk/position_sizer.py`, `database/db_manager.py`.
* **Giao diện & Web:** `dashboard/app.py`, `dashboard/templates/index.html` (Flank Radar Cyberpunk, link chart Binance, copy coin), `loading.html`.
* **Đồng bộ & Triển khai:** `cloud_sync.py`, `sync_telemetry_loop.py`, `deploy_web_client.py` (script deploy tự động 1 chạm), `run_web.py`.
* **Cấu hình & Batch:** `config/settings.yaml`, `config/strategies.yaml`, `config/pairs.yaml`, `.env`, `START.bat`, `RESTART.bat`, `Fix_Time.bat`, `install.bat`, `requirements.txt`.
* **Tài liệu SSOT:** `HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md` (toàn văn thuật toán & kiểm chứng 105 lệnh).

---

## 4. QUY TRÌNH BẮT BUỘC KHI PHÁT TRIỂN & CHỈNH SỬA CODE
Khi nhận bất kỳ yêu cầu sửa đổi nào từ người dùng, AI phải tuân thủ nghiêm ngặt:
1. **Kiểm tra cú pháp:** Biên dịch `py_compile` tất cả file sửa đổi, bảo đảm 0 syntax errors.
2. **Kiểm tra xung đột:** Chạy `pip check` bảo đảm không lỗi phụ thuộc.
3. **Đồng bộ tự động sang PC2 & Web:** Chạy lệnh `python deploy_web_client.py` để:
   * Copy toàn bộ mã sạch sang `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` qua LAN.
   * Tạo gói zip sạch `TradeMatrix_Client_v2.0_clean.zip`.
   * Commit và Push lên GitHub để Cloudflare Pages tự build web mới.
   * Xác nhận tỷ lệ trùng khớp Hash SHA-256 đạt 100%.
