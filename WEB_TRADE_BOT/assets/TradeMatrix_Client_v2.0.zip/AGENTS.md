# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & LEAN CONSTITUTION
> **Single Source of Truth (SSOT) Tinh Gọn — Nạp Tự Động 100% Không Bị Cắt Cụt (Zero Truncation Guarantee < 21 KB)**
> *Dành riêng cho mọi phiên làm việc mới trên Antigravity IDE. Tự động liên kết thư viện chuyên biệt trong `docs/`.*

---

## ⚡ 0.0. GIAO THỨC KHỞI ĐỘNG BẮT BUỘC (MANDATORY BOOTSTRAP DIRECTIVE)
> [!IMPORTANT]
> **MỌI PHIÊN AI MỚI KHI KHỞI TẠO BẮT BUỘC THỰC THI NGAY:**
> Trước khi đưa ra bất kỳ kết luận hay sửa code, AI BẮT BUỘC dùng `read_file` nạp 3 file SSOT cốt lõi:
> 1. [`docs/LESSONS_LEARNED_SESSION_11_AND_V53.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_11_AND_V53.md): Giải phẫu lệnh thua mới nhất, bài học SOXL 3x, ChoCH V3.6.
> 2. [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md): Bảng điểm tin cậy thực tế (Hiện tại: **42% — Vùng cảnh báo đỏ**).
> 3. [`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md): SSOT Quản lý vốn, MFE Ratchet & Tam Tầng SL V4.1.

---

## 👑 0. TÔN CHỈ TỐI THƯỢNG (SUPREME QUANT DOCTRINE)
### **"THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN (SMART INVERSION & WHALE FLOW ALIGNMENT)"**
1. **Mục tiêu cốt lõi:** Kiếm lợi nhuận bền vững bằng cách đi cùng phe Số Đông Chiến Lược và Dòng Tiền Cá Mập (Smart Money / Whale Flow). TUYỆT ĐỐI KHÔNG phòng thủ thụ động (`return None` / Veto = 0$).
2. **Phân tích Ngược lại (Inversion Analysis):**
   - **Cá mập xả thác đổ / Số đông báo SELL:** Xác nhận SHORT (`🌊 SMART WATERFALL BREAKDOWN SHORT`).
   - **Cá mập bơm bão Volume (nến xanh đặc râu < 30%, RVol >= 1.8x):** Cấm Short cản tàu, kích hoạt `🚀 SMART MOMENTUM RIDE BUY` (Pha 1).
   - **Sóng bơm kiệt sức xuất hiện râu xả đỉnh >= 35%:** Ưu tiên Pha 2 (`⚡ EXHAUSTION FADING SHORT`) bắt đỉnh ăn trọn nhịp sập.
   - **Bảo vệ JEV Đa Khung Thời Gian (`JEV MTF TREND SHIELD`):** Cấm xóa phiếu JEV Agent hoặc ép Short ngược trend khi JEV 4H đang BUY $\ge 70\%$.

---

## 🛑 0.1. DANH MỤC 8 CƠ CHẾ ĐÃ BỊ ĐÀO THẢI VĨNH VIỄN (PURGED ANTI-PATTERNS)
*CẤM BẬT LẠI HOẶC TÁI ĐỀ XUẤT 8 CƠ CHẾ ĐÃ CHỨNG MINH GÂY THIỆT HẠI NẶNG NÀY:*
1. **CẮT THEO THỜI GIAN MÙ QUÁNG (`doa_15m, 25m, 35m`, `idle_120m`):** Xóa sổ vĩnh viễn. Thay bằng Mode 7 Telemetry Gate (xả khi volume dump $\ge 1.6x$).
2. **KHÓA HÒA VỐN NON TRƯỚC TP1 (dưới +0.65% MFE hoặc dưới 4.5 phút đầu):** Thay bằng Tam Tầng SL V4.1 (Chi tiết: [`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md)):
   - *Dưới +0.85%:* ChoCH Early Profit Lock (+0.12% -> +0.80% khi M1 ChoCH đối kháng RVol $\ge 1.5x$); Cushion SL (-0.25% tại MFE +0.80% hoặc +0.55% râu $\ge 35\%$); Cầu dao liên tài sản khẩn cấp.
   - *Từ +0.85% trở lên:* Flash Hard BE (+0.22% Net BE khi MFE $\ge +1.15\%$ hoặc $\max(0.85\%, 0.85 \times \text{ATR})$ cho TradFi & Low-ATR). CẤM TỰ Ý XÓA BỎ MỐC +0.85%.
3. **DE-RISKING SỚM KHÔNG LỌC THỜI GIAN (0.40 ATR):** Thay bằng 0.65 ATR + ép giữ $\ge 1.0$ phút.
4. **CHOP SHIELD VÔ HẠN (ATR BTC $\ge 1.2\%$ trên 15M):** Thay bằng ADX/ATR kèm giãn cách 120s.
5. **ĐẨY `Signal.HOLD` VÀO `by_strategy`:** Kéo tụt 31% điểm raw_score. HOLD chỉ làm Veto độc lập.
6. **BỎ RƠI SIÊU SÓNG BẰNG FAST-SKIP PRE-LLM:** Whale Pump Storm được miễn trừ Fast-Skip để mở Pha 1.
7. **TỰ Ý LẬT CHIỀU LỆNH TẠI EXECUTION (`M1 Inversion` trong `_execute_order`):** Bypass Quantum Gate và Veto 4H. Quyền Invert chỉ thuộc về Aggregator + Quantum Gate.
8. **SHADOW OVERWRITE TRIỆT TIÊU BỘ LỌC VOLUME BẪY ĐÁY:** Cấm ghi đè triệt tiêu $RVol \ge 0.85x$ để mở Short cản tàu ngược 4H Uptrend. Bắt buộc kiểm tra `has_valid_trap_vol_ctx`.

---

## 🛑 0.2. GIAO THỨC BÁO ĐỘNG ĐỎ KHI CHUỖI THUA LIÊN TIẾP (CONSECUTIVE LOSS FORENSIC GATE)
* Ghi nhận $\ge 2$ lệnh thua liên tiếp trên Live: CẤM coi là "nhiễu ngẫu nhiên", BẮT BUỘC kích hoạt Pháp y 4 Tầng: (1) Nguồn tín hiệu M1/15M $\to$ (2) Phán đoán AI/LLM $\to$ (3) Bộ lọc Aggregator $\to$ (4) Quá trình siết SL/thoát lệnh. Rà soát toàn diện code, chạy mô phỏng chuẩn quỹ đối chứng trước khi can thiệp.

---

## 🔬 0.3. TIÊU CHUẨN MÔ PHỎNG CHUẨN QUỸ ĐỊNH LƯỢNG (INSTITUTIONAL REPLAY STANDARD)
* BẮT BUỘC chạy mô phỏng hồi quy đối soát trên toàn bộ lịch sử (`trade_bot.db`) qua `tools/true_signal_simulator.py` hoặc `tools/full_historical_signal_and_position_simulator.py` trước mọi đề xuất sửa code.
* Đo lường chính xác Hiệu ứng Lan tỏa (Ripple Effect): **False Exits (lệnh thắng bị mất) BẮT BUỘC = 0!**
* Tái lập đầy đủ: Nến M1/Tick, MFE/MAE thực tế, Phí Maker 0.02%, Taker 0.05%, Slippage 0.02%, 50% TP1 và Cushion SL.

---

## 💡 0.4. QUY TRÌNH PHÁP Y PHÂN LOẠI 6 NHÓM TÍN HIỆU THUA
1. **🔄 Nhóm 1: Có thể Lật Ngược (Smart Inversion):** Vào sai khi cá mập đang bơm/xả thác đổ. Báo cáo 2 kịch bản: PnL Veto (0$) vs PnL Invert (+).
2. **📈 Nhóm 2: Vi phạm Xu Hướng Vĩ Mô (MTF Trend Violation):** Ngược 4H/1H khi cấu trúc chưa đảo chiều. Siết chặt `JEV MTF TREND SHIELD`.
3. **⏸️ Nhóm 3: Nên Đứng Ngoài (Veto / Stand Aside):** Sideway nén biên độ, bẫy 2 đầu, $RVol_{15M} < 0.8x$. Veto đứng ngoài tuyệt đối (0$).
4. **⚡ Nhóm 4: Suy Kiệt Sớm (Early Exhaustion):** Thoát hiểm khẩn cấp ở lỗ nhỏ (-0.15% đến -0.45%) qua Shock Rescue / ChoCH Choke SL.
5. **🐛 Nhóm 5: Lỗi Code / Lỗi Logic Ngầm (Semantic & Runtime Bugs):** Phân tích đúng nhưng lỗ do lỗi code. Sửa dứt điểm, kiểm thử AST 100%.
6. **🎲 Nhóm 6: Nhiễu Ngẫu Nhiên thuộc Cụm Sinh Lời (Statistical Noise):** Chi phí rủi ro ngẫu nhiên bình thường của chiến thuật EV > 0. Cấm xóa bỏ.

---

## ⚖️ 0.5. QUY CHUẨN TỔNG KẾT, CHẤM ĐIỂM & GIAO THỨC DỌN RÁC
1. **Quy tắc chấm điểm (SSOT: [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md)):**
   - **CHỈ SỐ TIN CẬY HIỆN TẠI: 42% (VÙNG CẢNH BÁO ĐỎ / GIÁM SÁT THỬ THÁCH).**
   - **Ảo tưởng Simulator vs Tiền tươi Live:** CẤM tự cộng điểm cho bản nâng cấp chỉ vì Simulator/AST đẹp! Chỉ được cộng điểm khi vị thế Live mở mới THỰC TẾ CÓ LỢI NHUẬN (Net PnL > 0) và False Exits = 0.
   - **Cơ chế phạt trừ điểm lũy kế:** Tái phạm lỗi Timer cấm, sót code cũ đè code mới, hoặc để lỗi phát sinh từ tín hiệu đầu vào $\implies$ Bị trừ điểm nặng (-5đ đến -15đ/lần).
2. **TỰ ĐỘNG DỌN RÁC CUỐI PHIÊN:** Chạy `python tools/clean_workspace.py` xóa sạch 100% script nháp trong `scratch/`.

---

## 🛑 0.6. BỘ QUY TẮC BẤT BIẾN SÀN BINANCE & BẢNG PHÒNG TRỪ LỖI
1. **5 Bộ Lọc Sàn Cứng:** `LOT_SIZE` (BTC 0.001, ETH 0.01, SOL 0.1, format qua `amount_to_precision`); `MIN_NOTIONAL` $\ge 5.0\text{ USDT}$ (`notional = max(6.0, notional)`); `PRICE_FILTER`; `PERCENT_PRICE` (Limit lệch $\le 2\%$ so với Mark); `MAX_NUM_ALGO_ORDERS` $\le 10$.
2. **Phòng trừ mã lỗi Binance Futures:** `-1013` (Notional/Precision), `-2011` (Hủy Algo sai), `-2019` (Ký quỹ $\le 50\%$ NAV), `-2021` (Stop price sai chiều), `-2022` (ReduceOnly sai), `-4116` (Trùng clientId), `-4181` (startTime > endTime), `-1021` (Clock lệch > 1000ms), `-4411` (Ký TradFi), `-5022` (Post Only trôi).
3. **Top 3 Lỗi Logic Ngầm Cấm Tuyệt Đối:** NameError/UnboundLocalError (quét AST 100%); Unpack thừa dữ liệu nến trong `get_ohlcv`; AttributeError trên AI/Aggregator (`aggregator.config`).

---

## 🏛️ 0.7. MA TRẬN 10 PHÂN LỚP TRADFI & SMART INVERSION PHIÊN MỸ
*Chi tiết 238 mã xem [`docs/QUANT_WORKFLOW_PLAYBOOK.md`](file:///d:/TRADE/docs/QUANT_WORKFLOW_PLAYBOOK.md):*
1. **10 Phân Lớp:** `SEMICONDUCTOR` (SOXL 3x vs SOXS 3x), `NASDAQ_TECH` (TQQQ 3x vs SQQQ 3x), `ASIAN_TECH`, `AI_INFRA_ENERGY`, `CRYPTO_PROXY` (MSTU 2x, CONL 2x), `EV_AEROSPACE` (TSLL 2x), `COMMODITY_METALS`, `COMMODITY_ENERGY`, `BROAD_INDEX` (UPRO 3x vs SPXU 3x), `TRADITIONAL_VALUE`.
2. **4 Rào Chắn Tương Hỗ:** (1) Khóa đối nghịch (`SOXL` vs `SOXS`); (2) Khóa cùng gốc (`NVDA` + `NVDL`); (3) Chặn bắt đáy Bear ETF khi Benchmark Uptrend (`EMA20 > EMA50, ADX >= 25`); (4) Tối đa 1 vị thế rủi ro cho mỗi ngành.
3. **Mở Khóa Smart Inversion Giờ Mở Phiên Mỹ (21:30 - 22:30 VN):** Nến 60m đầu có $RVol \ge 1.8x$ và nến xanh đặc râu xả $< 30\%$ $\implies$ Invert Short thành Momentum Ride Buy.
4. **Sandbox Mã Mới (< 72h):** Đòn bẩy $\le 3x$ (TradFi $2x$), ký quỹ $\le 10\%$ NAV. Thua $\ge 2$ lệnh kích hoạt Cooldown 24h.

---

## 🔬 0.8. QUY TRÌNH PHÁT TRIỂN & ĐỐI SOÁT ĐỊNH LƯỢNG CHUẨN QUỸ 7 BƯỚC
1. **Bước 1 (Phân Lập Đơn Lẻ):** Giải quyết từng vấn đề, phân tích nguyên nhân gốc rễ và công thức định lượng trước khi code.
2. **Bước 2 (Mô Phỏng Toàn Phần):** Tái lập $100\%$ cơ chế: Nến M1/M15, Sniper Stalking, Phí Maker/Taker, Slippage, Tam Tầng SL. **Tuyệt đối Zero-Timer**.
3. **Bước 3 (Đối Soát Lịch Sử):** Đo lường Win Rate, Net PnL, PnL Delta và **False Exits BẮT BUỘC = 0**.
4. **Bước 4 (Exhaustive Branch Coverage):** Quét ngang 100% nhánh rẽ, xóa sạch mã chết/mã cũ cướp quyền, đồng bộ rào chắn fallback.
5. **Bước 5 (Dò Tìm Lỗi Logic Ngầm):** Kiểm tra tính nhất quán tuần hoàn Scanner $\to$ Aggregator $\to$ Sniper $\to$ Position Mgr $\to$ DB. Sàn nén 50% ATR 1H.
6. **Bước 6 (Kiểm Tra Toàn Cục):** Chạy `python tools/hard_constraints_gate.py` (11/11 Passed) và AST SymTable 0 lỗi.
7. **Bước 7 (Đồng Bộ LAN PC2 & Đẩy Cloud):** Chạy `python deploy_web_client.py` đồng bộ SMB sang PC2, auto-backup Ổ D PC2, push Git Cloudflare Pages và chạy `python tools/clean_workspace.py`. Kiểm toán RAM vs Disk: Nếu `StartTime < ModifiedTime`, báo chạy `RESTART.bat`.

---

## 🚫 0.9. MA TRẬN 20 BẤT BIẾN THỰC CHIẾN (TWENTY PRODUCTION INVARIANTS)
1. **Bất biến 1 (Zero-Timer Sniper):** Xóa bỏ vĩnh viễn timeout_sec. Hủy lệnh rình khi giá chạy mất ($> 1.5\text{ ATR}$) hoặc nến M1 gãy vỡ ($RVol_{M1} \ge 2.0x$).
2. **Bất biến 2 (Win Rate vs Payoff Ratio):** Chấp nhận Win Rate 37-55% khi Payoff Ratio $\ge 4.0x$ và mức lỗ trung bình giảm $> 70\%$.
3. **Bất biến 3 (Dynamic Peak MFE):** Luôn tính Fresh MFE từ đỉnh nến M1 thời gian thực, cấm đọc giá trị tĩnh trong RAM.
4. **Bất biến 4 (Timestamp Nến M1):** ChoCH Invalidation bắt buộc kiểm tra $ts_{\text{candle}} \ge ts_{\text{entry}} - 10s$.
5. **Bất biến 5 (Mute Telegram Săn Rình):** CẤM bắn Telegram khi đặt Limit Maker rình. Chỉ bắn khi ĐÃ KHỚP vị thế mở.
6. **Bất biến 6 (Dọn Rác Workspace):** Tự động chạy `tools/clean_workspace.py` xóa 100% file scratch cuối phiên.
7. **Bất biến 7 (Khung SL TradFi Leveraged 3x ETF):** `SOXL, TQQQ, UPRO` dùng khung ATR $[1.8\%, 3.5\%]$, cấm ép trần $1.5\%$.
8. **Bất biến 8 (Bức Tường Lửa Tâm Lý):** Cấm FOMO đánh tay 20x. Sự im lặng của bot là vị thế bảo toàn vốn (Veto = 0$).
9. **Bất biến 9 (Auto-Disaster Backup Ổ D PC2):** Tự động sao lưu vào `\\192.168.1.10\trade-web\BACKUP_MASTER_TRADE_AND_WEB`.
10. **Bất biến 10 (4 Anti-Blindspots):** Quét 100% nhánh rẽ; rào chắn fallback; sàn ATR 1H; kiểm toán RAM vs Disk PC2.
11. **Bất biến 11 (Tam Tầng V4.1 Sub-0.85% & Flash BE):** Chi tiết [`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md). Đóng BE tại $+0.85\%$ là thắng bảo toàn vốn.
12. **Bất biến 12 (Zero-Timer Chu Kỳ Nến Đóng):** Cấm timer giây/phút. Thay bằng Completed Auction Cycles (`closed_m1_count >= 2`).
13. **Bất biến 13 (Sàn Nhiễu Sub-0.50% & Entry vs Exit):** Dải $0.0\% \to +0.35\%$ là sàn nhiễu Gaussian $1.5\sigma$. CẤM hạ MFE Ratchet $< +0.40\%$. Lệnh lỗ cắm thẳng SL ($MFE < +0.20\%$) phải chặn từ Entry (Quantum Gate, M1 Flow, JEV 4H).
14. **Bất biến 14 (Mã Lỗi -2021 Immediate Exit):** Nâng SL bị sàn từ chối do -2021 $\implies$ BẮT BUỘC ĐÓNG MARKET NGAY LẬP TỨC (`_close_position_locked`), cấm giữ SL cũ ở xa.
15. **Bất biến 15 (Three-Tier Audit):** Cấp 1 (Lỗi logic thực chiến: sửa ngay); Cấp 2 (Đặt tên biến: cấm đổi ẩu); Cấp 3 (Đánh đổi hiệu năng có chủ đích: giữ cache TTL 30s chống nghẽn I/O).
16. **Bất biến 16 (Breathing Room vs Ratchet):** Khoảng thở săn TP1 Altcoin tối thiểu $\ge 0.50 \times \text{ATR}$. Không ép khóa sát làm mất siêu sóng.
17. **Bất biến 17 (Sàn Sóng Bơm Thích Ứng Kịch Bản 10):** Sàn Buying Climax chuẩn hóa **`0.7%` cho Altcoin** (TradFi **`0.5%`**). Đồng bộ ở cả 3 tầng (Fast-Skip, Trap Detector, Signal Aggregator).
18. **Bất biến 18 (Benchmark Thích Ứng Đòn Bẩy - V5.3):** Ngưỡng Cầu dao liên tài sản: ETF 3x (`SOXL, TQQQ...`) **`>= 2.50%`**; ETF 2x (`MSTU, CONL`) **`>= 1.70%`**; Tài sản 1x (`BTC, QQQ, SPY`) **`0.85%`**. CẤM áp 0.85% lên ETF 3x gây chém non (`NVDA`). Miễn trừ cho `is_fading_short` & `is_oversold_bounce`.
19. **Bất biến 19 (Exhaustive Branch Coverage & Legacy Purge - V5.3):** Nâng cấp MFE $\ge +0.50\%$ bắt buộc xóa sạch tham số cũ ở hàm trên (`_check_microstructure_choch_invalidation:6838`), CẤM để sót `mfe_trigger_th = 0.0035` cướp quyền tầng Trailing Stop (`JCT`).
20. **Bất biến 20 (Zero-Timer Bar-Close Invariant - V5.3):** Thoát hiểm vi cấu trúc bắt buộc dùng `closed_m1_count >= 2`. Khi `closed_m1_count == 0`, dải $|\text{pnl}| \le 0.25\%$ là sàn nhiễu spread được bảo vệ.

---

## 🛑 0.10. TÔN CHỈ TRIỆT TIÊU LỖI ĐẦU-CUỐI (ZERO-BUG CONSTITUTION)
*SSOT chi tiết: [`docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md`](file:///d:/TRADE/docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md):*
1. **3 Nguyên Tắc Thép:** (1) Trace vòng đời 8 trạm kiểm soát; (2) Exhaustive Branch Coverage (sửa LONG đối soát SHORT, sửa Altcoin đối soát Major & TradFi); (3) Live Runtime & RAM Verification (`StartTime >= ModifiedTime`).

---

## 🏛️ 1. HẠ TẦNG 2 MÁY TÍNH & 4 LOẠI PHIÊN LÀM VIỆC
- **PC1 (Dev):** `d:\TRADE` (Antigravity IDE, Python 3.14.7 venv). | **PC2 (Live Daemon 24/7):** `\\192.168.1.10\trade-web` (Binance Futures Live, Equity ~409 USDT).
- **4 Loại Phiên Làm Việc:**
  1. **`[OPS]` Giám Sát Live:** Đọc log PC2, kiểm toán vị thế, lệnh `-2021`, đối soát số dư.
  2. **`[QUANT]` Mô Phỏng:** Chạy `tools/full_historical_signal_and_position_simulator.py`, đối soát 10 kịch bản. False Exits phải = 0.
  3. **`[DEV]` Sửa Code & Web:** Sửa code, chạy `hard_constraints_gate.py` (11/11 Passed), chạy `deploy_web_client.py` đồng bộ PC2 & Cloud.
  4. **`[RESTORE]` Khôi Phục Thảm Họa:** Kéo toàn bộ mã nguồn sạch từ `\\192.168.1.10\trade-web\BACKUP_MASTER_TRADE_AND_WEB` về `D:\TRADE`.

---

## 🛡️ 2. RÀO CHẮN CỨNG BẰNG CODE (HARD CONSTRAINTS GATE 11/11)
*Kiểm toán tự động qua `python tools/hard_constraints_gate.py`:*
1. Cấm bật lại `time_based_exits`. 2. Cấm `pop('jev_agent')` thiếu MTF Shield. 3. SL an toàn `[1.0%, 3.5%]`. 4. Endpoint `/api/stop` idempotent. 5. Cache bản quyền 60s. 6. Cấm bypass MTF Trend Veto thiếu Waterfall. 7. SL Altcoin thích ứng ATR đến 3.5%. 8. Cushion SL held_minutes >= 3.0. 9. AST check 0 NameError. 10. Đồng bộ SSOT KB5. 11. Kiểm toán bộ lọc sàn Binance (-2011, -2021, Min Notional).

---

## 📚 3. BẢN ĐỒ TÀI LIỆU HỆ THỐNG (SSOT POINTERS)
- **Bài học V5.3 mới nhất (NVDA, JCT, ChoCH V3.6, SOXL 3x):** [`docs/LESSONS_LEARNED_SESSION_11_AND_V53.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_11_AND_V53.md)
- **Bảng theo dõi chỉ số tin cậy AI Trust (Hiện tại: 42%):** [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md)
- **Ma trận Tam Tầng Bảo Vệ Vốn V4.1:** [`docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md`](file:///d:/TRADE/docs/TAM_TANG_BAO_VE_VON_VA_CHOT_LAI_V41.md)
- **Quy trình kiểm toán vòng đời tín hiệu đầu-cuối:** [`docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md`](file:///d:/TRADE/docs/KE_HOACH_DUT_DIEM_TRIET_TIEU_LOI.md)
- **Bài học thực chiến V5.0 (Phiên 9):** [`docs/LESSONS_LEARNED_SESSION_9_AND_V50.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_9_AND_V50.md)
- **Bài học V3.7 & 4 Bất Biến Triệt Tiêu Điểm Mù:** [`docs/LESSONS_LEARNED_SESSION_4_AND_V37.md`](file:///d:/TRADE/docs/LESSONS_LEARNED_SESSION_4_AND_V37.md)
- **Ma trận 238 mã TradFi & Playbook chuẩn quỹ:** [`docs/QUANT_WORKFLOW_PLAYBOOK.md`](file:///d:/TRADE/docs/QUANT_WORKFLOW_PLAYBOOK.md)
- **Bản đồ tính năng 100 tệp code:** [`docs/FEATURE_MAP.md`](file:///d:/TRADE/docs/FEATURE_MAP.md)
- **Kho lưu trữ 112 bài học lịch sử:** [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md)
