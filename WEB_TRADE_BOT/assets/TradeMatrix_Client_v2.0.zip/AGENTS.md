# TRADEMATRIX MASTER QUANT ECOSYSTEM - WORKSPACE RULES & LEAN CONSTITUTION
> **Single Source of Truth (SSOT) Tinh Gọn — Nạp Tự Động 100% Không Bị Cắt Cụt (Zero Truncation)**
> *Dành riêng cho mọi phiên làm việc mới trên Antigravity IDE. Người dùng KHÔNG CẦN copy-paste prompt dài.*

---

## 👑 0. TÔN CHỈ TỐI THƯỢNG (SUPREME QUANT DOCTRINE)
### **"THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN (SMART INVERSION & WHALE FLOW ALIGNMENT)"**
1. **Mục tiêu cốt lõi:** Kiếm lợi nhuận bền vững bằng cách đi cùng phe Số Đông Chiến Lược và Dòng Tiền Cá Mập (Smart Money / Whale Flow). TUYỆT ĐỐI KHÔNG rơi vào tư duy phòng thủ thụ động / chỉ né tránh (`return None` / Veto = 0$).
2. **Phân tích Ngược lại (Inversion Analysis):** Trước mọi lệnh thua hoặc xung đột tín hiệu, câu hỏi bắt buộc phải là: *"Làm thế nào để LẬT NGƯỢC (Invert) lệnh thua đó thành LỆNH THẮNG đi thuận dòng tiền cá mập?"*:
   - **Cá mập xả thác đổ / Số đông báo SELL:** Loại bỏ bẫy đáy giả, xác nhận lệnh SHORT (`🌊 SMART WATERFALL BREAKDOWN SHORT`).
   - **Cá mập bơm bão Volume (nến xanh đặc râu < 30%, RVol >= 1.8x):** Cấm Short cản tàu, kích hoạt `🚀 SMART MOMENTUM RIDE BUY` (Pha 1).
   - **Sóng bơm kiệt sức xuất hiện râu xả đỉnh >= 35%:** Ưu tiên Pha 2 (`⚡ EXHAUSTION FADING SHORT`) bắt đỉnh ăn trọn nhịp sập.
   - **Bảo vệ JEV Đa Khung Thời Gian (`JEV MTF TREND SHIELD`):** Tuyệt đối cấm xóa phiếu của JEV Agent (`pop('jev_agent')`) hoặc ép Short ngược trend khi JEV 4H đang báo BUY mạnh $\ge 70\%$.

---

## 🛑 0.1. DANH MỤC 6 CƠ CHẾ ĐÃ BỊ ĐÀO THẢI VĨNH VIỄN (PURGED ANTI-PATTERNS)
*CẤM BẬT LẠI HOẶC TÁI ĐỀ XUẤT 6 CƠ CHẾ ĐÃ CHỨNG MINH GÂY THIỆT HẠI NẶNG NÀY:*
1. **CẮT THEO THỜI GIAN MÙ QUÁNG (`doa_15m`, `doa_25m`, `doa_35m`, `idle_120m`):** Đã xóa sổ vĩnh viễn (gây lỗ -3.63 USDT, cắt đúng đáy 87.5%). Thay bằng Mode 7 Telemetry Gate (xả khi volume dump $\ge 1.6x$).
2. **KHÓA HÒA VỐN NON TRƯỚC TP1 (dưới +0.65% MFE hoặc dưới 4.5 phút đầu):** Làm 82% lệnh bị quét văng siêu sóng. Thay bằng Tam Tầng Bảo Vệ Vốn V3.0 (Cushion SL -0.25% tại MFE +0.80%, Hard BE +0.22% tại MFE +1.15%).
3. **DE-RISKING SỚM KHÔNG LỌC THỜI GIAN (0.40 ATR):** Cắt non ở râu giật 12s đầu. Thay bằng 0.65 ATR + ép giữ $\ge 1.0$ phút.
4. **CHOP SHIELD VÔ HẠN (ATR BTC $\ge 1.2\%$ trên 15M):** Khóa cứng Altcoin suốt 3 tiếng. Thay bằng ADX/ATR kèm giãn cách 120s.
5. **ĐẨY `Signal.HOLD` VÀO `by_strategy`:** Kéo tụt 31% điểm raw_score của phe đa số. HOLD chỉ làm Veto độc lập.
6. **BỎ RƠI SIÊU SÓNG BẰNG FAST-SKIP PRE-LLM:** Bỏ rơi coin tăng dựng đứng. Whale Pump Storm được miễn trừ Fast-Skip để mở Pha 1.

---

## 🛑 0.2. GIAO THỨC BÁO ĐỘNG ĐỎ KHI CHUỖI THUA LIÊN TIẾP (CONSECUTIVE LOSS FORENSIC GATE)
1. **Quy tắc kích hoạt:** Khi hệ thống ghi nhận >= 2 lệnh thua liên tiếp trên Live:
   - NGHIÊM CẤM coi đây là "nhiễu ngẫu nhiên". BẮT BUỘC coi đây là dấu hiệu tiềm ẩn LỖI HỆ THỐNG / LỖI LOGIC NGẦM (Semantic Bug).
   - TỰ ĐỘNG KÍCH HOẠT quy trình Pháp y 4 Tầng: (1) Nguồn tín hiệu M1/15M -> (2) Phán đoán của LLM/AI -> (3) Bộ lọc Aggregator -> (4) Quá trình siết SL/thoát lệnh.
   - BẮT BUỘC rà soát toàn diện code, chạy mô phỏng chuẩn quỹ đối chứng trước khi đưa ra bất kỳ kết luận hay can thiệp nào.

---

## 🔬 0.3. TIÊU CHUẨN MÔ PHỎNG CHUẨN QUỸ ĐỊNH LƯỢNG (INSTITUTIONAL REPLAY STANDARD)
1. **CẤM mô phỏng tĩnh/qua loa:** Mô phỏng không được chỉ dừng lại ở kiểm tra hàm tính điểm (`aggregate`).
2. **Cỗ máy Event-Driven Replay chuẩn quỹ BẮT BUỘC phải bao gồm:**
   - Dữ liệu nến M1/Tick, đo lường chính xác đường cong MFE/MAE thực tế.
   - Bóc tách nhân tố dẫn dắt vĩ mô: BTC Dominance, ATR BTC và hệ số Beta đối với Altcoin; QQQ/SPY, VIX và Giờ mở phiên Mỹ đối với Cổ phiếu TradFi.
   - Tái lập đầy đủ chi phí: Phí Maker/Taker, trượt giá (slippage), nấc cắt giảm tải 50% và Cushion SL.

---

## 💡 0.4. QUY TẮC ĐÁNH GIÁ LẬT NGƯỢC BẮT BUỘC (MANDATORY SMART INVERSION PROTOCOL)
1. Khi phát hiện một tín hiệu vào lệnh sai hoặc đi ngược dòng tiền cá mập:
   - TUYỆT ĐỐI KHÔNG dừng lại ở tư duy phòng thủ thụ động "bỏ lệnh/veto" (PnL = 0$).
   - BẮT BUỘC phải chạy thử nghiệm mô phỏng phương án LẬT NGƯỢC (Invert) đi thuận theo cá mập (ví dụ: chuyển Short cản tàu thành Whale Momentum Ride BUY).
   - Báo cáo rõ ràng cả 2 kịch bản: PnL khi Veto (0$) vs PnL khi Lật Ngược ($+$).

---

## 🏛️ 1. KIẾN TRÚC 2 MÁY TÍNH & MA TRẬN 3 LỚP TÀI SẢN
- **💻 PC1 (Máy Phát Triển - Dev Machine):** `d:\TRADE` (Python 3.14.7 64-bit venv, Antigravity IDE).
- **🖥️ PC2 (Máy Thử Nghiệm 24/7 - Live Daemon):** `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0` (Binance Futures Live, Equity ~95.69 USDT, Ollama `qwen2.5:7b`).
- **Ma trận 3 Lớp Tài Sản (Three-Tier Asset Matrix):**
  1. **Major Crypto (`BTC`, `ETH`, `SOL`):** Thanh khoản dày, ATR 0.4% - 0.9%, không bị chặn bởi Weekend Shield.
  2. **TradFi Cổ Phiếu Mỹ (`NVDA`, `TSLA`, `MRVL`, `TQQQ`):** Đòn bẩy $\le 4x$, trần ký quỹ 20% NAV, đóng trước thứ 7 qua Weekend Shield, SL ngắn bám sát, cấm nới rộng.
  3. **Crypto Altcoins (`MOVR`, `WAL`, `PEPE`, `SKYAI`):** ATR biến động lớn (1.5% - 4.5%), cần vùng đệm Stop-Loss thích ứng theo ATR, cooldown 180m khi đóng lỗ.
  *⚠️ NGUYÊN TẮC BẮT BUỘC: Tuyệt đối không lấy kết quả của 1 coin Altcoin đơn lẻ để tự ý sửa đổi SL/TP toàn sàn khi chưa chạy mô phỏng đối chứng trên cả 3 lớp tài sản!*

---

## 🧭 2. QUY CHUẨN 3 PHIÊN CHAT MỚI TRÊN ANTIGRAVITY
*Khi người dùng mở một phiên chat mới, chỉ cần gõ tiền tố tương ứng:*

### 🟢 1. PHIÊN `[OPS]` — GIÁM SÁT THỰC CHIẾN HẰNG NGÀY
- **Nhiệm vụ:** Điểm danh sáng, check số dư, PnL ngày, đối soát vị thế mở, kiểm tra lệnh SL/TP sàn.
- **Lệnh mở màn:** `"Chạy kiểm toán ngày PC2"` (hoặc `"audit"`, hoặc chạy `CHECK_HE_THONG.bat`).
- **Hành động của AI:** Tự động chạy `python tools/daily_auditor.py`, đọc database PC2 qua LAN, chấm điểm Rubric 100. Tuyệt đối không chỉnh sửa code trong phiên này.

### 🔬 2. PHIÊN `[QUANT]` — PHÒNG THÍ NGHIỆM & MÔ PHỎNG TÍN HIỆU
- **Nhiệm vụ:** Phân tích pháp y các lệnh vừa đóng, giải phẫu nguyên nhân nến quét SL, chạy mô phỏng tái lập.
- **Lệnh mở màn:** `"Pháp y lệnh [Tên coin] và chạy true_signal_simulator đối soát."`
- **Hành động của AI:** Chạy `python tools/true_signal_simulator.py` trên các cụm tín hiệu log PC2, phân tích trên 3 lớp tài sản trước khi đưa ra bất kỳ kiến nghị thay đổi nào.

### 🛠️ 3. PHIÊN `[DEV]` — XƯỞNG SỬA CODE & NÂNG CẤP WEB
- **Nhiệm vụ:** Sửa lỗi logic ngầm, tối ưu hóa giao diện Web Dashboard, nâng cấp cơ chế chốt lời/cắt lỗ.
- **Lệnh mở màn:** `"Nâng cấp [Tính năng X]. Kiểm tra Hard Gate rồi deploy sang PC2."`
- **Hành động của AI:** Tham chiếu `docs/FEATURE_MAP.md`, sửa code, chạy `python tools/hard_constraints_gate.py` (vượt qua 100%), chạy `python deploy_web_client.py` (đồng bộ LAN PC2 và đẩy Git Cloudflare).

---

## 🛡️ 3. RÀO CHẮN CỨNG BẰNG CODE (HARD CONSTRAINTS GATE)
*Được thực thi tự động qua `tools/hard_constraints_gate.py` trước mỗi lần deploy:*
1. **Rào chắn 1:** Cấm bật lại `time_based_exits` trong `config/settings.yaml`.
2. **Rào chắn 2:** Cấm `pop('jev_agent')` thiếu khiên `JEV MTF TREND SHIELD` trong `ai/signal_aggregator.py`.
3. **Rào chắn 3:** Bảo đảm Stop-Loss luôn nằm trong khung an toàn định lượng `[1.0%, 3.5%]`.
4. **Rào chắn 4:** Endpoint `/api/stop` và `/api/pause` luôn trả về HTTP 200 idempotent, cấm báo lỗi `Bot chưa chạy`.
5. **Rào chắn 5:** `cloud_sync.py` bắt buộc có bộ đệm cache bản quyền 60s và gửi ACK tức thì cho Web.

---

## 📚 4. BẢN ĐỒ TÀI LIỆU HỆ THỐNG
- **Bản đồ tính năng & 100 tệp code:** [`docs/FEATURE_MAP.md`](file:///d:/TRADE/docs/FEATURE_MAP.md)
- **Cẩm nang tác chiến hằng ngày:** [`docs/DAILY_PLAYBOOK.md`](file:///d:/TRADE/docs/DAILY_PLAYBOOK.md)
- **Kho lưu trữ 108 bài học lịch sử đầy đủ:** [`HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md`](file:///d:/TRADE/HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md)
