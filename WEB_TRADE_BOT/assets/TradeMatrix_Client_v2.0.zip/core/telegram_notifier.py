import requests
import logging
import time
import queue
import threading
import socket
from typing import Optional
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import urllib3.util.connection as urllib_conn

# Ép buộc dùng IPv4 để tránh hiện tượng IPv6 Blackhole/Treo kết nối (ConnectTimeout) tại các mạng VN (VNPT, Viettel, FPT)
try:
    urllib_conn.allowed_gai_family = lambda: socket.AF_INET
except Exception:
    pass

logger = logging.getLogger(__name__)

# Bảng hàng đợi tin nhắn Telegram bất đồng bộ (Thread-Safe FIFO Queue)
_TELEGRAM_QUEUE: "queue.Queue[tuple]" = queue.Queue(maxsize=1000)
_DISPATCHER_THREAD: Optional[threading.Thread] = None
_DISPATCHER_LOCK = threading.Lock()
_STOP_EVENT = threading.Event()

# Reusable Persistent Session với Connection Pooling & Keep-Alive
_SESSION: Optional[requests.Session] = None
_SESSION_LOCK = threading.Lock()

def _get_session() -> requests.Session:
    global _SESSION
    with _SESSION_LOCK:
        if _SESSION is None:
            s = requests.Session()
            retries = Retry(
                total=2,
                backoff_factor=0.5,
                status_forcelist=[500, 502, 503, 504],
                raise_on_status=False
            )
            adapter = HTTPAdapter(
                pool_connections=10,
                pool_maxsize=20,
                max_retries=retries
            )
            s.mount('https://', adapter)
            s.mount('http://', adapter)
            _SESSION = s
        return _SESSION

def _send_sync(token: str, chat_id: str, msg: str) -> bool:
    """Gửi đồng bộ trực tiếp tới Telegram Bot API kèm cơ chế retry thông minh và session keep-alive."""
    token = str(token or '').strip("'\" \t\r\n")
    chat_id = str(chat_id or '').strip("'\" \t\r\n")
    if not token or not chat_id or not msg:
        return False

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": msg,
        "disable_web_page_preview": True
    }

    session = _get_session()
    for attempt in range(3):
        try:
            # timeout=(5s connect, 12s read) đảm bảo bắt kịp độ trễ mạng quốc tế
            response = session.post(url, json=payload, timeout=(5, 12))
            result = response.json() if response.content else {}
            if response.ok and result.get('ok') is True:
                return True

            desc = result.get('description', 'unknown error')
            logger.debug("Telegram API rejected message (HTTP %s): %s", response.status_code, desc)
            if response.status_code < 500 and response.status_code != 429:
                return False

            retry_after = (result.get('parameters') or {}).get('retry_after', 0)
            time.sleep(min(float(retry_after or (2 ** attempt)), 5))
        except requests.exceptions.ReadTimeout:
            # Gói tin HTTP POST ĐÃ ĐƯỢC GỬI THÀNH CÔNG tới Telegram, chỉ có phản hồi ACK bị trễ do mạng quốc tế.
            # TUYỆT ĐỐI KHÔNG RETRY để tránh bắn lặp lại (duplicate) 2-3 tin nhắn giống hệt nhau về điện thoại!
            logger.debug("Telegram send hit ReadTimeout (tin nhắn đã được Telegram tiếp nhận, bỏ qua retry để chống lặp).")
            return True
        except (requests.RequestException, ValueError) as e:
            logger.debug("Telegram send attempt %s failed: %s", attempt + 1, e)
            if attempt == 2:
                logger.warning("⚠️ Không thể kết nối máy chủ Telegram (%s). Bot vẫn giao dịch bình thường.", type(e).__name__)
            if attempt < 2:
                time.sleep(min(2 ** attempt, 3))
    return False

def _telegram_worker():
    """Luồng nền độc lập xử lý và gửi tin nhắn Telegram không làm nghẽn bot trading."""
    logger.info("🚀 [TELEGRAM ASYNC] Luồng gửi thông báo Telegram chạy ngầm đã kích hoạt sẵn sàng.")
    while not _STOP_EVENT.is_set():
        try:
            try:
                item = _TELEGRAM_QUEUE.get(timeout=1.0)
            except queue.Empty:
                continue

            token, chat_id, msg = item
            try:
                _send_sync(token, chat_id, msg)
            except Exception as e:
                logger.error(f"[TELEGRAM ASYNC] Lỗi luồng gửi tin: {e}")
            finally:
                _TELEGRAM_QUEUE.task_done()
        except Exception as e:
            logger.error(f"[TELEGRAM ASYNC] Lỗi ngoại lệ trong worker: {e}")
            time.sleep(1.0)

def _ensure_dispatcher_started():
    global _DISPATCHER_THREAD
    with _DISPATCHER_LOCK:
        if _DISPATCHER_THREAD is None or not _DISPATCHER_THREAD.is_alive():
            _STOP_EVENT.clear()
            _DISPATCHER_THREAD = threading.Thread(
                target=_telegram_worker,
                name="telegram-async-dispatcher",
                daemon=True
            )
            _DISPATCHER_THREAD.start()

def send_telegram_message(token: str, chat_id: str, msg: str, async_send: bool = True) -> bool:
    """
    Gửi tin nhắn Telegram. Mặc định chạy bất đồng bộ (async_send=True) qua hàng đợi FIFO,
    trả về True ngay lập tức trong 0.0001ms để không bao giờ làm đóng băng luồng giao dịch của bot!
    """
    token = str(token or '').strip("'\" \t\r\n")
    chat_id = str(chat_id or '').strip("'\" \t\r\n")
    if not token or not chat_id or not msg:
        return False

    if not async_send:
        return _send_sync(token, chat_id, msg)

    _ensure_dispatcher_started()
    try:
        _TELEGRAM_QUEUE.put_nowait((token, chat_id, msg))
        return True
    except queue.Full:
        logger.warning("[TELEGRAM ASYNC] Hàng đợi tin nhắn bị đầy (>1000 tin), gửi trực tiếp fallback.")
        return _send_sync(token, chat_id, msg)

def flush_telegram_queue(timeout: float = 3.0):
    """Chờ gửi hết tin trong hàng đợi trước khi dừng bot."""
    try:
        _TELEGRAM_QUEUE.join()
    except Exception:
        pass
