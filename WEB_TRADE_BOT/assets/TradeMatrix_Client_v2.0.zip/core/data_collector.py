import logging
import pandas as pd
import os
from typing import Optional

logger = logging.getLogger(__name__)

class DataCollector:
    """
    Lớp thu thập và lưu trữ dữ liệu nến (OHLCV).
    """
    def __init__(self, exchange_connector, data_dir: str = 'data/historical/'):
        self.exchange = exchange_connector
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)

    def _get_file_path(self, symbol: str, timeframe: str) -> str:
        """Lấy đường dẫn file CSV cho một mã và khung thời gian (chuẩn hóa chống ký tự cấm trên Windows NTFS như dấu hai chấm ':')."""
        safe_symbol = symbol.replace('/', '_').replace(':', '_')
        return os.path.join(self.data_dir, f"{safe_symbol}_{timeframe}.csv")

    def fetch_data(self, symbol: str, timeframe: str, limit: int = 500) -> pd.DataFrame:
        """Tải dữ liệu mới từ sàn."""
        logger.info(f"Đang tải dữ liệu {symbol} {timeframe} (limit: {limit})")
        df = self.exchange.get_ohlcv(symbol, timeframe, limit)
        if not df.empty:
            self.save_data(df, symbol, timeframe)
        return df

    def update_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        """Cập nhật dữ liệu mới (incremental)."""
        cached_df = self.get_cached_data(symbol, timeframe)
        if cached_df is None or cached_df.empty:
            return self.fetch_data(symbol, timeframe)
            
        # Dữ liệu đã có, lấy dữ liệu mới hơn
        try:
            new_df = self.exchange.get_ohlcv(symbol, timeframe, limit=500)
            if new_df.empty:
                raise ValueError("API trả về dữ liệu rỗng")
        except Exception as e:
            logger.error(f"Lỗi cập nhật data cho {symbol}, dừng sử dụng data cũ: {e}")
            raise
        # Gộp và loại bỏ trùng lặp
        combined_df = pd.concat([cached_df, new_df])
        combined_df = combined_df[~combined_df.index.duplicated(keep='last')]
        combined_df.sort_index(inplace=True)
        
        # Giới hạn dung lượng cache để tránh phình to file (Giữ 2000 nến gần nhất)
        if len(combined_df) > 2000:
            combined_df = combined_df.tail(2000)
            
        self.save_data(combined_df, symbol, timeframe)
        logger.info(f"Đã cập nhật dữ liệu cho {symbol} {timeframe}")
        return combined_df

    def get_cached_data(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Lấy dữ liệu đã lưu trữ từ file CSV."""
        filepath = self._get_file_path(symbol, timeframe)
        if os.path.exists(filepath):
            try:
                df = pd.read_csv(filepath, index_col='timestamp', parse_dates=True)
                return df
            except Exception as e:
                logger.error(f"Lỗi đọc file cache {filepath}: {str(e)}")
        return None

    def save_data(self, df: pd.DataFrame, symbol: str, timeframe: str) -> None:
        """Lưu trữ dữ liệu vào file CSV."""
        if df.empty:
            return
            
        filepath = self._get_file_path(symbol, timeframe)
        try:
            df.to_csv(filepath)
            logger.debug(f"Đã lưu dữ liệu vào {filepath}")
        except Exception as e:
            logger.error(f"Lỗi lưu file {filepath}: {str(e)}")
