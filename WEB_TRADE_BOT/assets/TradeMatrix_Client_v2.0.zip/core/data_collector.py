import logging
import numpy as np
import pandas as pd
import os
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)

class DataCollector:
    """
    Lớp thu thập và lưu trữ dữ liệu nến (OHLCV).
    """
    def __init__(self, exchange_connector, data_dir: str = 'data/historical/'):
        self.exchange = exchange_connector
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        # [BOM #18 FIX - RAM TTL CACHE CHỐNG SPAM REST KLINES Ở NHỊP GÓI A 2.0s & PHA 1->2]:
        # 1m cache 8s (cắt ~80% REST weight khi giữ 2-3 lệnh song song), 5m/15m/1h/4h cache 12s (tránh gọi trùng Pha 1->2).
        self._ram_cache_lock = threading.Lock()
        self._ram_ohlcv_cache = {}
        # [BOM #137 FIX]: Per-file lock + disk-write throttle chong WinError 32 wipe CSV va giam bao Disk I/O
        self._file_locks_guard = threading.Lock()
        self._file_locks = {}
        self._last_disk_write_meta = {}

    def _get_file_lock(self, filepath: str) -> threading.Lock:
        with self._file_locks_guard:
            lock = self._file_locks.get(filepath)
            if lock is None:
                if len(self._file_locks) > 1000:
                    self._file_locks.clear()
                lock = threading.Lock()
                self._file_locks[filepath] = lock
            return lock

    def _get_file_path(self, symbol: str, timeframe: str) -> str:
        """Lấy đường dẫn file CSV cho một mã và khung thời gian (chuẩn hóa chống ký tự cấm trên Windows NTFS như dấu hai chấm ':')."""
        norm_sym = str(symbol or '').split(':')[0].strip().upper()
        safe_symbol = norm_sym.replace('/', '_').replace(':', '_')
        return os.path.join(self.data_dir, f"{safe_symbol}_{timeframe}.csv")

    _TF_SECONDS = {
        '1m': 60, '3m': 180, '5m': 300, '15m': 900,
        '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400,
    }

    def fetch_data(self, symbol: str, timeframe: str, limit: int = 500) -> pd.DataFrame:
        """Tải dữ liệu mới từ sàn (có RAM TTL Cache + kiểm tra ranh giới đóng nến + ghép nối không cắt cụt CSV lịch sử 500 nến)."""
        tf_str = str(timeframe or '15m').lower()
        ttl_sec = 8.0 if tf_str == '1m' else 12.0
        tf_sec = self._TF_SECONDS.get(tf_str, 900)
        cur_bucket = int(time.time() // tf_sec)
        norm_key = str(symbol or '').split(':')[0].strip().upper().replace('/', '')
        cache_key = (norm_key, tf_str)
        now_m = time.monotonic()
        lim_i = int(limit or 0)
        with self._ram_cache_lock:
            cached = self._ram_ohlcv_cache.get(cache_key)
            if cached is not None:
                # [BOM #147 P1-1 FIX]: Khớp cả ranh giới đóng nến (cur_bucket) để KHÔNG bao giờ trả về nến đóng cũ iloc[-2] ngay đầu phút :00/:15/:30/:45!
                if len(cached) == 4:
                    c_ts, c_lim, c_df, c_bucket = cached
                else:
                    c_ts, c_lim, c_df = cached
                    c_bucket = cur_bucket
                if (now_m - c_ts) < ttl_sec and c_bucket == cur_bucket and c_lim >= lim_i and c_df is not None and not c_df.empty:
                    return c_df.tail(lim_i).copy() if 0 < lim_i < len(c_df) else c_df.copy()

        logger.info(f"Đang tải dữ liệu {symbol} {timeframe} (limit: {limit})")
        df = self.exchange.get_ohlcv(symbol, timeframe, limit)
        if df is not None and not df.empty:
            ram_df, disk_df = self._merge_with_existing_history(df, symbol, timeframe, cache_key, lim_i)
            now_done = time.monotonic()
            # [BOM #148 P2-4 FIX]: Neo done_bucket theo timestamp nến cuối thực tế của sàn (ram_df.index[-1]) để tránh cache nến cũ ở giây :00.1 khi sàn chưa phát nến mới!
            try:
                done_bucket = int(pd.Timestamp(ram_df.index[-1]).timestamp() // tf_sec)
            except Exception:
                done_bucket = int(time.time() // tf_sec)
            with self._ram_cache_lock:
                self._ram_ohlcv_cache[cache_key] = (
                    now_done,
                    max(lim_i, len(ram_df)),
                    ram_df.copy(),
                    done_bucket,
                )
                if len(self._ram_ohlcv_cache) > 400:
                    oldest_keys = sorted(self._ram_ohlcv_cache.items(), key=lambda kv: kv[1][0])[:100]
                    for ok, _ in oldest_keys:
                        self._ram_ohlcv_cache.pop(ok, None)
            if disk_df is not None and not disk_df.empty:
                self.save_data(disk_df, symbol, timeframe)
                try:
                    last_bar_ts = pd.Timestamp(disk_df.index.max()).timestamp()
                except Exception:
                    last_bar_ts = 0.0
                with self._ram_cache_lock:
                    self._last_disk_write_meta[cache_key] = (now_done, last_bar_ts, len(disk_df))
            return ram_df.tail(lim_i).copy() if 0 < lim_i < len(ram_df) else ram_df.copy()
        return df

    CSV_MAX_ROWS_BY_TF = {
        '1m': 3000,   # ~2.1 ngày liên tục
        '3m': 3000,   # ~6.2 ngày
        '5m': 5000,   # ~17.3 ngày
        '15m': 4000,  # ~41.6 ngày
        '30m': 2500,  # ~52 ngày
        '1h': 2000,   # ~83 ngày
        '4h': 1000,   # ~166 ngày
        '1d': 500,    # ~1.4 năm
    }

    @staticmethod
    def _slice_last_contiguous_tail(df: pd.DataFrame, max_rows: int, gap_thresh_sec: float) -> pd.DataFrame:
        """[BOM #137 FIX]: Cắt đúng đoạn nến liên tục gần nhất cho RAM (không bao giờ kéo hố nhảy thời gian từ CSV vào tính EMA/RSI/ATR)."""
        if df is None or df.empty:
            return df
        tail_df = df.tail(max_rows) if len(df) > max_rows else df
        if len(tail_df) < 2:
            return tail_df
        try:
            idx_s = tail_df.index.to_series()
            diffs = idx_s.diff().dt.total_seconds()
            gap_mask = diffs > gap_thresh_sec
            if gap_mask.any():
                # [BOM #138 FIX]: Dùng np.flatnonzero O(N) bất biến trước duplicate timestamps (không gọi get_loc trả slice/array!)
                gap_positions = np.flatnonzero(gap_mask.to_numpy())
                if len(gap_positions) > 0:
                    last_gap_pos = int(gap_positions[-1])
                    if 0 < last_gap_pos < len(tail_df):
                        return tail_df.iloc[last_gap_pos:]
        except Exception:
            pass
        return tail_df

    def _merge_with_existing_history(
        self, new_df: pd.DataFrame, symbol: str, timeframe: str, cache_key: tuple, min_keep: int = 500
    ) -> tuple:
        """[BOM #135 + #136B + #137]: Tích lũy lịch sử CSV dài hạn theo timeframe (1m:3000, 5m:5000, 15m:4000, 1h:2000, 4h:1000),
        bảo vệ chống WinError 32 xóa lịch sử, không trả fallback dữ liệu cũ, lọc hố nhảy thời gian theo tf_step*8 và giảm Disk I/O."""
        tf_low = str(timeframe or '15m').lower()
        disk_keep = max(int(self.CSV_MAX_ROWS_BY_TF.get(tf_low, 1500)), int(min_keep or 500), len(new_df))
        ram_keep = max(600, int(min_keep or 500), len(new_df))
        tf_s_map = {'1m': 60.0, '3m': 180.0, '5m': 300.0, '15m': 900.0, '30m': 1800.0, '1h': 3600.0, '4h': 14400.0, '1d': 86400.0}
        tf_step = tf_s_map.get(tf_low, 900.0)
        gap_thresh = tf_step * 8.0

        filepath = self._get_file_path(symbol, timeframe)
        file_has_data = os.path.exists(filepath) and os.path.getsize(filepath) > 0

        # [BOM #137 FIX]: Giảm Disk I/O storm — nếu nến cuối không đổi và vừa ghi disk < 60s, chỉ ghép RAM và bỏ qua đọc/ghi CSV!
        now_m = time.monotonic()
        try:
            new_last_ts = pd.Timestamp(new_df.index.max()).timestamp()
        except Exception:
            new_last_ts = 0.0
        ram_existing = None
        last_w_meta = None
        with self._ram_cache_lock:
            c_ent = self._ram_ohlcv_cache.get(cache_key)
            if c_ent and c_ent[2] is not None and not c_ent[2].empty:
                ram_existing = c_ent[2]
            last_w_meta = self._last_disk_write_meta.get(cache_key)

        if (
            file_has_data
            and last_w_meta is not None
            and (now_m - last_w_meta[0]) < 60.0
            and new_last_ts > 0.0
            and abs(new_last_ts - last_w_meta[1]) < 1.0
        ):
            if ram_existing is not None and not ram_existing.empty:
                try:
                    comb_ram = pd.concat([ram_existing, new_df])
                    comb_ram = comb_ram[~comb_ram.index.duplicated(keep='last')].sort_index()
                    ram_df = self._slice_last_contiguous_tail(comb_ram, ram_keep, gap_thresh)
                    if len(ram_df) < len(new_df):
                        ram_df = new_df
                    return ram_df, None
                except Exception:
                    return new_df, None
            return new_df, None

        disk_existing = self.get_cached_data(symbol, timeframe) if file_has_data else None
        # [BOM #137 FIX]: Nếu CSV trên đĩa tồn tại và khác rỗng nhưng đọc thất bại (WinError 32 tạm thời),
        # TUYỆT ĐỐI KHÔNG ghi đè disk_df (trả None) để không xóa sạch 3000-5000 nến lịch sử!
        if file_has_data and (disk_existing is None or disk_existing.empty):
            logger.warning(f"Bỏ qua ghi đè CSV {filepath} vì lỗi đọc tạm thời (bảo toàn lịch sử đĩa).")
            if ram_existing is not None and not ram_existing.empty:
                try:
                    comb_ram = pd.concat([ram_existing, new_df])
                    comb_ram = comb_ram[~comb_ram.index.duplicated(keep='last')].sort_index()
                    ram_df = self._slice_last_contiguous_tail(comb_ram, ram_keep, gap_thresh)
                    return (ram_df if len(ram_df) >= len(new_df) else new_df), None
                except Exception:
                    return new_df, None
            return new_df, None

        base_existing = disk_existing if (disk_existing is not None and not disk_existing.empty) else ram_existing
        if base_existing is None or base_existing.empty:
            return new_df, new_df
        try:
            combined_disk = pd.concat([base_existing, new_df])
            combined_disk = combined_disk[~combined_disk.index.duplicated(keep='last')]
            combined_disk = combined_disk.sort_index()
            if len(combined_disk) > disk_keep:
                combined_disk = combined_disk.tail(disk_keep)

            ram_df = self._slice_last_contiguous_tail(combined_disk, ram_keep, gap_thresh)
            if ram_df is None or len(ram_df) < len(new_df):
                ram_df = new_df
            return ram_df, combined_disk
        except Exception as merge_err:
            logger.warning(f"Lỗi ghép lịch sử OHLCV {symbol} {timeframe} (giữ nguyên nến live mới, không ghi đè đĩa): {merge_err}")
            return new_df, None

    def get_cached_data(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Lấy dữ liệu đã lưu trữ từ file CSV (có khóa theo file + retry WinError 32 an toàn đa luồng)."""
        filepath = self._get_file_path(symbol, timeframe)
        if not (os.path.exists(filepath) and os.path.getsize(filepath) > 0):
            return None
        file_lock = self._get_file_lock(filepath)
        for attempt in range(3):
            try:
                with file_lock:
                    with open(filepath, 'r', encoding='utf-8', errors='replace') as fh:
                        header_line = fh.readline().strip()
                    cols = [c.strip().strip('"').strip("'") for c in header_line.split(',')] if header_line else []
                    idx_col = 'timestamp' if 'timestamp' in cols else ('datetime' if 'datetime' in cols else 0)
                    df = pd.read_csv(filepath, index_col=idx_col, parse_dates=True)
                    return df
            except (PermissionError, OSError) as pe:
                if attempt < 2:
                    time.sleep(0.06 * (attempt + 1))
                else:
                    logger.error(f"Lỗi đọc file cache {filepath} sau 3 lần thử: {pe}")
            except Exception as e:
                logger.error(f"Lỗi đọc file cache {filepath}: {str(e)}")
                return None
        return None

    def save_data(self, df: pd.DataFrame, symbol: str, timeframe: str) -> None:
        """Lưu trữ dữ liệu vào file CSV theo cơ chế nguyên tử (Atomic Write) an toàn trên Windows đa luồng."""
        if df is None or df.empty:
            return
            
        filepath = self._get_file_path(symbol, timeframe)
        file_lock = self._get_file_lock(filepath)
        # Sử dụng thread id và nano timestamp để tránh va chạm tên tmp giữa các luồng ghi đồng thời
        tmp_path = f"{filepath}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp"
        try:
            df.to_csv(tmp_path)
            # Trên Windows NTFS, nếu file đích đang được luồng khác đọc, os.replace có thể bắn WinError 32
            # Thực hiện retry tối đa 5 lần với khóa per-file để loại bỏ dứt điểm WinError 32
            with file_lock:
                for attempt in range(5):
                    try:
                        os.replace(tmp_path, filepath)
                        break
                    except (PermissionError, OSError) as pe:
                        if attempt < 4:
                            time.sleep(0.08 * (attempt + 1))
                        else:
                            raise pe
            logger.debug(f"Đã lưu dữ liệu vào {filepath}")
        except Exception as e:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
            logger.warning(f"Lỗi lưu file cache {filepath} (đang bị luồng khác truy cập): {str(e)}")
