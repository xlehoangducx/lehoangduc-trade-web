import os
import yaml
import logging
import itertools
import pandas as pd
from datetime import datetime
from pathlib import Path
import sys

# Setup paths
ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))

from core.exchange import ExchangeConnector
from strategies.trend_following import TrendFollowingStrategy

logger = logging.getLogger(__name__)

class StrategyOptimizer:
    """
    Module tự động tìm kiếm thông số tối ưu (Hyperparameter Tuning) 
    và nâng cấp strategies.yaml hằng ngày.
    """
    def __init__(self, config_path: str):
        self.config_path = config_path
        self.strategies_path = str(ROOT_DIR / "config" / "strategies.yaml")
        
        with open(self.config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
            
        with open(self.strategies_path, 'r', encoding='utf-8') as f:
            self.strategies_config = yaml.safe_load(f)
            
        self.exchange = ExchangeConnector(self.config)
        
    def fetch_recent_data(self, symbol: str, timeframe: str = '1h', limit: int = 1000) -> pd.DataFrame:
        """Lấy dữ liệu để test."""
        logger.info(f"Đang tải dữ liệu {symbol} {timeframe} để tối ưu hóa...")
        return self.exchange.get_ohlcv(symbol, timeframe, limit)

    def simple_backtest(self, df: pd.DataFrame, strategy, params: dict) -> float:
        """
        Backtest siêu nhanh để đánh giá một bộ thông số.
        Trả về PnL ước tính.
        """
        # Cập nhật thông số tạm thời
        strategy.params.update(params)
        df_analyzed = strategy.get_indicators(df)
        
        if df_analyzed is None or df_analyzed.empty:
            return -999.0
            
        # Mô phỏng mua bán cơ bản
        position = 0
        entry_price = 0
        pnl = 0.0
        fee_rate = max(0.0, float(self.config.get('trading', {}).get('fee_rate', 0.001)))
        slippage_rate = max(0.0, float(self.config.get('trading', {}).get('slippage_rate', 0.0005)))
        
        # Lấy ATR an toàn
        df_analyzed['atr'] = df_analyzed['atr'].fillna(0)
        
        for i in range(50, len(df_analyzed)):
            current = df_analyzed.iloc[i]
            previous = df_analyzed.iloc[i-1]
            price = current['close']
            
            # Logic trend_following giản lược để đánh giá nhanh
            ema_crossover_up = previous['ema_fast'] <= previous.get('ema_mid', previous['ema_slow']) and current['ema_fast'] > current.get('ema_mid', current['ema_slow'])
            rsi_buy = current['rsi'] < params.get('rsi_overbought', 65)
            
            ema_crossover_down = previous['ema_fast'] >= previous.get('ema_mid', previous['ema_slow']) and current['ema_fast'] < current.get('ema_mid', current['ema_slow'])
            rsi_sell = current['rsi'] > 70
            
            if position == 0 and ema_crossover_up and rsi_buy:
                position = 1
                entry_price = price * (1 + slippage_rate)
            elif position == 1 and (ema_crossover_down or rsi_sell):
                position = 0
                exit_price = price * (1 - slippage_rate)
                pnl += ((exit_price * (1 - fee_rate)) / (entry_price * (1 + fee_rate)) - 1) * 100

        if position == 1 and entry_price > 0:
            exit_price = float(df_analyzed['close'].iloc[-1]) * (1 - slippage_rate)
            pnl += ((exit_price * (1 - fee_rate)) / (entry_price * (1 + fee_rate)) - 1) * 100
                
        return pnl

    def optimize_trend_following(self, df: pd.DataFrame):
        """Tìm bộ thông số tốt nhất cho Trend Following."""
        logger.info("Bắt đầu tối ưu hóa Trend Following...")
        
        param_grid = {
            'ema_fast': [7, 9, 12],
            'ema_mid': [21, 25],
            'ema_slow': [50, 55, 60],
            'rsi_overbought': [60, 65, 70]
        }
        
        # Tạo tất cả các tổ hợp
        keys = param_grid.keys()
        combinations = [dict(zip(keys, v)) for v in itertools.product(*param_grid.values())]
        
        best_pnl = -999.0
        best_params = None
        
        base_strat = TrendFollowingStrategy("test", self.strategies_config['strategies']['trend_following'])
        
        count = 0
        for params in combinations:
            count += 1
            pnl = self.simple_backtest(df, base_strat, params)
            if pnl > best_pnl:
                best_pnl = pnl
                best_params = params
                
        logger.info(f"Đã test {count} bộ thông số.")
        logger.info(f"Tổ hợp sinh lời cao nhất ({best_pnl:.2f}%): {best_params}")
        
        return best_params

    def run_optimization(self):
        """Chạy quá trình nâng cấp."""
        logger.info("\n" + "="*50)
        logger.info(f"🚀 BẮT ĐẦU AUTO-OPTIMIZER (AI TỰ NÂNG CẤP) - {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        logger.info("="*50)
        
        primary_pair = self.config['trading']['pairs'][0]
        df = self.fetch_recent_data(primary_pair, '1h', limit=1000)
        
        if df is not None and not df.empty and len(df) >= 250:
            # Optimize on older candles; only apply if a later holdout window
            # beats the current parameters after estimated fees and slippage.
            split = int(len(df) * 0.70)
            train_df, validation_df = df.iloc[:split], df.iloc[split:]
            best_trend_params = self.optimize_trend_following(train_df)
            current_params = dict(self.strategies_config['strategies']['trend_following']['params'])
            candidate_params = dict(current_params)
            if best_trend_params:
                candidate_params.update(best_trend_params)
                current_config = dict(self.strategies_config['strategies']['trend_following'])
                current_config['params'] = dict(current_params)
                candidate_config = dict(self.strategies_config['strategies']['trend_following'])
                candidate_config['params'] = dict(candidate_params)
                current_score = self.simple_backtest(
                    validation_df, TrendFollowingStrategy('current', current_config), current_params
                )
                candidate_score = self.simple_backtest(
                    validation_df, TrendFollowingStrategy('candidate', candidate_config), candidate_params
                )
                if candidate_score > max(0.0, current_score):
                    self.strategies_config['strategies']['trend_following']['params'] = candidate_params
                    with open(self.strategies_path, 'w', encoding='utf-8') as f:
                        yaml.dump(self.strategies_config, f, default_flow_style=False, allow_unicode=True)
                    logger.info(
                        f"✅ Cập nhật tham số sau holdout: hiện tại {current_score:.2f}%, "
                        f"ứng viên {candidate_score:.2f}% (đã trừ phí/slippage ước tính)."
                    )
                else:
                    logger.info(
                        f"Giữ tham số hiện tại: holdout hiện tại {current_score:.2f}%, "
                        f"ứng viên {candidate_score:.2f}%."
                    )
        else:
            logger.error("Không đủ dữ liệu để tối ưu hóa và xác thực ngoài mẫu (cần tối thiểu 250 nến).")
            
        logger.info("="*50)
        logger.info("🏁 QUÁ TRÌNH NÂNG CẤP HOÀN TẤT")
        logger.info("="*50 + "\n")

if __name__ == "__main__":
    # Setup basic logging for standalone run
    logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s')
    
    config_file = str(ROOT_DIR / "config" / "settings.yaml")
    optimizer = StrategyOptimizer(config_file)
    optimizer.run_optimization()
