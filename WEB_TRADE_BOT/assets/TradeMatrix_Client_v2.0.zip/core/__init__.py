# File khởi tạo module core
# Chứa các thành phần cốt lõi của bot giao dịch
