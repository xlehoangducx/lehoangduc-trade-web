"""
BINANCE QUANTUM WEBSOCKET ORCHESTRATOR (DUAL-TIER WEBSOCKET)
============================================================
Module quản lý luồng WebSocket chuyên dụng cho TradeMatrix:
1. TẦNG 2: On-Demand Depth Stream Pool (Sổ lệnh động nấc 20 @ 100ms)
   - Chỉ mở kết nối khi có lệnh M1 Sniper Stalking rình mồi.
   - Gộp nhiều cặp qua luồng Combined Stream duy nhất của Binance:
     wss://fstream.binance.com/stream?streams=btcusdt@depth20@100ms/ethusdt@depth20@100ms
   - Tự động đóng và giải phóng tài nguyên khi hoàn tất rình mồi.
2. TẦNG 3: Binance User Data Stream (Lắng nghe sự kiện tài khoản 24/7)
   - Lấy listenKey qua ccxt.binanceusdm fapiPrivatePostListenKey()
   - Lắng nghe sự kiện ORDER_TRADE_UPDATE để phản xạ 0ms khi khớp SL/TP/Maker.
   - Tự động gửi keepalive PUT request mỗi 30 phút.
3. Fail-Safe:
   - Chạy trên thread riêng biệt với asyncio event loop độc lập.
   - Tự động kết nối lại khi rớt mạng (Exponential Backoff).
   - Tuyệt đối không làm crash bot khi có lỗi ngoại lệ.
"""

import asyncio
import concurrent.futures
import json
import logging
import threading
import time
from typing import Any, Callable, Dict, Optional, Set

try:
    import websockets
except ImportError:
    websockets = None

logger = logging.getLogger("binance_ws")


def clean_stream_symbol(symbol: str) -> str:
    """Chuyển đổi symbol chuẩn (e.g. BTC/USDT:USDT -> btcusdt) cho Binance WebSocket."""
    if not symbol:
        return ""
    clean = symbol.split(':')[0].strip().replace('/', '').lower()
    return clean


def norm_sym_key(symbol: str) -> str:
    """Chuẩn hóa symbol thành key viết hoa không dấu gạch (e.g. BTC/USDT:USDT -> BTCUSDT)."""
    if not symbol:
        return ""
    return symbol.split(':')[0].strip().replace('/', '').upper()


class BinanceWSManager:
    """
    Quản lý luồng WebSocket cho Binance Futures:
    - User Data Stream (Kênh cá nhân báo khớp lệnh 0ms)
    - On-Demand Depth Stream Pool (Sổ lệnh 20 nấc thời gian thực)
    """

    def __init__(
        self,
        exchange_wrapper,
        mode: str = 'live',
        on_order_update: Optional[Callable[[Dict], None]] = None,
        max_depth_streams: int = 3,
    ):
        self.exchange_wrapper = exchange_wrapper
        self.mode = mode.lower() if mode else 'live'
        self.on_order_update = on_order_update
        self.max_depth_streams = max(1, int(max_depth_streams))

        self._lock = threading.Lock()
        self._active_depth_symbols: Set[str] = set()   # Lưu raw symbols cho Depth 20 @ 100ms
        self._active_ticker_symbols: Set[str] = set()  # Lưu raw symbols cho BookTicker (0 REST weight kéo SL/TP)
        self._latest_depth: Dict[str, Dict] = {}       # norm_sym -> {'bids': [...], 'asks': [...], 'timestamp': float}
        self._latest_book_ticker: Dict[str, Dict] = {} # norm_sym -> {'bid': float, 'ask': float, 'last': float, 'timestamp': float}
        self.max_ticker_streams = 8

        self._is_running = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        self._listen_key: Optional[str] = None
        self._last_listen_key_keepalive: float = 0.0
        self._streams_need_restart = asyncio.Event() if asyncio else None
        self._seen_algo_events: Dict[tuple, float] = {}
        self._actual_to_algo_id: Dict[str, str] = {}
        self._pending_sub_reqs: Dict[int, Set[str]] = {}
        self._last_market_msg_ts: float = 0.0
        self._order_executor: Optional[concurrent.futures.ThreadPoolExecutor] = (
            concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="ws_order_seq")
        )

    # ==========================================
    # PUBLIC LIFECYCLE API
    # ==========================================

    def start(self):
        """Khởi chạy WebSocket Manager trên thread nền."""
        if websockets is None:
            logger.warning("Thư viện 'websockets' chưa được cài đặt; tắt WebSocket Manager.")
            return

        with self._lock:
            if self._is_running:
                return
            if self._order_executor is None:
                self._order_executor = concurrent.futures.ThreadPoolExecutor(
                    max_workers=1, thread_name_prefix="ws_order_seq"
                )
            self._is_running = True

        self._thread = threading.Thread(
            target=self._run_event_loop,
            name="binance-ws-orchestrator",
            daemon=True,
        )
        self._thread.start()
        logger.info("📡 Binance Quantum WebSocket Orchestrator đã khởi chạy nền thành công.")

    def stop(self):
        """Dừng WebSocket Manager và đóng các kết nối."""
        with self._lock:
            if not self._is_running:
                return
            self._is_running = False

        loop = self._loop
        if loop and loop.is_running():
            try:
                loop.call_soon_threadsafe(loop.stop)
            except RuntimeError:
                pass

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

        order_exec = getattr(self, '_order_executor', None)
        if order_exec is not None:
            try:
                order_exec.shutdown(wait=False)
            except Exception:
                pass
            self._order_executor = None
        logger.info("📡 Binance Quantum WebSocket Orchestrator đã dừng.")

    # ==========================================
    # ON-DEMAND DEPTH STREAM POOL (TẦNG 2)
    # ==========================================

    def subscribe_depth(self, symbol: str) -> bool:
        """
        Đăng ký theo dõi Sổ lệnh 20 nấc (Depth 20 @ 100ms) cho 1 cặp tiền.
        Chỉ cho phép tối đa max_depth_streams cặp cùng lúc để bảo vệ tài nguyên.
        """
        if not symbol or websockets is None:
            return False

        norm_s = norm_sym_key(symbol)
        with self._lock:
            if len(self._active_depth_symbols) >= self.max_depth_streams and norm_s not in self._active_depth_symbols:
                logger.warning(
                    f"⚠️ Depth Pool đã đầy ({len(self._active_depth_symbols)}/{self.max_depth_streams}). "
                    f"Từ chối mở thêm WebSocket cho {symbol}."
                )
                return False
            self._active_depth_symbols.add(norm_s)

        logger.info(f"🎯 [DEPTH WS] Đã đăng ký luồng sổ lệnh 100ms cho {symbol} (Pool: {len(self._active_depth_symbols)}/{self.max_depth_streams}).")
        self._notify_streams_changed()
        return True

    def unsubscribe_depth(self, symbol: str):
        """Hủy đăng ký và giải phóng slot trong Depth Pool."""
        if not symbol:
            return

        norm_s = norm_sym_key(symbol)
        with self._lock:
            if norm_s in self._active_depth_symbols:
                self._active_depth_symbols.remove(norm_s)
                self._latest_depth.pop(norm_s, None)
                logger.info(f"🏁 [DEPTH WS] Đã hủy luồng sổ lệnh cho {symbol} (Pool còn: {len(self._active_depth_symbols)}/{self.max_depth_streams}).")

        self._notify_streams_changed()

    def sync_active_depth_symbols(self, active_symbols: Set[str]):
        """
        Tự động đồng bộ và dọn dẹp các stream không còn nằm trong hàng đợi rình mồi.
        Đảm bảo không bao giờ bị rò rỉ tài nguyên (Self-Healing Pool).
        """
        if active_symbols is None:
            active_symbols = set()
        norm_target = {norm_sym_key(s) for s in active_symbols if s}

        changed = False
        with self._lock:
            current_symbols = set(self._active_depth_symbols)
            to_remove = current_symbols - norm_target
            for s in to_remove:
                self._active_depth_symbols.remove(s)
                self._latest_depth.pop(s, None)
                changed = True
            if changed:
                logger.info(f"🔄 [DEPTH WS SYNC] Đã thu hồi {len(to_remove)} luồng thừa. Pool hiện tại: {len(self._active_depth_symbols)}/{self.max_depth_streams}.")

        if changed:
            self._notify_streams_changed()

    def sync_active_ticker_symbols(self, active_symbols: Set[str], priority_symbols: Optional[Set[str]] = None):
        """
        [GÓI A + BOM #120J FIX - ZERO-REST-WEIGHT SL/TP STREAM]:
        Đồng bộ danh sách mã đang có vị thế mở / rình mồi M1 để nhận giá Best Bid/Ask real-time qua @bookTicker.
        Ưu tiên tuyệt đối `priority_symbols` (vị thế đang mở) lên đầu trước khi cắt trần 8 mã để không bao giờ
        đẩy văng vị thế đang mở do thứ tự bảng chữ cái!
        """
        if active_symbols is None:
            active_symbols = set()
        merged_in = set(active_symbols) | {p for p in (priority_symbols or ()) if p}
        prio_norm = {norm_sym_key(p) for p in (priority_symbols or ()) if p}
        ordered_in = sorted(
            merged_in,
            key=lambda s: (0 if norm_sym_key(s) in prio_norm else 1, str(s)),
        )
        normalized_in = set()
        capped_symbols = []
        for s in ordered_in:
            nk = norm_sym_key(s)
            if nk and nk not in normalized_in:
                normalized_in.add(nk)
                capped_symbols.append(s)
            if len(capped_symbols) >= self.max_ticker_streams:
                break
        target_set = set(capped_symbols)

        changed = False
        with self._lock:
            current_norm = {norm_sym_key(s) for s in self._active_ticker_symbols}
            target_norm = {norm_sym_key(s) for s in target_set}
            if current_norm != target_norm:
                removed_norm = current_norm - target_norm
                for nk in removed_norm:
                    self._latest_book_ticker.pop(nk, None)
                self._active_ticker_symbols = target_set
                changed = True
                logger.info(
                    f"⚡ [BOOKTICKER WS SYNC] Cập nhật luồng giá thực thời gian kéo SL/TP: "
                    f"{len(self._active_ticker_symbols)}/{self.max_ticker_streams} mã (0 REST Weight)."
                )
        if changed:
            self._notify_streams_changed()

    def get_live_book_ticker(self, symbol: str, max_age_seconds: float = 3.0) -> Optional[Dict]:
        """
        Trả về Best Bid/Ask & Mid price thời gian thực từ WebSocket @bookTicker (0ms, 0 REST API weight).
        Trả None nếu chưa có hoặc quá hạn để fallback an toàn sang REST API.
        """
        clean_k = norm_sym_key(symbol)
        with self._lock:
            item = self._latest_book_ticker.get(clean_k)
            if not item:
                return None
            age = time.time() - item.get('timestamp', 0.0)
            ws_healthy = self._is_running and (time.time() - float(getattr(self, '_last_market_msg_ts', 0.0) or 0.0)) <= 15.0
            eff_max_age = max(float(max_age_seconds), 15.0) if ws_healthy else float(max_age_seconds)
            if age <= eff_max_age:
                return {
                    'bid': item['bid'],
                    'ask': item['ask'],
                    'last': item['last'],
                    'close': item['last'],
                    'timestamp': item['timestamp'],
                    'source': 'ws_bookTicker',
                }
        return None

    def get_live_depth(self, symbol: str, max_age_seconds: float = 1.5) -> Optional[Dict]:
        """
        Lấy ảnh chụp sổ lệnh 20 nấc thời gian thực từ WebSocket cache.
        Nếu dữ liệu còn tươi (< max_age_seconds), trả về {'bids': [...], 'asks': [...]}.
        Nếu không có hoặc dữ liệu quá cũ, trả về None (để fallback an toàn sang REST API).
        """
        clean_k = norm_sym_key(symbol)
        with self._lock:
            item = self._latest_depth.get(clean_k)
            if not item:
                return None
            age = time.time() - item.get('timestamp', 0.0)
            if age <= max_age_seconds:
                return {
                    'bids': item['bids'],
                    'asks': item['asks'],
                    'timestamp': item['timestamp'],
                    'source': 'websocket_live',
                }
        return None

    def _notify_streams_changed(self):
        """Báo cho async loop biết danh sách stream đã thay đổi để tái kết nối luồng gộp."""
        loop = self._loop
        ev = self._streams_need_restart
        if loop and loop.is_running() and ev:
            try:
                loop.call_soon_threadsafe(ev.set)
            except RuntimeError:
                pass

    # ==========================================
    # ASYNCIO WORKER CORE
    # ==========================================

    def _run_event_loop(self):
        """Chạy asyncio event loop trên thread riêng."""
        loop = asyncio.new_event_loop()
        self._loop = loop
        asyncio.set_event_loop(loop)
        self._streams_need_restart = asyncio.Event()

        try:
            loop.run_until_complete(self._main_worker())
        except Exception as e:
            logger.debug(f"[BinanceWS] Event loop kết thúc: {e}")
        finally:
            self._cleanup_loop(loop)

    def _cleanup_loop(self, loop=None):
        """Dọn dẹp các task còn sót lại khi loop kết thúc."""
        target_loop = loop or self._loop
        if not target_loop:
            return
        try:
            if not target_loop.is_closed():
                pending = asyncio.all_tasks(target_loop)
                for task in pending:
                    task.cancel()
                if pending:
                    target_loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                target_loop.close()
        except Exception:
            pass
        finally:
            if self._loop is target_loop:
                self._loop = None

    async def _main_worker(self):
        """Worker chính quản lý song song User Data Stream và Depth Pool."""
        tasks = [
            asyncio.create_task(self._depth_stream_loop()),
        ]

        # Chỉ kích hoạt User Data Stream ở chế độ LIVE
        if self.mode == 'live':
            tasks.append(asyncio.create_task(self._user_data_stream_loop()))

        try:
            await asyncio.gather(*tasks, return_exceptions=True)
        except asyncio.CancelledError:
            pass

    # ==========================================
    # TẦNG 2: DEPTH STREAM LOOP (COMBINED STREAM)
    # ==========================================

    async def _depth_stream_loop(self):
        """Vòng lặp duy trì kết nối luồng gộp Combined Stream (@depth20@100ms + @bookTicker)."""
        market_backoff = 2.0
        while self._is_running:
            with self._lock:
                if self._streams_need_restart is not None:
                    self._streams_need_restart.clear()
                depth_symbols = list(self._active_depth_symbols)
                ticker_symbols = list(self._active_ticker_symbols)

            if not depth_symbols and not ticker_symbols:
                # Không có cặp nào đang mở lệnh hoặc rình mồi, ngủ tiết kiệm tài nguyên
                try:
                    await asyncio.wait_for(self._streams_need_restart.wait(), timeout=2.0)
                except asyncio.TimeoutError:
                    pass
                continue

            stream_parts = []
            seen_parts = set()
            for s in depth_symbols:
                cs = clean_stream_symbol(s)
                if cs:
                    part = f"{cs}@depth20@100ms"
                    if part not in seen_parts:
                        seen_parts.add(part)
                        stream_parts.append(part)
            for s in ticker_symbols:
                cs = clean_stream_symbol(s)
                if cs:
                    part = f"{cs}@bookTicker"
                    if part not in seen_parts:
                        seen_parts.add(part)
                        stream_parts.append(part)

            streams_param = "/".join(stream_parts)
            if not streams_param:
                await asyncio.sleep(1.0)
                continue

            _ws_host = "wss://stream.binancefuture.com" if bool(getattr(self.exchange_wrapper, 'testnet', False)) else "wss://fstream.binance.com"
            ws_url = f"{_ws_host}/stream?streams={streams_param}"

            need_market_backoff = False
            try:
                logger.debug(f"Kết nối Combined Market WS ({len(stream_parts)} streams): {ws_url}")
                current_stream_set = set(stream_parts)
                req_id = 1
                sub_err_backoff = 2.0
                pending_sub_reqs: Dict[int, Dict[str, Any]] = {}
                inflight_sub: Set[str] = set()
                inflight_unsub: Set[str] = set()
                sub_retry_after: float = 0.0
                async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
                    while self._is_running:
                        now_mono = time.monotonic()
                        due_retry = (sub_retry_after > 0.0 and now_mono >= sub_retry_after)
                        if (self._streams_need_restart.is_set() or due_retry) and (sub_retry_after <= 0.0 or now_mono >= sub_retry_after):
                            sub_retry_after = 0.0
                            with self._lock:
                                self._streams_need_restart.clear()
                                n_depth = list(self._active_depth_symbols)
                                n_tick = list(self._active_ticker_symbols)
                            new_set = set()
                            for s in n_depth:
                                cs = clean_stream_symbol(s)
                                if cs:
                                    new_set.add(f"{cs}@depth20@100ms")
                            for s in n_tick:
                                cs = clean_stream_symbol(s)
                                if cs:
                                    new_set.add(f"{cs}@bookTicker")
                            if not new_set:
                                break
                            to_unsub = sorted((current_stream_set - new_set) - inflight_unsub)
                            to_sub = sorted((new_set - current_stream_set) - inflight_sub)
                            try:
                                if to_unsub:
                                    unsub_id = req_id
                                    req_id += 1
                                    pending_sub_reqs[unsub_id] = {'unsub': list(to_unsub)}
                                    inflight_unsub.update(to_unsub)
                                    await ws.send(json.dumps({"method": "UNSUBSCRIBE", "params": to_unsub, "id": unsub_id}))
                                if to_sub:
                                    sub_id = req_id
                                    req_id += 1
                                    pending_sub_reqs[sub_id] = {'sub': list(to_sub)}
                                    inflight_sub.update(to_sub)
                                    await ws.send(json.dumps({"method": "SUBSCRIBE", "params": to_sub, "id": sub_id}))
                            except Exception:
                                need_market_backoff = True
                                break

                        try:
                            msg_raw = await asyncio.wait_for(ws.recv(), timeout=1.0)
                        except asyncio.TimeoutError:
                            continue

                        try:
                            msg = json.loads(msg_raw)
                        except Exception:
                            continue

                        msg_id = msg.get('id')
                        if msg_id is not None and msg_id in pending_sub_reqs:
                            req_meta = pending_sub_reqs.pop(msg_id, {})
                            inflight_unsub.difference_update(req_meta.get('unsub') or ())
                            inflight_sub.difference_update(req_meta.get('sub') or ())
                            if msg.get('error'):
                                logger.warning(f"⚠️ Binance WS SUBSCRIBE/UNSUBSCRIBE từ chối: {msg.get('error')}")
                                sub_retry_after = time.monotonic() + sub_err_backoff
                                sub_err_backoff = min(15.0, sub_err_backoff * 1.5)
                            else:
                                sub_err_backoff = 2.0
                                if req_meta.get('unsub'):
                                    current_stream_set -= set(req_meta['unsub'])
                                if req_meta.get('sub'):
                                    current_stream_set |= set(req_meta['sub'])
                            continue

                        stream_name = str(msg.get('stream') or '')
                        data = msg.get('data') or msg
                        if not isinstance(data, dict):
                            continue
                        sym = data.get('s')
                        if not sym:
                            continue
                        market_backoff = 2.0
                        now_ts = time.time()
                        self._last_market_msg_ts = now_ts
                        norm_k = norm_sym_key(sym)

                        if '@bookTicker' in stream_name or data.get('e') == 'bookTicker':
                            try:
                                bid_px = float(data.get('b') or 0.0)
                                ask_px = float(data.get('a') or 0.0)
                                if bid_px > 0 and ask_px > 0:
                                    mid_px = (bid_px + ask_px) * 0.5
                                    with self._lock:
                                        if any(norm_sym_key(s) == norm_k for s in self._active_ticker_symbols):
                                            self._latest_book_ticker[norm_k] = {
                                                'bid': bid_px,
                                                'ask': ask_px,
                                                'last': mid_px,
                                                'timestamp': now_ts,
                                            }
                            except (TypeError, ValueError):
                                pass
                        elif '@depth' in stream_name or data.get('e') == 'depthUpdate':
                            bids = data.get('b')
                            asks = data.get('a')
                            if bids is not None and asks is not None:
                                try:
                                    bids_f = [[float(lvl[0]), float(lvl[1])] for lvl in bids if isinstance(lvl, (list, tuple)) and len(lvl) >= 2]
                                    asks_f = [[float(lvl[0]), float(lvl[1])] for lvl in asks if isinstance(lvl, (list, tuple)) and len(lvl) >= 2]
                                    if bids_f and asks_f:
                                        with self._lock:
                                            if any(norm_sym_key(s) == norm_k for s in self._active_depth_symbols):
                                                self._latest_depth[norm_k] = {
                                                    'bids': bids_f,
                                                    'asks': asks_f,
                                                    'timestamp': now_ts,
                                                }
                                except (TypeError, ValueError):
                                    pass
                if need_market_backoff and self._is_running:
                    logger.debug(f"Combined Market WS gửi lệnh gián đoạn; kết nối lại sau {market_backoff:.1f}s...")
                    await asyncio.sleep(market_backoff)
                    market_backoff = min(30.0, market_backoff * 1.5)
            except Exception as e:
                if self._is_running:
                    logger.debug(f"Kết nối Combined Market WS gián đoạn ({e}); tự động kết nối lại sau {market_backoff:.1f}s...")
                    await asyncio.sleep(market_backoff)
                    market_backoff = min(30.0, market_backoff * 1.5)

    # ==========================================
    # TẦNG 3: USER DATA STREAM LOOP
    # ==========================================

    def _get_listen_key(self) -> Optional[str]:
        """Tạo listenKey mới từ sàn Binance qua ccxt (tôn trọng cầu dao IP Ban)."""
        try:
            from core.exchange import get_ip_ban_remaining_seconds, _extract_and_activate_ip_ban
            if get_ip_ban_remaining_seconds() > 0:
                return None
            raw_ex = getattr(self.exchange_wrapper, 'exchange', None)
            if raw_ex and hasattr(raw_ex, 'fapiPrivatePostListenKey'):
                res = raw_ex.fapiPrivatePostListenKey()
                if isinstance(res, dict) and res.get('listenKey'):
                    return res['listenKey']
        except Exception as e:
            try:
                from core.exchange import _extract_and_activate_ip_ban
                _extract_and_activate_ip_ban(e)
            except Exception:
                pass
            logger.debug(f"Không thể tạo listenKey từ Binance: {e}")
        return None

    def _keepalive_listen_key(self, listen_key: str) -> bool:
        """Gửi keepalive PUT để gia hạn listenKey mỗi 30 phút (trả về False khi lỗi để reconnect sạch, chống spam 2s/lần)."""
        try:
            from core.exchange import get_ip_ban_remaining_seconds, _extract_and_activate_ip_ban
            if get_ip_ban_remaining_seconds() > 0:
                self._last_listen_key_keepalive = time.time() - 1740  # thử lại sau 60s
                return True
            raw_ex = getattr(self.exchange_wrapper, 'exchange', None)
            if raw_ex and hasattr(raw_ex, 'fapiPrivatePutListenKey'):
                raw_ex.fapiPrivatePutListenKey({'listenKey': listen_key})
                self._last_listen_key_keepalive = time.time()
                logger.debug("Đã gửi keepalive listenKey thành công.")
                return True
        except Exception as e:
            try:
                from core.exchange import _extract_and_activate_ip_ban
                _extract_and_activate_ip_ban(e)
            except Exception:
                pass
            logger.debug(f"Lỗi gửi keepalive listenKey: {e}")
            return False
        return False

    async def _user_data_stream_loop(self):
        """Vòng lặp duy trì kết nối User Data Stream để bắt sự kiện khớp lệnh 0ms (không block asyncio loop)."""
        backoff = 2.0
        while self._is_running:
            listen_key = await asyncio.to_thread(self._get_listen_key)
            if not listen_key:
                logger.debug("Chưa có listenKey; thử lại sau 15s...")
                await asyncio.sleep(15.0)
                continue

            self._listen_key = listen_key
            self._last_listen_key_keepalive = time.time()
            _ws_host = "wss://stream.binancefuture.com" if bool(getattr(self.exchange_wrapper, 'testnet', False)) else "wss://fstream.binance.com"
            ws_url = f"{_ws_host}/ws/{listen_key}"

            need_uds_backoff = False
            try:
                logger.info("📡 Đã kết nối thành công Binance User Data Stream WebSocket (0ms Fill Reaction).")
                backoff = 2.0
                async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
                    while self._is_running:
                        # Kiểm tra gia hạn listenKey mỗi 30 phút (1800s) qua thread phụ tránh treo @bookTicker
                        if time.time() - self._last_listen_key_keepalive >= 1800:
                            ok_ka = await asyncio.to_thread(self._keepalive_listen_key, listen_key)
                            if not ok_ka:
                                logger.warning("⚠️ Keepalive listenKey thất bại — tự động xin listenKey mới sau backoff.")
                                need_uds_backoff = True
                                break

                        try:
                            msg_raw = await asyncio.wait_for(ws.recv(), timeout=2.0)
                        except asyncio.TimeoutError:
                            continue

                        try:
                            event = json.loads(msg_raw)
                        except Exception:
                            continue

                        event_type = event.get('e')
                        if event_type == 'listenKeyExpired':
                            logger.warning("⚠️ Nhận sự kiện listenKeyExpired — tự động tạo lại User Data Stream.")
                            need_uds_backoff = True
                            break
                        if event_type in ('ORDER_TRADE_UPDATE', 'ALGO_UPDATE'):
                            order_data = event.get('o', {})
                            if event_type == 'ALGO_UPDATE' and isinstance(order_data, dict):
                                order_data = dict(order_data)
                                if order_data.get('aid') and order_data.get('ai'):
                                    _ai_k = str(order_data['ai'])
                                    _aid_v = str(order_data['aid'])
                                    with self._lock:
                                        self._actual_to_algo_id[_ai_k] = _aid_v
                                        if len(self._actual_to_algo_id) > 500:
                                            for _dk in list(self._actual_to_algo_id.keys())[:-500]:
                                                self._actual_to_algo_id.pop(_dk, None)
                                if not order_data.get('i') and order_data.get('aid'):
                                    order_data['i'] = order_data.get('aid')
                                if not order_data.get('c') and order_data.get('caid'):
                                    order_data['c'] = order_data.get('caid')
                                _raw_algo_st = str(order_data.get('X') or '').upper()
                                _algo_id_k = str(order_data.get('aid') or order_data.get('caid') or '')
                                try:
                                    _aq_f = float(order_data.get('aq') or order_data.get('z') or 0.0)
                                except (TypeError, ValueError):
                                    _aq_f = 0.0
                                # [BOM #120J + #121J FIX]: Chỉ map ALGO_UPDATE -> FILLED khi FINISHED và aq>0; đẩy terminal REJECTED/EXPIRED/CANCELED ngay!
                                if _raw_algo_st == 'FINISHED' and _aq_f > 0:
                                    _now_algo = time.time()
                                    if _algo_id_k and (_algo_id_k, 'FINISHED') in self._seen_algo_events and (_now_algo - self._seen_algo_events[(_algo_id_k, 'FINISHED')]) < 60.0:
                                        continue
                                    if _algo_id_k:
                                        self._seen_algo_events[(_algo_id_k, 'FINISHED')] = _now_algo
                                        if len(self._seen_algo_events) > 256:
                                            _cut_a = _now_algo - 120.0
                                            self._seen_algo_events = {k: v for k, v in self._seen_algo_events.items() if v >= _cut_a}
                                    order_data['X'] = 'FILLED'
                                elif _raw_algo_st in ('REJECTED', 'EXPIRED', 'CANCELED') or (_raw_algo_st == 'FINISHED' and _aq_f <= 0):
                                    order_data['algo_terminal_status'] = _raw_algo_st
                                order_data['_is_algo_update'] = True
                            elif event_type == 'ORDER_TRADE_UPDATE' and isinstance(order_data, dict):
                                _oid_otu = str(order_data.get('i') or '')
                                if _oid_otu:
                                    with self._lock:
                                        _mapped_aid = self._actual_to_algo_id.get(_oid_otu)
                                    if _mapped_aid:
                                        order_data = dict(order_data)
                                        order_data['algo_id'] = _mapped_aid
                            if self.on_order_update and callable(self.on_order_update):
                                def _dispatch_order_cb(payload_cb):
                                    try:
                                        self.on_order_update(payload_cb)
                                    except Exception as cb_err:
                                        logger.error(f"Lỗi callback on_order_update: {cb_err}")
                                try:
                                    loop = asyncio.get_running_loop()
                                    loop.run_in_executor(self._order_executor, _dispatch_order_cb, dict(order_data) if isinstance(order_data, dict) else order_data)
                                except Exception as ex_cb:
                                    logger.error(f"Lỗi dispatch on_order_update: {ex_cb}")
                if need_uds_backoff and self._is_running:
                    logger.debug(f"User Data Stream tái tạo sau {backoff:.1f}s backoff...")
                    await asyncio.sleep(backoff)
                    backoff = min(30.0, backoff * 1.5)
            except Exception as e:
                if self._is_running:
                    logger.debug(f"User Data Stream ngắt kết nối ({e}); thử lại sau {backoff:.1f}s...")
                    await asyncio.sleep(backoff)
                    backoff = min(30.0, backoff * 1.5)
