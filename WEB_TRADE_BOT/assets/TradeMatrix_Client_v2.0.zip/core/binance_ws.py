"""
BINANCE QUANTUM WEBSOCKET ORCHESTRATOR (DUAL-TIER WEBSOCKET)
============================================================
Module quản lý luồng WebSocket chuyên dụng cho TradeMatrix:
1. TẦNG 2: On-Demand Depth Stream Pool (Sổ lệnh động nấc 20 @ 100ms)
   - Chỉ mở kết nối khi có lệnh M1 Sniper Stalking rình mồi.
   - Gộp nhiều cặp qua luồng Combined Stream duy nhất của Binance:
     wss://fstream.binance.com/stream?streams=btcusdt@depth20@100ms/ethusdt@depth20@100ms
   - Tự động đóng và giải phóng tài nguyên khi hoàn tất rình mồi.
2. TẦNG 3: Binance User Data Stream (Lắng nghe sự kiện tài khoản 24/7)
   - Lấy listenKey qua ccxt.binanceusdm fapiPrivatePostListenKey()
   - Lắng nghe sự kiện ORDER_TRADE_UPDATE để phản xạ 0ms khi khớp SL/TP/Maker.
   - Tự động gửi keepalive PUT request mỗi 30 phút.
3. Fail-Safe:
   - Chạy trên thread riêng biệt với asyncio event loop độc lập.
   - Tự động kết nối lại khi rớt mạng (Exponential Backoff).
   - Tuyệt đối không làm crash bot khi có lỗi ngoại lệ.
"""

import asyncio
import json
import logging
import threading
import time
from typing import Callable, Dict, Optional, Set

try:
    import websockets
except ImportError:
    websockets = None

logger = logging.getLogger("binance_ws")


def clean_stream_symbol(symbol: str) -> str:
    """Chuyển đổi symbol chuẩn (e.g. BTC/USDT:USDT -> btcusdt) cho Binance WebSocket."""
    if not symbol:
        return ""
    clean = symbol.split(':')[0].strip().replace('/', '').lower()
    return clean


def norm_sym_key(symbol: str) -> str:
    """Chuẩn hóa symbol thành key viết hoa không dấu gạch (e.g. BTC/USDT:USDT -> BTCUSDT)."""
    if not symbol:
        return ""
    return symbol.split(':')[0].strip().replace('/', '').upper()


class BinanceWSManager:
    """
    Quản lý luồng WebSocket cho Binance Futures:
    - User Data Stream (Kênh cá nhân báo khớp lệnh 0ms)
    - On-Demand Depth Stream Pool (Sổ lệnh 20 nấc thời gian thực)
    """

    def __init__(
        self,
        exchange_wrapper,
        mode: str = 'live',
        on_order_update: Optional[Callable[[Dict], None]] = None,
        max_depth_streams: int = 3,
    ):
        self.exchange_wrapper = exchange_wrapper
        self.mode = mode.lower() if mode else 'live'
        self.on_order_update = on_order_update
        self.max_depth_streams = max(1, int(max_depth_streams))

        self._lock = threading.Lock()
        self._active_depth_symbols: Set[str] = set()  # Lưu raw symbols
        self._latest_depth: Dict[str, Dict] = {}     # norm_sym -> {'bids': [...], 'asks': [...], 'timestamp': float}

        self._is_running = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        self._listen_key: Optional[str] = None
        self._last_listen_key_keepalive: float = 0.0
        self._streams_need_restart = asyncio.Event() if asyncio else None

    # ==========================================
    # PUBLIC LIFECYCLE API
    # ==========================================

    def start(self):
        """Khởi chạy WebSocket Manager trên thread nền."""
        if websockets is None:
            logger.warning("Thư viện 'websockets' chưa được cài đặt; tắt WebSocket Manager.")
            return

        with self._lock:
            if self._is_running:
                return
            self._is_running = True

        self._thread = threading.Thread(
            target=self._run_event_loop,
            name="binance-ws-orchestrator",
            daemon=True,
        )
        self._thread.start()
        logger.info("📡 Binance Quantum WebSocket Orchestrator đã khởi chạy nền thành công.")

    def stop(self):
        """Dừng WebSocket Manager và đóng các kết nối."""
        with self._lock:
            if not self._is_running:
                return
            self._is_running = False

        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        logger.info("📡 Binance Quantum WebSocket Orchestrator đã dừng.")

    # ==========================================
    # ON-DEMAND DEPTH STREAM POOL (TẦNG 2)
    # ==========================================

    def subscribe_depth(self, symbol: str) -> bool:
        """
        Đăng ký theo dõi Sổ lệnh 20 nấc (Depth 20 @ 100ms) cho 1 cặp tiền.
        Chỉ cho phép tối đa max_depth_streams cặp cùng lúc để bảo vệ tài nguyên.
        """
        if not symbol or websockets is None:
            return False

        with self._lock:
            if len(self._active_depth_symbols) >= self.max_depth_streams and symbol not in self._active_depth_symbols:
                logger.warning(
                    f"⚠️ Depth Pool đã đầy ({len(self._active_depth_symbols)}/{self.max_depth_streams}). "
                    f"Từ chối mở thêm WebSocket cho {symbol}."
                )
                return False
            self._active_depth_symbols.add(symbol)

        logger.info(f"🎯 [DEPTH WS] Đã đăng ký luồng sổ lệnh 100ms cho {symbol} (Pool: {len(self._active_depth_symbols)}/{self.max_depth_streams}).")
        self._notify_streams_changed()
        return True

    def unsubscribe_depth(self, symbol: str):
        """Hủy đăng ký và giải phóng slot trong Depth Pool."""
        if not symbol:
            return

        with self._lock:
            if symbol in self._active_depth_symbols:
                self._active_depth_symbols.remove(symbol)
                clean_k = norm_sym_key(symbol)
                self._latest_depth.pop(clean_k, None)
                logger.info(f"🏁 [DEPTH WS] Đã hủy luồng sổ lệnh cho {symbol} (Pool còn: {len(self._active_depth_symbols)}/{self.max_depth_streams}).")

        self._notify_streams_changed()

    def sync_active_depth_symbols(self, active_symbols: Set[str]):
        """
        Tự động đồng bộ và dọn dẹp các stream không còn nằm trong hàng đợi rình mồi.
        Đảm bảo không bao giờ bị rò rỉ tài nguyên (Self-Healing Pool).
        """
        if active_symbols is None:
            active_symbols = set()

        changed = False
        with self._lock:
            current_symbols = set(self._active_depth_symbols)
            to_remove = current_symbols - set(active_symbols)
            for s in to_remove:
                self._active_depth_symbols.remove(s)
                clean_k = norm_sym_key(s)
                self._latest_depth.pop(clean_k, None)
                changed = True
            if changed:
                logger.info(f"🔄 [DEPTH WS SYNC] Đã thu hồi {len(to_remove)} luồng thừa. Pool hiện tại: {len(self._active_depth_symbols)}/{self.max_depth_streams}.")

        if changed:
            self._notify_streams_changed()

    def get_live_depth(self, symbol: str, max_age_seconds: float = 1.5) -> Optional[Dict]:
        """
        Lấy ảnh chụp sổ lệnh 20 nấc thời gian thực từ WebSocket cache.
        Nếu dữ liệu còn tươi (< max_age_seconds), trả về {'bids': [...], 'asks': [...]}.
        Nếu không có hoặc dữ liệu quá cũ, trả về None (để fallback an toàn sang REST API).
        """
        clean_k = norm_sym_key(symbol)
        with self._lock:
            item = self._latest_depth.get(clean_k)
            if not item:
                return None
            age = time.time() - item.get('timestamp', 0.0)
            if age <= max_age_seconds:
                return {
                    'bids': item['bids'],
                    'asks': item['asks'],
                    'timestamp': item['timestamp'],
                    'source': 'websocket_live',
                }
        return None

    def _notify_streams_changed(self):
        """Báo cho async loop biết danh sách stream đã thay đổi để tái kết nối luồng gộp."""
        if self._loop and self._loop.is_running() and self._streams_need_restart:
            self._loop.call_soon_threadsafe(self._streams_need_restart.set)

    # ==========================================
    # ASYNCIO WORKER CORE
    # ==========================================

    def _run_event_loop(self):
        """Chạy asyncio event loop trên thread riêng."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._streams_need_restart = asyncio.Event()

        try:
            self._loop.run_until_complete(self._main_worker())
        except Exception as e:
            logger.debug(f"[BinanceWS] Event loop kết thúc: {e}")
        finally:
            self._cleanup_loop()

    def _cleanup_loop(self):
        """Dọn dẹp các task còn sót lại khi loop kết thúc."""
        if not self._loop:
            return
        try:
            pending = asyncio.all_tasks(self._loop)
            for task in pending:
                task.cancel()
            self._loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            self._loop.close()
        except Exception:
            pass

    async def _main_worker(self):
        """Worker chính quản lý song song User Data Stream và Depth Pool."""
        tasks = [
            asyncio.create_task(self._depth_stream_loop()),
        ]

        # Chỉ kích hoạt User Data Stream ở chế độ LIVE
        if self.mode == 'live':
            tasks.append(asyncio.create_task(self._user_data_stream_loop()))

        try:
            await asyncio.gather(*tasks, return_exceptions=True)
        except asyncio.CancelledError:
            pass

    # ==========================================
    # TẦNG 2: DEPTH STREAM LOOP (COMBINED STREAM)
    # ==========================================

    async def _depth_stream_loop(self):
        """Vòng lặp duy trì kết nối luồng sổ lệnh gộp (Combined Depth Stream)."""
        while self._is_running:
            with self._lock:
                symbols_to_stream = list(self._active_depth_symbols)

            if not symbols_to_stream:
                # Không có cặp nào đang rình mồi, ngủ tiết kiệm tài nguyên
                self._streams_need_restart.clear()
                try:
                    await asyncio.wait_for(self._streams_need_restart.wait(), timeout=2.0)
                except asyncio.TimeoutError:
                    pass
                continue

            # Tạo URL Combined Stream của Binance:
            # wss://fstream.binance.com/stream?streams=btcusdt@depth20@100ms/ethusdt@depth20@100ms
            streams_param = "/".join(f"{clean_stream_symbol(s)}@depth20@100ms" for s in symbols_to_stream if clean_stream_symbol(s))
            if not streams_param:
                await asyncio.sleep(1.0)
                continue

            ws_url = f"wss://fstream.binance.com/stream?streams={streams_param}"
            self._streams_need_restart.clear()

            try:
                logger.debug(f"Kết nối Combined Depth WS: {ws_url}")
                async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
                    while self._is_running and not self._streams_need_restart.is_set():
                        try:
                            msg_raw = await asyncio.wait_for(ws.recv(), timeout=2.0)
                        except asyncio.TimeoutError:
                            continue

                        try:
                            msg = json.loads(msg_raw)
                        except Exception:
                            continue

                        # Cấu trúc Combined Stream: {"stream": "btcusdt@depth20@100ms", "data": {"s": "BTCUSDT", "b": [...], "a": [...]}}
                        data = msg.get('data') or msg
                        sym = data.get('s')
                        bids = data.get('b')
                        asks = data.get('a')

                        if sym and bids is not None and asks is not None:
                            now_ts = time.time()
                            norm_k = norm_sym_key(sym)
                            with self._lock:
                                self._latest_depth[norm_k] = {
                                    'bids': bids,
                                    'asks': asks,
                                    'timestamp': now_ts,
                                }
            except Exception as e:
                if self._is_running:
                    logger.debug(f"Kết nối Depth WS gián đoạn ({e}); tự động kết nối lại sau 2s...")
                    await asyncio.sleep(2.0)

    # ==========================================
    # TẦNG 3: USER DATA STREAM LOOP
    # ==========================================

    def _get_listen_key(self) -> Optional[str]:
        """Tạo listenKey mới từ sàn Binance qua ccxt."""
        try:
            raw_ex = getattr(self.exchange_wrapper, 'exchange', None)
            if raw_ex and hasattr(raw_ex, 'fapiPrivatePostListenKey'):
                res = raw_ex.fapiPrivatePostListenKey()
                if isinstance(res, dict) and res.get('listenKey'):
                    return res['listenKey']
        except Exception as e:
            logger.debug(f"Không thể tạo listenKey từ Binance: {e}")
        return None

    def _keepalive_listen_key(self, listen_key: str):
        """Gửi keepalive PUT để gia hạn listenKey mỗi 30 phút."""
        try:
            raw_ex = getattr(self.exchange_wrapper, 'exchange', None)
            if raw_ex and hasattr(raw_ex, 'fapiPrivatePutListenKey'):
                raw_ex.fapiPrivatePutListenKey({'listenKey': listen_key})
                self._last_listen_key_keepalive = time.time()
                logger.debug("Đã gửi keepalive listenKey thành công.")
        except Exception as e:
            logger.debug(f"Lỗi gửi keepalive listenKey: {e}")

    async def _user_data_stream_loop(self):
        """Vòng lặp duy trì kết nối User Data Stream để bắt sự kiện khớp lệnh 0ms."""
        backoff = 2.0
        while self._is_running:
            listen_key = self._get_listen_key()
            if not listen_key:
                logger.debug("Chưa có listenKey; thử lại sau 15s...")
                await asyncio.sleep(15.0)
                continue

            self._listen_key = listen_key
            self._last_listen_key_keepalive = time.time()
            ws_url = f"wss://fstream.binance.com/ws/{listen_key}"

            try:
                logger.info("📡 Đã kết nối thành công Binance User Data Stream WebSocket (0ms Fill Reaction).")
                backoff = 2.0
                async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10) as ws:
                    while self._is_running:
                        # Kiểm tra gia hạn listenKey mỗi 30 phút (1800s)
                        if time.time() - self._last_listen_key_keepalive >= 1800:
                            self._keepalive_listen_key(listen_key)

                        try:
                            msg_raw = await asyncio.wait_for(ws.recv(), timeout=2.0)
                        except asyncio.TimeoutError:
                            continue

                        try:
                            event = json.loads(msg_raw)
                        except Exception:
                            continue

                        event_type = event.get('e')
                        if event_type == 'ORDER_TRADE_UPDATE':
                            order_data = event.get('o', {})
                            if self.on_order_update and callable(self.on_order_update):
                                try:
                                    self.on_order_update(order_data)
                                except Exception as cb_err:
                                    logger.error(f"Lỗi callback on_order_update: {cb_err}")
            except Exception as e:
                if self._is_running:
                    logger.debug(f"User Data Stream ngắt kết nối ({e}); thử lại sau {backoff:.1f}s...")
                    await asyncio.sleep(backoff)
                    backoff = min(60.0, backoff * 1.5)
