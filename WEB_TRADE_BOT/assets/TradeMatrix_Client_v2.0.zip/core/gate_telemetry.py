import json
import os
import threading
import time
from collections import Counter, deque

_LOCK = threading.Lock()
_EVENTS = deque(maxlen=300)
_COUNTS = Counter()
_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'gate_events.json')

_RADAR_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'radar_candidates.json')
_RADAR_CANDIDATES = {}

def _load_persisted_radar():
    """Tự động nạp bộ nhớ đệm radar từ file nếu có."""
    global _RADAR_CANDIDATES
    try:
        if os.path.exists(_RADAR_PATH):
            with open(_RADAR_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
                now = time.time()
                # Chỉ nạp lại các cặp còn tươi trong cửa sổ 5 phút.
                _RADAR_CANDIDATES = {
                    k: v for k, v in data.items()
                    if isinstance(v, dict) and (now - v.get('last_seen_ts', 0) < 300)
                }
    except Exception:
        _RADAR_CANDIDATES = {}

# Khởi tạo nạp dữ liệu cũ
_load_persisted_radar()

def record_gate_event(gate: str, symbol: str, side: str = '', reason: str = '', meta: dict = None):
    """
    Ghi nhận sự kiện chốt chặn (Pre-Trade Gate / JEV Chop Veto) một cách an toàn và thread-safe.
    Lưu bộ đệm 300 sự kiện gần nhất và xuất ra file JSON để Dashboard Web hiển thị trực quan.
    """
    ev = {
        'ts': int(time.time()),
        'datetime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
        'gate': str(gate),
        'symbol': str(symbol),
        'side': str(side),
        'reason': str(reason)[:300],
        'meta': meta or {}
    }
    with _LOCK:
        _EVENTS.append(ev)
        _COUNTS[gate] += 1
        try:
            os.makedirs(os.path.dirname(_PATH), exist_ok=True)
            tmp = _PATH + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({
                    'counts': dict(_COUNTS),
                    'total_blocked': len(_EVENTS),
                    'last_updated': int(time.time()),
                    'events': list(_EVENTS)[-100:]
                }, f, ensure_ascii=False, indent=2, default=str)
            os.replace(tmp, _PATH)
        except Exception:
            pass

def record_radar_candidate(
    symbol: str,
    side: str,
    confidence: float,
    score: float = 0.0,
    strategies_agreed: str = '',
    dynamic_leverage: int = None,
    bottleneck_gate: str = '',
    bottleneck_reason: str = '',
    readiness_pct: float = 80.0,
    meta: dict = None
):
    """
    Ghi nhận hoặc cập nhật ứng viên Ra-đa Rình Mồi (Radar Stalking Leaderboard).
    Tự động tích lũy số lần quét lọt tầm ngắm (hit_count) và khung thời gian xuất hiện.
    """
    now = time.time()
    clean_sym = str(symbol or '').split(':')[0].strip().upper()
    side_str = str(side).strip().upper()
    if side_str in ('BUY', 'LONG'):
        side_clean = 'LONG'
    else:
        side_clean = 'SHORT'

    conf_pct = round(float(confidence) * 100.0, 1) if confidence <= 1.0 else round(float(confidence), 1)
    readiness = max(10.0, min(99.0, round(float(readiness_pct), 1)))

    with _LOCK:
        existing = _RADAR_CANDIDATES.get(clean_sym)
        if existing and (now - existing.get('last_seen_ts', 0) < 300) and existing.get('side') == side_clean:
            # Cùng một đợt rình mồi: tăng số lần xém vào
            hit_count = existing.get('hit_count', 1) + 1
            first_seen_ts = existing.get('first_seen_ts', now)
        else:
            hit_count = 1
            first_seen_ts = now

        first_seen_str = time.strftime('%H:%M', time.localtime(first_seen_ts))
        last_seen_str = time.strftime('%H:%M', time.localtime(now))
        time_window = f"{first_seen_str} - {last_seen_str}" if first_seen_str != last_seen_str else last_seen_str

        cand = {
            'symbol': clean_sym,
            'side': side_clean,
            'confidence_pct': conf_pct,
            'score': round(float(score), 4),
            'strategies_agreed': str(strategies_agreed or '2/2 Chiến lược'),
            'dynamic_leverage': f"{int(dynamic_leverage)}x" if dynamic_leverage not in (None, '', 0) else None,
            'bottleneck_gate': str(bottleneck_gate or 'PRE_TRADE_GATE'),
            'bottleneck_reason': str(bottleneck_reason or 'Đang kiểm tra ngưỡng an toàn')[:250],
            'readiness_pct': readiness,
            'hit_count': hit_count,
            'first_seen_ts': int(first_seen_ts),
            'last_seen_ts': int(now),
            'last_seen_str': time.strftime('%H:%M:%S', time.localtime(now)),
            'time_window_str': time_window,
            'meta': meta or {}
        }
        _RADAR_CANDIDATES[clean_sym] = cand

        try:
            os.makedirs(os.path.dirname(_RADAR_PATH), exist_ok=True)
            tmp_radar = _RADAR_PATH + '.tmp'
            with open(tmp_radar, 'w', encoding='utf-8') as f:
                json.dump(_RADAR_CANDIDATES, f, ensure_ascii=False, indent=2, default=str)
            os.replace(tmp_radar, _RADAR_PATH)
        except Exception:
            pass

def clear_radar_candidate(symbol: str):
    """
    Xóa ứng viên khỏi danh sách rình mồi khi vị thế đã chính thức được mở hoặc bị hủy.
    """
    clean_sym = str(symbol or '').split(':')[0].strip().upper()
    with _LOCK:
        if clean_sym in _RADAR_CANDIDATES:
            _RADAR_CANDIDATES.pop(clean_sym, None)
            try:
                tmp_radar = _RADAR_PATH + '.tmp'
                with open(tmp_radar, 'w', encoding='utf-8') as f:
                    json.dump(_RADAR_CANDIDATES, f, ensure_ascii=False, indent=2, default=str)
                os.replace(tmp_radar, _RADAR_PATH)
            except Exception:
                pass

def get_top_radar_candidates(limit: int = 4, max_age_seconds: int = 300) -> list:
    """
    Trả về Top N ứng viên còn tươi, ưu tiên trạng thái có thể hành động trước điểm theo dõi.
    Đảm bảo 100% không trùng lặp symbol.
    """
    now = time.time()
    badges = ['🥇 #1', '🥈 #2', '🥉 #3', '🎖️ #4', '🎯 #5', '🎯 #6']
    with _LOCK:
        active = []
        for sym, c in list(_RADAR_CANDIDATES.items()):
            age = now - c.get('last_seen_ts', 0)
            if age <= max_age_seconds:
                active.append(dict(c))
            else:
                _RADAR_CANDIDATES.pop(sym, None)

        # Deduplication tuyệt đối theo symbol chuẩn hóa
        seen_symbols = set()
        unique_active = []
        for item in active:
            base_sym = str(item.get('symbol', '')).split(':')[0].strip().upper()
            if not base_sym or base_sym in seen_symbols:
                continue
            seen_symbols.add(base_sym)
            gate = str(item.get('bottleneck_gate', '')).upper()
            if gate == 'M1_SNIPER_STALKING':
                item['radar_status'] = 'STALKING'
                status_rank = 3
            elif gate in ('SLOT_CAPACITY', 'RISK_CAPACITY', 'MARGIN_CAPACITY'):
                item['radar_status'] = 'WAITING_RESOURCE'
                status_rank = 2
            else:
                item['radar_status'] = 'BLOCKED'
                status_rank = 0
            item['_status_rank'] = status_rank
            unique_active.append(item)

        unique_active.sort(key=lambda x: (
            int(x.pop('_status_rank', 0)),
            float(x.get('readiness_pct', 0)),
            float(x.get('confidence_pct', 0)),
            int(x.get('hit_count', 1)),
            float(x.get('last_seen_ts', 0)),
        ), reverse=True)

        top_list = unique_active[:limit]

        for i, item in enumerate(top_list):
            item['rank_badge'] = badges[i] if i < len(badges) else f"#{i+1}"
            item['rank_num'] = i + 1

        return top_list

def get_gate_summary() -> dict:
    # Lấy radar trước khi giữ lock để tránh tái chiếm non-reentrant Lock trong cùng thread.
    top_radar = get_top_radar_candidates(4)
    with _LOCK:
        return {
            'counts': dict(_COUNTS),
            'recent_events': list(_EVENTS)[-20:],
            'top_radar': top_radar
        }

_PHASE2_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'phase2_last_candidates.json')
_PHASE2_CANDIDATES = deque(maxlen=60)

def record_phase2_candidate(entry: dict):
    """
    Lưu vết kết quả thẩm định ứng viên Pha 2 thời gian thực.
    Xuất ra file data/phase2_last_candidates.json để Web/Model AI khác đọc trực tiếp 0ms.
    """
    if not isinstance(entry, dict):
        return
    with _LOCK:
        item = dict(entry)
        item['ts'] = int(time.time())
        item['datetime'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        _PHASE2_CANDIDATES.append(item)
        try:
            os.makedirs(os.path.dirname(_PHASE2_PATH), exist_ok=True)
            tmp = _PHASE2_PATH + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_updated': int(time.time()),
                    'datetime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
                    'total_tracked': len(_PHASE2_CANDIDATES),
                    'candidates': list(_PHASE2_CANDIDATES)[-30:],
                }, f, ensure_ascii=False, indent=2, default=str)
            os.replace(tmp, _PHASE2_PATH)
        except Exception:
            pass
