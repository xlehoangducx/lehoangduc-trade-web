"""
TRADEMATRIX V6.1 - QUANT EVOLUTION, LIFECYCLE & ADAPTIVE TUNING ENGINE (SSOT)
==============================================================================
100% Offline (PRAGMA query_only=ON, 0 Binance REST calls).
Tich hop 4 Tru cot Chuan Quy da kiem chung tren 750 Shadow + 461 Live Trades:
  1. Auto-Discovery LAB + Tu Toi Uu 20 Thau Kinh Tieng Viet (Bailey & Lopez de Prado DSR + OOS 70/30)
     + Bang Rieng 'KHONG DAT / CAM THANG HANG' (config/lab_registry.json).
  2. Quan Tri Vong Doi Vu Khi 2 Chieu (LAB <-> THU NGHIEM <-> CHINH THUC <-> TAM TAT / XOA MEM)
     + Vu Khi Dong DYN-VK11..14 gan tron Khop Noi 8 Tram & Cong Thuc M1 CKS (config/weapon_lifecycle.json).
  3. Bo Nho Kep 'UU TIEN' (So Kep Lich Su vinh vien + Ham Mu Ban Ra 6h/12h/24h + Bayes alpha0=4).
  4. Trung Tam Tinh Chinh 4 Phan Lop Tai San (ALTCOIN / MAJOR / TRADFI_1X / TRADFI_ETF_3X)
     + TP1..TP5 Tu Gop Lat >= $6.5 + Auto Hoa Tron Bayes Weighted Median Kep Bien Hien Phap
     + Nut Khoi Phuc Mac Dinh (config/position_tuning.json).
"""

import copy
import json
import logging
import math
import os
import shutil
import sqlite3
import threading
import time
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

from core.scanner import MarketScanner

logger = logging.getLogger(__name__)

_ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_CONFIG_DIR = os.path.join(_ROOT_DIR, "config")
_HIST_DIR = os.path.join(_ROOT_DIR, "data", "historical")
LAB_REGISTRY_PATH = os.path.join(_CONFIG_DIR, "lab_registry.json")
WEAPON_LIFECYCLE_PATH = os.path.join(_CONFIG_DIR, "weapon_lifecycle.json")
POSITION_TUNING_PATH = os.path.join(_CONFIG_DIR, "position_tuning.json")

_ENGINE_LOCK = threading.RLock()
_LAB_OPT_CACHE: Dict[str, Any] = {"ts": 0.0, "db_path": "", "data": None}
_ADVISOR_CACHE: Dict[str, Any] = {"ts": 0.0, "db_path": "", "data": None}
_LAB_HIST_INDEX_CACHE: Dict[str, Any] = {"ts": 0.0, "map": {}}
_LAB_CSV_ARRAY_CACHE: Dict[str, Tuple[float, Optional[Dict[str, Any]]]] = {}

MAX_TOTAL_WEAPONS_CAP = 14  # Chong Overfitting danh muc (10 core + toi da 4 dong)

# ==============================================================================
# 1. BIEN AN TOAN HIEN PHAP & CAU HINH MAC DINH CHO 4 PHAN LOP TAI SAN
# ==============================================================================
CONSTITUTION_BOUNDS: Dict[str, Dict[str, float]] = {
    "ALTCOIN": {
        "sl_min": 1.50, "sl_max": 3.50, "be_min": 0.85, "be_max": 1.60,
        "max_lev": 5.0, "max_notional_pct": 0.40, "half_life_h": 6.0, "atr_mult": 1.50,
        "risk_min": 0.15, "risk_max": 1.00,
    },
    "MAJOR": {
        "sl_min": 1.00, "sl_max": 2.20, "be_min": 0.85, "be_max": 1.40,
        "max_lev": 5.0, "max_notional_pct": 0.40, "half_life_h": 12.0, "atr_mult": 1.25,
        "risk_min": 0.15, "risk_max": 1.00,
    },
    "TRADFI_1X": {
        "sl_min": 1.00, "sl_max": 1.80, "be_min": 0.85, "be_max": 1.30,
        "max_lev": 4.0, "max_notional_pct": 0.40, "half_life_h": 24.0, "atr_mult": 1.25,
        "risk_min": 0.15, "risk_max": 1.00,
    },
    "TRADFI_ETF_3X": {
        "sl_min": 1.80, "sl_max": 3.50, "be_min": 1.70, "be_max": 2.80,
        "max_lev": 2.0, "max_notional_pct": 0.30, "half_life_h": 24.0, "atr_mult": 1.30,
        "risk_min": 0.15, "risk_max": 1.00,
    },
}

ASSET_SUBCLASS_LABELS_VI: Dict[str, str] = {
    "ALTCOIN": "Altcoin (Crypto 24/7)",
    "MAJOR": "Major (BTC/ETH/SOL/BNB)",
    "TRADFI_1X": "TradFi 1x (Dầu, Vàng, Cổ phiếu)",
    "TRADFI_ETF_3X": "TradFi ETF 2x/3x (SOXL, TQQQ...)",
}

# [BOM #120A FIX]: Đồng bộ mốc chuẩn 1.0x bằng đúng sl_default_pct mặc định (triệt tiêu lỗi tự động bơm SL +13.64% khi auto_bayes_enabled=false!)
SL_ATR_BASE_REFERENCE: Dict[str, float] = {
    "ALTCOIN": 2.50,
    "MAJOR": 1.70,
    "TRADFI_1X": 1.40,
    "TRADFI_ETF_3X": 2.75,
}

DEFAULT_POSITION_TUNING: Dict[str, Any] = {
    "version": "V6.4",
    "global": {
        "soft_dd_enabled": True,
        "soft_dd_tier1_pct": 5.0,
        "soft_dd_tier1_mult": 0.70,
        "soft_dd_tier2_pct": 8.0,
        "soft_dd_tier2_mult": 0.40,
        "liquidity_impact_max_vol_ratio": 0.0015,
        "min_tp_slice_usd": 6.5,
        "liquidation_sl_multiple": 4.0,
        "hot_reload_new_positions_only": True,
    },
    "classes": {
        "ALTCOIN": {
            "base_risk_pct": 0.35,
            "sl_min_pct": 1.50,
            "sl_max_pct": 3.50,
            "sl_default_pct": 2.50,
            "breathing_atr_mult": 0.45,
            "cushion_trigger_pct": 0.80,
            "be_trigger_pct": 0.85,
            "mfe_ratchet_peak_pct": 0.50,
            "mfe_ratchet_retrace_pct": 0.25,
            "max_leverage": 5,
            "max_notional_pct": 20.0,
            "auto_bayes_enabled": False,
            "shrinkage_k": 8.0,
            "half_life_hours": 6.0,
            "tp1_take_pct": 50,
            "tp_stages": [
                {"name": "TP1", "pct": 1.35, "weight_pct": 50, "enabled": True},
                {"name": "TP2", "pct": 2.40, "weight_pct": 25, "enabled": True},
                {"name": "TP3", "pct": 3.80, "weight_pct": 10, "enabled": True},
                {"name": "TP4", "pct": 5.50, "weight_pct": 10, "enabled": True},
                {"name": "TP5", "pct": 7.50, "weight_pct": 5, "enabled": True},
            ],
        },
        "MAJOR": {
            "base_risk_pct": 0.35,
            "sl_min_pct": 1.00,
            "sl_max_pct": 2.20,
            "sl_default_pct": 1.70,
            "breathing_atr_mult": 0.45,
            "cushion_trigger_pct": 0.75,
            "be_trigger_pct": 0.90,
            "mfe_ratchet_peak_pct": 0.50,
            "mfe_ratchet_retrace_pct": 0.25,
            "max_leverage": 5,
            "max_notional_pct": 25.0,
            "auto_bayes_enabled": False,
            "shrinkage_k": 8.0,
            "half_life_hours": 12.0,
            "tp1_take_pct": 50,
            "tp_stages": [
                {"name": "TP1", "pct": 1.05, "weight_pct": 50, "enabled": True},
                {"name": "TP2", "pct": 1.80, "weight_pct": 25, "enabled": True},
                {"name": "TP3", "pct": 2.60, "weight_pct": 10, "enabled": True},
                {"name": "TP4", "pct": 3.60, "weight_pct": 10, "enabled": True},
                {"name": "TP5", "pct": 5.00, "weight_pct": 5, "enabled": True},
            ],
        },
        "TRADFI_1X": {
            "base_risk_pct": 0.35,
            "sl_min_pct": 1.00,
            "sl_max_pct": 1.80,
            "sl_default_pct": 1.40,
            "breathing_atr_mult": 0.45,
            "cushion_trigger_pct": 0.65,
            "be_trigger_pct": 0.85,
            "mfe_ratchet_peak_pct": 0.50,
            "mfe_ratchet_retrace_pct": 0.25,
            "max_leverage": 4,
            "max_notional_pct": 20.0,
            "auto_bayes_enabled": False,
            "shrinkage_k": 8.0,
            "half_life_hours": 24.0,
            "tp1_take_pct": 30,
            "tp_stages": [
                {"name": "TP1", "pct": 0.95, "weight_pct": 30, "enabled": True},
                {"name": "TP2", "pct": 1.60, "weight_pct": 35, "enabled": True},
                {"name": "TP3", "pct": 2.40, "weight_pct": 15, "enabled": True},
                {"name": "TP4", "pct": 3.40, "weight_pct": 10, "enabled": True},
                {"name": "TP5", "pct": 4.80, "weight_pct": 10, "enabled": True},
            ],
        },
        "TRADFI_ETF_3X": {
            "base_risk_pct": 0.30,
            "sl_min_pct": 1.80,
            "sl_max_pct": 3.50,
            "sl_default_pct": 2.75,
            "breathing_atr_mult": 0.45,
            "cushion_trigger_pct": 0.80,
            "be_trigger_pct": 1.80,
            "mfe_ratchet_peak_pct": 0.50,
            "mfe_ratchet_retrace_pct": 0.25,
            "max_leverage": 2,
            "max_notional_pct": 15.0,
            "auto_bayes_enabled": False,
            "shrinkage_k": 8.0,
            "half_life_hours": 24.0,
            "tp1_take_pct": 50,
            "tp_stages": [
                {"name": "TP1", "pct": 2.30, "weight_pct": 50, "enabled": True},
                {"name": "TP2", "pct": 3.80, "weight_pct": 25, "enabled": True},
                {"name": "TP3", "pct": 5.20, "weight_pct": 10, "enabled": True},
                {"name": "TP4", "pct": 6.80, "weight_pct": 10, "enabled": True},
                {"name": "TP5", "pct": 8.50, "weight_pct": 5, "enabled": True},
            ],
        },
    },
}


def _atomic_write_json(path: str, payload: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp_path = f"{path}.{os.getpid()}.{threading.get_ident()}_{int(time.time() * 1000)}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    if os.path.exists(path):
        try:
            shutil.copy2(path, f"{path}.bak")
        except Exception:
            pass
    os.replace(tmp_path, path)


def _safe_read_json(path: str, default_factory, raise_on_error: bool = False) -> Dict[str, Any]:
    if not os.path.exists(path):
        bak_path = f"{path}.bak"
        if os.path.exists(bak_path):
            try:
                with open(bak_path, "r", encoding="utf-8") as bf:
                    bak_obj = json.load(bf)
                if isinstance(bak_obj, dict):
                    logger.warning("Phục hồi %s từ bản sao lưu .bak do tệp chính vắng mặt.", path)
                    return bak_obj
            except Exception:
                pass
        data = default_factory()
        try:
            _atomic_write_json(path, data)
        except Exception as e:
            if raise_on_error:
                raise
            logger.warning("Không khởi tạo được %s (%s), dùng mặc định tạm.", path, e)
        return data

    last_err: Optional[Exception] = None
    for attempt in range(3):
        try:
            with open(path, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if isinstance(obj, dict):
                return obj
            last_err = ValueError(f"JSON root in {path} is {type(obj).__name__}, expected dict")
            break
        except (OSError, json.JSONDecodeError, ValueError) as e:
            last_err = e
            if attempt < 2:
                time.sleep(0.05)

    if not raise_on_error:
        bak_path = f"{path}.bak"
        if os.path.exists(bak_path):
            try:
                with open(bak_path, "r", encoding="utf-8") as bf:
                    bak_obj = json.load(bf)
                if isinstance(bak_obj, dict):
                    logger.warning("Đọc %s lỗi (%s); dùng bản sao lưu .bak.", path, last_err)
                    return bak_obj
            except Exception:
                pass
        logger.warning("Không đọc được %s (%s), dùng mặc định an toàn.", path, last_err)
        return default_factory()

    if last_err is not None:
        raise last_err
    raise ValueError(f"Failed to read valid JSON dict from {path}")


def classify_asset_subclass(symbol: str, exchange: Any = None) -> str:
    sym_u = str(symbol or "").split(":")[0].strip().upper()
    if "/" not in sym_u and sym_u.endswith("USDT"):
        sym_u = sym_u[:-4] + "/USDT"
    base = sym_u.split("/")[0]
    if base in ("BTC", "ETH", "SOL", "BNB", "XRP"):
        return "MAJOR"
    if MarketScanner.is_tradfi_symbol(sym_u, exchange) or MarketScanner.is_tradfi_stock(sym_u, exchange) or MarketScanner.is_tradfi_commodity(sym_u, exchange):
        if MarketScanner.is_leveraged_etf(sym_u):
            return "TRADFI_ETF_3X"
        return "TRADFI_1X"
    return "ALTCOIN"


def _normalize_shadow_row_asset_subclass(symbol: str, db_ac: Any, exchange: Any = None) -> str:
    """[BOM #108C FIX]: Chuan hoa 4 phan lop (ALTCOIN / MAJOR / TRADFI_1X / TRADFI_ETF_3X) cho dong Shadow:
    - Chi base in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP') moi la MAJOR (sua ETHFIUSDT tung bi startswith('ETH') gan nham MAJOR!).
    - Neu DB da xac nhan ac == 'ALTCOIN' tu live exchange (vd ONUSDT la Orochi Network 0.11$), giu nguyen ALTCOIN (khong tron vao TRADFI_1X!)."""
    sym_u = str(symbol or "").split(":")[0].strip().upper()
    if "/" not in sym_u and sym_u.endswith("USDT"):
        sym_u = sym_u[:-4] + "/USDT"
    base = sym_u.split("/")[0]
    if base in ("BTC", "ETH", "SOL", "BNB", "XRP"):
        return "MAJOR"
    ac_u = str(db_ac or "").strip().upper()
    if ac_u == "ALTCOIN":
        return "ALTCOIN"
    cls_k = classify_asset_subclass(sym_u, exchange=exchange)
    if cls_k in ("TRADFI_1X", "TRADFI_ETF_3X"):
        return cls_k
    if "TRADFI" in ac_u:
        return "TRADFI_ETF_3X" if MarketScanner.is_leveraged_etf(sym_u) else "TRADFI_1X"
    return "ALTCOIN"


def compute_weapon_half_life_hours(asset_class_target: str) -> float:
    ac = str(asset_class_target or "ALTCOIN").upper()
    if ac in ("TRADFI", "TRADFI_1X", "TRADFI_ETF_3X"):
        return 24.0
    if ac == "MAJOR":
        return 12.0
    return 6.0


def bayes_shrunk_win_rate(weighted_wins: float, weighted_total: float, prior_alpha: float = 4.0) -> float:
    """
    [SUITE 3 QUAN QUAN T-KB08]: Cong thuc Thu Hoi Bayes Beta-Binomial (alpha0 = beta0 = 4.0).
    - Nho mau (6 thang): 71.4% (chong phong dai ao 100%).
    - Cup dien 24h (N_eff -> 0.37): 52.2% (tu truot em ve Trung lap 50%, khong co vach da cung!).
    """
    denom = float(weighted_total) + 2.0 * float(prior_alpha)
    if denom <= 0:
        return 50.0
    return round(((float(weighted_wins) + float(prior_alpha)) / denom) * 100.0, 1)


def weighted_median(vals_weights: List[Tuple[float, float]]) -> Optional[float]:
    if not vals_weights:
        return None
    s = sorted(vals_weights, key=lambda x: x[0])
    tot = sum(w for _, w in s)
    if tot <= 0:
        return s[len(s) // 2][0]
    acc = 0.0
    half = tot * 0.5
    for v, w in s:
        acc += w
        if acc >= half:
            return v
    return s[-1][0]


# ==============================================================================
# 2. QUAN LY CAU HINH TINH CHINH VI THE 4 PHAN LOP + TP1..TP5 + AUTO BAYES
# ==============================================================================
def _safe_num(val: Any, fallback: float) -> float:
    try:
        if val is None or val == "":
            return float(fallback)
        v = float(val)
        return v if math.isfinite(v) else float(fallback)
    except (TypeError, ValueError):
        return float(fallback)


def _clamp_class_tuning(cls_key: str, raw: Dict[str, Any]) -> Dict[str, Any]:
    """Kep cung moi thong so trong Bien An Toan Hien Phap (cam xoa moc BE +0.85%, cam SL ngoai bien, chong crash None/NaN)."""
    b = CONSTITUTION_BOUNDS[cls_key]
    base = copy.deepcopy(DEFAULT_POSITION_TUNING["classes"][cls_key])
    merged = {**base, **(raw or {})}
    base_risk = round(
        max(
            float(b.get("risk_min", 0.15)),
            min(float(b.get("risk_max", 1.00)), _safe_num(merged.get("base_risk_pct"), base.get("base_risk_pct", 0.35))),
        ),
        2,
    )
    sl_min = round(max(b["sl_min"], min(b["sl_max"], _safe_num(merged.get("sl_min_pct"), base["sl_min_pct"]))), 2)
    sl_max = round(max(sl_min, min(b["sl_max"], _safe_num(merged.get("sl_max_pct"), base["sl_max_pct"]))), 2)
    sl_def = round(max(sl_min, min(sl_max, _safe_num(merged.get("sl_default_pct"), base["sl_default_pct"]))), 2)
    be_trig = round(max(b["be_min"], min(b["be_max"], _safe_num(merged.get("be_trigger_pct"), base["be_trigger_pct"]))), 2)
    cush = round(max(0.55, min(be_trig, _safe_num(merged.get("cushion_trigger_pct"), base["cushion_trigger_pct"]))), 2)
    breath = round(max(0.45, min(1.20, _safe_num(merged.get("breathing_atr_mult"), base["breathing_atr_mult"]))), 2)
    rat_peak = round(max(0.45, min(1.20, _safe_num(merged.get("mfe_ratchet_peak_pct"), base["mfe_ratchet_peak_pct"]))), 2)
    rat_ret = round(max(0.20, min(0.60, _safe_num(merged.get("mfe_ratchet_retrace_pct"), base["mfe_ratchet_retrace_pct"]))), 2)
    max_lev = int(max(1, min(int(b["max_lev"]), int(round(_safe_num(merged.get("max_leverage"), base["max_leverage"]))))))
    max_not = round(max(5.0, min(b["max_notional_pct"] * 100.0, _safe_num(merged.get("max_notional_pct"), base["max_notional_pct"]))), 1)
    shrink_k = round(max(4.0, min(40.0, _safe_num(merged.get("shrinkage_k"), base["shrinkage_k"]))), 1)
    hl_h = round(max(3.0, min(48.0, _safe_num(merged.get("half_life_hours"), base["half_life_hours"]))), 1)

    raw_stages = merged.get("tp_stages") or base["tp_stages"]
    clean_stages = []
    for i, st in enumerate(raw_stages[:5]):
        pct_v = round(max(0.85, min(15.0, _safe_num(st.get("pct"), base["tp_stages"][i]["pct"]))), 2)
        wt_v = round(max(5.0, min(100.0, _safe_num(st.get("weight_pct"), base["tp_stages"][i]["weight_pct"]))), 1)
        clean_stages.append({
            "name": f"TP{i + 1}",
            "pct": pct_v,
            "weight_pct": wt_v,
            "enabled": bool(st.get("enabled", True)),
        })
    # Bao dam TP tang dan va TP1 luon la mo neo bat buoc (BOM #121F FIX)
    clean_stages.sort(key=lambda x: x["pct"])
    for i, st in enumerate(clean_stages):
        st["name"] = f"TP{i + 1}"
    if clean_stages:
        clean_stages[0]["enabled"] = True

    raw_tp1_take = int(round(_safe_num(merged.get("tp1_take_pct"), base.get("tp1_take_pct", 50))))
    # [V6.4 BOM #104]: Tinh gon con DUNG 3 che do tot nhat (50%, 30%, 0%); tu dong chuyen 25->30, 100->50 (xoa dead modes!)
    if raw_tp1_take == 25:
        raw_tp1_take = 30
    elif raw_tp1_take not in (0, 30, 50):
        raw_tp1_take = 50

    return {
        "base_risk_pct": base_risk,
        "sl_min_pct": sl_min,
        "sl_max_pct": sl_max,
        "sl_default_pct": sl_def,
        "breathing_atr_mult": breath,
        "cushion_trigger_pct": cush,
        "be_trigger_pct": be_trig,
        "mfe_ratchet_peak_pct": rat_peak,
        "mfe_ratchet_retrace_pct": rat_ret,
        "max_leverage": max_lev,
        "max_notional_pct": max_not,
        "auto_bayes_enabled": bool(merged.get("auto_bayes_enabled", False)),
        "shrinkage_k": shrink_k,
        "half_life_hours": hl_h,
        "tp1_take_pct": raw_tp1_take,
        "tp_stages": clean_stages,
    }


def load_position_tuning(raise_on_error: bool = False) -> Dict[str, Any]:
    with _ENGINE_LOCK:
        raw = _safe_read_json(
            POSITION_TUNING_PATH,
            lambda: copy.deepcopy(DEFAULT_POSITION_TUNING),
            raise_on_error=raise_on_error,
        )
        out = copy.deepcopy(DEFAULT_POSITION_TUNING)
        if isinstance(raw.get("global"), dict):
            out["global"].update(raw["global"])
        raw_cls = raw.get("classes") if isinstance(raw.get("classes"), dict) else {}
        for k in CONSTITUTION_BOUNDS:
            out["classes"][k] = _clamp_class_tuning(k, raw_cls.get(k) or {})
        return out


def save_position_tuning(new_payload: Dict[str, Any]) -> Dict[str, Any]:
    with _ENGINE_LOCK:
        cur = load_position_tuning(raise_on_error=True)
        if isinstance(new_payload.get("global"), dict):
            g = new_payload["global"]
            cur["global"]["soft_dd_enabled"] = bool(g.get("soft_dd_enabled", cur["global"]["soft_dd_enabled"]))
            _def_slice_usd = float(cur["global"].get("min_tp_slice_usd", 6.5))
            cur["global"]["min_tp_slice_usd"] = round(max(5.5, min(25.0, _safe_num(g.get("min_tp_slice_usd"), _def_slice_usd))), 2)
        if isinstance(new_payload.get("classes"), dict):
            for k in CONSTITUTION_BOUNDS:
                if k in new_payload["classes"]:
                    merged_cls = dict(cur["classes"][k])
                    if isinstance(new_payload["classes"][k], dict):
                        merged_cls.update(new_payload["classes"][k])
                    cur["classes"][k] = _clamp_class_tuning(k, merged_cls)
        elif "asset_class" in new_payload and new_payload.get("asset_class") is not None:
            ak = str(new_payload.get("asset_class") or "").strip().upper()
            if ak not in CONSTITUTION_BOUNDS:
                raise ValueError(f"Phân lớp tài sản không hợp lệ: {ak!r}")
            merged_cls = dict(cur["classes"][ak])
            if isinstance(new_payload.get("settings"), dict):
                merged_cls.update(new_payload["settings"])
            cur["classes"][ak] = _clamp_class_tuning(ak, merged_cls)
        cur["updated_at"] = int(time.time())
        _atomic_write_json(POSITION_TUNING_PATH, cur)
        _ADVISOR_CACHE["ts"] = 0.0
        _LAB_OPT_CACHE["ts"] = 0.0
        return cur


def reset_position_tuning(asset_class: Optional[str] = None) -> Dict[str, Any]:
    """Nut 1-Click Khoi Phuc Mac Dinh chuan Quy V4.1 (reset 1 phan lop hoac toan bo)."""
    with _ENGINE_LOCK:
        ak = str(asset_class).strip().upper() if isinstance(asset_class, str) else asset_class
        if ak and ak in CONSTITUTION_BOUNDS:
            cur = load_position_tuning(raise_on_error=True)
            cur["classes"][ak] = copy.deepcopy(DEFAULT_POSITION_TUNING["classes"][ak])
            cur["updated_at"] = int(time.time())
            _atomic_write_json(POSITION_TUNING_PATH, cur)
            _ADVISOR_CACHE["ts"] = 0.0
            _LAB_OPT_CACHE["ts"] = 0.0
            return cur
        fresh = copy.deepcopy(DEFAULT_POSITION_TUNING)
        fresh["updated_at"] = int(time.time())
        _atomic_write_json(POSITION_TUNING_PATH, fresh)
        _ADVISOR_CACHE["ts"] = 0.0
        _LAB_OPT_CACHE["ts"] = 0.0
        return fresh


def compute_effective_notional_cap_pct(
    cls_key: str,
    base_risk_pct: float,
    equity_usd: float,
    is_tier1: bool = False,
    custom_max_notional_pct: Optional[float] = None,
) -> float:
    """[BOM #123A]: Tu dong noi tran Notional (<= 40% NAV, ETF 3x <= 30% NAV) ty le thuan voi BaseRisk % NAV."""
    ck = str(cls_key or "ALTCOIN").upper()
    if ck not in DEFAULT_POSITION_TUNING["classes"]:
        ck = "ALTCOIN"
    eq = max(10.0, float(equity_usd or 400.0))
    if is_tier1:
        base_frac = 0.35
    elif ck == "MAJOR":
        base_frac = 0.25
    elif ck == "TRADFI_ETF_3X":
        base_frac = 0.15
    elif ck == "TRADFI_1X":
        base_frac = 0.20
    else:
        base_frac = 0.12 if eq >= 5000.0 else (0.16 if eq >= 1000.0 else 0.20)

    default_r = 0.30 if ck == "TRADFI_ETF_3X" else 0.35
    try:
        eff_r = float(base_risk_pct if base_risk_pct is not None else default_r)
    except (TypeError, ValueError):
        eff_r = default_r
    if 0.0 < eff_r <= 0.02:
        eff_r *= 100.0
    risk_scale = max(1.0, eff_r / default_r)
    eff = base_frac * risk_scale
    ceil = 0.30 if ck == "TRADFI_ETF_3X" else 0.40

    def_custom = float(DEFAULT_POSITION_TUNING["classes"][ck]["max_notional_pct"])
    if custom_max_notional_pct is not None:
        try:
            cur_custom = float(custom_max_notional_pct)
            if cur_custom > 0 and abs(cur_custom - def_custom) >= 0.1:
                custom_frac = (cur_custom * (35.0 / max(1.0, def_custom)) if is_tier1 else cur_custom) / 100.0
                eff = min(ceil, max(0.08, custom_frac * risk_scale))
        except (TypeError, ValueError):
            pass

    return round(min(ceil, max(0.05, eff)), 6)


def auto_merge_tp_ladder(
    tp_stages: List[Dict[str, Any]],
    notional_usd: float,
    min_slice_usd: float = 6.5,
) -> List[Dict[str, Any]]:
    """
    Tu dong gop cac bac TP neu lat cat < $6.5 (dam bao 0 loi -4164 MIN_NOTIONAL Binance tren moi von $25->$20,000).
    """
    active = [s for s in (tp_stages or []) if s.get("enabled", True) and float(s.get("weight_pct", 0)) > 0]
    if not active:
        return []
    tot_w = sum(float(s["weight_pct"]) for s in active)
    norm = [{"name": s.get("name", f"TP{i+1}"), "pct": float(s["pct"]), "ratio": float(s["weight_pct"]) / tot_w} for i, s in enumerate(active)]
    if notional_usd < min_slice_usd * 2.0:
        return [{"name": "TP1", "pct": norm[0]["pct"], "ratio": 1.0, "est_usd": round(notional_usd, 2)}]

    merged: List[Dict[str, Any]] = []
    acc_r = 0.0
    for idx, st in enumerate(norm):
        acc_r += st["ratio"]
        if acc_r * notional_usd >= min_slice_usd or idx == len(norm) - 1:
            merged.append({"name": st["name"], "pct": st["pct"], "ratio": acc_r})
            acc_r = 0.0
    if acc_r > 0 and merged:
        merged[-1]["ratio"] += acc_r
    # Dam bao lat cuoi cung >= min_slice_usd (neu khong gop vao lat truoc do)
    while len(merged) >= 2 and (merged[-1]["ratio"] * notional_usd) < min_slice_usd:
        last = merged.pop()
        merged[-1]["ratio"] += last["ratio"]
    s_tot = sum(m["ratio"] for m in merged) or 1.0
    for i, m in enumerate(merged):
        m["name"] = f"TP{i + 1}"
        m["ratio"] = round(m["ratio"] / s_tot, 4)
        m["est_usd"] = round(m["ratio"] * notional_usd, 2)
    return merged


def compute_shadow_bayes_breathing_advisor(db_path: str = "data/trade_bot.db", ttl_sec: float = 30.0) -> Dict[str, Any]:
    """
    [SUITE 4 QUAN QUAN A-KB10+]: Do Khoang Tho (pre_tp1_mae / ATR) & Xac suat MFE TP1..TP5
    cho 4 Phan Lop Tai San bang Weighted Median + Ham Mu Ban Ra (6h/12h/24h) + Kish N_eff + Bayes Shrinkage!
    """
    resolved = db_path if os.path.isabs(db_path) else os.path.join(_ROOT_DIR, db_path)
    now = time.time()
    with _ENGINE_LOCK:
        if (
            _ADVISOR_CACHE["data"] is not None
            and _ADVISOR_CACHE["db_path"] == resolved
            and (now - _ADVISOR_CACHE["ts"]) < ttl_sec
        ):
            return copy.deepcopy(_ADVISOR_CACHE["data"])

    tuning = load_position_tuning()
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in CONSTITUTION_BOUNDS}
    if os.path.exists(resolved):
        con = None
        try:
            con = sqlite3.connect(f"file:{resolved}?mode=ro", uri=True, timeout=3.0)
            con.execute("PRAGMA query_only = ON;")
            rows = con.execute("""
                SELECT timestamp, symbol, direction, asset_class, max_mfe, max_mae, outcome, details_json
                FROM shadow_pathfinder_logs
                WHERE outcome IN ('TP1_HIT', 'SL_HIT', 'TIMEOUT_60M', 'TIMEOUT_240M')
                ORDER BY id DESC LIMIT 1200
            """).fetchall()
            seen_15m = set()
            for ts, sym, direc, ac, mfe, mae, out, dj_raw in rows:
                ts_s = (ts / 1000.0) if (ts and ts > 1e11) else float(ts or 0)
                sym_u = str(sym or "").upper()
                dk = (sym_u, str(direc or "LONG").upper(), int(ts_s // 900))
                if dk in seen_15m:
                    continue
                seen_15m.add(dk)
                dj = {}
                try:
                    dj = json.loads(dj_raw) if dj_raw else {}
                except Exception:
                    pass
                l2 = dj.get("layer2_candle_dna") or {}
                dual = dj.get("dual_eval_240m") or dj.get("dual_eval_60m") or {}
                cls_k = _normalize_shadow_row_asset_subclass(sym_u, ac or dj.get("asset_class"))
                pre_mae_l = dual.get("pre_tp1_mae_long_pct")
                pre_mae_s = dual.get("pre_tp1_mae_short_pct")
                pre_mae = None
                if dual.get("long_1to1") == "TP1_HIT" and pre_mae_l is not None:
                    pre_mae = abs(float(pre_mae_l))
                elif dual.get("short_1to1") == "TP1_HIT" and pre_mae_s is not None:
                    pre_mae = abs(float(pre_mae_s))
                buckets[cls_k].append({
                    "ts": ts_s,
                    "atr": float(l2.get("atr_pct") or 0.0),
                    "mfe": abs(float(mfe or 0.0)),
                    "mae": abs(float(mae or 0.0)),
                    "pre_tp1_mae": pre_mae,
                    "out": str(out or ""),
                })
        except Exception as e:
            logger.debug("Lỗi đọc Shadow cho Bayes Breathing Advisor: %s", e)
        finally:
            if con is not None:
                try:
                    con.close()
                except Exception:
                    pass

    advisor: Dict[str, Any] = {}
    for cls_k, b in CONSTITUTION_BOUNDS.items():
        sub = buckets[cls_k]
        cfg_c = tuning["classes"][cls_k]
        hl_h = float(cfg_c.get("half_life_hours") or b["half_life_h"])
        k_sh = float(cfg_c.get("shrinkage_k") or 8.0)
        def_sl = float(cfg_c.get("sl_default_pct"))
        lo, hi = float(cfg_c["sl_min_pct"]), float(cfg_c["sl_max_pct"])

        vw_sl: List[Tuple[float, float]] = []
        vw_atr: List[Tuple[float, float]] = []
        vw_pre_mae: List[Tuple[float, float]] = []
        ws = wsq = 0.0
        mfe_list = []
        for x in sub:
            dt_h = max(0.0, (now - x["ts"]) / 3600.0)
            w = math.pow(0.5, dt_h / hl_h)
            if x["mfe"] > 0:
                mfe_list.append(x["mfe"])
            if w > 1e-4:
                if x["atr"] > 0:
                    est_sl = max(lo, min(hi, x["atr"] * b["atr_mult"]))
                    vw_sl.append((est_sl, w))
                    vw_atr.append((x["atr"], w))
                    ws += w
                    wsq += w * w
                if x["pre_tp1_mae"] is not None and x["pre_tp1_mae"] > 0:
                    vw_pre_mae.append((x["pre_tp1_mae"], w))

        n_eff = round((ws * ws) / wsq, 1) if wsq > 0 else 0.0
        alpha = round(n_eff / (n_eff + k_sh), 3) if (n_eff + k_sh) > 0 else 0.0
        wmed_atr = round(weighted_median(vw_atr) or 0.0, 2)
        wmed_sl = weighted_median(vw_sl)
        wmed_pre_mae = round(weighted_median(vw_pre_mae) or 0.0, 2) if vw_pre_mae else None

        # Neu co du >= 10 mau do pre_tp1_mae that -> uu tien dung pre_tp1_mae * 1.25 de tinh SL goi y
        used_atr_fallback = False
        if len(vw_pre_mae) >= 10 and wmed_pre_mae:
            shadow_est_sl = max(lo, min(hi, wmed_pre_mae * 1.25))
            source_vi = f"Đo trực tiếp Khoảng Thở thật ({len(vw_pre_mae)} mẫu pre-TP1)"
        elif wmed_sl is not None:
            shadow_est_sl = wmed_sl
            used_atr_fallback = True
            source_vi = f"Đo Trung Vị ATR có trọng số (T½={hl_h:.0f}h)"
        else:
            shadow_est_sl = def_sl
            source_vi = "Chưa có mẫu tươi -> Giữ 100% Mặc định V4.1"

        blended_sl = round(max(lo, min(hi, alpha * shadow_est_sl + (1.0 - alpha) * def_sl)), 2)
        # BE luon kep >= 0.85% Hien Phap
        rec_be = round(max(b["be_min"], min(b["be_max"], max(0.85, wmed_atr * 0.70 if wmed_atr > 0 else cfg_c["be_trigger_pct"]))), 2)
        mfe_list.sort()
        n_mfe = len(mfe_list)
        r_be = round(sum(1 for v in mfe_list if v >= 0.85) / n_mfe * 100.0, 1) if n_mfe else 0.0
        r_tp1 = round(sum(1 for v in mfe_list if v >= 1.50) / n_mfe * 100.0, 1) if n_mfe else 0.0
        r_tp2 = round(sum(1 for v in mfe_list if v >= 2.50) / n_mfe * 100.0, 1) if n_mfe else 0.0
        r_tp3 = round(sum(1 for v in mfe_list if v >= 4.00) / n_mfe * 100.0, 1) if n_mfe else 0.0
        r_tp4 = round(sum(1 for v in mfe_list if v >= 6.00) / n_mfe * 100.0, 1) if n_mfe else 0.0

        advisor[cls_k] = {
            "asset_class": cls_k,
            "label_vi": ASSET_SUBCLASS_LABELS_VI[cls_k],
            "total_samples": len(sub),
            "pre_tp1_mae_samples": len(vw_pre_mae),
            "n_eff": n_eff,
            "blend_pct": round(alpha * 100.0, 1),
            "half_life_hours": hl_h,
            "wmed_atr_pct": wmed_atr,
            "wmed_pre_tp1_mae_pct": wmed_pre_mae,
            "suggested_sl_pct": blended_sl,
            "suggested_be_pct": rec_be,
            "auto_bayes_from_atr_fallback": used_atr_fallback,
            "reach_rates": {"be_085": r_be, "tp1_150": r_tp1, "tp2_250": r_tp2, "tp3_400": r_tp3, "tp4_600": r_tp4},
            "source_vi": source_vi,
            "constitution_bounds": {"sl_min": b["sl_min"], "sl_max": b["sl_max"], "be_min": b["be_min"], "max_lev": int(b["max_lev"])},
        }

    out = {"timestamp": int(now), "advisor_by_class": advisor}
    with _ENGINE_LOCK:
        _ADVISOR_CACHE["db_path"] = resolved
        _ADVISOR_CACHE["ts"] = now
        _ADVISOR_CACHE["data"] = copy.deepcopy(out)
    return out


def get_effective_position_tuning_for_symbol(symbol: str, db_path: str = "data/trade_bot.db", exchange: Any = None) -> Dict[str, Any]:
    """
    Tra ve thong so thuc thi cho 1 VI THE MOI (chi goi luc mo lenh -> Hot-Reload an toan 100%, khong giat lenh dang mo!).
    """
    cls_k = classify_asset_subclass(symbol, exchange=exchange)
    tuning = load_position_tuning()
    cfg_c = copy.deepcopy(tuning["classes"][cls_k])
    g_cfg = copy.deepcopy(tuning["global"])
    adv_item = (compute_shadow_bayes_breathing_advisor(db_path=db_path).get("advisor_by_class") or {}).get(cls_k) or {}
    if cfg_c.get("auto_bayes_enabled") and adv_item:
        cfg_c["effective_sl_pct"] = float(adv_item.get("suggested_sl_pct") or cfg_c["sl_default_pct"])
        cfg_c["effective_be_pct"] = float(adv_item.get("suggested_be_pct") or cfg_c["be_trigger_pct"])
        cfg_c["auto_bayes_from_atr_fallback"] = bool(adv_item.get("auto_bayes_from_atr_fallback", False))
        cfg_c["active_mode_vi"] = f"🤖 Auto Bayes (Hòa trộn {adv_item.get('blend_pct', 0):.0f}% · N_eff={adv_item.get('n_eff', 0)})"
    else:
        cfg_c["effective_sl_pct"] = float(cfg_c["sl_default_pct"])
        cfg_c["effective_be_pct"] = float(cfg_c["be_trigger_pct"])
        cfg_c["auto_bayes_from_atr_fallback"] = False
        cfg_c["active_mode_vi"] = "🎛️ Thủ công / Mặc định V4.1"
    cfg_c["asset_subclass"] = cls_k
    cfg_c["global"] = g_cfg
    return cfg_c


def simulate_manual_position_tuning(
    asset_class: str,
    settings: Dict[str, Any],
    equity_usd: float = 406.0,
    db_path: str = "data/trade_bot.db",
) -> Dict[str, Any]:
    """
    [V6.1 BOM #42]: Mo phong TUC THI (Live What-If Simulator, 100% Offline PRAGMA query_only=ON)
    tren toan bo mau Shadow 60p cua phan lop tai san theo DUNG thong so nguoi dung dang go tay!
    """
    cls_k = str(asset_class or "ALTCOIN").upper()
    if cls_k not in CONSTITUTION_BOUNDS:
        cls_k = "ALTCOIN"
    b = CONSTITUTION_BOUNDS[cls_k]
    sim_cfg = _clamp_class_tuning(cls_k, settings or {})
    def_cfg = copy.deepcopy(DEFAULT_POSITION_TUNING["classes"][cls_k])
    resolved = db_path if os.path.isabs(db_path) else os.path.join(_ROOT_DIR, db_path)

    rows_cls: List[Dict[str, float]] = []
    if os.path.exists(resolved):
        con = None
        try:
            con = sqlite3.connect(f"file:{resolved}?mode=ro", uri=True, timeout=3.0)
            con.execute("PRAGMA query_only = ON;")
            rows = con.execute("""
                SELECT timestamp, symbol, direction, asset_class, max_mfe, max_mae, outcome, details_json
                FROM shadow_pathfinder_logs
                WHERE outcome IN ('TP1_HIT', 'SL_HIT', 'TIMEOUT_60M', 'TIMEOUT_240M')
                ORDER BY id DESC LIMIT 2000
            """).fetchall()
            seen = set()
            for ts, sym, direc, ac, mfe, mae, out, dj_raw in rows:
                ts_s = (ts / 1000.0) if (ts and ts > 1e11) else float(ts or 0)
                sym_u = str(sym or "").upper()
                dk = (sym_u, str(direc or "LONG").upper(), int(ts_s // 900))
                if dk in seen:
                    continue
                seen.add(dk)
                c_sym = _normalize_shadow_row_asset_subclass(sym_u, ac)
                if c_sym != cls_k:
                    continue
                dj = {}
                try:
                    dj = json.loads(dj_raw) if dj_raw else {}
                except Exception:
                    pass
                l2 = dj.get("layer2_candle_dna") or {}
                rows_cls.append({
                    "mfe": abs(float(mfe or 0.0)),
                    "mae": abs(float(mae or 0.0)),
                    "atr": float(l2.get("atr_pct") or 0.0),
                    "out": str(out or ""),
                })
        except Exception as e:
            logger.debug("Lỗi simulate_manual_position_tuning: %s", e)
        finally:
            if con is not None:
                try:
                    con.close()
                except Exception:
                    pass

    adv_cls_sim = {}
    if bool(sim_cfg.get("auto_bayes_enabled", False)) or bool(def_cfg.get("auto_bayes_enabled", False)):
        try:
            adv_cls_sim = (compute_shadow_bayes_breathing_advisor(db_path=db_path).get("advisor_by_class") or {}).get(cls_k) or {}
        except Exception:
            adv_cls_sim = {}

    pt_global_sim = (load_position_tuning().get("global") or {})
    liq_mult_sim = max(2.0, float(pt_global_sim.get("liquidation_sl_multiple", 4.0) or 4.0))

    def _eval_cfg(cfg_obj: Dict[str, Any]) -> Dict[str, Any]:
        use_auto_bayes = bool(cfg_obj.get("auto_bayes_enabled", False))
        sl_p = float((adv_cls_sim.get("suggested_sl_pct") if (use_auto_bayes and adv_cls_sim) else None) or cfg_obj["sl_default_pct"])
        sl_lo_c = float(cfg_obj.get("sl_min_pct") or b["sl_min"])
        sl_hi_c = float(cfg_obj.get("sl_max_pct") or b["sl_max"])
        sl_scale_ratio = sl_p / max(0.5, float(SL_ATR_BASE_REFERENCE.get(cls_k, def_cfg["sl_default_pct"])))
        be_p = float((adv_cls_sim.get("suggested_be_pct") if (use_auto_bayes and adv_cls_sim) else None) or cfg_obj["be_trigger_pct"])
        cush_p = float(cfg_obj.get("cushion_trigger_pct") or def_cfg["cushion_trigger_pct"])
        breath_m = float(cfg_obj.get("breathing_atr_mult") or def_cfg.get("breathing_atr_mult", 0.45))
        rat_p = float(cfg_obj["mfe_ratchet_peak_pct"])
        eff_rat_p = max(0.99 if cls_k == "TRADFI_ETF_3X" else 0.65, rat_p)
        lev = int(cfg_obj["max_leverage"])
        not_pct = float(cfg_obj["max_notional_pct"])
        base_risk_p = float(cfg_obj.get("base_risk_pct") or def_cfg.get("base_risk_pct", 0.35))
        eq_tier_mult = (
            1.15 if equity_usd < 100.0
            else (1.00 if equity_usd < 1000.0 else (0.85 if equity_usd < 5000.0 else ((0.30 / 0.35) if cls_k == "MAJOR" else 0.70)))
        )
        eff_cap_frac = compute_effective_notional_cap_pct(
            cls_k, base_risk_p, equity_usd, is_tier1=False, custom_max_notional_pct=not_pct
        )
        cap_notional = max(10.6 if cls_k == "ALTCOIN" and equity_usd >= 40 else 6.0, equity_usd * eff_cap_frac)
        rp_notional = (equity_usd * (base_risk_p / 100.0) * eq_tier_mult) / max(0.005, sl_p / 100.0)
        est_notional = max(10.6 if cls_k == "ALTCOIN" and equity_usd >= 40 else 6.0, min(cap_notional, rp_notional))
        tp1_take = int(cfg_obj.get("tp1_take_pct", 50))
        if tp1_take == 25:
            tp1_take = 30
        elif tp1_take not in (0, 30, 50):
            tp1_take = 50
        active_st = [s for s in (cfg_obj.get("tp_stages") or []) if s.get("enabled", True)]
        if not active_st:
            active_st = [(cfg_obj.get("tp_stages") or [{"name": "TP1", "pct": 1.35}])[0]]
        merged_lad = [
            {
                "name": st.get("name", f"TP{i+1}"),
                "pct": float(st["pct"]),
                "ratio": (tp1_take / 100.0) if i == 0 else 0.0,
                "est_usd": round(est_notional * ((tp1_take / 100.0) if i == 0 else (1.0 - tp1_take / 100.0)), 2),
            }
            for i, st in enumerate(active_st)
        ]

        n = len(rows_cls)
        if n == 0:
            _liq_lev0 = max(1, int(0.80 / (liq_mult_sim * max(0.01, sl_p / 100.0))))
            return {
                "n": 0, "sl_hit_pct": 0.0, "be_reach_pct": 0.0, "ratchet_reach_pct": 0.0,
                "win_pct": 0.0, "ev_pct": 0.0, "est_notional_usd": round(est_notional, 2),
                "liq_safe_lev": _liq_lev0,
                "effective_lev": min(lev, _liq_lev0),
                "tp_mode_vi": "Chưa có mẫu Shadow", "merged_ladder": merged_lad, "stage_reach": [],
            }

        sl_hits = 0
        be_hits = 0
        rat_hits = 0
        wins = 0
        pnl_sum = 0.0
        stage_hits = [0] * len(merged_lad)
        fee_entry_maker = 0.02   # Phí Maker vào lệnh Limit
        fee_tp_taker = 0.07      # Phí Market Taker 0.05% + trượt giá 0.02% khi Partial TP1 live
        fee_sl_taker = 0.07      # Phí Taker 0.05% + Trượt giá 0.02% khi đóng Stop-Market
        stop_buf_pct = 0.22      # MIN_STOP_MARKET_BUFFER_PCT trong core/bot.py

        for r in rows_cls:
            mfe = r["mfe"]
            mae = r["mae"]
            row_atr = float(r.get("atr") or 0.0)
            # [V6.1 BOM #48 + V6.4 BOM #104 + BOM #122A]: Khi Auto-Bayes fallback ATR (<10 mau pre_tp1_mae), dung sl_p trực tiếp (khong nhan kep ATR*ATR!)
            _ab_atr_fb = bool(adv_cls_sim.get("auto_bayes_from_atr_fallback", False)) if (use_auto_bayes and adv_cls_sim) else False
            if (not _ab_atr_fb) and row_atr > 0.0:
                eff_row_sl = max(sl_lo_c, min(sl_hi_c, row_atr * b["atr_mult"] * sl_scale_ratio))
            else:
                eff_row_sl = max(sl_lo_c, min(sl_hi_c, sl_p))
            tier1_loss_pct = min(1.20, max(0.55, (breath_m + 0.10) * (row_atr if row_atr > 0 else 1.2)))
            hit_be = (mfe >= be_p)
            hit_cush = (mfe >= cush_p)
            hit_rat = (mfe >= eff_rat_p)
            if hit_be:
                be_hits += 1
            if hit_rat:
                rat_hits += 1

            # Tinh xac suat cham tung bac TP
            for i_s, st in enumerate(merged_lad):
                if mfe >= float(st["pct"]):
                    stage_hits[i_s] += 1

            # [V6.4 BOM #104 FIX]: Mô phỏng sát vật lý nến 1m của core/bot.py:
            # - Xóa ảo giác `mfe * 0.65` từng tô hồng 0% sai sự thật!
            # - Tách rõ tiền tươi tại TP1 (Market Taker 50%/30%) vs Runner Stop-Market Taker chịu đệm 0.22% + Lock 80%×TP1 + Choke 75%
            tp1_pct = float(merged_lad[0]["pct"])
            if mfe >= tp1_pct and (mae < eff_row_sl or (r["out"] == "TP1_HIT" and mae < eff_row_sl * 1.05)):
                take_f = tp1_take / 100.0
                rem_f = 1.0 - take_f
                # Bậc thang khóa SL thực tế: TP1 -> 80%×TP1, TP2 -> TP1, TP3 -> TP2, TP4 -> TP3, TP5 -> TP4
                lock_floor = max(0.45, tp1_pct * 0.80)
                for idx_m in range(1, len(merged_lad)):
                    if mfe >= float(merged_lad[idx_m]["pct"]):
                        lock_floor = max(lock_floor, float(merged_lad[idx_m - 1]["pct"]))
                # Choke 75% chỉ kích hoạt ở siêu sóng >= max(2.5%, TP1+0.8%)
                choke_trig = max(2.50, tp1_pct + 0.80)
                if mfe >= choke_trig:
                    lock_floor = max(lock_floor, mfe * 0.75)
                # [V6.4 BOM #104]: Runner chỉ được ghi nhận đúng mức SL bậc thang thực tế đã khóa (eff_lock),
                # KHÔNG ăn gian đỉnh 4h chưa kiểm chứng bằng mfe - trail_gap (gây ảo giác tô hồng 0%!)
                # Nếu giá có rút chân ngược rõ (mae >= eff_row_sl * 0.40) -> rủi ro bị quét ở BE/bậc thấp hơn
                eff_lock = max(0.22, min(lock_floor, mfe - stop_buf_pct))
                if mae >= eff_row_sl * 0.40 and len(merged_lad) >= 2 and mfe < float(merged_lad[1]["pct"]):
                    eff_lock = max(0.22, eff_lock * 0.70)
                runner_gross = eff_lock
                net_r = (
                    take_f * (tp1_pct - fee_entry_maker - fee_tp_taker)
                    + rem_f * (runner_gross - fee_entry_maker - fee_sl_taker)
                )
                pnl_sum += net_r
                if net_r > 0:
                    wins += 1
            elif mae >= eff_row_sl:
                if hit_be and r["out"] != "SL_HIT":
                    pnl_sum += (0.22 - fee_entry_maker - fee_sl_taker)
                    wins += 1
                elif hit_cush and r["out"] != "SL_HIT":
                    pnl_sum += (-tier1_loss_pct - fee_entry_maker - fee_sl_taker)
                else:
                    sl_hits += 1
                    pnl_sum += (-eff_row_sl - fee_entry_maker - fee_sl_taker)
            elif hit_be:
                pnl_sum += (0.22 - fee_entry_maker - fee_sl_taker)
                wins += 1
            elif hit_rat:
                pnl_sum += (0.12 - fee_entry_maker - fee_sl_taker)
                wins += 1
            else:
                pnl_sum += (mfe * 0.20 - mae * 0.35 - fee_entry_maker - fee_sl_taker)

        liq_safe = max(1, int(0.80 / (liq_mult_sim * max(0.01, sl_p / 100.0))))
        if cls_k == "TRADFI_ETF_3X":
            liq_safe = min(2, liq_safe)
        elif cls_k == "TRADFI_1X":
            liq_safe = min(4, liq_safe)

        if tp1_take == 0:
            tp_mode_vi = (
                f"🚀 0% Gồng Siêu Sóng (Kéo SL Bậc Thang 80%×TP1 · giữ Hard BE +{be_p}%): "
                + " → ".join(f"{m['name']}(+{m['pct']}%)" for m in merged_lad)
                + " + Choke 75% + 4 lớp Chốt Non"
            )
        else:
            tp_mode_vi = (
                f"🏆 Chốt {tp1_take}% tiền tươi tại TP1 (+{merged_lad[0]['pct']}%) + {100-tp1_take}% Kéo SL Bậc Thang (80%×TP1): "
                + " → ".join(f"{m['name']}(+{m['pct']}%)" for m in merged_lad)
                + " + Choke 75% + 4 lớp Chốt Non"
            )

        return {
            "n": n,
            "sl_hit_pct": round(sl_hits / n * 100.0, 1),
            "be_reach_pct": round(be_hits / n * 100.0, 1),
            "ratchet_reach_pct": round(rat_hits / n * 100.0, 1),
            "win_pct": round(wins / n * 100.0, 1),
            "ev_pct": round(pnl_sum / n, 3),
            "est_notional_usd": round(est_notional, 2),
            "liq_safe_lev": liq_safe,
            "effective_lev": min(lev, liq_safe),
            "tp_mode_vi": tp_mode_vi,
            "merged_ladder": merged_lad,
            "stage_reach": [
                {
                    "name": merged_lad[i]["name"],
                    "pct": merged_lad[i]["pct"],
                    "ratio_pct": round(merged_lad[i]["ratio"] * 100.0, 0),
                    "est_usd": merged_lad[i]["est_usd"],
                    "reach_pct": round(stage_hits[i] / n * 100.0, 1),
                }
                for i in range(len(merged_lad))
            ],
        }

    cur_res = _eval_cfg(sim_cfg)
    def_res = _eval_cfg(def_cfg)
    return {
        "asset_class": cls_k,
        "label_vi": ASSET_SUBCLASS_LABELS_VI[cls_k],
        "clamped_settings": sim_cfg,
        "current": cur_res,
        "baseline": def_res,
        "delta": {
            "sl_hit_pct": round(cur_res["sl_hit_pct"] - def_res["sl_hit_pct"], 1),
            "be_reach_pct": round(cur_res["be_reach_pct"] - def_res["be_reach_pct"], 1),
            "win_pct": round(cur_res["win_pct"] - def_res["win_pct"], 1),
            "ev_pct": round(cur_res["ev_pct"] - def_res["ev_pct"], 3),
        },
        "constitution_note": f"Biên Hiến Pháp {cls_k}: SL [{b['sl_min']}–{b['sl_max']}%] · BE >= {b['be_min']}% · Lev <= {int(b['max_lev'])}x · Liq >= 4×SL",
    }


# ==============================================================================
# 3. PHONG THI NGHIEM TU SINH + TU TOI UU 20 THAU KINH TIENG VIET + TAB CAM
# ==============================================================================
_LAB_CODE_PREFIXES = ("LAB", "COMBO", "GATE", "2WAY")


def _parse_lab_code_parts(code: Any) -> Optional[Tuple[str, int]]:
    s = str(code or "").strip().upper()
    if "-" not in s:
        return None
    prefix, suffix = s.rsplit("-", 1)
    if prefix in _LAB_CODE_PREFIXES and suffix.isdigit():
        return prefix, int(suffix)
    return None


def _normalize_lab_registry(reg: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(reg, dict):
        reg = {}
    if not isinstance(reg.get("rejected"), dict):
        reg["rejected"] = {}
    if not isinstance(reg.get("id_map"), dict):
        reg["id_map"] = {}
    counters = reg.get("counters")
    if not isinstance(counters, dict):
        counters = {}
    norm_counters: Dict[str, int] = {}
    for p in _LAB_CODE_PREFIXES:
        try:
            norm_counters[p] = max(0, int(counters.get(p) or 0))
        except (TypeError, ValueError):
            norm_counters[p] = 0

    clean_id_map: Dict[str, str] = {}
    used_codes = set()
    # Seed rejected codes first to preserve existing user history cleanly without collisions
    for sig_r, info_r in list(reg["rejected"].items()):
        sig_k = str(sig_r or "").strip()
        if not sig_k or not isinstance(info_r, dict):
            continue
        parsed = _parse_lab_code_parts(reg["id_map"].get(sig_k) or info_r.get("code"))
        if parsed is not None:
            canon = f"{parsed[0]}-{parsed[1]}"
            if canon not in used_codes:
                clean_id_map[sig_k] = canon
                used_codes.add(canon)
                norm_counters[parsed[0]] = max(norm_counters[parsed[0]], parsed[1])
                info_r["code"] = canon

    for sig_m, code_m in list(reg["id_map"].items()):
        sig_k = str(sig_m or "").strip()
        if not sig_k or sig_k in clean_id_map:
            continue
        parsed = _parse_lab_code_parts(code_m)
        if parsed is not None:
            canon = f"{parsed[0]}-{parsed[1]}"
            if canon not in used_codes:
                clean_id_map[sig_k] = canon
                used_codes.add(canon)
                norm_counters[parsed[0]] = max(norm_counters[parsed[0]], parsed[1])

    reg["version"] = "V6.2"
    reg["id_map"] = clean_id_map
    reg["counters"] = norm_counters
    return reg


def _default_lab_registry() -> Dict[str, Any]:
    return _normalize_lab_registry({
        "version": "V6.2",
        "rejected": {
            "LAB_2_ALT_MEANREV_BUY_AI_SELL_JEV_SKIP_LONG": {
                "signature": "LAB_2_ALT_MEANREV_BUY_AI_SELL_JEV_SKIP_LONG",
                "code": "LAB-2",
                "title_vi": "Mua Bật Nảy Quá Bán Sâu (Altcoin · AI Đối Kháng)",
                "asset_class": "ALTCOIN",
                "side": "LONG",
                "dna_vi": "ALTCOIN · MeanReversion MUA + AI BÁN + JEV SKIP",
                "reason_vi": "0/20 thấu kính đạt chuẩn OOS · 40.9% chôn vốn TIMEOUT_60M · 1 mã meme AKEUSDT chiếm 38% mẫu",
                "rejected_at": int(time.time()),
            }
        },
        "id_map": {
            "LAB_2_ALT_MEANREV_BUY_AI_SELL_JEV_SKIP_LONG": "LAB-2",
        },
        "counters": {"LAB": 2, "COMBO": 0, "GATE": 0, "2WAY": 0},
    })


def load_lab_registry() -> Dict[str, Any]:
    with _ENGINE_LOCK:
        reg = _safe_read_json(LAB_REGISTRY_PATH, _default_lab_registry)
        return _normalize_lab_registry(reg)


def _assign_stable_lab_codes(reg: Dict[str, Any], items: List[Dict[str, Any]]) -> bool:
    """[BOM #116A]: Gan ma LAB/COMBO/GATE/2WAY vinh vien theo signature (khong nhay so khi cam/thang hang/sap xep)."""
    if not items:
        return False
    _normalize_lab_registry(reg)
    id_map = reg["id_map"]
    counters = reg["counters"]
    used_codes = set(id_map.values())
    changed = False
    axis_to_prefix = {"2WAY_BOTH": "2WAY", "COMBO_2_4": "COMBO", "GATE_INV": "GATE"}

    for item in items:
        sig = str(item.get("signature") or "").strip()
        if not sig:
            continue
        existing = id_map.get(sig)
        if existing and _parse_lab_code_parts(existing) is not None:
            item["code"] = existing
            continue
        prefix = axis_to_prefix.get(str(item.get("axis") or "SINGLE"), "LAB")
        counters[prefix] = int(counters.get(prefix) or 0) + 1
        while f"{prefix}-{counters[prefix]}" in used_codes:
            counters[prefix] += 1
        new_code = f"{prefix}-{counters[prefix]}"
        id_map[sig] = new_code
        used_codes.add(new_code)
        item["code"] = new_code
        changed = True
    return changed


def reject_lab_cluster(signature: str, info: Dict[str, Any]) -> Dict[str, Any]:
    with _ENGINE_LOCK:
        reg = load_lab_registry()
        sig = str(signature or "").strip()
        stable_code = reg["id_map"].get(sig)
        if not stable_code:
            parsed = _parse_lab_code_parts((info or {}).get("code"))
            used_codes = set(reg["id_map"].values())
            if parsed is not None and f"{parsed[0]}-{parsed[1]}" not in used_codes:
                stable_code = f"{parsed[0]}-{parsed[1]}"
                reg["counters"][parsed[0]] = max(int(reg["counters"].get(parsed[0]) or 0), parsed[1])
            else:
                reg["counters"]["LAB"] = int(reg["counters"].get("LAB") or 0) + 1
                while f"LAB-{reg['counters']['LAB']}" in used_codes:
                    reg["counters"]["LAB"] += 1
                stable_code = f"LAB-{reg['counters']['LAB']}"
            if sig:
                reg["id_map"][sig] = stable_code
        reg["rejected"][sig] = {
            "signature": sig,
            "code": stable_code,
            "title_vi": str((info or {}).get("title_vi") or sig),
            "asset_class": str((info or {}).get("asset_class") or "ALTCOIN"),
            "side": str((info or {}).get("side") or "LONG"),
            "dna_vi": str((info or {}).get("dna_vi") or ""),
            "reason_vi": str((info or {}).get("reason_vi") or "Người dùng kiểm định không đạt — cấm thăng hạng"),
            "rejected_at": int(time.time()),
        }
        _atomic_write_json(LAB_REGISTRY_PATH, reg)
        _LAB_OPT_CACHE["ts"] = 0.0
        return reg


def restore_lab_cluster(signature: str) -> Dict[str, Any]:
    with _ENGINE_LOCK:
        reg = load_lab_registry()
        reg["rejected"].pop(str(signature or "").strip(), None)
        _atomic_write_json(LAB_REGISTRY_PATH, reg)
        _LAB_OPT_CACHE["ts"] = 0.0
        return reg


def invalidate_lab_optimizer_cache() -> None:
    """Xoa cache 20 Thau Kinh Giam SL de nguoi dung bam Quet Toi Uu Lai tuc thi."""
    with _ENGINE_LOCK:
        _LAB_OPT_CACHE["ts"] = 0.0
        _ADVISOR_CACHE["ts"] = 0.0


# 20 Thau Kinh Loc DNA Chuan Hoa 100% Tieng Viet (Bailey & Lopez de Prado DSR <= 20 trials!)
def _build_20_vietnamese_dna_lenses(asset_class: str, side: str) -> List[Dict[str, Any]]:
    is_t = asset_class in ("TRADFI", "TRADFI_1X", "TRADFI_ETF_3X")
    atr_lo = 0.35 if is_t else 0.80
    atr_hi = 0.45 if is_t else 1.20
    rv_lo = 0.85 if is_t else 1.15
    rv_hi = 1.10 if is_t else 1.50
    w_key = "lw" if side == "LONG" else "uw"
    opp_w = "uw" if side == "LONG" else "lw"
    is_long = (side == "LONG")

    return [
        {"id": "L00", "name_vi": "Nguyên bản (Không lọc thêm)", "rules": {}, "fn": lambda x: True},
        {"id": "L01", "name_vi": "Lọc Biên Độ Thực Tối Thiểu (Chống đứng im)", "rules": {"atr_min": atr_lo}, "fn": lambda x: x["atr"] >= atr_lo},
        {"id": "L02", "name_vi": "Lọc Sóng Biên Độ Mạnh", "rules": {"atr_min": atr_hi}, "fn": lambda x: x["atr"] >= atr_hi},
        {"id": "L03", "name_vi": "Lọc Dòng Tiền Volume Cơ Bản", "rules": {"rvol_min": rv_lo}, "fn": lambda x: x["rvol"] >= rv_lo},
        {"id": "L04", "name_vi": "Lọc Dòng Tiền Cá Mập Đột Biến", "rules": {"rvol_min": rv_hi}, "fn": lambda x: x["rvol"] >= rv_hi},
        {"id": "L05", "name_vi": "Lọc Râu Rút Chân / Xả Đỉnh >= 35%", "rules": {f"{w_key}_min": 35.0}, "fn": lambda x: x[w_key] >= 35.0},
        {"id": "L06", "name_vi": "Lọc Râu Đảo Chiều Sâu >= 50%", "rules": {f"{w_key}_min": 50.0}, "fn": lambda x: x[w_key] >= 50.0},
        {"id": "L07", "name_vi": "Lọc Râu Cực Đại >= 65% Sạch Một Đầu", "rules": {f"{w_key}_min": 65.0, f"{opp_w}_max": 25.0}, "fn": lambda x: x[w_key] >= 65.0 and x[opp_w] < 25.0},
        {"id": "L08", "name_vi": "Tránh Đi Ngược Bão Xu Hướng Mạnh", "rules": {"adx_max": 32.0, "avoid_strong_opp": True}, "fn": lambda x: x["adx"] <= 32.0 and ("strong_downtrend" not in x["reg"] if is_long else "strong_uptrend" not in x["reg"])},
        {"id": "L09", "name_vi": "Yêu Cầu Thị Trường Có Sóng (ADX >= 20)", "rules": {"adx_min": 20.0}, "fn": lambda x: x["adx"] >= 20.0},
        {"id": "L10", "name_vi": "Vùng RSI An Toàn Không Cực Đoan", "rules": {"rsi_min": 33.0} if is_long else {"rsi_max": 68.0}, "fn": lambda x: (x["rsi"] >= 33.0) if is_long else (x["rsi"] <= 68.0)},
        {"id": "L11", "name_vi": "Động Lượng RSI Thuận Đà", "rules": {"rsi_min": 52.0} if is_long else {"rsi_max": 55.0}, "fn": lambda x: (x["rsi"] >= 52.0) if is_long else (x["rsi"] <= 55.0)},
        {"id": "L12", "name_vi": "Kép Biên Độ + Dòng Tiền (ATR & RVol)", "rules": {"atr_min": atr_lo, "rvol_min": rv_lo}, "fn": lambda x: x["atr"] >= atr_lo and x["rvol"] >= rv_lo},
        {"id": "L13", "name_vi": "Bắt Đáy/Đỉnh Rút Chân Chuẩn Phiên (S13)", "rules": {"atr_min": atr_lo, "adx_min": 0.01, "adx_max": 30.0, "avoid_strong_opp": True, f"{w_key}_min": 38.0, **({"rsi_min": 33.0} if is_long else {"rsi_max": 67.0}), "rvol_min": rv_lo}, "fn": lambda x: x["atr"] >= atr_lo and 0 < x["adx"] <= 30.0 and (("strong_downtrend" not in x["reg"] and x["rsi"] >= 33.0) if is_long else ("strong_uptrend" not in x["reg"] and x["rsi"] <= 67.0)) and x[w_key] >= 38.0 and x["rvol"] >= rv_lo},
        {"id": "L14", "name_vi": "Đảo Chiều Râu Cực Đại Kèm Volume (S14)", "rules": {f"{w_key}_min": 60.0, f"{opp_w}_max": 25.0, "rvol_min": rv_lo, "adx_min": 20.0}, "fn": lambda x: x[w_key] >= 60.0 and x[opp_w] < 25.0 and x["rvol"] >= rv_lo and x["adx"] >= 20.0},
        {"id": "L15", "name_vi": "Đà Sóng Mạnh Kèm Volume & RSI", "rules": ({"rsi_min": 55.0} if is_long else {"rsi_max": 45.0}) | {"rvol_min": 1.20, "wave_min": 0.50}, "fn": lambda x: (x["rsi"] >= 55.0 if is_long else x["rsi"] <= 45.0) and x["rvol"] >= 1.20 and (x["pump"] >= 0.50 if is_long else x["dump"] >= 0.50)},
        {"id": "L16", "name_vi": "Tam Hợp Biên Độ + Râu + Volume", "rules": {"atr_min": atr_lo, f"{w_key}_min": 35.0, "rvol_min": rv_lo}, "fn": lambda x: x["atr"] >= atr_lo and x[w_key] >= 35.0 and x["rvol"] >= rv_lo},
        {"id": "L17", "name_vi": "Đảo Chiều Sạch Hai Đầu (Chống Twin-Wick)", "rules": {f"{w_key}_min": 35.0, f"{opp_w}_max": 28.0, "atr_min": atr_lo}, "fn": lambda x: x[w_key] >= 35.0 and x[opp_w] < 28.0 and x["atr"] >= atr_lo},
        {"id": "L18", "name_vi": "Đảo Chiều Biến Độ Cao Sạch Râu", "rules": {"atr_min": atr_hi, "rvol_min": rv_lo, f"{opp_w}_max": 30.0}, "fn": lambda x: x["atr"] >= atr_hi and x["rvol"] >= rv_lo and x[opp_w] < 30.0},
        {"id": "L19", "name_vi": "Cân Bằng Chống Sideway & Bẫy Hai Đầu", "rules": {"adx_min": 18.0, "atr_min": atr_lo, "rvol_min": rv_lo, f"{opp_w}_max": 30.0}, "fn": lambda x: x["adx"] >= 18.0 and x["atr"] >= atr_lo and x["rvol"] >= rv_lo and x[opp_w] < 30.0},
    ]


def _vietnamese_family_name(fam: str, side: str, ac: str, ai_v: str = "NONE", jev_v: str = "NONE") -> str:
    ac_vi = {"ALTCOIN": "Altcoin", "MAJOR": "Major", "TRADFI": "TradFi", "TRADFI_1X": "TradFi", "TRADFI_ETF_3X": "ETF 3x"}.get(ac, ac)
    ai_lbl = {"BUY": "AI Mua", "SELL": "AI Bán", "NONE": "Không AI"}.get(ai_v, ai_v)
    jev_lbl = {"BUY": "4H Mua", "SELL": "4H Bán", "SKIP": "Bỏ qua 4H", "NONE": "Không 4H"}.get(jev_v, jev_v)
    ctx = f"{ac_vi} · {ai_lbl}/{jev_lbl}"
    if fam == "TRAP_SELL" and side == "LONG":
        return f"Lật Ngược Bẫy Bán Quá Đà ({ctx})"
    if fam == "TRAP_BUY" and side == "SHORT":
        return f"Lật Ngược Bẫy Mua Đuổi ({ctx})"
    if fam == "TRAP_BUY" and side == "LONG":
        return f"Mua Đáy Rút Chân ({ctx})"
    if fam == "TRAP_SELL" and side == "SHORT":
        return f"Bán Đỉnh Râu Dài ({ctx})"
    if fam == "MEANREV_SELL" and side == "LONG":
        return f"Lật Ngược Quá Mua Tiếp Đà ({ctx})"
    if fam == "MEANREV_BUY" and side == "LONG":
        return f"Mua Bật Nảy Quá Bán ({ctx})"
    if fam == "TREND_BUY" and side == "LONG":
        return f"Mua Thuận Đà Xu Hướng ({ctx})"
    if fam == "TREND_SELL" and side == "SHORT":
        return f"Bán Thuận Thác Xu Hướng ({ctx})"
    if fam == "BREAKOUT_BUY" and side == "LONG":
        return f"Mua Phá Cản Bùng Nổ ({ctx})"
    if fam == "BREAKOUT_SELL" and side == "SHORT":
        return f"Bán Phá Đáy Bùng Nổ ({ctx})"
    return f"{'Mua' if side == 'LONG' else 'Bán'} Mẫu Tự Khai Phá ({ctx})"


def _eval_lab_subset(sub: List[Dict[str, Any]], side: str) -> Dict[str, Any]:
    if not sub:
        return {
            "n": 0, "coins": 0, "max_coin_share": 1.0, "tp": 0, "sl": 0, "to": 0,
            "resolved_n": 0, "to_adverse": 0,
            "strict_tp": 0.0, "sl_rate": 100.0, "res_sl_rate": 100.0, "res_wr": 0.0,
        }
    rk = "l11" if side == "LONG" else "s11"
    tp = sum(1 for x in sub if x[rk] == "TP1_HIT")
    sl = sum(1 for x in sub if x[rk] == "SL_HIT")
    to = sum(1 for x in sub if x[rk] in ("TIMEOUT_60M", "TIMEOUT_240M"))
    # [BOM #102A FIX]: Dem so lenh TIMEOUT bi keo am sau (adverse excursion >= 0.70 * sl_dist)
    # va tinh res_sl_rate tren lenh da phan dinh (tp+sl) de chong ao giac SL% thap gia do chia cho mau TIMEOUT!
    to_adv = 0
    for x in sub:
        if x[rk] in ("TIMEOUT_60M", "TIMEOUT_240M"):
            adv_pct = float(x.get("max_down_pct", 0.0)) if side == "LONG" else float(x.get("max_up_pct", 0.0))
            fav_pct = float(x.get("max_up_pct", 0.0)) if side == "LONG" else float(x.get("max_down_pct", 0.0))
            sl_d = float(x.get("sl_dist_pct") or 1.8)
            if adv_pct >= max(0.7, sl_d * 0.65) and adv_pct > fav_pct:
                to_adv += 1
    n = len(sub)
    resolved_n = tp + sl
    cc = Counter(x["sym"] for x in sub)
    return {
        "n": n,
        "coins": len(cc),
        "max_coin_share": round(max(cc.values()) / n, 3),
        "tp": tp,
        "sl": sl,
        "to": to,
        "resolved_n": resolved_n,
        "to_adverse": to_adv,
        "strict_tp": round((tp / n) * 100.0, 1),
        "sl_rate": round((sl / n) * 100.0, 1),
        "res_sl_rate": round((sl / max(1, resolved_n)) * 100.0, 1) if resolved_n > 0 else 100.0,
        "res_wr": round((tp / max(1, resolved_n)) * 100.0, 1) if resolved_n > 0 else 0.0,
    }


def _get_lab_candle_index() -> Dict[Tuple[str, str], str]:
    """Lập chỉ mục CSV nến lịch sử local theo (SYM_CLEAN, tf) — 0 Binance REST calls, cache 120s."""
    now_m = time.monotonic()
    with _ENGINE_LOCK:
        if _LAB_HIST_INDEX_CACHE.get("map") and (now_m - float(_LAB_HIST_INDEX_CACHE.get("ts") or 0.0)) < 120.0:
            return dict(_LAB_HIST_INDEX_CACHE["map"])
    idx_map: Dict[Tuple[str, str], str] = {}
    if os.path.isdir(_HIST_DIR):
        try:
            for fn in os.listdir(_HIST_DIR):
                if not fn.endswith(".csv") or "_" not in fn:
                    continue
                parts = fn[:-4].rsplit("_", 1)
                if len(parts) != 2:
                    continue
                sym_part, tf = parts
                if tf not in ("1m", "5m", "15m"):
                    continue
                sym_clean = sym_part.replace("_", "").upper()
                idx_map.setdefault((sym_clean, tf), os.path.join(_HIST_DIR, fn))
        except Exception:
            pass
    with _ENGINE_LOCK:
        _LAB_HIST_INDEX_CACHE["ts"] = time.monotonic()
        _LAB_HIST_INDEX_CACHE["map"] = dict(idx_map)
    return idx_map


def _load_lab_csv_arrays(fp: str) -> Optional[Dict[str, Any]]:
    """Đọc CSV nến chuẩn UTC sang NumPy arrays với cache theo mtime (bounded 300 entries)."""
    if not fp or not os.path.exists(fp):
        return None
    try:
        mtime = float(os.path.getmtime(fp))
    except Exception:
        return None
    with _ENGINE_LOCK:
        cached = _LAB_CSV_ARRAY_CACHE.get(fp)
        if cached is not None and cached[0] == mtime:
            return cached[1]
    arr: Optional[Dict[str, Any]] = None
    try:
        hdr_cols = pd.read_csv(fp, nrows=0).columns
        ts_col = "timestamp" if "timestamp" in hdr_cols else ("datetime" if "datetime" in hdr_cols else None)
        if ts_col is not None:
            df = pd.read_csv(fp, usecols=[ts_col, "open", "high", "low", "close"])
            if not df.empty:
                ts_dt = pd.to_datetime(df[ts_col], utc=True, errors="coerce")
                valid = ts_dt.notna()
                df = df.loc[valid]
                if not df.empty:
                    ts_ms = ((ts_dt.loc[valid] - pd.Timestamp("1970-01-01", tz="UTC")).dt.total_seconds().astype("int64") * 1000).to_numpy()
                    arr = {
                        "ts": ts_ms,
                        "o": df["open"].astype(float).to_numpy(),
                        "h": df["high"].astype(float).to_numpy(),
                        "l": df["low"].astype(float).to_numpy(),
                        "c": df["close"].astype(float).to_numpy(),
                    }
    except Exception:
        arr = None
    with _ENGINE_LOCK:
        if len(_LAB_CSV_ARRAY_CACHE) >= 300:
            oldest_k = next(iter(_LAB_CSV_ARRAY_CACHE))
            _LAB_CSV_ARRAY_CACHE.pop(oldest_k, None)
        _LAB_CSV_ARRAY_CACHE[fp] = (mtime, arr)
    return arr


def _eval_lab_m1_sniper_replay(
    sub: List[Dict[str, Any]],
    side: str,
    ac: str,
    notional_usd: float = 80.0,
) -> Dict[str, Any]:
    """
    [BOM #111D - KIỂM CHỨNG M1 SNIPER + V6.4 C5 CHO QUÉT SL AUTO LAB]:
    0 REST API calls; chạy nến UTC local 1m>5m>15m để tránh loại oan các mẫu mạnh bị TIMEOUT_60M ở chế độ 1:1 raw.
    """
    empty_res: Dict[str, Any] = {
        "matched": 0, "fills": 0, "fill_rate": 0.0, "wins": 0, "sl_count": 0, "coins": 0, "max_coin_share": 1.0,
        "wr": 0.0, "sl_rate": 0.0, "net_usd": 0.0, "pf": 0.0, "oos_ok": False, "rescued_by_m1": False,
    }
    if not sub:
        return empty_res
    idx_map = _get_lab_candle_index()
    if not idx_map:
        return empty_res

    d = str(side or "LONG").upper()
    sub_sorted = sorted(sub, key=lambda x: (float(x.get("ts") or 0.0), int(x.get("id") or 0)))
    matched = 0
    filled_trades: List[Tuple[float, bool]] = []  # (pnl_usd, is_sl)
    fill_coins: Counter = Counter()
    post_ms = 240 * 60_000

    for row in sub_sorted:
        sym_clean = str(row.get("sym") or "").split(":")[0].replace("/", "").upper()
        ts_ms = int(float(row.get("ts") or 0.0) * 1000.0)
        if ts_ms <= 0 or not sym_clean:
            continue

        by_tf: Dict[str, Dict[str, Any]] = {}
        for tf in ("1m", "5m", "15m"):
            fp = idx_map.get((sym_clean, tf))
            if not fp:
                continue
            arr = _load_lab_csv_arrays(fp)
            if arr is not None and len(arr["ts"]) >= 5 and arr["ts"][0] <= ts_ms + 900_000 and arr["ts"][-1] >= ts_ms + 300_000:
                by_tf[tf] = arr
        if not by_tf:
            continue

        fwd_o: List[float] = []
        fwd_h: List[float] = []
        fwd_l: List[float] = []
        fwd_c: List[float] = []
        fwd_step: List[int] = []
        cursor = ts_ms

        for tf, step_ms, max_gap in (("1m", 60_000, 180_000), ("5m", 300_000, 600_000), ("15m", 900_000, 1_200_000)):
            arr = by_tf.get(tf)
            if arr is None or cursor >= ts_ms + post_ms - (step_ms // 2):
                continue
            pos = int(np.searchsorted(arr["ts"], cursor, side="left"))
            if pos >= len(arr["ts"]) or arr["ts"][pos] > cursor + max_gap:
                continue
            end = int(np.searchsorted(arr["ts"], ts_ms + post_ms, side="right"))
            for i in range(pos, end):
                fwd_o.append(float(arr["o"][i]))
                fwd_h.append(float(arr["h"][i]))
                fwd_l.append(float(arr["l"][i]))
                fwd_c.append(float(arr["c"][i]))
                fwd_step.append(step_ms)
            if end > pos:
                cursor = int(arr["ts"][end - 1]) + 1

        n_fwd = len(fwd_o)
        if n_fwd < 4:
            continue
        matched += 1

        sig_px = float(row.get("entry_price") or 0.0)
        if sig_px <= 0.0:
            sig_px = fwd_o[0]
        if sig_px <= 0.0:
            continue

        ac_sub = _normalize_shadow_row_asset_subclass(sym_clean, row.get("ac") or ac)
        atr_raw = float(row.get("atr") or 0.0)
        # [BOM #132 FIX]: layer2_candle_dna['atr_pct'] luôn ở đơn vị % (vd 0.05 = 0.05%, 1.50 = 1.50%) -> luôn chia 100.0!
        atr_dec = max(0.0, atr_raw) / 100.0
        if atr_dec <= 0.0:
            atr_dec = 0.008 if ac_sub == "TRADFI_1X" else (0.010 if ac_sub == "MAJOR" else 0.015)

        if ac_sub == "TRADFI_1X":
            pb = max(0.0010, min(0.0022, atr_dec * 0.18))
            tp1_pct = 0.0105
            sl_pct = min(0.018, max(0.010, atr_dec * 1.5))
            be_trig = 0.0085
        elif ac_sub == "TRADFI_ETF_3X":
            pb = max(0.0012, min(0.0035, atr_dec * 0.22))
            tp1_pct = 0.0230
            sl_pct = min(0.035, max(0.018, atr_dec * 1.7))
            be_trig = 0.0180
        elif ac_sub == "MAJOR":
            pb = max(0.0012, min(0.0035, atr_dec * 0.22))
            tp1_pct = 0.0105
            sl_pct = min(0.022, max(0.010, atr_dec * 1.5))
            be_trig = 0.0090
        else:
            pb = max(0.0012, min(0.0035, atr_dec * 0.22))
            tp1_pct = 0.0135
            sl_pct = min(0.035, max(0.015, atr_dec * 2.0))
            be_trig = 0.0085

        target_px = sig_px * (1.0 - pb) if d == "LONG" else sig_px * (1.0 + pb)
        runaway_dist = max(0.012, 1.5 * atr_dec)
        runaway_px = sig_px * (1.0 + runaway_dist) if d == "LONG" else sig_px * (1.0 - runaway_dist)
        inval_dist = max(0.010, min(0.025, 1.2 * atr_dec))
        inval_px = target_px * (1.0 - inval_dist) if d == "LONG" else target_px * (1.0 + inval_dist)

        fill_idx = None
        stalk_ms = 0
        # [BOM #112A FIX]: Kiem tra Khop Limit Maker TRUOC khi loai runaway/invalidation!
        # Tren nen tho 5m/15m, kiem tra inval_px truoc khop lenh tung xoa nham cac nen dap thung target_px -> SL,
        # tao ao giac M1 Sniper (VD LAB-4 SL goc 81.8% nhung bi M1 xoa SL!).
        for fi in range(min(n_fwd - 2, 30)):
            h, l, o = fwd_h[fi], fwd_l[fi], fwd_o[fi]
            if d == "LONG":
                if l <= target_px <= max(h, o):
                    fill_idx = fi
                    break
                if fwd_step[fi] <= 60_000 and l <= inval_px:
                    break
                if h >= runaway_px and o > target_px:
                    break
            else:
                if min(l, o) <= target_px <= h:
                    fill_idx = fi
                    break
                if fwd_step[fi] <= 60_000 and h >= inval_px:
                    break
                if l <= runaway_px and o < target_px:
                    break
            stalk_ms += fwd_step[fi]
            if stalk_ms >= 45 * 60_000:
                break
        if fill_idx is None:
            continue

        entry_px = target_px
        sl_lvl = -sl_pct
        tier1_loss = min(0.0120, max(0.0055, 0.55 * atr_dec))
        best_mfe = 0.0
        partial_done = False
        rem_frac = 1.0
        realized_pct = -0.0002
        fee_mkt = 0.0007
        stop_buf = 0.0022
        hold_ms = 0
        closed_bars = 0
        hit_sl_flag = False
        exited = False

        # Worst-case same-bar Hard SL check ngay tren nen fill_idx (chong bo sot SL tuc thi trong cung cay nen khop)
        _fh, _fl = fwd_h[fill_idx], fwd_l[fill_idx]
        _same_bar_adv = ((_fl - entry_px) / entry_px) if d == "LONG" else ((entry_px - _fh) / entry_px)
        if _same_bar_adv <= sl_lvl:
            realized_pct += rem_frac * (sl_lvl - fee_mkt)
            hit_sl_flag = True
            exited = True

        if not exited:
            for j in range(fill_idx + 1, n_fwd):
                h, l, c = fwd_h[j], fwd_l[j], fwd_c[j]
                hold_ms += fwd_step[j]
                held_min = hold_ms / 60_000.0
                closed_bars += 1
                if d == "LONG":
                    bar_fav = (h - entry_px) / entry_px
                    bar_adv = (l - entry_px) / entry_px
                    close_pnl = (c - entry_px) / entry_px
                else:
                    bar_fav = (entry_px - l) / entry_px
                    bar_adv = (entry_px - h) / entry_px
                    close_pnl = (entry_px - c) / entry_px

                if bar_adv <= sl_lvl:
                    realized_pct += rem_frac * (sl_lvl - fee_mkt)
                    hit_sl_flag = (sl_lvl <= -0.0035)
                    exited = True
                    break
                if bar_fav > best_mfe:
                    best_mfe = bar_fav

                if (not partial_done) and best_mfe >= tp1_pct:
                    partial_done = True
                    realized_pct += 0.50 * (tp1_pct - 0.0002)
                    rem_frac = 0.50
                    lock_80 = max(0.0045, tp1_pct * 0.80)
                    sl_lvl = max(sl_lvl, min(lock_80, max(0.0022, close_pnl - stop_buf)))
                elif partial_done:
                    if best_mfe >= max(0.0250, tp1_pct + 0.0080):
                        sl_lvl = max(sl_lvl, min(best_mfe * 0.75, close_pnl - stop_buf))
                elif held_min >= 3.0 or closed_bars >= 3:
                    if best_mfe >= max(be_trig, 0.85 * atr_dec) and held_min >= 4.5:
                        sl_lvl = max(sl_lvl, min(0.0022, close_pnl - stop_buf))
                    elif best_mfe >= 0.0080:
                        sl_lvl = max(sl_lvl, -tier1_loss)

        if not exited:
            last_c = fwd_c[-1]
            mtm = (last_c - entry_px) / entry_px if d == "LONG" else (entry_px - last_c) / entry_px
            realized_pct += rem_frac * (mtm - fee_mkt)

        filled_trades.append((notional_usd * realized_pct, hit_sl_flag))
        fill_coins[sym_clean] += 1

    fills = len(filled_trades)
    if fills == 0:
        empty_res["matched"] = matched
        return empty_res

    wins = sum(1 for p, _ in filled_trades if p > 0.0)
    sl_count = sum(1 for _, is_sl in filled_trades if is_sl)
    gross_pos = sum(p for p, _ in filled_trades if p > 0.0)
    gross_neg = abs(sum(p for p, _ in filled_trades if p < 0.0))
    net_usd = sum(p for p, _ in filled_trades)
    pf = (gross_pos / gross_neg) if gross_neg > 1e-6 else (99.0 if gross_pos > 0.0 else 0.0)

    oos_ok = False
    if fills >= 4:
        sp_o = max(1, int(fills * 0.70))
        oos_sub = filled_trades[sp_o:]
        if len(oos_sub) >= 2:
            oos_sl_rate = (sum(1 for _, slf in oos_sub if slf) / len(oos_sub)) * 100.0
            oos_net = sum(p for p, _ in oos_sub)
            oos_ok = (oos_sl_rate <= 25.0 and oos_net > 0.0)

    max_coin_share = round(max(fill_coins.values()) / max(1, fills), 3) if fill_coins else 1.0

    return {
        "matched": matched,
        "fills": fills,
        "fill_rate": round((fills / max(1, matched)) * 100.0, 1),
        "wins": wins,
        "sl_count": sl_count,
        "coins": len(fill_coins),
        "max_coin_share": max_coin_share,
        "wr": round((wins / fills) * 100.0, 1),
        "sl_rate": round((sl_count / fills) * 100.0, 1),
        "net_usd": round(net_usd, 2),
        "pf": round(min(99.0, pf), 2),
        "oos_ok": oos_ok,
        "rescued_by_m1": False,
    }


def _build_8station_blueprint(
    ac: str,
    fam: str,
    ai_v: str,
    jev_v: str,
    side: str,
    lens: Dict[str, Any],
    title_vi: str,
    slot_override: Optional[str] = None,
    pathway_families: Optional[List[str]] = None,
    ai_votes: Optional[List[str]] = None,
    jev_votes: Optional[List[str]] = None,
    veto_gate_match: str = "",
) -> Dict[str, Any]:
    """Sinh tron bo Khop Noi 8 Tram + Cong Thuc M1 CKS cho Vu Khi Dong (ho tro ca Cum Don, Phoi 2-4 Nhanh COMBO, va Lat Cong Veto GATE-INV)."""
    is_trf = ac in ("TRADFI", "TRADFI_1X", "TRADFI_ETF_3X")
    _vgate_u = str(veto_gate_match or "").upper()
    _rules_l = dict(lens.get("rules") or {})
    slot_val = slot_override or ("SLOT_A" if jev_v in ("SKIP", "NONE", "") else "SLOT_B1")
    _slot_b2_trend = (
        ("SLOT_B2" in str(slot_val).upper())
        and (
            ("JEV_SHIELD" in _vgate_u)
            or (any(k in fam for k in ("TRAP", "MEANREV")) and side in ("LONG", "SHORT"))
        )
    )
    # [BOM #86D FIX] & [BOM #124B FIX]: GATE_INV / SLOT_B2 lat nguoc theo JEV 4H la Thuan Xu Huong (TREND_MOMENTUM, 0.10xATR),
    # khong ep thanh Dao Chieu Rau 0.18xATR; cac cum dao chieu non-SLOT_B2 van giu 0.18xATR.
    is_rev = (not _slot_b2_trend) and (
        any(k in fam for k in ("TRAP", "MEANREV", "JEV_SHIELD"))
        or any(k in _vgate_u for k in ("JEV_SHIELD", "TWIN_WICK", "AGGREGATOR_VETO"))
        or ("uw_min" in _rules_l)
        or ("lw_min" in _rules_l)
    )
    if is_trf:
        regime_mode = "TRADFI_INDEPENDENT"
        q_arch = "TRADFI_BOTTOM" if side == "LONG" else "CLIMAX_REVERSAL"
        m1_k = 0.22
        m1_profile_vi = "CKS TradFi (0.22×ATR kẹp [0.10–0.22%] + OFI 75%)"
    elif is_rev:
        regime_mode = "CRYPTO_CLIMAX_TIER1"
        q_arch = "CLIMAX_REVERSAL" if side == "SHORT" else "OVERSOLD_BOUNCE"
        m1_k = 0.18
        m1_profile_vi = "CKS Đảo Chiều Râu (0.18×ATR + OFI 75% + Hủy thủng râu)"
    else:
        regime_mode = "CRYPTO_STANDARD"
        q_arch = "TREND_MOMENTUM"
        m1_k = 0.10
        m1_profile_vi = "CKS Thuận Đà Nhanh (0.10×ATR + OFI 75% + Hủy chạy mất 1.5×ATR)"

    return {
        "name_vi": title_vi,
        "asset_class": ac,
        "side": side,
        "slot": slot_val,
        "pathway_family": fam,
        "pathway_families": list(pathway_families or ([fam] if fam and fam != "ANY" else [])),
        "ai_vote": ai_v,
        "ai_votes": list(ai_votes or ([ai_v] if ai_v and ai_v not in ("ANY", "MULTI") else [])),
        "jev_vote": jev_v,
        "jev_votes": list(jev_votes or ([jev_v] if jev_v and jev_v not in ("ANY", "MULTI") else [])),
        "veto_gate_match": str(veto_gate_match or ""),
        "lens_id": lens["id"],
        "lens_name_vi": lens["name_vi"],
        "dna_rules": dict(lens.get("rules") or {}),
        "regime_mode": regime_mode,
        "quantum_archetype": q_arch,
        "m1_cks_urgency_k": m1_k,
        "m1_ofi_limit": 0.75,
        "m1_profile_vi": m1_profile_vi,
    }


def _eval_adaptive_oos(sub: List[Dict[str, Any]], side: str) -> Tuple[bool, Dict[str, Any], str]:
    """[V6.2 BOM #84, #91 & #103K FIX]: Kiem dinh Walk-Forward thich ung theo quy mo du lieu + SIET SL THUC PHAN DINH (res_sl_rate):
    - N < 50: Walk-Forward 70/30 OOS (sl_rate<=30%, res_sl_rate<=35% va (Strict TP>=50% hoac (TP>=2 & TP>SL))).
    - N >= 50: 3-Fold Rolling Walk-Forward OOS (>=2/3 giai doan sl_rate<=25% & res_sl_rate<=30% & TP>=2 & TP>=SL)."""
    if len(sub) < 6:
        return False, {
            "n": 0, "coins": 0, "max_coin_share": 1.0, "tp": 0, "sl": 0, "to": 0,
            "resolved_n": 0, "to_adverse": 0, "strict_tp": 0.0, "sl_rate": 100.0, "res_sl_rate": 100.0, "res_wr": 0.0,
        }, "70/30"
    if len(sub) >= 50:
        f_sz = len(sub) // 3
        folds = [sub[:f_sz], sub[f_sz:2 * f_sz], sub[2 * f_sz:]]
        fold_stats = [_eval_lab_subset(fl, side) for fl in folds]
        ok_folds = sum(
            1 for fs in fold_stats
            if fs["sl_rate"] <= 25.0 and fs["res_sl_rate"] <= 30.0 and fs["tp"] >= 2 and fs["tp"] >= fs["sl"]
        )
        last_st = fold_stats[-1]
        oos_ok = (
            ok_folds >= 2
            and last_st["sl_rate"] <= 25.0
            and last_st["res_sl_rate"] <= 30.0
            and last_st["tp"] >= max(2, last_st["sl"])
        )
        return oos_ok, last_st, f"3-Fold({ok_folds}/3)"
    sp = max(1, int(len(sub) * 0.70))
    oos_st = _eval_lab_subset(sub[sp:], side)
    oos_ok = (
        oos_st["n"] >= 2
        and oos_st["sl_rate"] <= 30.0
        and oos_st["res_sl_rate"] <= 35.0
        and (oos_st["strict_tp"] >= 50.0 or (oos_st["tp"] >= 2 and oos_st["tp"] > oos_st["sl"]))
    )
    return oos_ok, oos_st, "70/30"


def run_auto_dna_lab_discovery_and_optimizer(db_path: str = "data/trade_bot.db", ttl_sec: float = 30.0) -> Dict[str, Any]:
    """
    Tu dong khai pha cum LAB moi tren ca 3 lop tai san (khu lap 15M + chong 1 coin > 25%),
    chay 20 Thau Kinh Tieng Viet + Kiem chung OOS 70/30, va tach rieng tab 'KHONG DAT / CAM THANG HANG'.
    """
    resolved = db_path if os.path.isabs(db_path) else os.path.join(_ROOT_DIR, db_path)
    now = time.time()
    with _ENGINE_LOCK:
        if (
            _LAB_OPT_CACHE["data"] is not None
            and _LAB_OPT_CACHE["db_path"] == resolved
            and (now - _LAB_OPT_CACHE["ts"]) < ttl_sec
        ):
            return copy.deepcopy(_LAB_OPT_CACHE["data"])

    reg = load_lab_registry()
    rejected_map = reg.get("rejected") or {}
    lifecycle = load_weapon_lifecycle()
    promoted_sigs = {
        str(dw.get("source_signature") or "")
        for wid_p, dw in (lifecycle.get("dynamic_weapons") or {}).items()
        if (lifecycle.get("states") or {}).get(wid_p, dw.get("state")) in ("OFFICIAL", "EXPERIMENTAL", "PAUSED")
    }

    samples: List[Dict[str, Any]] = []
    if os.path.exists(resolved):
        con = None
        try:
            con = sqlite3.connect(f"file:{resolved}?mode=ro", uri=True, timeout=3.0)
            con.execute("PRAGMA query_only = ON;")
            rows = con.execute("""
                SELECT id, timestamp, symbol, direction, asset_class, entry_price, rvol, details_json
                FROM shadow_pathfinder_logs
                WHERE outcome IN ('TP1_HIT', 'SL_HIT', 'TIMEOUT_60M', 'TIMEOUT_240M')
                ORDER BY timestamp DESC, id DESC
                LIMIT 5000
            """).fetchall()
            rows.reverse()  # Tra ve thu tu thoi gian tang dan cho Walk-Forward OOS 70/30
            seen = set()
            for rid, ts, sym, direc, ac, ep, rv, dj_raw in rows:
                ts_s = (ts / 1000.0) if (ts and ts > 1e11) else float(ts or 0)
                sym_u = str(sym or "").upper()
                dk = (sym_u, str(direc or "LONG").upper(), int(ts_s // 900))
                if dk in seen:
                    continue
                seen.add(dk)
                dj = {}
                try:
                    dj = json.loads(dj_raw) if dj_raw else {}
                except Exception:
                    pass
                l2 = dj.get("layer2_candle_dna") or {}
                l3 = dj.get("layer3_consensus_dna") or {}
                dual = dj.get("dual_eval_240m") or dj.get("dual_eval_60m") or {}
                tpk = str(dj.get("tech_pathway_key") or "")
                tpk_l = tpk.lower()
                if "trap_detector:buy" in tpk_l: fam = "TRAP_BUY"
                elif "trap_detector:sell" in tpk_l: fam = "TRAP_SELL"
                elif "mean_reversion:buy" in tpk_l: fam = "MEANREV_BUY"
                elif "mean_reversion:sell" in tpk_l: fam = "MEANREV_SELL"
                elif "momentum_breakout:buy" in tpk_l: fam = "BREAKOUT_BUY"
                elif "momentum_breakout:sell" in tpk_l: fam = "BREAKOUT_SELL"
                elif "trend_following:buy" in tpk_l: fam = "TREND_BUY"
                elif "trend_following:sell" in tpk_l: fam = "TREND_SELL"
                else: fam = "OTHER"

                # [BOM #102C + BOM #108C FIX]: Chuan hoa 3 lop tai san (sua ETHFIUSDT startswith('ETH') va ONUSDT 0.11$ Altcoin)
                _sub_norm = _normalize_shadow_row_asset_subclass(sym_u, ac or dj.get("asset_class"))
                if "TRADFI" in _sub_norm:
                    _ac_norm = "TRADFI"
                elif _sub_norm == "MAJOR":
                    _ac_norm = "MAJOR"
                else:
                    _ac_norm = "ALTCOIN"
                _max_up = float(dual.get("max_up_pct_240m") or dual.get("max_up_pct_60m") or 0.0)
                _max_dn = float(dual.get("max_down_pct_240m") or dual.get("max_down_pct_60m") or 0.0)
                _sl_dp = float(dual.get("sl_dist_pct") or (1.0 if _ac_norm == "TRADFI" else (1.2 if _ac_norm == "MAJOR" else 1.8)))

                samples.append({
                    "id": rid, "ts": ts_s, "sym": sym_u,
                    "entry_price": float(ep or 0.0),
                    "dir": str(direc or "LONG").upper(),
                    "ac": _ac_norm,
                    "fam": fam, "tpk": tpk,
                    "gate": str(dj.get("layer4_exact_veto_gate") or ""),
                    "wid": str(dj.get("weapon_id") or ""),
                    "ai": str(l3.get("ai_vote") or "NONE").upper(),
                    "jev": str(l3.get("jev_vote") or "NONE").upper(),
                    "rsi": float(l2.get("rsi") or 50.0), "adx": float(l2.get("adx") or 0.0),
                    "atr": float(l2.get("atr_pct") or 0.0),
                    "rvol": float(l2.get("rvol") if l2.get("rvol") is not None else (rv if rv is not None else 1.0)),
                    "uw": float(l2.get("u_wick_pct") or 0.0), "lw": float(l2.get("l_wick_pct") or 0.0),
                    "pump": float(l2.get("pump_pct") or 0.0), "dump": float(l2.get("dump_pct") or 0.0),
                    "reg": str(l2.get("regime") or "").lower(),
                    "l11": str(dual.get("long_1to1") or ""), "s11": str(dual.get("short_1to1") or ""),
                    "max_up_pct": _max_up, "max_down_pct": _max_dn, "sl_dist_pct": _sl_dp,
                })
        except Exception as e:
            logger.debug("Lỗi quét Auto LAB Optimizer: %s", e)
        finally:
            if con is not None:
                try:
                    con.close()
                except Exception:
                    pass

    # ==========================================================================
    # [V6.2 BOM #84]: BO KHAI PHA DA TRUC 3 TRUC (CUM DON + COMBO 2-4 NHANH + LAT CONG VETO GATE-INV)
    # + TUONG LUA CHONG TRUNG LAP OVERLAP < 40% + KIEM DINH OOS THICH UNG (70/30 -> 3-FOLD ROLLING)
    # ==========================================================================
    # Tap mau cua 3 Vu Khi thu nghiem hien huu (VK2, VK9, VK10) de chan sinh vu khi song sinh trung >= 40% (BOM #91 FIX: sua nguoc dau RSI VK9!)
    existing_vk_sets: Dict[str, set] = {
        "VK2": {x["id"] for x in samples if x["ac"] == "ALTCOIN" and x["fam"] == "TRAP_SELL" and x["ai"] == "SELL" and x["jev"] == "BUY" and x["rsi"] >= 65 and 1.1 <= x["rvol"] <= 3.5},
        "VK9": {x["id"] for x in samples if x["ac"] == "ALTCOIN" and x["fam"] == "TRAP_SELL" and x["ai"] == "SELL" and x["jev"] == "BUY" and x["uw"] >= 65 and x["lw"] < 25 and x["rsi"] < 65 and x["rvol"] >= 1.33 and x["adx"] >= 20},
        "VK10": {x["id"] for x in samples if x["ac"] == "TRADFI" and x["fam"] == "TRAP_BUY" and x["ai"] == "BUY" and x["jev"] == "SELL" and x["atr"] >= 0.38 and 0 < x["adx"] <= 30 and ("strong_downtrend" not in x["reg"]) and x["lw"] >= 38 and x["rsi"] >= 33 and x["rvol"] >= 0.85},
    }

    # Moi ung vien co dang dict: sig_key, axis, ac, fam, fams, ai_v, ai_list, jev_v, jev_list, gate_match, slot_ov, side_e, title_vi, dna_vi, rows
    candidate_Specs: List[Dict[str, Any]] = []

    # TRUC 1: Cum Don (asset_class, fam, ai, jev, side)
    groups: Dict[Tuple[str, str, str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for x in samples:
        if x["fam"] == "OTHER":
            continue
        for side_e, res_k in (("LONG", "l11"), ("SHORT", "s11")):
            if x[res_k] not in ("TP1_HIT", "SL_HIT", "TIMEOUT_60M", "TIMEOUT_240M"):
                continue
            if x["ac"] == "TRADFI" and x["fam"] == "TRAP_BUY" and x["ai"] == "BUY" and x["jev"] == "SELL" and side_e == "LONG":
                continue
            if x["ac"] == "ALTCOIN" and x["fam"] == "TRAP_SELL" and x["ai"] == "SELL" and x["jev"] == "BUY" and side_e in ("LONG", "SHORT"):
                continue
            groups[(x["ac"], x["fam"], x["ai"], x["jev"], side_e)].append(x)

    for (ac, fam, ai_v, jev_v, side_e), g_rows in groups.items():
        sig_key = f"LAB_{ac}_{fam}_AI_{ai_v}_JEV_{jev_v}_{side_e}"
        if ac == "ALTCOIN" and fam == "MEANREV_BUY" and ai_v == "SELL" and jev_v in ("SKIP", "NONE", "") and side_e == "LONG":
            sig_key = "LAB_2_ALT_MEANREV_BUY_AI_SELL_JEV_SKIP_LONG"
        candidate_Specs.append({
            "sig_key": sig_key, "axis": "SINGLE", "ac": ac, "fam": fam, "fams": [fam],
            "ai_v": ai_v, "ai_list": [ai_v], "jev_v": jev_v, "jev_list": [jev_v],
            "gate_match": "", "slot_ov": None, "side_e": side_e,
            "title_vi": _vietnamese_family_name(fam, side_e, ac, ai_v, jev_v),
            "dna_vi": f"{ac} · {fam.replace('_', ' ')} + AI {ai_v} + JEV {jev_v}",
            "rows": g_rows,
        })

    # TRUC 2: Tu Dong Phoi Hop 2-4 Nhanh Cung Ho & Cung Chieu (COMBO-*)
    # 2a. Gop cac nhanh JEV khong xung dot (vd JEV=SELL + JEV=SKIP/NONE -> tu sinh ra K02 = LAB-1 + LAB-2!)
    combo_jev_buckets: Dict[Tuple[str, str, str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    combo_jev_members: Dict[Tuple[str, str, str, str, str], set] = defaultdict(set)
    for (ac, fam, ai_v, jev_v, side_e), g_rows in groups.items():
        if jev_v in ("SELL", "SKIP", "NONE", ""):
            ck = (ac, fam, ai_v, "SELL_OR_SKIP", side_e)
            combo_jev_buckets[ck].extend(g_rows)
            combo_jev_members[ck].add(jev_v or "NONE")
        if jev_v in ("BUY", "SKIP", "NONE", ""):
            ck2 = (ac, fam, ai_v, "BUY_OR_SKIP", side_e)
            combo_jev_buckets[ck2].extend(g_rows)
            combo_jev_members[ck2].add(jev_v or "NONE")

    for (ac, fam, ai_v, j_tag, side_e), c_rows in combo_jev_buckets.items():
        if len(combo_jev_members[(ac, fam, ai_v, j_tag, side_e)]) < 2 or len(c_rows) < 10:
            continue
        # Sap xep theo thoi gian tang dan cho Walk-Forward
        c_rows_sorted = sorted(c_rows, key=lambda r: (r["ts"], r["id"]))
        j_list = ["SELL", "SKIP", "NONE"] if j_tag == "SELL_OR_SKIP" else ["BUY", "SKIP", "NONE"]
        j_lbl = "4H Bán/Bỏ qua" if j_tag == "SELL_OR_SKIP" else "4H Mua/Bỏ qua"
        base_t = _vietnamese_family_name(fam, side_e, ac, ai_v, "SKIP").split("(")[0].strip()
        _combo_slot_ov = "SLOT_B2" if ((fam.endswith("_SELL") and side_e == "LONG") or (fam.endswith("_BUY") and side_e == "SHORT")) else "SLOT_B1"
        candidate_Specs.append({
            "sig_key": f"COMBO_{ac}_{fam}_AI_{ai_v}_JEV_{j_tag}_{side_e}",
            "axis": "COMBO_2_4", "ac": ac, "fam": fam, "fams": [fam],
            "ai_v": ai_v, "ai_list": [ai_v], "jev_v": "MULTI", "jev_list": j_list,
            "gate_match": "", "slot_ov": _combo_slot_ov, "side_e": side_e,
            "title_vi": f"🧬 Phối Hợp {base_t} ({ac.title()} · AI {ai_v} · {j_lbl})",
            "dna_vi": f"🧬 PHỐI HỢP · {ac} · {fam.replace('_', ' ')} + AI {ai_v} + JEV({'/'.join(j_list[:2])})",
            "rows": c_rows_sorted,
        })

    # 2b. Gop lien ho 2-4 nhanh dao chieu cung chieu (TRAP_SELL + MEANREV_SELL -> LONG hoac TRAP_BUY + MEANREV_BUY -> SHORT)
    for ac_t in ("ALTCOIN", "MAJOR", "TRADFI"):
        for f_pair, s_pair, t_lbl in (
            (("TRAP_SELL", "MEANREV_SELL"), "LONG", "🧬 Phối 3-4 Nhánh Đảo Chiều Quá Bán"),
            (("TRAP_BUY", "MEANREV_BUY"), "SHORT", "🧬 Phối 3-4 Nhánh Đảo Chiều Quá Mua"),
        ):
            m_rows = [
                x for x in samples
                if x["ac"] == ac_t and x["fam"] in f_pair
                and (x["l11"] if s_pair == "LONG" else x["s11"]) in ("TP1_HIT", "SL_HIT", "TIMEOUT_60M", "TIMEOUT_240M")
                and x["ai"] in ("NONE", "SELL" if s_pair == "LONG" else "BUY")
                and x["jev"] in ("SKIP", "NONE", "", "SELL" if s_pair == "LONG" else "BUY")
            ]
            if len(m_rows) >= 15:
                candidate_Specs.append({
                    "sig_key": f"COMBO4_{ac_t}_{'_'.join(f_pair)}_{s_pair}",
                    "axis": "COMBO_2_4", "ac": ac_t, "fam": f_pair[0], "fams": list(f_pair),
                    "ai_v": "MULTI", "ai_list": ["NONE", "SELL" if s_pair == "LONG" else "BUY"],
                    "jev_v": "MULTI", "jev_list": ["SKIP", "NONE", "SELL" if s_pair == "LONG" else "BUY"],
                    "gate_match": "", "slot_ov": "SLOT_B2", "side_e": s_pair,
                    "title_vi": f"{t_lbl} ({ac_t.title()})",
                    "dna_vi": f"🧬 PHỐI ĐA NHÁNH · {ac_t} · {'+'.join(f_pair)} → {s_pair}",
                    "rows": m_rows,
                })

    # TRUC 3: Tu Dong Khai Pha Lat Cong Veto (GATE-INV-*, vd T3_JEV_SHIELD_NEED_2_STRATS -> K10/K11/K12!)
    gate_buckets: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for x in samples:
        g_name = x["gate"]
        if not g_name:
            continue
        if not any(tok in g_name for tok in ("JEV_SHIELD_NEED_2", "AGGREGATOR_VETO", "FAST_SKIP_COUNTER_TREND", "FAST_SKIP_TWIN_WICK")):
            continue
        inv_side = "SHORT" if x["dir"] == "LONG" else "LONG"
        if "JEV_SHIELD" in g_name:
            expected_jev_g = "BUY" if inv_side == "LONG" else "SELL"
            if x["jev"] != expected_jev_g:
                continue
        res_k = "l11" if inv_side == "LONG" else "s11"
        if x[res_k] not in ("TP1_HIT", "SL_HIT", "TIMEOUT_60M", "TIMEOUT_240M"):
            continue
        gate_buckets[(x["ac"], g_name, inv_side)].append(x)

    gate_name_vi = {
        "T3_JEV_SHIELD_NEED_2_STRATS": "Lật Cổng Khiên JEV 4H",
        "T3_AGGREGATOR_VETO": "Lật Cổng Hội Đồng Veto",
        "T2_FAST_SKIP_COUNTER_TREND": "Lật Cổng Ngược Xu Hướng",
        "T2_FAST_SKIP_TWIN_WICK": "Lật Cổng Râu Hai Đầu",
    }
    for (ac, g_name, inv_side), gt_rows in gate_buckets.items():
        if len(gt_rows) < 12:
            continue
        g_short = gate_name_vi.get(g_name, f"Lật Cổng {g_name[:22]}")
        _slot_gate = "SLOT_A" if "FAST_SKIP" in g_name else "SLOT_B2"
        candidate_Specs.append({
            "sig_key": f"GATE_INV_{ac}_{g_name}_{inv_side}",
            "axis": "GATE_INV", "ac": ac, "fam": "ANY", "fams": [],
            "ai_v": "ANY", "ai_list": [], "jev_v": "ANY", "jev_list": [],
            "gate_match": g_name, "slot_ov": _slot_gate, "side_e": inv_side,
            "title_vi": f"🛡️ {g_short} ({ac.title()} · {'MUA' if inv_side == 'LONG' else 'BÁN'})",
            "dna_vi": f"🛡️ LẬT CỔNG VETO · {ac} · {g_name} → {inv_side} ({_slot_gate})",
            "rows": gt_rows,
        })

    active_labs: List[Dict[str, Any]] = []
    idx_seq = 0
    for spec in candidate_Specs:
        ac = spec["ac"]
        fam = spec["fam"]
        ai_v = spec["ai_v"]
        jev_v = spec["jev_v"]
        side_e = spec["side_e"]
        g_rows = spec["rows"]
        sig_key = spec["sig_key"]
        axis_type = spec["axis"]

        if len(g_rows) < 6:
            continue
        raw_st = _eval_lab_subset(g_rows, side_e)
        if raw_st["coins"] < 3:
            continue
        if sig_key in rejected_map or sig_key in promoted_sigs:
            continue

        # [BOM #91 + BOM #102A/B + BOM #103K FIX - ZERO-LEAKAGE OOS + CHỐNG ẢO GIÁC SL DO TIMEOUT_60M]:
        # 1) Chia 70/30 TRÊN CHÍNH `sub` (khớp 1-1 với `_eval_adaptive_oos(sub)`) để `st_is` KHÔNG BAO GIỜ nhìn trộm đuôi OOS 30%!
        # 2) Yêu cầu đủ đa dạng coin + `res_sl_rate <= 25%` + `resolved_n >= 5` và đồng bộ `passed_is` trong `lens_trials` (không mâu thuẫn như LAB-2)!
        lenses = _build_20_vietnamese_dna_lenses(ac, side_e)
        best_opt = None
        lens_trials: List[Dict[str, Any]] = []
        for ln in lenses:
            sub = [x for x in g_rows if ln["fn"](x)]
            sp_sub = max(1, int(len(sub) * 0.70)) if sub else 0
            sub_is = sub[:sp_sub]
            st = _eval_lab_subset(sub, side_e)
            st_is = _eval_lab_subset(sub_is, side_e)
            max_share = 0.25 if st["n"] >= 12 else 0.35
            oos_ok, oos_st, oos_mode_lbl = _eval_adaptive_oos(sub, side_e)
            min_n_lens = 7 if axis_type != "SINGLE" else 6
            min_tp_lens = 55.0 if axis_type == "GATE_INV" else 60.0
            passed_is = (
                st_is["n"] >= 4
                and st_is["resolved_n"] >= 3
                and st_is["coins"] >= 3
                and st_is["sl_rate"] <= 20.0
                and st_is["res_sl_rate"] <= 28.0
                and st_is["strict_tp"] >= 50.0
            )
            passed_base = (
                passed_is
                and st["n"] >= min_n_lens
                and st["resolved_n"] >= 5
                and st["coins"] >= 4
                and st["max_coin_share"] <= max_share
                and st["sl_rate"] <= 18.0
                and st["res_sl_rate"] <= 25.0
                and st["strict_tp"] >= min_tp_lens
            )
            fail_reasons = []
            if not passed_is: fail_reasons.append(f"Trượt IS 70% (SL thực IS {st_is['res_sl_rate']}%)")
            if st["n"] < min_n_lens: fail_reasons.append(f"Ít mẫu ({st['n']}<{min_n_lens})")
            if st["resolved_n"] < 5: fail_reasons.append(f"Ít lệnh phân định ({st['resolved_n']}<5)")
            if st["coins"] < 4: fail_reasons.append(f"Ít coin ({st['coins']}<4)")
            if st["max_coin_share"] > max_share: fail_reasons.append(f"Lệch 1 coin ({st['max_coin_share']*100:.0f}%)")
            if st["sl_rate"] > 18.0: fail_reasons.append(f"SL còn cao ({st['sl_rate']}%)")
            if st["res_sl_rate"] > 25.0: fail_reasons.append(f"SL thực phân định cao ({st['res_sl_rate']}%>25%)")
            if st["strict_tp"] < min_tp_lens: fail_reasons.append(f"Strict TP thấp ({st['strict_tp']}%)")
            if passed_base and not oos_ok: fail_reasons.append(f"Trượt OOS {oos_mode_lbl} (SL {oos_st['sl_rate']}% | Thực {oos_st.get('res_sl_rate', oos_st['sl_rate'])}%)")

            lens_trials.append({
                "lens_id": ln["id"],
                "lens_name_vi": ln["name_vi"],
                "n": st["n"],
                "coins": st["coins"],
                "tp": st["tp"],
                "sl": st["sl"],
                "to": st["to"],
                "resolved_n": st["resolved_n"],
                "strict_tp": st["strict_tp"],
                "sl_rate": st["sl_rate"],
                "res_sl_rate": st["res_sl_rate"],
                "oos_sl_rate": oos_st["sl_rate"],
                "passed": bool(passed_base and oos_ok),
                "note_vi": f"✅ ĐẠT CHUẨN OOS {oos_mode_lbl} (SL thực {st['res_sl_rate']}%)" if (passed_base and oos_ok) else (" · ".join(fail_reasons) or "Chưa đạt"),
            })
            if passed_is:
                # Xep hang chon thau kinh 100% bang diem In-Sample (KHONG nhin trom OOS 30%!)
                sc = (st_is["strict_tp"] - st_is["res_sl_rate"] * 2.0 - st_is["sl_rate"], st_is["resolved_n"], st_is["coins"])
                if best_opt is None or sc > best_opt[0]:
                    best_opt = (sc, ln, st, oos_st, bool(passed_base and oos_ok), oos_mode_lbl, sub)
        if best_opt is not None and not best_opt[4]:
            best_opt = None

        lens_trials.sort(key=lambda t: (0 if t["passed"] else 1, t["sl_rate"] if t["n"] >= 4 else 999.0, -t["strict_tp"], -t["n"]))
        top_lenses = lens_trials[:4]

        # Cum COMBO/GATE_INV chi hien thi khi CO it nhat 1 thau kinh dat chuan OOS (tranh lam loang bang LAB!)
        if axis_type != "SINGLE" and (best_opt is None or not best_opt[4]):
            continue
        if best_opt is None and raw_st["strict_tp"] < 40.0 and raw_st["n"] < 15:
            continue

        # Tuong lua Chong Trung Lap (< 40%) voi cac Vu Khi hien huu VK2/VK9/VK10
        cand_ids = {x["id"] for x in (best_opt[6] if best_opt is not None else g_rows)}
        max_vk_ov = 0.0
        max_vk_name = ""
        if cand_ids:
            for vk_k, vk_s in existing_vk_sets.items():
                if vk_s:
                    ov_r = len(cand_ids & vk_s) / max(1, min(len(cand_ids), len(vk_s)))
                    if ov_r > max_vk_ov:
                        max_vk_ov = ov_r
                        max_vk_name = vk_k
        if axis_type != "SINGLE" and max_vk_ov >= 0.40:
            continue

        idx_seq += 1
        title_vi = spec["title_vi"]
        dna_vi = spec["dna_vi"]

        # [V6.1 BOM #72 + BOM #102A FIX]: Uoc luong Net PnL (USDT) bao thu tren notional chuan 80$ sau phi khu hoi 0.12%
        # + khau tru -0.50*SL cho moi lenh TIMEOUT bi keo am sau (chong ao giac Net duong tren mau toan TIMEOUT am!)
        _sl_unit_pct = 1.0 if ac == "TRADFI" else (1.2 if ac == "MAJOR" else 1.8)
        def _calc_est_net_usd(st_d: Dict[str, Any]) -> float:
            _n = int(st_d.get("n") or 0)
            _tp = int(st_d.get("tp") or 0)
            _sl = int(st_d.get("sl") or 0)
            _to_adv = int(st_d.get("to_adverse") or 0)
            return round(((_tp * _sl_unit_pct - _sl * _sl_unit_pct - _to_adv * (_sl_unit_pct * 0.50) - _n * 0.12) / 100.0) * 80.0, 2)

        m1_st = _eval_lab_m1_sniper_replay(best_opt[6] if best_opt is not None else g_rows, side_e, ac, notional_usd=80.0)
        _can_m1_rescue = (
            raw_st["to"] >= max(5, int(raw_st["n"] * 0.40))
            and raw_st["coins"] >= 4
            and raw_st["max_coin_share"] <= 0.30
            and float(raw_st.get("res_sl_rate", raw_st["sl_rate"])) <= 35.0
            and m1_st["fills"] >= 8
            and m1_st.get("coins", 0) >= 4
            and m1_st.get("max_coin_share", 1.0) <= 0.35
            and m1_st["wr"] >= 70.0
            and m1_st["sl_rate"] <= 15.0
            and m1_st["net_usd"] >= 4.0
            and m1_st["pf"] >= 1.60
            and m1_st["oos_ok"]
        )
        _m1_rescue_ready = (
            _can_m1_rescue
            and raw_st["n"] >= 15
            and m1_st.get("matched", 0) >= 15
            and m1_st["fills"] >= 12
            and m1_st["wr"] >= 75.0
            and m1_st["sl_rate"] <= 15.0
            and m1_st["net_usd"] > 5.0
        )
        dual_m1_verified = False
        if best_opt is not None:
            _, best_ln, opt_st, oos_st, oos_ok, oos_mode_lbl, _ = best_opt
            est_net_usd = _calc_est_net_usd(opt_st)
            # [BOM #117E - CHỨNG THỰC KÉP 15M LENS + M1 SNIPER REPLAY]:
            # Cho phép mẫu đã qua OOS 70/30 có Resolved WR >= 85% (SL <= 10%, SL thực <= 15%) và M1 thật WR >= 80% (SL <= 10%, Net > +5$) đạt chuẩn READY_OPTIMIZED!
            dual_m1_verified = bool(
                opt_st["n"] >= 15
                and opt_st.get("resolved_n", 0) >= 8
                and oos_ok
                and opt_st.get("res_wr", 0.0) >= 85.0
                and opt_st["sl_rate"] <= 10.0
                and opt_st.get("res_sl_rate", 100.0) <= 15.0
                and est_net_usd > 5.0
                and m1_st["fills"] >= 5
                and m1_st.get("coins", 0) >= 4
                and m1_st["wr"] >= 80.0
                and m1_st["sl_rate"] <= 10.0
                and m1_st["net_usd"] > 5.0
                and m1_st["oos_ok"]
            )
            # 5 Tieu Chuan Cung Alpha SSOT + BOM #102A (SL thuc phan dinh <= 25%) + BOM #117E Dual M1 Verification
            ready = (
                (
                    opt_st["n"] >= 15
                    and opt_st.get("resolved_n", 0) >= 8
                    and oos_ok
                    and opt_st["strict_tp"] >= 75.0
                    and opt_st["sl_rate"] <= 20.0
                    and opt_st.get("res_sl_rate", 100.0) <= 25.0
                    and est_net_usd > 5.0
                )
                or dual_m1_verified
            )
            if (not ready) and _m1_rescue_ready:
                m1_st["rescued_by_m1"] = True
                ready = True
            verdict = "READY_OPTIMIZED" if ready else "ACCUMULATING_GOOD"
            status_vi = (
                f"✨ Đã tự tối ưu SL ({raw_st['sl_rate']}% → {opt_st['sl_rate']}% | SL thực {opt_st.get('res_sl_rate', opt_st['sl_rate'])}%) [{best_ln['name_vi']}]: "
                f"TP {opt_st['tp']} ({opt_st['strict_tp']}% · thực {opt_st['res_wr']}%) / SL {opt_st['sl']} / TO {opt_st['to']} · {opt_st['coins']} coin · Net ước tính {est_net_usd:+.1f}$ · OOS {oos_mode_lbl} SL {oos_st['sl_rate']}%"
            )
            if m1_st["fills"] >= 3:
                status_vi += f" · M1 thật: {m1_st['fills']}f WR {m1_st['wr']}% SL {m1_st['sl_rate']}% ({m1_st['net_usd']:+.1f}$)"
            blueprint = _build_8station_blueprint(
                ac, fam, ai_v, jev_v, side_e, best_ln, title_vi,
                slot_override=spec["slot_ov"],
                pathway_families=spec["fams"],
                ai_votes=spec["ai_list"],
                jev_votes=spec["jev_list"],
                veto_gate_match=spec["gate_match"],
            )
            show_st = opt_st
            oos_passed_flag = bool(oos_ok)
        elif _can_m1_rescue:
            m1_st["rescued_by_m1"] = True
            est_net_usd = m1_st["net_usd"]
            verdict = "READY_OPTIMIZED" if _m1_rescue_ready else "ACCUMULATING_GOOD"
            status_vi = (
                f"🎯 [M1 SNIPER CỨU MẪU] Quét SL 1:1 bị TIMEOUT nhưng M1 thật đạt WR {m1_st['wr']}% · "
                f"SL {m1_st['sl_rate']}% · Net {m1_st['net_usd']:+.2f}$ ({m1_st['fills']}/{m1_st['matched']} khớp · PF {m1_st['pf']})"
            )
            blueprint = _build_8station_blueprint(
                ac, fam, ai_v, jev_v, side_e, lenses[0], title_vi,
                slot_override=spec["slot_ov"],
                pathway_families=spec["fams"],
                ai_votes=spec["ai_list"],
                jev_votes=spec["jev_list"],
                veto_gate_match=spec["gate_match"],
            )
            show_st = raw_st
            oos_passed_flag = True
        else:
            est_net_usd = _calc_est_net_usd(raw_st)
            verdict = "SUGGEST_REJECT" if raw_st["n"] >= 15 else "ACCUMULATING"
            status_vi = (
                f"🚫 0/20 thấu kính đạt chuẩn OOS (Gốc: TP {raw_st['tp']} / SL {raw_st['sl']} ({raw_st['sl_rate']}%) / TO {raw_st['to']} · {raw_st['coins']} coin) — Đề xuất cấm!"
                if verdict == "SUGGEST_REJECT"
                else f"⏳ Đang tích lũy ({raw_st['n']}/15 · TP {raw_st['tp']} / SL {raw_st['sl']} / TO {raw_st['to']} · {raw_st['coins']} coin)"
            )
            if m1_st["fills"] >= 3:
                status_vi += f" · M1 thật: {m1_st['fills']}f WR {m1_st['wr']}% SL {m1_st['sl_rate']}% ({m1_st['net_usd']:+.1f}$)"
            blueprint = _build_8station_blueprint(
                ac, fam, ai_v, jev_v, side_e, lenses[0], title_vi,
                slot_override=spec["slot_ov"],
                pathway_families=spec["fams"],
                ai_votes=spec["ai_list"],
                jev_votes=spec["jev_list"],
                veto_gate_match=spec["gate_match"],
            )
            show_st = raw_st
            oos_passed_flag = False

        active_labs.append({
            "signature": sig_key,
            "code": f"LAB-{idx_seq}",
            "axis": axis_type,
            "title_vi": title_vi,
            "asset_class": ac,
            "side": side_e,
            "slot": blueprint["slot"],
            "samples_n": show_st["n"],
            "raw_n": raw_st["n"],
            "target_n": 15,
            "coins_count": show_st["coins"],
            "tp_count": show_st["tp"],
            "sl_count": show_st["sl"],
            "to_count": show_st["to"],
            "win_rate": show_st["strict_tp"],
            "res_wr": show_st["res_wr"],
            "sl_rate": show_st["sl_rate"],
            "res_sl_rate": show_st.get("res_sl_rate", show_st["sl_rate"]),
            "resolved_n": show_st.get("resolved_n", show_st["tp"] + show_st["sl"]),
            "to_adverse": show_st.get("to_adverse", 0),
            "est_net_usd": est_net_usd,
            "oos_passed": oos_passed_flag,
            "hard_gates_passed": bool(verdict == "READY_OPTIMIZED"),
            "max_vk_overlap_pct": round(max_vk_ov * 100.0, 1),
            "max_vk_overlap_name": max_vk_name,
            "raw_stats": raw_st,
            "top_lenses": top_lenses,
            "m1_replay": m1_st,
            "m1_rescued": bool(m1_st.get("rescued_by_m1")),
            "dual_m1_verified": bool(dual_m1_verified),
            "verdict": verdict,
            "status_vi": status_vi,
            "dna_vi": dna_vi,
            "m1_profile_vi": blueprint["m1_profile_vi"],
            "blueprint": blueprint,
            "_cand_ids": cand_ids,
        })

    # Sap xep: READY_OPTIMIZED -> ACCUMULATING_GOOD -> ACCUMULATING -> SUGGEST_REJECT; uu tien Net & WR cao, SL thap
    order_map = {"READY_OPTIMIZED": 0, "ACCUMULATING_GOOD": 1, "ACCUMULATING": 2, "SUGGEST_REJECT": 3}
    active_labs.sort(key=lambda x: (order_map.get(x["verdict"], 9), -x["est_net_usd"], -x["win_rate"], x["sl_rate"], -x["samples_n"]))

    # [BOM #103K FIX]: Loai trung COMBO/GATE_INV THEO TUNG CHIEU (side) de khong xoa cheo LONG vs SHORT & khong chan ghep 2WAY_BOTH!
    dedup_labs: List[Dict[str, Any]] = []
    accepted_combo_sets: Dict[str, List[set]] = defaultdict(list)
    for item in active_labs:
        c_ids = item.get("_cand_ids", set())
        _side_d = str(item.get("side") or "LONG").upper()
        if item.get("axis") != "SINGLE" and c_ids:
            is_dup = False
            for prev_s in accepted_combo_sets[_side_d]:
                if len(c_ids & prev_s) / max(1, min(len(c_ids), len(prev_s))) >= 0.70:
                    is_dup = True
                    break
            if is_dup:
                continue
            accepted_combo_sets[_side_d].append(c_ids)
        dedup_labs.append(item)

    # ==========================================================================
    # [V6.2 BOM #85]: TRUC 4 — TU DONG GHEP DOI VU KHI LINH HOAT 2 CHIEU (2WAY-* / BOTH)
    # Tiet kiem 1 slot trong tran 14 vu khi bang cach gop 1 cap LONG + SHORT doi xung cung goc & deu PASS OOS!
    # ==========================================================================
    by_sym_base: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for item in dedup_labs:
        sg = str(item.get("signature") or "")
        if sg.endswith("_LONG"):
            by_sym_base.setdefault(sg[:-5], {})["LONG"] = item
        elif sg.endswith("_SHORT"):
            by_sym_base.setdefault(sg[:-6], {})["SHORT"] = item

    two_way_cards: List[Dict[str, Any]] = []
    for base_sig, pair in by_sym_base.items():
        if "LONG" not in pair or "SHORT" not in pair:
            continue
        lg, sh_c = pair["LONG"], pair["SHORT"]
        if not (lg.get("oos_passed") and sh_c.get("oos_passed")):
            continue
        sig_2w = f"2WAY_{base_sig}_BOTH"
        if sig_2w in rejected_map or sig_2w in promoted_sigs:
            continue
        c_ids_2w = set(lg.get("_cand_ids") or set()) | set(sh_c.get("_cand_ids") or set())
        # [BOM #110B FIX]: Nếu 2 nhánh trùng lặp cùng các nến (SINGLE/COMBO), dùng số mẫu duy nhất c_ids_2w thay vì cộng đôi nến!
        if c_ids_2w and len(c_ids_2w) < (int(lg["samples_n"]) + int(sh_c["samples_n"])):
            continue
        n_2w = len(c_ids_2w) if c_ids_2w else (int(lg["samples_n"]) + int(sh_c["samples_n"]))
        tp_2w = int(lg["tp_count"]) + int(sh_c["tp_count"])
        sl_2w = int(lg["sl_count"]) + int(sh_c["sl_count"])
        to_2w = int(lg["to_count"]) + int(sh_c["to_count"])
        wr_2w = round((tp_2w / max(1, n_2w)) * 100.0, 1)
        sl_r_2w = round((sl_2w / max(1, n_2w)) * 100.0, 1)
        resolved_2w = tp_2w + sl_2w
        res_wr_2w = round((tp_2w / max(1, resolved_2w)) * 100.0, 1)
        res_sl_2w = round((sl_2w / max(1, resolved_2w)) * 100.0, 1) if resolved_2w > 0 else sl_r_2w
        net_2w = round(float(lg.get("est_net_usd") or 0.0) + float(sh_c.get("est_net_usd") or 0.0), 2)
        coins_2w = max(int(lg["coins_count"]), int(sh_c["coins_count"]))
        ready_2w = (n_2w >= 15 and wr_2w >= 75.0 and sl_r_2w <= 20.0 and res_sl_2w <= 25.0 and net_2w > 5.0)
        verdict_2w = "READY_OPTIMIZED" if ready_2w else "ACCUMULATING_GOOD"
        base_title = str(lg["title_vi"]).split("(")[0].strip()
        ac_2w = str(lg["asset_class"])
        title_2w = f"⚖️ {base_title} 2 Chiều ({ac_2w.title()} · MUA + BÁN)"
        bp_2w = {
            "name_vi": title_2w,
            "asset_class": ac_2w,
            "side": "BOTH",
            "slot": lg["blueprint"].get("slot") or "SLOT_B2",
            "pathway_family": "BOTH_2WAY",
            "pathway_families": list({*(lg["blueprint"].get("pathway_families") or []), *(sh_c["blueprint"].get("pathway_families") or [])}),
            "veto_gate_match": lg["blueprint"].get("veto_gate_match") or "",
            "lens_id": f"{lg['blueprint'].get('lens_id','')}+{sh_c['blueprint'].get('lens_id','')}",
            "lens_name_vi": f"MUA: {lg['blueprint'].get('lens_name_vi','')} | BÁN: {sh_c['blueprint'].get('lens_name_vi','')}",
            "legs": {
                "LONG": copy.deepcopy(lg["blueprint"]),
                "SHORT": copy.deepcopy(sh_c["blueprint"]),
            },
            "regime_mode": lg["blueprint"].get("regime_mode", "CRYPTO_CLIMAX_TIER1"),
            "quantum_archetype": "CLIMAX_REVERSAL",
            "m1_cks_urgency_k": lg["blueprint"].get("m1_cks_urgency_k", 0.18),
            "m1_ofi_limit": 0.75,
            "m1_profile_vi": f"2 Chiều CKS ({lg['blueprint'].get('m1_profile_vi', '')})",
        }
        two_way_cards.append({
            "signature": sig_2w,
            "code": "2WAY-1",
            "axis": "2WAY_BOTH",
            "title_vi": title_2w,
            "asset_class": ac_2w,
            "side": "BOTH",
            "slot": bp_2w["slot"],
            "samples_n": n_2w,
            "raw_n": int(lg.get("raw_n") or lg["samples_n"]) + int(sh_c.get("raw_n") or sh_c["samples_n"]),
            "target_n": 15,
            "coins_count": coins_2w,
            "tp_count": tp_2w,
            "sl_count": sl_2w,
            "to_count": to_2w,
            "win_rate": wr_2w,
            "res_wr": res_wr_2w,
            "sl_rate": sl_r_2w,
            "res_sl_rate": res_sl_2w,
            "resolved_n": resolved_2w,
            "est_net_usd": net_2w,
            "oos_passed": True,
            "hard_gates_passed": bool(ready_2w),
            "max_vk_overlap_pct": max(float(lg.get("max_vk_overlap_pct") or 0.0), float(sh_c.get("max_vk_overlap_pct") or 0.0)),
            "max_vk_overlap_name": lg.get("max_vk_overlap_name") or sh_c.get("max_vk_overlap_name") or "",
            "covered_children_sigs": [lg["signature"], sh_c["signature"]],
            "raw_stats": {"n": n_2w, "coins": coins_2w, "tp": tp_2w, "sl": sl_2w, "to": to_2w, "strict_tp": wr_2w, "sl_rate": sl_r_2w, "res_wr": res_wr_2w},
            "top_lenses": (sh_c.get("top_lenses") or [])[:2] + (lg.get("top_lenses") or [])[:2],
            "verdict": verdict_2w,
            "status_vi": (
                f"🏆 ĐẠT 5/5 CỔNG CỨNG 2 CHIỀU (MUA {lg['tp_count']}/{lg['samples_n']} + BÁN {sh_c['tp_count']}/{sh_c['samples_n']}): "
                f"TP {tp_2w} ({wr_2w}%) / SL {sl_2w} ({sl_r_2w}%) · Net {net_2w:+.1f}$ · Tiết kiệm 1 slot trần 14 VK!"
                if ready_2w
                else f"⚖️ Đối xứng 2 Chiều (MUA {lg['tp_count']}/{lg['samples_n']} + BÁN {sh_c['tp_count']}/{sh_c['samples_n']}): TP {tp_2w} ({wr_2w}%) / SL {sl_2w} ({sl_r_2w}%) · Net {net_2w:+.1f}$"
            ),
            "dna_vi": f"⚖️ LINH HOẠT 2 CHIỀU · {ac_2w} · {bp_2w.get('veto_gate_match') or bp_2w['pathway_family']} (MUA+BÁN chỉ tốn 1 slot!)",
            "m1_profile_vi": bp_2w["m1_profile_vi"],
            "blueprint": bp_2w,
            "_cand_ids": c_ids_2w,
        })

    # Gan danh sach mau con (covered_children_sigs) cho cac COMBO_2_4 truoc khi chay Auto-Subsumption
    for c_item in dedup_labs:
        if c_item.get("axis") != "COMBO_2_4":
            continue
        c_bp = c_item.get("blueprint") or {}
        c_fams = set(c_bp.get("pathway_families") or [])
        c_ais = set(c_bp.get("ai_votes") or [])
        c_jevs = set(c_bp.get("jev_votes") or [])
        kids = []
        for ch in dedup_labs:
            if ch is c_item or ch.get("axis") != "SINGLE":
                continue
            if ch["asset_class"] != c_item["asset_class"] or ch["side"] != c_item["side"]:
                continue
            ch_bp = ch.get("blueprint") or {}
            if (ch_bp.get("pathway_family") in c_fams
                    and (not c_ais or str(ch_bp.get("ai_vote") or "NONE").upper() in c_ais)
                    and (not c_jevs or str(ch_bp.get("jev_vote") or "NONE").upper() in c_jevs)):
                kids.append(ch["signature"])
        if kids:
            c_item["covered_children_sigs"] = kids

    all_ranked = two_way_cards + dedup_labs
    all_ranked.sort(key=lambda x: (order_map.get(x["verdict"], 9), 0 if x.get("axis") == "2WAY_BOTH" else 1, -x["est_net_usd"], -x["win_rate"], x["sl_rate"], -x["samples_n"]))

    # [BOM #116A]: Gan ma vinh vien theo signature TRUOC Pass A/B de 0% nhay ma & 0% trung ten giua 3 tab!
    with _ENGINE_LOCK:
        reg_latest = load_lab_registry()
        if _assign_stable_lab_codes(reg_latest, all_ranked):
            try:
                _atomic_write_json(LAB_REGISTRY_PATH, reg_latest)
            except Exception:
                pass

    # ==========================================================================
    # [V6.2 BOM #85]: CO CHE TU DONG BAO TRUM (AUTO-SUBSUMPTION -> TAB "DA BAO TRUM")
    # 1. Bat ky mau nao bi bao trum boi Vu Khi Dong dang bat (DYN-VK11..14) -> tu dong chuyen sang tab Da Bao Trum.
    # 2. Bat ky mau con nao da nam gon trong 2WAY-* hoac COMBO-* manh hon (OOS PASS) -> tu dong gom sang tab Da Bao Trum
    #    de bang chinh LAB Tu Sinh 100% gon sach, tiet kiem tran 14 vu khi! (Neu xoa/tam tat cha -> con tu hoi phuc!)
    # ==========================================================================
    active_dyn_weapons = [
        dw for wid_act, dw in (lifecycle.get("dynamic_weapons") or {}).items()
        if (lifecycle.get("states") or {}).get(wid_act, dw.get("state")) in ("OFFICIAL", "EXPERIMENTAL")
    ]
    subsumed_by_sig: Dict[str, Dict[str, str]] = {}

    # Pass A: Bao trum boi Vu Khi Dong da thang hang (DYN-VK11..14)
    for dw in active_dyn_weapons:
        dw_code = str(dw.get("code") or "DYN")
        dw_name = str(dw.get("short_name") or dw_code)
        for child_sig in (dw.get("covered_children_sigs") or []):
            subsumed_by_sig[str(child_sig)] = {
                "covered_by_code": dw_code,
                "covered_by_name": dw_name,
                "covered_by_kind": "PROMOTED_WEAPON",
                "covered_reason_vi": f"Đã được bao trùm bởi Vũ Khí đang chạy Live {dw_name} (tự động ẩn để tiết kiệm trần 14 VK).",
            }
        # Kiem tra them theo cau truc blueprint (phong truong hop mau con moi phat sinh sau khi da promote cha)
        dw_bp = dw.get("blueprint") or {}
        dw_legs = list((dw_bp.get("legs") or {}).values()) if dw_bp.get("side") == "BOTH" else [dw_bp]
        for cand in all_ranked:
            c_sig = cand["signature"]
            if c_sig in subsumed_by_sig:
                continue
            c_bp = cand.get("blueprint") or {}
            for leg in dw_legs:
                if str(c_bp.get("asset_class") or "") != str(leg.get("asset_class") or ""):
                    continue
                if str(c_bp.get("side") or "") != str(leg.get("side") or ""):
                    continue
                leg_gate = str(leg.get("veto_gate_match") or "")
                c_gate = str(c_bp.get("veto_gate_match") or "")
                if leg_gate and c_gate and leg_gate == c_gate:
                    subsumed_by_sig[c_sig] = {
                        "covered_by_code": dw_code,
                        "covered_by_name": dw_name,
                        "covered_by_kind": "PROMOTED_WEAPON",
                        "covered_reason_vi": f"Cùng cổng lật ngược {leg_gate} với Vũ Khí Live {dw_name} (tự gom tiết kiệm trần 14 VK).",
                    }
                    break
                leg_fams = set(leg.get("pathway_families") or [])
                leg_ais = set(leg.get("ai_votes") or [])
                leg_jevs = set(leg.get("jev_votes") or [])
                if (c_bp.get("pathway_family") in leg_fams
                        and (not leg_ais or str(c_bp.get("ai_vote") or "NONE").upper() in leg_ais)
                        and (not leg_jevs or str(c_bp.get("jev_vote") or "NONE").upper() in leg_jevs)):
                    subsumed_by_sig[c_sig] = {
                        "covered_by_code": dw_code,
                        "covered_by_name": dw_name,
                        "covered_by_kind": "PROMOTED_WEAPON",
                        "covered_reason_vi": f"Nhánh con nằm gọn trong Vũ Khí Live {dw_name} (tự gom tiết kiệm trần 14 VK).",
                    }
                    break

    # Ma co dinh (2WAY-*, COMBO-*, GATE-*, LAB-*) da duoc gan vinh vien qua _assign_stable_lab_codes() o tren.
    # Pass B: Mau con nam gon trong 2WAY-* hoac COMBO-* cha (OOS PASS) ngay trong LAB -> gom sang tab Da Bao Trum
    # [BOM #91 FIX]: KHONG cho mau cha chua dat 5/5 (ACCUMULATING_GOOD) nuot mat mau con da dat 5/5 (READY_OPTIMIZED)!
    by_sig_ranked = {it["signature"]: it for it in all_ranked}
    for parent in all_ranked:
        if parent["signature"] in subsumed_by_sig:
            continue
        if parent.get("axis") not in ("2WAY_BOTH", "COMBO_2_4"):
            continue
        if not parent.get("oos_passed"):
            continue
        for child_sig in (parent.get("covered_children_sigs") or []):
            ch_obj = by_sig_ranked.get(str(child_sig))
            if ch_obj is not None and ch_obj.get("verdict") == "READY_OPTIMIZED" and parent.get("verdict") != "READY_OPTIMIZED":
                continue
            if child_sig not in subsumed_by_sig:
                subsumed_by_sig[str(child_sig)] = {
                    "covered_by_code": parent["code"],
                    "covered_by_name": f"{parent['code']} · {parent['title_vi']}",
                    "covered_by_kind": "LAB_PARENT",
                    "covered_reason_vi": (
                        f"Đã được gộp gọn vào mẫu mạnh hơn {parent['code']} ({parent['win_rate']}% TP · SL {parent['sl_rate']}% · Net {parent['est_net_usd']:+.1f}$). "
                        f"Chỉ cần đưa {parent['code']} lên thực chiến là đủ, tiết kiệm slot trần 14 VK!"
                    ),
                }

    final_active: List[Dict[str, Any]] = []
    subsumed_labs: List[Dict[str, Any]] = []
    for item in all_ranked:
        item.pop("_cand_ids", None)
        cov_info = subsumed_by_sig.get(item["signature"])
        if cov_info is not None:
            sub_copy = dict(item)
            sub_copy.update(cov_info)
            subsumed_labs.append(sub_copy)
        else:
            final_active.append(item)

    # Gan thu tu xep hang hien thi #1, #2... doc lap hoan toan voi ma co dinh (khong bao gio doi ma khi cam/thang hang!)
    for i, item in enumerate(final_active, 1):
        item["rank"] = i

    rejected_list = sorted(
        list(rejected_map.values()),
        key=lambda r: (-int(r.get("rejected_at") or 0), str(r.get("code") or "")),
    )

    non_rej_active = [x for x in final_active if x.get("verdict") != "SUGGEST_REJECT"]
    rej_sug_active = [x for x in final_active if x.get("verdict") == "SUGGEST_REJECT"]
    kept_active = non_rej_active + rej_sug_active[:max(4, 12 - len(non_rej_active))]

    out = {
        "timestamp": int(now),
        "active_labs": kept_active,
        "subsumed_labs": subsumed_labs,
        "rejected_labs": rejected_list,
    }
    with _ENGINE_LOCK:
        _LAB_OPT_CACHE["db_path"] = resolved
        _LAB_OPT_CACHE["ts"] = now
        _LAB_OPT_CACHE["data"] = copy.deepcopy(out)
    return out


# ==============================================================================
# 4. QUAN TRI VONG DOI VU KHI 2 CHIEU (VK1..VK10 + DYN-VK11..14)
# ==============================================================================
def _default_weapon_lifecycle() -> Dict[str, Any]:
    return {
        "version": "V6.1",
        "states": {
            "VK1_LONG_THUAN_SONG_CA_MAP": "OFFICIAL",
            "VK2_LONG_LAT_NGUOC_SONG_PARABOL": "PAUSED",
            "VK3_LONG_SAN_RU_GOM_DAY": "PAUSED",
            "VK4_LONG_BAT_NAY_QUA_BAN": "OFFICIAL",
            "VK5_SHORT_THAC_DO_CA_MAP_XA": "OFFICIAL",
            "VK6_SHORT_BAT_DINH_KIET_SUC": "OFFICIAL",
            "VK7_SHORT_BAY_TANG_GIA_RAU_XA": "PAUSED",
            "VK8_THUAN_XU_HUONG_DA_KHUNG": "OFFICIAL",
            "VK9_SHORT_BAN_DINH_RAU_CUC_DAI": "EXPERIMENTAL",
            "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI": "EXPERIMENTAL",
        },
        "dynamic_weapons": {},
    }


def load_weapon_lifecycle(raise_on_error: bool = False) -> Dict[str, Any]:
    with _ENGINE_LOCK:
        lc = _safe_read_json(WEAPON_LIFECYCLE_PATH, _default_weapon_lifecycle, raise_on_error=raise_on_error)
        if not isinstance(lc.get("states"), dict):
            lc["states"] = _default_weapon_lifecycle()["states"]
        if not isinstance(lc.get("dynamic_weapons"), dict):
            lc["dynamic_weapons"] = {}
        return lc


def is_weapon_enabled_for_live(weapon_id: str) -> bool:
    """Kiem tra nhanh xem Vu Khi co dang duoc phep mo lenh Live hay dang TAM TAT / HA VE LAB / DA XOA."""
    if not weapon_id:
        return True
    lc = load_weapon_lifecycle()
    st = lc["states"].get(weapon_id)
    if st is None and weapon_id in lc["dynamic_weapons"]:
        st = lc["dynamic_weapons"][weapon_id].get("state")
    if st in ("PAUSED", "LAB_DEMOTED", "DELETED"):
        return False
    return True


def synthesize_dynamic_weapon_tree(dw: Dict[str, Any]) -> Dict[str, List[str]]:
    """[BOM #90 FIX]: Tu dong sinh Cay Dieu Kien 7 Tang (T1, T2, T3, T4, T5_M1, T6) khop 1-1 voi pipeline_map.html
    de bam xem chi tiet VK11..14 tren web hien thi ro rang DNA, 2 chan MUA/BAN va M1 CKS (khong bao gio trang tron!)."""
    bp = (dw or {}).get("blueprint") or {}
    ac = str(bp.get("asset_class") or dw.get("asset_class_target") or "ALTCOIN").upper()
    slot = str(bp.get("slot") or "SLOT_B2")
    side = str(bp.get("side") or dw.get("side") or "LONG").upper()
    vgate = str(bp.get("veto_gate_match") or "")
    m1_prof = str(bp.get("m1_profile_vi") or f"CKS M1 ({bp.get('m1_cks_urgency_k', 0.18)}×ATR + OFI 75%)")

    t2_conds: List[str] = []
    t5_conds: List[str] = [
        f"ĐK 5.1 [CKS ĐỘNG]: {m1_prof}",
        f"ĐK 5.2 [OFI CHỐNG NUỐT LỆNH]: Hủy Limit Maker nếu Taker đối kháng >= {int(float(bp.get('m1_ofi_limit') or 0.75)*100)}% tại vùng cận khớp <= 0.35%",
    ]
    if side == "BOTH" and isinstance(bp.get("legs"), dict):
        for lg_s in ("LONG", "SHORT"):
            lg = bp["legs"].get(lg_s) or {}
            rules = lg.get("dna_rules") or {}
            r_str = ", ".join(f"{k}={v}" for k, v in rules.items()) or "Mặc định"
            lbl_s = "CHÂN MUA (LONG)" if lg_s == "LONG" else "CHÂN BÁN (SHORT)"
            t2_conds.append(f"ĐK 2.{1 if lg_s == 'LONG' else 2} [{lbl_s}]: {lg.get('lens_name_vi', '')} — DNA ({r_str})")
            t5_conds.append(f"ĐK 5.{3 if lg_s == 'LONG' else 4} [M1 {lbl_s}]: {lg.get('m1_profile_vi', m1_prof)} (Archetype: {lg.get('quantum_archetype', '')})")
    else:
        rules = bp.get("dna_rules") or {}
        r_str = ", ".join(f"{k}={v}" for k, v in rules.items()) or "Nguyên bản"
        t2_conds.append(f"ĐK 2.1 [THẤU KÍNH DNA]: {bp.get('lens_name_vi', '')} — Nhánh {bp.get('pathway_family', 'ANY')} ({r_str})")

    return {
        "T1": [
            f"ĐK 1.1 [PHÂN LỚP TÀI SẢN]: Quét nhóm {ac} đạt Sàn Phí Biến Động ATR_15M (chống sideway đứng im)",
        ],
        "T2": t2_conds,
        "T3": [
            (
                f"ĐK 3.1 [CỔNG LẬT NGƯỢC {slot}]: Chỉ kích hoạt khi cổng {vgate} chặn lệnh gốc ĐỐI NGHỊCH & thuận Khiên JEV 4H"
                if vgate
                else f"ĐK 3.1 [HỘI ĐỒNG {slot}]: AI={bp.get('ai_vote','ANY')} · JEV 4H={bp.get('jev_vote','ANY')}"
            ),
        ],
        "T4": [
            f"ĐK 4.1 [AN TOÀN & KÝ QUỸ]: Kẹp SL/TP chuẩn 3 lớp ({ac}), tôn trọng trần 14 VK và Risk Budget",
        ],
        "T5_M1": t5_conds,
        "T6": [
            "ĐK 6.1 [TAM TẦNG V4.1]: Khóa Hòa Vốn Thép >= +0.85%, Cushion SL / MFE Ratchet, 0% cắt thời gian mù quáng",
        ],
    }


def _extract_vk_num(code: Any, wid: str = "") -> int:
    for cand in (str(code or ""), str(wid or "").split("_")[0]):
        c_u = cand.strip().upper()
        if c_u.startswith("VK") and c_u[2:].isdigit():
            return int(c_u[2:])
    return 0


def _active_vk_nums(lc: Dict[str, Any], exclude_wid: Optional[str] = None) -> set:
    used = set()
    states_map = lc.get("states") or {}
    for _wid_i, _dw_i in (lc.get("dynamic_weapons") or {}).items():
        if _wid_i == exclude_wid or not isinstance(_dw_i, dict):
            continue
        _st_i = states_map.get(_wid_i) or _dw_i.get("state")
        if _st_i in ("OFFICIAL", "EXPERIMENTAL", "PAUSED"):
            n_i = _extract_vk_num(_dw_i.get("code"), _wid_i)
            if n_i > 0:
                used.add(n_i)
    return used


def _retitle_dynamic_weapon_code(dw: Dict[str, Any], num: int) -> None:
    new_code = f"VK{num}"
    old_code = str(dw.get("code") or "").strip()
    bp = dw.get("blueprint") or {}
    base_name = str(bp.get("name_vi") or "").strip()
    if not base_name:
        sn = str(dw.get("short_name") or "").strip()
        if old_code and sn.startswith(old_code + " · "):
            base_name = sn[len(old_code) + 3:].strip()
        elif " · " in sn:
            base_name = sn.split(" · ", 1)[1].strip()
        else:
            base_name = sn or "Vũ Khí Động"
    dw["code"] = new_code
    dw["weapon_num"] = num
    dw["name_vi"] = f"Vũ Khí {num}: {base_name}"
    dw["short_name"] = f"{new_code} · {base_name}"


def _invalidate_lifecycle_caches() -> None:
    """[BOM #124B FIX]: Xóa toàn bộ cache Advisor, Optimizer & Arsenal khi danh sách vũ khí động thay đổi."""
    _LAB_OPT_CACHE["ts"] = 0.0
    _ADVISOR_CACHE["ts"] = 0.0
    try:
        from core.vietnamese_weapon_arsenal import invalidate_arsenal_cache
        invalidate_arsenal_cache()
    except Exception:
        pass


def update_weapon_lifecycle_state(weapon_id: str, new_state: str) -> Dict[str, Any]:
    valid_states = ("OFFICIAL", "EXPERIMENTAL", "LAB_DEMOTED", "PAUSED", "DELETED")
    if new_state not in valid_states:
        raise ValueError(f"Trạng thái không hợp lệ: {new_state}")
    from core.vietnamese_weapon_arsenal import WEAPON_ARSENAL_CATALOG
    badge_map = {
        "EXPERIMENTAL": "🧪 THỬ NGHIỆM",
        "OFFICIAL": "⚔️ CHÍNH THỨC",
        "PAUSED": "⏸️ TẠM TẮT",
        "LAB_DEMOTED": "⬇️ HẠ VỀ LAB",
        "DELETED": "🗑️ ĐÃ XÓA MỀM",
    }
    with _ENGINE_LOCK:
        lc = load_weapon_lifecycle(raise_on_error=True)
        if weapon_id not in WEAPON_ARSENAL_CATALOG and weapon_id not in lc["dynamic_weapons"]:
            raise ValueError(f"Không tìm thấy mã vũ khí hợp lệ: {weapon_id}")
        cur_state = lc["states"].get(weapon_id)
        if new_state in ("OFFICIAL", "EXPERIMENTAL") and cur_state not in ("OFFICIAL", "EXPERIMENTAL"):
            active_cnt = sum(
                1 for wid_k, s_v in lc["states"].items()
                if s_v in ("OFFICIAL", "EXPERIMENTAL") and (wid_k in WEAPON_ARSENAL_CATALOG or wid_k in lc["dynamic_weapons"])
            )
            if active_cnt >= MAX_TOTAL_WEAPONS_CAP:
                raise ValueError(f"Đã đạt trần tối đa {MAX_TOTAL_WEAPONS_CAP} vũ khí hoạt động. Hãy tạm tắt bớt 1 vũ khí trước!")
        if weapon_id in lc["dynamic_weapons"]:
            dw = lc["dynamic_weapons"][weapon_id]
            if new_state in ("OFFICIAL", "EXPERIMENTAL", "PAUSED"):
                used_nums = _active_vk_nums(lc, exclude_wid=weapon_id)
                cur_num = _extract_vk_num(dw.get("code"), weapon_id)
                if cur_num < 11 or cur_num in used_nums:
                    free_num = next((n for n in range(11, 21) if n not in used_nums), max([10] + list(used_nums)) + 1)
                    _retitle_dynamic_weapon_code(dw, free_num)
            dw["state"] = new_state
            dw["is_experimental"] = (new_state == "EXPERIMENTAL")
            dw["experimental_badge_vi"] = badge_map.get(new_state, "⚔️ CHÍNH THỨC")
        lc["states"][weapon_id] = new_state
        lc["updated_at"] = int(time.time())
        _atomic_write_json(WEAPON_LIFECYCLE_PATH, lc)
        _invalidate_lifecycle_caches()
        return lc


def hard_delete_dynamic_weapon(weapon_id: str) -> Dict[str, Any]:
    """[BOM #116A]: Xoa vinh vien 1 vu khi dong da Xoa Mem / Ha LAB / Tam Tat khoi weapon_lifecycle.json."""
    from core.vietnamese_weapon_arsenal import WEAPON_ARSENAL_CATALOG
    if weapon_id in WEAPON_ARSENAL_CATALOG:
        raise ValueError("Không thể xóa vĩnh viễn vũ khí lõi VK1..VK10; chỉ có thể Tạm Tắt.")
    with _ENGINE_LOCK:
        lc = load_weapon_lifecycle(raise_on_error=True)
        if weapon_id not in lc["dynamic_weapons"]:
            raise ValueError(f"Không tìm thấy vũ khí động: {weapon_id}")
        cur_st = lc["states"].get(weapon_id) or lc["dynamic_weapons"][weapon_id].get("state")
        if cur_st in ("OFFICIAL", "EXPERIMENTAL"):
            raise ValueError("Hãy Tạm tắt hoặc Xóa mềm vũ khí đang chạy trước khi xóa vĩnh viễn.")
        lc["dynamic_weapons"].pop(weapon_id, None)
        lc["states"].pop(weapon_id, None)
        lc["updated_at"] = int(time.time())
        _atomic_write_json(WEAPON_LIFECYCLE_PATH, lc)
        _invalidate_lifecycle_caches()
        return lc


def compact_dynamic_weapon_codes() -> Dict[str, Any]:
    """[BOM #116A]: Sap xep & danh so gon lai cac vu khi dong hoat dong/tam tat theo dung thu tu VK11, VK12..."""
    with _ENGINE_LOCK:
        lc = load_weapon_lifecycle(raise_on_error=True)
        states_map = lc.get("states") or {}
        dyn_map = lc.get("dynamic_weapons") or {}
        keep_list = []
        for wid_i, dw_i in dyn_map.items():
            if not isinstance(dw_i, dict):
                continue
            st_i = states_map.get(wid_i) or dw_i.get("state")
            if st_i in ("OFFICIAL", "EXPERIMENTAL", "PAUSED"):
                keep_list.append((
                    int(dw_i.get("created_at") or 0),
                    _extract_vk_num(dw_i.get("code"), wid_i) or 999,
                    wid_i,
                    dw_i,
                ))
        keep_list.sort(key=lambda x: (x[0], x[1], x[2]))
        for idx, (_, _, _, dw_i) in enumerate(keep_list):
            _retitle_dynamic_weapon_code(dw_i, 11 + idx)
        lc["updated_at"] = int(time.time())
        _atomic_write_json(WEAPON_LIFECYCLE_PATH, lc)
        _invalidate_lifecycle_caches()
        return lc


def promote_lab_to_dynamic_weapon(
    lab_payload: Dict[str, Any],
    db_path: Optional[str] = None,
) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """[V6.1 BOM #72]: Dua 1 mau LAB len Kho Vu Khi Dong (DYN-VK11..14) KEM RAO CHAN 5 TIEU CHUAN CUNG SERVER-SIDE.
    Tuyet doi KHONG tin payload tu trinh duyet: server tu tinh lai truc tiep tu SQLite (N>=15, WR>=75%, SL<=20%, Net>+5$, OOS Pass)."""
    sig_req = str((lab_payload or {}).get("signature") or "").strip()
    if not sig_req:
        return False, "🛡️ [5-GATE SERVER GUARD] Thiếu chữ ký (signature) của mẫu LAB để kiểm định phía máy chủ.", None

    # 1. Tu kiem dinh lai truc tiep tren du lieu that trong SQLite (khong tin JSON client gui len!)
    server_scan = run_auto_dna_lab_discovery_and_optimizer(db_path=db_path or "data/trade_bot.db", ttl_sec=0.0)
    server_active = server_scan.get("active_labs") or []
    verified_lab = next((item for item in server_active if str(item.get("signature") or "") == sig_req), None)
    if verified_lab is None:
        return (
            False,
            f"🛡️ [5-GATE SERVER GUARD] Từ chối thăng hạng: mẫu '{sig_req}' không tồn tại trong danh sách LAB hợp lệ trên máy chủ (hoặc đã bị cấm/chưa đủ mẫu).",
            None,
        )

    # 2. Kiem tra du 5 Tieu Chuan Cung Alpha phia may chu
    gate_fails = []
    n_srv = int(0 if verified_lab.get("samples_n") is None else verified_lab.get("samples_n"))
    wr_srv = float(0.0 if verified_lab.get("win_rate") is None else verified_lab.get("win_rate"))
    sl_srv = float(100.0 if verified_lab.get("sl_rate") is None else verified_lab.get("sl_rate"))
    net_srv = float(0.0 if verified_lab.get("est_net_usd") is None else verified_lab.get("est_net_usd"))
    oos_srv = bool(verified_lab.get("oos_passed"))
    verdict_srv = str(verified_lab.get("verdict") or "")

    # [BOM #112F FIX + BOM #117E FIX]: Kiem dinh M1 Sniper Rescue (N_raw>=15, M1 matched>=15, fills>=12, WR>=75%, SL<=15%, Net>+5$)
    # hoac Chung Thuc Kep (15M Resolved WR>=85%, SL<=10%, OOS Pass + M1 Replay WR>=80%, SL<=10%, Net>+5$)
    m1_rep = verified_lab.get("m1_replay") if isinstance(verified_lab.get("m1_replay"), dict) else {}
    if bool(verified_lab.get("m1_rescued")) and m1_rep:
        m1_matched = int(0 if m1_rep.get("matched") is None else m1_rep.get("matched"))
        m1_fills = int(0 if m1_rep.get("fills") is None else m1_rep.get("fills"))
        m1_wr = float(0.0 if m1_rep.get("wr") is None else m1_rep.get("wr"))
        m1_sl = float(100.0 if m1_rep.get("sl_rate") is None else m1_rep.get("sl_rate"))
        m1_net = float(0.0 if m1_rep.get("net_usd") is None else m1_rep.get("net_usd"))
        m1_oos = bool(m1_rep.get("oos_ok"))
        if n_srv < 15 or m1_matched < 15 or m1_fills < 12:
            gate_fails.append(f"Thiếu khớp M1 ({m1_fills}/12 khớp trên {m1_matched}/15 mẫu)")
        if m1_wr < 75.0:
            gate_fails.append(f"M1 WR={m1_wr:.1f}%<75%")
        if m1_sl > 15.0:
            gate_fails.append(f"M1 SL={m1_sl:.1f}%>15%")
        if m1_net <= 5.0:
            gate_fails.append(f"M1 Net={m1_net:+.2f}$<=+5$")
        if (not m1_oos) or verdict_srv != "READY_OPTIMIZED":
            gate_fails.append(f"Chưa đạt M1 OOS 70/30 (verdict={verdict_srv})")
    elif bool(verified_lab.get("dual_m1_verified")) and m1_rep:
        # [BOM #118A FIX]: Chon is None thay vi `or 100.0` de khong bien m1_sl=0.0% (0% SL nhu COMBO-1) thanh 100.0%!
        res_wr_srv = float(0.0 if verified_lab.get("res_wr") is None else verified_lab.get("res_wr"))
        m1_fills = int(0 if m1_rep.get("fills") is None else m1_rep.get("fills"))
        m1_wr = float(0.0 if m1_rep.get("wr") is None else m1_rep.get("wr"))
        m1_sl = float(100.0 if m1_rep.get("sl_rate") is None else m1_rep.get("sl_rate"))
        m1_net = float(0.0 if m1_rep.get("net_usd") is None else m1_rep.get("net_usd"))
        if n_srv < 15:
            gate_fails.append(f"Thiếu mẫu N={n_srv}<15")
        if res_wr_srv < 85.0 or m1_wr < 80.0:
            gate_fails.append(f"Chưa đạt Chứng Thực Kép (15M ResWR={res_wr_srv:.1f}%, M1 WR={m1_wr:.1f}%)")
        if sl_srv > 10.0 or m1_sl > 10.0:
            gate_fails.append(f"SL={sl_srv:.1f}% / M1 SL={m1_sl:.1f}%>10%")
        if net_srv <= 5.0 or m1_net <= 5.0 or m1_fills < 5:
            gate_fails.append(f"Net={net_srv:+.2f}$ / M1 Net={m1_net:+.2f}$<=+5$")
        if not oos_srv or verdict_srv != "READY_OPTIMIZED":
            gate_fails.append(f"Chưa đạt OOS 70/30 (verdict={verdict_srv})")
    else:
        if n_srv < 15:
            gate_fails.append(f"Thiếu mẫu N={n_srv}<15")
        if wr_srv < 75.0:
            gate_fails.append(f"Strict WR={wr_srv:.1f}%<75%")
        if sl_srv > 20.0:
            gate_fails.append(f"SL={sl_srv:.1f}%>20%")
        if net_srv <= 5.0:
            gate_fails.append(f"Net ước tính={net_srv:+.2f}$<=+5$")
        if not oos_srv or verdict_srv != "READY_OPTIMIZED":
            gate_fails.append(f"Chưa đạt OOS 70/30 (verdict={verdict_srv})")

    if gate_fails:
        return (
            False,
            "🛡️ [5-GATE SERVER GUARD] Từ chối thăng hạng (không đạt 5 Tiêu Chuẩn Cứng Alpha): " + " · ".join(gate_fails),
            None,
        )

    from core.vietnamese_weapon_arsenal import WEAPON_ARSENAL_CATALOG
    with _ENGINE_LOCK:
        lc = load_weapon_lifecycle(raise_on_error=True)
        active_cnt = sum(
            1 for wid_k, s_v in lc["states"].items()
            if s_v in ("OFFICIAL", "EXPERIMENTAL") and (wid_k in WEAPON_ARSENAL_CATALOG or wid_k in lc["dynamic_weapons"])
        )
        if active_cnt >= MAX_TOTAL_WEAPONS_CAP:
            return False, f"Đã đạt trần tối đa {MAX_TOTAL_WEAPONS_CAP} vũ khí hoạt động (chống Overfitting). Hãy tạm tắt/xóa bớt 1 vũ khí yếu trước!", None

        # Chi su dung blueprint da duoc may chu xac thuc (chong gia mao payload client)
        bp = verified_lab.get("blueprint") or {}
        if not bp:
            return False, "Thiếu thông tin Khớp nối 8 Trạm của mẫu LAB trên máy chủ.", None

        # [BOM #86A FIX]: Kiem tra trung lap theo source_signature TRUOC khi cap ma VK moi!
        # Neu mau nay da tung duoc dua len (VD: VK11) roi Ha ve LAB / Tam tat / Xoa mem -> KICH HOAT & CAP NHAT LAI DUNG VK11,
        # tuyet doi KHONG tao ban sao trung lap VK12!
        existing_wid = None
        existing_dw = None
        for _ewid, _edw in (lc.get("dynamic_weapons") or {}).items():
            if str(_edw.get("source_signature") or "") == sig_req:
                existing_wid = _ewid
                existing_dw = _edw
                if _edw.get("state") in ("OFFICIAL", "EXPERIMENTAL"):
                    return (
                        False,
                        f"🛡️ Mẫu này đã đang hoạt động trong Kho Vũ Khí dưới mã {_edw.get('code', _ewid)} — chặn tạo bản sao trùng!",
                        _edw,
                    )

        side = str(bp.get("side") or "LONG").upper()
        name_vi = str(bp.get("name_vi") or verified_lab.get("title_vi") or "Vũ Khí Động")

        active_nums = _active_vk_nums(lc, exclude_wid=existing_wid)
        if existing_wid and existing_dw is not None:
            wid = existing_wid
            old_num = _extract_vk_num(existing_dw.get("code"), wid)
            if old_num >= 11 and old_num not in active_nums:
                next_num = old_num
            else:
                next_num = next((n for n in range(11, 21) if n not in active_nums), max([10] + list(active_nums)) + 1)
            code = f"VK{next_num}"
            created_ts = int(existing_dw.get("created_at") or time.time())
            action_note = f"Đã khôi phục & cập nhật lại {code} ({name_vi}) vào Kho Vũ Khí Thử Nghiệm (chống tạo trùng VK mới)!"
        else:
            # [BOM #98 + BOM #116A + #121H]: Tai su dung ma VK11..VK20 dang trong, bao dam khong trung ma VK dang chay/tam tat!
            next_num = next((n for n in range(11, 21) if n not in active_nums), max([10] + list(active_nums)) + 1)
            code = f"VK{next_num}"
            wid = f"{code}_{side}_DONG_{int(time.time()) % 10000}"
            created_ts = int(time.time())
            action_note = f"Đã đưa {code} ({name_vi}) vào Kho Vũ Khí Thử Nghiệm với đủ Khớp Nối 8 Trạm!"

        dyn_obj = {
            "id": wid,
            "code": code,
            "weapon_num": next_num,
            "name_vi": f"Vũ Khí {next_num}: {name_vi}",
            "short_name": f"{code} · {name_vi}",
            "side": side,
            "icon": "⚖️" if side == "BOTH" else "🧪",
            "color": "#38bdf8" if side == "BOTH" else ("#10b981" if side == "LONG" else "#f43f5e"),
            "is_experimental": True,
            "is_dynamic": True,
            "experimental_badge_vi": "🧪 THỬ NGHIỆM",
            "asset_class_target": str(bp.get("asset_class") or "ALTCOIN").upper(),
            "group_vi": (
                f"LINH HOẠT 2 CHIỀU ({bp.get('slot', 'SLOT_B2')} · 🧪 ĐỘNG)"
                if side == "BOTH"
                else f"PHE {'MUA' if side == 'LONG' else 'BÁN'} ({bp.get('slot', 'SLOT_B1')} · 🧪 ĐỘNG)"
            ),
            "target_goal_vi": f"Vũ khí tự tối ưu từ LAB [{bp.get('lens_name_vi', '')}] — {bp.get('m1_profile_vi', '')}",
            "source_signature": sig_req,
            "covered_children_sigs": list(verified_lab.get("covered_children_sigs") or []),
            # [BOM #113B FIX + BOM #118A FIX]: Khi mau duoc M1 Sniper cuu hop le hoac Dual-Verified (M1 + Resolved WR),
            # luu chi so win_rate hieu dung (84.6% / 92.3%) lam nen Bayes cho Kho Vu Khi & Quantum Gate!
            "verified_server_stats": (
                {
                    "samples_n": int(m1_rep.get("fills") or n_srv),
                    "win_rate": round(float(wr_srv if m1_rep.get("wr") is None else m1_rep.get("wr")), 1),
                    "sl_rate": round(float(sl_srv if m1_rep.get("sl_rate") is None else m1_rep.get("sl_rate")), 1),
                    "est_net_usd": round(float(net_srv if m1_rep.get("net_usd") is None else m1_rep.get("net_usd")), 2),
                    "oos_passed": bool(m1_rep.get("oos_ok", oos_srv)),
                    "m1_rescued": True,
                }
                if (bool(verified_lab.get("m1_rescued")) and m1_rep)
                else (
                    {
                        "samples_n": n_srv,
                        "win_rate": round(max(wr_srv, float(0.0 if verified_lab.get("res_wr") is None else verified_lab.get("res_wr"))), 1),
                        "sl_rate": sl_srv,
                        "est_net_usd": round(max(net_srv, float(0.0 if m1_rep.get("net_usd") is None else m1_rep.get("net_usd"))), 2),
                        "oos_passed": oos_srv,
                        "dual_m1_verified": True,
                        "m1_win_rate": round(float(0.0 if m1_rep.get("wr") is None else m1_rep.get("wr")), 1),
                        "m1_sl_rate": round(float(100.0 if m1_rep.get("sl_rate") is None else m1_rep.get("sl_rate")), 1),
                        "m1_fills": int(0 if m1_rep.get("fills") is None else m1_rep.get("fills")),
                    }
                    if (bool(verified_lab.get("dual_m1_verified")) and m1_rep)
                    else {
                        "samples_n": n_srv,
                        "win_rate": wr_srv,
                        "sl_rate": sl_srv,
                        "est_net_usd": net_srv,
                        "oos_passed": oos_srv,
                    }
                )
            ),
            "state": "EXPERIMENTAL",
            "blueprint": bp,
            "created_at": created_ts,
        }
        lc["dynamic_weapons"][wid] = dyn_obj
        lc["states"][wid] = "EXPERIMENTAL"
        lc["updated_at"] = int(time.time())
        _atomic_write_json(WEAPON_LIFECYCLE_PATH, lc)
        _invalidate_lifecycle_caches()
        return True, f"✅ [5-GATE PASSED] {action_note}", dyn_obj


def evaluate_active_dynamic_weapons(
    symbol: str,
    asset_class: str,
    by_strategy: Dict[str, Any],
    ai_vote: str,
    jev_vote: str,
    candle_dna: Dict[str, float],
    veto_gate: str = "",
    blocked_direction: str = "",
    preferred_weapon_id: str = "",
) -> Optional[Dict[str, Any]]:
    """
    [V6.2 BOM #84 & #87 FIX]: Danh gia tat ca Vu Khi Dong (DYN-VK11..14) dang bat (OFFICIAL/EXPERIMENTAL) tai Tang 3 SignalAggregator.
    - Bat buoc xac thuc chieu lenh goc bi chan (`blocked_direction`) doi nghich cho GATE_INV / SLOT_B2 (chan VK11 ban nguoc JEV 4H!).
    - Chuan hoa NONE == SKIP trong `jev_votes` de Vu Khi Don JEV=NONE chay song 100%.
    - Chon nhanh BOTH 2 chieu theo thu tu thuan JEV 4H thay vi ep cung SHORT truoc LONG.
    """
    lc = load_weapon_lifecycle()
    dyn_map = lc.get("dynamic_weapons") or {}
    if not dyn_map:
        return None

    ac_raw_ev = str(asset_class or "ALTCOIN").upper()
    # [BOM #126A FIX]: Ánh xạ cả COMMODITY/GOLD/SILVER/OIL vào TRADFI thay vì rơi nhầm sang ALTCOIN
    ac_up = (
        "TRADFI"
        if any(k in ac_raw_ev for k in ("TRADFI", "COMMODITY", "GOLD", "SILVER", "OIL"))
        else ("MAJOR" if "MAJOR" in ac_raw_ev else "ALTCOIN")
    )
    ai_u = str(ai_vote or "NONE").upper()
    jev_u = str(jev_vote or "NONE").upper()
    gate_u = str(veto_gate or "").upper()
    blk_u = str(blocked_direction or "").upper()

    # Kiem tra cac strategy co trong by_strategy (bo hau to @idx neu co tu multi-TF)
    # [BOM #119D FIX + BOM #126A FIX]: Chi ghi nhan chien thuat ky thuat dat nguong confidence >= 0.65 & chong TypeError khi confidence=None!
    strat_tokens = set()
    for s_name, s_sig in (by_strategy or {}).items():
        base_sn = str(s_name or "").split("@")[0].strip().lower()
        _raw_conf_ev = getattr(s_sig, "confidence", None) if hasattr(s_sig, "confidence") else (s_sig.get("confidence") if isinstance(s_sig, dict) else None)
        try:
            s_conf_ev = 1.0 if _raw_conf_ev is None else float(_raw_conf_ev)
        except (TypeError, ValueError):
            s_conf_ev = 0.0
        if s_conf_ev < 0.65:
            continue
        s_val = str(getattr(getattr(s_sig, "signal", s_sig), "value", s_sig) or "").upper()
        if "BUY" in s_val:
            strat_tokens.add(f"{base_sn}:BUY")
        elif "SELL" in s_val:
            strat_tokens.add(f"{base_sn}:SELL")

    fam_check = {
        "TRAP_BUY": "trap_detector:BUY",
        "TRAP_SELL": "trap_detector:SELL",
        "MEANREV_BUY": "mean_reversion:BUY",
        "MEANREV_SELL": "mean_reversion:SELL",
        "BREAKOUT_BUY": "momentum_breakout:BUY",
        "BREAKOUT_SELL": "momentum_breakout:SELL",
        "TREND_BUY": "trend_following:BUY",
        "TREND_SELL": "trend_following:SELL",
    }

    atr = float(candle_dna.get("atr_pct") or 0.0)
    adx = float(candle_dna.get("adx") or 0.0)
    rsi = float(candle_dna.get("rsi") or 50.0)
    rvol = float(candle_dna.get("rvol") if candle_dna.get("rvol") is not None else 1.0)
    uw = float(candle_dna.get("u_wick_pct") or 0.0)
    lw = float(candle_dna.get("l_wick_pct") or 0.0)
    pump = float(candle_dna.get("pump_pct") or 0.0)
    dump = float(candle_dna.get("dump_pct") or 0.0)
    reg = str(candle_dna.get("regime") or "").lower()

    def _match_single_blueprint(bp_leg: Dict[str, Any]) -> bool:
        if str(bp_leg.get("asset_class") or "").upper() != ac_up:
            return False
        leg_side_u = str(bp_leg.get("side") or "LONG").upper()
        req_gate = str(bp_leg.get("veto_gate_match") or "").upper()
        if req_gate:
            if not gate_u or req_gate not in gate_u:
                return False
            # [BOM #87 CRITICAL-1 FIX]: GATE_INV / SLOT_B2 chi duoc phep LAT NGUOC chieu lenh bi chan (blocked_direction phai doi nghich!)
            if blk_u not in ("LONG", "SHORT"):
                return False
            if (leg_side_u == "LONG" and blk_u != "SHORT") or (leg_side_u == "SHORT" and blk_u != "LONG"):
                return False
            if "JEV_SHIELD" in req_gate:
                expected_jev = "BUY" if leg_side_u == "LONG" else "SELL"
                if jev_u != expected_jev:
                    return False
        req_fams = [str(f) for f in (bp_leg.get("pathway_families") or []) if f and f != "ANY"]
        if not req_fams:
            pf_one = str(bp_leg.get("pathway_family") or "")
            if pf_one and pf_one not in ("ANY", "BOTH_2WAY"):
                req_fams = [pf_one]
        if req_fams:
            need_toks = [fam_check.get(f, "") for f in req_fams if fam_check.get(f, "")]
            if need_toks and not any(tok in strat_tokens for tok in need_toks):
                return False
        req_ai_list = [str(a).upper() for a in (bp_leg.get("ai_votes") or []) if a]
        # [BOM #118C FIX]: Khi Tang 3 dang o trang thai T3_EXTREME_AI_CONFLICT (AI Ensemble doi khang >= 70%),
        # chi cho phep Vu Khi Dong kich hoat neu vu khi do KHAI BAO TUONG MINH ai_votes khop voi chieu AI hien tai
        # (nhu VK13 voi ai_votes=['BUY']) hoac co veto_gate_match == T3_EXTREME_AI_CONFLICT (chan VK11 ai_votes=[]!).
        if gate_u == "T3_EXTREME_AI_CONFLICT" and not req_gate:
            if not req_ai_list or "ANY" in {a.upper() for a in req_ai_list}:
                return False
        if req_ai_list:
            # [BOM #120F FIX]: Phân biệt rõ NONE vs HOLD khi blueprint khai báo tường minh 1 giá trị (tránh VK14 cướp VK15!)
            norm_ai_req = {a.upper() for a in req_ai_list if a}
            if "NONE" in norm_ai_req and "HOLD" in norm_ai_req:
                norm_ai_req.add("")
            _eff_ai_u = ai_u or "NONE"
            if "ANY" not in norm_ai_req and _eff_ai_u not in norm_ai_req:
                return False
        else:
            req_ai = str(bp_leg.get("ai_vote") or "NONE").upper()
            if req_ai not in ("NONE", "ANY", "HOLD", "MULTI", "") and ai_u != req_ai:
                return False
        req_jev_list = [str(j).upper() for j in (bp_leg.get("jev_votes") or []) if j]
        if req_jev_list:
            norm_jev_req = set(req_jev_list)
            if "NONE" in norm_jev_req or "SKIP" in norm_jev_req or "HOLD" in norm_jev_req:
                norm_jev_req.update({"NONE", "SKIP", "HOLD"})
            if "ANY" not in norm_jev_req and jev_u not in norm_jev_req:
                return False
        else:
            req_jev = str(bp_leg.get("jev_vote") or "NONE").upper()
            if req_jev not in ("NONE", "ANY", "SKIP", "HOLD", "MULTI", "") and jev_u != req_jev:
                return False
        rules = bp_leg.get("dna_rules") or {}
        # [BOM #119C FIX] [BOM #121H FIX]: Chi ap dung san rau vat ly ngam dinh (35%) khi danh THUAN CHIEU TRAP (SHORT voi TRAP_SELL, LONG voi TRAP_BUY),
        # khong tu y them cong live-only uw>=28% len cac lenh lat nguoc chieu nhu VK14/VK15!
        if req_fams == ["TRAP_SELL"] and leg_side_u == "SHORT" and "uw_min" not in rules:
            if uw < 35.0:
                return False
        elif req_fams == ["TRAP_BUY"] and leg_side_u == "LONG" and "lw_min" not in rules:
            if lw < 35.0:
                return False
        if "atr_min" in rules and atr < float(rules["atr_min"]):
            return False
        if "rvol_min" in rules and rvol < float(rules["rvol_min"]):
            return False
        if "adx_min" in rules and adx < float(rules["adx_min"]):
            return False
        if "adx_max" in rules and adx > float(rules["adx_max"]):
            return False
        if "rsi_min" in rules and rsi < float(rules["rsi_min"]):
            return False
        if "rsi_max" in rules and rsi > float(rules["rsi_max"]):
            return False
        if "uw_min" in rules and uw < float(rules["uw_min"]):
            return False
        if "uw_max" in rules and uw >= float(rules["uw_max"]):
            return False
        if "lw_min" in rules and lw < float(rules["lw_min"]):
            return False
        if "lw_max" in rules and lw >= float(rules["lw_max"]):
            return False
        if rules.get("no_twin_wick") and uw >= 28.0 and lw >= 28.0:
            return False
        if "wave_min" in rules:
            if _resolve_wave_for_dna(leg_side_u, pump, dump) < float(rules["wave_min"]):
                return False
        if rules.get("avoid_strong_opp"):
            if leg_side_u == "LONG" and "strong_downtrend" in reg:
                return False
            if leg_side_u == "SHORT" and "strong_uptrend" in reg:
                return False
        return True

    # [BOM #94 + #121H FIX]: Priority tuong minh >0 (vd VK15=82, VK14=81) xep TRUOC gate_rank de khong bi VK11 (0) cuop mat!
    def _dyn_priority(item_kv: Tuple[str, Dict[str, Any]]) -> Tuple[int, int, int, int, int]:
        _w_k, _d_v = item_kv
        _bp_p = _d_v.get("blueprint") or {}
        _pref_rank = 0 if (preferred_weapon_id and _w_k == preferred_weapon_id) else 1
        _pri_val = int(_d_v.get("priority") or 0)
        _has_exp_pri = 0 if _pri_val > 0 else 1
        _vg_p = str(_bp_p.get("veto_gate_match") or "").upper()
        _gate_rank = 0 if (gate_u and _vg_p and _vg_p in gate_u) else 1
        # [BOM #98 FIX]: Tinh so dna_rules cho ca vu khi 2 chieu BOTH (luu trong blueprint['legs'])!
        _rules_cnt = len(_bp_p.get("dna_rules") or {})
        if _rules_cnt == 0 and isinstance(_bp_p.get("legs"), dict):
            _rules_cnt = max(
                (len((lg or {}).get("dna_rules") or {}) for lg in _bp_p["legs"].values() if isinstance(lg, dict)),
                default=0,
            )
        return (_pref_rank, _has_exp_pri, -_pri_val, _gate_rank, -_rules_cnt)

    _states_lc = lc.get("states") or {}
    for wid, dw in sorted(dyn_map.items(), key=_dyn_priority):
        if _states_lc.get(wid, dw.get("state")) not in ("OFFICIAL", "EXPERIMENTAL"):
            continue
        bp = dw.get("blueprint") or {}
        if str(bp.get("side") or "").upper() == "BOTH" and isinstance(bp.get("legs"), dict):
            # Vu khi Linh Hoat 2 Chieu: danh gia ca 2 chan doc lap; neu ca 2 deu khop thi uu tien chan thuan JEV 4H (tranh ep cung SHORT)
            matched_legs = []
            for leg_side in ("LONG", "SHORT"):
                leg_bp = bp["legs"].get(leg_side)
                if isinstance(leg_bp, dict) and _match_single_blueprint(leg_bp):
                    matched_legs.append((leg_side, leg_bp))
            if len(matched_legs) == 1:
                chosen_side, chosen_bp = matched_legs[0]
            elif len(matched_legs) == 2:
                if jev_u == "BUY":
                    chosen_side, chosen_bp = matched_legs[0]
                elif jev_u == "SELL":
                    chosen_side, chosen_bp = matched_legs[1]
                else:
                    continue  # hoa khong ro chieu -> khong doan mo
            else:
                continue
            matched_copy = dict(dw)
            matched_copy["_resolved_side"] = chosen_side
            matched_copy["blueprint"] = chosen_bp
            return matched_copy
        if _match_single_blueprint(bp):
            matched_copy = dict(dw)
            matched_copy["_resolved_side"] = str(bp.get("side") or dw.get("side") or "LONG").upper()
            return matched_copy
    return None


def _resolve_wave_for_dna(side: str, pump: Any, dump: Any) -> float:
    """[BOM #122C FIX]: Nguon chan ly duy nhat cho wave_min (khop 100% Lens L15 LAB OOS vs Live): LONG do pump, SHORT do dump."""
    return float(pump or 0.0) if str(side or "LONG").upper() == "LONG" else float(dump or 0.0)


def _check_dna_rules(rules: Dict[str, Any], row: Dict[str, Any], side: str = "LONG") -> bool:
    if not rules:
        return True
    if "atr_min" in rules and float(row.get("atr", 0.0)) < float(rules["atr_min"]):
        return False
    if "rvol_min" in rules and float(row.get("rvol", 0.0)) < float(rules["rvol_min"]):
        return False
    if "adx_min" in rules and float(row.get("adx", 0.0)) < float(rules["adx_min"]):
        return False
    if "adx_max" in rules and float(row.get("adx", 0.0)) > float(rules["adx_max"]):
        return False
    if "rsi_min" in rules and float(row.get("rsi", 50.0)) < float(rules["rsi_min"]):
        return False
    if "rsi_max" in rules and float(row.get("rsi", 50.0)) > float(rules["rsi_max"]):
        return False
    if "uw_min" in rules and float(row.get("uw", 0.0)) < float(rules["uw_min"]):
        return False
    if "uw_max" in rules and float(row.get("uw", 0.0)) >= float(rules["uw_max"]):
        return False
    if "lw_min" in rules and float(row.get("lw", 0.0)) < float(rules["lw_min"]):
        return False
    if "lw_max" in rules and float(row.get("lw", 0.0)) >= float(rules["lw_max"]):
        return False
    if rules.get("no_twin_wick") and float(row.get("uw", 0.0)) >= 28.0 and float(row.get("lw", 0.0)) >= 28.0:
        return False
    if "wave_min" in rules:
        if _resolve_wave_for_dna(side, row.get("pump"), row.get("dump")) < float(rules["wave_min"]):
            return False
    if rules.get("avoid_strong_opp"):
        reg = str(row.get("reg") or "").lower()
        if str(side or "LONG").upper() == "LONG" and "strong_downtrend" in reg:
            return False
        if str(side or "LONG").upper() == "SHORT" and "strong_uptrend" in reg:
            return False
    return True


def audit_and_optimize_existing_weapons(db_path: str = "data/trade_bot.db") -> Dict[str, Any]:
    """[V6.2 BOM #84]: Kiem toan & Toi uu phoi 2-4 tang DNA cho CHINH 10 VU KHI CU (VK1..VK10)
    tren toan bo kho du lieu Shadow + Live (100% Offline, PRAGMA query_only=ON):
    - De xuat thau kinh DNA (qua OOS) giup giam SL/Timeout cho tung vu khi cu.
    - Tinh Ma tran Trung Lap giua VK1..VK10.
    - Cham diem Luat 3 Ky (GIU / THEO DOI / TAM TAT DE XUAT)."""
    resolved = db_path if os.path.isabs(db_path) else os.path.join(_ROOT_DIR, db_path)
    lc = load_weapon_lifecycle()
    out_weapons: List[Dict[str, Any]] = []
    if not os.path.exists(resolved):
        return {"weapons": [], "overlaps": [], "db_summary": {}}

    con = None
    try:
        con = sqlite3.connect(f"file:{resolved}?mode=ro", uri=True, timeout=5.0)
        con.execute("PRAGMA query_only = ON;")
        srows = con.execute("""
            SELECT id, timestamp, symbol, direction, asset_class, rvol, outcome, details_json
            FROM shadow_pathfinder_logs
            WHERE outcome IN ('TP1_HIT', 'SL_HIT', 'TIMEOUT_60M', 'TIMEOUT_240M')
            ORDER BY timestamp ASC, id ASC
        """).fetchall()
    finally:
        if con is not None:
            try:
                con.close()
            except Exception:
                pass

    from core.vietnamese_weapon_arsenal import WEAPON_ARSENAL_CATALOG, classify_signal_weapon
    # [BOM #106D FIX]: Gop ca cac vu khi dong (DYN-VK11..14) vao combined_catalog de Kiem Toan 10+ Vu Khi
    # tren Web bao cao day du cho ca VK1..VK10 lan VK11..14!
    combined_catalog: Dict[str, Dict[str, Any]] = dict(WEAPON_ARSENAL_CATALOG)
    for _dwid, _dw_meta in (lc.get("dynamic_weapons") or {}).items():
        if isinstance(_dw_meta, dict) and str(_dw_meta.get("state") or "") != "DELETED":
            combined_catalog[_dwid] = _dw_meta

    by_wid: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    wid_sample_ids: Dict[str, set] = defaultdict(set)
    cnt_240m = 0
    cnt_wid_present = 0
    ac_counter: Counter = Counter()
    seen = set()

    for rid, ts, sym, d, ac, rv, out_v, dj_raw in srows:
        ts_s = (ts / 1000.0) if (ts and ts > 1e11) else float(ts or 0)
        dk = (str(sym).upper(), str(d).upper(), int(ts_s // 900))
        if dk in seen:
            continue
        seen.add(dk)
        dj = {}
        try:
            dj = json.loads(dj_raw or "{}") if dj_raw else {}
        except Exception:
            pass
        if dj.get("dual_eval_240m"):
            cnt_240m += 1
        if dj.get("weapon_id"):
            cnt_wid_present += 1
        _sub_w = _normalize_shadow_row_asset_subclass(sym, ac or dj.get("asset_class"))
        ac_u = "TRADFI" if "TRADFI" in _sub_w else ("MAJOR" if _sub_w == "MAJOR" else "ALTCOIN")
        ac_counter[ac_u] += 1
        l2 = dj.get("layer2_candle_dna") or {}
        l3 = dj.get("layer3_consensus_dna") or {}
        dual = dj.get("dual_eval_240m") or dj.get("dual_eval_60m") or {}
        d_str = str(d or "LONG").upper()
        setup_up = str(dj.get("primary_setup_type") or "").upper()
        path_up = str(dj.get("tech_pathway_key") or "").upper()
        gate_up = str(dj.get("layer4_exact_veto_gate") or "").upper()
        b_str = str(dj.get("block_reason") or "").upper()
        rsi_v = float(l2.get("rsi") or 50.0)
        adx_v = float(l2.get("adx") or 0.0)
        atr_v = float(l2.get("atr_pct") or 0.0)
        reg_v = str(l2.get("regime") or "").lower()
        uw_v = float(l2.get("u_wick_pct") or 0.0)
        lw_v = float(l2.get("l_wick_pct") or 0.0)
        pump_v = float(l2.get("pump_pct") or 0.0)
        dump_v = float(l2.get("dump_pct") or 0.0)
        rv_v = float(l2.get("rvol") if l2.get("rvol") is not None else (rv if rv is not None else 1.0))
        ai_v_sh = str(l3.get("ai_vote") or "").upper()
        jev_v = str(l3.get("jev_vote") or "").upper()
        explicit_w = str(dj.get("weapon_id") or "")

        is_vk9_sh = (
            ac_u == "ALTCOIN" and "TRAP_DETECTOR:SELL" in path_up and "TREND_FOLLOWING:BUY" in path_up
            and ai_v_sh == "SELL" and jev_v == "BUY" and gate_up == "T3_JEV_SHIELD_NEED_2_STRATS"
            and uw_v >= 65.0 and lw_v < 25.0 and rsi_v < 65.0 and rv_v >= 1.33 and adx_v >= 20.0
        )
        is_vk10_sh = (
            ac_u == "TRADFI" and "TRAP_DETECTOR:BUY" in path_up and ai_v_sh == "BUY" and jev_v == "SELL"
            and atr_v >= 0.38 and (0.0 < adx_v <= 30.0) and ("strong_downtrend" not in reg_v)
            and lw_v >= 38.0 and rsi_v >= 33.0 and rv_v >= 0.85
        )
        # [BOM #108D + #124B FIX]: Dong bo 100% logic phan loai giua get_living_arsenal_status va audit_and_optimize_existing_weapons
        eff_dir = d_str
        if explicit_w in combined_catalog and bool(combined_catalog[explicit_w].get("is_dynamic")):
            wid = explicit_w
            _dyn_cat = combined_catalog[explicit_w] or {}
            _dyn_side = str(_dyn_cat.get("side") or "").upper()
            _dyn_slot = str(((_dyn_cat.get("blueprint") or {}).get("slot")) or _dyn_cat.get("slot") or "").upper()
            if (_dyn_side in ("LONG", "SHORT") and _dyn_side != d_str) or ("SLOT_B2" in _dyn_slot and _dyn_side not in ("LONG", "SHORT")):
                eff_dir = "SHORT" if d_str == "LONG" else "LONG"
        elif is_vk9_sh:
            wid = "VK9_SHORT_BAN_DINH_RAU_CUC_DAI"
            eff_dir = "SHORT"
        elif is_vk10_sh:
            wid = "VK10_LONG_MUA_DAY_RUT_CHAN_TRADFI"
            eff_dir = "LONG"
        elif ac_u == "ALTCOIN" and d_str == "SHORT" and jev_v == "BUY" and "TRAP_DETECTOR:SELL" in path_up and rsi_v >= 65.0 and 1.10 <= rv_v <= 3.50:
            wid = "VK2_LONG_LAT_NGUOC_SONG_PARABOL"
            eff_dir = "LONG"
        elif explicit_w in combined_catalog:
            wid = explicit_w
            _w_cat = combined_catalog[explicit_w] or {}
            _w_side = str(_w_cat.get("side") or "").upper()
            if _w_side in ("LONG", "SHORT") and _w_side != d_str:
                eff_dir = _w_side
        elif d_str == "LONG" and (setup_up in ("SELLING_CLIMAX", "PANIC_CLIMAX_BOUNCE", "OVERSOLD_BOUNCE") or (rsi_v <= 50.0 and lw_v >= 35.0 and "BEAR_TRAP" not in setup_up)):
            wid = "VK4_LONG_BAT_NAY_QUA_BAN"
        else:
            if d_str == "LONG":
                if setup_up == "BEAR_TRAP_WICK" or lw_v >= 35.0 or ("TRAP" in path_up and lw_v >= 25.0):
                    wid = "VK3_LONG_SAN_RU_GOM_DAY"
                elif rv_v >= 1.80 or pump_v >= 1.20 or "BREAKOUT" in path_up:
                    wid = "VK1_LONG_THUAN_SONG_CA_MAP"
                else:
                    wid = "VK8_THUAN_XU_HUONG_DA_KHUNG"
            else:
                if setup_up == "BUYING_CLIMAX" or (uw_v >= 35.0 and pump_v >= 1.00) or "FADING" in b_str:
                    wid = "VK6_SHORT_BAT_DINH_KIET_SUC"
                elif setup_up == "BULL_TRAP_WICK" or uw_v >= 35.0 or "TRAP_DETECTOR" in path_up:
                    wid = "VK7_SHORT_BAY_TANG_GIA_RAU_XA"
                elif dump_v >= 1.20 or rv_v >= 1.50:
                    wid = "VK5_SHORT_THAC_DO_CA_MAP_XA"
                else:
                    wid = "VK8_THUAN_XU_HUONG_DA_KHUNG"
        if wid not in combined_catalog:
            continue
        _ex_max_up = float(dual.get("max_up_pct_240m") or dual.get("max_up_pct_60m") or 0.0)
        _ex_max_dn = float(dual.get("max_down_pct_240m") or dual.get("max_down_pct_60m") or 0.0)
        _ex_sl_dp = float(dual.get("sl_dist_pct") or (1.0 if "TRADFI" in ac_u else (1.2 if "MAJOR" in ac_u else 1.8)))
        item = {
            "id": rid, "ts": ts_s, "sym": str(sym).upper(), "ac": ac_u, "dir": eff_dir,
            "rsi": rsi_v, "adx": adx_v,
            "atr": atr_v, "rvol": rv_v,
            "uw": uw_v, "lw": lw_v,
            "pump": pump_v, "dump": dump_v,
            "reg": reg_v, "gate": gate_up,
            "tpk": path_up, "ai": ai_v_sh, "jev": jev_v,
            "l11": str(dual.get("long_1to1") or ""), "s11": str(dual.get("short_1to1") or ""),
            "max_up_pct": _ex_max_up, "max_down_pct": _ex_max_dn, "sl_dist_pct": _ex_sl_dp,
        }
        by_wid[wid].append(item)
        wid_sample_ids[wid].add(rid)

        # Khop them cho cac Vu Khi Dong (VK11..14) theo day du blueprint (asset_class, gate, JEV shield, pathway, ai, jev, dna_rules)
        _fam_tok_map_aud = {
            "TRAP_BUY": "TRAP_DETECTOR:BUY", "TRAP_SELL": "TRAP_DETECTOR:SELL",
            "MEANREV_BUY": "MEAN_REVERSION:BUY", "MEAN_REVERSION_SELL": "MEAN_REVERSION:SELL",
            "MEANREV_SELL": "MEAN_REVERSION:SELL", "BREAKOUT_BUY": "MOMENTUM_BREAKOUT:BUY",
            "BREAKOUT_SELL": "MOMENTUM_BREAKOUT:SELL", "TREND_BUY": "TREND_FOLLOWING:BUY",
            "TREND_SELL": "TREND_FOLLOWING:SELL",
        }
        for _dwid, _dw_m in combined_catalog.items():
            if not bool(_dw_m.get("is_dynamic")) or wid == _dwid:
                continue
            _bp_d = _dw_m.get("blueprint") or {}
            if str(_bp_d.get("asset_class") or "ALTCOIN").upper() != ac_u:
                continue
            _vg_d = str(_bp_d.get("veto_gate_match") or "").upper()
            if _vg_d and _vg_d not in gate_up:
                continue
            _legs_d = _bp_d.get("legs") if (_bp_d.get("side") == "BOTH" and isinstance(_bp_d.get("legs"), dict)) else {str(_bp_d.get("side") or "LONG").upper(): _bp_d}
            _bp_fams_d = [str(f) for f in (_bp_d.get("pathway_families") or []) if f] or ([str(_bp_d.get("pathway_family") or "")] if _bp_d.get("pathway_family") else [])
            _bp_side_d = str(_bp_d.get("side") or "").upper()
            _is_bp_inverted = (
                bool(_vg_d)
                or str(_bp_d.get("slot") or "") == "SLOT_B2"
                or any((f.endswith("_SELL") and _bp_side_d == "LONG") or (f.endswith("_BUY") and _bp_side_d == "SHORT") for f in _bp_fams_d)
            )
            _inv_d = "SHORT" if d_str == "LONG" else "LONG"
            _leg_side_match = _inv_d if _is_bp_inverted else d_str
            _leg_cfg = (_legs_d or {}).get(_leg_side_match)
            if not isinstance(_leg_cfg, dict):
                continue
            if _vg_d and "JEV_SHIELD" in _vg_d:
                _exp_jev_d = "BUY" if _leg_side_match == "LONG" else "SELL"
                if jev_v != _exp_jev_d:
                    continue
            _req_fams_d = [str(f) for f in (_leg_cfg.get("pathway_families") or []) if f and f != "ANY"]
            if not _req_fams_d:
                _pf_d = str(_leg_cfg.get("pathway_family") or "")
                if _pf_d and _pf_d not in ("ANY", "BOTH_2WAY"):
                    _req_fams_d = [_pf_d]
            if _req_fams_d:
                _need_t_d = [_fam_tok_map_aud.get(f, "") for f in _req_fams_d if _fam_tok_map_aud.get(f, "")]
                if _need_t_d and not any(tok in path_up for tok in _need_t_d):
                    continue
            _req_ai_l = [str(a).upper() for a in (_leg_cfg.get("ai_votes") or []) if a]
            if _req_ai_l:
                _norm_ai_l = set(_req_ai_l)
                if "NONE" in _norm_ai_l and "HOLD" in _norm_ai_l:
                    _norm_ai_l.add("")
                if "ANY" not in _norm_ai_l and (ai_v_sh or "NONE") not in _norm_ai_l:
                    continue
            _req_jev_l = [str(j).upper() for j in (_leg_cfg.get("jev_votes") or []) if j]
            if _req_jev_l:
                _norm_jev_l = set(_req_jev_l)
                if "NONE" in _norm_jev_l or "SKIP" in _norm_jev_l or "HOLD" in _norm_jev_l:
                    _norm_jev_l.update({"NONE", "SKIP", "HOLD"})
                if "ANY" not in _norm_jev_l and (jev_v or "NONE") not in _norm_jev_l:
                    continue
            if _check_dna_rules(_leg_cfg.get("dna_rules") or {}, item, side=_leg_side_match):
                _dyn_item = dict(item)
                _dyn_item["dir"] = _leg_side_match
                by_wid[_dwid].append(_dyn_item)
                wid_sample_ids[_dwid].add(rid)

    for wid, meta_w in combined_catalog.items():
        w_rows = by_wid.get(wid) or []
        w_side = str(meta_w.get("side") or "BOTH").upper()
        eval_side = "LONG" if w_side == "LONG" else ("SHORT" if w_side == "SHORT" else "LONG")
        if w_side == "BOTH":
            # [BOM #102D + #103K FIX]: Chuan hoa rau, pump/dump, rsi, max_up/down VA regime (strong_uptrend<->strong_downtrend) cho VK8!
            norm_rows = []
            for r in w_rows:
                rr = dict(r)
                if r["dir"] == "SHORT":
                    rr["l11"] = r["s11"]
                    rr["uw"], rr["lw"] = r["lw"], r["uw"]
                    rr["pump"], rr["dump"] = r["dump"], r["pump"]
                    rr["max_up_pct"], rr["max_down_pct"] = r["max_down_pct"], r["max_up_pct"]
                    rr["rsi"] = round(100.0 - float(r.get("rsi", 50.0)), 2)
                    _rg_s = str(r.get("reg") or "")
                    if "strong_uptrend" in _rg_s:
                        rr["reg"] = _rg_s.replace("strong_uptrend", "strong_downtrend")
                    elif "strong_downtrend" in _rg_s:
                        rr["reg"] = _rg_s.replace("strong_downtrend", "strong_uptrend")
                norm_rows.append(rr)
            w_eval_rows = norm_rows
            eval_side = "LONG"
        else:
            w_eval_rows = w_rows
        valid_rows = [r for r in w_eval_rows if (r["l11"] if eval_side == "LONG" else r["s11"]) in ("TP1_HIT", "SL_HIT", "TIMEOUT_60M", "TIMEOUT_240M")]
        raw_st = _eval_lab_subset(valid_rows, eval_side)
        by_ac_stats = {}
        for _ac_k in ("ALTCOIN", "MAJOR", "TRADFI"):
            _ac_sub = [r for r in valid_rows if (_ac_k in r["ac"] if _ac_k != "ALTCOIN" else ("TRADFI" not in r["ac"] and "MAJOR" not in r["ac"]))]
            if _ac_sub:
                by_ac_stats[_ac_k] = _eval_lab_subset(_ac_sub, eval_side)
        _sl_u_w = 1.0 if "TRADFI" in wid else 1.8
        raw_net = round(((raw_st["tp"] * _sl_u_w - raw_st["sl"] * _sl_u_w - raw_st.get("to_adverse", 0) * (_sl_u_w * 0.50) - raw_st["n"] * 0.12) / 100.0) * 80.0, 2)

        # Chay 20 Thau Kinh DNA (Chon duy nhat 1 thau kinh tot nhat tren IS truoc, sau do moi kiem dinh OOS - Zero Leakage!)
        ac_hint = "TRADFI" if "TRADFI" in wid else "ALTCOIN"
        lenses = _build_20_vietnamese_dna_lenses(ac_hint, eval_side)
        best_is_candidate = None
        for ln in lenses[1:]:
            sub = [x for x in valid_rows if ln["fn"](x)]
            if len(sub) < max(8, int(len(valid_rows) * 0.25)):
                continue
            split_idx = max(1, int(len(sub) * 0.70))
            st_is = _eval_lab_subset(sub[:split_idx], eval_side)
            st_is_raw = _eval_lab_subset(valid_rows[:max(1, int(len(valid_rows) * 0.70))], eval_side)
            is_net = round(((st_is["tp"] * _sl_u_w - st_is["sl"] * _sl_u_w - st_is.get("to_adverse", 0) * (_sl_u_w * 0.50) - st_is["n"] * 0.12) / 100.0) * 80.0, 2)
            if (
                is_net > 0.0
                and st_is["res_sl_rate"] <= 25.0
                and (st_is["sl_rate"] <= st_is_raw["sl_rate"] - 3.0)
                and (st_is["strict_tp"] >= st_is_raw["strict_tp"] + 3.0)
            ):
                sc = (st_is["strict_tp"] - st_is["res_sl_rate"] * 2.0, is_net, st_is["n"])
                if best_is_candidate is None or sc > best_is_candidate[0]:
                    best_is_candidate = (sc, ln["name_vi"], sub)

        best_ref = None
        if best_is_candidate is not None:
            sc_best, best_ln_name, sub_best = best_is_candidate
            st = _eval_lab_subset(sub_best, eval_side)
            oos_ok, oos_st, oos_lbl = _eval_adaptive_oos(sub_best, eval_side)
            ref_net = round(((st["tp"] * _sl_u_w - st["sl"] * _sl_u_w - st.get("to_adverse", 0) * (_sl_u_w * 0.50) - st["n"] * 0.12) / 100.0) * 80.0, 2)
            if oos_ok and ref_net > 0.0 and st["res_sl_rate"] <= 25.0:
                best_ref = (sc_best, best_ln_name, st, oos_st, oos_lbl, ref_net)

        state_cur = lc["states"].get(wid, "OFFICIAL")
        if raw_st["n"] < 30:
            rule3 = "GIỮ / TÍCH LŨY (N<30)"
        elif raw_net > 0 and raw_st.get("res_sl_rate", 100.0) <= 25.0:
            rule3 = "✅ GIỮ CHÍNH THỨC (Dương bền)"
        elif raw_net < 0:
            rule3 = "⚠️ CẦN TINH CHỈNH / XEM XÉT PAUSE"
        else:
            rule3 = "🟡 THEO DÕI THÊM"

        out_weapons.append({
            "id": wid,
            "code": meta_w.get("code", ""),
            "name_vi": meta_w.get("short_name", wid),
            "side": w_side,
            "state": state_cur,
            "raw": raw_st,
            "by_asset_class": by_ac_stats,
            "raw_net_usd": raw_net,
            "rule3_verdict": rule3,
            "best_refinement": (
                {
                    "lens_name_vi": best_ref[1],
                    "n": best_ref[2]["n"],
                    "strict_tp": best_ref[2]["strict_tp"],
                    "sl_rate": best_ref[2]["sl_rate"],
                    "oos_mode": best_ref[4],
                    "oos_sl_rate": best_ref[3]["sl_rate"],
                    "net_usd": best_ref[5],
                    "sl_delta_pp": round(best_ref[2]["sl_rate"] - raw_st["sl_rate"], 1),
                    "tp_delta_pp": round(best_ref[2]["strict_tp"] - raw_st["strict_tp"], 1),
                }
                if best_ref is not None
                else None
            ),
        })

    # Tinh ma tran trung lap giua VK2/VK9/VK10 & cac vu khi
    overlaps = []
    vk_keys = list(wid_sample_ids.keys())
    for i in range(len(vk_keys)):
        for j in range(i + 1, len(vk_keys)):
            a, b = vk_keys[i], vk_keys[j]
            sa, sb = wid_sample_ids[a], wid_sample_ids[b]
            if not sa or not sb:
                continue
            ov = len(sa & sb)
            if ov > 0:
                pct = round(ov / max(1, min(len(sa), len(sb))) * 100.0, 1)
                if pct >= 15.0:
                    overlaps.append({"a": a, "b": b, "shared": ov, "pct": pct})

    return {
        "db_summary": {
            "total_dedup_samples": len(seen),
            "samples_240m": cnt_240m,
            "weapon_id_coverage_pct": round(cnt_wid_present / max(1, len(seen)) * 100.0, 1),
            "by_asset_class": dict(ac_counter),
        },
        "weapons": out_weapons,
        "overlaps": overlaps,
    }
