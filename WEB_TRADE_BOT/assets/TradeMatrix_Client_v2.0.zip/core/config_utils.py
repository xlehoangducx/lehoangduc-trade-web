# -*- coding: utf-8 -*-
"""Atomic YAML and settings file helpers preserving comments and structure."""

from __future__ import annotations

import logging
import os
import shutil
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

import yaml

logger = logging.getLogger(__name__)

_SETTINGS_YAML_LOCK = threading.RLock()
_STRATEGIES_YAML_LOCK = threading.RLock()
_CONFIG_YAML_LOCK = threading.RLock()


def get_yaml_lock(file_path: str | Path) -> threading.RLock:
    """Return a shared module-level RLock protecting concurrent writes to a YAML file."""
    name = Path(file_path).name.lower()
    if name == 'strategies.yaml':
        return _STRATEGIES_YAML_LOCK
    if name == 'settings.yaml':
        return _SETTINGS_YAML_LOCK
    return _CONFIG_YAML_LOCK

REQUIRED_SETTINGS_SECTIONS = (
    'ai', 'bot', 'cloud', 'dashboard', 'database', 'exchange',
    'notifications', 'quantum_gate', 'risk', 'tradfi', 'trading',
)


def atomic_write_text(
    file_path: str | Path,
    payload: str,
    *,
    create_backup: bool = True,
    verify_yaml: bool = False,
    required_sections: Optional[Iterable[str]] = None,
) -> Path:
    """Write text atomically (mkstemp + flush + fsync + optional .bak + os.replace)."""
    target = Path(file_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if not payload or not payload.strip():
        raise ValueError(f'Refuse to write empty payload to {target.name}')

    if verify_yaml or required_sections:
        loaded = yaml.safe_load(payload)
        if not isinstance(loaded, dict):
            raise ValueError(f'{target.name} YAML payload must be a mapping')
        if required_sections:
            missing = [key for key in required_sections if key not in loaded]
            if missing:
                raise ValueError(f'Refuse to write incomplete {target.name}; missing={missing}')

    with get_yaml_lock(target):
        fd, temp_name = tempfile.mkstemp(
            prefix=f'.{target.name}.{os.getpid()}.{threading.get_ident()}.',
            suffix='.tmp',
            dir=str(target.parent),
        )
        temp_path = Path(temp_name)
        backup_path = target.with_name(target.name + '.bak')
        try:
            with os.fdopen(fd, 'w', encoding='utf-8', newline='') as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            if create_backup and target.exists():
                try:
                    shutil.copy2(target, backup_path)
                except Exception as e:
                    logger.warning('Không tạo được bản sao lưu %s: %s', target.name, e)
            os.replace(temp_path, target)
        finally:
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except OSError:
                    pass
    return backup_path


def _format_yaml_scalar(value: Any) -> str:
    if value is None:
        return 'null'
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    needs_quote = (
        text == ''
        or text != text.strip()
        or text.lower() in ('true', 'false', 'null', 'none', 'yes', 'no', 'on', 'off', '~')
        or text[0] in ('-', '?', ':', '[', ']', '{', '}', '&', '*', '#', '!', '|', '>', "'", '"', '%', '@', '`', ',')
        or any(ch in text for ch in (':', '#', '\n', '\r', '"', "'", '[', ']', '{', '}'))
    )
    if not needs_quote:
        try:
            parsed = yaml.safe_load(text)
            if not isinstance(parsed, str) or parsed != text:
                needs_quote = True
        except Exception:
            needs_quote = True
    if needs_quote:
        escaped = text.replace("'", "''")
        return f"'{escaped}'"
    return text


def update_yaml_section_key(
    file_path: str | Path,
    section: str,
    updates: Dict[str, Any],
    *,
    required_sections: Optional[Iterable[str]] = REQUIRED_SETTINGS_SECTIONS,
) -> Path:
    """Update top-level section key(s) in a YAML file in-place atomically, preserving comments."""
    target = Path(file_path)
    with get_yaml_lock(target):
        raw = target.read_bytes().decode('utf-8-sig')
        lines = raw.splitlines(keepends=True)

        sec_start = next((i for i, line in enumerate(lines) if not line[:1].isspace() and line.split('#', 1)[0].strip() == f'{section}:'), None)
        if sec_start is None:
            raise ValueError(f"Không tìm thấy mục '{section}:' trong {target.name}")

        sec_end = len(lines)
        for i in range(sec_start + 1, len(lines)):
            stripped = lines[i].strip()
            if stripped and not stripped.startswith('#') and not lines[i][0].isspace():
                sec_end = i
                break

        default_nl = next(
            ('\r\n' if line.endswith('\r\n') else '\n' for line in lines if line.endswith(('\r\n', '\n'))),
            '\n',
        )
        child_indent = next(
            (
                lines[i][:len(lines[i]) - len(lines[i].lstrip())]
                for i in range(sec_start + 1, sec_end)
                if lines[i].strip() and not lines[i].strip().startswith('#') and lines[i][0].isspace()
            ),
            '  ',
        )

        for key, value in updates.items():
            val_str = _format_yaml_scalar(value)
            line_idx = next(
                (
                    i for i in range(sec_start + 1, sec_end)
                    if (lines[i][:len(lines[i]) - len(lines[i].lstrip())] == child_indent)
                    and lines[i].lstrip().startswith(f'{key}:')
                ),
                None,
            )
            if line_idx is not None:
                current_line = lines[line_idx]
                indent = current_line[:len(current_line) - len(current_line.lstrip())]
                newline = '\r\n' if current_line.endswith('\r\n') else ('\n' if current_line.endswith('\n') else default_nl)
                body_no_nl = current_line.rstrip('\r\n')
                comment = ''
                in_sq = False
                in_dq = False
                for idx_c, ch in enumerate(body_no_nl):
                    if ch == "'" and not in_dq:
                        in_sq = not in_sq
                    elif ch == '"' and not in_sq:
                        in_dq = not in_dq
                    elif ch == '#' and not in_sq and not in_dq and idx_c > 0 and body_no_nl[idx_c - 1].isspace():
                        comment = f"  {body_no_nl[idx_c:].rstrip()}"
                        break
                lines[line_idx] = f'{indent}{key}: {val_str}{comment}{newline}'
            else:
                insert_at = sec_end
                while insert_at > sec_start + 1 and not lines[insert_at - 1].strip():
                    insert_at -= 1
                lines.insert(insert_at, f'{child_indent}{key}: {val_str}{default_nl}')
                sec_end += 1

        payload = ''.join(lines)
        return atomic_write_text(
            target,
            payload,
            create_backup=True,
            verify_yaml=True,
            required_sections=required_sections,
        )
