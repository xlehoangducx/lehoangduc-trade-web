"""
TRADE BOT - Bot Engine Chính
Điều phối tất cả các components: thu thập dữ liệu, phân tích chiến lược,
tổng hợp tín hiệu, quản lý rủi ro, và thực thi lệnh.
"""

import logging
import time
import yaml
import json
import os
import sys
import math
import warnings
warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass
import re
import threading
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

# Thêm root directory vào path
ROOT_DIR = Path(__file__).parent.parent
MIN_STOP_MARKET_BUFFER_PCT = 0.0022
# [SỔ VỐN] Các stablecoin được quy đổi 1:1 về đồng định giá khi dựng sổ nạp/rút từ sàn.
# Binance trả `income` theo đúng asset đã chuyển; nếu bỏ qua asset khác USDT thì sổ vốn
# sẽ thiếu tiền thật và PnL bị thổi phồng. Stablecoin lệch giá < 0,5% nên quy 1:1 là đủ.
STABLECOIN_PAR_ASSETS = {
    'USDT', 'USDC', 'BUSD', 'FDUSD', 'TUSD', 'DAI', 'USDP', 'USDD', 'PYUSD', 'EUR',
}
# Số ngày gần nhất đồng bộ TĂNG DẦN mỗi giờ (dư rộng so với chu kỳ 1 giờ + độ trễ sàn).
NET_DEPOSITS_INCREMENTAL_DAYS = 3
# [ĐỈNH VỐN] Mốc phiên bản của `peak_balance`. Bản 1 (không có mốc) là đỉnh được sinh ra
# trong thời kỳ `_auto_adjust_capital()` tự bóp méo vốn gốc -> có giá trị CHƯA TỪNG TỒN TẠI.
# Bản 2 = đỉnh được đánh giá lại theo mốc kế toán mới (sổ nạp/rút thật từ sàn) và chỉ tăng
# theo equity thực, không bao giờ bị hạ xuống để "giấu" mức sụt giảm.
PEAK_BASELINE_VERSION = 2
sys.path.insert(0, str(ROOT_DIR))

from dotenv import load_dotenv
load_dotenv(ROOT_DIR / ".env", override=False)

from core.exchange import ExchangeConnector
from core.data_collector import DataCollector
from core.order_manager import OrderManager
from core.telegram_notifier import send_telegram_message
from database.db_manager import DatabaseManager
from strategies.base_strategy import TradeSignal, Signal
from strategies.trend_following import TrendFollowingStrategy
from strategies.mean_reversion import MeanReversionStrategy
from strategies.smart_dca import SmartDCAStrategy
from strategies.hft_scalping import HFTScalpingStrategy
from strategies.trap_detector import TrapDetectorStrategy
from strategies.momentum_breakout import MomentumBreakoutStrategy
from ai.feature_engine import FeatureEngine
from ai.ml_model import MLPredictor
from ai.signal_aggregator import SignalAggregator
from ai.quantum_path_simulator import QuantumPathSimulator
from core.scanner import MarketScanner
from risk.risk_manager import RiskManager
from risk.position_sizer import PositionSizer

logger = logging.getLogger(__name__)

# [P1] Bẫy "râu nến giả hấp thụ" (Fake Absorption Wick).
# Một râu nến dài CHỈ được coi là hấp thụ lực xả thật khi giá vào lệnh còn nằm trong vùng
# hấp thụ của chính cây nến đó: 1/3 dưới của range với BUY, 1/3 trên của range với SELL.
# Nếu giá đã bật ra xa khỏi râu, râu đó chỉ là dấu vết xả cũ, KHÔNG được miễn trừ cổng
# Waterfall / Bull-Ramp.
#
# ⚠️ GIỚI HẠN TOÁN HỌC PHẢI NHỚ (đo trên 216 chu kỳ thật, xem Bài học 59):
# Với nến ĐỎ thì vị trí của giá đóng cửa trong range CHÍNH BẰNG tỷ lệ râu dưới:
#     (close - low) / (high - low) == (min(open, close) - low) / range
# nên phép thử "ngoài vùng hấp thụ" tương đương `lower_wick_ratio > ratio`. Hai cổng gọi
# hàm này chỉ chạm tới nhánh này khi `lower_wick_ratio >= 0.35`, mà ratio = 0.33 < 0.35,
# do đó điều kiện LUÔN ĐÚNG NGAY KHI VÀO NHÁNH.
# Hệ quả thực tế: P1 KHÔNG lọc được "râu giả" — nó BÃI BỎ miễn trừ hấp thụ, tức là chặn
# toàn bộ mẫu 3 nến đỏ thác đổ (BUY) / 3 nến xanh bơm dốc (SELL) trên Altcoin. Đây là hành
# vi có chủ đích sau khi đo: chặn 16/165 lệnh Altcoin, cứu 9 lệnh thua (-2.0875 USDT) nhưng
# mất 7 lệnh thắng (+1.6277 USDT), Delta +0.4598, CI 90% [-1.6106, +2.4572], P(delta>0)=66%.
# Muốn khôi phục hành vi trước bản vá (chỉ chặn khi râu < 35%): đặt ratio = 1.0.
WICK_ABSORPTION_ZONE_RATIO = 0.33


def _safe_float(val, default: float = 0.0) -> float:
    """Chuyển đổi an toàn sang float, trả về default nếu None, rỗng hoặc không hợp lệ."""
    if val is None or val == '':
        return default
    try:
        f = float(val)
        return f if math.isfinite(f) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _entry_inside_absorption_zone(entry_price, candle_high, candle_low, side,
                                  ratio: float = WICK_ABSORPTION_ZONE_RATIO) -> bool:
    """True khi giá vào lệnh còn nằm trong vùng hấp thụ của râu nến tương ứng."""
    try:
        price = float(entry_price)
        high = float(candle_high)
        low = float(candle_low)
    except (TypeError, ValueError, OverflowError):
        return False
    if not all(math.isfinite(v) for v in (price, high, low)):
        return False
    rng = high - low
    if rng <= 0 or price <= 0:
        return False
    side_u = str(side or '').upper()
    if side_u == 'BUY':
        return low <= price <= (low + ratio * rng)
    if side_u == 'SELL':
        return (high - ratio * rng) <= price <= high
    return False


class TradeBot:
    """
    Bot giao dịch crypto AI chính.
    Hỗ trợ chế độ demo (paper trading) và live trading.
    """

    def __init__(self, config_path: str = None):
        """Khởi tạo bot với cấu hình từ file YAML."""
        self.root_dir = ROOT_DIR
        self.config_path = config_path or str(self.root_dir / "config" / "settings.yaml")
        self.config = self._load_config(self.config_path)
        self.strategy_config = self._load_config(str(self.root_dir / "config" / "strategies.yaml"))
        
        # Trạng thái bot
        self.is_running = False
        self.exchange_connected = False
        import threading
        self._position_lock = threading.RLock()
        self._history_sync_lock = threading.Lock()
        self._position_monitor_stop = threading.Event()
        self._history_market_discovery_done = False
        self._telegram_warning_logged = False
        self._manual_exit_cooldowns = {}
        self._symbol_cooldowns = {}
        self._phase2_veto_cooldowns = {}
        self._symbol_loss_streaks = {}
        self._global_loss_cooldown_until = 0.0
        self.mode = self.config['bot']['mode']  # 'demo' hoặc 'live'
        trading_config = self.config['trading']
        try:
            self._live_initial_capital = float(trading_config.get('live_initial_capital', trading_config['initial_capital']))
            if not math.isfinite(self._live_initial_capital) or self._live_initial_capital <= 0:
                raise ValueError('invalid live initial capital')
        except (TypeError, ValueError, OverflowError):
            self._live_initial_capital = 1000.0
        try:
            self._demo_initial_capital = float(trading_config.get('demo_initial_capital', 1000.0))
            if not math.isfinite(self._demo_initial_capital) or self._demo_initial_capital <= 0:
                raise ValueError('invalid demo initial capital')
        except (TypeError, ValueError, OverflowError):
            self._demo_initial_capital = 1000.0
        if self.mode == 'demo':
            trading_config['initial_capital'] = self._demo_initial_capital
        else:
            trading_config['initial_capital'] = self._live_initial_capital
        self.live_balance_synced = self.mode != 'live'
        self.balance = trading_config['initial_capital']
        self.peak_balance = self.balance
        # [H6 - KẾ TOÁN VỐN] `initial_capital` là VỐN GỐC CỐ ĐỊNH do người dùng đặt,
        # KHÔNG bao giờ bị tự động sửa bởi kết quả giao dịch. Mọi dòng tiền nạp/rút được
        # ghi riêng vào sổ `capital_ledger` và cộng dồn vào `net_deposits`.
        # PnL thực = equity - initial_capital - net_deposits.
        try:
            configured_net_deposits = float(trading_config.get('net_deposits', 0.0) or 0.0)
        except (TypeError, ValueError, OverflowError):
            configured_net_deposits = 0.0
        self.net_deposits = configured_net_deposits if math.isfinite(configured_net_deposits) else 0.0
        self.capital_ledger: List[Dict] = []
        self._deposit_tran_ids: List[str] = []
        # [SỔ VỐN TỰ DỰNG LẠI] `_ledger_complete=True` nghĩa là sổ nạp/rút đã được đối chiếu
        # ĐẦY ĐỦ với lịch sử TRANSFER của sàn (đã truy ngược tới đầu ví). Chỉ khi đó mốc vốn
        # mới lấy bằng tổng nạp/rút ròng, thay vì "vốn gốc khai báo + phần nạp đã thấy".
        self._ledger_complete = False
        self._ledger_coverage_start_ms = 0
        self._net_deposits_checked_at = 0.0
        self._net_deposits_last_success_at = 0.0
        self._capital_baseline_warned_at = 0.0
        self.open_positions: List[Dict] = []
        self.pending_stalking_orders: Dict[str, Dict] = {}
        self._futures_account_snapshot: Optional[Dict] = None
        self._futures_account_snapshot_time: Optional[datetime] = None
        self._futures_account_snapshot_monotonic: Optional[float] = None
        self._futures_positions_snapshot: List[Dict] = []
        self._futures_positions_snapshot_time: Optional[datetime] = None
        self.pending_protection_cleanup: List[Dict] = []
        self.unreconciled_exchange_positions = False
        self.trade_count = 0
        self.start_time = None
        self._skip_dynamic_exit_cycle = False
        self.last_optimized = 0
        self._trailing_market_cache = {}
        self._position_monitor_thread = None
        self._runner_thread = None
        self._background_threads = []
        self.last_dynamic_leverage = 1
        self.last_leverage_symbol = None
        self.last_pair_max_leverage = None
        self.last_leverage_limit_verified = None
        self.last_leverage_limit_source = None
        self.ai_recommended_max_positions = 1
        self.last_dynamic_position_limit = None
        self.last_position_signal_quality = None
        self.last_position_available_margin = None
        self.last_position_open_risk = None
        self.last_position_risk_budget = None
        
        # Khởi tạo components
        self._init_components()
        
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        logger.info(f"🤖 TRADE BOT v{self.config['bot']['version']} khởi tạo thành công!")
        logger.info(f"📊 Chế độ: {'DEMO (Paper Trading)' if self.mode == 'demo' else '⚠️ LIVE TRADING'}")
        if self.mode == 'demo':
            logger.info(f"💰 Vốn ban đầu (Demo): {self.balance} {quote}")
        else:
            logger.info(f"💰 Vốn ban đầu: Đang kết nối API sàn để lấy số dư thực tế...")

    def _load_config(self, path: str) -> dict:
        """Đọc YAML, tự phục hồi settings.yaml từ .bak nếu file thiếu section."""
        is_settings = os.path.basename(str(path)).lower() == 'settings.yaml'
        required_sections = (
            'ai', 'bot', 'cloud', 'dashboard', 'database', 'exchange',
            'notifications', 'quantum_gate', 'risk', 'tradfi', 'trading',
        )

        def validated(candidate):
            if not isinstance(candidate, dict):
                if is_settings:
                    raise ValueError('settings.yaml không phải mapping hợp lệ')
                return None
            missing = [key for key in required_sections if key not in candidate]
            if is_settings and missing:
                raise ValueError(f'settings.yaml thiếu section: {missing}')
            return candidate

        try:
            with open(path, 'r', encoding='utf-8') as f:
                return validated(yaml.safe_load(f))
        except FileNotFoundError as primary:
            error = primary
        except (yaml.YAMLError, ValueError) as primary:
            error = primary

        backup_path = str(path) + '.bak'
        if is_settings and os.path.exists(backup_path):
            try:
                with open(backup_path, 'r', encoding='utf-8') as backup_file:
                    backup_cfg = validated(yaml.safe_load(backup_file))
                restore_tmp = str(path) + '.restore.tmp'
                with open(restore_tmp, 'w', encoding='utf-8') as restore_file:
                    yaml.safe_dump(backup_cfg, restore_file, default_flow_style=False,
                                   allow_unicode=True, sort_keys=False)
                    restore_file.flush()
                    os.fsync(restore_file.fileno())
                os.replace(restore_tmp, path)
                logger.warning(
                    "🩹 [CONFIG RECOVERY] settings.yaml không hợp lệ (%s); đã phục hồi nguyên tử từ settings.yaml.bak.",
                    error,
                )
                return backup_cfg
            except Exception as backup_error:
                logger.error("Không thể phục hồi settings.yaml.bak: %s", backup_error)
        if isinstance(error, FileNotFoundError):
            logger.error(f"Không tìm thấy file cấu hình: {path}")
        else:
            logger.error(f"Lỗi đọc file YAML: {error}")
        raise error

    def _init_components(self):
        """Khởi tạo tất cả các thành phần của bot."""
        # Database
        db_path = str(self.root_dir / self.config['database']['path'])
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db = DatabaseManager(db_path)
        self.db.init_db()
        
        # Exchange connector
        self.exchange = ExchangeConnector(self.config)
        
        # Market Scanner (Quét thị trường)
        self.scanner = MarketScanner(self.exchange)
        
        # Setup futures if in futures mode
        if self.config['trading'].get('market_type', 'spot') == 'futures':
            self.market_type = 'futures'
            self.leverage = self.config['trading'].get('leverage', 5)
        else:
            self.market_type = 'spot'
            self.leverage = 1
        
        # Data collector
        self.data_collector = DataCollector(self.exchange, str(self.root_dir / "data" / "historical"))
        
        # Strategies
        self.strategies = []
        strat_configs = self.strategy_config.get('strategies', {})
        
        if strat_configs.get('trend_following', {}).get('enabled', False):
            self.strategies.append(
                TrendFollowingStrategy("trend_following", strat_configs['trend_following'])
            )
        
        if strat_configs.get('mean_reversion', {}).get('enabled', False):
            self.strategies.append(
                MeanReversionStrategy("mean_reversion", strat_configs['mean_reversion'])
            )
        
        if strat_configs.get('smart_dca', {}).get('enabled', False):
            self.strategies.append(
                SmartDCAStrategy("smart_dca", strat_configs['smart_dca'])
            )
            
        if strat_configs.get('hft_scalping', {}).get('enabled', False):
            self.strategies.append(
                HFTScalpingStrategy("hft_scalping", strat_configs['hft_scalping'])
            )

        if strat_configs.get('trap_detector', {}).get('enabled', False):
            self.strategies.append(
                TrapDetectorStrategy("trap_detector", strat_configs['trap_detector'])
            )
            
        if strat_configs.get('momentum_breakout', {}).get('enabled', False):
            self.strategies.append(
                MomentumBreakoutStrategy("momentum_breakout", strat_configs.get('momentum_breakout', {}))
            )

        # AI components
        self.feature_engine = FeatureEngine()
        self.ml_predictor = MLPredictor()
        aggregator_config = dict(self.config)
        aggregator_config['strategies'] = strat_configs
        self.signal_aggregator = SignalAggregator(aggregator_config)
        q_cfg = self.config.get('quantum_gate', {}) if isinstance(self.config.get('quantum_gate'), dict) else {}
        self.quantum_simulator = QuantumPathSimulator(
            n_paths=int(q_cfg.get('n_paths', 2500)),
            n_steps=int(q_cfg.get('n_steps', 40)),
            min_win_prob=float(q_cfg.get('min_win_prob', 0.0)),
            max_doa_prob=float(q_cfg.get('max_doa_prob', 0.40)),
            min_ev_pct=float(q_cfg.get('min_ev_pct', 0.0)),
            edge_margin=float(q_cfg.get('edge_margin', 0.10)),
        )
        
        try:
            from ai.jev_agent import JevAgent
            self.jev_agent = JevAgent(
                model_name=self.config.get('ai', {}).get('ollama_model', 'qwen2.5:7b'),
                read_timeout_seconds=self.config.get('ai', {}).get('jev_read_timeout_seconds', 30),
                num_predict=self.config.get('ai', {}).get('jev_num_predict', 180),
            )
        except ImportError:
            self.jev_agent = None
        
        # Risk management
        self.risk_manager = RiskManager(self.config)
        self.position_sizer = PositionSizer()
        self.cycle_count = 0
        self._fading_short_watchlist = {}  # [BÀI HỌC 78 & 82] {clean_sym: expire_ts} Ra-đa Rình Short Pha 2
        
        # Order manager
        self.order_manager = OrderManager(self.exchange, self.db, self.mode)
        self.scanner.exchange = self.exchange
        self.data_collector.exchange = self.exchange
        
        # Khôi phục trạng thái nếu có
        if self.mode == 'live':
            try:
                # Load public market metadata so a LIVE session can reconcile and
                # display existing positions while the trading loop stays stopped.
                self.exchange_connected = bool(self.exchange.connect())
                if not self.exchange_connected:
                    logger.error("Không kết nối được Binance lúc mở dashboard LIVE; bot vẫn giữ trạng thái dừng.")
            except Exception as e:
                self.exchange_connected = False
                logger.error("Không thể khởi tạo kết nối LIVE lúc mở dashboard: %s", e)
        self._restore_state()
        active_cds = {
            self._clean_symbol(symbol): expires_at
            for symbol, expires_at in self.db.get_symbol_cooldowns(self.mode).items()
        }
        self._manual_exit_cooldowns = dict(active_cds)
        self._symbol_cooldowns = dict(active_cds)
        self.sync_live_positions_with_exchange()
        
        logger.info(f"✅ Đã khởi tạo {len(self.strategies)} chiến lược giao dịch")

    def _restore_state(self):
        """Khôi phục trạng thái bot từ database (cho trường hợp restart)."""
        try:
            state = self.db.get_bot_state(self.mode)
            if state:
                # [H6 - DI TRÚ VỐN GỐC]
                # Bot cũ tự động ghi đè `initial_capital` theo chênh lệch số dư, khiến mỗi lần
                # lỗ > 2 USDT bị ghi thành "rút tiền" và vốn gốc bị hạ xuống -> xoá sạch dấu vết
                # thua lỗ, vô hiệu hoá cầu dao Max Drawdown. Nay chỉ khôi phục vốn gốc từ DB khi
                # bản ghi mang mốc `capital_baseline_version >= 2`; bản ghi cũ bị bỏ qua để
                # dùng vốn gốc trong settings.yaml do người dùng đặt.
                baseline_from_state = (
                    state.get('initial_capital') is not None
                    and int(state.get('capital_baseline_version') or 0) >= 2
                )
                if baseline_from_state:
                    self.config['trading']['initial_capital'] = state['initial_capital']
                    if self.mode == 'demo':
                        self._demo_initial_capital = float(state['initial_capital'])
                    else:
                        self._live_initial_capital = float(state['initial_capital'])
                elif state.get('initial_capital') is not None:
                    logger.warning(
                        "🧾 [VỐN GỐC] Bỏ qua initial_capital=%.4f lưu trong DB (bản ghi cũ đã bị "
                        "bóp méo bởi cơ chế tự điều chỉnh theo số dư). Dùng vốn gốc settings.yaml: "
                        "%.4f %s.",
                        float(state.get('initial_capital') or 0.0),
                        float(self.config['trading']['initial_capital']),
                        self.config.get('trading', {}).get('base_currency', 'USDT'),
                    )

                if 'net_deposits' in state:
                    try:
                        loaded_net_deposits = float(state.get('net_deposits') or 0.0)
                    except (TypeError, ValueError, OverflowError):
                        loaded_net_deposits = 0.0
                    self.net_deposits = (
                        loaded_net_deposits if math.isfinite(loaded_net_deposits)
                        else float(getattr(self, 'net_deposits', 0.0) or 0.0)
                    )
                ledger = state.get('capital_ledger') or []
                self.capital_ledger = (
                    [entry for entry in ledger if isinstance(entry, dict)]
                    if isinstance(ledger, list) else []
                )
                tran_ids = state.get('deposit_tran_ids') or []
                self._deposit_tran_ids = (
                    [str(t) for t in tran_ids] if isinstance(tran_ids, list) else []
                )
                # [SỔ VỐN] Trạng thái "đã đối chiếu đầy đủ với sàn" phải sống qua restart, nếu không
                # mỗi lần khởi động bot lại phải quét lại toàn bộ lịch sử (tốn API) và tệ hơn là
                # có thể tạm thời hạ mốc vốn về "vốn gốc khai báo" gây sai PnL.
                self._ledger_complete = bool(state.get('ledger_complete') or False)
                try:
                    self._net_deposits_last_success_at = float(state.get('net_deposits_last_success_at') or 0.0)
                except (TypeError, ValueError, OverflowError):
                    self._net_deposits_last_success_at = 0.0
                try:
                    self._ledger_coverage_start_ms = int(
                        state.get('ledger_coverage_start_ms') or 0
                    )
                except (TypeError, ValueError, OverflowError):
                    self._ledger_coverage_start_ms = 0
                    
                if self.mode == 'demo':
                    self.balance = state.get('balance', self.balance)
                loaded_peak = float(state.get('peak_balance', self.peak_balance) or self.peak_balance)
                if self.mode == 'live' and loaded_peak == 1000.0 and self.balance < 500:
                    loaded_peak = self.balance # Ignore leaked demo peak
                # [ĐỈNH VỐN] Đỉnh sinh ra trước bản vá kế toán vốn là số giả -> đặt lại một lần.
                # Ưu tiên số dư đã lưu trong DB làm mốc: lúc này `self.balance` vẫn là
                # `initial_capital` (chưa fetch số dư thật từ sàn), nếu dùng nó thì đỉnh bị hạ
                # xuống 100 rồi mới được nâng lại ở chu kỳ đầu -> log gây hiểu nhầm.
                try:
                    _peak_hint = (
                        float(state.get('balance'))
                        if state.get('balance') is not None else None
                    )
                except (TypeError, ValueError, OverflowError):
                    _peak_hint = None
                loaded_peak = self._sanitize_peak_baseline(
                    state, loaded_peak, equity_hint=_peak_hint
                )
                self.peak_balance = max(self.balance, loaded_peak)
                self.trade_count = int(state.get('trade_count', self.trade_count) or 0)
                pending_cleanup = state.get('pending_protection_cleanup', []) or []
                self.pending_protection_cleanup = (
                    [item for item in pending_cleanup if isinstance(item, dict)]
                    if isinstance(pending_cleanup, list) else []
                )
                
                # Trong LIVE mode, self.balance đã được đồng bộ chính xác từ sàn qua switch_mode
                # nên không ghi đè từ DB cũ lên nữa.
                
                self.open_positions = state.get('open_positions', [])
                # Khôi phục các lệnh bắn tỉa rình mồi M1 đang chờ
                self.pending_stalking_orders = {}
                try:
                    stalking_file = Path(ROOT_DIR) / "data" / f"pending_stalking_orders_{self.mode}.json"
                    if stalking_file.exists():
                        raw_stk = stalking_file.read_text(encoding="utf-8").strip()
                        loaded_stk = json.loads(raw_stk) if raw_stk else {}
                        now_ts = time.time()
                        if isinstance(loaded_stk, dict):
                            for s_sym, s_data in loaded_stk.items():
                                if now_ts - float(s_data.get('created_at', 0)) < float(s_data.get('timeout_seconds', 900)):
                                    self.pending_stalking_orders[s_sym] = s_data
                except Exception as e_stk:
                    logger.debug(f"Không thể đọc file stalking orders: {e_stk}")

                # [BÀI HỌC 95]: Khôi phục Ra-đa Rình Short Pha 2 sau khi bot khởi động lại
                try:
                    wl_file = Path(ROOT_DIR) / "data" / f"fading_short_watchlist_{self.mode}.json"
                    if wl_file.exists():
                        raw_wl = wl_file.read_text(encoding="utf-8").strip()
                        loaded_wl = json.loads(raw_wl) if raw_wl else {}
                        now_wl = time.time()
                        if isinstance(loaded_wl, dict):
                            self._fading_short_watchlist = {k: float(v) for k, v in loaded_wl.items() if float(v) > now_wl}
                except Exception as e_wl:
                    logger.debug(f"Không thể đọc file fading short watchlist: {e_wl}")

                quote = self.config.get('trading', {}).get('base_currency', 'USDT')
                
                # Parse last_check to track daily drawdown resets
                last_check_str = state.get('last_check')
                if last_check_str:
                    try:
                        self.last_reset_date = datetime.fromisoformat(last_check_str).date()
                    except Exception:
                        self.last_reset_date = datetime.now().date()
                else:
                    self.last_reset_date = datetime.now().date()
                    
                if self.mode == 'live' and not self.live_balance_synced:
                    logger.info(f"🔄 Khôi phục trạng thái: Chế độ LIVE TRADING (chuẩn bị kết nối sàn Binance), "
                              f"Open positions={len(self.open_positions)}")
                else:
                    logger.info(f"🔄 Khôi phục trạng thái: Balance={self.balance:.2f} {quote}, "
                              f"Open positions={len(self.open_positions)}")
            else:
                self.open_positions = []
                self.last_reset_date = datetime.now().date()
                logger.info(f' Không tìm thấy trạng thái cũ cho {self.mode}, bắt đầu mới.')
        except Exception as e:
            logger.warning(f"Không thể khôi phục trạng thái: {e}")

    def _save_state(self):
        """Lưu trạng thái hiện tại vào database."""
        try:
            state = {
                'mode': self.mode,
                'balance': self.balance,
                'initial_capital': self.config['trading']['initial_capital'],
                # Mốc phiên bản: >= 2 nghĩa là vốn gốc là hằng số do người dùng đặt và
                # dòng tiền nạp/rút được ghi riêng trong capital_ledger/net_deposits.
                'capital_baseline_version': 2,
                'net_deposits': float(getattr(self, 'net_deposits', 0.0) or 0.0),
                # [SỔ VỐN] Giữ tối đa 1000 bản ghi; nếu vượt ngưỡng thì buộc lần sau DỰNG LẠI
                # từ sàn, vì cắt bớt sổ mà vẫn tin tổng cũ sẽ làm sai `net_deposits` vĩnh viễn.
                'capital_ledger': list(getattr(self, 'capital_ledger', []) or [])[-1000:],
                'deposit_tran_ids': list(getattr(self, '_deposit_tran_ids', []) or [])[-1000:],
                # [SỔ VỐN] Đánh dấu sổ đã đối chiếu đầy đủ với sàn + mốc thời gian đã quét tới.
                'ledger_complete': bool(getattr(self, '_ledger_complete', False)),
                'net_deposits_last_success_at': float(getattr(self, '_net_deposits_last_success_at', 0.0) or 0.0),
                'ledger_coverage_start_ms': int(getattr(self, '_ledger_coverage_start_ms', 0) or 0),
                'open_positions': self.open_positions,
                'pending_protection_cleanup': self.pending_protection_cleanup,
                'peak_balance': self.peak_balance,
                # [ĐỈNH VỐN] Mốc >= 2 nghĩa là đỉnh đã được đánh giá lại theo kế toán vốn mới.
                # Thiếu mốc này => lần khôi phục kế tiếp sẽ coi đỉnh là số giả và đặt lại.
                'peak_baseline_version': PEAK_BASELINE_VERSION,
                'trade_count': self.trade_count,
                'last_check': datetime.now().isoformat()
            }
            self.db.save_bot_state(state)
            # Lưu trạng thái các lệnh rình mồi M1 vào file JSON
            try:
                stalking_file = Path(ROOT_DIR) / "data" / f"pending_stalking_orders_{self.mode}.json"
                with open(stalking_file, "w", encoding="utf-8") as sf:
                    json.dump(getattr(self, 'pending_stalking_orders', {}), sf, indent=2, ensure_ascii=False)
            except Exception as e_stk:
                logger.debug(f"Không thể ghi file stalking orders: {e_stk}")

            # [BÀI HỌC 95]: Lưu Ra-đa Rình Short Pha 2 xuống file đĩa cứng
            try:
                wl_file = Path(ROOT_DIR) / "data" / f"fading_short_watchlist_{self.mode}.json"
                with open(wl_file, "w", encoding="utf-8") as wf:
                    json.dump(getattr(self, '_fading_short_watchlist', {}), wf, indent=2, ensure_ascii=False)
            except Exception as e_wl:
                logger.debug(f"Không thể ghi file fading short watchlist: {e_wl}")
        except Exception as e:
            logger.error(f"Lỗi lưu trạng thái: {e}")

    def connect(self) -> bool:
        """Kết nối tới sàn giao dịch."""
        try:
            connected = self.exchange.connect()
            self.exchange_connected = bool(connected)
            if connected:
                logger.info("✅ Kết nối sàn giao dịch thành công!")
                
                if self.mode == 'live':
                    self._detect_base_currency()
                    base_currency = self.config['trading'].get('base_currency', 'USDT')
                    if getattr(self, 'market_type', 'spot') == 'futures':
                        bal = self.exchange.get_futures_balance()
                        curr_balance = float(bal.get('free', 0))
                    else:
                        bal = self.exchange.get_balance()
                        curr_balance = bal.get(base_currency, {}).get('free', 0)
                        
                    self.balance = curr_balance  # Cập nhật số dư thực tế
                    self.live_balance_synced = True
                    logger.info(f"💰 Số dư tài khoản thực tế từ Binance: {curr_balance} {base_currency}")
                    self._reconcile_capital_baseline()
                else:
                    curr_balance = self.balance
                    base_currency = self.config['trading'].get('base_currency', 'USDT')

                current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                start_msg = (
                    f"🤖 **TRADE BOT ĐÃ KHỞI ĐỘNG**\n"
                    f"🕒 **Thời gian:** {current_time}\n"
                    f"🔹 **Trạng thái:** Đã kết nối sàn thành công! Đang chờ tín hiệu...\n"
                    f"🛡️ **Cơ chế an toàn:** Đang chạy Chu kỳ #1 Warm-up (Nạp nóng AI VRAM & đồng bộ nến). Lệnh mới sẵn sàng kích hoạt từ Chu kỳ #2!"
                )
                self._notify_telegram(start_msg)
                
                return True
            else:
                logger.error("❌ Không thể kết nối sàn giao dịch!")
                return False
        except Exception as e:
            self.exchange_connected = False
            logger.error(f"❌ Lỗi kết nối: {e}")
            return False

    def _analyze_market(self, symbol: str, fast_mode: bool = False) -> List:
        """
        Phân tích thị trường cho một cặp giao dịch.
        Thu thập dữ liệu, chạy tất cả strategies, trả về danh sách signals.
        Nếu fast_mode=True, bỏ qua các model AI chậm (JEV, LLM).
        """
        signals = []
        market_analysis = None
        timeframes = self.config['trading'].get('timeframes', [])
        primary_timeframe = timeframes[0] if timeframes else None
        
        dfs = {}
        # Tải nến song song các khung thời gian để giảm 60% độ trễ mạng
        if len(timeframes) > 1:
            import concurrent.futures
            def _fetch_tf(tf):
                try:
                    res_df = self.data_collector.fetch_data(symbol, tf, limit=500)
                    return tf, res_df
                except Exception as e:
                    logger.warning(f"Lỗi tải nến {symbol} {tf}: {e}")
                    return tf, None

            with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(timeframes))) as tf_executor:
                fetched = list(tf_executor.map(_fetch_tf, timeframes))
            for tf, df_res in fetched:
                if df_res is not None and len(df_res) >= 100:
                    dfs[tf] = df_res
                else:
                    if tf == primary_timeframe:
                        MarketScanner.mark_insufficient_data(symbol, cooldown_seconds=3600.0)
                    logger.warning(f"Không đủ dữ liệu cho {symbol} {tf} (đã tạm cách ly khỏi danh sách quét 60m)")
        else:
            for timeframe in timeframes:
                try:
                    df = self.data_collector.fetch_data(symbol, timeframe, limit=500)
                    if df is not None and len(df) >= 100:
                        dfs[timeframe] = df
                    else:
                        if timeframe == primary_timeframe:
                            MarketScanner.mark_insufficient_data(symbol, cooldown_seconds=3600.0)
                        logger.warning(f"Không đủ dữ liệu cho {symbol} {timeframe} (đã tạm cách ly khỏi danh sách quét 60m)")
                except Exception as e:
                    logger.warning(f"Lỗi tải nến {symbol} {timeframe}: {e}")

        for timeframe in timeframes:
            try:
                df = dfs.get(timeframe)
                if df is None or len(df) < 100:
                    continue

                if timeframe == primary_timeframe:
                    try:
                        from ai.market_regime import MarketRegimeDetector
                        regime_info = MarketRegimeDetector().detect_regime(df)
                        regime = regime_info.get('regime')
                        now_ts = time.time()
                        clean_sym = self._clean_symbol(symbol)
                        if hasattr(self, '_fading_short_watchlist'):
                            self._fading_short_watchlist = {s: exp for s, exp in self._fading_short_watchlist.items() if exp > now_ts}
                        in_p2_wl = bool(hasattr(self, '_fading_short_watchlist') and clean_sym in self._fading_short_watchlist)
                        market_analysis = {
                            'in_fading_short_watchlist': in_p2_wl,
                            'regime': getattr(regime, 'value', regime),
                            'confidence': float(regime_info.get('confidence', 0.0)),
                            'adx': float(regime_info.get('adx', 0.0)),
                            'di_plus': float(regime_info.get('di_plus', 0.0)),
                            'di_minus': float(regime_info.get('di_minus', 0.0)),
                            'atr_pct': float(regime_info.get('atr_pct', 0.0)),
                            'rsi': float(regime_info.get('rsi', 50.0)),
                            'ema_alignment': regime_info.get('ema_alignment', 'mixed'),
                        }
                        if len(df) >= 20:
                            c_prev_ma = df.iloc[-2]
                            c_range_ma = max(1e-8, float(c_prev_ma['high'] - c_prev_ma['low']))
                            c_upper_wick_ma = float(c_prev_ma['high'] - max(c_prev_ma['open'], c_prev_ma['close']))
                            c_lower_wick_ma = float(min(c_prev_ma['open'], c_prev_ma['close']) - c_prev_ma['low'])
                            c_body_ma = float(abs(c_prev_ma['open'] - c_prev_ma['close']))
                            vol_sma20_ma = float(df['volume'].iloc[-21:-1].mean()) if len(df) >= 21 else float(df['volume'].mean())
                            c_vol_ratio_ma = float(c_prev_ma['volume'] / max(1e-8, vol_sma20_ma))
                            market_analysis['upper_wick_pct'] = round(c_upper_wick_ma / c_range_ma, 4)
                            market_analysis['lower_wick_pct'] = round(c_lower_wick_ma / c_range_ma, 4)
                            market_analysis['body_pct'] = round(c_body_ma / c_range_ma, 4)
                            market_analysis['candle_vol_ratio'] = round(c_vol_ratio_ma, 2)
                            if len(df) >= 6:
                                p_min3_ma = float(df['low'].iloc[-5:-2].min())
                                p_max3_ma = float(df['high'].iloc[-5:-2].max())
                                c_close_ma = float(c_prev_ma['close'])
                                market_analysis['recent_pump_pct'] = round((c_close_ma - p_min3_ma) / max(1e-8, p_min3_ma), 4)
                                market_analysis['recent_dump_pct'] = round((p_max3_ma - c_close_ma) / max(1e-8, p_max3_ma), 4)
                    except Exception as e:
                        logger.debug("Không có market regime cho %s %s: %s", symbol, timeframe, e)
                        market_analysis = None
                elif timeframe == '15m' and isinstance(market_analysis, dict):
                    try:
                        import ta
                        rsi_15m_s = ta.momentum.RSIIndicator(df['close'].iloc[:-1], window=14).rsi().dropna()
                        if not rsi_15m_s.empty:
                            market_analysis['tactical_rsi'] = float(rsi_15m_s.iloc[-1])
                        adx_15m_s = ta.trend.ADXIndicator(df['high'].iloc[:-1], df['low'].iloc[:-1], df['close'].iloc[:-1], window=14).adx().dropna()
                        if not adx_15m_s.empty:
                            market_analysis['tactical_adx'] = float(adx_15m_s.iloc[-1])
                        atr_15m_s = ta.volatility.AverageTrueRange(df['high'].iloc[:-1], df['low'].iloc[:-1], df['close'].iloc[:-1], window=14).average_true_range().dropna()
                        if not atr_15m_s.empty and len(df) >= 2:
                            cl_prev = float(df['close'].iloc[-2])
                            market_analysis['tactical_atr_pct'] = float(atr_15m_s.iloc[-1] / cl_prev * 100) if cl_prev > 0 else 0.0
                        if len(df) >= 20:
                            c_prev15 = df.iloc[-2]
                            c_range15 = max(1e-8, float(c_prev15['high'] - c_prev15['low']))
                            c_upper_wick15 = float(c_prev15['high'] - max(c_prev15['open'], c_prev15['close']))
                            c_lower_wick15 = float(min(c_prev15['open'], c_prev15['close']) - c_prev15['low'])
                            c_body15 = float(abs(c_prev15['open'] - c_prev15['close']))
                            vol_sma20_15 = float(df['volume'].iloc[-21:-1].mean()) if len(df) >= 21 else float(df['volume'].mean())
                            c_vol_ratio15 = float(c_prev15['volume'] / max(1e-8, vol_sma20_15))
                            market_analysis['upper_wick_pct'] = round(c_upper_wick15 / c_range15, 4)
                            market_analysis['lower_wick_pct'] = round(c_lower_wick15 / c_range15, 4)
                            market_analysis['body_pct'] = round(c_body15 / c_range15, 4)
                            market_analysis['candle_vol_ratio'] = round(c_vol_ratio15, 2)
                            clean_sym_15 = self._clean_symbol(symbol)
                            if len(df) >= 6:
                                p_min3_15 = float(df['low'].iloc[-5:-2].min())
                                p_max3_15 = float(df['high'].iloc[-5:-2].max())
                                c_close15 = float(c_prev15['close'])
                                raw_pump = round((c_close15 - p_min3_15) / max(1e-8, p_min3_15), 4)
                                raw_dump = round((p_max3_15 - c_close15) / max(1e-8, p_max3_15), 4)

                                # [BÀI HỌC 92]: Đối chiếu nến đang chạy iloc[-1] và giá tươi để triệt tiêu BẪY THÁC ĐỔ TRỄ PHA (Stale Waterfall Trap)
                                # Nếu nến hiện tại đang bật tăng xanh mạnh (>= 0.8% từ đáy/close cũ), thác đổ ĐÃ KẾT THÚC, cấm Short cản tàu!
                                c_curr15 = df.iloc[-1]
                                curr_close15 = float(c_curr15['close'])
                                curr_open15 = float(c_curr15['open'])
                                is_live_rebounding = (curr_close15 > c_close15 * 1.008) or (curr_close15 > curr_open15 * 1.008)
                                is_live_dumping = (curr_close15 < c_close15 * 0.992) or (curr_close15 < curr_open15 * 0.992)
                                market_analysis['is_live_rebounding'] = is_live_rebounding
                                market_analysis['is_live_dumping'] = is_live_dumping
                                market_analysis['recent_pump_pct'] = 0.0 if is_live_dumping else raw_pump
                                market_analysis['recent_dump_pct'] = 0.0 if is_live_rebounding else raw_dump
                                # [BÀI HỌC 78 & 85]: Tự động ghi nhận đồng coin đang có Bão Volume Cá Mập (Whale Pump Storm)
                                # vào Ra-đa Rình Short Pha 2 (60 phút) ngay cả khi chưa khớp LONG Pha 1 để đón đầu nhịp xả đỉnh!
                                if (
                                    hasattr(self, '_fading_short_watchlist')
                                    and market_analysis['recent_pump_pct'] >= 0.025
                                    and market_analysis['candle_vol_ratio'] >= 1.80
                                ):
                                    self._fading_short_watchlist[clean_sym_15] = time.time() + 3600.0
                            if hasattr(self, '_fading_short_watchlist') and clean_sym_15 in self._fading_short_watchlist:
                                market_analysis['in_fading_short_watchlist'] = True
                    except Exception:
                        pass
                
                # Chạy từng strategy
                for strategy in self.strategies:
                    try:
                        strat_name_l = str(getattr(strategy, 'name', '')).lower()
                        # Khung 5m chỉ cấp dữ liệu vi mô (Layer 4) cho JEV Agent;
                        # cấm chạy các chiến lược kỹ thuật trên nến 5m để tránh rác tín hiệu
                        if timeframe == '5m':
                            continue
                        # Khung 4h (240 phút) chỉ dùng TrendFollowing để định hướng vĩ mô;
                        # cấm chạy MomentumBreakout/MeanReversion/TrapDetector trên nến 4h để tránh bẫy trễ pha (như INTC, DUSK #0)
                        if timeframe == '4h' and strat_name_l in (
                            'momentumbreakout', 'momentum_breakout',
                            'meanreversion', 'mean_reversion',
                            'trapdetector', 'trap_detector',
                        ):
                            continue
                        signal = strategy.analyze(df, symbol)
                        if signal:
                            if isinstance(getattr(signal, 'metadata', None), dict):
                                signal.metadata['timeframe'] = timeframe
                            signals.append(signal)
                            if signal.signal.value != 'hold':
                                logger.info(
                                    f"📊 [{strategy.name}] {symbol} {timeframe}: "
                                    f"{signal.signal.value.upper()} "
                                    f"(confidence: {signal.confidence:.2%})"
                                )
                    except Exception as e:
                        logger.error(f"Lỗi strategy {strategy.name}: {e}")
                        
            except Exception as e:
                logger.error(f"Lỗi phân tích {symbol} {timeframe}: {e}")

        # AI Analysis với đầy đủ bối cảnh Đa Khung Thời Gian (Multi-Timeframe)
        if not fast_mode and bool(dfs):
            # 1. AI Ensemble Analysis (sử dụng khung chính kèm market analysis)
            primary_df = dfs.get(primary_timeframe)
            if primary_df is None or (hasattr(primary_df, 'empty') and primary_df.empty):
                primary_df = list(dfs.values())[0] if dfs else None
            try:
                ai_signal = self._ai_analysis(primary_df, symbol, market_analysis)
                if ai_signal:
                    signals.append(ai_signal)
                    if ai_signal.signal.value != 'hold':
                        logger.info(
                            f"🧠 [AI Ensemble] {symbol}: "
                            f"{ai_signal.signal.value.upper()} "
                            f"(confidence: {ai_signal.confidence:.2%})"
                        )
            except Exception as e:
                logger.error(f"Lỗi AI Ensemble analysis: {e}")

            # 2. JEV Agent Analysis (Tích hợp chuẩn Multi-Timeframe: 15M tác chiến + 1H sóng + 4H xu hướng lớn)
            if hasattr(self, 'jev_agent') and self.jev_agent:
                # =========================================================================
                # BỘ LỌC BẢN CHẤT KỸ THUẬT PRE-LLM (STRUCTURAL PRE-LLM FAST-SKIP GATE)
                # Chỉ đánh thức Ollama LLM (qwen2.5:7b) khi setup có Trụ Cột Kỹ Thuật thực thụ,
                # không xung đột nội bộ, và không vi phạm quy luật nến/xung lực thị trường!
                # =========================================================================
                skip_llm_reason = None
                
                # 1. Trụ Cột Kỹ Thuật (Anchor Strategy): Phải có ít nhất 1 chiến thuật cốt lõi tự tin cao
                # Lưu giữ mức độ tự tin cao nhất theo từng chiến thuật và danh sách toàn bộ tín hiệu để đối soát
                all_tech_signals = []
                best_tech_by_strat = {}
                best_price_by_strat = {}
                for s in signals:
                    s_name = str(getattr(s, 'strategy', '')).lower()
                    if s_name in ('trendfollowing', 'trend_following', 'trapdetector', 'trap_detector', 
                                  'momentumbreakout', 'momentum_breakout', 'meanreversion', 'mean_reversion'):
                        if s.signal.value != 'hold':
                            conf_val = float(s.confidence)
                            dir_val = s.signal.value.upper()
                            all_tech_signals.append((s_name, dir_val, conf_val))
                            if s_name not in best_tech_by_strat or conf_val > best_tech_by_strat[s_name][1]:
                                best_tech_by_strat[s_name] = (dir_val, conf_val)
                                best_price_by_strat[s_name] = float(getattr(s, 'price', 0.0) or 0.0)

                # [BÀI HỌC 86]: Nếu cặp tiền đang là vị thế mở, bỏ qua gọi JEV Agent (LLM) vì vị thế mở
                # được quản trị tập trung bằng Trailing Stop, SL sàn và tín hiệu khẩn cấp của AI Ensemble + TrapDetector!
                is_symbol_open = any(
                    self._clean_symbol(p.get('symbol')) == self._clean_symbol(symbol)
                    for p in getattr(self, 'open_positions', [])
                )
                if is_symbol_open:
                    skip_llm_reason = "Vị thế đang mở, quản trị rủi ro tập trung bằng AI Ensemble, TrapDetector và Trailing Stop"

                anchor_dir = None
                anchor_name = None
                anchor_conf = 0.0
                anchor_price = 0.0

                # Kiểm tra các ngưỡng chuẩn đã định lượng: Trend >= 75%, Trap >= 68%, Breakout >= 72%, MeanReversion >= 72%
                for s_name, (s_dir, s_conf) in best_tech_by_strat.items():
                    if ('trend' in s_name and s_conf >= 0.75) or                        ('trap' in s_name and s_conf >= 0.68) or                        ('momentum' in s_name and s_conf >= 0.72) or                        ('reversion' in s_name and s_conf >= 0.72):
                        if s_conf > anchor_conf:
                            anchor_conf = s_conf
                            anchor_dir = s_dir
                            anchor_name = s_name
                            anchor_price = float(best_price_by_strat.get(s_name) or 0.0)

                # [BÀI HỌC 85 - THUẬN THEO SỐ ĐÔNG & KẺ CÓ TIỀN]: Nhận diện ứng viên Smart Inversion
                # để KHÔNG hủy bỏ ở cổng Pre-LLM khi đang có dòng tiền cá mập (Whale Pump / Waterfall Dump / Climax),
                # cho phép đi thẳng vào JEV Agent và SignalAggregator để lật ngược thế cờ kiếm lợi nhuận!
                ma_dict = market_analysis if isinstance(market_analysis, dict) else {}
                ma_pump = float(ma_dict.get('recent_pump_pct') or 0.0)
                ma_dump = float(ma_dict.get('recent_dump_pct') or 0.0)
                ma_uwick = float(ma_dict.get('upper_wick_pct') or 0.0)
                ma_lwick = float(ma_dict.get('lower_wick_pct') or 0.0)
                ma_rvol = float(ma_dict.get('candle_vol_ratio') or 1.0)
                ma_rsi = float(ma_dict.get('tactical_rsi') or ma_dict.get('rsi') or 50.0)
                ai_dir_pre = str(getattr(getattr(ai_signal, 'signal', None), 'value', '') or '').upper() if 'ai_signal' in locals() and ai_signal else ''
                ai_conf_pre = float(getattr(ai_signal, 'confidence', 0.0) or 0.0) if 'ai_signal' in locals() and ai_signal else 0.0

                has_real_trap_pillar = any(
                    'trap' in sn and sc >= 0.68 and (
                        (sd == 'SELL' and ma_uwick >= 0.35)
                        or (sd == 'BUY' and ma_lwick >= 0.35 and not (ma_dump >= 0.025 and ma_lwick < 0.30))
                    )
                    for sn, sd, sc in all_tech_signals
                )

                is_smart_inversion_candidate = (
                    (ma_pump >= 0.025 and ma_rvol >= 2.0)  # Whale Pump Storm / Buying Climax
                    or (ma_rvol >= 2.5 and ma_pump >= 0.015)
                    or (ma_dump >= 0.025 and (ma_lwick < 0.30 or ma_lwick >= 0.35) and ma_rsi > 32.0)  # Waterfall Short / Selling Climax
                    or (ma_dump >= 0.015 and ma_lwick < 0.25 and ma_rvol >= 1.30 and ma_rsi > 32.0)
                    or (ma_uwick >= 0.35 and (ma_rvol >= 1.10 or ma_rsi >= 58.0))
                    or (ma_lwick >= 0.35 and (ma_rvol >= 1.10 or ma_rsi <= 42.0) and not (ma_dict.get('regime') == 'ranging' and 0.0 < _safe_float(ma_dict.get('tactical_adx')) < 20.0 and ai_dir_pre == 'SELL' and ai_conf_pre >= 0.65) and not (('downtrend' in str(ma_dict.get('regime', '')).lower() or _safe_float(ma_dict.get('adx')) >= 28.0) and ai_dir_pre == 'SELL' and ai_conf_pre >= 0.70))
                    or has_real_trap_pillar
                    or bool(ma_dict.get('in_fading_short_watchlist', False))
                    or (ai_dir_pre in ('BUY', 'SELL') and ai_conf_pre >= 0.68 and anchor_dir and ai_dir_pre != anchor_dir)
                )

                if not anchor_dir:
                    if is_smart_inversion_candidate:
                        # [BÀI HỌC 86]: Tự động xác lập Trụ Cột Kỹ Thuật Đảo Chiều (Smart Inversion Anchor)
                        # từ chính hình thái dòng tiền cá mập, cấm Fast-Skip bỏ lỡ siêu sóng!
                        if ma_pump >= 0.025 and ma_rvol >= 2.0:
                            anchor_dir = 'BUY'
                            anchor_name = 'WhalePumpStorm'
                            anchor_conf = 0.85
                        elif (ma_dump >= 0.025 and (ma_lwick < 0.30 or ma_lwick >= 0.35) and ma_rsi > 32.0) or (ma_dump >= 0.015 and ma_lwick < 0.25 and ma_rvol >= 1.30 and ma_rsi > 32.0):
                            anchor_dir = 'SELL'
                            anchor_name = 'WaterfallDump'
                            anchor_conf = 0.85
                        elif (ma_uwick >= 0.35 and (ma_rvol >= 1.10 or ma_rsi >= 58.0)) or bool(ma_dict.get('in_fading_short_watchlist', False)):
                            anchor_dir = 'SELL'
                            anchor_name = 'ExhaustionFadingShort'
                            anchor_conf = 0.85
                        elif ma_lwick >= 0.35 and (ma_rvol >= 1.10 or ma_rsi <= 42.0):
                            anchor_dir = 'BUY'
                            anchor_name = 'OversoldBounce'
                            anchor_conf = 0.85
                        else:
                            anchor_dir = ai_dir_pre if ai_dir_pre in ('BUY', 'SELL') else 'BUY'
                            anchor_name = 'SmartInversionFlow'
                            anchor_conf = max(0.80, ai_conf_pre)
                        logger.info(
                            f"🌊 [SMART INVERSION ANCHOR] Xác lập Trụ Cột Cá Mập cho {symbol}: {anchor_name} ({anchor_dir} {anchor_conf:.0%}), mở cổng vào JEV Agent & Aggregator!"
                        )
                    else:
                        skip_llm_reason = "Không có Trụ Cột Kỹ Thuật đạt chuẩn (Trend >= 75%, Trap >= 68%, Breakout >= 72%)"
                else:
                    # 2. Khử Xung Đột Nội Bộ (Zero Intra-Technical Clash) - Miễn trừ nếu là ứng viên Smart Inversion / Climax
                    if not is_smart_inversion_candidate:
                        for s_name, s_dir, s_conf in all_tech_signals:
                            if s_dir != anchor_dir and s_conf >= 0.68:
                                skip_llm_reason = f"Xung đột nội bộ kỹ thuật: {anchor_name} ({anchor_dir} {anchor_conf:.0%}) bị đối kháng bởi {s_name} ({s_dir} {s_conf:.0%})"
                                break

                # 3. Bộ Lọc Xung Lực Thị Trường (Dead ADX Gate)
                # [BÀI HỌC #96]: Khắc phục triệt để lỗi Falsy fallback (0.0 or 25.0 -> 25.0) làm vô hiệu hóa 100% Dead ADX Gate!
                # Chuẩn hóa việc đọc ADX: không gán cứng 25.0 khi ADX là 0.0 hoặc None.
                # Đối với các chiến lược theo xu hướng (TrendFollowing, Breakout), bắt buộc khung tác chiến 15M phải có xung lực (tactical_adx >= 20.0).
                # Nếu tactical_adx < 20.0 và không có bão volume (rvol < 1.8x), cấm tuyệt đối đánh Trend/Breakout vào thị trường đi ngang sideway chop!
                if not skip_llm_reason and anchor_name and 'trap' not in anchor_name.lower() and not is_smart_inversion_candidate:
                    macro_adx = float((market_analysis or {}).get('adx') or 0.0)
                    tactical_adx = float((market_analysis or {}).get('tactical_adx', 0.0) or 0.0)
                    anchor_is_trend_breakout = any(k in anchor_name.lower() for k in ('trend', 'breakout'))
                    ma_rvol_check = float((market_analysis or {}).get('candle_vol_ratio', 1.0) or 1.0)
                    
                    if anchor_is_trend_breakout and ma_rvol_check < 1.80:
                        if 0.0 < tactical_adx < 20.0:
                            skip_llm_reason = f"Thị trường 15M chết xung lực (tactical_ADX={tactical_adx:.1f} < 20.0, RVol={ma_rvol_check:.2f}x < 1.8x), cấm đánh {anchor_name} vào vùng sideway chop"
                        elif max(macro_adx, tactical_adx) < 20.0:
                            skip_llm_reason = f"Thị trường vĩ mô & vi mô chết thanh khoản (ADX_4H={macro_adx:.1f}, ADX_15M={tactical_adx:.1f} < 20.0), cấm đánh {anchor_name}"

                # 4. Bộ Lọc Chống Bắt Dao Rơi / Đâm Đầu Vào Bơm (Anti-Waterfall BUY & Anti-Bull-Ramp SELL)
                # [BÀI HỌC 85]: Nếu ứng viên thỏa mãn Smart Inversion (có dòng tiền cá mập hoặc AI ủng hộ chiều ngược lại),
                # KHÔNG Fast-Skip mà cho phép đi tiếp vào SignalAggregator để lật ngược từ BUY->SELL (Waterfall Short)
                # hoặc từ SELL->BUY (Momentum Ride)!
                if not skip_llm_reason and not is_smart_inversion_candidate:
                    df_check = dfs.get('15m')
                    if df_check is not None and len(df_check) >= 5:
                        c2, o2 = float(df_check['close'].iloc[-2]), float(df_check['open'].iloc[-2])
                        c3, o3 = float(df_check['close'].iloc[-3]), float(df_check['open'].iloc[-3])
                        c4, o4 = float(df_check['close'].iloc[-4]), float(df_check['open'].iloc[-4])
                        h2, l2 = float(df_check['high'].iloc[-2]), float(df_check['low'].iloc[-2])
                        rng2 = max(1e-8, h2 - l2)
                        _ref_px = anchor_price if anchor_price > 0 else float(df_check['close'].iloc[-1])

                        if anchor_dir == 'BUY':
                            # Nếu cả 3 nến 15M gần nhất đều là nến đỏ rơi tự do
                            if c2 < o2 and c3 < o3 and c4 < o4:
                                lower_wick2 = (c2 - l2) / rng2 if c2 >= l2 else 0.0
                                _abs_floor = l2 + WICK_ABSORPTION_ZONE_RATIO * rng2
                                if lower_wick2 < 0.35:
                                    skip_llm_reason = "Bẫy rơi tự do dạng thác nước (Waterfall 3 nến đỏ 15M không có râu gom)"
                                elif not _entry_inside_absorption_zone(_ref_px, h2, l2, 'BUY'):
                                    skip_llm_reason = (
                                        f"Bẫy rơi tự do dạng thác nước (Waterfall 3 nến đỏ 15M): râu dưới "
                                        f"{lower_wick2 * 100:.1f}% nhưng giá vào lệnh {_ref_px:.4f} đã bật ra ngoài "
                                        f"vùng hấp thụ 1/3 dưới ({l2:.4f} - {_abs_floor:.4f}) nên râu này là dấu vết xả cũ"
                                    )
                        elif anchor_dir == 'SELL':
                            # Nếu cả 3 nến 15M gần nhất đều là nến xanh dựng đứng bơm dốc
                            if c2 > o2 and c3 > o3 and c4 > o4:
                                upper_wick2 = (h2 - c2) / rng2 if h2 >= c2 else 0.0
                                _rej_ceiling = h2 - WICK_ABSORPTION_ZONE_RATIO * rng2
                                if upper_wick2 < 0.35:
                                    skip_llm_reason = "Bẫy tăng dốc dựng đứng dạng Bull Ramp (3 nến xanh 15M không có râu xả, cấm Short đón đầu)"
                                elif not _entry_inside_absorption_zone(_ref_px, h2, l2, 'SELL'):
                                    skip_llm_reason = (
                                        f"Bẫy tăng dốc dựng đứng dạng Bull Ramp (3 nến xanh 15M): râu trên "
                                        f"{upper_wick2 * 100:.1f}% nhưng giá vào lệnh {_ref_px:.4f} đã tụt ra ngoài "
                                        f"vùng hấp thụ 1/3 trên ({_rej_ceiling:.4f} - {h2:.4f}) nên râu này là dấu vết bơm cũ"
                                    )

                if skip_llm_reason:
                    logger.info(f"⏭️ [FAST-SKIP PRE-LLM] Bỏ qua gọi Ollama cho {symbol}: {skip_llm_reason} (Tiết kiệm 5-8s GPU).")
                    # A skipped JEV pass cannot validate a new entry. Carry an
                    # explicit entry-only marker to Phase 2; position management
                    # uses the raw strategy signals and remains unaffected.
                    for signal in signals:
                        metadata = getattr(signal, 'metadata', None)
                        if isinstance(metadata, dict):
                            metadata['pre_llm_entry_veto'] = {
                                'status': 'structural_fast_skip',
                                'reason': skip_llm_reason,
                            }
                else:
                    try:
                        df_tactical = dfs.get('15m')
                        if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                            df_tactical = dfs.get('5m')
                        if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                            df_tactical = primary_df
                        df_1h = dfs.get('1h')
                        df_4h = dfs.get('4h')
                        df_5m = dfs.get('5m')
                        from ai.ollama_runtime import ollama_phase2_enter, ollama_phase2_exit
                        ollama_phase2_enter()
                        try:
                            jev_resp = self.jev_agent.analyze_klines(
                                df=df_tactical,
                                symbol=symbol,
                                df_1h=df_1h,
                                df_4h=df_4h,
                                df_5m=df_5m
                            )
                        finally:
                            ollama_phase2_exit()
                        if jev_resp:
                            from strategies.base_strategy import TradeSignal, Signal
                            
                            jev_sig_val = Signal.HOLD
                            if jev_resp['decision'] == 'BUY': jev_sig_val = Signal.BUY
                            elif jev_resp['decision'] == 'SELL': jev_sig_val = Signal.SELL
                            
                            jev_signal = TradeSignal(
                                signal=jev_sig_val,
                                symbol=symbol,
                                confidence=jev_resp['confidence'],
                                strategy="jev_agent",
                                price=float(df_tactical['close'].iloc[-1]),
                                metadata={
                                    'reason': jev_resp['reason'],
                                    'risk_factors': jev_resp.get('risk_factors', 'none'),
                                    'availability_status': jev_resp.get('availability_status', 'ok'),
                                    'thinking': jev_resp.get('thinking', ''),
                                }
                            )
                            signals.append(jev_signal)
                            if jev_signal.signal.value != 'hold':
                                logger.info(
                                    f"⚡ [JEV Agent MTF] {symbol}: "
                                    f"{jev_signal.signal.value.upper()} "
                                    f"(confidence: {jev_signal.confidence:.2%})"
                                )
                    except Exception as e:
                        logger.error(f"Lỗi JEV Agent MTF analysis: {e}")
        
        if market_analysis:
            for signal in signals:
                signal.metadata.setdefault('market_analysis', market_analysis)
        for signal in signals:
            signal.metadata['dfs'] = dfs
        return signals

    def _ai_analysis(self, df, symbol: str, market_analysis: dict = None):
        """Phân tích bằng AI/ML model."""
        from strategies.base_strategy import TradeSignal, Signal
        
        try:
            # QUY TẮC BÀI HỌC SỐ 4: Neo dự đoán AI Ensemble vào nến đã đóng hoàn toàn (iloc[-2])
            # bằng cách bỏ cây nến đang chạy (df.iloc[:-1]) khi tính features dự báo, tránh nhiễu râu nến 1s đầu!
            df_for_ai = df.iloc[:-1] if (df is not None and len(df) > 55) else df
            features_df = self.feature_engine.generate_features(df_for_ai)
            
            if features_df is None or len(features_df) < 50:
                return None
            
            # Kiểm tra model đã train chưa
            model_path = str(self.root_dir / "data" / "models" / f"model_{symbol.replace('/', '_')}.pkl")
            # --- SMART AUTO-RETRAIN LOGIC ---
            if os.path.exists(model_path):
                file_age_days = (time.time() - os.path.getmtime(model_path)) / (24 * 3600)
                retrain_days = self.config.get('ai', {}).get('model_retrain_days', 7.0)
                if file_age_days > retrain_days:
                    logger.info(f"\u26a0\ufe0f N\u00e3o b\u1ed9 c\u1ee7a {symbol} \u0111\u00e3 c\u0169 ({file_age_days:.1f} ng\u00e0y). T\u1ef1 \u0111\u1ed9ng t\u1ea9y n\u00e3o \u0111\u1ec3 h\u1ecdc l\u1ea1i c\u1ea5u tr\u00fac m\u1edbi!")
                    try:
                        os.remove(model_path)
                    except Exception as e:
                        logger.error(f"L\u1ed7i khi x\u00f3a model c\u0169 {symbol}: {e}")
            # --------------------------------
            
            just_trained = False
            trained_cv_acc = 0.0
            if os.path.exists(model_path):
                self.ml_predictor.load_model(model_path)
            else:
                # Train model mới
                logger.info(f"🔄 Training AI model cho {symbol}...")
                train_res = self.ml_predictor.train(features_df)
                trained_cv_acc = float((train_res or {}).get('mean_cv_accuracy', 0.0))
                os.makedirs(os.path.dirname(model_path), exist_ok=True)
                self.ml_predictor.save_model(model_path)
                logger.info(f"✅ AI model trained và saved! (Mean CV Accuracy: {trained_cv_acc*100:.2f}%)")
                just_trained = True
            
            current_price = float(df['close'].iloc[-1])

            # COLD-START GUARD: Nếu vừa train model cấp tốc trên coin mới,
            # Bắt buộc Warm-up (tạm thời HOLD) để kiểm chứng nến tiếp theo, cấm BUY đu đỉnh ngay trên chính cây nến vừa train.
            if just_trained:
                logger.info(f"⏳ [Cold-start Warmup] Model {symbol} vừa train xong. Tạm thời HOLD 1 chu kỳ để kiểm chứng out-of-sample trước khi cấp lệnh.")
                return TradeSignal(
                    signal=Signal.HOLD,
                    symbol=symbol,
                    confidence=0.50,
                    strategy="ai_ensemble",
                    price=current_price,
                    metadata={'status': 'cold_start_warmup', 'mean_cv_accuracy': trained_cv_acc}
                )

            # Predict
            latest_features = features_df.iloc[[-1]]
            prediction, confidence = self.ml_predictor.predict(latest_features)
            
            # Tính toán ngưỡng tự tin động (Dynamic Threshold) dựa vào cấu trúc thị trường
            base_threshold = self.config['ai'].get('confidence_threshold', 0.60)
            dynamic_threshold = base_threshold
            
            regime_info = market_analysis or {}
            try:
                from ai.market_regime import MarketRegimeDetector, MarketRegime
                if not regime_info:
                    regime_info = MarketRegimeDetector().detect_regime(df)
                regime = regime_info.get('regime')
                if isinstance(regime, str):
                    regime = MarketRegime(regime)
                
                # Điều chỉnh ngưỡng tự tin tùy theo sức mạnh xu hướng
                if regime in [MarketRegime.STRONG_UPTREND, MarketRegime.STRONG_DOWNTREND]:
                    dynamic_threshold = max(0.40, base_threshold - 0.15)  # Xu hướng mạnh -> Dễ dãi hơn
                elif regime in [MarketRegime.UPTREND, MarketRegime.DOWNTREND]:
                    dynamic_threshold = max(0.50, base_threshold - 0.05)
                elif regime == MarketRegime.HIGH_VOLATILITY:
                    dynamic_threshold = min(0.85, base_threshold + 0.15)  # Biến động mạnh -> Khắt khe hơn

                # Ngưỡng sàn cơ sở của AI Ensemble: Tối thiểu 58% để đồng bộ với chuẩn Cold-start CV Accuracy >= 58%,
                # triệt tiêu các tín hiệu dự đoán ngang tung đồng xu ngẫu nhiên (như 52.8% của QNT).
                dynamic_threshold = max(0.58, dynamic_threshold)
            except Exception as e:
                pass
            
            if prediction == 1 and confidence >= dynamic_threshold:
                return TradeSignal(
                    signal=Signal.BUY,
                    symbol=symbol,
                    confidence=confidence,
                    strategy="ai_ensemble",
                    price=current_price,
                    metadata={
                        'prediction': 'up', 'model_confidence': confidence,
                        'threshold': dynamic_threshold, 'market_analysis': market_analysis or {},
                    }
                )
            elif prediction == 0 and confidence >= dynamic_threshold:
                return TradeSignal(
                    signal=Signal.SELL,
                    symbol=symbol,
                    confidence=confidence,
                    strategy="ai_ensemble",
                    price=current_price,
                    metadata={
                        'prediction': 'down', 'model_confidence': confidence,
                        'threshold': dynamic_threshold, 'market_analysis': market_analysis or {},
                    }
                )
            
            # Khi độ tự tin AI Ensemble thấp hơn ngưỡng dynamic_threshold, trả về tín hiệu HOLD kèm confidence thực tế
            # để SignalAggregator nhận diện được ai_sig yếu (<60%) và kích hoạt chuẩn xác MICRO CONSENSUS VETO (ép ADX >= 30.0)!
            return TradeSignal(
                signal=Signal.HOLD,
                symbol=symbol,
                confidence=confidence,
                strategy="ai_ensemble",
                price=current_price,
                metadata={
                    'prediction': 'up' if prediction == 1 else 'down',
                    'model_confidence': confidence,
                    'threshold': dynamic_threshold,
                    'market_analysis': market_analysis or {},
                }
            )
            
        except Exception as e:
            logger.error(f"Lỗi AI analysis: {e}")
            return None

    
    def _get_market_chop_context(self) -> dict:
        """Đo ADX/ATR thật của BTC & ETH trên khung 15m để làm bối cảnh cho CRYPTO CHOP SHIELD.

        [SỬA LỖI GỐC RỄ] Trước đây SignalAggregator tự "đo" BTC/ETH bằng market_analysis của
        CHÍNH ứng viên đang xét, nên khi ứng viên là Altcoin thì shield không bao giờ có bối cảnh
        thật, còn khi ứng viên là BTC/ETH thì phép đo lại lấy chỉ số của chính nó. Nay bot đo
        độc lập từ dữ liệu 15m của BTC/USDT và ETH/USDT (cache 120s để không tốn API).

        Trả về {} nếu chưa đo được -> shield không tự kích hoạt (fail-open).
        """
        now = time.time()
        cached = getattr(self, '_market_chop_context_cache', None)
        if isinstance(cached, dict) and (now - float(cached.get('ts') or 0.0) < 120.0):
            return cached.get('data') or {}

        data = {}
        try:
            from ai.market_regime import MarketRegimeDetector
            detector = MarketRegimeDetector()
        except Exception:
            detector = None
        for symbol in ('BTC/USDT', 'ETH/USDT'):
            try:
                # [BẮT BUỘC >= 100 nến] MarketRegimeDetector.detect_regime() trả
                # adx=0.0/atr_pct=0.0 khi len(df) < 100 (xem ai/market_regime.py:35).
                # Trước đây chỗ này gọi limit=60 nên LUÔN nhận về 0.0, khiên hiểu nhầm
                # "BTC/ETH ADX=0 -> đang nén" và bật khóa 100% lệnh Altcoin vô thời hạn.
                df = self.data_collector.fetch_data(symbol, '15m', limit=300)
                if df is None or len(df) < 100:
                    continue
                # detect_regime tự loại nến chưa đóng một lần; không cắt hai lần
                # làm Chop Shield dùng nến đã đóng cũ hơn 15 phút.
                info = detector.detect_regime(df) if detector else {}
                adx_val = float((info or {}).get('adx') or 0.0)
                atr_pct_val = float((info or {}).get('atr_pct') or 0.0)
                # 0.0/0.0 nghĩa là CHƯA đo được, không phải "thị trường nén".
                # Bỏ qua để shield fail-open thay vì khóa oan.
                if adx_val <= 0.0 and atr_pct_val <= 0.0:
                    logger.debug(f"Chưa đo được ADX/ATR của {symbol} cho Chop Shield - bỏ qua.")
                    continue
                data[symbol.split('/')[0]] = {
                    'adx': adx_val,
                    'atr_pct': atr_pct_val,
                }
            except Exception as e:
                logger.debug(f"Không đo được bối cảnh {symbol} cho Chop Shield: {e}")

        self._market_chop_context_cache = {'ts': now, 'data': data}
        return data

    def _notify_telegram(self, msg: str, on_delivery: Optional[Callable[[bool], None]] = None):
        # Credentials belong in environment variables, with fallback to config.
        token = (
            os.getenv('TELEGRAM_BOT_TOKEN', '')
            or self.config.get('notifications', {}).get('telegram_token', '')
        )
        chat_id = (
            os.getenv('TELEGRAM_CHAT_ID', '')
            or self.config.get('notifications', {}).get('telegram_chat_id', '')
        )
        if token and chat_id:
            self._telegram_warning_logged = False
            try:
                queued = send_telegram_message(token, chat_id, msg, on_delivery=on_delivery)
            except Exception as e:
                logger.warning("Telegram không nhận được yêu cầu gửi tin: %s", e)
                queued = False
                if callable(on_delivery):
                    on_delivery(False)
            if not queued:
                logger.warning("Telegram chưa xác nhận tin nhắn; xem phản hồi API và kiểm tra lại token/chat ID.")
        else:
            if not self._telegram_warning_logged:
                logger.warning("Telegram chưa được cấu hình: thêm TELEGRAM_BOT_TOKEN và TELEGRAM_CHAT_ID trong .env hoặc giao diện Telegram.")
                self._telegram_warning_logged = True
            if callable(on_delivery):
                on_delivery(False)

    def _fee_safe_breakeven_stop(self, position: dict) -> float:
        """Return the fee-aware BE stop plus the configured minimum profit lock."""
        net_be = self._trailing_net_breakeven(position)
        try:
            lock_pct = float(self.config.get('risk', {}).get('trailing_min_lock_profit_pct', 0.001))
        except (TypeError, ValueError, OverflowError):
            lock_pct = 0.001
        lock_pct = min(0.05, max(0.0, lock_pct))
        if position.get('direction', 'LONG') == 'LONG':
            return net_be * (1.0 + lock_pct)
        return net_be * (1.0 - lock_pct)

    def _stop_meets_fee_safe_breakeven(self, position: dict, stop_price: float) -> bool:
        try:
            stop_price = float(stop_price)
            target = self._fee_safe_breakeven_stop(position)
            if not math.isfinite(stop_price) or stop_price <= 0 or target <= 0:
                return False
            if position.get('direction', 'LONG') == 'LONG':
                return stop_price >= target
            return stop_price <= target
        except (TypeError, ValueError, OverflowError):
            return False

    @staticmethod
    def _stop_has_minimum_market_buffer(direction: str, stop_price: float, current_price: float) -> bool:
        try:
            stop_price = float(stop_price)
            current_price = float(current_price)
            if not math.isfinite(stop_price) or not math.isfinite(current_price) or current_price <= 0:
                return False
            min_buffer_dist = current_price * MIN_STOP_MARKET_BUFFER_PCT
            if direction == 'LONG':
                return stop_price <= current_price - min_buffer_dist
            return stop_price >= current_price + min_buffer_dist
        except (TypeError, ValueError, OverflowError):
            return False

    @staticmethod
    def _crr_snell_optimal_exit_check(
        current_profit_pct: float,
        max_profit_pct: float,
        atr_pct: float,
        held_minutes: float,
        is_super_wave: bool = False,
        exhaustion_wick: float = 0.0,
        adverse_rvol: float = 1.0,
    ) -> bool:
        """
        [BÀI HỌC 98 & 99 - CÂY NHỊ PHÂN CRR ĐỊNH GIÁ QUYỀN CHỌN KIỂU MỸ (SNELL ENVELOPE OPTIMAL EXIT)]:
        Khi vị thế đang chạy nấc Runner (đã chốt Partial TP1 hoặc TP1 unavailable) với lãi >= +1.50% và đã giữ >= 3.0 phút:
        Tính toán Đường Biên Dừng Tối Ưu (Snell Envelope) bằng cây nhị phân CRR 15 bước.
        Nếu thị trường xuất hiện dấu hiệu kiệt sức vật lý (MFE pullback >= 18% từ đỉnh, râu xả đỉnh >= 35%, hoặc volume đối kháng >= 1.6x),
        động lượng kỳ vọng chuyển sang âm và Giá Trị Nội Tại chốt ngay g(S) >= Kỳ Vọng Nắm Giữ Tiếp C(S).
        Thuật toán ra quyết định CHỐT LỜI TỐI ƯU TẠI ĐỈNH SÓNG (Optimal Peak Exit) bảo toàn 80%+ đỉnh MFE thay vì chờ giá sập về Trailing Stop!
        """
        if current_profit_pct < 0.0150 or held_minutes < 3.0:
            return False
        
        try:
            intrinsic_value = current_profit_pct
            mu = 0.0010  # Baseline drift dương khi xu hướng tăng trưởng lành mạnh
            has_physical_exhaustion = False

            # 1. Độ thoái lui từ đỉnh cao nhất (MFE pullback >= 18% của đỉnh lãi)
            if max_profit_pct >= 0.0180:
                pullback_ratio = (max_profit_pct - current_profit_pct) / max_profit_pct
                if pullback_ratio >= 0.18:
                    mu -= 0.015 * (pullback_ratio / 0.18)
                    has_physical_exhaustion = True

            # 2. Râu nến xả từ chối đỉnh vật lý (exhaustion wick >= 35%)
            if exhaustion_wick >= 0.35:
                mu -= 0.012 * (exhaustion_wick / 0.35)
                has_physical_exhaustion = True

            # 3. Đột biến volume nến đối kháng (adverse rvol >= 1.6x)
            if adverse_rvol >= 1.60:
                mu -= 0.010 * (adverse_rvol / 1.60)
                has_physical_exhaustion = True

            # Nếu sóng vẫn đang tăng lành mạnh, không có râu xả và không thoái lui -> TIẾP TỤC GỒNG SÓNG!
            if not has_physical_exhaustion:
                return False

            n_steps = 15
            dt = 1.0 / n_steps
            sigma = max(0.005, (atr_pct if atr_pct > 0 else 0.012) / 2.0)
            u = math.exp(sigma * math.sqrt(dt))
            d = 1.0 / u
            p = (math.exp(mu * dt) - d) / (u - d)
            p = max(0.05, min(0.95, p))

            val_up = current_profit_pct * u
            val_down = current_profit_pct * d
            continuation_value = (p * val_up + (1.0 - p) * val_down)

            return intrinsic_value >= continuation_value
        except Exception:
            return False

    def _queue_breakeven_telegram(self, position: dict, stop_price: float, source: str):
        """Queue a BE alert and persist notified_be only after Telegram confirms delivery."""
        if position.get('notified_be'):
            return
        if position.get('be_notification_pending'):
            try:
                pending_since = float(position.get('be_notification_pending_since') or 0.0)
            except (TypeError, ValueError, OverflowError):
                pending_since = 0.0
            if pending_since > 0 and time.time() - pending_since < 180.0:
                return
            # Recover a queued notification after a daemon restart or a dead worker.
            position['be_notification_pending'] = False
        if not self._stop_meets_fee_safe_breakeven(position, stop_price):
            return

        is_live_futures = self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures'
        if is_live_futures and (
            not position.get('sl_order_id')
            or position.get('protection_status') != 'exchange_stop_verified'
        ):
            logger.warning(
                "Chưa gửi thông báo BE cho %s vì chưa có SL sàn được xác nhận.",
                position.get('symbol'),
            )
            return

        now = time.time()
        try:
            retry_after = float(position.get('be_notification_retry_after') or 0.0)
        except (TypeError, ValueError, OverflowError):
            retry_after = 0.0
        if now < retry_after:
            return

        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        source_label = 'Khóa thời gian 60 phút' if source == 'time_60m' else 'Trailing thích ứng'
        msg = (
            f"🛡️ **[BẢO TOÀN VỐN - HÒA VỐN ĐÃ XÁC NHẬN]**\n"
            f"Cặp: **{position.get('symbol')}** ({position.get('direction', 'LONG')})\n"
            f"🔹 **SL sàn mới:** `{float(stop_price):.8g}`\n"
            f"💸 **Ngưỡng SL đã tính phí và buffer:** `{self._fee_safe_breakeven_stop(position):.8g}` {quote}\n"
            f"⚙️ **Nguồn kích hoạt:** {source_label}. Binance đã xác nhận lệnh bảo vệ."
        )
        position['be_notification_pending'] = True
        position['be_notification_pending_since'] = time.time()

        def on_delivery(delivered: bool):
            with self._position_lock:
                position['be_notification_pending'] = False
                position.pop('be_notification_pending_since', None)
                position['be_notification_delivery'] = 'delivered' if delivered else 'failed'
                if delivered:
                    position['notified_be'] = True
                    position.pop('be_notification_retry_after', None)
                else:
                    position['notified_be'] = False
                    position['be_notification_retry_after'] = time.time() + 60.0
                self._save_state()
                if delivered:
                    logger.info("Telegram BE đã được xác nhận giao tới Telegram cho %s.", position.get('symbol'))
                else:
                    logger.error("Telegram BE chưa giao được cho %s; có thể thử lại sau 60 giây.", position.get('symbol'))

        self._notify_telegram(msg, on_delivery=on_delivery)

    def _configured_max_leverage(self) -> int:
        try:
            value = float(self.config.get('trading', {}).get('max_leverage', 5))
            if not math.isfinite(value):
                return 1
            return min(150, max(1, int(value)))
        except (TypeError, ValueError, OverflowError):
            return 1

    def _configured_min_open_positions(self) -> int:
        """Return the minimum floor for dynamic position coordination."""
        val = self.config.get('trading', {}).get('min_open_trades', 1)
        try:
            return max(1, min(20, int(val)))
        except (TypeError, ValueError, OverflowError):
            return 1

    def _confirmed_filled_amount(self, order: dict, symbol: str, requested_amount: float) -> float:
        """Chỉ trả khối lượng đã khớp thật; ID/amount của lệnh mới không phải fill."""
        try:
            requested = abs(float(requested_amount))
            if not isinstance(order, dict) or requested <= 0:
                return 0.0
            filled = float(order.get('filled') or 0.0)
            if filled <= 0:
                info = order.get('info') or {}
                order_id = str(order.get('id') or info.get('orderId') or '')
                if order_id and self.mode == 'live':
                    try:
                        fresh = self.exchange.get_order_status(order_id, symbol) or {}
                        filled = float(fresh.get('filled') or 0.0)
                    except Exception:
                        filled = 0.0
            if not math.isfinite(filled) or filled <= 0:
                return 0.0
            return min(requested, filled)
        except (TypeError, ValueError, OverflowError):
            return 0.0

    def _is_position_risk_free(self, position: dict) -> bool:
        """Kiểm tra xem vị thế đã triệt tiêu rủi ro vốn (Free-Roll) hay chưa.
        Điều kiện Free-Roll:
        1. Đã chốt lời từng phần (partial_tp_done == True) -> Lợi nhuận đã khóa vào số dư.
        2. HOẶC Stop-Loss đã được kéo về mức hòa vốn có lãi (>= entry * 1.0012 cho LONG, <= entry * 0.9988 cho SHORT).
        """
        try:
            if not position or not isinstance(position, dict):
                return False
            # Partial TP một mình KHÔNG chứng minh phần còn lại không còn rủi ro.
            entry = float(position.get('entry_price') or 0.0)
            sl = float(position.get('stop_loss') or 0.0)
            direction = str(position.get('direction', 'LONG')).upper()
            if entry <= 0 or sl <= 0:
                return False
            
            # Phải có SL vượt mốc hòa vốn sau phí và (với LIVE) có xác nhận SL sàn.
            be_stop = float(self._fee_safe_breakeven_stop(position) or 0.0)
            if be_stop <= 0:
                return False
            beyond_be = sl <= be_stop if direction == 'SHORT' else sl >= be_stop
            if not beyond_be:
                return False
            if self.mode == 'live':
                return bool(
                    position.get('sl_order_id')
                    or position.get('exchange_stop_verified')
                    or position.get('protection_status') == 'exchange_stop'
                )
            return True
        except Exception:
            return False

    def _count_at_risk_positions(self, exclude_symbol: Optional[str] = None) -> int:
        """Đếm số lượng vị thế ĐANG CHỊU RỦI RO (At-Risk Positions).
        Loại trừ các vị thế đã Free-Roll (Hòa Vốn / Đã Partial TP).
        """
        count = 0
        exclude_clean = self._clean_symbol(exclude_symbol) if exclude_symbol else None
        raw_pos = getattr(self, 'open_positions', []) or []
        pos_list = list(raw_pos.values()) if isinstance(raw_pos, dict) else list(raw_pos)
        for p in pos_list:
            try:
                sym = self._clean_symbol(p.get('symbol', ''))
                if exclude_clean and sym == exclude_clean:
                    continue
                if not self._is_position_risk_free(p):
                    count += 1
            except Exception:
                count += 1
        return count

    def _configured_max_at_risk_positions(self) -> int:
        """Số vị thế chịu rủi ro đồng thời tối đa (At-Risk Slots).
        Mặc định: 2 vị thế chịu rủi ro cùng lúc để bảo vệ drawdown (Max Risk <= 1.2% NAV),
        nhưng không bao giờ vượt quá trần cấu hình vị thế tối đa configured_cap.
        """
        risk_limit = self.config.get('risk', {}).get('max_at_risk_positions', 2)
        try:
            val = max(1, min(5, int(risk_limit)))
        except Exception:
            val = 2
        return min(val, self._configured_max_open_positions())

    def _configured_max_open_positions(self) -> int:
        """Return the configurable safety ceiling, dynamically scaling with equity and risk budgeting."""
        trading_limit = self.config.get('trading', {}).get('max_open_trades', None)
        risk_limit = self.config.get('risk', {}).get('max_open_positions', 10)
        
        # Tự động co giãn tổng số slot vị thế tối đa theo nấc vốn thực tế (Tiered Capital Scaling):
        # Dưới 100$: 3 slot (2 at-risk + 1 free-roll)
        # 100$ - 300$: 4 slot (2 at-risk + 2 free-roll tái chế)
        # 300$ - 1,000$: 5 slot
        # 1,000$ - 5,000$: 6 slot
        # 5,000$ - 20,000$: 8 slot
        # Trên 20,000$: 10 slot
        equity = 40.0
        try:
            portfolio_equity, _, _ = self._portfolio_capacity_snapshot()
            if portfolio_equity and portfolio_equity > 0:
                equity = float(portfolio_equity)
            else:
                equity = float(getattr(self, 'balance', 40.0) or 40.0)
        except Exception:
            equity = float(getattr(self, 'balance', 40.0) or 40.0)

        if equity < 100.0:
            equity_slots = 3
        elif equity < 300.0:
            equity_slots = 4
        elif equity < 1000.0:
            equity_slots = 5
        elif equity < 5000.0:
            equity_slots = 6
        elif equity < 20000.0:
            equity_slots = 8
        else:
            equity_slots = 10

        # NGUYÊN TẮC TÔN TRỌNG TUYỆT ĐỐI THIẾT LẬP NGƯỜI DÙNG (User Override Authority):
        # Nếu người dùng đã chỉ định rõ trên Web UI hoặc Local Dashboard (trading_limit),
        # bot PHẢI tuân thủ tuyệt đối con số người dùng đã chọn (base_cfg), không được tự ý ép tăng.
        # Chỉ khi người dùng KHÔNG cấu hình (trading_limit is None - Auto Mode), bot mới tự động áp dụng equity_slots theo bậc vốn.
        configured_cap = equity_slots
        if trading_limit is not None:
            try:
                base_cfg = max(1, min(20, int(trading_limit)))
                configured_cap = base_cfg
            except (TypeError, ValueError, OverflowError):
                pass
        
        try:
            risk_cap = max(1, min(100, int(risk_limit)))
            return min(risk_cap, configured_cap)
        except Exception:
            return configured_cap

    def _max_margin_utilization(self) -> float:
        """Read the configured equity fraction reserved for futures margin."""
        try:
            value = float(self.config.get('risk', {}).get('max_margin_utilization_pct', 0.50))
            if value > 1:
                value /= 100.0
        except (TypeError, ValueError, OverflowError):
            value = 0.50
        if not math.isfinite(value) or not 0.05 <= value <= 0.90:
            return 0.50
        return value

    def _max_total_open_risk(self) -> float:
        """Read the portfolio stop-loss risk ceiling as a fraction of equity."""
        try:
            value = float(self.config.get('risk', {}).get('max_total_open_risk_pct', 0.08))
            if value > 1:
                value /= 100.0
        except (TypeError, ValueError, OverflowError):
            value = 0.08
        if not math.isfinite(value) or not 0.01 <= value <= 0.25:
            return 0.08
        return value

    def _portfolio_capacity_snapshot(self):
        """Return (equity, used margin, free margin) from the freshest safe source."""
        positions = list(getattr(self, 'open_positions', []) or [])
        local_used_margin = 0.0
        local_unrealized = 0.0
        for position in positions:
            try:
                local_used_margin += max(0.0, float(
                    position.get('exchange_initial_margin') or position.get('cost') or 0.0
                ))
                local_unrealized += float(
                    position.get('unrealized_pnl_mark', position.get('real_pnl', 0.0)) or 0.0
                )
            except (TypeError, ValueError, OverflowError):
                continue

        snapshot = getattr(self, '_futures_account_snapshot', None)
        snapshot_age = None
        snapshot_clock = getattr(self, '_futures_account_snapshot_monotonic', None)
        if snapshot_clock is not None:
            try:
                import time as _time
                snapshot_age = _time.monotonic() - snapshot_clock
            except (TypeError, ValueError, OverflowError):
                snapshot_age = None
        if (
            getattr(self, 'mode', 'demo') == 'live'
            and getattr(self, 'market_type', 'spot') == 'futures'
            and snapshot
            and snapshot_age is not None
            and 0 <= snapshot_age <= 30
        ):
            try:
                equity = float(snapshot.get('margin_balance'))
                used_margin = float(snapshot.get('initial_margin') or local_used_margin)
                free_balance = float(snapshot.get('available_balance', self.balance))
                if all(math.isfinite(value) for value in (equity, used_margin, free_balance)) and equity > 0:
                    used_margin = max(0.0, used_margin)
                    free_margin = max(
                        0.0,
                        min(free_balance, equity * self._max_margin_utilization() - used_margin),
                    )
                    return equity, used_margin, free_margin
            except (TypeError, ValueError, OverflowError):
                pass

        try:
            free_balance = max(0.0, float(self.balance))
        except (TypeError, ValueError, OverflowError):
            free_balance = 0.0
        equity = max(0.0, free_balance + local_used_margin + local_unrealized)
        free_margin = max(
            0.0,
            min(free_balance, equity * self._max_margin_utilization() - local_used_margin),
        )
        return equity, local_used_margin, free_margin

    def _current_open_stop_risk(self) -> float:
        """Estimate the combined loss at current protective stops for open positions."""
        try:
            fallback_stop_pct = float(self.config.get('risk', {}).get('stop_loss_pct', 0.04))
        except (TypeError, ValueError, OverflowError):
            fallback_stop_pct = 0.04
        if not math.isfinite(fallback_stop_pct) or not 0 < fallback_stop_pct < 1:
            fallback_stop_pct = 0.04

        total_risk = 0.0
        raw_positions = getattr(self, 'open_positions', []) or []
        positions_list = list(raw_positions.values()) if isinstance(raw_positions, dict) else list(raw_positions)
        for position in positions_list:
            try:
                entry = float(position.get('entry_price') or 0.0)
                amount = abs(float(position.get('amount') or 0.0))
                stop = float(position.get('stop_loss') or 0.0)
                direction = str(position.get('direction', 'LONG')).upper()
                if entry <= 0 or amount <= 0:
                    continue
                if self._is_position_risk_free(position):
                    # Vị thế đã Free-Roll (Hòa Vốn hoặc đã Partial TP): Rủi ro vốn = 0.0
                    distance = 0.0
                elif stop > 0:
                    # Nếu Stop Loss đã dịch vào vùng có lãi hoặc hòa vốn (Trailing SL bảo vệ):
                    # Rủi ro vốn thực tế = 0 (không tính lãi bảo vệ thành rủi ro)
                    if direction == 'SHORT':
                        distance = max(0.0, stop - entry)
                    else:
                        distance = max(0.0, entry - stop)
                else:
                    distance = entry * fallback_stop_pct
                if math.isfinite(distance):
                    total_risk += amount * distance
            except (TypeError, ValueError, OverflowError):
                continue
        return max(0.0, total_risk)

    def _dynamic_open_position_limit(self, signal, precomputed_leverage: Optional[int] = None) -> int:
        """Estimate an open-position cap from analysis, equity, margin and stop risk."""
        hard_cap = self._configured_max_open_positions()
        if getattr(self, 'free_roll_recycling', True):
            raw_pos = getattr(self, 'open_positions', []) or []
            pos_list = list(raw_pos.values()) if isinstance(raw_pos, dict) else list(raw_pos)
            free_roll_count = sum(1 for p in pos_list if self._is_position_risk_free(p))
            if free_roll_count > 0:
                hard_cap = min(hard_cap + free_roll_count, hard_cap + 2)
        sig_clean = self._clean_symbol(getattr(signal, 'symbol', ''))
        stalking_dict = getattr(self, 'pending_stalking_orders', {}) or {}
        stalking_other_count = sum(
            1 for k in stalking_dict if self._clean_symbol(k) != sig_clean
        )
        current_count = len(getattr(self, 'open_positions', []) or []) + stalking_other_count
        self.last_dynamic_position_limit = max(current_count, hard_cap)
        if hard_cap <= 0:
            self.last_dynamic_position_limit = current_count
            self.last_position_signal_quality = None
            return current_count

        metadata = getattr(signal, 'metadata', {}) or {}
        metadata = metadata if isinstance(metadata, dict) else {}
        market = metadata.get('market_analysis') or {}
        market = market if isinstance(market, dict) else {}
        try:
            confidence = float(signal.confidence)
            agreement = float(metadata.get('agreement_ratio', 0.0))
            adx = float(market.get('adx', 0.0))
            di_plus = float(market.get('di_plus', 0.0))
            di_minus = float(market.get('di_minus', 0.0))
            atr_pct = float(market.get('atr_pct', 0.0))
            metrics = (confidence, agreement, adx, di_plus, di_minus, atr_pct)
            if not all(math.isfinite(value) for value in metrics):
                raise ValueError('non-finite signal metrics')
        except (TypeError, ValueError, OverflowError):
            confidence, agreement, adx, di_plus, di_minus, atr_pct = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0

        confidence = min(1.0, max(0.0, confidence))
        agreement = min(1.0, max(0.0, agreement))
        try:
            threshold = float(self.config.get('ai', {}).get('confidence_threshold', 0.65))
            if not math.isfinite(threshold):
                threshold = 0.65
        except (TypeError, ValueError, OverflowError):
            threshold = 0.65
        threshold = min(0.95, max(0.0, threshold))

        regime = str(market.get('regime', 'unknown')).lower()
        direction = str(getattr(getattr(signal, 'signal', None), 'value', '')).lower()
        bullish = direction == 'buy'
        ema_alignment = str(market.get('ema_alignment', '')).lower()
        trend_aligned = (
            (bullish and (ema_alignment == 'bullish' or di_plus > di_minus))
            or (not bullish and (ema_alignment == 'bearish' or di_minus > di_plus))
        )
        strong_trend = (
            'strong_uptrend' in regime or 'strong_downtrend' in regime
            or regime in ('uptrend', 'downtrend') or adx >= 25
        )
        ai_bias = str(metadata.get('ai_bias', 'NEUTRAL')).upper()
        bias_aligned = (
            ai_bias == 'NEUTRAL'
            or (ai_bias == 'BULLISH' and bullish)
            or (ai_bias == 'BEARISH' and not bullish)
        )

        confidence_quality = min(
            1.0,
            max(0.0, (confidence - threshold) / max(0.05, 1.0 - threshold)),
        )
        trend_quality = 1.0 if trend_aligned and strong_trend else (0.2 if not trend_aligned else 0.5)
        volatility_quality = min(1.0, max(0.1, 1.0 - atr_pct / 5.0)) if atr_pct > 0 else 0.3
        quality = 0.45 * confidence_quality + 0.35 * agreement + 0.15 * trend_quality + 0.05 * volatility_quality
        if regime == 'high_volatility' or (adx >= 25 and not trend_aligned):
            quality *= 0.65
        self.last_position_signal_quality = round(quality, 3)

        min_cap = self._configured_min_open_positions()
        hard_cap = max(min_cap, hard_cap)
        try:
            ai_recommendation = int(self.ai_recommended_max_positions)
        except (TypeError, ValueError, OverflowError):
            ai_recommendation = min_cap
        ai_recommendation = min(hard_cap, max(min_cap, ai_recommendation))

        # AI's suggested count is advisory. The technical/quant score can grow
        # the target smoothly; margin and aggregate stop risk still cap it.
        base_cap = self._configured_max_open_positions()
        expansion_spread = max(0, hard_cap - base_cap)
        if expansion_spread > 0:
            if quality < 0.30:
                bonus = 0
            elif quality < 0.60:
                bonus = min(1, expansion_spread)
            else:
                bonus = min(2, expansion_spread)
            quality_cap = min(hard_cap, base_cap + bonus)
        else:
            spread = max(0, base_cap - min_cap)
            quality_cap = min(base_cap, base_cap if quality >= 0.25 else min_cap)

        ai_quality_cap = min(
            hard_cap,
            max(min_cap, min_cap + round(quality * max(0, min(hard_cap, ai_recommendation) - min_cap))),
        )
        analysis_cap = min(hard_cap, max(quality_cap, ai_quality_cap))

        equity, used_margin, free_margin = self._portfolio_capacity_snapshot()
        risk_cfg = self.config.get('risk', {})
        try:
            risk_pct = float(risk_cfg.get('max_risk_per_trade', 0.0060))
        except (TypeError, ValueError, OverflowError):
            risk_pct = 0.0060
        if not math.isfinite(risk_pct) or not 0 < risk_pct <= 0.05:
            risk_pct = 0.0060
        # Đồng bộ 100% với _execute_signal_locked: khống chế cứng ngân sách rủi ro tối đa 0.60% NAV
        if risk_pct > 0.010:
            risk_pct = 0.0060
        current_stop_risk = self._current_open_stop_risk()
        remaining_total_risk = max(0.0, equity * self._max_total_open_risk() - current_stop_risk)

        try:
            price = float(signal.price)
            stop = float(getattr(signal, 'stop_loss', None) or 0.0)
        except (TypeError, ValueError, OverflowError):
            price, stop = 0.0, 0.0
        if price > 0 and stop > 0:
            stop_distance_pct = abs(price - stop) / price
        else:
            try:
                stop_distance_pct = float(risk_cfg.get('stop_loss_pct', 0.02))
            except (TypeError, ValueError, OverflowError):
                stop_distance_pct = 0.02
        if not math.isfinite(stop_distance_pct) or not 0 < stop_distance_pct < 1:
            stop_distance_pct = 0.02
        # Kẹp khoảng cách SL vào đúng dải [1.5%, 3.5%] như _execute_signal_locked để tránh phóng đại candidate_margin gấp 5 lần
        stop_distance_pct = min(0.035, max(0.015, stop_distance_pct))

        max_dollar_risk = max(0.35, max(0.0, equity) * risk_pct)
        candidate_risk = min(
            max_dollar_risk,
            remaining_total_risk,
        )
        margin_slots = 0
        risk_slots = 0
        candidate_margin = 0.0
        candidate_notional = 0.0
        candidate_leverage = 1
        leverage_verified = True
        if candidate_risk > 0 and stop_distance_pct > 0:
            candidate_notional = candidate_risk / stop_distance_pct
            if precomputed_leverage is not None and precomputed_leverage > 0:
                candidate_leverage = int(precomputed_leverage)
            else:
                candidate_leverage = self._select_dynamic_leverage(signal)
            if getattr(self, 'market_type', 'spot') == 'futures':
                resolved_leverage, leverage_limit = self._resolve_pair_leverage(
                    signal.symbol, candidate_leverage, candidate_notional, free_margin,
                )
                leverage_verified = bool(leverage_limit.get('verified'))
                self.last_leverage_symbol = signal.symbol
                self.last_pair_max_leverage = leverage_limit.get('max_leverage')
                self.last_leverage_limit_verified = leverage_verified
                self.last_leverage_limit_source = leverage_limit.get('source')
                if resolved_leverage is None:
                    candidate_leverage = 0
                else:
                    candidate_leverage = max(1, int(resolved_leverage))
            if candidate_leverage > 0 and candidate_notional > 0:
                candidate_margin = candidate_notional / candidate_leverage
                if candidate_margin > 0 and free_margin > 0:
                    margin_slots = max(0, int((free_margin + 1e-9) / candidate_margin))
                    if margin_slots == 0:
                        # _execute_signal_locked caps the actual order size to
                        # available_margin. Allow that one reduced-size position
                        # through the slot gate; its stop risk stays at or below
                        # the candidate risk budget, and exchange min-notional
                        # checks can still reject it later.
                        margin_slots = 1
                        logger.info(
                            "Allow one reduced-size slot for %s: candidate margin %.2f exceeds "
                            "available margin %.2f; execution will cap size to available margin.",
                            signal.symbol, candidate_margin, free_margin,
                        )
                if candidate_risk > 0:
                    risk_slots = max(0, int((remaining_total_risk + 1e-9) / candidate_risk))

        account_cap = current_count + margin_slots
        risk_cap = current_count + risk_slots
        allowed = min(hard_cap, analysis_cap, account_cap, risk_cap)
        if getattr(self, 'mode', 'demo') == 'live' and not leverage_verified:
            # Never allocate new LIVE capacity from an unverified symbol tier.
            allowed = current_count
        allowed = max(current_count, allowed)
        self.last_dynamic_position_limit = allowed
        self.last_position_available_margin = round(free_margin, 6)
        self.last_position_open_risk = round(current_stop_risk, 6)
        self.last_position_risk_budget = round(remaining_total_risk, 6)
        logger.info(
            "Adaptive open-position cap for %s: %d/%d (analysis=%d, AI suggestion=%d, "
            "equity=%.2f, free margin=%.2f, candidate margin=%.2f at %dx, "
            "open stop risk=%.2f/%.2f, quality=%.2f, regime=%s, ADX=%.1f, ATR=%.2f%%).",
            signal.symbol, allowed, hard_cap, analysis_cap, ai_recommendation,
            equity, free_margin, candidate_margin, candidate_leverage,
            current_stop_risk, equity * self._max_total_open_risk(), quality,
            regime, adx, atr_pct,
        )
        return allowed

    def _resolve_pair_leverage(self, symbol, requested_leverage, target_notional, available_margin):
        """Clamp the strategy-selected leverage to the exchange tier for this pair."""
        get_max_leverage = getattr(self.exchange, 'get_max_leverage', None)
        if not callable(get_max_leverage):
            return (None if self.mode == 'live' else requested_leverage), {
                'max_leverage': None, 'verified': False, 'source': 'unavailable',
                'error': 'Exchange connector cannot read leverage limits',
            }

        initial = get_max_leverage(symbol, target_notional)
        if not initial.get('verified'):
            # Paper mode may still simulate the user's selected cap, but make the
            # missing exchange verification visible. LIVE fails closed below.
            return (None if self.mode == 'live' else requested_leverage), initial

        target_notional = max(0.0, float(target_notional))
        available_margin = max(0.0, float(available_margin))
        for candidate in range(int(requested_leverage), 0, -1):
            expected_notional = min(target_notional, available_margin * candidate)
            limit = get_max_leverage(symbol, expected_notional)
            if limit.get('verified') and candidate <= int(limit.get('max_leverage') or 1):
                return candidate, limit

        # The first bracket always permits at least 1x; retain a hard-safe floor
        # if an exchange returns malformed or incomplete tiers.
        return 1, initial

    def _select_dynamic_leverage(self, signal) -> int:
        """Select an integer futures leverage from 1x up to the user's cap."""
        if getattr(self, 'market_type', 'spot') != 'futures':
            self.last_dynamic_leverage = 1
            return 1

        max_leverage = self._configured_max_leverage()
        # Ép trần đòn bẩy Cổ phiếu & Hàng hóa TradFi tối đa 4x theo Bài học #3 SSOT
        is_tradfi_asset = MarketScanner.is_tradfi_stock(signal.symbol, getattr(self, 'exchange', None)) or (
            hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(signal.symbol, getattr(self, 'exchange', None))
        )
        if is_tradfi_asset:
            max_leverage = min(max_leverage, 4)

        metadata = getattr(signal, 'metadata', {}) or {}
        metadata = metadata if isinstance(metadata, dict) else {}
        try:
            confidence = float(signal.confidence)
            if not math.isfinite(confidence):
                confidence = 0.0
        except (TypeError, ValueError, OverflowError):
            confidence = 0.0
        confidence = min(1.0, max(0.0, confidence))
        try:
            confidence_threshold = float(self.config.get('ai', {}).get('confidence_threshold', 0.65))
            if not math.isfinite(confidence_threshold):
                confidence_threshold = 0.65
        except (TypeError, ValueError, OverflowError):
            confidence_threshold = 0.65
        confidence_threshold = min(0.95, max(0.0, confidence_threshold))
        confidence_quality = min(
            1.0,
            max(0.0, (confidence - confidence_threshold) / max(0.05, 1.0 - confidence_threshold)),
        )

        try:
            agreement = float(metadata.get('agreement_ratio', 0.5))
            if not math.isfinite(agreement):
                agreement = 0.5
        except (TypeError, ValueError, OverflowError):
            agreement = 0.5
        agreement = min(1.0, max(0.0, agreement))

        market = metadata.get('market_analysis') or {}
        market = market if isinstance(market, dict) else {}
        regime = str(market.get('regime', 'ranging')).lower()
        direction = getattr(getattr(signal, 'signal', None), 'value', '')
        bullish_signal = direction == 'buy'
        bullish_market = str(market.get('ema_alignment', '')).lower() == 'bullish'
        bearish_market = str(market.get('ema_alignment', '')).lower() == 'bearish'
        try:
            adx = float(market.get('adx', 0.0))
            di_plus = float(market.get('di_plus', 0.0))
            di_minus = float(market.get('di_minus', 0.0))
            atr_pct = float(market.get('atr_pct', 0.0))
            if not all(math.isfinite(v) for v in (adx, di_plus, di_minus, atr_pct)):
                raise ValueError('invalid market metrics')
        except (TypeError, ValueError, OverflowError):
            adx, di_plus, di_minus, atr_pct = 0.0, 0.0, 0.0, 0.0

        is_trap_candidate = (
            'trap_detector' in metadata.get('contributing_strategies', [])
            or str(metadata.get('type', '')).upper().endswith(('TRAP_WICK', 'TRAP_BOUNCE', 'CLIMAX'))
            or (str(metadata.get('type', '')).upper().endswith('TRAP_DIP') and float(metadata.get('c_lower_wick_pct', 0.0)) >= 0.35)
            or str(getattr(signal, 'strategy', '')).lower() in ('trap_detector', 'trapdetector')
            or bool(metadata.get('is_fading_short'))
            or bool(metadata.get('is_waterfall_short'))
            or (bool(metadata.get('is_oversold_bounce')) and float(metadata.get('c_lower_wick_pct', 0.0)) >= 0.35)
            or bool(metadata.get('is_momentum_ride'))
        )

        market_trend_aligned = (
            (bullish_signal and (bullish_market or di_plus > di_minus))
            or (not bullish_signal and (bearish_market or di_minus > di_plus))
        )
        if is_trap_candidate:
            # Lệnh Bắt Bẫy Cá Mập (TrapDetector): Đi ngược trend cũ là setup tự nhiên của bẫy đảo chiều
            trend_quality = 0.85
        elif regime == 'high_volatility':
            trend_quality = 0.15
        elif 'strong_uptrend' in regime or 'strong_downtrend' in regime:
            trend_quality = 1.0 if market_trend_aligned else 0.10
        elif regime in ('uptrend', 'downtrend'):
            trend_quality = 0.80 if market_trend_aligned else 0.20
        elif adx >= 25:
            trend_quality = 0.75 if market_trend_aligned else 0.20
        elif regime == 'ranging':
            trend_quality = 0.40
        else:
            trend_quality = 0.50

        # MarketRegimeDetector reports ATR as percent units (e.g. 2.0 means 2%).
        volatility_quality = min(1.0, max(0.10, 1.0 - atr_pct / 5.0)) if atr_pct > 0 else 0.50
        ai_bias = str(metadata.get('ai_bias', 'NEUTRAL')).upper()
        aligned_bias = (ai_bias == 'BULLISH' and bullish_signal) or (ai_bias == 'BEARISH' and not bullish_signal)
        opposite_bias = (ai_bias == 'BEARISH' and bullish_signal) or (ai_bias == 'BULLISH' and not bullish_signal)
        bias_quality = 1.0 if aligned_bias else (0.15 if opposite_bias else 0.50)

        quality = (
            0.35 * confidence_quality
            + 0.30 * agreement
            + 0.20 * trend_quality
            + 0.10 * volatility_quality
            + 0.05 * bias_quality
        )
        if not is_trap_candidate:
            if regime == 'high_volatility' or (adx >= 25 and not market_trend_aligned):
                quality *= 0.65
        else:
            if regime == 'high_volatility':
                quality *= 0.85
        leverage_quality = min(1.0, max(0.0, (quality - 0.40) / 0.60))
        leverage = min(
            max_leverage,
            max(1, math.floor(1 + leverage_quality * (max_leverage - 1) + 0.5)),
        )
        self.last_dynamic_leverage = leverage
        self.last_signal_quality = quality
        if isinstance(getattr(signal, 'metadata', None), dict):
            signal.metadata['signal_quality'] = quality
        logger.info(
            "Dynamic leverage %s: %dx (cap=%dx, quality=%.2f, confidence=%.2f, "
            "consensus=%.2f, regime=%s, ADX=%.1f, ATR=%.2f%%, AI=%s)",
            signal.symbol, leverage, max_leverage, quality, confidence, agreement,
            regime, adx, atr_pct, ai_bias,
        )
        return leverage

    def _pre_trade_safety_gate(self, signal) -> tuple:
        """
        Bộ lọc an toàn trước khi vào lệnh (Pre-Trade Safety Gate):
        1. Volume Exhaustion Filter (AIStock & QuantDinger): Chặn bẫy suy kiệt khối lượng / mua đỉnh xả.
        2. Derivatives Gate (Funding Rate & OI): Tránh bẫy thanh khoản cá mập (Long/Short squeeze).
        3. Order Book Depth Gate: Tránh lao đầu vào tường cản lớn (Order Book Imbalance).
        """
        from strategies.base_strategy import Signal
        symbol = signal.symbol
        sig_val = getattr(signal.signal, 'value', str(signal.signal)).upper()
        side = 'BUY' if sig_val in ('BUY', 'SIGNAL.BUY') else 'SELL'
        
        clean_sym_chk = symbol.split(':')[0].strip().upper()
        clean_base_chk = clean_sym_chk.split('/')[0] if '/' in clean_sym_chk else clean_sym_chk
        is_major_pair = any(clean_base_chk == t for t in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP'))
        is_tradfi_pre = MarketScanner.is_tradfi_stock(symbol, self.exchange) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol, self.exchange))

        strat_name_chk = str(getattr(signal, 'strategy', '')).lower()
        _md = getattr(signal, 'metadata', None) or {}
        _contrib = [str(x).lower() for x in (_md.get('contributing_strategies', []) if isinstance(_md, dict) else [])]
        is_mr_trade = ('mean_reversion' in strat_name_chk) or ('mean_reversion' in _contrib)
        is_counter_trend_trap = (
            is_mr_trade
            or ('trap_detector' in strat_name_chk)
            or ('trap_detector' in _contrib)
            or bool(_md.get('is_fading_short'))
            or bool(_md.get('is_waterfall_short'))
            or (bool(_md.get('is_oversold_bounce')) and float(_md.get('c_lower_wick_pct', 0.0)) >= 0.35)
            or bool(_md.get('is_momentum_ride'))
            or str(_md.get('type', '')).upper().endswith(('TRAP_WICK', 'TRAP_BOUNCE', 'CLIMAX'))
            or (str(_md.get('type', '')).upper().endswith('TRAP_DIP') and float(_md.get('c_lower_wick_pct', 0.0)) >= 0.35)
        )
        is_deep_liquidity = False

        # 1. BỘ LỌC SUY KIỆT VOLUME (VOLUME EXHAUSTION)
        try:
            dfs = signal.metadata.get('dfs') or {}
            df_tactical = dfs.get('15m')
            if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                df_tactical = dfs.get('5m')
            if df_tactical is None or (hasattr(df_tactical, 'empty') and df_tactical.empty):
                df_tactical = self.data_collector.fetch_data(symbol, '15m', limit=30)
                
            # 0. CHỐT CHẶN ĐỒNG PHA NẾN 15M TÁC CHIẾN (15M TACTICAL ALIGNMENT GATE)
            # Triệt tiêu tình trạng chỉ báo khung lớn 4H trễ pha lôi bot vào lệnh khi nến 15M đang rơi tự do
            if df_tactical is not None and len(df_tactical) >= 20:
                try:
                    tactical_close = float(df_tactical['close'].iloc[-2])
                    ema20_tactical = float(df_tactical['close'].ewm(span=20, adjust=False).mean().iloc[-2])
                    import ta
                    rsi_tactical_s = ta.momentum.RSIIndicator(df_tactical['close'].iloc[:-1], window=14).rsi().dropna()
                    rsi_tactical = float(rsi_tactical_s.iloc[-1]) if not rsi_tactical_s.empty else 50.0
                    # [P1] Giá tham chiếu để đánh giá râu nến có thật sự "hấp thụ" hay không.
                    # Ưu tiên giá của tín hiệu (giá sẽ vào lệnh), fallback về nến đã đóng.
                    try:
                        _entry_ref_px = float(getattr(signal, 'price', 0.0) or 0.0)
                    except (TypeError, ValueError, OverflowError):
                        _entry_ref_px = 0.0
                    if not math.isfinite(_entry_ref_px) or _entry_ref_px <= 0:
                        _entry_ref_px = tactical_close
                    
                    strat_name_chk = str(getattr(signal, 'strategy', '')).lower()
                    _md = getattr(signal, 'metadata', None) or {}
                    _contrib = [str(x).lower() for x in (_md.get('contributing_strategies', []) if isinstance(_md, dict) else [])]
                    is_mr_trade = ('mean_reversion' in strat_name_chk) or ('mean_reversion' in _contrib)
                    is_counter_trend_trap = (
                        is_mr_trade
                        or ('trap_detector' in strat_name_chk)
                        or ('trap_detector' in _contrib)
                        or bool(_md.get('is_fading_short'))
                        or bool(_md.get('is_waterfall_short'))
                        or (bool(_md.get('is_oversold_bounce')) and float(_md.get('c_lower_wick_pct', 0.0)) >= 0.35)
                        or bool(_md.get('is_momentum_ride'))
                        or str(_md.get('type', '')).upper().endswith(('TRAP_WICK', 'TRAP_BOUNCE', 'CLIMAX'))
                        or (str(_md.get('type', '')).upper().endswith('TRAP_DIP') and float(_md.get('c_lower_wick_pct', 0.0)) >= 0.35)
                    )
                    
                    # Chỉ áp dụng cho các chiến thuật xu hướng thuần túy trên Altcoin; Miễn trừ cho Bẫy Đảo Chiều (Trap/Inversion), Mean Reversion, Major Pairs và TradFi
                    if not is_counter_trend_trap and not is_major_pair and not is_tradfi_pre:
                        if side == 'BUY':
                            # 1) Rơi tự do thủng EMA20 kèm RSI suy yếu
                            is_falling_free = (tactical_close < ema20_tactical * 0.995 and rsi_tactical < 45.0)
                            
                            # 2) Bẫy bắt dao rơi nến đỏ thác đổ (Falling Knife Waterfall):
                            # Nếu 3 nến 15M gần nhất đã đóng (iloc[-2], iloc[-3], iloc[-4]) đều là nến đỏ,
                            # HOẶC 2 nến đỏ sụt giảm mạnh (>= 0.80%) nằm dưới EMA20 mà không có râu dưới hấp thụ (LowerWick < 35%):
                            is_waterfall_red = False
                            lower_wick_ratio = 0.0
                            wick_reject_reason = ""
                            if len(df_tactical) >= 5:
                                c1 = df_tactical.iloc[-2]
                                c2 = df_tactical.iloc[-3]
                                c3 = df_tactical.iloc[-4]
                                rng1 = float(c1['high'] - c1['low'])
                                lower_wick_ratio = (float(min(c1['open'], c1['close']) - c1['low']) / rng1) if rng1 > 0 else 0.0
                                all_red_3 = (c1['close'] < c1['open']) and (c2['close'] < c2['open']) and (c3['close'] < c3['open'])
                                two_heavy_red = (c1['close'] < c1['open']) and (c2['close'] < c2['open']) and (c2['open'] > 0 and (c1['close'] - c2['open']) / c2['open'] <= -0.008)
                                if all_red_3 or two_heavy_red:
                                    if tactical_close >= ema20_tactical:
                                        is_waterfall_red = False
                                    elif lower_wick_ratio < 0.35:
                                        is_waterfall_red = True
                                    elif not _entry_inside_absorption_zone(
                                            _entry_ref_px, float(c1['high']), float(c1['low']), 'BUY'):
                                        # [P1] Nhánh này trên thực tế LUÔN chạy khi đã tới đây: với nến đỏ,
                                        # (close - low)/range == lower_wick_ratio, mà lower_wick_ratio đã
                                        # >= 0.35 > ratio 0.33. Nói cách khác P1 = bãi bỏ miễn trừ hấp thụ
                                        # cho mẫu 3 nến đỏ thác đổ (xem ghi chú ở WICK_ABSORPTION_ZONE_RATIO).
                                        is_waterfall_red = True
                                        wick_reject_reason = (
                                            f"râu dưới {lower_wick_ratio * 100:.1f}% nhưng giá vào lệnh "
                                            f"{_entry_ref_px:.4f} nằm ngoài vùng hấp thụ 1/3 dưới "
                                            f"({float(c1['low']):.4f} - "
                                            f"{float(c1['low']) + WICK_ABSORPTION_ZONE_RATIO * rng1:.4f})"
                                        )
                            
                            if is_falling_free or is_waterfall_red:
                                reason_str = (
                                    f"Bẫy bắt dao rơi nến đỏ thác đổ (Falling Knife Gate): Nến 15M liên tục xả đỏ nằm dưới EMA20 ({tactical_close:.4f} < {ema20_tactical:.4f}) và {wick_reject_reason}!"
                                    if wick_reject_reason else
                                    f"Bẫy bắt dao rơi nến đỏ thác đổ (Falling Knife Gate): Nến 15M liên tục xả đỏ nằm dưới EMA20 ({tactical_close:.4f} < {ema20_tactical:.4f}) không có râu gom hàng (LowerWick={lower_wick_ratio*100:.1f}% < 35%)!"
                                    if is_waterfall_red else
                                    f"Nến 15M lệch pha đà giảm (15M Alignment Gate): Giá ({tactical_close:.4f}) < EMA20 ({ema20_tactical:.4f}) & RSI ({rsi_tactical:.1f}) < 45. Cấm mở BUY khi nến tác chiến 15M đang rơi tự do!"
                                )
                                return False, reason_str
                        elif side == 'SELL':
                            # 1) Tăng vọt vượt EMA20 kèm RSI quá mua
                            is_rising_free = (tactical_close > ema20_tactical * 1.005 and rsi_tactical > 55.0)
                            
                            # 2) Bẫy chặn đầu xe lửa nến xanh tăng tốc (Bull Ramp Gate):
                            is_waterfall_green = False
                            upper_wick_ratio = 0.0
                            upper_wick_reject_reason = ""
                            if len(df_tactical) >= 5:
                                c1 = df_tactical.iloc[-2]
                                c2 = df_tactical.iloc[-3]
                                c3 = df_tactical.iloc[-4]
                                rng1 = float(c1['high'] - c1['low'])
                                upper_wick_ratio = (float(c1['high'] - max(c1['open'], c1['close'])) / rng1) if rng1 > 0 else 0.0
                                all_green_3 = (c1['close'] > c1['open']) and (c2['close'] > c2['open']) and (c3['close'] > c3['open'])
                                two_heavy_green = (c1['close'] > c1['open']) and (c2['close'] > c2['open']) and (c2['open'] > 0 and (c1['close'] - c2['open']) / c2['open'] >= 0.008)
                                if all_green_3 or two_heavy_green:
                                    if tactical_close <= ema20_tactical:
                                        is_waterfall_green = False
                                    elif upper_wick_ratio < 0.35:
                                        is_waterfall_green = True
                                    elif not _entry_inside_absorption_zone(
                                            _entry_ref_px, float(c1['high']), float(c1['low']), 'SELL'):
                                        # [P1] Đối xứng nhánh BUY: với nến xanh, (high - close)/range == upper_wick_ratio
                                        # đã >= 0.35 > ratio 0.33, nên nhánh này luôn chạy khi đã tới đây.
                                        is_waterfall_green = True
                                        upper_wick_reject_reason = (
                                            f"râu trên {upper_wick_ratio * 100:.1f}% nhưng giá vào lệnh "
                                            f"{_entry_ref_px:.4f} nằm ngoài vùng hấp thụ 1/3 trên "
                                            f"({float(c1['high']) - WICK_ABSORPTION_ZONE_RATIO * rng1:.4f} - "
                                            f"{float(c1['high']):.4f})"
                                        )
                                    
                            if is_rising_free or is_waterfall_green:
                                reason_str = (
                                    f"Bẫy chặn đầu xe lửa nến xanh tăng tốc (Bull Ramp Gate): Nến 15M liên tục dựng xanh nằm trên EMA20 ({tactical_close:.4f} > {ema20_tactical:.4f}) và {upper_wick_reject_reason}!"
                                    if upper_wick_reject_reason else
                                    f"Bẫy chặn đầu xe lửa nến xanh tăng tốc (Bull Ramp Gate): Nến 15M liên tục dựng xanh nằm trên EMA20 ({tactical_close:.4f} > {ema20_tactical:.4f}) không có râu xả đỉnh (UpperWick={upper_wick_ratio*100:.1f}% < 35%)!"
                                    if is_waterfall_green else
                                    f"Nến 15M lệch pha đà tăng (15M Alignment Gate): Giá ({tactical_close:.4f}) > EMA20 ({ema20_tactical:.4f}) & RSI ({rsi_tactical:.1f}) > 55. Cấm mở SHORT khi nến tác chiến 15M đang tăng vọt!"
                                )
                                return False, reason_str
                except Exception as e:
                    logger.debug(f"Bỏ qua kiểm tra 15M Alignment cho {symbol}: {e}")

            # Lưu ý chuẩn định lượng: Toàn bộ chiến thuật (Trend, Trap, Reversion) đều tạo tín hiệu dựa trên nến vừa đóng cửa (iloc[-2]).
            # Nến iloc[-1] trên Binance là nến ĐANG CHẠY (chưa đóng cửa), chỉ mới chạy được vài phút nên volume rất nhỏ.
            # Do đó, kiểm tra Volume và Exhaustion BẮT BUỘC phải xét nến hoàn chỉnh vừa đóng (iloc[-2]) so với lịch sử các nến đóng trước đó!
            if df_tactical is not None and len(df_tactical) >= 10:
                vol_history = df_tactical['volume'].iloc[:-2].tail(20)
                sma_vol_20 = float(vol_history.mean()) if not vol_history.empty else 0.0
                curr_vol_chk = float(df_tactical['volume'].iloc[-2])
                curr_close_chk = float(df_tactical['close'].iloc[-2])
                candle_quote_vol = curr_vol_chk * curr_close_chk
                rvol_thresh = float(self.config.get('risk', {}).get('rvol_filter_threshold', 0.45))
                # Phân lớp thanh khoản thích ứng: Đối với Coin Major (BTC, ETH, SOL, BNB, XRP), Cổ phiếu TradFi hoặc nến có giá trị giao dịch
                # thực tế lớn (>= 300,000 USDT/nến 15m), thanh khoản luôn dồi dào, không bị trượt giá.
                # Hạ ngưỡng sàn xuống 0.20 cho Major & TradFi để không bị bóp nghẹt bởi nhịp nghỉ volume tự nhiên vào ban đêm hoặc đầu phiên!
                effective_rvol_thresh = (rvol_thresh * 0.45) if (is_major_pair or is_tradfi_pre) else rvol_thresh
                is_deep_liquidity = (candle_quote_vol >= 300000.0)
                if sma_vol_20 > 0 and math.isfinite(sma_vol_20) and math.isfinite(curr_vol_chk):
                    rvol = curr_vol_chk / sma_vol_20
                    if rvol < effective_rvol_thresh and not (is_deep_liquidity and rvol >= 0.20):
                        return False, (
                            f"Thanh khoản cạn kiệt (RVol Gate): Volume nến tín hiệu ({curr_vol_chk:.0f}) "
                            f"chỉ đạt {rvol*100:.1f}% mức trung bình 20 kỳ ({sma_vol_20:.0f} < sàn {effective_rvol_thresh*100:.0f}%). "
                            f"Cấm vào lệnh trong vùng thanh khoản kiệt quệ / Sideway bẫy!"
                        )

            if df_tactical is not None and len(df_tactical) >= 8:
                # Mở rộng cửa sổ kiểm tra từ 4 nến (-6:-2) lên 6 nến (-8:-2, 90 phút) để bắt trọn các nến Climax volume trước đó
                prev_candles = df_tactical.iloc[-8:-2] if len(df_tactical) >= 10 else df_tactical.iloc[-6:-2]
                curr_candle = df_tactical.iloc[-2]
                
                max_prev_vol = float(prev_candles['volume'].max())
                curr_vol = float(curr_candle['volume'])
                # Chuẩn hóa ngưỡng suy kiệt volume mặc định 0.65 (nếu volume tụt > 35% sau nến cao trào kèm râu cản -> chặn đứng)
                exhaustion_threshold = float(self.config.get('risk', {}).get('volume_exhaustion_ratio', 0.65))
                
                # Miễn trừ kiểm tra Volume Exhaustion cho Coin Major (BTC, ETH, SOL, BNB, XRP), TradFi, nến thanh khoản sâu (>= 300,000 USDT) và Bẫy Đảo Chiều (Trap/Climax/Bounce)
                if max_prev_vol > 0 and not is_major_pair and not is_tradfi_pre and not is_deep_liquidity and not is_counter_trend_trap:
                    vol_ratio = curr_vol / max_prev_vol
                    if side == 'BUY':
                        prev_highest = float(prev_candles['high'].max())
                        curr_close = float(curr_candle['close'])
                        curr_open = float(curr_candle['open'])
                        upper_shadow = float(curr_candle['high'] - max(curr_close, curr_open))
                        body = abs(curr_close - curr_open)
                        
                        if vol_ratio < exhaustion_threshold and curr_close < prev_highest:
                            if (curr_close < curr_open) or (upper_shadow > body):
                                return False, (
                                    f"Suy kiệt Volume phe Mua: Volume nến tín hiệu ({curr_vol:.0f}) "
                                    f"sụt giảm {(1-vol_ratio)*100:.1f}% so với đỉnh volume trước ({max_prev_vol:.0f}), "
                                    f"giá ({curr_close:.5f}) không bứt phá được đỉnh ({prev_highest:.5f}) kèm râu xả!"
                                )
                    elif side == 'SELL':
                        prev_lowest = float(prev_candles['low'].min())
                        curr_close = float(curr_candle['close'])
                        curr_open = float(curr_candle['open'])
                        lower_shadow = float(min(curr_close, curr_open) - curr_candle['low'])
                        body = abs(curr_close - curr_open)
                        
                        if vol_ratio < exhaustion_threshold and curr_close > prev_lowest:
                            if (curr_close > curr_open) or (lower_shadow > body):
                                return False, (
                                    f"Suy kiệt Volume phe Bán: Volume nến tín hiệu ({curr_vol:.0f}) "
                                    f"sụt giảm {(1-vol_ratio)*100:.1f}% so với đáy xả ({max_prev_vol:.0f}), "
                                    f"giá ({curr_close:.5f}) hồi phục trên đáy ({prev_lowest:.5f}) kèm rút chân!"
                                )
        except Exception as e:
            logger.debug(f"Bỏ qua kiểm tra Volume Exhaustion cho {symbol}: {e}")

        # 1B. BỘ LỌC HẤP THỤ VOLUME VI MÔ 5M (5M MICRO VOLUME ABSORPTION FILTER)
        # Ngăn chặn mua ngay trước cây xả 5M hoặc bán ngay trước cây dựng 5M
        try:
            m5_filter_enabled = bool(self.config.get('risk', {}).get('m5_micro_absorption_filter', True))
            if m5_filter_enabled and not is_major_pair and not is_tradfi_pre and not is_mr_trade:
                dfs = signal.metadata.get('dfs') or {}
                df_5m = dfs.get('5m')
                if df_5m is None or (hasattr(df_5m, 'empty') and df_5m.empty):
                    df_5m = self.data_collector.fetch_data(symbol, '5m', limit=20)
                if df_5m is not None and len(df_5m) >= 10:
                    c_5m_closed = df_5m.iloc[-2]
                    rng_5m = float(c_5m_closed['high'] - c_5m_closed['low'])
                    vol_5m_s = df_5m['volume'].iloc[:-2].tail(10)
                    sma_vol_5m = float(vol_5m_s.mean()) if not vol_5m_s.empty else 0.0
                    vol_5m_curr = float(c_5m_closed['volume'])
                    rvol_5m = (vol_5m_curr / sma_vol_5m) if sma_vol_5m > 0 else 1.0

                    if rng_5m > 0 and sma_vol_5m > 0:
                        body_5m_pct = abs(float(c_5m_closed['close'] - c_5m_closed['open'])) / max(1e-8, float(c_5m_closed['open']))
                        if side == 'BUY':
                            # Cây 5M đóng đỏ mạnh, đóng sát đáy (lower wick < 30%), volume xả lớn (>= 1.3x) HOẶC nến đỏ dài (>= 0.8%)
                            lower_wick_5m = float(min(c_5m_closed['open'], c_5m_closed['close']) - c_5m_closed['low']) / rng_5m
                            is_dumping_5m = (c_5m_closed['close'] < c_5m_closed['open']) and (lower_wick_5m < 0.30) and (rvol_5m >= 1.30 or body_5m_pct >= 0.008)
                            if is_dumping_5m:
                                return False, (
                                    f"Bẫy xả vi mô 5M (5M Micro Dump Gate): Nến 5M vừa đóng đỏ mạnh "
                                    f"sát đáy (LowerWick={lower_wick_5m*100:.1f}% < 30%, Thân={body_5m_pct*100:.2f}%) kèm Volume xả lớn "
                                    f"({rvol_5m:.2f}x trung bình). Từ chối mở BUY đón dao rơi vi mô!"
                                )
                        elif side == 'SELL':
                            # Cây 5M đóng xanh mạnh, đóng sát đỉnh (upper wick < 30%), volume mua lớn (>= 1.3x) HOẶC nến xanh dài (>= 0.8%)
                            upper_wick_5m = float(c_5m_closed['high'] - max(c_5m_closed['open'], c_5m_closed['close'])) / rng_5m
                            is_ramping_5m = (c_5m_closed['close'] > c_5m_closed['open']) and (upper_wick_5m < 0.30) and (rvol_5m >= 1.30 or body_5m_pct >= 0.008)
                            if is_ramping_5m:
                                return False, (
                                    f"Bẫy tăng vi mô 5M (5M Micro Ramp Gate): Nến 5M vừa đóng xanh mạnh "
                                    f"sát đỉnh (UpperWick={upper_wick_5m*100:.1f}% < 30%, Thân={body_5m_pct*100:.2f}%) kèm Volume tăng vọt "
                                    f"({rvol_5m:.2f}x trung bình). Từ chối mở SHORT chặn đầu xe lửa vi mô!"
                                )
        except Exception as e_m5:
            logger.debug(f"Bỏ qua kiểm tra 5M Micro Absorption cho {symbol}: {e_m5}")

        # 2. BỘ LỌC PHÁI SINH: FUNDING RATE & OPEN INTEREST
        if getattr(self, 'market_type', 'spot') == 'futures':
            try:
                funding_info = self.exchange.get_funding_rate(symbol)
                if funding_info and funding_info.get('fundingRate') is not None:
                    fr = float(funding_info['fundingRate'])
                    if isinstance(getattr(signal, 'metadata', None), dict):
                        signal.metadata['funding_rate'] = fr
                    fr_threshold = float(self.config.get('risk', {}).get('funding_extreme_threshold', 0.0003))
                    
                    # [BÀI HỌC 87]: Co giãn Funding Rate thích ứng cho các chiến lược Lật Ngược & Dòng Tiền Cá Mập (Whale Flow / Smart Inversion)
                    # Khi cá mập xả lũ thác đổ (Waterfall Short / Fading Short) hoặc bơm bão volume (Whale Pump Storm / Oversold Bounce),
                    # Funding Rate hợp đồng tương lai tự nhiên bị lệch vào vùng 0.04% - 0.06%.
                    # Nới ngưỡng sàn thích ứng lên 0.08% (0.0008) để không bức tử các siêu sóng thuận cá mập như Q/USDT hay AIN/USDT!
                    _sig_meta = getattr(signal, 'metadata', None) or {}
                    is_smart_inversion_fr = bool(
                        _sig_meta.get('is_waterfall_short')
                        or _sig_meta.get('is_fading_short')
                        or _sig_meta.get('is_whale_pump_storm')
                        or _sig_meta.get('is_oversold_bounce')
                        or _sig_meta.get('is_trap_entry')
                        or (_sig_meta.get('is_trap_candidate') and float(getattr(signal, 'confidence', 0.0) or 0.0) >= 0.75)
                    )
                    adaptive_fr_thresh = float(self.config.get('risk', {}).get('funding_extreme_adaptive_threshold', 0.0008))
                    effective_fr_thresh = adaptive_fr_thresh if is_smart_inversion_fr else fr_threshold

                    if side == 'BUY' and fr > effective_fr_thresh:
                        return False, (
                            f"Funding Rate quá cao ({fr*100:+.4f}% > +{effective_fr_thresh*100:.2f}%): "
                            f"Phe Long quá đông, nguy cơ Long Squeeze quét thanh khoản rất cao"
                        )
                    elif side == 'SELL' and fr < -effective_fr_thresh:
                        return False, (
                            f"Funding Rate quá âm ({fr*100:+.4f}% < -{effective_fr_thresh*100:.2f}%): "
                            f"Phe Short quá đông, nguy cơ Short Squeeze ép bứt phá rất cao"
                        )
            except Exception as e:
                logger.debug(f"Bỏ qua kiểm tra Funding Rate cho {symbol}: {e}")

        # 3. BỘ LỌC ĐỘ SÂU SỔ LỆNH & CHÊNH LỆCH GIÁ (ORDER BOOK DEPTH & SPREAD GATE)
        try:
            ob = self.exchange.get_order_book(symbol, limit=20)
            if ob and ob.get('bids') and ob.get('asks'):
                # Kiểm tra Spread (chênh lệch Bid/Ask) chống trượt giá Market
                if len(ob['bids']) > 0 and len(ob['asks']) > 0:
                    best_bid = float(ob['bids'][0][0])
                    best_ask = float(ob['asks'][0][0])
                    if best_bid > 0 and best_ask >= best_bid:
                        spread_pct = (best_ask - best_bid) / best_bid
                        is_tradfi_pair = MarketScanner.is_tradfi_stock(symbol, self.exchange) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol, self.exchange))
                        max_allowed_spread = 0.0030 if is_tradfi_pair else 0.0018
                        if spread_pct > max_allowed_spread:
                            return False, (
                                f"Chênh lệch giá (Spread) quá giãn ({spread_pct*100:.2f}% > {max_allowed_spread*100:.2f}%): "
                                f"Nguy cơ trượt giá cao khi vào lệnh Market, từ chối mở vị thế!"
                            )

                bids_vol = sum(float(b[1]) for b in ob['bids'][:10] if len(b) > 1)
                asks_vol = sum(float(a[1]) for a in ob['asks'][:10] if len(a) > 1)
                imbalance_threshold = float(self.config.get('risk', {}).get('max_order_book_imbalance', 3.0))
                
                if side == 'BUY' and bids_vol > 0 and (asks_vol / bids_vol >= imbalance_threshold):
                    return False, (
                        f"Áp lực cản sổ lệnh quá lớn: Tường bán ({asks_vol:.1f}) dày gấp "
                        f"{asks_vol/bids_vol:.1f}x tường mua ({bids_vol:.1f}) trong 10 bước giá"
                    )
                elif side == 'SELL' and asks_vol > 0 and (bids_vol / asks_vol >= imbalance_threshold):
                    return False, (
                        f"Áp lực đỡ sổ lệnh quá lớn: Tường mua ({bids_vol:.1f}) dày gấp "
                        f"{bids_vol/asks_vol:.1f}x tường bán ({asks_vol:.1f}) trong 10 bước giá"
                    )
        except Exception as e:
            logger.debug(f"Bỏ qua kiểm tra Order Book Depth cho {symbol}: {e}")

        return True, "Passed all pre-trade safety gates"

    def _execute_signal(self, signal) -> Optional[Dict]:
        """Serialize order-entry decisions with manual exits and position checks."""
        with self._position_lock:
            return self._execute_signal_locked(signal)

    def _execute_signal_locked(self, signal) -> Optional[Dict]:
        """
        Thực thi tín hiệu giao dịch sau khi kiểm tra rủi ro.
        """
        if not self.is_running:
            logger.info("Bỏ qua tín hiệu %s vì bot đã được yêu cầu dừng.", signal.symbol)
            return None
        from strategies.base_strategy import Signal

        # 0. Kiểm tra ngay nếu cặp tiền này đã có vị thế mở hoặc đang có lệnh rình mồi M1 chờ khớp
        # (Tránh gọi thừa 4 REST API trong _pre_trade_safety_gate hoặc đóng ngược vị thế vừa khớp M1 Sniper)
        sig_clean = self._clean_symbol(signal.symbol)
        if any(self._clean_symbol(p.get('symbol')) == sig_clean for p in self.open_positions):
            logger.info(f"⏳ Cặp {signal.symbol} đã có vị thế đang mở; bỏ qua mở lệnh mới.")
            return None

        stk_key = None
        for k in getattr(self, 'pending_stalking_orders', {}):
            if self._clean_symbol(k) == sig_clean:
                stk_key = k
                break

        if stk_key:
            stk = self.pending_stalking_orders[stk_key]
            current_stalking_dir = stk.get('direction', 'LONG')
            signal_dir = 'LONG' if signal.signal == Signal.BUY else 'SHORT'
            if current_stalking_dir == signal_dir:
                logger.info(f"⏳ Cặp {signal.symbol} đang có lệnh bắn tỉa M1 cùng chiều {signal_dir} chờ khớp; bỏ qua tín hiệu mới.")
                return {'status': 'ALREADY_STALKING', 'symbol': signal.symbol, 'direction': signal_dir}
            else:
                logger.info(f"🔄 Cặp {signal.symbol} đảo chiều từ {current_stalking_dir} -> {signal_dir}. Hủy lệnh rình mồi cũ để chuẩn bị theo chiều mới.")
                oid = stk.get('order_id')
                cancel_confirmed = True
                if self.mode == 'live' and oid:
                    cancel_confirmed = self._cancel_stalking_order(stk_key, stk, str(oid), time.time())
                if not cancel_confirmed:
                    self._save_state()
                    return None
                self.pending_stalking_orders.pop(stk_key, None)
                self._save_state()

        # Kiểm tra rủi ro (bao gồm cả các lệnh M1 Sniper đang rình mồi để không vượt trần vị thế TradFi / tương quan Altcoin)
        estimated_equity, existing_margin, _ = self._portfolio_capacity_snapshot()
        combined_positions_for_risk = list(self.open_positions) + list(getattr(self, 'pending_stalking_orders', {}).values())
        configured_max = self._configured_max_open_positions()
        free_roll_count = sum(1 for p in getattr(self, 'open_positions', []) if self._is_position_risk_free(p))
        effective_cap = min(configured_max + free_roll_count, configured_max + 2)
        can_trade, reason = self.risk_manager.can_trade(
            signal, self.balance, combined_positions_for_risk, account_equity=estimated_equity,
            max_open_positions=effective_cap,
        )
        
        if not can_trade:
            logger.info(f"⚠️ Không giao dịch: {reason}")
            return None

        # Kiểm tra Pre-Trade Safety Gate (Volume Exhaustion, Funding Rate, Order Book Depth)
        passes_gate, gate_reason = self._pre_trade_safety_gate(signal)
        if not passes_gate:
            logger.warning(f"🛡️ [PRE-TRADE GATE CHẶN] {signal.symbol} ({signal.signal.value.upper()}): {gate_reason}")
            try:
                from core.gate_telemetry import record_gate_event, record_radar_candidate
                gate_name = ('15M_ALIGNMENT' if '15M Alignment' in gate_reason else
                             'VOLUME_EXHAUSTION' if 'Suy kiệt Volume' in gate_reason else
                             'RVOL' if 'RVol Gate' in gate_reason else 'PRE_TRADE_GATE')
                record_gate_event(gate_name, signal.symbol, side=signal.signal.value.upper(), reason=gate_reason)

                readiness = 85.0 if 'RVol Gate' in gate_reason else (78.0 if '15M Alignment' in gate_reason else 72.0)
                meta_s = getattr(signal, 'metadata', {}) or {}
                contrib = meta_s.get('contributing_strategies', [])
                strat_str = f"{len(contrib)}/{self.config.get('ai',{}).get('min_agreeing_strategies',2)} chiến lược" if contrib else str(getattr(signal, 'strategy', ''))
                lev_calc = meta_s.get('dynamic_leverage')

                record_radar_candidate(
                    symbol=signal.symbol,
                    side=signal.signal.value.upper(),
                    confidence=signal.confidence,
                    score=float(meta_s.get('weighted_score', 0.0) or 0.0),
                    strategies_agreed=strat_str,
                    dynamic_leverage=lev_calc,
                    bottleneck_gate=gate_name,
                    bottleneck_reason=gate_reason,
                    readiness_pct=readiness
                )
            except Exception:
                pass
            return None
        
        # position_size is quote-currency margin. Convert the risk budget and
        # actual stop distance to notional, then apply leverage and margin caps.
        if signal.price <= 0:
            logger.warning("Giá tín hiệu không hợp lệ, bỏ qua")
            return None

        # Khóa phòng thủ: Nếu là cổ phiếu / hàng hóa TradFi nhưng tính năng TradFi đang TẮT, từ chối mở lệnh
        is_stock_pre = MarketScanner.is_tradfi_stock(signal.symbol, self.exchange) or (
            hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(signal.symbol, self.exchange)
        )
        tradfi_active_pre = bool(self.config.get('tradfi', {}).get('enabled', False))
        if is_stock_pre and not tradfi_active_pre:
            logger.warning(
                f"🛡️ [TRADFI KHÓA] Bỏ qua lệnh {signal.symbol}: Cổ phiếu/Hàng hóa TradFi nhưng tradfi.enabled đang TẮT!"
            )
            return None

        # Chuẩn hóa khoảng cách Stop-Loss và Take-Profit theo ATR & Tỷ lệ R:R chuẩn
        meta = signal.metadata or {}
        market_analysis_meta = meta.get('market_analysis') if isinstance(meta.get('market_analysis'), dict) else {}
        atr_val = float(meta.get('atr') or 0)
        raw_meta_atr_pct = float(meta.get('atr_pct') or 0)
        if raw_meta_atr_pct <= 0 and market_analysis_meta.get('atr_pct'):
            try:
                ma_atr = float(market_analysis_meta.get('atr_pct') or 0)
                raw_meta_atr_pct = ma_atr / 100.0 if ma_atr > 0.25 else ma_atr
            except (TypeError, ValueError):
                raw_meta_atr_pct = 0.0
        atr_pct = (atr_val / signal.price) if (signal.price > 0 and atr_val > 0) else (raw_meta_atr_pct if raw_meta_atr_pct > 0 else 0.015)
        if atr_pct <= 0 or not math.isfinite(atr_pct):
            atr_pct = 0.015

        # Ngưỡng sàn tối thiểu để không bị nhiễu nến 15m quét: 1.5%
        min_sl_dist = 0.015
        # Ngưỡng trần tối đa tuyệt đối để khống chế rủi ro đuôi: 3.5%
        max_sl_dist = 0.035

        stop_loss = signal.stop_loss
        # [P3] Hợp nhất nguồn ATR: SL vào lệnh dùng đúng ATR 15m đã đóng của thang giảm tải
        # (`_adaptive_trailing_metrics`) thay vì ATR riêng của chiến thuật, để nấc cắt
        # 1.0 ATR và SL ban đầu nằm trên cùng một thước đo.
        unified_atr_pct, unified_adx = self._entry_atr_pct(signal)
        strategy_sl_dist = None
        try:
            if stop_loss is not None and math.isfinite(float(stop_loss)) and float(stop_loss) > 0:
                strategy_sl_dist = abs(signal.price - float(stop_loss)) / signal.price
        except (TypeError, ValueError, OverflowError):
            strategy_sl_dist = None

        if unified_atr_pct is not None and unified_atr_pct > 0:
            risk_cfg_sl = self.config.get('risk') if isinstance(self.config.get('risk'), dict) else {}
            try:
                unified_mult = float(risk_cfg_sl.get('unified_sl_atr_multiplier', 1.5))
            except (TypeError, ValueError, OverflowError):
                unified_mult = 1.5
            if not math.isfinite(unified_mult) or unified_mult <= 0:
                unified_mult = 1.5
            current_sl_dist = unified_mult * unified_atr_pct
            if not (meta.get('is_momentum_ride') or meta.get('is_fading_short') or meta.get('is_waterfall_short') or meta.get('is_oversold_bounce')):
                logger.info(
                    "[P3] SL hợp nhất theo ATR 15m cho %s: %.3f%% (%.2fx ATR %.3f%%)%s",
                    signal.symbol, current_sl_dist * 100, unified_mult, unified_atr_pct * 100,
                    (f" thay cho SL chiến thuật {strategy_sl_dist * 100:.3f}%"
                     if strategy_sl_dist else " (chiến thuật không đặt SL)"),
                )
        elif strategy_sl_dist is not None:
            current_sl_dist = strategy_sl_dist
        else:
            current_sl_dist = max(min_sl_dist, 1.2 * atr_pct)

        # Kẹp cứng khoảng cách SL vào vùng an toàn [1.5%, 3.5%], tuyệt đối không vượt quá trần 3.5%
        clamped_sl_dist = min(max_sl_dist, max(min_sl_dist, current_sl_dist))
        effective_15m_atr_pct = unified_atr_pct if (unified_atr_pct is not None and unified_atr_pct > 0) else atr_pct

        # [SMART DUAL-PHASE QUANT MATRIX] Tối ưu hóa SL/TP theo chiến lược chuyển hóa đặc biệt:
        # Watchlist pop được thực hiện sau khi đặt lệnh thành công (tránh lỗi NameError và bảo toàn Cooldown)
        if meta.get('is_momentum_ride'):
            clamped_tp_dist = float(meta.get('target_tp_pct', 0.025))
            clamped_sl_dist = min(0.015, max(0.010, 1.0 * effective_15m_atr_pct))
            logger.info(
                "[P3] SL chuyên biệt Smart Momentum Ride cho %s: %.3f%% (TP=%.2f%%, ATR_15m=%.3f%%)",
                signal.symbol, clamped_sl_dist * 100, clamped_tp_dist * 100, effective_15m_atr_pct * 100,
            )
        elif meta.get('is_fading_short') or meta.get('is_waterfall_short'):
            clamped_tp_dist = float(meta.get('target_tp_pct', 0.030 if meta.get('is_fading_short') else 0.025))
            clamped_sl_dist = min(0.018 if meta.get('is_fading_short') else 0.015, max(0.010, 1.0 * effective_15m_atr_pct))
            logger.info(
                "[P3] SL chuyên biệt Smart Fading/Waterfall Short cho %s: %.3f%% (TP=%.2f%%, ATR_15m=%.3f%%)",
                signal.symbol, clamped_sl_dist * 100, clamped_tp_dist * 100, effective_15m_atr_pct * 100,
            )
        elif meta.get('is_oversold_bounce'):
            clamped_tp_dist = float(meta.get('target_tp_pct', 0.025))
            clamped_sl_dist = min(0.015, max(0.010, 1.0 * effective_15m_atr_pct))
            logger.info(
                "[P3] SL chuyên biệt Oversold Bounce Long cho %s: %.3f%% (TP=%.2f%%, ATR_15m=%.3f%%)",
                signal.symbol, clamped_sl_dist * 100, clamped_tp_dist * 100, effective_15m_atr_pct * 100,
            )
        else:
            target_rr = 2.0
            expected_tp_dist = clamped_sl_dist * target_rr

            if signal.take_profit and math.isfinite(float(signal.take_profit)):
                raw_tp_dist = abs(signal.take_profit - signal.price) / signal.price
                if raw_tp_dist < clamped_sl_dist * 1.5:
                    clamped_tp_dist = expected_tp_dist
                elif raw_tp_dist > clamped_sl_dist * 3.5:
                    clamped_tp_dist = clamped_sl_dist * 2.5
                else:
                    clamped_tp_dist = raw_tp_dist
            else:
                clamped_tp_dist = expected_tp_dist
            clamped_tp_dist = max(0.015, clamped_tp_dist)

        if signal.signal == Signal.BUY:
            stop_loss = signal.price * (1.0 - clamped_sl_dist)
            take_profit = signal.price * (1.0 + clamped_tp_dist)
        else:
            stop_loss = signal.price * (1.0 + clamped_sl_dist)
            take_profit = signal.price * (1.0 - clamped_tp_dist)

        signal.stop_loss = stop_loss
        signal.take_profit = take_profit
        stop_distance_pct = clamped_sl_dist
        try:
            risk_pct = float(self.config['risk'].get('max_risk_per_trade', 0.02))
        except (TypeError, ValueError, OverflowError):
            risk_pct = 0.02
        if not math.isfinite(risk_pct) or not 0 < risk_pct <= 0.05:
            logger.warning("max_risk_per_trade cấu hình không hợp lệ, bỏ qua")
            return None
        leverage = self._select_dynamic_leverage(signal)
        sig_quality = getattr(self, 'last_signal_quality', 1.0)
        is_trap_entry = (
            'trap_detector' in meta.get('contributing_strategies', [])
            or str(meta.get('type', '')).upper().endswith(('TRAP_WICK', 'TRAP_BOUNCE', 'CLIMAX'))
            or (str(meta.get('type', '')).upper().endswith('TRAP_DIP') and float(meta.get('c_lower_wick_pct', 0.0)) >= 0.35)
            or str(getattr(signal, 'strategy', '')).lower() in ('trap_detector', 'trapdetector')
            or bool(meta.get('is_fading_short'))
            or bool(meta.get('is_waterfall_short'))
            or (bool(meta.get('is_oversold_bounce')) and float(meta.get('c_lower_wick_pct', 0.0)) >= 0.35)
            or bool(meta.get('is_momentum_ride'))
        )
        min_quality_gate = 0.35 if is_trap_entry else 0.45
        if getattr(self, 'market_type', 'spot') == 'futures' and sig_quality < min_quality_gate:
            logger.warning(
                f"🛡️ [LỌC TÍN HIỆU YẾU] Bỏ qua vào lệnh {signal.symbol}: "
                f"Chỉ số chất lượng tín hiệu {sig_quality:.2f} < {min_quality_gate:.2f}. "
                f"Hệ thống từ chối mở lệnh rủi ro cao để bảo vệ an toàn vốn!"
            )
            return None

        # --- CỔNG THẨM ĐỊNH LƯỢNG TỬ KÉP (DUAL-ENGINE QUANTUM GATE v2.0) ---
        if not getattr(self, 'quantum_simulator', None):
            try:
                q_cfg = self.config.get('quantum_gate', {}) if isinstance(self.config.get('quantum_gate'), dict) else {}
                self.quantum_simulator = QuantumPathSimulator(
                    n_paths=int(q_cfg.get('n_paths', 2500)),
                    n_steps=int(q_cfg.get('n_steps', 40)),
                    min_win_prob=float(q_cfg.get('min_win_prob', 0.0)),
                    max_doa_prob=float(q_cfg.get('max_doa_prob', 0.40)),
                    min_ev_pct=float(q_cfg.get('min_ev_pct', 0.0)),
                    edge_margin=float(q_cfg.get('edge_margin', 0.10)),
                )
            except Exception as q_init_error:
                self.quantum_simulator = None
                logger.error(f"Không thể khởi tạo Cổng Lượng Tử cho {signal.symbol}: {q_init_error}; VETO fail-closed.")
                return None
        if hasattr(self, 'quantum_simulator') and self.quantum_simulator is not None:
            try:
                # Quantum mô phỏng 40 bước ngắn hạn phải dùng đúng ATR/ADX 15m,
                # không được bịa ADX=30 hoặc mặc định regime='uptrend' làm lệch SHORT/LONG.
                try:
                    q_atr_pct = float(market_analysis_meta.get('tactical_atr_pct') or 0.0)
                    q_adx = float(market_analysis_meta.get('tactical_adx') or 0.0)
                except (TypeError, ValueError, OverflowError):
                    q_atr_pct = 0.0
                    q_adx = 0.0
                q_regime = str(market_analysis_meta.get('regime') or meta.get('market_regime') or '').strip()
                if q_atr_pct <= 0 or q_adx <= 0 or not math.isfinite(q_atr_pct) or not math.isfinite(q_adx) or not q_regime:
                    logger.warning(
                        "🛡️ [QUANTUM DATA VETO] %s thiếu đo lường 15m/regime hợp lệ (ATR=%s, ADX=%s, regime=%r); VETO fail-closed.",
                        signal.symbol, q_atr_pct, q_adx, q_regime,
                    )
                    return None
                q_btc_bias = str(meta.get('ai_bias') or 'NEUTRAL')
                q_funding = float(meta.get('funding_rate') or 0.0)
                q_jev_verdict = meta.get('jev_decision')
                q_jev_risk = meta.get('risk_factors')
                q_jev_reason = meta.get('reason')

                # [BÀI HỌC 94]: Chống TypeError float(None) làm sập Cổng Lượng Tử khi SL/TP chưa được gán
                q_sl_raw = signal.stop_loss
                q_tp_raw = signal.take_profit
                q_px_float = float(signal.price)
                if q_sl_raw is not None:
                    try:
                        q_sl_val = float(q_sl_raw)
                    except (TypeError, ValueError):
                        q_sl_val = q_px_float * (1.0 + (1.5 * q_atr_pct if signal.signal.value.upper() == 'SELL' else -1.5 * q_atr_pct))
                else:
                    q_sl_val = q_px_float * (1.0 + (1.5 * q_atr_pct if signal.signal.value.upper() == 'SELL' else -1.5 * q_atr_pct))

                if q_tp_raw is not None:
                    try:
                        q_tp_val = float(q_tp_raw)
                    except (TypeError, ValueError):
                        q_tp_val = q_px_float * (1.0 - (2.5 * q_atr_pct if signal.signal.value.upper() == 'SELL' else -2.5 * q_atr_pct))
                else:
                    q_tp_val = q_px_float * (1.0 - (2.5 * q_atr_pct if signal.signal.value.upper() == 'SELL' else -2.5 * q_atr_pct))

                q_res = self.quantum_simulator.simulate(
                    symbol=signal.symbol,
                    side=signal.signal.value.upper(),
                    entry_price=q_px_float,
                    stop_loss=q_sl_val,
                    take_profit=q_tp_val,
                    atr_pct=q_atr_pct,
                    adx=q_adx,
                    score=float(signal.confidence),
                    regime=q_regime,
                    btc_bias=q_btc_bias,
                    funding_rate=q_funding,
                    jev_verdict=q_jev_verdict,
                    jev_risk=q_jev_risk,
                    jev_reason=q_jev_reason,
                )
                conf_tier = str(q_res.get('confidence_tier', 'CONFIRMED')).upper()
                p_win_val = float(q_res.get('p_win', 0.0) or 0.0)
                ev_pct_val = float(q_res.get('expected_ev_pct', 0.0) or 0.0)
                try:
                    q_gate_cfg = self.config.get('quantum_gate', {}) if isinstance(self.config.get('quantum_gate'), dict) else {}
                    min_ev_pass = float(q_gate_cfg.get('min_ev_pct', 0.0))
                    if 0.0 < min_ev_pass < 0.05:
                        min_ev_pass *= 100.0  # Chuẩn hóa về phần trăm (%) đồng nhất với expected_ev_pct
                    reject_marginal = bool(q_gate_cfg.get('reject_marginal', False))
                except (TypeError, ValueError):
                    min_ev_pass = 0.0
                    reject_marginal = False
                # Cổng thẩm định chính dùng KỲ VỌNG EV SAU PHÍ (đã chuẩn hóa drift), không dùng
                # mốc P(Win) >= 68% tuyệt đối nữa: sau khi sửa lỗi drift, P(Win) trần lý thuyết của
                # mô hình random-walk chỉ ~0.35-0.50 với R:R = 2.0, giữ mốc 68% sẽ chặn 100% lệnh.
                # reject_marginal mặc định TẮT (False) để cho phép các lệnh có kỳ vọng EV > 0 thông qua Cổng Lượng Tử.
                is_marginal_rejected = reject_marginal and conf_tier == 'QUANTUM_MARGINAL'
                is_ev_rejected = ev_pct_val <= min_ev_pass
                if (not q_res.get('pass_gate', True)) or is_marginal_rejected or is_ev_rejected:
                    if is_marginal_rejected:
                        rejection_reason = f"HẠNG_VỚT_MARGINAL(BẬT_TÙY_CHỌN), EV={ev_pct_val:+.2f}%"
                    elif is_ev_rejected:
                        rejection_reason = f"KỲ_VỌNG_EV_KHÔNG_ĐỦ({ev_pct_val:+.2f}%<={min_ev_pass:+.2f}%)"
                    else:
                        rejection_reason = ", ".join(q_res.get('veto_reasons', []))
                    logger.warning(
                        "🛡️ [QUANTUM GATE v2.0 VETO] Chặn lệnh %s %s (%s): Tier=%s, P(Win)=%.1f%%, P(Loss)=%.1f%%, P(DOA)=%.1f%%, EV=%+.2f%%, R:R=%.2f | Lý do: %s (%.1fms)",
                        signal.signal.value.upper(),
                        signal.symbol,
                        q_res.get('asset_class', 'UNKNOWN'),
                        conf_tier,
                        p_win_val * 100.0,
                        q_res.get('p_loss', 0.0) * 100.0,
                        q_res.get('p_doa', 0.0) * 100.0,
                        q_res.get('expected_ev_pct', 0.0),
                        q_res.get('reward_risk_ratio', 0.0),
                        rejection_reason,
                        q_res.get('time_taken_ms', 0.0),
                    )
                    return None

                q_mult = float(q_res.get('leverage_multiplier', 1.0))
                is_tradfi_asset = MarketScanner.is_tradfi_stock(signal.symbol, getattr(self, 'exchange', None)) or (
                    hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(signal.symbol, getattr(self, 'exchange', None))
                )
                if getattr(self, 'market_type', 'spot') == 'futures' and q_mult > 0 and q_mult != 1.0:
                    max_lev = min(self._configured_max_leverage(), 4) if is_tradfi_asset else self._configured_max_leverage()
                    adjusted_lev = max(1 if is_tradfi_asset else 3, min(max_lev, int(round(leverage * q_mult))))
                    if adjusted_lev != leverage:
                        logger.info(
                            "⚛️ [QUANTUM LEVERAGE SCALE] Điều chỉnh đòn bẩy %s từ %dx -> %dx theo hạng %s (P_Win=%.1f%%, Mult=%.2fx).",
                            signal.symbol,
                            leverage,
                            adjusted_lev,
                            q_res.get('confidence_tier', 'CONFIRMED'),
                            q_res.get('p_win', 0.0) * 100.0,
                            q_mult,
                        )
                        leverage = adjusted_lev
                        self.last_dynamic_leverage = leverage

                logger.info(
                    "⚛️ [QUANTUM GATE v2.0 PASS] Duyệt lệnh %s %s (%s): Tier=%s, P(Win)=%.1f%% (hòa vốn %.1f%%), P(DOA)=%.1f%%, EV=%+.2f%%, R:R=%.2f, Drift=%.2f%%/Sigma=%.2f%%, Leverage=%dx (%.1fms)",
                    signal.signal.value.upper(),
                    signal.symbol,
                    q_res.get('asset_class', 'UNKNOWN'),
                    q_res.get('confidence_tier', 'CONFIRMED'),
                    q_res.get('p_win', 0.0) * 100.0,
                    q_res.get('breakeven_win_prob', 0.0) * 100.0,
                    q_res.get('p_doa', 0.0) * 100.0,
                    q_res.get('expected_ev_pct', 0.0),
                    q_res.get('reward_risk_ratio', 0.0),
                    q_res.get('drift_total_pct', 0.0),
                    q_res.get('sigma_total_pct', 0.0),
                    leverage,
                    q_res.get('time_taken_ms', 0.0),
                )
                if isinstance(getattr(signal, 'metadata', None), dict):
                    signal.metadata['quantum_validation'] = q_res
            except Exception as qe:
                logger.error(f"Lỗi thực thi Cổng Lượng Tử cho {signal.symbol}: {qe}; VETO fail-closed.")
                return None
        # Thực thi lệnh
        try:
            # Kiểm tra lại lần cuối xem có vị thế mở trùng cặp hay không (tuyệt đối không đóng ngược vị thế
            # bên trong hàm mở lệnh để tránh vượt rào Grace Period 15m khi lệnh M1 Sniper vừa khớp!)
            has_position = any(self._clean_symbol(p.get('symbol')) == self._clean_symbol(signal.symbol) for p in self.open_positions)
            if has_position:
                logger.info(f"⏳ Cặp {signal.symbol} đã có vị thế đang mở; bỏ qua mở lệnh mới.")
                return None

            # Chặn tuyệt đối Race Condition: Kiểm tra Cooldown bảo vệ vốn trước khi mở lệnh
            clean_sig_sym = self._clean_symbol(signal.symbol)
            cd_until = max(
                self._manual_exit_cooldowns.get(clean_sig_sym, 0),
                self._symbol_cooldowns.get(clean_sig_sym, 0)
            )
            is_p2_short_exempt = bool(meta.get('is_fading_short')) and (clean_sig_sym in getattr(self, '_fading_short_watchlist', {}))
            if time.time() < cd_until and not is_p2_short_exempt:
                logger.warning(
                    f"🛑 [CHẶN VÀO LẠI RACE CONDITION] Cặp {signal.symbol} đang trong thời gian Cooldown "
                    f"(còn {int(cd_until - time.time())}s); từ chối mở lệnh mới!"
                )
                return None
            is_open_signal = False
            side = 'buy'
            direction = 'LONG'
            
            if signal.signal == Signal.BUY and not has_position:
                is_open_signal = True
                side = 'buy'
                direction = 'LONG'
            elif signal.signal == Signal.SELL and not has_position and getattr(self, 'market_type', 'spot') == 'futures':
                is_open_signal = True
                side = 'sell'
                direction = 'SHORT'
                
            if is_open_signal:
                occupied_slots = len(self.open_positions) + len(getattr(self, 'pending_stalking_orders', {}))
                base_cap = self._configured_max_open_positions()

                # Nếu TẮT công tắc Gia Tăng Vị Thế Khi Bảo Toàn Vốn -> Khóa cứng trần danh nghĩa base_cap
                if not getattr(self, 'free_roll_recycling', True) and occupied_slots >= base_cap:
                    logger.info(
                        "Bỏ qua lệnh mới %s: đã đạt trần danh nghĩa %d/%d (Gia Tăng Vị Thế Khi Bảo Toàn Vốn: TẮT).",
                        signal.symbol, occupied_slots, base_cap
                    )
                    return None

                dynamic_limit = self._dynamic_open_position_limit(signal, precomputed_leverage=leverage)
                if occupied_slots >= dynamic_limit:
                    logger.info(
                        "Bỏ qua lệnh mới %s: tổng vị thế & lệnh rình mồi (%d) đã chạm giới hạn động %d/%d.",
                        signal.symbol, occupied_slots, dynamic_limit,
                        base_cap,
                    )
                    return None

                # CỔNG PHÒNG VỆ 1: Phân bổ ngân sách rủi ro (Risk Budgeting) - Giới hạn số vị thế ĐANG CHỊU RỦI RO (At-Risk Slots)
                at_risk_slots = self._count_at_risk_positions(exclude_symbol=signal.symbol) + len(getattr(self, 'pending_stalking_orders', {}))
                max_at_risk = self._configured_max_at_risk_positions()
                if at_risk_slots >= max_at_risk:
                    logger.info(
                        "🛡️ RISK BUDGET GATE: Bỏ qua lệnh mới %s: Đang có %d vị thế chịu rủi ro (ngưỡng tối đa: %d). "
                        "Chờ vị thế hiện tại dời SL về Hòa Vốn hoặc Chốt Lời 1 phần (Free-Roll) mới mở thêm!",
                        signal.symbol, at_risk_slots, max_at_risk
                    )
                    return None

                portfolio_equity, already_used, available_margin = self._portfolio_capacity_snapshot()

                # CỔNG PHÒNG VỆ 2: Ký quỹ khả dụng tối thiểu (Free Margin Ratio >= 30% NAV)
                free_margin_ratio = available_margin / max(1.0, portfolio_equity)
                if free_margin_ratio < 0.30:
                    logger.warning(
                        "🛡️ MARGIN SAFETY GATE: Bỏ qua lệnh mới %s: Ký quỹ khả dụng %.2f%% (< 30.0%% NAV). "
                        "Bảo tồn vốn thanh khoản khẩn cấp!",
                        signal.symbol, free_margin_ratio * 100
                    )
                    return None

                remaining_risk = max(
                    0.0,
                    portfolio_equity * self._max_total_open_risk() - self._current_open_stop_risk(),
                )
                # QUẢN TRỊ RỦI RO & PHÂN BỔ VỐN ĐỊNH LƯỢNG CO GIÃN ĐA QUY MÔ (SCALE-INVARIANT RISK PARITY SIZING):
                # 1. Ngân sách rủi ro cố định 0.60% Equity (chuẩn institutional Risk Parity, tự động co giãn từ 100$ đến 100,000$+)
                configured_slots = self._configured_max_open_positions()
                fixed_risk_pct = float(self.config.get('risk', {}).get('max_risk_per_trade', 0.0060))
                if fixed_risk_pct > 0.010:
                    fixed_risk_pct = 0.0060 # Khống chế cứng không quá 0.60%
                max_dollar_risk = max(0.35, portfolio_equity * fixed_risk_pct)
                risk_budget = min(
                    remaining_risk,
                    max_dollar_risk,
                )
                if risk_budget <= 0:
                    logger.info(
                        "Bỏ qua lệnh mới %s: đã dùng hết ngân sách rủi ro tổng (%.2f%% equity).",
                        signal.symbol, self._max_total_open_risk() * 100,
                    )
                    return None
                notional = risk_budget / stop_distance_pct

                # [BÀI HỌC 98 - DYNAMIC DELTA SIZING SCALE]:
                # Nhân quy mô Notional theo hệ số Delta N(d1) từ Cổng Lượng Tử (0.75x - 1.25x)
                q_meta_v = (signal.metadata or {}).get('quantum_validation') or {}
                delta_mult = float(q_meta_v.get('delta_multiplier', 1.0))
                if delta_mult > 0 and delta_mult != 1.0:
                    old_notional = notional
                    notional *= delta_mult
                    logger.info(
                        "⚛️ [DYNAMIC DELTA SIZING] Điều chỉnh Notional %s theo hệ số Delta N(d1) (Mult=%.2fx): %.2f USDT -> %.2f USDT.",
                        signal.symbol, delta_mult, old_notional, notional
                    )
                
                # BẢO VỆ DANH MỤC: KHỐNG CHẾ TRẦN NOTIONAL CO GIÃN ĐỘNG THEO PHÂN KHÚC & SCALE-INVARIANT FRACTIONS
                clean_sym = self._clean_symbol(signal.symbol)
                base_coin_cap = signal.symbol.split('/')[0].split(':')[0].strip().upper()
                is_tier1 = base_coin_cap in ('BTC', 'ETH')
                is_stock = MarketScanner.is_tradfi_stock(signal.symbol, self.exchange)
                is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(signal.symbol, self.exchange)
                is_major = base_coin_cap in ('SOL', 'XRP', 'BNB')
                
                if is_tier1:
                    max_notional_cap = max(10.0, portfolio_equity * 0.35)  # Tier 1 (BTC/ETH) tối đa 35% equity
                elif is_major:
                    max_notional_cap = max(8.0, portfolio_equity * 0.25)   # Tier 2 (Top Major Crypto) tối đa 25% equity
                elif is_stock or is_commodity:
                    max_notional_cap = max(6.0, portfolio_equity * 0.20)   # TradFi Equity / Commodity (spread dày) tối đa 20% equity
                else:
                    # Tier 3 (Altcoins): Trần chuẩn 20% equity.
                    # GHI CHÚ KIỂM CHỨNG THỰC TẾ:
                    # Với vốn nhỏ (portfolio_equity trong khoảng 40 - 70 USDT), áp dụng sàn tối thiểu 10.60 USDT
                    # để sau khi làm tròn bước số nguyên (lot step) của Altcoin, vị thế thực tế luôn đạt >= 10.20 USDT,
                    # đảm bảo khi cắt lỗ 50%, mỗi nửa đều >= 5.10 USDT > 5.00 USDT của Binance, tránh lỗi -4164.
                    min_small_cap_floor = 10.60 if portfolio_equity >= 40.0 else 6.0
                    max_notional_cap = max(min_small_cap_floor, portfolio_equity * 0.20)
                
                if notional > max_notional_cap:
                    logger.info(
                        "🛡️ [NOTIONAL CAP] Giới hạn vị thế %s từ %.2f USDT xuống trần %.2f USDT (Phân khúc: %s, Equity: %.2f USDT, Slot: %d).",
                        signal.symbol, notional, max_notional_cap,
                        'Tier 1 (BTC/ETH)' if is_tier1 else ('Tier 2 (TradFi)' if (is_stock or is_commodity) else ('Tier 2 (Major Crypto)' if is_major else 'Tier 3 (Altcoin)')),
                        portfolio_equity, configured_slots
                    )
                    notional = max_notional_cap
                
                # Luôn đảm bảo đạt ngưỡng Min Notional an toàn của Binance (>= 6.0 USDT)
                notional = max(6.0, notional)

                # Ép đòn bẩy TradFi xuống tối đa 4x để tránh trượt giá
                if (is_stock or is_commodity) and leverage > 4:
                    leverage = 4

                requested_leverage = int(leverage)
                if getattr(self, 'market_type', 'spot') == 'futures':
                    leverage, leverage_limit = self._resolve_pair_leverage(
                        signal.symbol, requested_leverage, notional, available_margin,
                    )
                else:
                    leverage = 1
                    leverage_limit = {
                        'max_leverage': 1, 'verified': True, 'source': 'spot',
                        'notional': notional, 'error': None,
                    }
                self.last_leverage_symbol = signal.symbol
                self.last_pair_max_leverage = leverage_limit.get('max_leverage')
                self.last_leverage_limit_verified = bool(leverage_limit.get('verified'))
                self.last_leverage_limit_source = leverage_limit.get('source')
                if leverage is None:
                    logger.error(
                        "Bỏ qua lệnh LIVE %s: chưa xác minh được trần leverage theo cặp/notional (%s).",
                        signal.symbol, leverage_limit.get('error') or 'không có dữ liệu bracket',
                    )
                    return None
                leverage = int(leverage)
                self.last_dynamic_leverage = leverage
                position_size = min(notional / leverage, available_margin)
                base_coin_chk = signal.symbol.split('/')[0].split(':')[0].strip().upper()
                is_major_coin = base_coin_chk in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
                is_stock_chk = MarketScanner.is_tradfi_stock(signal.symbol, self.exchange)
                is_commodity_chk = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(signal.symbol, self.exchange)
                if not is_major_coin and not is_stock_chk and not is_commodity_chk:
                    max_alt_margin = max(6.0, (portfolio_equity / max(1, configured_slots)) * 0.25)
                    # Khi đòn bẩy thấp (<= 2x), đảm bảo position_size * leverage không bị bóp nghẹt dưới sàn min_small_cap_floor (10.60 USDT)
                    # để vị thế luôn đạt tối thiểu 2 nấc chốt lời / cắt giảm tải (> 5.0 USDT/nấc)
                    if leverage <= 2 and portfolio_equity >= 40.0:
                        min_eff_margin = min(available_margin, min_small_cap_floor / leverage)
                        max_alt_margin = max(max_alt_margin, min_eff_margin)
                    if position_size > max_alt_margin:
                        logger.info(
                            "🛡️ [ALTCOIN MARGIN CAP] Giới hạn ký quỹ %s từ %.2f USDT xuống trần %.2f USDT (Đòn bẩy: %dx) để tránh phình vốn.",
                            signal.symbol, position_size, max_alt_margin, leverage
                        )
                        position_size = max_alt_margin
                if position_size <= 0:
                    logger.info("⚠️ Không còn ký quỹ khả dụng cho %s sau khi tính giới hạn cặp", signal.symbol)
                    return None
                if leverage < requested_leverage:
                    logger.info(
                        "Giảm leverage %s từ %dx xuống %dx theo trần cặp %sx tại notional %.2f.",
                        signal.symbol, requested_leverage, leverage,
                        leverage_limit.get('max_leverage'), leverage_limit.get('notional', 0),
                    )
                if not leverage_limit.get('verified'):
                    logger.warning(
                        "DEMO %s dùng %dx nhưng trần leverage cặp chưa xác minh; dữ liệu bracket không khả dụng.",
                        signal.symbol, leverage,
                    )
                
                # Cập nhật đòn bẩy trên sàn thật nếu là futures và live
                if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                    try:
                        leverage_ready = self.exchange.setup_futures_pair(signal.symbol, leverage)
                        if not leverage_ready:
                            logger.error(
                                "Bỏ qua %s vì không xác nhận được margin mode/leverage %dx trên sàn.",
                                signal.symbol, leverage,
                            )
                            return None
                    except Exception as e:
                        logger.error(f"Lỗi cập nhật đòn bẩy {leverage}x cho {signal.symbol}: {e}")
                        return None
                        
                effective_size = position_size * leverage
                amount = effective_size / signal.price
                
                # Kiểm tra và điều chỉnh theo giới hạn tối thiểu của sàn (Min Notional / Min Amount)
                try:
                    ccxt_symbol = self.exchange._get_ccxt_symbol(signal.symbol)
                    markets = self.exchange.exchange.markets
                    if markets and ccxt_symbol in markets:
                        market = markets[ccxt_symbol]
                        min_amount = market.get('limits', {}).get('amount', {}).get('min', 0)
                        min_cost = market.get('limits', {}).get('cost', {}).get('min', 0)
                        
                        # Điều chỉnh theo min_amount
                        if amount < min_amount:
                            amount = min_amount * 1.05
                            
                        # Làm tròn lot-step trước khi kiểm tra min notional để tránh lỗi Binance -4164
                        try:
                            if hasattr(self.exchange, 'exchange') and hasattr(self.exchange.exchange, 'amount_to_precision'):
                                for _ in range(5):
                                    fmt_amt = float(self.exchange.exchange.amount_to_precision(ccxt_symbol, amount))
                                    if min_cost <= 0 or (fmt_amt > 0 and fmt_amt * signal.price >= min_cost * 1.02):
                                        amount = fmt_amt
                                        break
                                    amount *= 1.03
                        except Exception:
                            pass

                        # Điều chỉnh theo min_cost (Notional)
                        if min_cost and (amount * signal.price) < min_cost:
                            amount = (min_cost * 1.05) / signal.price
                            
                        # Tính lại số tiền Ký quỹ thực tế sau khi điều chỉnh
                        required_margin = (amount * signal.price) / leverage
                        # Bổ sung Margin Precision Tolerance (Dung sai làm tròn bước sàn: tối đa 8% hoặc 0.08 USDT)
                        # Ngăn chặn việc hủy oan các lệnh xác suất thắng cao (như IOTX) chỉ vì lệch 0.002 USDT do lot size
                        margin_tolerance = max(0.08, position_size * 0.08)

                        # CƠ CHẾ NÂNG ĐỠ MAJOR PAIRS CHO VỐN NHỎ (BINANCE 0.001 BTC CONTRACT FLOOR):
                        # Đối với Coin Major (BTC/ETH) khi Cổng Lượng Tử phê duyệt hạng xuất sắc (QUANTUM_EXCELLENT/VERY_HIGH),
                        # bước tối thiểu 0.001 BTC (~68 USDT Notional) cần ~7.5 - 8.9 USDT margin.
                        # Cho phép mở rộng margin_tolerance nếu tổng ký quỹ required_margin <= available_margin
                        # và rủi ro tối đa khi dính SL không vượt quá 1.0% NAV (tương đương 1.00 USDT trên vốn $100).
                        clean_sym_maj = signal.symbol.split(':')[0].strip().upper()
                        is_major_tier1 = any(clean_sym_maj.startswith(m) for m in ('BTC/', 'ETH/', 'BTC', 'ETH'))
                        q_meta = getattr(signal, 'metadata', {}).get('quantum_validation', {}) if isinstance(getattr(signal, 'metadata', None), dict) else {}
                        is_quantum_top = q_meta.get('confidence_tier') in ('QUANTUM_EXCELLENT', 'QUANTUM_VERY_HIGH') and float(q_meta.get('p_win', 0.0)) >= 0.78
                        if is_major_tier1 and is_quantum_top:
                            major_risk_cap = max(0.010, float(self.config.get('risk', {}).get('max_risk_per_trade', 0.0060)) * 1.67) # Tối đa 1.0% NAV
                            cand_sl = getattr(signal, 'stop_loss', None)
                            est_sl_dist = abs(signal.price - float(cand_sl)) / signal.price if cand_sl and float(cand_sl) > 0 else 0.015
                            est_dollar_loss = (amount * signal.price) * est_sl_dist
                            account_eq = float(self.balance)
                            if est_dollar_loss <= (account_eq * major_risk_cap) and required_margin <= available_margin:
                                margin_tolerance = max(margin_tolerance, required_margin - position_size)
                                logger.info(
                                    f"🛡️ [QUANTUM MAJOR ADAPTIVE SIZING] {signal.symbol}: Ký quỹ thích ứng {required_margin:.2f} USDT cho bước tối thiểu sàn "
                                    f"(P_Win={q_meta.get('p_win', 0)*100:.1f}%, Rủi ro SL={est_dollar_loss:.2f} USDT <= {account_eq * major_risk_cap:.2f} USDT trần 1.0% NAV)."
                                )

                        if required_margin > (position_size + margin_tolerance):
                            logger.warning(
                                f"Bỏ qua {signal.symbol}: margin tối thiểu của sàn "
                                f"({required_margin:.2f}) vượt ngân sách rủi ro ({position_size:.2f} + đệm {margin_tolerance:.2f})."
                            )
                            return None
                        elif required_margin > position_size:
                            if required_margin <= available_margin:
                                logger.info(
                                    f"🛡️ [MARGIN PRECISION TOLERANCE] {signal.symbol}: Điều chỉnh ký quỹ từ {position_size:.2f} lên {required_margin:.2f} USDT để thỏa mãn bước sàn (Đệm: +{required_margin - position_size:.3f} USDT <= {margin_tolerance:.2f})."
                                )
                                position_size = required_margin
                            else:
                                logger.warning(
                                    f"Bỏ qua {signal.symbol}: Ký quỹ yêu cầu ({required_margin:.2f}) vượt số dư khả dụng ({available_margin:.2f})."
                                )
                                return None
                except Exception as e:
                    logger.error(f"Lỗi kiểm tra giới hạn sàn: {e}")
                    pass
                
                # Kiểm tra bảo vệ trượt giá trước khi đặt lệnh (Pre-Order Slippage Shield):
                # Tránh trường hợp sau 20-30s phân tích AI/JEV, giá thị trường đã chạy quá xa so với giá tín hiệu
                try:
                    live_ticker = self.exchange.get_ticker(signal.symbol)
                    if live_ticker and signal.price > 0:
                        if side == 'buy':
                            exec_check_price = float(live_ticker.get('ask') or live_ticker.get('last') or signal.price)
                            slip_pct = (exec_check_price - signal.price) / signal.price
                            if slip_pct > 0.006:  # Giá đã tăng vọt > 0.6% so với lúc phân tích
                                logger.warning(
                                    f"🛡️ [CHẶN ĐUA LỆNH ĐỈNH] Bỏ qua vào BUY {signal.symbol}: Giá Ask thị trường ({exec_check_price:.6g}) "
                                    f"đã chạy vọt +{slip_pct*100:.2f}% so với giá tín hiệu ({signal.price:.6g}) trong thời gian AI phân tích! "
                                    f"Hủy lệnh để tránh đu đỉnh râu nến."
                                )
                                return None
                        else:
                            exec_check_price = float(live_ticker.get('bid') or live_ticker.get('last') or signal.price)
                            slip_pct = (signal.price - exec_check_price) / signal.price
                            if slip_pct > 0.006:  # Giá đã sập > 0.6% so với lúc phân tích
                                logger.warning(
                                    f"🛡️ [CHẶN BÁN THÁO ĐÁY] Bỏ qua vào SELL {signal.symbol}: Giá Bid thị trường ({exec_check_price:.6g}) "
                                    f"đã sập -{slip_pct*100:.2f}% so với giá tín hiệu ({signal.price:.6g}) trong thời gian AI phân tích! "
                                    f"Hủy lệnh để tránh bán tháo đáy."
                                )
                                return None
                except Exception as se:
                    logger.debug(f"Không thể kiểm tra slippage trước lệnh: {se}")

                trading_cfg = self.config.get('trading', {})
                sniper_m1_active = bool(trading_cfg.get('sniper_retest_enabled', True))
                pullback_pct = float(trading_cfg.get('sniper_pullback_pct', 0.0035))
                max_plunge_pct = float(trading_cfg.get('sniper_max_plunge_pct', 0.0080))
                sniper_timeout = int(trading_cfg.get('sniper_timeout_seconds', 900))

                # PHÂN LỚP TÀI SẢN (ADAPTIVE ASSET EXECUTION - KIỂM CHỨNG TRÊN 3111 TÍN HIỆU LOGS):
                # - TRADFI STOCKS (Cổ phiếu Mỹ: MU, TSLA, NVDA...): Chạy độc lập theo phiên Wall Street,
                #   không bị râu quét như crypto nên kích hoạt vào lệnh trực tiếp (Runner Entry) để bắt trọn sóng bứt phá!
                # - CRYPTO (Altcoins & Majors): Bắt buộc dùng M1 Sniper Retest (-0.35% Limit Maker) để phòng thủ bẫy xả đỉnh!
                is_commodity_pair = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(signal.symbol, self.exchange)
                is_pure_stock = MarketScanner.is_tradfi_stock(signal.symbol, self.exchange) and not is_commodity_pair
                is_tradfi_pair = is_pure_stock or is_commodity_pair

                # TOÀN BỘ TÀI SẢN (Crypto Major, Altcoins, Hàng hóa, Cổ phiếu TradFi):
                # BẮT BUỘC dùng M1 Sniper Maker (-0.12% đến -0.35% ATR) để đón lõng và tự hủy trong RAM nếu giá giật ngược!
                # Triệt tiêu hoàn toàn thảm họa Runner Entry Market Taker đu đỉnh/bán đáy như BE/USDT (-0.25$)!
                if sniper_m1_active:
                    # THUẬT TOÁN BẮN TỈA M1 CHO CRYPTO: ĐÓN LÕNG TẠI ĐÁY NHỊP RETEST THÍCH ỨNG THEO ATR (ATR-ADAPTIVE)
                    # Đã kiểm chứng tối ưu trên 244 lệnh lịch sử (Net PnL +1.93$, PF 2.34):
                    # - Coin biến động thấp / nhịp chạy dứt khoát: Rình ở 0.18% - 0.22% để khớp ngay không lỡ nhịp
                    # - Coin giật mạnh / Meme: Rình ở 0.30% - 0.35% để tránh bẫy râu xả đỉnh
                    calculated_pullback = pullback_pct
                    try:
                        dfs = getattr(signal, 'metadata', {}).get('dfs') or {}
                        df_15m = dfs.get('15m')
                        if df_15m is None or (hasattr(df_15m, 'empty') and df_15m.empty) or len(df_15m) < 15:
                            if hasattr(self, 'data_collector'):
                                df_15m = self.data_collector.fetch_data(signal.symbol, '15m', limit=20)
                        if df_15m is not None and len(df_15m) >= 15:
                            # ATR rình Maker chỉ được đo trên nến 15m đã đóng; nến đang chạy
                            # có thể phóng râu làm lệch giá retest ngay trong chu kỳ.
                            closed_15m = df_15m.iloc[:-1]
                            prev_close = closed_15m['close'].shift(1)
                            tr = pd.concat([
                                closed_15m['high'] - closed_15m['low'],
                                (closed_15m['high'] - prev_close).abs(),
                                (closed_15m['low'] - prev_close).abs()
                            ], axis=1).max(axis=1)
                            atr_val = float(tr.tail(14).mean())
                            if signal.price > 0 and atr_val > 0:
                                atr_pct = atr_val / signal.price
                                # Khi tín hiệu có độ tự tin cao (>= 75%), thị trường đang có đà bứt phá dứt khoát:
                                # Co hẹp khoảng cách đón lõng (0.12% - 0.22%) để lệnh Maker khớp ngay, không bị bỏ rơi khi giá bay thẳng!
                                sig_conf_val = float(getattr(signal, 'confidence', 0.50) or 0.50)
                                if sig_conf_val >= 0.75:
                                    calculated_pullback = max(0.0012, min(0.0022, atr_pct * 0.18))
                                else:
                                    calculated_pullback = max(0.0018, min(0.0035, atr_pct * 0.30))
                    except Exception as atre:
                        logger.debug("Không tính được ATR adaptive pullback cho %s: %s", signal.symbol, atre)

                    if side == 'buy':
                        retest_target_price = signal.price * (1.0 - calculated_pullback)
                        plunge_invalid_price = signal.price * (1.0 - max_plunge_pct)
                    else:
                        retest_target_price = signal.price * (1.0 + calculated_pullback)
                        plunge_invalid_price = signal.price * (1.0 + max_plunge_pct)

                    if hasattr(self.exchange, 'exchange') and hasattr(self.exchange.exchange, 'price_to_precision'):
                        try:
                            ccxt_sym_prec = self.exchange._get_ccxt_symbol(signal.symbol)
                            retest_target_price = float(self.exchange.exchange.price_to_precision(ccxt_sym_prec, retest_target_price))
                        except Exception:
                            pass

                    # Điều chỉnh khoảng cách SL/TP theo giá retest tối ưu (giữ nguyên clamped_tp_dist của chiến thuật)
                    if direction == 'LONG':
                        sl_price = retest_target_price * (1.0 - clamped_sl_dist)
                        tp_price = retest_target_price * (1.0 + clamped_tp_dist)
                    else:
                        sl_price = retest_target_price * (1.0 + clamped_sl_dist)
                        tp_price = retest_target_price * (1.0 - clamped_tp_dist)

                    if self.mode == 'demo':
                        order = {'id': f"demo_sniper_{int(time.time()*1000)}", 'status': 'open', 'price': retest_target_price, 'amount': amount}
                    else:
                        try:
                            order = self.exchange.create_futures_order(
                                signal.symbol, side, amount, retest_target_price,
                                order_type='limit', post_only=True
                            )
                        except Exception as pe:
                            # Timeout không chứng minh GTX đã thất bại. Không được đặt thêm một
                            # lệnh non-post-only: có thể thành Taker hoặc nhân đôi lệnh trên sàn.
                            logger.warning(
                                "Không xác nhận được lệnh GTX/Maker cho %s (%s); giữ nguyên không vào lệnh, chờ chu kỳ sau.",
                                signal.symbol, pe,
                            )
                            order = None

                    if not order or not order.get('id'):
                        logger.error("Không đặt được lệnh Limit Maker rình mồi cho %s", signal.symbol)
                        return None

                    # Đưa vào hàng đợi rình mồi M1
                    self.pending_stalking_orders[signal.symbol] = {
                        'order_id': str(order.get('id')),
                        'symbol': signal.symbol,
                        'side': side,
                        'direction': direction,
                        'signal_price': signal.price,
                        'target_price': retest_target_price,
                        'invalid_price': plunge_invalid_price,
                        'created_at': time.time(),
                        'timeout_seconds': sniper_timeout,
                        'amount': amount,
                        'position_size': position_size,
                        'leverage': leverage,
                        'sl_price': sl_price,
                        'tp_price': tp_price,
                        'clamped_sl_dist': clamped_sl_dist,
                        'clamped_tp_dist': clamped_tp_dist,
                        'atr_pct': atr_pct,
                        'strategy': getattr(signal, 'strategy', 'sniper_m1'),
                        'trap_type': (getattr(signal, 'metadata', None) or {}).get('type') if isinstance(getattr(signal, 'metadata', None), dict) else None,
                        'confidence': float(getattr(signal, 'confidence', 0.8)),
                        'signal_quality': float(getattr(self, 'last_signal_quality', 1.0) or 1.0),
                        'is_momentum_ride': bool(meta.get('is_momentum_ride')),
                        'is_fading_short': bool(meta.get('is_fading_short')),
                        'is_waterfall_short': bool(meta.get('is_waterfall_short')),
                        'is_oversold_bounce': bool(meta.get('is_oversold_bounce')),
                        'be_trigger_override': meta.get('be_trigger_pct'),
                        'exchange_leverage_limit': leverage_limit.get('max_leverage'),
                        'leverage_limit_verified': bool(leverage_limit.get('verified')),
                        'leverage_limit_source': leverage_limit.get('source'),
                        'market_type': getattr(self, 'market_type', 'spot'),
                    }
                    self._save_state()
                    if meta.get('is_fading_short') and hasattr(self, '_fading_short_watchlist'):
                        self._fading_short_watchlist.pop(clean_sig_sym, None)
                    try:
                        from core.gate_telemetry import record_radar_candidate
                        record_radar_candidate(
                            symbol=signal.symbol,
                            side=direction,
                            confidence=float(getattr(signal, 'confidence', 0.8)),
                            score=float((getattr(signal, 'metadata', {}) or {}).get('weighted_score', getattr(signal, 'score', 0.0)) or 0.0),
                            strategies_agreed=', '.join((getattr(signal, 'metadata', {}) or {}).get('contributing_strategies', [])) or str(getattr(signal, 'strategy', 'M1 Sniper Retest')),
                            dynamic_leverage=leverage,
                            bottleneck_gate='M1_SNIPER_STALKING',
                            bottleneck_reason=f"Đang rình khớp Limit Maker tại {retest_target_price:.6g} (-{calculated_pullback*100:.2f}%)",
                            readiness_pct=98.0
                        )
                    except Exception:
                        pass
                    logger.info(
                        f"🎯 [BẮN TỈA M1 ATR-ADAPTIVE] {signal.symbol} ({side.upper()}): Đặt lệnh Limit Maker tại {retest_target_price:.6g} "
                        f"(-{calculated_pullback*100:.2f}% chiết khấu ATR so với đỉnh {signal.price:.6g})! Hạn chờ {sniper_timeout//60}m, hủy nếu xả thủng {plunge_invalid_price:.6g}."
                    )
                    return order
                elif self.mode == 'demo':
                    if is_tradfi_pair:
                        logger.info(
                            f"🏛️ [TRADFI RUNNER DEMO] {signal.symbol} ({side.upper()}): "
                            f"Cổ phiếu / Hàng hóa Mỹ TradFi vào lệnh trực tiếp để bắt trọn sóng bứt phá (không rình lùi)!"
                        )
                    # Demo mode - giả lập lệnh
                    order = self._demo_order(signal, amount, side=side)
                else:
                    # Live mode

                    order_type_cfg = self.config['trading'].get('order_type', 'market')
                    if getattr(self, 'market_type', 'spot') == 'futures':
                        if order_type_cfg in ('maker', 'post_only'):
                            # Thực thi Post-Only Maker: Lấy giá tốt nhất từ sổ lệnh
                            ticker = self.exchange.get_ticker(signal.symbol)
                            exec_price = signal.price
                            if ticker:
                                if side == 'buy' and ticker.get('bid'):
                                    exec_price = float(ticker['bid'])
                                elif side == 'sell' and ticker.get('ask'):
                                    exec_price = float(ticker['ask'])
                            order = self.exchange.create_futures_order(
                                signal.symbol, side, amount, exec_price,
                                order_type='limit', post_only=True
                            )
                        else:
                            order = self.exchange.create_futures_order(
                                signal.symbol, side, amount, signal.price,
                                order_type_cfg
                            )
                    else:
                        order = self.exchange.create_buy_order(
                            signal.symbol, amount, signal.price,
                            order_type_cfg
                        )

                if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                    if not order:
                        logger.error("Binance không trả xác nhận cho lệnh mở %s; đối soát vị thế trước khi thử lại.", signal.symbol)
                        self.sync_live_positions_with_exchange()
                        return None
                    order = dict(order)
                    order_type_cfg = self.config['trading'].get('order_type', 'market')
                    max_checks = 60 if order_type_cfg in ('maker', 'post_only') else 12
                    if order.get('id'):
                        for _ in range(max_checks):
                            order_status = str(order.get('status') or '').lower()
                            if order_status in ('closed', 'filled', 'canceled', 'cancelled', 'rejected', 'expired'):
                                break
                            latest = self.exchange.get_order_status(order['id'], signal.symbol)
                            if latest:
                                order = latest
                            else:
                                time.sleep(0.25)
                    status = str(order.get('status') or '').lower()
                    filled_amount = float(order.get('filled') or 0)
                    if filled_amount <= 0 and status in ('closed', 'filled'):
                        filled_amount = float(order.get('amount') or amount)
                    if status not in ('closed', 'filled') and order_type_cfg in ('maker', 'post_only'):
                        logger.warning("Lệnh Maker %s chưa khớp sau thời gian chờ; hủy lệnh để tránh rủi ro trượt giá.", signal.symbol)
                        try:
                            self.exchange.cancel_order(order['id'], signal.symbol)
                        except Exception as ce:
                            logger.error(f"Lỗi hủy lệnh Maker {signal.symbol}: {ce}")
                        return None
                    if status in ('rejected', 'expired') or filled_amount <= 0:
                        logger.error("Không xác nhận được khối lượng khớp lệnh mở %s; đối soát Binance.", signal.symbol)
                        self.sync_live_positions_with_exchange()
                        return None
                    amount = filled_amount
                
                if order:
                    raw_avg = order.get('average') or (order.get('info') or {}).get('avgPrice')
                    if raw_avg and float(raw_avg) > 0:
                        real_entry_price = float(raw_avg)
                    elif order.get('price') and float(order.get('price')) > 0:
                        real_entry_price = float(order.get('price'))
                    else:
                        real_entry_price = float(signal.price)
                    entry_price = real_entry_price if self.mode == 'live' else float(signal.price)
                    if self.mode == 'live':
                        position_size = amount * entry_price / max(1.0, leverage)
                    fee_rate = max(0.0, float(self.config.get('trading', {}).get('fee_rate', 0.001)))
                    slippage_rate = max(0.0, float(self.config.get('trading', {}).get('slippage_rate', 0.0005)))
                    if self.mode == 'demo':
                        # Paper execution uses a conservative market fill and both-side fees.
                        entry_price *= (1 + slippage_rate) if direction == 'LONG' else (1 - slippage_rate)
                    entry_fee = amount * entry_price * fee_rate

                    if direction == 'LONG':
                        sl_price = entry_price * (1.0 - clamped_sl_dist)
                        tp_price = entry_price * (1.0 + clamped_tp_dist)
                    else:
                        sl_price = entry_price * (1.0 + clamped_sl_dist)
                        tp_price = entry_price * (1.0 - clamped_tp_dist)

                    sl_order_id = None
                    tp_order_id = None
                    if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                        close_side = 'sell' if direction == 'LONG' else 'buy'
                        try:
                            sls = self.exchange.create_stop_market_order(signal.symbol, close_side, amount, sl_price)
                            sl_info = (sls or {}).get('info') or {}
                            sl_order_id = str((sls or {}).get('id') or sl_info.get('algoId') or sl_info.get('orderId') or '') or None
                        except Exception as e:
                            logger.error(f"Lỗi tạo lệnh SL cho {signal.symbol}: {e}")
                            
                        try:
                            tps = self.exchange.create_take_profit_market_order(signal.symbol, close_side, amount, tp_price)
                            tp_info = (tps or {}).get('info') or {}
                            tp_order_id = str((tps or {}).get('id') or tp_info.get('algoId') or tp_info.get('orderId') or '') or None
                        except Exception as e:
                            logger.error(f"Lỗi tạo lệnh TP cho {signal.symbol}: {e}")

                    protection_status = 'exchange_stop'
                    if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures' and not sl_order_id:
                        protection_status = 'bot_poll_only'
                        logger.critical(
                            "Không đặt được stop-loss phía sàn cho %s; đang thử đóng vị thế ngay.",
                            signal.symbol,
                        )
                        self._notify_telegram(
                            f"🚨 KHẨN CẤP: Binance không nhận stop-loss cho {signal.symbol}. "
                            "Bot đang thử đóng vị thế để tránh giữ lệnh không được bảo vệ."
                        )
                        try:
                            emergency_close = self.exchange.close_futures_position(
                                signal.symbol, direction, amount,
                            )
                            logger.error("Đã gửi lệnh đóng khẩn cấp cho %s; đang xác nhận vị thế trên Binance.", signal.symbol)
                        except Exception as e:
                            logger.critical("Đóng khẩn cấp %s cũng thất bại: %s", signal.symbol, e)

                        try:
                            remaining = self._matching_exchange_positions(signal.symbol, direction)
                            remaining_amount = sum(
                                abs(float(pos.get('contracts') or (pos.get('info') or {}).get('positionAmt') or 0))
                                for pos in remaining
                            )
                            if remaining_amount <= 0:
                                if tp_order_id:
                                    try:
                                        self.exchange.cancel_order(
                                            tp_order_id, signal.symbol,
                                            trigger=True, strict=True,
                                        )
                                    except Exception as e:
                                        logger.error(
                                            "Không hủy được TP điều kiện %s sau khi đóng khẩn cấp %s: %s",
                                            tp_order_id, signal.symbol, e,
                                        )
                                self.sync_live_positions_with_exchange()
                                logger.warning("Đã xác nhận vị thế %s đóng sau khi Binance từ chối stop-loss.", signal.symbol)
                                return None
                            amount = remaining_amount
                            remote_entry = remaining[0].get('entryPrice') or (remaining[0].get('info') or {}).get('entryPrice')
                            if remote_entry:
                                entry_price = float(remote_entry)
                            position_size = amount * entry_price / max(1.0, leverage)
                            logger.critical("Vị thế %s vẫn mở nhưng chưa có SL sàn; sẽ được theo dõi trong dashboard.", signal.symbol)
                            self._notify_telegram(
                                f"🚨 Vị thế LIVE {direction} {signal.symbol} vẫn còn mở nhưng Binance từ chối stop-loss. "
                                "Tool sẽ giữ vị thế trong dashboard; hãy đóng thủ công hoặc kiểm tra ngay SL/TP trên Binance."
                            )
                        except Exception as e:
                            logger.critical("Không đối soát được vị thế %s sau lỗi đặt SL: %s; giữ trạng thái để xử lý.", signal.symbol, e)
                            self._notify_telegram(
                                f"🚨 Không xác nhận được trạng thái vị thế LIVE {signal.symbol} sau lỗi đặt stop-loss. "
                                "Hãy kiểm tra Binance ngay; tool sẽ giữ trạng thái để đối soát."
                            )

                    position_atr_pct = (atr_val / entry_price) if (atr_val > 0 and entry_price > 0) else atr_pct
                    if not math.isfinite(position_atr_pct) or position_atr_pct <= 0:
                        position_atr_pct = 0.015

                    position = {
                        'symbol': signal.symbol,
                        'side': side,
                        'direction': direction,
                        'entry_price': entry_price,
                        'amount': amount,
                        'initial_amount': amount,
                        'cost': position_size,
                        'initial_cost': position_size,
                        'atr': entry_price * position_atr_pct,
                        'atr_pct': position_atr_pct,
                        'initial_sl_distance_pct': stop_distance_pct,
                        'total_sl_stages': self._calc_adaptive_stages({'initial_amount': amount, 'entry_price': entry_price}, entry_price),
                        'sl_stage_completed': 0,
                        'entry_fee': entry_fee,
                        'leverage': leverage,
                        'exchange_leverage_limit': leverage_limit.get('max_leverage'),
                        'leverage_limit_verified': bool(leverage_limit.get('verified')),
                        'leverage_limit_source': leverage_limit.get('source'),
                        'market_type': getattr(self, 'market_type', 'spot'),
                        'stop_loss': sl_price,
                        'take_profit': tp_price,
                        'strategy': signal.strategy,
                        'trap_type': getattr(signal, 'metadata', {}).get('type') if isinstance(getattr(signal, 'metadata', None), dict) else None,
                        'signal_quality': getattr(self, 'last_signal_quality', 1.0),
                        'is_momentum_ride': bool(meta.get('is_momentum_ride')),
                        'is_fading_short': bool(meta.get('is_fading_short')),
                        'is_waterfall_short': bool(meta.get('is_waterfall_short')),
                        'is_oversold_bounce': bool(meta.get('is_oversold_bounce')),
                        'be_trigger_override': meta.get('be_trigger_pct'),
                        'timestamp': datetime.now().isoformat(),
                        'order_id': order.get('id', f"demo_{int(time.time())}"),
                        'sl_order_id': sl_order_id,
                        'tp_order_id': tp_order_id,
                        'protection_status': protection_status,
                        'trailing_stop': None,
                        'trailing_best_price': entry_price,
                        'trailing_active': False,
                        'trailing_status': 'waiting_net_profit',
                        'trailing_distance_pct': None,
                        'trailing_atr_pct': None,
                        'trailing_adx': None,
                        'trailing_regime': 'not_calculated',
                        'trailing_net_breakeven': None,
                    }
                    self.open_positions.append(position)
                    if meta.get('is_fading_short') and hasattr(self, '_fading_short_watchlist'):
                        self._fading_short_watchlist.pop(clean_sig_sym, None)
                    try:
                        from core.gate_telemetry import clear_radar_candidate
                        clear_radar_candidate(position.get('symbol', ''))
                    except Exception:
                        pass
                    self.balance -= position_size
                    if self.mode == 'demo':
                        self.balance -= entry_fee
                    self.trade_count += 1
                    
                    entry_profile = self._get_asset_adaptive_trailing_profile(signal.symbol)
                    breakeven_trigger_pct = float(entry_profile.get('breakeven_trigger') or self.config.get('risk', {}).get('breakeven_trigger_pct', 0.0065))
                    mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
                    direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
                    quote = self.config.get('trading', {}).get('base_currency', 'USDT')
                    risk_factor_str = signal.metadata.get('risk_factors', 'Đã thẩm định: cấu trúc an toàn, không có bẫy thanh khoản')
                    ai_reason_str = signal.metadata.get('reason', 'Đồng thuận tín hiệu kỹ thuật & AI')
                    order_type_tag = "[MAKER 0.02% FEE]" if self.config.get('trading', {}).get('order_type') in ('maker', 'post_only') else "[MARKET TAKER]"
                    msg = (
                        f"🚀 **[{mode_str}] MỞ LỆNH {direction_str}** {order_type_tag}\n\n"
                        f"📊 **Cặp giao dịch:** {signal.symbol} ({leverage}x)\n"
                        f"🎯 **Giá vào (Entry):** {entry_price:.6f}\n"
                        f"🔒 **BE tham chiếu profile:** +{breakeven_trigger_pct*100:.1f}% (ngưỡng thực tế thích ứng theo ATR/TP1)\n"
                        f"🛑 **Cắt lỗ (SL):** {sl_price:.6f} ({abs(sl_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
                        f"🎯 **Chốt lời (TP):** {tp_price:.6f} ({abs(tp_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
                        f"🧠 **AI & Chiến lược:** {signal.strategy} (Độ tin cậy: {signal.confidence:.1%})\n"
                        f"💬 **Luận điểm kỹ thuật:** {ai_reason_str}\n"
                        f"🛡️ **Devil's Advocate:** {risk_factor_str}\n"
                        f"💰 **Ký quỹ:** {position_size:.2f} {quote} | **Khả dụng:** {self.balance:.2f} {quote}" + (f" | **Tổng vốn:** {float(self._futures_account_snapshot.get('wallet_balance')):.2f} {quote}" if self.mode == 'live' and getattr(self, '_futures_account_snapshot', None) and self._futures_account_snapshot.get('wallet_balance') is not None else "")
                    )
                    self._notify_telegram(msg)
                    
                    # Lưu vào database
                    self.db.save_trade({
                        'symbol': signal.symbol,
                        'side': side,
                        'type': self.config['trading']['order_type'],
                        'price': entry_price,
                        'amount': amount,
                        'cost': amount * entry_price,
                        'fee': entry_fee,
                        'pnl': 0,
                        'strategy': signal.strategy,
                        'status': 'open',
                        'order_id': position['order_id'],
                        'timestamp': int(time.time() * 1000),
                        'mode': self.mode
                    })
                    
                    logger.info(
                        f"✅ MỞ {direction} {signal.symbol}: "
                        f"Giá={entry_price:.6g}, "
                        f"Số lượng={amount:.6f}, "
                        f"Margin={position_size:.2f} {quote}, "
                        f"Đòn bẩy={leverage}x, "
                        f"SL={position['stop_loss']:.6g}, "
                        f"TP={position['take_profit']:.6g}"
                    )
                    
                    return position
                    
        except Exception as e:
            logger.error(f"Lỗi thực thi lệnh: {e}")
        
        return None

    def _demo_order(self, signal, amount: float, side: str = 'buy') -> dict:
        """Giả lập lệnh mua/bán trong chế độ demo."""
        return {
            'id': f"demo_{int(time.time() * 1000)}",
            'symbol': signal.symbol,
            'type': 'limit',
            'side': str(side or 'buy').lower(),
            'price': signal.price,
            'amount': amount,
            'cost': signal.price * amount,
            'status': 'closed',
            'timestamp': int(time.time() * 1000)
        }

    def _demo_buy(self, signal, amount: float) -> dict:
        """Backward compatibility wrapper."""
        return self._demo_order(signal, amount, side='buy')

    def _exchange_position_direction(self, exchange_position: dict) -> Optional[str]:
        """Normalize a CCXT/Binance position direction."""
        side = str(exchange_position.get('side') or '').lower()
        if side in ('long', 'buy'):
            return 'LONG'
        if side in ('short', 'sell'):
            return 'SHORT'

        info = exchange_position.get('info') or {}
        position_side = str(info.get('positionSide') or '').upper()
        if position_side in ('LONG', 'SHORT'):
            return position_side
        try:
            signed_amount = float(info.get('positionAmt') or 0)
            if signed_amount > 0:
                return 'LONG'
            if signed_amount < 0:
                return 'SHORT'
        except (TypeError, ValueError):
            pass
        return None

    @staticmethod
    def _clean_symbol(symbol: str) -> str:
        return str(symbol or '').split(':')[0].replace('/', '').upper()

    def _set_phase2_veto_cooldown(self, pair: str, duration: float = 240.0):
        """Khoa tam thoi ung vien bi phu quyet o Pha 2 de nhuong slot xoay vong cong bang (Fair Rotation) cho cac dong coin khac."""
        clean_sym = self._clean_symbol(pair)
        self._phase2_veto_cooldowns[clean_sym] = time.time() + duration

    def _matching_exchange_positions(self, symbol: str, direction: str) -> List[Dict]:
        clean_symbol = self._clean_symbol(symbol)
        return [
            p for p in self.exchange.get_futures_positions(symbol)
            if self._clean_symbol(p.get('symbol')) == clean_symbol
            and self._exchange_position_direction(p) == direction
        ]

    def _verify_live_position_protection(self, positions: List[dict]) -> bool:
        """Confirm saved futures stop IDs still exist among Binance trigger orders.

        This is read-only. If Binance cannot confirm the snapshot, or a saved
        stop is absent, mark the position for review and block new entries; do
        not invent a replacement order or close the position automatically.
        """
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures' or not positions:
            return False

        try:
            # Binance/CCXT rejects fetchOpenOrders() without a symbol by default
            # and charges a much higher request weight for an account-wide query.
            # Only fetch conditional orders for symbols whose positions need
            # protection verification.
            symbols_by_key = {}
            for position in positions:
                symbol = str(position.get('symbol') or '').strip()
                symbol_key = self._clean_symbol(symbol)
                if not symbol or not symbol_key:
                    raise RuntimeError('Vị thế thiếu mã symbol để xác minh lệnh bảo vệ')
                symbols_by_key.setdefault(symbol_key, symbol)

            open_order_keys = set()
            symbol_orders = {}
            for symbol in symbols_by_key.values():
                orders = self.exchange.get_open_orders(symbol, trigger=True, strict=True)
                if not isinstance(orders, list):
                    raise RuntimeError(f'Binance trả danh sách lệnh điều kiện không hợp lệ cho {symbol}')
                clean_sym = self._clean_symbol(symbol)
                symbol_orders[clean_sym] = orders
                for order in orders:
                    if not isinstance(order, dict):
                        continue
                    info = order.get('info') or {}
                    for oid in (order.get('id'), info.get('algoId'), info.get('orderId'), info.get('clientOrderId'), order.get('clientOrderId')):
                        if oid:
                            open_order_keys.add((clean_sym, str(oid)))
        except Exception as e:
            for position in positions:
                position['protection_review_required'] = True
                position['protection_review_reason'] = 'open_orders_unavailable'
                position['take_profit_order_unverified'] = True
            logger.critical(
                'Không xác minh được SL/TP điều kiện trên Binance; khóa lệnh mới và giữ nguyên vị thế: %s', e,
            )
            return True

        needs_review = False
        for position in positions:
            clean_sym = self._clean_symbol(position.get('symbol'))
            saved_sl_id = str(position.get('sl_order_id') or '')
            key = (clean_sym, saved_sl_id)
            stop_verified = bool(saved_sl_id and key in open_order_keys)

            # TỰ ĐỘNG ĐỒNG BỘ NẾU NGƯỜI DÙNG TỰ ĐIỀU CHỈNH SL TRỰC TIẾP TRÊN SÀN BINANCE:
            if not stop_verified:
                target_close_side = 'sell' if position.get('direction') == 'LONG' else 'buy'
                candidate_sl = None
                for o in symbol_orders.get(clean_sym, []):
                    o_info = o.get('info') or {}
                    raw_types = [
                        str(o_info.get('orderType') or ''),
                        str(o_info.get('origType') or ''),
                        str(o_info.get('type') or ''),
                        str(o.get('type') or ''),
                    ]
                    is_stop_order = any('STOP' in t.upper() for t in raw_types) or (
                        float(o.get('stopPrice') or o_info.get('triggerPrice') or o_info.get('stopPrice') or 0) > 0
                        and not any('TAKE' in t.upper() for t in raw_types)
                    )
                    o_side = str(o.get('side') or o_info.get('side') or '').lower()
                    reduce_flag = o_info.get('reduceOnly', o.get('reduceOnly'))
                    close_position_flag = o_info.get('closePosition', o.get('closePosition'))
                    is_reduce_only = (
                        str(reduce_flag).lower() == 'true'
                        or str(close_position_flag).lower() == 'true'
                    )
                    order_position_side = str(o_info.get('positionSide') or '').upper()
                    expected_position_side = str(position.get('direction') or 'LONG').upper()
                    order_qty = float(o.get('amount') or o_info.get('origQty') or o_info.get('quantity') or 0.0)
                    position_qty = abs(float(position.get('amount') or 0.0))
                    quantity_ok = str(close_position_flag).lower() == 'true' or (
                        order_qty > 0 and position_qty > 0 and order_qty >= position_qty * 0.98
                    )
                    if (
                        is_stop_order and o_side == target_close_side and is_reduce_only
                        and (not order_position_side or order_position_side in ('BOTH', expected_position_side))
                        and quantity_ok
                    ):
                        candidate_sl = o
                        break
                if candidate_sl:
                    c_info = candidate_sl.get('info') or {}
                    new_found_id = str(candidate_sl.get('id') or c_info.get('algoId') or c_info.get('orderId') or '')
                    new_stop_price = float(candidate_sl.get('stopPrice') or c_info.get('triggerPrice') or c_info.get('stopPrice') or 0)
                    if new_found_id and new_stop_price > 0:
                        logger.info(
                            "🔄 [TỰ ĐỒNG BỘ SL SÀN] Phát hiện lệnh SL của %s đã được cập nhật trực tiếp trên Binance: "
                            "ID cũ %s ➡️ ID mới %s (@ %.6g). Tự động đồng bộ và tiếp tục quản lý!",
                            position.get('symbol'), saved_sl_id or '<missing>', new_found_id, new_stop_price
                        )
                        position['sl_order_id'] = new_found_id
                        position['stop_loss'] = new_stop_price
                        stop_verified = True
                        self._save_state()
                elif self.auto_adopt_manual_positions and float(position.get('amount') or 0) > 0:
                    # Nếu lệnh SL trên sàn bị hủy tay hoặc chưa tồn tại trong khi công tắc Auto-Adopt đang BẬT:
                    # Tự động đặt lại lệnh STOP_MARKET bảo hiểm vốn ngay lập tức thay vì khóa chết bot!
                    try:
                        sym_re = position.get('symbol')
                        amt_re = float(position.get('amount') or 0)
                        entry_re = float(position.get('entry_price') or 0)
                        sl_re = float(position.get('stop_loss') or 0)
                        if sl_re <= 0 and entry_re > 0:
                            # [BAI HOC 69] Khôi phục SL theo ĐÚNG khoảng cách đã dùng khi tiếp nhận:
                            # ưu tiên initial_sl_distance_pct, kế đến ATR 15m đã lưu, cuối cùng mới
                            # tới khoá legacy manual_adopt_stop_loss_pct (không còn mặc định 1.5%).
                            risk_cfg_restore = self.config.get('risk') if isinstance(self.config.get('risk'), dict) else {}
                            try:
                                restore_sl_pct = float(risk_cfg_restore.get('manual_adopt_stop_loss_pct', 0.015))
                            except (TypeError, ValueError, OverflowError):
                                restore_sl_pct = 0.015
                            if not math.isfinite(restore_sl_pct) or not 0 < restore_sl_pct < 0.20:
                                restore_sl_pct = 0.015
                            stored_dist = position.get('initial_sl_distance_pct')
                            try:
                                stored_dist = float(stored_dist) if stored_dist is not None else None
                            except (TypeError, ValueError, OverflowError):
                                stored_dist = None
                            if stored_dist is not None and math.isfinite(stored_dist) and 0.005 <= stored_dist <= 0.06:
                                restore_sl_pct = stored_dist
                            else:
                                stored_atr_pct = position.get('atr_pct')
                                try:
                                    stored_atr_pct = float(stored_atr_pct) if stored_atr_pct is not None else None
                                except (TypeError, ValueError, OverflowError):
                                    stored_atr_pct = None
                                if (
                                    bool(risk_cfg_restore.get('unified_sl_from_atr', True))
                                    and stored_atr_pct is not None
                                    and math.isfinite(stored_atr_pct)
                                    and stored_atr_pct > 0
                                ):
                                    try:
                                        restore_mult = float(risk_cfg_restore.get('unified_sl_atr_multiplier', 1.5))
                                    except (TypeError, ValueError, OverflowError):
                                        restore_mult = 1.5
                                    if not math.isfinite(restore_mult) or restore_mult <= 0:
                                        restore_mult = 1.5
                                    restore_sl_pct = min(0.035, max(0.015, restore_mult * stored_atr_pct))
                            sl_re = entry_re * (1.0 - restore_sl_pct if position.get('direction') == 'LONG' else 1.0 + restore_sl_pct)
                        curr_p_re = entry_re
                        try:
                            tk_re = self.exchange.get_ticker(sym_re)
                            raw_p_re = float((tk_re or {}).get('last') or (tk_re or {}).get('close') or 0)
                            if raw_p_re > 0 and math.isfinite(raw_p_re):
                                curr_p_re = raw_p_re
                        except Exception:
                            pass
                        if curr_p_re > 0 and sl_re is not None and sl_re > 0:
                            if position.get('direction') == 'LONG' and sl_re >= curr_p_re * 0.998:
                                sl_re = curr_p_re * 0.9978
                            elif position.get('direction') == 'SHORT' and sl_re <= curr_p_re * 1.002:
                                sl_re = curr_p_re * 1.0022
                        if sl_re > 0:
                            re_sl_order = self.exchange.create_stop_market_order(sym_re, target_close_side, amt_re, sl_re)
                            re_info = (re_sl_order or {}).get('info') or {}
                            re_sl_id = str((re_sl_order or {}).get('id') or re_info.get('algoId') or re_info.get('orderId') or '')
                            if re_sl_id:
                                position['sl_order_id'] = re_sl_id
                                position['stop_loss'] = sl_re
                                stop_verified = True
                                self._save_state()
                                logger.info(
                                    "🛡️ [AUTO-RESTORE SL SÀN] Đã tự động khôi phục lệnh Stop-Loss trên Binance cho %s tại %.6g "
                                    "(cách giá vào %.2f%%, ID: %s)!",
                                    sym_re, sl_re,
                                    (abs(entry_re - sl_re) / entry_re * 100.0) if entry_re > 0 else 0.0,
                                    re_sl_id
                                )
                    except Exception as re_err:
                        logger.error(f"Không thể tự động khôi phục SL cho {position.get('symbol')}: {re_err}")

            if stop_verified:
                position.pop('protection_review_required', None)
                position.pop('protection_review_reason', None)
                position['protection_status'] = 'exchange_stop_verified'
            else:
                position['protection_review_required'] = True
                position['protection_review_reason'] = 'stop_order_missing_or_unverified'
                position['protection_status'] = 'stop_unverified'
                needs_review = True
                logger.critical(
                    'Không xác nhận được SL đang mở trên Binance cho %s %s (SL ID=%s); '
                    'giữ vị thế, khóa lệnh mới và bỏ qua quản lý bằng mức SL cục bộ.',
                    position.get('direction', 'LONG'), position.get('symbol'), key[1] or '<missing>',
                )

            take_profit_id = str(position.get('tp_order_id') or '')
            take_profit_verified = bool(
                take_profit_id
                and (self._clean_symbol(position.get('symbol')), take_profit_id) in open_order_keys
            )
            if take_profit_verified:
                position.pop('take_profit_order_unverified', None)
                position.pop('take_profit_review_alerted', None)
            else:
                position['take_profit_order_unverified'] = True
                if not position.get('take_profit_review_alerted'):
                    logger.warning(
                        'Không xác nhận được TP điều kiện trên Binance cho %s (TP ID=%s). '
                        'Mức chốt lời cục bộ chỉ được theo dõi khi bot đang chạy.',
                        position.get('symbol'), take_profit_id or '<missing>',
                    )
                    position['take_profit_review_alerted'] = True
        return needs_review

    def _cancel_position_protection_orders(self, position: dict, direction: str) -> List[str]:
        """Cancel and verify conditional reduce-only exits for a flat position."""
        symbol = position['symbol']
        known_ids = {
            str(position[key]) for key in ('sl_order_id', 'tp_order_id')
            if position.get(key)
        }
        warnings = []

        # Binance Futures conditional orders use the trigger/algo endpoints in
        # current CCXT. Try that endpoint and fall back to the legacy endpoint.
        for order_id in known_ids:
            for trigger in (True, False):
                try:
                    self.exchange.cancel_order(
                        order_id, symbol, trigger=trigger, strict=True
                    )
                    break
                except Exception:
                    continue

        expected_side = 'sell' if direction == 'LONG' else 'buy'

        def is_protective(order: dict) -> bool:
            info = order.get('info') or {}
            order_id = str(order.get('id') or info.get('algoId') or info.get('orderId') or '')
            if order_id and order_id in known_ids:
                return True
            side = str(order.get('side') or info.get('side') or '').lower()
            position_side = str(info.get('positionSide') or '').upper()
            reduce_only = order.get('reduceOnly') is True or str(info.get('reduceOnly', '')).lower() == 'true'
            close_position = order.get('closePosition') is True or str(info.get('closePosition', '')).lower() == 'true'
            matching_side = not side or side == expected_side
            matching_position = not position_side or position_side in ('BOTH', direction)
            return matching_side and matching_position and (reduce_only or close_position)

        try:
            regular_orders = self.exchange.get_open_orders(symbol, strict=True)
            trigger_orders = self.exchange.get_open_orders(symbol, trigger=True, strict=True)
        except Exception as e:
            return [f'cannot verify protection orders: {e}']

        for orders, is_trigger in ((regular_orders, False), (trigger_orders, True)):
            for order in orders:
                if not is_protective(order):
                    continue
                info = order.get('info') or {}
                order_id = str(order.get('id') or info.get('algoId') or info.get('orderId') or '')
                if not order_id:
                    warnings.append('protective order has no readable ID')
                    continue
                try:
                    self.exchange.cancel_order(
                        order_id, symbol, trigger=is_trigger, strict=True
                    )
                except Exception as e:
                    warnings.append(order_id)
                    logger.error("Could not cancel protective order %s for %s: %s", order_id, symbol, e)

        try:
            remaining_orders = (
                self.exchange.get_open_orders(symbol, strict=True)
                + self.exchange.get_open_orders(symbol, trigger=True, strict=True)
            )
            for order in remaining_orders:
                if is_protective(order):
                    info = order.get('info') or {}
                    warnings.append(str(order.get('id') or info.get('algoId') or 'unknown'))
        except Exception as e:
            warnings.append(f'cannot verify cancellation: {e}')

        return list(dict.fromkeys(warnings))

    def _close_position(self, position: dict, current_price: float, close_reason: str = "Đảo chiều tín hiệu") -> Optional[float]:
        """Close only after the exchange confirms the position is flat."""
        with self._position_lock:
            if not self.is_running and not str(close_reason).startswith('Đóng thủ công'):
                logger.info("Bỏ qua tự động đóng %s vì bot đã dừng.", position.get('symbol'))
                return None
            return self._close_position_locked(position, current_price, close_reason)

    def close_position_manually(self, symbol: str, direction: Optional[str] = None) -> Dict[str, Any]:
        """Close a position from the dashboard and suppress immediate re-entry."""
        symbol = str(symbol or '').strip()
        if not symbol:
            return {'success': False, 'error': 'Thiếu mã giao dịch.'}
        if direction is not None:
            direction = str(direction).upper().strip()
            if direction not in ('LONG', 'SHORT'):
                return {'success': False, 'error': 'Chiều vị thế không hợp lệ.'}

        with self._position_lock:
            if self.mode == 'live' and not self.exchange_connected:
                self._notify_telegram(
                    f"⚠️ Yêu cầu đóng thủ công {symbol} chưa gửi được: Binance đang mất kết nối. "
                    "Hãy kiểm tra và đóng vị thế trực tiếp trên Binance nếu cần."
                )
                return {'success': False, 'error': 'Binance đang mất kết nối; không thể xác nhận lệnh đóng.'}

            if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                if not self.sync_live_positions_with_exchange():
                    self._notify_telegram(
                        f"⚠️ Yêu cầu đóng thủ công {symbol} chưa thực hiện được: "
                        "không đồng bộ được vị thế với Binance. Hãy kiểm tra trực tiếp trên sàn."
                    )
                    return {'success': False, 'error': 'Không đồng bộ được vị thế Binance; chưa gửi lệnh đóng.'}

            matches = [
                p for p in self.open_positions
                if self._clean_symbol(p.get('symbol')) == self._clean_symbol(symbol)
                and (direction is None or p.get('direction', 'LONG') == direction)
            ]
            if not matches:
                self._notify_telegram(
                    f"⚠️ Dashboard nhận yêu cầu đóng {symbol} nhưng tool không còn vị thế tương ứng; "
                    "hãy kiểm tra trạng thái trực tiếp trên Binance."
                )
                return {'success': False, 'error': f'Không tìm thấy vị thế {symbol} đang mở trong tool.'}
            if len(matches) > 1:
                return {'success': False, 'error': f'{symbol} có nhiều vị thế; cần chỉ rõ LONG hoặc SHORT.'}
            position = matches[0]
            symbol = position['symbol']

            ticker = self.exchange.get_ticker(symbol)
            current_price = (ticker or {}).get('last')
            if current_price is None or float(current_price) <= 0:
                self._notify_telegram(
                    f"⚠️ Yêu cầu đóng thủ công {symbol} chưa gửi được: không lấy được giá mới nhất."
                )
                return {'success': False, 'error': f'Không lấy được giá mới nhất của {symbol}; chưa gửi lệnh đóng.'}

            direction = position.get('direction', 'LONG')
            pnl = self._close_position(
                position,
                float(current_price),
                close_reason='Đóng thủ công từ dashboard',
            )
            if pnl is None or position in self.open_positions:
                self._notify_telegram(
                    f"🚨 Tool chưa xác nhận đóng xong vị thế {direction} {symbol}. "
                    "Vị thế được giữ để tiếp tục đối soát; hãy kiểm tra trạng thái và lệnh SL/TP trên Binance."
                )
                return {
                    'success': False,
                    'error': f'Chưa xác nhận đóng hết {symbol}. Hãy kiểm tra Binance trước khi bấm lại.',
                }

            cooldown_minutes = max(
                0, int(self.config.get('trading', {}).get('manual_exit_cooldown_minutes', 30))
            )
            if cooldown_minutes:
                expires_at = time.time() + cooldown_minutes * 60
                cooldown_symbol = self._clean_symbol(symbol)
                self._manual_exit_cooldowns[cooldown_symbol] = expires_at
                self._symbol_cooldowns[cooldown_symbol] = expires_at
                self.db.set_symbol_cooldown(
                    self.mode, cooldown_symbol, expires_at, 'manual_exit'
                )
            self._save_state()
            quote = self.config.get('trading', {}).get('base_currency', 'USDT')
            warning = position.get('_close_warning')
            message = f'Đã xác nhận đóng {direction} {symbol}; PnL ước tính {pnl:+.4f} {quote}.'
            if warning:
                message += ' Cảnh báo: ' + warning + '. Kiểm tra lệnh chờ trên Binance.'
            return {
                'success': True,
                'message': message,
                'symbol': symbol,
                'direction': direction,
                'estimated_pnl': pnl,
                'warning': warning,
            }

    def _close_position_locked(self, position: dict, current_price: float, close_reason: str) -> Optional[float]:
        entry_price = position['entry_price']
        amount = float(position['amount'])
        direction = position.get('direction', 'LONG')
        close_order = {}
        exit_price = float(current_price)
        cleanup_warnings = []

        if self.mode == 'live':
            try:
                is_futures = (
                    position.get('market_type') == 'futures'
                    or getattr(self, 'market_type', 'spot') == 'futures'
                )
                if is_futures:
                    # Never trust a stale local quantity when closing a live position.
                    exchange_positions = self._matching_exchange_positions(
                        position['symbol'], direction
                    )
                    live_amounts = []
                    for live_pos in exchange_positions:
                        raw_amount = abs(float(live_pos.get('contracts') or 0))
                        if raw_amount <= 0:
                            raw_amount = abs(float((live_pos.get('info') or {}).get('positionAmt') or 0))
                        live_amounts.append(abs(float(raw_amount or 0)))
                    live_amount = sum(live_amounts)
                    if live_amount <= 0:
                        logger.warning(
                            "Không gửi lệnh đóng %s: Binance không còn vị thế %s; cần đồng bộ trạng thái.",
                            position['symbol'], direction,
                        )
                        self.sync_live_positions_with_exchange()
                        return None
                    # A full exit must use the exchange's current position size;
                    # a stale smaller local size would leave residual exposure.
                    amount = live_amount
                    close_order = self.exchange.close_futures_position(position['symbol'], direction, amount)
                    if (close_order or {}).get('id') == 'already_closed':
                        logger.info(
                            f"⚡ Vị thế {position['symbol']} ({direction}) đã được sàn Binance đóng trước đó (ReduceOnly -2022). "
                            "Hủy lệnh bảo vệ thừa và chuyển sang đối soát fill sàn."
                        )
                        self._cancel_position_protection_orders(position, direction)
                        if position in self.open_positions:
                            self.open_positions.remove(position)
                        self._handle_externally_closed_position(position)
                        self._save_state()
                        return 0.0
                else:
                    if direction == 'SHORT':
                        raise RuntimeError('Không thể đóng vị thế SHORT trên thị trường spot.')
                    close_order = self.exchange.create_sell_order(
                        position['symbol'], amount, current_price, 'market'
                    )

                # Market order responses may initially be acknowledgements. Poll
                # briefly for a terminal status before changing local state.
                if close_order and close_order.get('id') and str(close_order.get('id')) != 'already_closed':
                    for _ in range(12):
                        status = str(close_order.get('status') or '').lower()
                        if status in ('closed', 'filled', 'canceled', 'cancelled', 'rejected', 'expired'):
                            break
                        latest = self.exchange.get_order_status(
                            close_order['id'], position['symbol']
                        )
                        if latest:
                            close_order = latest
                        else:
                            time.sleep(0.25)

                if is_futures:
                    remaining = self._matching_exchange_positions(position['symbol'], direction)
                    remaining_amount = 0.0
                    for live_pos in remaining:
                        raw_amount = abs(float(live_pos.get('contracts') or 0))
                        if raw_amount <= 0:
                            raw_amount = abs(float((live_pos.get('info') or {}).get('positionAmt') or 0))
                        remaining_amount += abs(float(raw_amount or 0))
                    if remaining_amount > 0:
                        position['amount'] = remaining_amount
                        self._save_state()
                        logger.error(
                            "Lệnh đóng %s chưa làm vị thế về 0 (còn %.8f); giữ vị thế và lệnh bảo vệ.",
                            position['symbol'], remaining_amount,
                        )
                        return None
                else:
                    status = str((close_order or {}).get('status') or '').lower()
                    filled = float((close_order or {}).get('filled') or 0)
                    if not close_order or (status not in ('closed', 'filled') and filled < amount * 0.999999):
                        logger.error("Lệnh đóng spot %s chưa được xác nhận khớp đủ.", position['symbol'])
                        return None

                if close_order:
                    status = str(close_order.get('status') or '').lower()
                    filled = close_order.get('filled')
                    if filled is None and status in ('closed', 'filled'):
                        filled = amount
                    if status in ('canceled', 'cancelled', 'rejected', 'expired') and not is_futures:
                        logger.error("Lệnh đóng %s kết thúc với trạng thái %s.", position['symbol'], status)
                        return None
                    if filled is not None and float(filled) > 0 and float(filled) < amount * 0.999999:
                        if not is_futures:
                            logger.warning(
                                "Binance báo khớp một phần lệnh đóng %s: %.8f/%.8f; cần đối soát.",
                                position['symbol'], float(filled), amount,
                            )
                            return None
                        logger.warning(
                            "Lệnh đóng futures %s báo khớp một phần, nhưng vị thế đã được xác nhận về 0; "
                            "ghi PnL ước tính và đối soát fill sau.",
                            position['symbol'],
                        )

                    average = close_order.get('average') or close_order.get('price')
                    if average:
                        exit_price = float(average)

                # Cancel protections only after confirming flat, without bulk-
                # cancelling unrelated entries on the same market.
                if is_futures:
                    cleanup_warnings.extend(
                        self._cancel_position_protection_orders(position, direction)
                    )
                else:
                    for key in ('sl_order_id', 'tp_order_id'):
                        order_id = position.get(key)
                        if not order_id:
                            continue
                        try:
                            canceled = self.exchange.cancel_order(order_id, position['symbol'])
                            if not canceled:
                                cleanup_warnings.append(str(order_id))
                        except Exception as e:
                            cleanup_warnings.append(str(order_id))
                            logger.error("Không xác nhận được hủy lệnh bảo vệ %s của %s: %s", order_id, position['symbol'], e)
                if cleanup_warnings:
                    position['_close_warning'] = 'Chưa xác nhận hủy lệnh SL/TP: ' + ', '.join(cleanup_warnings)
                    logger.critical(
                        "Đã đóng vị thế %s nhưng chưa xác nhận hủy hết SL/TP: %s",
                        position['symbol'], ', '.join(cleanup_warnings),
                    )
            except Exception as e:
                logger.error(
                    "Không xác nhận được lệnh đóng %s; giữ trạng thái để đối soát: %s",
                    position.get('symbol'), e,
                )
                return None

        if self.mode == 'demo':
            slippage_rate = max(0.0, float(self.config.get('trading', {}).get('slippage_rate', 0.0005)))
            exit_price *= (1 - slippage_rate) if direction == 'LONG' else (1 + slippage_rate)

        # Tính PnL
        if direction == 'LONG':
            pnl = (exit_price - entry_price) * amount
        else:
            pnl = (entry_price - exit_price) * amount
             
        fee_rate = max(0.0, float(self.config.get('trading', {}).get('fee_rate', 0.001)))
        exchange_fee = (close_order or {}).get('fee') or {}
        close_fee = float(exchange_fee.get('cost') or 0) if isinstance(exchange_fee, dict) else 0.0
        if self.mode == 'live' and close_fee <= 0:
            close_fee = exit_price * amount * fee_rate
        entry_fee = float(position.get('entry_fee', 0) or 0)
        fee = close_fee
        net_pnl = pnl - close_fee - entry_fee

        # Binance owns live margin accounting; paper mode updates its local cash.
        if self.mode == 'demo':
            self.balance += position['cost'] + net_pnl
        else:
            if getattr(self, 'market_type', 'spot') == 'futures':
                live_balance = self.exchange.get_futures_balance()
                free_balance = (live_balance or {}).get('free')
            else:
                base_currency = self.config.get('trading', {}).get('base_currency', 'USDT')
                live_balance = self.exchange.get_balance()
                free_balance = (live_balance.get(base_currency) or {}).get('free') if live_balance else None
            if free_balance is not None:
                self.balance = float(free_balance)
        
        # Cập nhật peak balance
        if self.balance > self.peak_balance:
            self.peak_balance = self.balance
        
        # Xóa khỏi open positions
        if position in self.open_positions:
            self.open_positions.remove(position)
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
        # win_loss will be evaluated based on overall_pnl below
        roi = (net_pnl / position['cost']) * 100 if position['cost'] > 0 else 0
        init_cost = float(position.get('initial_cost') or position.get('cost', 1) or 1)
        
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        part_pnl_str = ""
        part_tp_val = float(position.get('partial_tp_pnl', 0.0) or 0.0)
        part_sl_val = float(position.get('partial_sl_pnl', 0.0) or 0.0)
        total_trade_net_pnl = net_pnl + part_tp_val + part_sl_val
        total_roi = (total_trade_net_pnl / init_cost) * 100 if init_cost > 0 else roi
        has_partial = bool(position.get('partial_tp_done') or position.get('partial_sl_done') or abs(part_tp_val) > 1e-6 or abs(part_sl_val) > 1e-6)
        overall_pnl = total_trade_net_pnl if has_partial else net_pnl
        win_loss = "🏆 CHỐT LỜI (WIN)" if overall_pnl > 0 else "🛑 CẮT LỖ (LOSS)" if overall_pnl < 0 else "⚪ HÒA VỐN"
        if position.get('partial_tp_done') or abs(part_tp_val) > 1e-6:
            part_pnl_str += f"🔹 **Lãi chốt 50% trước đó:** `+{part_tp_val:.4f} {quote}`\n"
        if position.get('partial_sl_done') or abs(part_sl_val) > 1e-6:
            part_pnl_str += f"🔹 **Cắt giảm tải trước đó:** `{part_sl_val:.4f} {quote}`\n"
        if has_partial:
            part_pnl_str += f"🔹 **Tổng Net PnL toàn lệnh:** `{total_trade_net_pnl:+.4f} {quote}` ({total_roi:+.2f}% vốn lệnh)\n" 

        last_pnl_label = f"Lợi nhuận phần đóng cuối ({amount:.6g} coin)" if has_partial else "Lợi nhuận ước tính (PnL)"
        last_roi_str = f" ({roi:+.2f}%)" if not has_partial else ""

        msg = (
            f"{win_loss}\n**[{mode_str}] ĐÓNG LỆNH {direction_str}**\n\n"
            f"🔹 **Cặp giao dịch:** {position['symbol']}\n"
            f"🔹 **Giá vào (Entry):** {entry_price:.6f}\n"
            f"🔹 **Giá chốt (Exit):** {exit_price:.6f}\n"
            f"🔹 **{last_pnl_label}:** {net_pnl:+.4f} {quote}{last_roi_str}\n"
            f"{part_pnl_str}"
            f"🔹 **Lý do đóng:** {close_reason}\n"
            f"🔹 **Số dư khả dụng:** {self.balance:.2f} {quote}" + (f" | **Tổng vốn (Equity):** {float(self._futures_account_snapshot.get('wallet_balance')):.2f} {quote}" if self.mode == 'live' and getattr(self, '_futures_account_snapshot', None) and self._futures_account_snapshot.get('wallet_balance') is not None else "")
        )
        if self.mode == 'live':
            msg += "\nℹ️ PnL ước tính từ giá khớp; số quyết toán cuối cùng lấy theo lịch sử fill Binance."
        if cleanup_warnings:
            msg += "\n⚠️ Chưa xác nhận hủy hết lệnh SL/TP: " + ', '.join(cleanup_warnings)
        self._notify_telegram(msg)
            
        # --- Ghi Log Hoạt động Cỗ Máy cho AI Khác Đọc ---
        try:
            log_path = Path(__file__).parent.parent / "ai_knowledge_base.md"
            with open(log_path, "a", encoding="utf-8") as f:
                win_loss = "WIN 🟢" if net_pnl > 0 else ("LOSS 🔴" if net_pnl < 0 else "BREAK-EVEN ⚪")
                f.write(f"### Trade {win_loss} lúc {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"- **Chế độ chạy**: {self.mode.upper()}\n")
                f.write(f"- **Tài sản**: {position['symbol']} (Chiều đánh: {direction})\n")
                f.write(f"- **Đòn bẩy (Leverage)**: {position.get('leverage', 1)}x\n")
                f.write(f"- **Giá vào (Entry)**: {entry_price:.6f}\n")
                f.write(f"- **Giá đóng (Exit)**: {exit_price:.6f}\n")
                f.write(f"- **Tiền lãi/lỗ ước tính (Net PnL)**: {net_pnl:+.4f} {quote}\n")
                f.write(f"- **Chiến thuật áp dụng**: {position.get('strategy', 'N/A')}\n")
                f.write(f"- **Lý do đóng lệnh**: {close_reason}\n")
                f.write(f"- **Vốn sau lệnh này**: {self.balance:.4f} {quote}\n\n")
        except Exception as e:
            logger.error(f"Lỗi ghi log AI: {e}")
        
        # [BÀI HỌC 78, 82 & 85] SMART DUAL-PHASE TRANSITION (PHA 1 -> PHA 2):
        if direction == 'LONG' and total_trade_net_pnl > 0 and (
            position.get('is_momentum_ride')
            or (entry_price > 0 and exit_price >= entry_price * 1.015)
        ):
            sym_clean = self._clean_symbol(position.get('symbol', ''))
            if hasattr(self, '_fading_short_watchlist'):
                self._fading_short_watchlist[sym_clean] = time.time() + 3600.0  # Rình short trong 60 phút
                logger.info(
                    "🎯 [SMART DUAL-PHASE TRANSITION] %s hoàn thành Pha 1 LONG có lãi (Net PnL: %+.4f %s)! "
                    "Đưa vào Ra-đa Rình Short Pha 2 (60 phút) để bắt đỉnh cá mập đón cú sập -5%% đến -8%%!",
                    sym_clean, total_trade_net_pnl, quote
                )

        # Lưu vào database (Ghi đúng net_pnl của phần đóng cuối để khớp 1-1 với order_id trên sàn,
        # vì các phần Partial TP / Partial SL đã được lưu bản ghi riêng ngay lúc khớp)
        self.db.save_trade({
            'symbol': position['symbol'],
            'side': ('buy' if direction == 'SHORT' else 'sell'),
            'type': ('market' if self.mode == 'live' else 'limit'),
            'price': exit_price,
            'amount': amount,
            'cost': exit_price * amount,
            'fee': fee,
            'pnl': net_pnl,
            'strategy': position.get('strategy', 'unknown'),
            'status': 'closed',
            'order_id': str((close_order or {}).get('id') or ((close_order or {}).get('info') or {}).get('orderId') or f"local-close-{int(time.time() * 1000)}"),
            'timestamp': int(time.time() * 1000),
            'mode': self.mode,
            'close_reason': close_reason,
            'raw': {'close_reason': close_reason},
        })
        if position.get('order_id'):
            self.db.update_trade_status(
                str(position['order_id']), 'closed', mode=self.mode, symbol=position['symbol']
            )
        if self.mode == 'live':
            try:
                import threading
                threading.Thread(
                    target=self.sync_live_trades_from_exchange,
                    name='post-close-trade-sync',
                    daemon=True,
                ).start()
            except Exception:
                pass
        
        # Quyết định reinvest hay take profit
        # [SỔ VỐN] Mốc vốn = tiền THẬT đã bơm vào ví Futures (tự dựng từ lịch sử TRANSFER của sàn).
        invested_basis = self._invested_basis()
        total_pnl = self.balance - invested_basis
        action = self.risk_manager.should_take_profit_or_reinvest(
            total_pnl, self.balance
        )
        if total_pnl > 0:
            logger.info(f"💡 Quản lý lợi nhuận: {action} (Tổng PnL: {total_pnl:+.4f} {quote})")
        
        # Cooldown quản trị rủi ro sau khi đóng lệnh (Phân biệt Lệnh Thắng vs Lệnh Thua & Chặn Lỗ Lặp Trên Cùng 1 Mã)
        # Giữ nguyên total_trade_net_pnl = net_pnl + part_tp_val + part_sl_val đã tính ở trên để tính cả phần lỗ giảm tải 50%
        cooldown_sym = self._clean_symbol(position['symbol'])
        if total_trade_net_pnl < 0:
            streak = getattr(self, '_symbol_loss_streaks', {}).get(cooldown_sym, 0) + 1
            self._symbol_loss_streaks[cooldown_sym] = streak
            base_loss_cd = int(
                self.config.get('risk', {}).get('loss_symbol_cooldown_minutes')
                or self.config.get('trading', {}).get('loss_symbol_cooldown_minutes')
                or 180
            )
            eff_cooldown = max(360, base_loss_cd * 2) if streak >= 2 else max(180, base_loss_cd)
            expires = time.time() + (eff_cooldown * 60)
            self._symbol_cooldowns[cooldown_sym] = expires
            self._manual_exit_cooldowns[cooldown_sym] = expires
            self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason=f"loss_streak_{streak}")
            logger.warning(
                f"🛑 [CHẶN VÀO LẠI MÃ ĐANG SUY YẾU] {cooldown_sym} vừa đóng lỗ ({total_trade_net_pnl:+.4f} {quote}, chuỗi lỗ={streak}). "
                f"Khóa giao dịch mã {cooldown_sym} trong {eff_cooldown} phút!"
            )
            loss_cooldown = int(self.config.get('risk', {}).get('post_loss_cooldown_minutes', 0))
            if loss_cooldown > 0:
                self._global_loss_cooldown_until = time.time() + (loss_cooldown * 60)
                logger.warning(f"🛑 [BẢO VỆ TÂM LÝ & TÀI KHOẢN] Vừa cắt lỗ ({net_pnl:+.4f} {quote}). Kích hoạt Global Cooldown {loss_cooldown} phút, bot tạm dừng mở lệnh mới.")
        else:
            self._symbol_loss_streaks[cooldown_sym] = 0
            sym_cooldown = int(self.config.get('risk', {}).get('symbol_cooldown_minutes') or self.config.get('trading', {}).get('symbol_cooldown_minutes', 45))
            if sym_cooldown > 0:
                expires = time.time() + (sym_cooldown * 60)
                self._symbol_cooldowns[cooldown_sym] = expires
                self._manual_exit_cooldowns[cooldown_sym] = expires
                self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason="post_win_cooldown")
                logger.info(f"⏳ Bật symbol cooldown {sym_cooldown} phút cho {cooldown_sym} sau lệnh thắng (tránh FOMO đu đỉnh nhịp cuối).")

        self._save_state()
        return net_pnl



    def _find_triggered_protection_fill(
        self,
        symbol: str,
        candidates: List[tuple],
        close_order_ids: set,
    ) -> Optional[dict]:
        """Nối algoId SL/TP với orderId của fill khi Binance đã kích hoạt conditional order."""
        fetch_algo_order = getattr(self.exchange, 'get_algo_order', None)
        if not callable(fetch_algo_order) or not close_order_ids:
            return None

        close_ids = {str(order_id) for order_id in close_order_ids if order_id is not None and str(order_id)}
        for algo_id, order_kind, direction in candidates:
            algo_key = str(algo_id or '').strip()
            if not algo_key or algo_key in close_ids:
                continue
            try:
                algo_order = fetch_algo_order(symbol, algo_key)
            except Exception as e:
                logger.debug('Không thể nối algoId %s với fill của %s: %s', algo_key, symbol, e)
                continue
            if not isinstance(algo_order, dict) or not algo_order:
                continue

            algo_info = algo_order.get('info') if isinstance(algo_order.get('info'), dict) else {}
            order_data = {**algo_info, **algo_order}
            returned_algo_id = str(order_data.get('algoId') or order_data.get('strategyId') or '').strip()
            if returned_algo_id and returned_algo_id != algo_key:
                continue

            returned_symbol = str(order_data.get('symbol') or '')
            if returned_symbol and self._clean_symbol(returned_symbol) != self._clean_symbol(symbol):
                continue

            expected_side = 'sell' if str(direction).upper() == 'LONG' else 'buy'
            returned_side = str(order_data.get('side') or '').lower()
            if returned_side and returned_side != expected_side:
                continue

            order_type = str(order_data.get('orderType') or order_data.get('type') or '').upper()
            if order_type:
                if order_kind == 'tp' and 'TAKE_PROFIT' not in order_type:
                    continue
                if order_kind == 'sl' and not any(token in order_type for token in ('STOP', 'TRAILING')):
                    continue

            actual_order_id = str(
                order_data.get('actualOrderId')
                or order_data.get('actual_order_id')
                or ''
            ).strip()
            if actual_order_id and actual_order_id in close_ids:
                return {
                    'kind': order_kind,
                    'algo_id': algo_key,
                    'actual_order_id': actual_order_id,
                }
        return None

    def _handle_externally_closed_position(self, position: dict):
        """Xử lý khi vị thế bị đóng trên Binance (khớp SL/TP hoặc đóng tay) mà bot chưa biết."""
        symbol = position.get('symbol')
        direction = position.get('direction', 'LONG')
        entry_price = float(position.get('entry_price', 0))
        amount = float(position.get('amount', 0))
        entry_time = position.get('timestamp', 0)
        
        # Parse ISO string to milliseconds if necessary
        if isinstance(entry_time, str):
            try:
                from datetime import datetime
                entry_time = int(datetime.fromisoformat(entry_time).timestamp() * 1000)
            except Exception:
                entry_time = int(time.time() * 1000) - 86400000 # Fallback 24h
        else:
            entry_time = int(entry_time or (time.time() * 1000 - 86400000))
        
        # 1. Thử lấy giá đóng và PnL từ lịch sử Binance
        exit_price = entry_price
        net_pnl = 0.0
        close_reason = "Đóng ngoài bot trên Binance (chưa xác định nguyên nhân)"
        real_order_id = None
        real_trade_id = None
        close_order_ids = set()
        last_trade = None
        # [BÀI HỌC 67] Kiểm toán TOÀN CHU KỲ: một vị thế có thể bị đóng qua NHIỀU lệnh
        # (Partial SL, Partial TP rồi Hard SL) với nhiều order id khác nhau. Trước đây bot chỉ
        # kiểm toán fill của đúng order id CUỐI CÙNG nên bỏ sót các fill đóng trước đó
        # (SNXX/USDT 30/10/2026: báo cáo Telegram thiếu 0.1656 USDT).
        whole_cycle_net = None
        whole_cycle_volume = 0.0
        whole_cycle_vwap = 0.0
        audit_trusted = False
        audit_close_order_ids = []
        last_order_amount = 0.0

        try:
            ccxt_symbol = self.exchange._get_ccxt_symbol(symbol)
            # Lấy trades từ lúc vào lệnh tới nay
            recent_trades = self.exchange.exchange.fetch_my_trades(ccxt_symbol, since=entry_time, limit=200)
            if recent_trades:
                # Lọc các trade ngược chiều (để đóng)
                close_side = 'sell' if direction == 'LONG' else 'buy'
                close_trades = [t for t in recent_trades if (t.get('side') or '').lower() == close_side]
                if close_trades:
                    # Lấy trade cuối cùng
                    last_trade = close_trades[-1]
                    info = last_trade.get('info', {})
                    real_order_id = last_trade.get('order') or info.get('orderId') or info.get('algoId')
                    real_trade_id = last_trade.get('id') or info.get('id')
                    close_order_ids = {
                        str(value)
                        for value in (
                            last_trade.get('order'), info.get('orderId'), info.get('algoId'),
                            info.get('clientOrderId'), info.get('origClientOrderId'),
                        )
                        if value is not None and str(value)
                    }

                    if real_order_id:
                        order_trades = [
                            t for t in close_trades
                            if str(t.get('order') or t.get('info', {}).get('orderId') or t.get('info', {}).get('algoId') or '')
                            == str(real_order_id)
                        ]
                    else:
                        order_trades = [last_trade]
    
                    total_amt = sum(float(t.get('amount') or 0) for t in order_trades)
                    last_order_amount = total_amt
                    if total_amt > 0:
                        exit_price = sum(float(t.get('price') or t.get('info', {}).get('price') or 0) * float(t.get('amount') or 0) for t in order_trades) / total_amt
                    else:
                        exit_price = float(last_trade.get('price') or info.get('price') or entry_price)
    
                    realized = sum(float(t.get('info', {}).get('realizedPnl', t.get('realizedPnl', 0)) or 0) for t in order_trades)
                    fee = sum(float((t.get('fee') or {}).get('cost', t.get('info', {}).get('commission', 0)) or 0) for t in order_trades)
                    rem_entry_fee = float(position.get('entry_fee', 0.0) or 0.0)
                    # Net PnL must be computed BEFORE classifying the close reason (trừ đủ cả phí đóng lệnh và phần phí mở lệnh còn lại).
                    net_pnl = realized - fee - rem_entry_fee

                    # [BÀI HỌC 67] Tổng hợp TOÀN CHU KỲ trên MỌI fill đóng kể từ lúc mở lệnh.
                    # Nguồn sự thật duy nhất gồm: realizedPnl của sàn - toàn bộ phí đóng - toàn bộ
                    # phí mở lệnh (entry_fee hiện tại chỉ còn phần chưa phân bổ cho khối lượng còn lại).
                    cycle_fills = [t for t in close_trades if float(t.get('amount') or 0) > 0]
                    cycle_close_amt = sum(float(t.get('amount') or 0) for t in cycle_fills)
                    cycle_realized = sum(
                        float(t.get('info', {}).get('realizedPnl', t.get('realizedPnl', 0)) or 0)
                        for t in cycle_fills
                    )
                    cycle_commission = sum(
                        float((t.get('fee') or {}).get('cost', t.get('info', {}).get('commission', 0)) or 0)
                        for t in cycle_fills
                    )
                    cycle_has_realized = any(
                        abs(float(t.get('info', {}).get('realizedPnl', t.get('realizedPnl', 0)) or 0)) > 0
                        for t in cycle_fills
                    )
                    cycle_vwap = (
                        sum(
                            float(t.get('price') or t.get('info', {}).get('price') or 0) * float(t.get('amount') or 0)
                            for t in cycle_fills
                        ) / cycle_close_amt
                        if cycle_close_amt > 0 else exit_price
                    )
                    init_amt_for_fee = float(position.get('initial_amount') or 0)
                    cycle_amt_ref = float(position.get('amount') or amount or 0)
                    entry_fee_total = float(rem_entry_fee or 0.0)
                    if init_amt_for_fee > 0 and cycle_amt_ref > 0 and init_amt_for_fee > cycle_amt_ref * 1.0001:
                        entry_fee_total = entry_fee_total * (init_amt_for_fee / cycle_amt_ref)
                    cycle_ref_amt = init_amt_for_fee if init_amt_for_fee > 0 else cycle_amt_ref
                    if cycle_fills and cycle_ref_amt > 0 and cycle_close_amt > 0:
                        volume_deviation = abs(cycle_close_amt - cycle_ref_amt) / cycle_ref_amt
                        # Chỉ tin kiểm toán toàn chu kỳ khi khối lượng đóng khớp >=75% khối lượng mở
                        # (chống trường hợp cửa sổ `since=entry_time` vô tình vơ cả chu kỳ cũ) và sàn
                        # thực sự trả realizedPnl.
                        if volume_deviation <= 0.25 and cycle_has_realized:
                            whole_cycle_net = cycle_realized - cycle_commission - entry_fee_total
                            whole_cycle_volume = cycle_close_amt
                            whole_cycle_vwap = cycle_vwap
                            audit_trusted = True
                            audit_close_order_ids = sorted({
                                str(value)
                                for t in cycle_fills
                                for value in (
                                    t.get('order'), t.get('info', {}).get('orderId'),
                                    t.get('info', {}).get('algoId'),
                                )
                                if value is not None and str(value)
                            })
                    position['entry_fee'] = 0.0
                    tp_oid = str(position.get('tp_order_id') or '')
                    sl_oid = str(position.get('sl_order_id') or '')
                    stale_sl_oids = [str(x) for x in (position.get('stale_sl_order_ids') or []) if x]
                    target_tp = float(position.get('take_profit') or 0)
                    target_sl = float(position.get('stop_loss') or 0)
                    
                    is_tp_order = bool(tp_oid and tp_oid in close_order_ids)
                    is_sl_order = bool(
                        (sl_oid and sl_oid in close_order_ids)
                        or any(stale_id in close_order_ids for stale_id in stale_sl_oids)
                    )

                    if not is_tp_order and not is_sl_order:
                        protection_candidates = []
                        if sl_oid:
                            protection_candidates.append((sl_oid, 'sl', direction))
                        stale_candidates = [
                            (stale_id, 'sl', direction)
                            for stale_id in stale_sl_oids
                            if stale_id and str(stale_id) != sl_oid
                        ]
                        protection_candidates.extend(stale_candidates[:6])
                        if tp_oid:
                            protection_candidates.append((tp_oid, 'tp', direction))
                        algo_match = self._find_triggered_protection_fill(
                            symbol, protection_candidates[:8], close_order_ids
                        )
                        if algo_match:
                            close_order_ids.add(algo_match['algo_id'])
                            close_order_ids.add(algo_match['actual_order_id'])
                            is_tp_order = algo_match['kind'] == 'tp'
                            is_sl_order = algo_match['kind'] == 'sl'
                            logger.info(
                                '[CLOSE AUDIT LINK] %s %s algoId=%s linked to triggered fill orderId=%s (%s).',
                                symbol, direction, algo_match['algo_id'],
                                algo_match['actual_order_id'], algo_match['kind'],
                            )
                    
                    if is_tp_order:
                        close_reason = "🎯 Binance khớp Take Profit (Đạt mục tiêu chốt lời)"
                    elif is_sl_order:
                        if net_pnl > 0:
                            close_reason = "🛡️ Binance khớp Trailing Stop-Loss (Bảo toàn vốn & Khóa lãi)"
                        else:
                            close_reason = "🛑 Binance khớp Stop Loss (Cắt lỗ bảo vệ vốn)"
                    elif target_tp > 0 and abs(exit_price - target_tp) / target_tp < 0.003:
                        close_reason = "Giá khớp gần TP; ước lượng theo giá vì ID lệnh chưa khớp"
                    elif target_sl > 0 and abs(exit_price - target_sl) / target_sl < 0.003:
                        if net_pnl > 0:
                            close_reason = "Giá khớp gần SL/trailing; ước lượng theo giá vì ID lệnh chưa khớp"
                        else:
                            close_reason = "Giá khớp gần SL; ước lượng theo giá vì ID lệnh chưa khớp"
                    else:
                        close_reason = "Đóng ngoài bot trên Binance (không khớp ID SL/TP; chưa phân loại)"
        except Exception as e:
            logger.warning(f"Không thể lấy lịch sử trade để tính PnL cho {symbol}: {e}")
            # Giữ fallback PnL nhưng không suy đoán SL chỉ từ dấu lãi/lỗ.
            if position.get('real_pnl', 0) < 0:
                net_pnl = float(position.get('real_pnl', 0))
            close_reason = "Đóng ngoài bot trên Binance (không truy xuất được fill để xác định nguyên nhân)"

        logger.info(
            "[CLOSE AUDIT] %s %s close_reason=%s order_id=%s trade_id=%s order_ids=%s exit=%.8g net_pnl=%+.6f "
            "whole_cycle_net=%s trusted=%s cycle_volume=%.8g cycle_vwap=%.8g cycle_order_ids=%s",
            symbol, direction, close_reason, real_order_id, real_trade_id,
            sorted(close_order_ids), exit_price, net_pnl,
            ("%+.6f" % whole_cycle_net) if whole_cycle_net is not None else "n/a",
            audit_trusted, whole_cycle_volume, whole_cycle_vwap, audit_close_order_ids,
        )
            
        # 2. Bật cooldown thông minh (Phân biệt Lệnh Thắng vs Lệnh Thua)
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        cooldown_sym = self._clean_symbol(symbol)
        part_tp_val = float(position.get('partial_tp_pnl', 0.0) or 0.0)
        part_sl_val = float(position.get('partial_sl_pnl', 0.0) or 0.0)
        legacy_total_net_pnl = net_pnl + part_tp_val + part_sl_val
        # [BÀI HỌC 67] Kiểm toán toàn chu kỳ (nếu đáng tin) là nguồn sự thật DUY NHẤT cho tổng PnL
        # của vị thế: nó cộng mọi fill đóng + mọi phí. `net_pnl` (fill cuối) được giữ nguyên để
        # ghi DB 1-1 với real_order_id trên Binance, KHÔNG dùng để tuyên bố tổng lãi/lỗ.
        total_trade_net_pnl = float(whole_cycle_net) if audit_trusted else legacy_total_net_pnl
        if audit_trusted and abs(total_trade_net_pnl - legacy_total_net_pnl) > 0.01:
            logger.warning(
                "[CLOSE AUDIT MISMATCH] %s %s kiểm toán toàn chu kỳ %+.6f vs công thức cũ %+.6f "
                "(lệch %+.6f; %d fill đóng; order_ids=%s). Dùng số kiểm toán toàn chu kỳ.",
                symbol, direction, total_trade_net_pnl, legacy_total_net_pnl,
                total_trade_net_pnl - legacy_total_net_pnl,
                len(audit_close_order_ids), audit_close_order_ids,
            )
        if total_trade_net_pnl < 0:
            streak = getattr(self, '_symbol_loss_streaks', {}).get(cooldown_sym, 0) + 1
            self._symbol_loss_streaks[cooldown_sym] = streak
            base_loss_cd = int(
                self.config.get('risk', {}).get('loss_symbol_cooldown_minutes')
                or self.config.get('trading', {}).get('loss_symbol_cooldown_minutes')
                or self.config.get('trading', {}).get('manual_exit_cooldown_minutes')
                or 180
            )
            eff_cooldown = max(360, base_loss_cd * 2) if streak >= 2 else max(180, base_loss_cd)
            expires = time.time() + (eff_cooldown * 60)
            self._symbol_cooldowns[cooldown_sym] = expires
            self._manual_exit_cooldowns[cooldown_sym] = expires
            self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason=f"loss_streak_{streak}")
            logger.warning(
                f"🛑 [CHẶN VÀO LẠI MÃ ĐANG SUY YẾU] {cooldown_sym} đóng lỗ trên Binance ({total_trade_net_pnl:+.4f} {quote}, chuỗi lỗ={streak}). "
                f"Khóa giao dịch mã {cooldown_sym} trong {eff_cooldown} phút!"
            )
            loss_cooldown = int(self.config.get('risk', {}).get('post_loss_cooldown_minutes', 0))
            if loss_cooldown > 0:
                self._global_loss_cooldown_until = time.time() + (loss_cooldown * 60)
                logger.warning(f"🛑 [BẢO VỆ TÂM LÝ & TÀI KHOẢN] Vừa cắt lỗ trên Binance ({total_trade_net_pnl:+.4f} {quote}). Kích hoạt Global Cooldown {loss_cooldown} phút, bot tạm dừng mở lệnh mới.")
        else:
            self._symbol_loss_streaks[cooldown_sym] = 0
            # [BÀI HỌC 78, 82 & 85] SMART DUAL-PHASE TRANSITION (PHA 1 -> PHA 2 TRONG CHẾ ĐỘ LIVE SYNC):
            if direction == 'LONG' and (
                position.get('is_momentum_ride')
                or (entry_price > 0 and exit_price >= entry_price * 1.015)
            ):
                if hasattr(self, '_fading_short_watchlist'):
                    self._fading_short_watchlist[cooldown_sym] = time.time() + 3600.0
                    logger.info(
                        "🎯 [SMART DUAL-PHASE TRANSITION - SYNC] %s hoàn thành Pha 1 LONG có lãi trên Binance (Net PnL: %+.4f %s)! "
                        "Đưa vào Ra-đa Rình Short Pha 2 (60 phút) để bắt đỉnh cá mập đón cú sập!",
                        cooldown_sym, total_trade_net_pnl, quote
                    )
            sym_cooldown = int(self.config.get('risk', {}).get('symbol_cooldown_minutes') or self.config.get('trading', {}).get('symbol_cooldown_minutes', 45))
            if sym_cooldown > 0:
                expires = time.time() + (sym_cooldown * 60)
                self._symbol_cooldowns[cooldown_sym] = expires
                self._manual_exit_cooldowns[cooldown_sym] = expires
                self.db.set_symbol_cooldown(self.mode, cooldown_sym, expires, reason="post_win_cooldown")
                logger.info(f"⏳ Bật symbol cooldown {sym_cooldown} phút cho {cooldown_sym} sau khi chốt lời trên Binance.")
        
        # 3. Gửi Telegram
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
        # win_loss will be evaluated based on overall_pnl below
        roi = (net_pnl / position.get('cost', 1)) * 100 if position.get('cost', 1) > 0 else 0
        init_cost = float(position.get('initial_cost') or position.get('cost', 1) or 1)
        total_roi = (total_trade_net_pnl / init_cost) * 100 if init_cost > 0 else roi
        has_partial = bool(
            position.get('partial_tp_done') or position.get('partial_sl_done')
            or abs(part_tp_val) > 1e-6 or abs(part_sl_val) > 1e-6
            # [BÀI HỌC 67] Nhiều fill đóng dù bot không chủ động cắt nấc (ví dụ 2 lệnh SL
            # khác order id) vẫn phải hiển thị tổng chu kỳ, không chỉ fill cuối.
            or (audit_trusted and abs(total_trade_net_pnl - net_pnl) > 0.01)
        )
        overall_pnl = total_trade_net_pnl if has_partial else net_pnl
        win_loss = "🏆 CHỐT LỜI (WIN)" if overall_pnl > 0 else "🛑 CẮT LỖ (LOSS)" if overall_pnl < 0 else "⚪ HÒA VỐN"
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        part_pnl_str = ""
        if position.get('partial_tp_done') or abs(part_tp_val) > 1e-6:
            part_pnl_str += f"🔹 **Lãi chốt 50% trước đó:** `+{part_tp_val:.4f} {quote}`\n"
        if position.get('partial_sl_done') or abs(part_sl_val) > 1e-6:
            part_pnl_str += f"🔹 **Cắt giảm tải trước đó:** `{part_sl_val:.4f} {quote}`\n"
        if has_partial:
            part_pnl_str += f"🔹 **Tổng Net PnL toàn lệnh:** `{total_trade_net_pnl:+.4f} {quote}` ({total_roi:+.2f}% vốn lệnh)\n" 
        if audit_trusted and len(audit_close_order_ids) > 1:
            part_pnl_str += (
                f"🔹 **Kiểm toán chu kỳ:** `{len(audit_close_order_ids)} lệnh đóng · "
                f"{whole_cycle_volume:.6g} coin · giá bình quân {whole_cycle_vwap:.6f}`\n"
            )

        display_last_amt = last_order_amount if last_order_amount > 0 else amount
        last_pnl_label = f"Lợi nhuận phần đóng cuối ({display_last_amt:.6g} coin)" if has_partial else "Lợi nhuận ước tính (PnL)"
        last_roi_str = f" ({roi:+.2f}%)" if not has_partial else ""

        msg = (
            f"{win_loss}\n**[{mode_str}] ĐÓNG LỆNH {direction_str} (SYNC)**\n\n"
            f"🔹 **Cặp giao dịch:** {symbol}\n"
            f"🔹 **Giá vào (Entry):** {entry_price:.6f}\n"
            f"🔹 **Giá chốt (Exit):** {exit_price:.6f}\n"
            f"🔹 **{last_pnl_label}:** {net_pnl:+.4f} {quote}{last_roi_str}\n"
            f"{part_pnl_str}"
            f"🔹 **Lý do đóng:** {close_reason}"
        )
        self._notify_telegram(msg)
        
        # 4. Ghi DB (Ghi đúng net_pnl của lệnh đóng cuối để khớp 1-1 với real_order_id trên Binance)
        self.db.save_trade({
            'symbol': symbol,
            'side': ('buy' if direction == 'SHORT' else 'sell'),
            'type': 'market',
            'price': exit_price,
            'amount': amount,
            'cost': exit_price * amount,
            'fee': 0,
            'pnl': net_pnl,
            'strategy': position.get('strategy', 'unknown'),
            'status': 'closed',
            'order_id': real_order_id or f"binance-sync-{int(time.time() * 1000)}",
            'exchange_trade_id': None,
            'timestamp': int(time.time() * 1000),
            'mode': self.mode,
            'close_reason': close_reason,
            'raw': {
                'last_trade': last_trade or {},
                'close_reason': close_reason,
                'close_order_ids': sorted(close_order_ids),
                'real_trade_id': real_trade_id,
                # [BÀI HỌC 67] Lưu lại số kiểm toán toàn chu kỳ để đối soát về sau
                # (cột trades.pnl vẫn là net_pnl của fill cuối, khớp 1-1 với real_order_id).
                'whole_cycle_net': whole_cycle_net,
                'whole_cycle_volume': whole_cycle_volume,
                'whole_cycle_vwap': whole_cycle_vwap,
                'audit_trusted': audit_trusted,
                'cycle_order_ids': audit_close_order_ids,
                'legacy_total_net_pnl': legacy_total_net_pnl,
            },
        })
        # [BÀI HỌC 67] Gắn lý do đóng cho MỌI order id của chu kỳ, không chỉ fill cuối.
        reason_targets = []
        if real_order_id:
            reason_targets.append(str(real_order_id))
        for oid in audit_close_order_ids:
            if oid not in reason_targets:
                reason_targets.append(oid)
        affected_fills = 0
        for oid in reason_targets[:12]:
            try:
                affected_fills += int(self.db.update_trade_close_reason(
                    self.mode, symbol, oid, close_reason,
                ) or 0)
            except Exception as reason_err:
                logger.debug("Không cập nhật được close_reason cho %s order_id=%s: %s", symbol, oid, reason_err)
        if reason_targets:
            logger.info(
                "[CLOSE AUDIT PERSIST] %s close_reason applied to %d stored fill(s) across %d order id(s): %s",
                symbol, affected_fills, min(len(reason_targets), 12), reason_targets[:12],
            )
        if position.get('order_id'):
            self.db.update_trade_status(
                str(position['order_id']), 'closed', mode=self.mode, symbol=position['symbol']
            )
        if self.mode == 'live':
            try:
                import threading
                threading.Thread(
                    target=self.sync_live_trades_from_exchange,
                    name='post-ext-close-trade-sync',
                    daemon=True,
                ).start()
            except Exception:
                pass

    def _check_open_positions(self):
        with self._position_lock:
            return self._check_open_positions_locked()

    def _position_management_loop(self):
        """Manage exchange protection independently from slow market scans/AI."""
        risk = self.config.get('risk', {})
        try:
            interval = int(risk.get('position_monitor_interval_seconds', 10))
        except (TypeError, ValueError, OverflowError):
            interval = 10
        interval = min(60, max(3, interval))

        while self.is_running and not self._position_monitor_stop.is_set():
            try:
                with self._position_lock:
                    has_positions = bool(self.open_positions)
                    has_stalking = bool(getattr(self, 'pending_stalking_orders', None))
                if has_positions or has_stalking:
                    if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                        if not self.sync_live_positions_with_exchange():
                            self._position_monitor_stop.wait(interval)
                            continue
                    self._check_open_positions()
            except Exception as e:
                logger.error("Lỗi luồng quản lý vị thế nhanh: %s", e)
            self._position_monitor_stop.wait(interval)

    def _get_asset_adaptive_trailing_profile(self, symbol: str) -> dict:
        """
        Xác định cấu hình chốt lời & Choke Trailing Stop thích ứng theo từng phân khúc tài sản
        dựa trên kết quả mô phỏng dữ liệu lịch sử chuẩn:
        1. TRADFI_STOCK (Cổ phiếu Mỹ: NVDA, TSLA, AAPL, MSTR, MU...):
           - Sóng nén trong ngày 1.0% - 2.5%, chốt 50% ở +0.70%, Choke ở +1.00%, Gap 1.0%.
        2. TRADFI_LEVERAGED_ETF (ETF Đòn bẩy 3x: SOXL, SOXS, TQQQ...):
           - Sóng gia tốc mạnh 4.0% - 8.0%, cho không gian gồng rộng (+1.20% chốt 50%, Choke ở +2.00%, Gap 1.6%).
        3. TRADFI_COMMODITY (Hàng hóa TradFi: Vàng XAU, Bạc XAG, Dầu CL/BZ, Đồng, Gas...):
           - Biên độ co giãn nén tự nhiên, thanh khoản tổ chức dày, chốt 50% ở +0.95%, Choke ở +1.30%, Gap 0.75%.
        4. CRYPTO_MAJOR (Coin Top: BTC, ETH, SOL, BNB, XRP):
           - Thanh khoản dày, sóng nén đêm 1.1% - 1.5%, chốt 50% ở +0.75%, Choke ở +1.10%, Gap 0.75%.
        5. CRYPTO_PERPETUAL (Altcoins: SUI, NEAR, DOGE, TIA...):
           - Biến động trung bình cao, chốt 50% ở +0.90%, Choke ở +1.50%, Gap 1.3%.
        """
        asset_class = "CRYPTO_PERPETUAL"
        try:
            from ai.quantum_path_simulator import QuantumPathSimulator
            asset_class = QuantumPathSimulator.classify_asset(symbol, getattr(self, 'exchange', None))
        except Exception:
            clean = str(symbol).split(':')[0].upper().replace('/', '')
            if any(clean.startswith(e) for e in ('SOXL', 'SOXS', 'NVDL', 'TSLL', 'TQQQ', 'SQQQ', 'KORU')):
                asset_class = "TRADFI_LEVERAGED_ETF"
            elif any(clean.startswith(c) for c in ('XAU', 'XAG', 'CL', 'BZ', 'COPPER', 'NATGAS', 'OIL', 'GOLD', 'SILVER', 'HG', 'NG', 'PA', 'PL')) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(symbol)):
                asset_class = "TRADFI_COMMODITY"
            elif any(clean.startswith(s) for s in ('NVDA', 'TSLA', 'AAPL', 'MSFT', 'MSTR', 'MU', 'AMD', 'INTC', 'SNDK', 'ON', 'SNXX', 'PLTR', 'COIN', 'AMZN', 'GOOG', 'META', 'NFLX', 'BABA')) or (hasattr(MarketScanner, 'is_tradfi_stock') and MarketScanner.is_tradfi_stock(symbol, getattr(self, 'exchange', None))):
                asset_class = "TRADFI_STOCK"
            elif any(clean.startswith(m) for m in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')):
                asset_class = "CRYPTO_MAJOR"
            else:
                asset_class = "CRYPTO_PERPETUAL"

        # =========================================================================
        # BẢNG THAM SỐ SÀN LỢI NHUẬN BÙ PHÍ SÀN (FEE-COMPENSATED PAYOFF FLOOR)
        # KẾT QUẢ ĐÃ ĐƯỢC MÔ PHỎNG & ĐO LƯỜNG TỐI ƯU TRÊN 274 LỆNH LỊCH SỬ & 8 KỊCH BẢN THỰC NGHIỆM:
        # -------------------------------------------------------------------------
        # [LÝ DO BẮT BUỘC KHÔNG ĐƯỢC PHÉP THAY ĐỔI THAM SỐ NÀY]:
        # Phí Taker Binance Futures 2 đầu là 0.10% (0.05% mở + 0.05% đóng).
        # - Khảo sát thực tế 274 lệnh cũ cho thấy trung vị lệnh thắng chỉ đạt +0.42% (lãi ròng +0.32%),
        #   trong khi trung vị lệnh thua là -1.02% (lỗ ròng -1.12%) -> Payoff chỉ đạt 0.285 (cần Win Rate > 78% mới hòa).
        # - Mô phỏng nến 15m (MFE) chỉ ra: 72.5% lệnh đạt đỉnh >= +1.00%, và 58.9% chạm >= +1.35%.
        # - Kịch bản tối ưu nhất thực tế là TP1 = +1.20% ~ +1.35% và Trailing kích hoạt tại +0.95%:
        #   Profit Factor đạt ĐỈNH CỰC ĐẠI: 2.61, Win Rate giữ vững 65.6%, Payoff nhảy vọt lên 1.37!
        # - CẢNH BÁO: KHÔNG ĐƯỢC nâng TP1 >= 1.75% vì thực nghiệm chứng minh Win Rate sẽ rớt từ 65.6% xuống 57.8%!
        #   KHÔNG ĐƯỢC hạ TP1 <= 0.85% vì phí sàn sẽ bào mòn lợi nhuận và PF chỉ đạt 2.32!
        # =========================================================================
        if asset_class == "TRADFI_STOCK":
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0075,
                "partial_tp_trigger": 0.0110,
                "partial_tp_min": 0.0090,
                "partial_tp_max": 0.0140,
                "choke_trigger": 0.0140,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0080,
                "min_distance_pct": 0.008,
            }
        elif asset_class == "TRADFI_LEVERAGED_ETF":
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0085,
                "partial_tp_trigger": 0.0140,
                "partial_tp_min": 0.0110,
                "partial_tp_max": 0.0170,
                "choke_trigger": 0.0200,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0120,
                "min_distance_pct": 0.012,
            }
        elif asset_class == "TRADFI_COMMODITY":
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0070,
                "partial_tp_trigger": 0.0095,
                "partial_tp_min": 0.0080,
                "partial_tp_max": 0.0125,
                "choke_trigger": 0.0130,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0075,
                "min_distance_pct": 0.0075,
            }
        elif asset_class == "CRYPTO_MAJOR":
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0075,
                "partial_tp_trigger": 0.0095,
                "partial_tp_min": 0.0085,
                "partial_tp_max": 0.0115,
                "choke_trigger": 0.0120,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0075,
                "min_distance_pct": 0.007,
            }
        else: # CRYPTO_PERPETUAL (Altcoins) - VÙNG GIAO THOA VÀNG ĐẠT PF 2.61
            return {
                "asset_class": asset_class,
                "breakeven_trigger": 0.0080,
                "partial_tp_trigger": 0.0125,
                "partial_tp_min": 0.0110,
                "partial_tp_max": 0.0150,
                "choke_trigger": 0.0180,
                "choke_ratio": 0.70,
                "trailing_gap": 0.0090,
                "min_distance_pct": 0.009,
            }

    def _entry_atr_pct(self, signal) -> tuple:
        """[P3] ATR 15m đã đóng, dùng CHUNG nguồn với thang giảm tải/trailing.

        Trước đây khoảng cách SL khi vào lệnh lấy từ ATR của chính chiến thuật (mỗi chiến
        thuật tự tính ATR trên khung nó chạy), còn thang de-risk lại dùng ATR 15m của
        ``_adaptive_trailing_metrics``. Hai nguồn lệch nhau nên SL ban đầu rộng hơn 1.0 ATR
        của thang de-risk (GTC/USDT: 2.613% so với 2.394%), khiến nấc siết SL chỉ đạt
        0.219% và nấc cắt thứ 2 nằm sát SL gần như không bao giờ kích hoạt độc lập.

        Trả về ``(atr_pct, adx)``; ``(None, None)`` khi không đo được hoặc bị tắt cấu hình.
        """
        risk_cfg = self.config.get('risk') if isinstance(self.config.get('risk'), dict) else {}
        if not bool(risk_cfg.get('unified_sl_from_atr', True)):
            return None, None
        symbol = str(getattr(signal, 'symbol', '') or '')
        if not symbol:
            return None, None
        try:
            price = float(getattr(signal, 'price', 0.0) or 0.0)
        except (TypeError, ValueError, OverflowError):
            price = 0.0
        if not math.isfinite(price) or price <= 0:
            return None, None
        raw_side = getattr(getattr(signal, 'signal', None), 'value', getattr(signal, 'signal', ''))
        direction = 'SHORT' if str(raw_side).upper() == 'SELL' else 'LONG'
        try:
            metrics = self._adaptive_trailing_metrics(
                {'symbol': symbol, 'direction': direction}, price
            )
        except Exception as exc:
            logger.debug(f"[P3] Không đo được ATR 15m hợp nhất cho {symbol}: {exc}")
            return None, None
        try:
            atr_pct_val = float(metrics.get('atr_pct') or 0.0)
        except (TypeError, ValueError, OverflowError):
            atr_pct_val = 0.0
        if not math.isfinite(atr_pct_val) or atr_pct_val <= 0:
            return None, metrics.get('adx')
        return atr_pct_val, metrics.get('adx')

    def _adaptive_trailing_metrics(self, position: dict, current_price: float) -> dict:
        """Build a bounded ATR/ADX trailing distance from closed candles."""
        symbol = str(position.get('symbol') or '')
        profile = self._get_asset_adaptive_trailing_profile(symbol)
        risk = self.config.get('risk', {})
        try:
            period = int(risk.get('trailing_atr_period', 14))
        except (TypeError, ValueError, OverflowError):
            period = 14
        period = min(50, max(5, period))
        timeframe = str(risk.get('trailing_atr_timeframe', '15m'))
        try:
            cache_ttl = float(risk.get('trailing_atr_refresh_seconds', 60))
        except (TypeError, ValueError, OverflowError):
            cache_ttl = 60.0
        cache_ttl = min(600.0, max(5.0, cache_ttl))

        try:
            min_pct = float(profile.get('min_distance_pct', risk.get('trailing_min_distance_pct', 0.005)))
            max_pct = float(risk.get('trailing_max_distance_pct', 0.04))
            base_fallback_pct = float(profile.get('trailing_gap', risk.get('trailing_stop_pct', 0.015)))
            base_multiplier = float(risk.get('trailing_atr_multiplier', 2.0))
            trend_threshold = float(risk.get('trailing_trend_adx_threshold', 25.0))
            favorable_multiplier = float(risk.get('trailing_favorable_trend_multiplier', 1.15))
            adverse_multiplier = float(risk.get('trailing_adverse_trend_multiplier', 0.85))
            min_step_pct = float(risk.get('trailing_min_step_pct', 0.001))
        except (TypeError, ValueError, OverflowError):
            min_pct = profile.get('min_distance_pct', 0.005)
            max_pct = 0.04
            base_fallback_pct = profile.get('trailing_gap', 0.015)
            base_multiplier, trend_threshold = 2.0, 25.0
            favorable_multiplier, adverse_multiplier = 1.15, 0.85
            min_step_pct = 0.001

        min_pct = min(0.20, max(0.001, min_pct))
        max_pct = min(0.20, max(min_pct, max_pct))
        base_fallback_pct = min(max_pct, max(min_pct, base_fallback_pct))
        base_multiplier = min(5.0, max(0.25, base_multiplier))
        favorable_multiplier = min(2.0, max(1.0, favorable_multiplier))
        adverse_multiplier = min(1.0, max(0.5, adverse_multiplier))
        min_step_pct = min(0.05, max(0.0, min_step_pct))

        cache = self._trailing_market_cache.get(symbol)
        now = time.monotonic()
        if cache and cache.get('error') and now - cache.get('time', 0.0) < cache_ttl:
            previous = position.get('trailing_distance_pct')
            try:
                fallback = float(previous) if previous is not None else base_fallback_pct
            except (TypeError, ValueError, OverflowError):
                fallback = base_fallback_pct
            return {
                'distance_pct': min(max_pct, max(min_pct, fallback)),
                'atr_pct': None,
                'adx': None,
                'regime': 'fallback',
                'min_step_pct': min_step_pct,
                'ema20': None,
                'rvol': 1.0,
                'profile': profile,
            }
        if not cache or now - cache.get('time', 0.0) >= cache_ttl:
            try:
                import ta
                candles = self.exchange.get_ohlcv(
                    symbol, timeframe, limit=max(60, period * 3 + 2)
                )
                if candles is None or len(candles) < period * 2 + 2:
                    raise ValueError("Không đủ nến đóng để tính ATR/ADX")

                # Ignore the still-forming candle so the volatility estimate does
                # not jump around while its OHLC values are incomplete.
                closed = candles.iloc[:-1]
                atr_values = ta.volatility.AverageTrueRange(
                    closed['high'], closed['low'], closed['close'], window=period
                ).average_true_range()
                adx_indicator = ta.trend.ADXIndicator(
                    closed['high'], closed['low'], closed['close'], window=period
                )
                adx_values = adx_indicator.adx()
                plus_values = adx_indicator.adx_pos()
                minus_values = adx_indicator.adx_neg()
                ema20_indicator = ta.trend.EMAIndicator(closed['close'], window=20)
                ema20_values = ema20_indicator.ema_indicator()

                atr_value = float(atr_values.iloc[-1])
                adx_value = float(adx_values.iloc[-1])
                plus_value = float(plus_values.iloc[-1])
                minus_value = float(minus_values.iloc[-1])
                ema20_value = float(ema20_values.iloc[-1]) if not ema20_values.empty else None
                avg_vol_20 = float(closed['volume'].tail(20).mean()) if ('volume' in closed.columns and len(closed) >= 20) else 1.0
                latest_vol = float(closed['volume'].iloc[-1]) if ('volume' in closed.columns and not closed.empty) else 1.0
                rvol_value = float(latest_vol / avg_vol_20) if avg_vol_20 > 0 else 1.0
                closed_open = float(closed['open'].iloc[-1]) if not closed.empty else 0.0
                closed_close = float(closed['close'].iloc[-1]) if not closed.empty else 0.0
                curr_candle = candles.iloc[-1] if not candles.empty else None
                curr_vol = float(curr_candle['volume']) if (curr_candle is not None and 'volume' in candles.columns) else 0.0
                curr_rvol = float(curr_vol / avg_vol_20) if avg_vol_20 > 0 else 0.0
                curr_open = float(curr_candle['open']) if curr_candle is not None else 0.0
                curr_close = float(curr_candle['close']) if curr_candle is not None else 0.0
                closed_open_ts = None
                current_open_ts = None
                try:
                    if not closed.empty:
                        closed_open_ts = float(closed.index[-1].value) / 1_000_000_000.0
                    if not candles.empty:
                        current_open_ts = float(candles.index[-1].value) / 1_000_000_000.0
                except (AttributeError, TypeError, ValueError, OverflowError):
                    pass
                if not all(math.isfinite(v) for v in (atr_value, adx_value, plus_value, minus_value)) or atr_value <= 0:
                    raise ValueError("ATR/ADX không hợp lệ")

                cache = {
                    'time': now,
                    'atr': atr_value,
                    'adx': adx_value,
                    'di_plus': plus_value,
                    'di_minus': minus_value,
                    'ema20': ema20_value,
                    'rvol': rvol_value,
                    'curr_rvol': curr_rvol,
                    'closed_open_ts': closed_open_ts,
                    'current_open_ts': current_open_ts,
                    'closed_bearish': closed_close < closed_open,
                    'closed_bullish': closed_close > closed_open,
                    'curr_bearish': curr_close < curr_open,
                    'curr_bullish': curr_close > curr_open,
                }
                self._trailing_market_cache[symbol] = cache
            except Exception as e:
                self._trailing_market_cache[symbol] = {'time': now, 'error': str(e)}
                logger.warning(
                    "Không tính được ATR/ADX cho trailing %s; dùng khoảng dự phòng: %s",
                    symbol, e,
                )
                previous = position.get('trailing_distance_pct')
                try:
                    fallback = float(previous) if previous is not None else base_fallback_pct
                except (TypeError, ValueError, OverflowError):
                    fallback = base_fallback_pct
                fallback = min(max_pct, max(min_pct, fallback))
                return {
                    'distance_pct': fallback,
                    'atr_pct': None,
                    'adx': None,
                    'regime': 'fallback',
                    'min_step_pct': min_step_pct,
                    'ema20': None,
                    'rvol': 1.0,
                    'profile': profile,
                }

        price = float(current_price)
        if not math.isfinite(price) or price <= 0:
            return {
                'distance_pct': base_fallback_pct,
                'atr_pct': None,
                'adx': None,
                'regime': 'fallback',
                'min_step_pct': min_step_pct,
                'ema20': None,
                'rvol': 1.0,
                'profile': profile,
            }

        direction = position.get('direction', 'LONG')
        favorable = (
            cache['di_plus'] > cache['di_minus']
            if direction == 'LONG'
            else cache['di_minus'] > cache['di_plus']
        )
        adverse = not favorable
        multiplier = base_multiplier
        regime = 'ranging'
        if cache['adx'] >= trend_threshold and favorable:
            multiplier *= favorable_multiplier
            regime = 'trend_favorable'
        elif cache['adx'] >= trend_threshold and adverse:
            multiplier *= adverse_multiplier
            regime = 'trend_adverse'

        atr_pct = cache['atr'] / price
        distance_pct = min(max_pct, max(min_pct, atr_pct * multiplier))

        # Chỉ dùng volume từ nến bắt đầu sau thời điểm mở vị thế. Volume tích lũy
        # trước entry trong nến đang chạy không được xem là lực xả sau entry.
        entry_epoch = None
        try:
            raw_entry_ts = position.get('timestamp')
            if isinstance(raw_entry_ts, (int, float)):
                entry_epoch = float(raw_entry_ts) / 1000.0 if float(raw_entry_ts) > 1e11 else float(raw_entry_ts)
            elif raw_entry_ts:
                entry_epoch = datetime.fromisoformat(str(raw_entry_ts)).timestamp()
        except (TypeError, ValueError, OverflowError, OSError):
            entry_epoch = None

        now_ts = time.time()
        held_secs = (now_ts - entry_epoch) if entry_epoch is not None else 0.0
        # [BÀI HỌC 93 - MỞ MẮT RVOL 15-30M ĐẦU CHO MODE 7 TELEMETRY GATE]:
        # Trước đây so current_open_ts >= entry_epoch làm 100% vị thế trong 15-30 phút đầu bị coi là
        # current_is_post_entry = False -> adverse_rvol mặc định = 1.0 -> Mode 7 bị mù hoàn toàn trước bão xả cá mập.
        # Nay: Nếu lệnh đã giữ >= 60 giây và nến đang chạy giật ngược entry_price, volume nến này chính là lực xả/bơm thật!
        entry_p_chk = float(position.get('entry_price') or price)
        curr_is_adverse_move = (price < entry_p_chk) if direction == 'LONG' else (price > entry_p_chk)
        is_held_1m = (entry_epoch is not None) and (held_secs >= 60.0)

        current_is_post_entry = (
            (is_held_1m and curr_is_adverse_move)
            or (
                entry_epoch is not None
                and cache.get('current_open_ts') is not None
                and float(cache['current_open_ts']) >= entry_epoch
            )
        )
        closed_is_post_entry = (
            entry_epoch is not None
            and (
                held_secs >= 900.0
                or (cache.get('closed_open_ts') is not None and float(cache['closed_open_ts']) >= (entry_epoch - 60.0))
            )
        )
        curr_rv = float(cache.get('curr_rvol', 0.0) or 0.0)
        closed_rv = float(cache.get('rvol', 1.0) or 1.0)
        adverse_rvol_values = []
        if direction == 'LONG':
            if current_is_post_entry:
                adverse_rvol_values.append(curr_rv if cache.get('curr_bearish', False) else curr_rv * 0.5)
            if closed_is_post_entry and cache.get('closed_bearish', False):
                adverse_rvol_values.append(closed_rv)
        else:
            if current_is_post_entry:
                adverse_rvol_values.append(curr_rv if cache.get('curr_bullish', False) else curr_rv * 0.5)
            if closed_is_post_entry and cache.get('closed_bullish', False):
                adverse_rvol_values.append(closed_rv)
        adverse_rvol = max(adverse_rvol_values) if adverse_rvol_values else 1.0

        return {
            'distance_pct': distance_pct,
            'atr_pct': atr_pct,
            'adx': cache['adx'],
            'regime': regime,
            'min_step_pct': min_step_pct,
            'ema20': cache.get('ema20'),
            'rvol': adverse_rvol,
            'raw_closed_rvol': closed_rv,
            'profile': profile,
        }

    def _trailing_net_breakeven(self, position: dict) -> float:
        """Estimate a fee-aware exit price, with a configurable cost reserve."""
        risk = self.config.get('risk', {})
        trading = self.config.get('trading', {})
        entry = float(position.get('entry_price') or 0)
        amount = abs(float(position.get('amount') or 0))
        if entry <= 0 or amount <= 0:
            return entry

        try:
            configured_fee = float(trading.get('fee_rate', 0.001))
            extra_cost = float(risk.get('trailing_cost_buffer_pct', 0.001))
        except (TypeError, ValueError, OverflowError):
            configured_fee, extra_cost = 0.001, 0.001
        configured_fee = min(0.05, max(0.0, configured_fee))
        extra_cost = min(0.05, max(0.0, extra_cost))

        entry_fee = max(0.0, float(position.get('entry_fee') or 0))
        observed_entry_fee_rate = entry_fee / (entry * amount)
        entry_fee_rate = observed_entry_fee_rate if observed_entry_fee_rate > 0 else configured_fee
        exit_cost_rate = min(0.20, configured_fee + extra_cost)

        if position.get('direction', 'LONG') == 'LONG':
            denominator = max(0.50, 1.0 - exit_cost_rate)
            return entry * (1.0 + entry_fee_rate) / denominator
        return entry * (1.0 - entry_fee_rate) / (1.0 + exit_cost_rate)

    def _is_manual_position(self, position: dict) -> bool:
        """[BAI HOC 68] Vị thế do NGƯỜI DÙNG tự mở bằng tay trên Binance và được bot tiếp nhận.

        Với loại vị thế này, bot CHỈ được phép HỖ TRỢ bảo vệ (Stop-Loss sàn, Take-Profit,
        Trailing Stop, cảnh báo), TUYỆT ĐỐI KHÔNG được tự ý đóng vị thế theo phán đoán
        riêng (AI đảo chiều, Telemetry Gate xả khẩn cấp, cắt giảm tải từng phần, cắt theo
        thời gian, khiên cuối tuần). Quyền quyết định thoát lệnh thuộc về người dùng.
        """
        if not isinstance(position, dict):
            return False
        strat = str(position.get('strategy') or '').strip().lower()
        if strat in ('manual_adopted', 'manual'):
            return True
        if bool(position.get('manual_adopted')) or bool(position.get('is_manual_position')):
            return True
        oid = str(position.get('order_id') or '').lower()
        if oid.startswith('manual-adopted-') or oid.startswith('manual-'):
            return True
        return False

    def _calc_adaptive_stages(self, position: dict, current_price: float) -> int:
        """
        DYNAMIC ADAPTIVE STAGING ENGINE:
        Tự động xác định số nấc tối ưu (1 đến 5 nấc) cho vị thế dựa trên Notional,
        đảm bảo 100% không bao giờ gặp lỗi sàn Binance MIN_NOTIONAL (-4164).
        """
        init_amt = float(position.get('initial_amount') or position.get('amount') or 0)
        entry_p = float(position.get('entry_price') or current_price or 0)
        base_p = entry_p if entry_p > 0 else current_price
        pos_notional = init_amt * base_p
        # [BÀI HỌC 91 & BÀI HỌC 14]: Chuẩn hóa quy mô nấc giảm tải (2 Nấc Tối Ưu Cho Notional < 30 USDT)
        # Với tài khoản vốn ~100 USDT (Notional ~15-25 USDT), chia 2 nấc chuẩn (50% Nấc 1 + 50% Nấc 2 đón nhịp rút râu 44.3%)
        # tránh phân mảnh thành 3 nấc 5 USDT gây chịu 3 lần phí Taker và vướng trần MIN_NOTIONAL 5.00 USDT của Binance.
        if pos_notional < 9.80:
            return 1
        elif pos_notional < 30.0:
            return 2
        elif pos_notional < 45.0:
            return 3
        else:
            return min(5, int(pos_notional // 10.0))

    @staticmethod
    def _conditional_order_id(order: dict) -> str:
        info = order.get('info') or {}
        order_id = order.get('id') or info.get('algoId') or info.get('orderId')
        return str(order_id or '')

    def _retry_pending_protection_cleanup(self, position: dict, direction: str) -> List[str]:
        """Cancel and verify only this flat position's saved protective exits."""
        symbol = position.get('symbol')
        if not symbol:
            return ['missing symbol']

        known_ids = {
            str(position[key]) for key in ('sl_order_id', 'tp_order_id')
            if position.get(key)
        }
        known_ids.update(
            str(order_id) for order_id in position.get('stale_sl_order_ids', [])
            if order_id
        )

        if not known_ids:
            # Legacy/recovered positions may lack saved order IDs. The existing
            # matcher is restricted to reduce-only/close-position exits on the
            # same symbol and direction; never bulk-cancel entries.
            return self._cancel_position_protection_orders(position, direction)

        try:
            regular = self.exchange.get_open_orders(symbol, strict=True)
            trigger = self.exchange.get_open_orders(symbol, trigger=True, strict=True)
        except Exception as e:
            return [f'cannot verify open orders: {e}']

        for orders, is_trigger in ((regular, False), (trigger, True)):
            for order in orders:
                order_id = self._conditional_order_id(order)
                if order_id not in known_ids:
                    continue
                try:
                    self.exchange.cancel_order(
                        order_id, symbol, trigger=is_trigger, strict=True
                    )
                except Exception:
                    # The order may have triggered/canceled between reads.
                    # Verify below before deciding whether cleanup is pending.
                    pass

        try:
            remaining = (
                self.exchange.get_open_orders(symbol, strict=True)
                + self.exchange.get_open_orders(symbol, trigger=True, strict=True)
            )
        except Exception as e:
            return [f'cannot verify cancellation: {e}']

        remaining_ids = {
            self._conditional_order_id(order) for order in remaining
        }
        return sorted(known_ids & remaining_ids)

    def _retry_stale_trailing_stop_cancellations(self, position: dict) -> None:
        """Retry cleanup of old conditional stops without losing the active stop."""
        pending_ids = list(dict.fromkeys(
            str(order_id) for order_id in position.get('stale_sl_order_ids', [])
            if order_id
        ))
        if not pending_ids:
            return

        symbol = position['symbol']
        try:
            open_orders = self.exchange.get_open_orders(
                symbol, trigger=True, strict=True
            )
        except Exception as e:
            logger.error(
                "Không xác minh được các trailing stop cũ của %s; giữ nguyên danh sách để thử lại: %s",
                symbol, e,
            )
            return

        open_ids = {self._conditional_order_id(order) for order in open_orders}
        for order_id in pending_ids:
            if order_id not in open_ids:
                continue
            try:
                self.exchange.cancel_order(
                    order_id, symbol, trigger=True, strict=True
                )
            except Exception as e:
                logger.warning(
                    "Chưa hủy được trailing stop cũ %s của %s; sẽ thử lại chu kỳ sau: %s",
                    order_id, symbol, e,
                )

        try:
            remaining_orders = self.exchange.get_open_orders(
                symbol, trigger=True, strict=True
            )
            remaining_ids = {
                self._conditional_order_id(order) for order in remaining_orders
            }
            position['stale_sl_order_ids'] = [
                order_id for order_id in pending_ids if order_id in remaining_ids
            ]
        except Exception as e:
            # Keep every ID pending unless Binance confirms it is no longer open.
            position['stale_sl_order_ids'] = pending_ids
            logger.error(
                "Không xác minh được kết quả dọn trailing stop của %s; sẽ thử lại: %s",
                symbol, e,
            )


    def _check_pending_stalking_orders_locked(self):
        """
        Kiểm tra và quản lý các lệnh bắn tỉa rình mồi M1 (Sniper Retest Stalking).
        1. Nếu sàn báo lệnh Limit đã khớp: kích hoạt vị thế mở, đặt Stop-Loss và Take-Profit trên Binance.
        2. Nếu giá xả gãy thủng ngưỡng an toàn (> -0.80%): HỦY LỆNH NGAY để bảo vệ 100% vốn trước cú sập bẫy.
        3. Nếu quá thời gian chờ (15 phút) hoặc giá phóng vọt bay thẳng (> +1.50%): Hủy lệnh an toàn.
        """
        if not self.is_running or not getattr(self, 'pending_stalking_orders', None):
            return

        now = time.time()
        for symbol, stalking in list(self.pending_stalking_orders.items()):
            order_id = str(stalking.get('order_id') or '')
            side = stalking.get('side', 'buy')
            direction = stalking.get('direction', 'LONG')
            signal_price = float(stalking.get('signal_price') or 0.0)
            target_price = float(stalking.get('target_price') or 0.0)
            invalid_price = float(stalking.get('invalid_price') or 0.0)
            created_at = float(stalking.get('created_at') or now)
            timeout_sec = float(stalking.get('timeout_seconds') or 900.0)

            # Lấy giá thị trường hiện tại
            current_price = signal_price
            try:
                ticker = self.exchange.get_ticker(symbol)
                if ticker:
                    current_price = float(ticker.get('last') or ticker.get('close') or signal_price)
            except Exception:
                pass

            is_filled = False
            is_cancelled = False

            if self.mode == 'live' and order_id and getattr(self, 'market_type', 'spot') == 'futures':
                try:
                    order_status_info = self.exchange.get_order_status(order_id, symbol)
                    order_status = str((order_status_info or {}).get('status') or '').lower()
                    filled_qty = float((order_status_info or {}).get('filled') or 0.0)
                    fee_meta = (order_status_info or {}).get('fee') or {}
                    try:
                        actual_entry_fee = abs(float(fee_meta.get('cost') or 0.0))
                        if actual_entry_fee > 0:
                            stalking['entry_fee'] = actual_entry_fee
                    except (TypeError, ValueError):
                        pass
                    if order_status in ('closed', 'filled'):
                        is_filled = True
                        target_price = float(order_status_info.get('average') or order_status_info.get('price') or target_price)
                        if filled_qty > 0:
                            stalking['amount'] = filled_qty
                    elif order_status in ('canceled', 'cancelled', 'rejected', 'expired'):
                        if filled_qty > 0:
                            is_filled = True
                            target_price = float(order_status_info.get('average') or order_status_info.get('price') or target_price)
                            stalking['amount'] = filled_qty
                        else:
                            is_cancelled = True
                    elif filled_qty > 0:
                        # [SỬA LỖI GỐC RỄ - KHỚP MỘT PHẦN] Trước đây lệnh Limit Maker khớp một phần
                        # (status vẫn 'open'/'partially_filled') bị coi như chưa khớp: bot không đặt
                        # SL/TP cho phần đã khớp, và nếu giá quay đầu thì phần vốn đó phơi nhiễm hoàn
                        # toàn không bảo vệ. Nay phần đã khớp được kích hoạt ngay sau khi hủy phần dư.
                        logger.warning(
                            f"⚠️ [M1 KHỚP MỘT PHẦN] {symbol} ({direction}): Đã khớp {filled_qty} "
                            f"nhưng phần dư vẫn treo. Hủy phần dư để bảo vệ phần vốn đã vào lệnh."
                        )
                        stalking['partial_filled_qty'] = filled_qty
                        if self._cancel_stalking_order(symbol, stalking, order_id, now):
                            is_filled = True
                            target_price = float(
                                order_status_info.get('average')
                                or order_status_info.get('price')
                                or target_price
                            )
                            stalking['amount'] = filled_qty
                        else:
                            logger.warning(
                                "Chưa xác nhận hủy phần dư %s; giữ lệnh trong danh sách theo dõi, không kích hoạt sớm.",
                                symbol,
                            )
                except Exception as e:
                    logger.debug(f"Chưa lấy được trạng thái lệnh rình mồi {symbol}: {e}")
            elif self.mode == 'demo':
                if direction == 'LONG':
                    if current_price <= target_price and current_price > invalid_price:
                        is_filled = True
                    elif current_price <= invalid_price:
                        is_cancelled = True
                else:
                    if current_price >= target_price and current_price < invalid_price:
                        is_filled = True
                    elif current_price >= invalid_price:
                        is_cancelled = True

            # Kịch bản 1: LỆNH ĐÃ KHỚP ĐÁY RETEST THÀNH CÔNG!
            if is_filled:
                logger.info(f"🎯 [BẮN TỈA M1 KHỚP ĐÁY RETEST] {symbol} ({direction}): Đã khớp lệnh tại {target_price:.6g}! Đang kích hoạt vị thế...")
                self._activate_stalking_position(stalking, target_price)
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                continue

            if is_cancelled:
                logger.info(f"Lệnh rình mồi M1 của {symbol} đã bị hủy trên sàn.")
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                try:
                    from core.gate_telemetry import clear_radar_candidate
                    clear_radar_candidate(symbol)
                except Exception:
                    pass
                continue

            # Kịch bản 2: BẢO VỆ XẢ GÃY THỦNG NGƯỠNG AN TOÀN (> -0.80%)
            is_dumping = False
            if direction == 'LONG' and current_price <= invalid_price:
                is_dumping = True
            elif direction == 'SHORT' and current_price >= invalid_price:
                is_dumping = True

            if is_dumping:
                logger.warning(
                    f"🛡️ [M1 BẢO VỆ XẢ GÃY - HỦY LỆNH ĐÓN LÕNG] {symbol} ({direction}): "
                    f"Giá thị trường ({current_price:.6g}) đã xả gãy thủng ngưỡng an toàn ({invalid_price:.6g})! "
                    f"HỦY LỆNH CHỜ NGAY LẬP TỨC ĐỂ BẢO VỆ 100% VỐN!"
                )
                if not self._cancel_stalking_order(symbol, stalking, order_id, now):
                    self._save_state()
                    continue
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                try:
                    from core.gate_telemetry import clear_radar_candidate
                    clear_radar_candidate(symbol)
                except Exception:
                    pass
                self._notify_telegram(
                    f"🛡️ **[M1 BẢO VỆ XẢ GÃY - ĐÃ HỦY LỆNH]**\n"
                    f"Cặp: **{symbol}** ({direction})\n"
                    f"Giá đã xả thủng ngưỡng -0.80% (Giá: `{current_price:.6g}` < Ngưỡng: `{invalid_price:.6g}`).\n"
                    f"🚪 **Đã hủy lệnh Limit đón lõng, bảo toàn 100% vốn trước cú sập bẫy!**"
                )
                continue

            # Kịch bản 3: GIÁ BAY THẲNG HOẶC HẾT HẠN CHỜ (TIMEOUT 15M)
            is_runner_away = False
            if direction == 'LONG' and current_price >= signal_price * 1.015:
                is_runner_away = True
            elif direction == 'SHORT' and current_price <= signal_price * 0.985:
                is_runner_away = True

            is_timeout = (now - created_at) >= timeout_sec

            if is_runner_away or is_timeout:
                reason_str = "Giá bay thẳng > +1.5% không hồi" if is_runner_away else f"Hết thời gian chờ {timeout_sec/60:.0f} phút"
                logger.info(f"⏱️ [M1 HỦY LỆNH RÌNH MỒI] {symbol}: {reason_str}. Hủy lệnh chờ an toàn.")
                if not self._cancel_stalking_order(symbol, stalking, order_id, now):
                    self._save_state()
                    continue
                self.pending_stalking_orders.pop(symbol, None)
                self._save_state()
                try:
                    from core.gate_telemetry import clear_radar_candidate
                    clear_radar_candidate(symbol)
                except Exception:
                    pass
                continue

    def _cancel_stalking_order(self, symbol: str, stalking: dict, order_id: str, now: float) -> bool:
        """Hủy lệnh rình mồi M1. Trả True nếu chắc chắn lệnh đã rời sổ lệnh, False nếu phải giữ theo dõi.

        [SỬA LỖI GỐC RỄ] Trước đây cả 2 nhánh hủy (xả gãy ngưỡng và hết hạn/bay thẳng) đều gọi
        cancel_order trong try/except rồi BẤT CHẤP kết quả vẫn pop(symbol) khỏi
        pending_stalking_orders. Khi lệnh hủy thất bại (mạng lag, sàn bận, -2011 unknown order do
        đã khớp), bot bỏ rơi một lệnh Limit Maker còn SỐNG trên Binance: nếu lệnh đó khớp sau, bot
        không hề biết -> vị thế mở không SL/TP, phơi nhiễm 100% vốn.
        Nay chỉ pop khi sàn xác nhận lệnh đã đóng/hủy; nếu không, giữ trong RAM và thử lại có giãn cách.
        """
        if self.mode != 'live' or not order_id:
            return True
        if stalking.get('cancel_pending') and now < float(stalking.get('cancel_retry_at') or 0.0):
            return False
        try:
            # strict=True bắt buộc lỗi API được ném ra; response rỗng không được
            # hiểu là đã hủy. Luôn đọc lại trạng thái terminal trước khi bỏ tracking.
            self.exchange.cancel_order(order_id, symbol, strict=True)
        except Exception as ce:
            logger.error(f"Lỗi hủy lệnh limit rình mồi {symbol}: {ce}", exc_info=True)
        try:
            info = self.exchange.get_order_status(order_id, symbol) or {}
            status = str(info.get('status') or '').lower()
            if status in ('canceled', 'cancelled', 'rejected', 'expired'):
                stalking.pop('cancel_pending', None)
                return True
            if status in ('closed', 'filled'):
                # Lệnh đã khớp trong lúc hủy -> KHÔNG bỏ rơi, để vòng sau kích hoạt vị thế
                stalking['cancel_pending'] = False
                stalking['cancel_retry_at'] = 0.0
                return False
        except Exception:
            pass
        attempts = int(stalking.get('cancel_attempts') or 0) + 1
        stalking['cancel_attempts'] = attempts
        stalking['cancel_pending'] = True
        stalking['cancel_retry_at'] = now + min(60.0, 10.0 * attempts)
        logger.warning(
            f"🛡️ [M1 GIỮ THEO DÕI] Chưa xác nhận được việc hủy lệnh rình mồi {symbol} "
            f"(lần {attempts}). GIỮ lệnh trong RAM để tiếp tục bảo vệ, không bỏ rơi lệnh trên sàn."
        )
        return False

    def _activate_stalking_position(self, stalking: dict, fill_price: float):
        """Kích hoạt vị thế chính thức sau khi lệnh bắn tỉa M1 khớp đáy retest thành công."""
        symbol = stalking['symbol']
        side = stalking['side']
        direction = stalking['direction']
        amount = stalking['amount']
        position_size = stalking['position_size']
        leverage = stalking['leverage']
        order_id = stalking['order_id']
        entry_price = fill_price
        clamped_sl_dist = float(stalking.get('clamped_sl_dist') or 0.02)
        clamped_tp_dist = float(stalking.get('clamped_tp_dist') or 0.04)

        if direction == 'LONG':
            sl_price = entry_price * (1.0 - clamped_sl_dist)
            tp_price = entry_price * (1.0 + clamped_tp_dist)
        else:
            sl_price = entry_price * (1.0 + clamped_sl_dist)
            tp_price = entry_price * (1.0 - clamped_tp_dist)

        if hasattr(self.exchange, 'exchange') and hasattr(self.exchange.exchange, 'price_to_precision'):
            try:
                ccxt_sym_sniper = self.exchange._get_ccxt_symbol(symbol)
                sl_price = float(self.exchange.exchange.price_to_precision(ccxt_sym_sniper, sl_price))
                tp_price = float(self.exchange.exchange.price_to_precision(ccxt_sym_sniper, tp_price))
            except Exception:
                pass

        if self.mode == 'live':
            position_size = amount * entry_price / max(1.0, leverage)

        # Đặt Stop-Loss và Take-Profit ngay lập tức trên Binance Futures
        sl_order_id = None
        tp_order_id = None
        protection_status = 'exchange_stop' if self.mode == 'demo' else 'pending_placement'
        close_side = 'sell' if side == 'buy' else 'buy'

        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            try:
                sl_order = self.exchange.create_stop_market_order(symbol, close_side, amount, sl_price)
                sl_info = (sl_order or {}).get('info') or {}
                sl_order_id = str((sl_order or {}).get('id') or sl_info.get('algoId') or sl_info.get('orderId') or '')
                if sl_order_id:
                    protection_status = 'exchange_stop'
                    logger.info(f"✅ Đã đặt Stop-Loss bảo vệ M1 cho {symbol} tại {sl_price:.6g} (Order ID: {sl_order_id})")
                else:
                    protection_status = 'bot_poll_only'
                    logger.warning(f"Binance chưa trả về ID cho Stop-Loss {symbol}")
            except Exception as e:
                protection_status = 'bot_poll_only'
                logger.error(f"Lỗi đặt Stop-Loss bảo vệ M1 cho {symbol}: {e}", exc_info=True)

            try:
                tp_order = self.exchange.create_take_profit_market_order(symbol, close_side, amount, tp_price)
                tp_info = (tp_order or {}).get('info') or {}
                tp_order_id = str((tp_order or {}).get('id') or tp_info.get('algoId') or tp_info.get('orderId') or '')
                if tp_order_id:
                    logger.info(f"✅ Đã đặt Take-Profit bảo vệ M1 cho {symbol} tại {tp_price:.6g} (Order ID: {tp_order_id})")
            except Exception as e:
                logger.error(f"Lỗi đặt Take-Profit bảo vệ M1 cho {symbol}: {e}", exc_info=True)

            if not sl_order_id:
                # Không để vị thế M1 mới khớp sống mà không có Hard SL sàn. Ưu tiên
                # đóng khẩn đúng khối lượng đã fill; chỉ giữ tracking nếu đóng cũng thất bại.
                try:
                    emergency_order = self.exchange.close_futures_position(symbol, direction, amount)
                    emergency_filled = self._confirmed_filled_amount(emergency_order, symbol, amount)
                except Exception as close_error:
                    emergency_filled = 0.0
                    logger.error("Không thể đóng khẩn M1 thiếu SL %s: %s", symbol, close_error)
                if emergency_filled >= amount * 0.999999:
                    if tp_order_id:
                        try:
                            self.exchange.cancel_order(tp_order_id, symbol, trigger=True, strict=False)
                        except Exception:
                            pass
                    logger.critical(
                        "🛑 [M1 THIẾU HARD SL] %s đã được đóng khẩn toàn bộ vì không đặt được SL sàn.",
                        symbol,
                    )
                    self._notify_telegram(
                        f"🛑 **M1 THIẾU HARD SL — ĐÃ ĐÓNG KHẨN**\nCặp: **{symbol}**\nKhông đặt được SL sàn nên bot đã đóng vị thế để tránh thả trôi rủi ro."
                    )
                    return
                protection_status = 'bot_poll_only'

        # Ưu tiên phí fill thật nếu sàn trả về; M1 post-only mới dùng Maker 0.02%.
        entry_fee = float(stalking.get('entry_fee') or ((amount * entry_price) * 0.0002))
        strategy_name = stalking.get('strategy', 'sniper_m1')
        confidence = float(stalking.get('confidence', 0.8))

        position = {
            'symbol': symbol,
            'side': side,
            'direction': direction,
            'entry_price': entry_price,
            'amount': amount,
            'initial_amount': amount,
            'cost': position_size,
            'initial_cost': position_size,
            'atr': entry_price * float(stalking.get('atr_pct') or 0.012),
            'atr_pct': float(stalking.get('atr_pct') or 0.012),
            'initial_sl_distance_pct': clamped_sl_dist,
            'total_sl_stages': self._calc_adaptive_stages({'initial_amount': amount, 'entry_price': entry_price}, entry_price),
            'sl_stage_completed': 0,
            'entry_fee': entry_fee,
            'leverage': leverage,
            'exchange_leverage_limit': stalking.get('exchange_leverage_limit'),
            'leverage_limit_verified': stalking.get('leverage_limit_verified', True),
            'leverage_limit_source': stalking.get('leverage_limit_source', 'bracket'),
            'market_type': stalking.get('market_type', getattr(self, 'market_type', 'spot')),
            'stop_loss': sl_price,
            'take_profit': tp_price,
            'strategy': strategy_name,
            'trap_type': stalking.get('trap_type'),
            'signal_quality': float(stalking.get('signal_quality', getattr(self, 'last_signal_quality', 1.0)) or 1.0),
            'is_momentum_ride': bool(stalking.get('is_momentum_ride')),
            'is_fading_short': bool(stalking.get('is_fading_short')),
            'is_waterfall_short': bool(stalking.get('is_waterfall_short')),
            'is_oversold_bounce': bool(stalking.get('is_oversold_bounce')),
            'be_trigger_override': stalking.get('be_trigger_override'),
            'timestamp': datetime.now().isoformat(),
            'order_id': order_id,
            'sl_order_id': sl_order_id,
            'tp_order_id': tp_order_id,
            'protection_status': protection_status,
            'protection_review_required': bool(self.mode == 'live' and not sl_order_id),
            'trailing_stop': None,
            'trailing_best_price': entry_price,
            'trailing_active': False,
            'trailing_status': 'waiting_net_profit',
            'trailing_distance_pct': None,
            'trailing_atr_pct': None,
            'trailing_adx': None,
            'trailing_regime': 'not_calculated',
            'trailing_net_breakeven': None,
        }
        self.open_positions.append(position)
        try:
            from core.gate_telemetry import clear_radar_candidate
            clear_radar_candidate(position.get('symbol', ''))
        except Exception:
            pass
        if self.mode != 'live':
            self.balance -= position_size
            self.balance -= entry_fee
        self.trade_count += 1

        # Gửi Telegram thông báo khớp lệnh M1
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        direction_str = "MUA LÊN (LONG)" if direction == "LONG" else "BÁN XUỐNG (SHORT)"
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        sig_ref_px = float(stalking.get('signal_price') or entry_price)
        retest_diff_pct = abs(entry_price - sig_ref_px) / max(1e-8, sig_ref_px) * 100.0
        retest_note = f"Rẻ hơn {retest_diff_pct:.2f}% so với giá tín hiệu!" if direction == "LONG" else f"Cao hơn {retest_diff_pct:.2f}% so với giá tín hiệu!"
        msg = (
            f"🎯 **[{mode_str}] BẮN TỈA M1 KHỚP ĐÁY RETEST: {direction_str}** [MAKER 0.02% FEE]\n\n"
            f"📊 **Cặp giao dịch:** {symbol} ({leverage}x)\n"
            f"🎯 **Giá khớp (Entry):** `{entry_price:.6f}` ({retest_note})\n"
            f"🛑 **Cắt lỗ (SL):** `{sl_price:.6f}` ({abs(sl_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
            f"🎯 **Chốt lời (TP):** `{tp_price:.6f}` ({abs(tp_price - entry_price)/entry_price*leverage*100:.2f}% Margin)\n"
            f"🧠 **AI & Chiến lược:** {strategy_name} (Sniper Retest Execution)\n"
            f"💰 **Ký quỹ:** {position_size:.2f} {quote} | **Khả dụng:** {self.balance:.2f} {quote}" + (f" | **Tổng vốn:** {float(self._futures_account_snapshot.get('wallet_balance')):.2f} {quote}" if self.mode == 'live' and getattr(self, '_futures_account_snapshot', None) and self._futures_account_snapshot.get('wallet_balance') is not None else "")
        )
        self._notify_telegram(msg)

        # Lưu lịch sử trade
        self.db.save_trade({
            'symbol': symbol,
            'side': side,
            'type': 'limit_maker',
            'price': entry_price,
            'amount': amount,
            'cost': amount * entry_price,
            'fee': entry_fee,
            'pnl': 0,
            'strategy': position['strategy'],
            'status': 'open',
            'order_id': order_id,
            'timestamp': int(time.time() * 1000),
            'mode': self.mode
        })

    def _check_open_positions_locked(self):
        """Kiểm tra stop-loss và take-profit cho các positions đang mở."""
        if not self.is_running:
            return
        # Giám sát và xử lý các lệnh bắn tỉa rình mồi M1 (Sniper Retest Stalking)
        self._check_pending_stalking_orders_locked()
        for position in self.open_positions[:]:  # Copy list to avoid mutation issues
            try:
                if (
                    self.mode == 'live'
                    and getattr(self, 'market_type', 'spot') == 'futures'
                    and position.get('protection_review_required')
                ):
                    # Thiếu xác nhận SL không được làm tê liệt cầu dao giá thật. Chỉ
                    # đóng khẩn bằng ticker sàn khi vượt ngưỡng thảm họa; các thao tác
                    # trailing/TP khác vẫn chờ đối soát bảo vệ.
                    try:
                        review_ticker = self.exchange.get_ticker(position['symbol'])
                        review_price = float((review_ticker or {}).get('last') or (review_ticker or {}).get('close') or 0.0)
                        review_entry = float(position.get('entry_price') or 0.0)
                        if review_price > 0 and review_entry > 0:
                            review_direction = str(position.get('direction', 'LONG')).upper()
                            review_pnl = (
                                (review_price - review_entry) / review_entry
                                if review_direction == 'LONG'
                                else (review_entry - review_price) / review_entry
                            )
                            emergency_pct = float(self.config.get('risk', {}).get('stop_loss_pct', 0.04) or 0.04) + 0.01
                            if review_pnl <= -emergency_pct:
                                if self._is_manual_position(position):
                                    logger.info(
                                        "🛡️ [MANUAL POSITION IMMUNITY] %s lỗ %.2f%% khi SL chưa xác minh; miễn trừ cầu dao khẩn cấp để tôn trọng lệnh tay.",
                                        position['symbol'], review_pnl * 100,
                                    )
                                else:
                                    logger.critical(
                                        "🚨 [PROTECTION REVIEW EMERGENCY] %s lỗ %.2f%% khi SL chưa xác minh; đóng khẩn bằng giá sàn.",
                                        position['symbol'], review_pnl * 100,
                                    )
                                    self._close_position(position, review_price, "Cầu dao khẩn cấp khi thiếu xác nhận SL")
                    except Exception as review_error:
                        logger.error("Không thể chạy cầu dao protection review cho %s: %s", position.get('symbol'), review_error)
                    continue
                self._retry_stale_trailing_stop_cancellations(position)
                ticker = self.exchange.get_ticker(position['symbol'])
                if not ticker:
                    continue
                    
                raw_ticker_price = ticker.get('last') or ticker.get('close')
                if raw_ticker_price is None:
                    continue
                try:
                    current_price = float(raw_ticker_price)
                    if not math.isfinite(current_price) or current_price <= 0:
                        continue
                except (TypeError, ValueError):
                    continue
                direction = position.get('direction', 'LONG')
                
                # 0. BẢO VỆ CUỐI TUẦN CHO CỔ PHIẾU & HÀNG HÓA MỸ (TRADFI WEEKEND SHIELD & AUTO-CLOSE):
                is_tradfi_held = (
                    MarketScanner.is_tradfi_stock(position.get('symbol', ''), self.exchange)
                    or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(position.get('symbol', ''), self.exchange))
                )
                if is_tradfi_held:
                    tradfi_cfg = self.config.get('tradfi', {})
                    is_gap_window = MarketScanner.is_weekend_gap_risk_window(symbol=position.get('symbol', ''), exchange=self.exchange)
                    
                    if not is_gap_window:
                        if position.get('weekend_shield_applied') or position.get('weekend_shield_loss_logged'):
                            position.pop('weekend_shield_applied', None)
                            position.pop('weekend_shield_loss_logged', None)
                            position.pop('_weekend_shield_retry_after', None)
                    else:
                        # Phương án A: Tùy chọn đóng cưỡng bức (Forced Weekend Close) nếu cấu hình weekend_close: true
                        # [BAI HOC 68] Lệnh tay của người dùng KHÔNG bị đóng cưỡng bức; chỉ kéo SL về
                        # hòa vốn (Phương án B bên dưới) để bảo vệ mà không tước quyền quyết định.
                        if tradfi_cfg.get('weekend_close', False) and not self._is_manual_position(position):
                            logger.warning(
                                f"🛡️ [CHỐT LỆNH CUỐI TUẦN] {position['symbol']} @ {current_price:.6g}! "
                                f"Tự động đóng vị thế trước kỳ nghỉ cuối tuần của sàn chứng khoán Mỹ theo cấu hình weekend_close."
                            )
                            self._close_position(position, current_price, close_reason="🛡️ Tự động chốt lệnh trước kỳ nghỉ cuối tuần (Tránh Gap giá)")
                            continue
                        if tradfi_cfg.get('weekend_close', False) and self._is_manual_position(position):
                            logger.info(
                                "🖐️ [MANUAL POSITION SUPPORT-ONLY] Không đóng cưỡng bức lệnh tay %s trước kỳ nghỉ; chỉ kéo SL về hòa vốn.",
                                position['symbol'],
                            )

                        # Phương án B: BẢO HIỂM THÔNG MINH CUỐI TUẦN (SMART WEEKEND SHIELD - HYBRID MẶC ĐỊNH)
                        # Giữ nguyên lệnh 24/7 trên Binance, NHƯNG nếu có lãi an toàn (vượt net_be + 0.22% đệm) -> kéo ngay SL về Hòa Vốn (Net Breakeven)
                        # để trở thành vị thế Risk-Free 100%, săn Take Profit xuyên suốt Thứ 7 & Chủ Nhật mà không sợ rủi ro mở phiên Thứ 2!
                        if tradfi_cfg.get('weekend_shield', True):
                            try:
                                now_ws = time.time()
                                retry_after_ws = float(position.get('_weekend_shield_retry_after', 0.0) or 0.0)
                                if now_ws < retry_after_ws:
                                    pass # Đang trong cooldown giãn cách, tránh spam API Binance mỗi 10s
                                else:
                                    entry_p = float(position.get('entry_price') or 0)
                                    current_sl = float(position.get('stop_loss') or 0)
                                    net_be = self._trailing_net_breakeven(position)
                                    
                                    # CHỐNG LỖI -2021 (Immediately Trigger): Bắt buộc giá hiện tại đã vượt qua net_be tối thiểu 0.35%
                                    # và điểm SL bảo hiểm kéo lên phải có đệm an toàn >= 0.35% so với giá thị trường
                                    safe_ws_buf = 0.0035
                                    is_in_safe_net_profit = False
                                    proposed_shield_sl = net_be
                                    if direction == 'LONG' and current_price >= net_be * (1.0 + safe_ws_buf):
                                        is_in_safe_net_profit = True
                                        proposed_shield_sl = min(net_be, current_price * (1.0 - safe_ws_buf))
                                    elif direction == 'SHORT' and current_price <= net_be * (1.0 - safe_ws_buf):
                                        is_in_safe_net_profit = True
                                        proposed_shield_sl = max(net_be, current_price * (1.0 + safe_ws_buf))

                                    if is_in_safe_net_profit:
                                        improves = False
                                        if direction == 'LONG' and proposed_shield_sl > current_sl * 1.0005:
                                            improves = True
                                        elif direction == 'SHORT' and proposed_shield_sl < current_sl * 0.9995:
                                            improves = True

                                        if improves:
                                            is_live_fut = (
                                                self.mode == 'live'
                                                and getattr(self, 'market_type', 'spot') == 'futures'
                                            )
                                            old_sl_id = str(position.get('sl_order_id') or '')
                                            close_side = 'sell' if direction == 'LONG' else 'buy'
                                            shield_success = True
                                            new_shield_sl_id = old_sl_id

                                            if is_live_fut:
                                                try:
                                                    new_order = self.exchange.create_stop_market_order(
                                                        position['symbol'], close_side,
                                                        position['amount'], proposed_shield_sl,
                                                    )
                                                    new_info = (new_order or {}).get('info') or {}
                                                    new_shield_sl_id = str(
                                                        (new_order or {}).get('id')
                                                        or new_info.get('algoId')
                                                        or new_info.get('orderId')
                                                        or ''
                                                    )
                                                    shield_success = bool(new_shield_sl_id)
                                                    if not shield_success:
                                                        logger.error(
                                                            f"Binance chưa xác nhận SL bảo hiểm cuối tuần cho {position['symbol']}; giữ nguyên SL cũ tại {current_sl:.6g}"
                                                        )
                                                        position['_weekend_shield_retry_after'] = now_ws + 180.0
                                                except Exception as e_sl:
                                                    shield_success = False
                                                    logger.error(f"Lỗi đặt SL bảo hiểm cuối tuần cho {position['symbol']}: {e_sl}")
                                                    position['_weekend_shield_retry_after'] = now_ws + 180.0

                                            if shield_success:
                                                position['stop_loss'] = proposed_shield_sl
                                                position['sl_order_id'] = new_shield_sl_id
                                                position['weekend_shield_applied'] = True
                                                position.pop('_weekend_shield_retry_after', None)

                                                if is_live_fut and old_sl_id and old_sl_id != new_shield_sl_id:
                                                    pending_ids = list(dict.fromkeys(
                                                        str(oid) for oid in position.get('stale_sl_order_ids', []) if oid
                                                    ))
                                                    pending_ids.append(old_sl_id)
                                                    position['stale_sl_order_ids'] = list(dict.fromkeys(pending_ids))
                                                    try:
                                                        self.exchange.cancel_order(
                                                            old_sl_id, position['symbol'],
                                                            trigger=True, strict=True,
                                                        )
                                                    except Exception as ce:
                                                        logger.warning("Chưa hủy ngay được SL cũ %s của %s: %s", old_sl_id, position['symbol'], ce)

                                                self._save_state()
                                                logger.info(
                                                    f"🛡️ [BẢO HIỂM CUỐI TUẦN - RISK FREE] Đã kéo SL cho {position['symbol']} "
                                                    f"từ {current_sl:.6g} lên mức Hòa Vốn an toàn {proposed_shield_sl:.6g} (Entry: {entry_p:.6g})!"
                                                )
                                                self._notify_telegram(
                                                    f"🛡️ **[BẢO HIỂM CUỐI TUẦN - 100% RISK-FREE]**\n"
                                                    f"Mã: **{position['symbol']}** ({direction})\n"
                                                    f"Thị trường bước vào kỳ nghỉ cuối tuần. Để bảo toàn lợi nhuận và triệt tiêu rủi ro Gap giá:\n"
                                                    f"🔹 **Entry:** `{entry_p:.6g}` | **Giá hiện tại:** `{current_price:.6g}`\n"
                                                    f"🛡️ **Stop-Loss đã kéo về Hòa Vốn:** `{current_sl:.6g}` ➡️ `{proposed_shield_sl:.6g}`\n"
                                                    f"💎 **Trạng thái:** Vị thế miễn nhiễm rủi ro (Risk-Free)! Bot tiếp tục giữ lệnh 24/7 trên Binance để săn Take Profit qua Thứ Bảy & Chủ Nhật."
                                                )
                                        elif not position.get('weekend_shield_applied'):
                                            position['weekend_shield_applied'] = True
                                            logger.info(
                                                f"🛡️ [BẢO HIỂM CUỐI TUẦN] {position['symbol']} đã được bảo vệ có lãi từ trước (SL: {current_sl:.6g} >= BE: {net_be:.6g}). Tiếp tục gồng lệnh 24/7."
                                            )
                                            self._save_state()
                                    else:
                                        # Lệnh chưa có lãi an toàn (đang hòa hoặc âm nhẹ hoặc chưa đủ đệm 0.22%)
                                        if not position.get('weekend_shield_loss_logged'):
                                            logger.info(
                                                f"🛡️ [BẢO HIỂM CUỐI TUẦN] {position['symbol']} chưa đạt điểm an toàn để kéo BE (Giá: {current_price:.6g}, Entry: {entry_p:.6g}, BE: {net_be:.6g}). "
                                                f"Giữ nguyên SL sàn {current_sl:.6g}, không cắt lỗ non, tiếp tục bảo vệ vị thế 24/7 trên Binance."
                                            )
                                            position['weekend_shield_loss_logged'] = True
                                            self._save_state()
                            except Exception as wse:
                                logger.error(f"Lỗi xử lý Weekend Shield cho {position.get('symbol')}: {wse}")

                # 1. Kiểm tra Stop-Loss theo kế hoạch (SL đặt trên sàn)
                is_sl_hit = False
                if direction == 'LONG' and current_price <= position['stop_loss']:
                    is_sl_hit = True
                elif direction == 'SHORT' and current_price >= position['stop_loss']:
                    is_sl_hit = True

                if is_sl_hit or self.risk_manager.check_stop_loss(position, current_price):
                    logger.warning(
                        f"🛑 STOP-LOSS hit! {position['symbol']} "
                        f"@ {current_price:.6g} (SL: {position['stop_loss']:.6g})"
                    )
                    self._close_position(position, current_price, close_reason="Chạm Stop Loss theo kế hoạch")
                    continue
                    
                # 2. Cầu dao bảo vệ thảm họa khẩn cấp (Emergency Circuit Breaker):
                # Chỉ kích hoạt khi giá sập/bơm thủng sâu quá mức Stop-Loss cho phép (Flash crash / Trượt giá nghiêm trọng)
                entry_price_val = float(position.get('entry_price') or 0)
                fast_pnl_pct = 0.0
                if entry_price_val > 0:
                    fast_pnl_pct = (current_price - entry_price_val) / entry_price_val if direction == 'LONG' else (entry_price_val - current_price) / entry_price_val
                    
                max_allowed_loss = -max(0.045, abs(float(self.config.get('risk', {}).get('stop_loss_pct', 0.04))) * 1.25)
                if fast_pnl_pct <= max_allowed_loss:
                    if self._is_manual_position(position):
                        logger.info(
                            f"🛡️ [MANUAL POSITION IMMUNITY] {position['symbol']} chạm {fast_pnl_pct*100:.2f}%; "
                            f"miễn trừ cầu dao cắt lỗ thảm họa để bảo toàn ý chí giao dịch thủ công."
                        )
                    else:
                        logger.critical(
                            f"🚨 [CẦU DAO CẮT LỖ THẢM HỌA] {position['symbol']} rơi tự do chạm {fast_pnl_pct*100:.2f}% "
                            f"(vượt ngưỡng trần rủi ro {max_allowed_loss*100:.2f}%)! Đóng vị thế khẩn cấp bảo vệ tài khoản."
                        )
                        self._close_position(position, current_price, close_reason=f"Cầu dao cắt lỗ thảm họa ({fast_pnl_pct*100:.2f}%)")
                        continue
                
                # Kiểm tra take-profit
                # --- DYNAMIC TAKE PROFIT VẬT LÝ TRÊN SÀN (GỒNG SIÊU SÓNG KÈM KHÓA SL BẢO HIỂM 100%) ---
                if self.config.get('risk', {}).get('enable_dynamic_tp', False):
                    try:
                        metrics = self._adaptive_trailing_metrics(position, current_price)
                        adx = float(metrics.get('adx') or 0)
                        atr_pct = float(metrics.get('atr_pct') or 0.01)
                        entry_price = float(position.get('entry_price') or 0)
                        current_tp = float(position.get('take_profit') or 0)
                        current_sl = float(position.get('stop_loss') or 0)
                        
                        last_tp_extend = float(position.get('last_tp_extend_time', 0))
                        now_ts = time.time()
                        
                        if entry_price > 0 and current_tp > 0 and (now_ts - last_tp_extend >= 60.0):
                            tp_dist_pct = abs(current_tp - current_price) / current_price
                            init_tp_dist = abs(current_tp - entry_price) / entry_price
                            curr_pnl_tp = (
                                (current_price - entry_price) / entry_price
                                if direction == 'LONG'
                                else (entry_price - current_price) / entry_price
                            )
                            # [BÀI HỌC 85]: Chỉ kích hoạt Gồng Siêu Sóng khi giá đã đi được >= 80% quãng đường tới TP
                            # (còn cách TP <= 25% quãng đường và <= 0.35 ATR) VÀ vị thế đang lãi thực >= +1.20%!
                            # Chấm dứt lỗi kích hoạt ở 0.9s sau khi mở lệnh (ON/USDT #1) và đảm bảo locked_sl luôn khóa lãi >= +0.50%!
                            near_tp_zone = (tp_dist_pct <= max(0.0025, 0.25 * init_tp_dist)) and (tp_dist_pct <= atr_pct * 0.35)
                            
                            new_tp = None
                            locked_sl = None
                            
                            if direction == 'LONG':
                                if near_tp_zone and curr_pnl_tp >= 0.0120 and adx > 30 and current_price > entry_price:
                                    new_tp = current_tp * (1 + atr_pct * 1.5)
                                    # KHÓA SL BẢO HIỂM: Tối thiểu khóa +0.50% trên giá vào và cách giá hiện tại >= 0.35%
                                    proposed_locked_sl = max(
                                        entry_price * 1.0050,
                                        min(current_tp * 0.998, current_price * 0.9965)
                                    )
                                    if proposed_locked_sl > current_sl and proposed_locked_sl < current_price * 0.9975:
                                        locked_sl = proposed_locked_sl
                            else:
                                if near_tp_zone and curr_pnl_tp >= 0.0120 and adx > 30 and current_price < entry_price:
                                    new_tp = current_tp * (1 - atr_pct * 1.5)
                                    proposed_locked_sl = min(
                                        entry_price * 0.9950,
                                        max(current_tp * 1.002, current_price * 1.0035)
                                    )
                                    if proposed_locked_sl < current_sl and proposed_locked_sl > current_price * 1.0025:
                                        locked_sl = proposed_locked_sl
                            
                            if new_tp:
                                old_tp_id = str(position.get('tp_order_id') or '')
                                old_sl_id = str(position.get('sl_order_id') or '')
                                close_side = 'sell' if direction == 'LONG' else 'buy'
                                
                                is_live = getattr(self, 'mode', 'demo') == 'live'
                                tp_success = True
                                
                                if is_live:
                                    new_tp_order = self.exchange.create_take_profit_market_order(
                                        position['symbol'], close_side,
                                        position['amount'], new_tp,
                                    )
                                    tp_info = (new_tp_order or {}).get('info') or {}
                                    new_tp_id = str((new_tp_order or {}).get('id') or tp_info.get('algoId') or tp_info.get('orderId') or '')
                                    tp_success = bool(new_tp_id)
                                else:
                                    new_tp_id = f"demo-tp-{int(now_ts*1000)}"

                                if tp_success:
                                    # Cập nhật Stop-Loss bảo hiểm trên sàn
                                    new_sl_id = old_sl_id
                                    sl_updated_ok = not is_live
                                    if locked_sl and is_live:
                                        try:
                                            new_sl_order = self.exchange.create_stop_market_order(
                                                position['symbol'], close_side,
                                                position['amount'], locked_sl,
                                            )
                                            if new_sl_order:
                                                sl_info = (new_sl_order or {}).get('info') or {}
                                                cand_sl_id = str((new_sl_order or {}).get('id') or sl_info.get('algoId') or sl_info.get('orderId') or '')
                                                if cand_sl_id:
                                                    new_sl_id = cand_sl_id
                                                    sl_updated_ok = True
                                                    if old_sl_id and new_sl_id != old_sl_id:
                                                        try:
                                                            self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                                        except Exception as e:
                                                            logger.error(f"Lỗi hủy SL cũ khi dời TP: {e}")
                                                            stale = position.setdefault('stale_sl_order_ids', [])
                                                            stale.append(old_sl_id)
                                        except Exception as e:
                                            logger.error(f"Lỗi đặt SL bảo hiểm khi dời TP: {e}")
                                    
                                    # Hủy TP cũ
                                    if old_tp_id and is_live:
                                        try:
                                            self.exchange.cancel_order(
                                                old_tp_id, position['symbol'],
                                                trigger=True, strict=True
                                            )
                                        except Exception as e:
                                            logger.error(f"Lỗi hủy TP cũ {old_tp_id}: {e}")
                                            stale = position.setdefault('stale_sl_order_ids', [])
                                            stale.append(old_tp_id)
                                            
                                    position['take_profit'] = new_tp
                                    position['tp_order_id'] = new_tp_id
                                    if locked_sl and sl_updated_ok:
                                        position['stop_loss'] = locked_sl
                                        position['sl_order_id'] = new_sl_id
                                    position['last_tp_extend_time'] = now_ts
                                    self._save_state()

                                    est_tp_pnl = (new_tp - entry_price) * position['amount'] if direction == 'LONG' else (entry_price - new_tp) * position['amount']
                                    locked_pnl = ((locked_sl or current_sl) - entry_price) * position['amount'] if direction == 'LONG' else (entry_price - (locked_sl or current_sl)) * position['amount']
                                    quote_curr = self.config.get('trading', {}).get('base_currency', 'USDT')
                                    dir_txt = "tăng" if direction == "LONG" else "giảm"
                                    move_txt = "LÊN" if direction == "LONG" else "XUỐNG"
                                    
                                    logger.info(f"🚀 GỒNG SIÊU SÓNG THÀNH CÔNG: {position['symbol']} dời TP từ {current_tp:.6g} {move_txt} {new_tp:.6g}, khóa SL bảo hiểm ở {(locked_sl or current_sl):.6g}")
                                    self._notify_telegram(
                                        f"🚀 **[GỒNG SIÊU SÓNG - KHÓA BẢO HIỂM 100%]**\n"
                                        f"Đà {dir_txt} của {position['symbol']} đang rất mạnh (ADX={adx:.1f})!\n"
                                        f"🔹 **Dời Take-Profit {move_txt}:** {current_tp:.6g} ➡️ {new_tp:.6g} (Ước tính lãi chạm TP: {est_tp_pnl:+.4f} {quote_curr})\n"
                                        f"🛡️ **ĐỒNG THỜI KÉO STOP-LOSS:** {current_sl:.6g} ➡️ {(locked_sl or current_sl):.6g}\n"
                                        f"💎 **Khóa chặt lợi nhuận tối thiểu:** {locked_pnl:+.4f} {quote_curr}\n"
                                        f"👉 Nếu giá đảo chiều: Tự động chốt lời bảo vệ tiền ở {(locked_sl or current_sl):.6g}.\n"
                                        f"👉 Nếu tiếp tục bứt phá: Ăn trọn mục tiêu mới {new_tp:.6g}!"
                                    )
                    except Exception as e:
                        logger.error(f"Lỗi dời TP vật lý cho {position.get('symbol')}: {e}")
                
                is_tp_hit = False
                if direction == 'LONG' and current_price >= position['take_profit']:
                    is_tp_hit = True
                elif direction == 'SHORT' and current_price <= position['take_profit']:
                    is_tp_hit = True
                    
                if is_tp_hit or self.risk_manager.check_take_profit(position, current_price):
                    logger.info(
                        f"🎯 TAKE-PROFIT hit! {position['symbol']} "
                        f"@ {current_price:.6g} (TP: {position['take_profit']:.6g})"
                    )
                    self._close_position(position, current_price, close_reason="Chạm Take Profit")
                    continue

                # =========================================================================
                # BẢO VỆ ĐA TẦNG THEO THỜI GIAN & ĐỘNG LƯỢNG (MULTI-STAGE TIME RISK CASCADE V3.0)
                # Chống giam vốn & cấm tuyệt đối ôm lệnh lỗ chờ chết khi giá không bứt phá,
                # đồng thời phân biệt rõ Lệnh Chết Yểu (DOA: peak < +0.30%) và Lệnh Đang Có Sóng!
                # =========================================================================
                entry_price_chk = float(position.get('entry_price') or position.get('price', 0))
                pnl_pct_chk = 0.0
                if entry_price_chk > 0 and current_price > 0:
                    pnl_pct_chk = (current_price - entry_price_chk) / entry_price_chk if direction == 'LONG' else (entry_price_chk - current_price) / entry_price_chk

                # Tính toán đỉnh lợi nhuận (Peak Profit / MFE) đã đạt được từ lúc mở lệnh
                old_best_chk = position.get('trailing_best_price')
                try:
                    old_best_chk = float(old_best_chk) if old_best_chk is not None else None
                except (TypeError, ValueError, OverflowError):
                    old_best_chk = None
                if direction == 'LONG':
                    best_price_chk = max(entry_price_chk, current_price, old_best_chk or 0.0)
                    peak_profit_pct = (best_price_chk - entry_price_chk) / entry_price_chk if entry_price_chk > 0 else 0.0
                else:
                    valid_bests = [v for v in (entry_price_chk, current_price, old_best_chk) if v is not None and v > 0]
                    best_price_chk = min(valid_bests) if valid_bests else entry_price_chk
                    peak_profit_pct = (entry_price_chk - best_price_chk) / entry_price_chk if entry_price_chk > 0 else 0.0
                position['trailing_best_price'] = best_price_chk

                held_minutes_chk = 0.0
                raw_ts_chk = position.get('timestamp')
                if raw_ts_chk:
                    try:
                        if isinstance(raw_ts_chk, str):
                            pos_dt_chk = datetime.fromisoformat(raw_ts_chk)
                            held_minutes_chk = (datetime.now() - pos_dt_chk).total_seconds() / 60.0
                        elif isinstance(raw_ts_chk, (int, float)):
                            pos_secs_chk = raw_ts_chk / 1000.0 if raw_ts_chk > 1e11 else float(raw_ts_chk)
                            held_minutes_chk = (time.time() - pos_secs_chk) / 60.0
                    except Exception:
                        held_minutes_chk = 0.0

                risk_metrics = self._adaptive_trailing_metrics(position, current_price)
                try:
                    risk_atr_pct = float(risk_metrics.get('atr_pct') or position.get('atr_pct') or 0.012)
                    if not math.isfinite(risk_atr_pct) or risk_atr_pct <= 0:
                        risk_atr_pct = 0.012
                except (TypeError, ValueError, OverflowError):
                    risk_atr_pct = 0.012
                ema20_lvl = risk_metrics.get('ema20')
                is_adverse_ema = True
                if ema20_lvl is not None and math.isfinite(ema20_lvl):
                    is_adverse_ema = (current_price < ema20_lvl) if direction == 'LONG' else (current_price > ema20_lvl)

                is_live_fut = (self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures')
                pos_amount = float(position.get('amount') or 0)
                curr_sl_val = float(position.get('stop_loss') or 0)
                close_side = 'sell' if direction == 'LONG' else 'buy'
                time_exit_cfg = self.config.get('risk', {}).get('time_based_exits', {})
                if not isinstance(time_exit_cfg, dict):
                    time_exit_cfg = {}
                doa15_enabled = bool(time_exit_cfg.get('doa_15m', False))
                doa25_enabled = bool(time_exit_cfg.get('doa_25m', False))
                doa35_enabled = bool(time_exit_cfg.get('doa_35m', False))
                idle120_enabled = bool(time_exit_cfg.get('idle_120m', False))
                ladder_sl_enabled = bool(time_exit_cfg.get('ladder_sl', False))
                # [BAI HOC 68] Lệnh tay: bot không được cắt theo thời gian (DOA/Ladder/120m).
                # Chỉ giữ SL sàn, TP và Trailing do chính người dùng/ bot đã đặt để bảo vệ.
                if self._is_manual_position(position):
                    if doa15_enabled or doa25_enabled or doa35_enabled or idle120_enabled or ladder_sl_enabled:
                        logger.debug(
                            "[MANUAL POSITION SUPPORT-ONLY] Bỏ qua toàn bộ cắt lỗ theo thời gian cho %s (%s).",
                            position.get('symbol'), direction,
                        )
                    doa15_enabled = doa25_enabled = doa35_enabled = idle120_enabled = ladder_sl_enabled = False

                # --- 1. THỜI GIAN THỞ (15 PHÚT) VÀ CẮT LỖ SỚM TRÁNH ÔM BOM (DEAD-ON-ARRIVAL) ---
                if doa15_enabled and held_minutes_chk >= 15.0 and pnl_pct_chk <= -0.012 and peak_profit_pct < 0.0030 and not position.get('partial_tp_done'):
                    logger.warning(
                        f"🛑 [CẮT LỖ SỚM - 15 PHÚT DOA] {position['symbol']} ({direction}) "
                        f"ngâm 15m nến đóng âm sâu ({pnl_pct_chk*100:+.2f}% <= -1.2%) không có đỉnh sóng (Peak={peak_profit_pct*100:+.2f}% < +0.30%)! Đóng Market ngay bảo toàn vốn."
                    )
                    self._notify_telegram(
                        f"🛑 **[CẮT LỖ SỚM - 15 PHÚT HẾT HẠN THỞ]**\n"
                        f"Cặp: **{position['symbol']}** ({direction})\n"
                        f"Vị thế sau 15 phút không sinh lời mà lỗ sâu (`{pnl_pct_chk*100:+.2f}%`).\n"
                        f"🚪 **Chủ động cắt lỗ sớm** tránh ôm bom rủi ro lớn hơn."
                    )
                    self._close_position(position, current_price, close_reason=f"Cắt lỗ sớm 15m DOA (PnL: {pnl_pct_chk*100:+.2f}%)")
                    continue

                # --- 2. CO HẸP STOP LOSS GIAI ĐOẠN 1 (15 PHÚT): SIẾT TRẦN SL TỪ -3.5% VỀ -1.8% CHO LỆNH ĐI NGANG ---
                if ladder_sl_enabled and held_minutes_chk >= 15.0 and not position.get('time_sl_compressed_15m') and not position.get('_time_sl_checked_15m'):
                    proposed_sl_15m = entry_price_chk * (1.0 - 0.018) if direction == 'LONG' else entry_price_chk * (1.0 + 0.018)
                    improves_15m = (proposed_sl_15m > curr_sl_val) if direction == 'LONG' else (proposed_sl_15m < curr_sl_val)
                    if not improves_15m:
                        position['_time_sl_checked_15m'] = True
                    elif pos_amount > 0:
                        is_breached_15m = (current_price <= proposed_sl_15m) if direction == 'LONG' else (current_price >= proposed_sl_15m)
                        if is_breached_15m:
                            logger.warning(f"🛡️ [CO HẸP SL 15M] Giá đã chạm ngưỡng siết -1.8% ({proposed_sl_15m:.6g}). Đóng Market!")
                            self._close_position(position, current_price, close_reason="🛡️ Co hẹp SL 15m chạm giá")
                            continue
                        old_sl_id = str(position.get('sl_order_id') or '')
                        sl_confirmed = not is_live_fut
                        if is_live_fut:
                            try:
                                new_sl_order = self.exchange.create_stop_market_order(position['symbol'], close_side, pos_amount, proposed_sl_15m)
                                new_info = (new_sl_order or {}).get('info') or {}
                                new_sl_id = str((new_sl_order or {}).get('id') or new_info.get('algoId') or new_info.get('orderId') or '')
                                if new_sl_id:
                                    sl_confirmed = True
                                    if old_sl_id and old_sl_id != new_sl_id:
                                        try:
                                            self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                        except Exception:
                                            position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                    position['sl_order_id'] = new_sl_id
                                else:
                                    logger.error(f"Binance chưa xác nhận SL 15m mới cho {position['symbol']}; giữ SL cũ.")
                            except Exception as e:
                                logger.error(f"Lỗi siết SL 15m cho {position['symbol']}: {e}")
                        if sl_confirmed:
                            position['time_sl_compressed_15m'] = True
                            position['_time_sl_checked_15m'] = True
                            position['stop_loss'] = proposed_sl_15m
                            curr_sl_val = proposed_sl_15m
                            self._save_state()
                            logger.info(f"🛡️ [CO HẸP SL 15M] {position['symbol']} ({direction}) đi ngang 15m, siết SL về -1.8% ({proposed_sl_15m:.6g}) cắt giảm 50% rủi ro.")

                # --- 3. CO HẸP STOP LOSS GIAI ĐOẠN 2 & CẮT Ứ ĐỘNG DOA (25 PHÚT): ---
                # Nếu lệnh chưa từng đạt được +0.30% (Peak < +0.30% -> 100% lệnh DOA không có sóng) và đang âm <= -0.60% kèm xu hướng nghịch EMA20 -> Cắt sớm!
                # Nếu lệnh đã từng có sóng (Peak >= +0.30%, ví dụ BR/USDT đạt +0.60% rồi chỉnh nhẹ) -> Chỉ siết SL về -1.00% để gồng tiếp!
                # ĐẶC BIỆT: MIỄN TRỪ NẾU VỊ THẾ ĐÃ CẮT GIẢM TẢI 50% (MODE 7 DE-RISKING):
                # Khi vị thế đã cắt 50% ở Nấc 1 (0.65 ATR) và siết Hard SL về 1.0 ATR, vị thế đang trong cơ chế
                # "đón 44.3% nhịp rút râu hồi phục về Hòa Vốn" (Bài học #14 & #15). Tuyệt đối không cưỡng bức đóng Market ở phút 25!
                if (doa25_enabled or ladder_sl_enabled) and held_minutes_chk >= 25.0:
                    has_derisked = bool(int(position.get('sl_stage_completed') or 0) >= 1 or position.get('partial_sl_done'))
                    if doa25_enabled and pnl_pct_chk <= -0.006 and peak_profit_pct < 0.0030 and is_adverse_ema and not position.get('partial_tp_done') and not has_derisked:
                        logger.warning(
                            f"🛑 [CẮT LỖ SỚM - 25 PHÚT Ứ ĐỘNG DOA] {position['symbol']} ({direction}) "
                            f"ngâm 25m không có lực bứt phá (Peak={peak_profit_pct*100:+.2f}% < +0.30%, PnL: {pnl_pct_chk*100:+.2f}% <= -0.6%, Adverse EMA)! Đóng Market giải phóng vốn."
                        )
                        self._close_position(position, current_price, close_reason=f"Cắt lỗ sớm 25m ứ đọng (PnL: {pnl_pct_chk*100:+.2f}%)")
                        continue
                    elif ladder_sl_enabled and not position.get('time_sl_compressed_25m') and not position.get('_time_sl_checked_25m'):
                        proposed_sl_25m = entry_price_chk * (1.0 - 0.010) if direction == 'LONG' else entry_price_chk * (1.0 + 0.010)
                        improves_25m = (proposed_sl_25m > curr_sl_val) if direction == 'LONG' else (proposed_sl_25m < curr_sl_val)
                        if not improves_25m:
                            position['_time_sl_checked_25m'] = True
                        elif pos_amount > 0:
                            is_breached_25m = (current_price <= proposed_sl_25m) if direction == 'LONG' else (current_price >= proposed_sl_25m)
                            if is_breached_25m:
                                logger.warning(f"🛡️ [CO HẸP SL 25M] Giá đã chạm ngưỡng siết -1.0% ({proposed_sl_25m:.6g}). Đóng Market!")
                                self._close_position(position, current_price, close_reason="🛡️ Co hẹp SL 25m chạm giá")
                                continue
                            old_sl_id = str(position.get('sl_order_id') or '')
                            sl_confirmed = not is_live_fut
                            if is_live_fut:
                                try:
                                    new_sl_order = self.exchange.create_stop_market_order(position['symbol'], close_side, pos_amount, proposed_sl_25m)
                                    new_info = (new_sl_order or {}).get('info') or {}
                                    new_sl_id = str((new_sl_order or {}).get('id') or new_info.get('algoId') or new_info.get('orderId') or '')
                                    if new_sl_id:
                                        sl_confirmed = True
                                        if old_sl_id and old_sl_id != new_sl_id:
                                            try:
                                                self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                            except Exception:
                                                position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                        position['sl_order_id'] = new_sl_id
                                    else:
                                        logger.error(f"Binance chưa xác nhận SL 25m mới cho {position['symbol']}; giữ SL cũ.")
                                except Exception as e:
                                    logger.error(f"Lỗi siết SL 25m cho {position['symbol']}: {e}")
                            if sl_confirmed:
                                position['time_sl_compressed_25m'] = True
                                position['_time_sl_checked_25m'] = True
                                position['stop_loss'] = proposed_sl_25m
                                curr_sl_val = proposed_sl_25m
                                self._save_state()
                                logger.info(f"🛡️ [CO HẸP SL 25M] {position['symbol']} ({direction}) đi ngang 25m, siết SL về -1.0% ({proposed_sl_25m:.6g}).")

                # --- 4. HẠN CHÓT THỜI GIAN (35 PHÚT): CẤM NGÂM VỐN LỆNH CHẾT YỂU (DOA) HOẶC SIẾT SL VỀ -0.55% ---
                if (doa35_enabled or ladder_sl_enabled) and held_minutes_chk >= 35.0 and pnl_pct_chk <= 0.0 and not position.get('partial_tp_done'):
                    # Thích ứng ngưỡng DOA theo ATR: với Vàng/Bạc (ATR ~0.43%), ngưỡng đòi hỏi là 0.22% thay vì cứng 0.35%
                    is_cmdty_pos = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(position.get('symbol', ''), self.exchange)
                    min_doa_peak = 0.0020 if is_cmdty_pos else 0.0035
                    if doa35_enabled and peak_profit_pct < min_doa_peak and is_adverse_ema:
                        logger.warning(
                            f"🛑 [THOÁT LỆNH QUÁ HẠN 35 PHÚT DOA] {position['symbol']} ({direction}) "
                            f"đã ngâm {held_minutes_chk:.0f} phút mà không sinh lời (Peak={peak_profit_pct*100:+.2f}% < +0.35%, PnL: {pnl_pct_chk*100:+.2f}%)! Đóng Market dứt khoát."
                        )
                        self._close_position(position, current_price, close_reason=f"Thoát quá hạn 35m không lãi (PnL {pnl_pct_chk*100:+.2f}%)")
                        continue
                    elif ladder_sl_enabled and not position.get('time_sl_compressed_35m') and not position.get('_time_sl_checked_35m'):
                        proposed_sl_35m = entry_price_chk * (1.0 - 0.0055) if direction == 'LONG' else entry_price_chk * (1.0 + 0.0055)
                        improves_35m = (proposed_sl_35m > curr_sl_val) if direction == 'LONG' else (proposed_sl_35m < curr_sl_val)
                        if not improves_35m:
                            position['_time_sl_checked_35m'] = True
                        elif pos_amount > 0:
                            is_breached_35m = (current_price <= proposed_sl_35m) if direction == 'LONG' else (current_price >= proposed_sl_35m)
                            if is_breached_35m:
                                logger.warning(f"🛡️ [CO HẸP SL 35M] Giá đã chạm ngưỡng siết -0.55% ({proposed_sl_35m:.6g}). Đóng Market!")
                                self._close_position(position, current_price, close_reason="🛡️ Co hẹp SL 35m chạm giá")
                                continue
                            old_sl_id = str(position.get('sl_order_id') or '')
                            sl_confirmed = not is_live_fut
                            if is_live_fut:
                                try:
                                    new_sl_order = self.exchange.create_stop_market_order(position['symbol'], close_side, pos_amount, proposed_sl_35m)
                                    new_info = (new_sl_order or {}).get('info') or {}
                                    new_sl_id = str((new_sl_order or {}).get('id') or new_info.get('algoId') or new_info.get('orderId') or '')
                                    if new_sl_id:
                                        sl_confirmed = True
                                        if old_sl_id and old_sl_id != new_sl_id:
                                            try:
                                                self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=True)
                                            except Exception:
                                                position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                        position['sl_order_id'] = new_sl_id
                                    else:
                                        logger.error(f"Binance chưa xác nhận SL 35m mới cho {position['symbol']}; giữ SL cũ.")
                                except Exception as e:
                                    logger.error(f"Lỗi siết SL 35m cho {position['symbol']}: {e}")
                            if sl_confirmed:
                                position['time_sl_compressed_35m'] = True
                                position['_time_sl_checked_35m'] = True
                                position['stop_loss'] = proposed_sl_35m
                                curr_sl_val = proposed_sl_35m
                                self._save_state()
                                logger.info(f"🛡️ [CO HẸP SL 35M] {position['symbol']} ({direction}) ngâm 35m, siết SL về -0.55% ({proposed_sl_35m:.6g}).")

                # --- 5. HẠN CHÓT 60 PHÚT: DÙNG CHUNG SÀN BE TÍNH PHÍ + BUFFER VỚI ADAPTIVE TRAILING ---
                if held_minutes_chk >= 60.0 and pnl_pct_chk > 0.0025 and pos_amount > 0 and position.get('partial_tp_done'):
                    be_floor_60m = self._fee_safe_breakeven_stop(position)
                    old_sl_id = str(position.get('sl_order_id') or '')
                    current_sl_60m = float(curr_sl_val or 0.0)
                    already_fee_safe = self._stop_meets_fee_safe_breakeven(position, current_sl_60m)
                    current_sl_unbreached = (
                        current_price > current_sl_60m if direction == 'LONG'
                        else current_price < current_sl_60m
                    )
                    existing_stop_confirmed = (
                        not is_live_fut
                        or (
                            bool(old_sl_id)
                            and position.get('protection_status') == 'exchange_stop_verified'
                        )
                    )

                    if already_fee_safe and current_sl_unbreached and existing_stop_confirmed:
                        be_60m_ok = True
                        proposed_sl_60m = current_sl_60m
                    else:
                        proposed_sl_60m = (
                            max(current_sl_60m, be_floor_60m)
                            if direction == 'LONG'
                            else min(current_sl_60m, be_floor_60m)
                        )
                        safely_spaced = self._stop_has_minimum_market_buffer(
                            direction, proposed_sl_60m, current_price
                        )
                        improves_60m = (
                            proposed_sl_60m > current_sl_60m
                            if direction == 'LONG'
                            else proposed_sl_60m < current_sl_60m
                        )
                        be_60m_ok = False

                        if not safely_spaced:
                            if not position.get('_time_be_60m_wait_logged'):
                                logger.info(
                                    "[BE 60M CHỜ] %s chưa đủ khoảng đệm 0.22%% để đặt SL phí-an-toàn; giữ SL hiện tại và thử lại.",
                                    position['symbol'],
                                )
                                position['_time_be_60m_wait_logged'] = True
                                self._save_state()
                        elif improves_60m and is_live_fut:
                            try:
                                new_sl_order = self.exchange.create_stop_market_order(
                                    position['symbol'], close_side, pos_amount, proposed_sl_60m
                                )
                                new_sl_id = self._conditional_order_id(new_sl_order or {})
                                if new_sl_id:
                                    be_60m_ok = True
                                    position['sl_order_id'] = new_sl_id
                                    position['protection_status'] = 'exchange_stop_verified'
                                    if old_sl_id and old_sl_id != new_sl_id:
                                        try:
                                            self.exchange.cancel_order(
                                                old_sl_id, position['symbol'], trigger=True, strict=True
                                            )
                                        except Exception:
                                            position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                else:
                                    logger.error(
                                        "Binance chưa xác nhận ID SL BE 60m mới cho %s; giữ SL cũ.",
                                        position['symbol'],
                                    )
                            except Exception as e:
                                logger.error(f"Lỗi khóa BE 60m cho {position['symbol']}: {e}")
                        elif improves_60m:
                            be_60m_ok = True

                    if be_60m_ok:
                        position.pop('_time_be_60m_wait_logged', None)
                        state_changed = (
                            not position.get('time_be_locked_60m')
                            or not position.get('breakeven_protection_confirmed')
                            or float(position.get('stop_loss') or 0.0) != proposed_sl_60m
                        )
                        position['time_be_locked_60m'] = True
                        position['breakeven_protection_confirmed'] = True
                        position['breakeven_protection_source'] = 'time_60m'
                        position['stop_loss'] = proposed_sl_60m
                        curr_sl_val = proposed_sl_60m
                        if state_changed:
                            self._save_state()
                            logger.info(
                                "🛡️ [KHÓA HÒA VỐN 60M] %s (%s) ngâm 60m, SL=%0.8f; phí/buffer đã tính, lãi hiện tại=%+.2f%%.",
                                position['symbol'], direction, proposed_sl_60m, pnl_pct_chk * 100.0,
                            )
                        self._queue_breakeven_telegram(position, proposed_sl_60m, 'time_60m')

                # --- 6. HẠN CHÓT 120 PHÚT (8 NẾN 15M): THOÁT LỆNH ĐỌNG VỐN NẾU THỊ TRƯỜNG ĐI NGANG RU NGỦ ---
                if idle120_enabled and held_minutes_chk >= 120.0 and not position.get('partial_tp_done'):
                    logger.warning(
                        f"🛑 [THOÁT LỆNH ĐỌNG VỐN 120 PHÚT] {position['symbol']} ({direction}) "
                        f"đã ngâm 120 phút (8 nến 15m) mà không tới TP (PnL: {pnl_pct_chk*100:+.2f}%)! Đóng Market dứt khoát giải phóng slot."
                    )
                    self._close_position(position, current_price, close_reason=f"Thoát đọng vốn 120m giải phóng slot (PnL: {pnl_pct_chk*100:+.2f}%)")
                    continue

                # --- 7. THỬ LẠI CHOKE SL SAU KHI RÂU NẾN HỒI PHỤC (AUTO-RETRY CHOKE SL) ---
                if position.get('choke_sl_pending') and position.get('choke_sl_target') and pos_amount > 0:
                    target_choke = float(position['choke_sl_target'])
                    raw_atr_pct = risk_atr_pct
                    safe_choke_buf = min(0.0080, max(0.0035, 0.15 * raw_atr_pct))
                    can_place_choke = False
                    if direction == 'LONG' and current_price >= target_choke * (1.0 + safe_choke_buf):
                        can_place_choke = True
                    elif direction == 'SHORT' and current_price <= target_choke * (1.0 - safe_choke_buf):
                        can_place_choke = True
                    
                    if can_place_choke:
                        old_sl_id = str(position.get('sl_order_id') or '')
                        choke_placed_ok = not is_live_fut
                        if is_live_fut:
                            try:
                                new_sl_order = self.exchange.create_stop_market_order(
                                    position['symbol'], close_side, pos_amount, target_choke
                                )
                                new_sl_info = (new_sl_order or {}).get('info') or {}
                                new_sl_id = str((new_sl_order or {}).get('id') or new_sl_info.get('algoId') or new_sl_info.get('orderId') or '')
                                if new_sl_id:
                                    choke_placed_ok = True
                                    if old_sl_id and old_sl_id != new_sl_id:
                                        try:
                                            self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=False)
                                        except Exception:
                                            position.setdefault('stale_sl_order_ids', []).append(old_sl_id)
                                    position['sl_order_id'] = new_sl_id
                            except Exception as e:
                                logger.error(f"Lỗi đặt lại Choke SL sau hồi phục cho {position['symbol']}: {e}")
                        if choke_placed_ok:
                            position.pop('choke_sl_pending', None)
                            position.pop('choke_sl_target', None)
                            position['stop_loss'] = target_choke
                            curr_sl_val = target_choke
                            self._save_state()
                            logger.info(
                                f"🛡️ [CHOKE SL HOÀN TẤT SAU HỒI PHỤC] {position['symbol']} ({direction}) "
                                f"đã hồi phục thoát khỏi râu giật, khóa thành công Hard SL 1.0 ATR tại {target_choke:.6g} trên Binance!"
                            )

                # --- 8. CO HẸP STOP LOSS DÍ THEO ĐÀ HỒI PHỤC (LOSS RECOVERY TRAILING RATCHET) ---\n                # [BÀI HỌC 92]: VÔ HIỆU HÓA HOÀN TOÀN MỤC 8 ĐỂ TRÁNH XUNG ĐỘT VỚI OPTION C (2-TIER BREAKEVEN 4.5M)\n                # VÀ BẢO VỆ TUYỆT ĐỐI KHÔNG GIAN THỞ CHO VỊ THẾ HỒI PHỤC.\n                # Căn nguyên: Khi vị thế vừa chớm xanh (+0.35%), Mục 8 đã vội vã siết SL lên -0.40% hoặc 0.65 ATR\n                # (như Q/USDT kéo SL từ 0.02684 lên 0.02698), tước đoạt toàn bộ vùng thở khiến lệnh bị quét sạch\n                # ở nhịp rung lắc nhẹ (-0.2193$ oan uổng). Toàn bộ nhiệm vụ bảo toàn vốn và khóa hòa vốn\n                # ĐÃ ĐƯỢC ĐẢM NHẬN AN TOÀN TUYỆT ĐỐI BỞI OPTION C (+0.80% MFE kèm khóa 4.5 phút) VÀ TRAILING STOP!\n                pass\n\n                # Adaptive trailing: ATR sets the breathing room, ADX adjusts it
                # to the symbol's trend regime, and the stop activates only after
                # it can protect estimated net profit after costs.
                if self.config.get('risk', {}).get('use_trailing_stop', False):
                    try:
                        metrics = self._adaptive_trailing_metrics(position, current_price)
                        trail_pct = float(metrics['distance_pct'])
                        entry_price = float(position.get('entry_price') or 0)
                        current_sl = float(position.get('stop_loss') or 0)
                        if entry_price <= 0 or current_sl <= 0:
                            continue

                        old_best = position.get('trailing_best_price')
                        try:
                            old_best = float(old_best) if old_best is not None else None
                        except (TypeError, ValueError, OverflowError):
                            old_best = None
                        if direction == 'LONG':
                            best_price = max(entry_price, current_price, old_best or 0)
                        else:
                            best_price = min(
                                value for value in (entry_price, current_price, old_best)
                                if value is not None and value > 0
                            )
                        best_changed = old_best is None or abs(best_price - old_best) > max(entry_price * 1e-8, 1e-12)

                        position['trailing_best_price'] = best_price
                        position['trailing_distance_pct'] = trail_pct
                        position['trailing_atr_pct'] = metrics.get('atr_pct')
                        position['trailing_adx'] = metrics.get('adx')
                        position['trailing_regime'] = metrics.get('regime', 'fallback')
                        profile = metrics.get('profile') or self._get_asset_adaptive_trailing_profile(position.get('symbol', ''))
                        net_breakeven = self._trailing_net_breakeven(position)
                        if position.get('breakeven_protection_confirmed'):
                            self._queue_breakeven_telegram(
                                position,
                                float(position.get('stop_loss') or 0.0),
                                str(position.get('breakeven_protection_source') or 'adaptive'),
                            )
                        try:
                            lock_profit_pct = float(
                                self.config.get('risk', {}).get('trailing_min_lock_profit_pct', 0.001)
                            )
                        except (TypeError, ValueError, OverflowError):
                            lock_profit_pct = 0.001
                        lock_profit_pct = min(0.05, max(0.0, lock_profit_pct))
                        # ƯU TIÊN ĐẶC BIỆT CHO CÁC NHÁNH CHUYỂN HÓA (SMART DUAL-PHASE INVERSION MATRIX):
                        # Chốt lời 50% tiền tươi tại TP1 và mở khóa gồng lãi TP2 đón siêu sóng
                        if position.get('is_momentum_ride'):
                            partial_tp_trigger = 0.0150
                        elif position.get('is_fading_short') or position.get('is_waterfall_short'):
                            partial_tp_trigger = 0.0180
                        elif position.get('is_oversold_bounce'):
                            partial_tp_trigger = 0.0150
                        elif self.config.get('risk', {}).get('enable_micro_adaptive_partial_tp', True):
                            raw_atr = metrics.get('atr_pct')
                            atr_pct_val = float(raw_atr) if (raw_atr is not None and math.isfinite(float(raw_atr)) and float(raw_atr) > 0) else 0.01
                            regime_val = metrics.get('regime', 'ranging')
                            regime_mult = 1.15 if regime_val == 'trend_favorable' else (0.85 if regime_val == 'trend_adverse' else 1.00)
                            risk_cfg = self.config.get('risk', {}) or {}
                            micro_k = float(risk_cfg.get('partial_tp_atr_multiplier', 0.88))
                            # [BAI HOC 68 - KICH BAN D & BAI HOC 75] Khung clamp hop nhat cho TP1.
                            # Trước đây mỗi lớp tài sản kẹp TP1 trong dải riêng (Altcoin 1.10-1.50%,
                            # Major 0.85-1.15%, Stock 0.90-1.40%, ETF 1.10-1.70%) nên nới hệ số ATR
                            # cũng không mở được TP1 ở các lớp có trần thấp. Khi bat co nay, TP1 dùng
                            # đúng dải đã mô phỏng 226 chu kỳ thật: ATR x 1.30 kẹp [1.30%, 2.20%].
                            # Riêng Hàng hóa TradFi (TRADFI_COMMODITY: Vàng XAU, Bạc XAG, Dầu CL/BZ) với đặc thù ATR 15m nén
                            # (0.25% - 0.45%), dùng trực tiếp profile [0.80%, 1.25%] để đảm bảo khả năng chạm đích chốt lời tiền tươi 50%
                            # và dời Hard BE bảo vệ Runner mà không bị kẹt bởi trần tối thiểu 1.30%!
                            # Tắt cờ -> quay lại nguyên trạng profile theo từng lớp tài sản.
                            if bool(risk_cfg.get('partial_tp_unified_bounds', False)) and profile.get('asset_class') != 'TRADFI_COMMODITY':
                                min_ptp = float(risk_cfg.get('partial_tp_min_pct', 0.0130))
                                max_ptp = float(risk_cfg.get('partial_tp_max_pct', 0.0220))
                            else:
                                min_ptp = float(profile.get('partial_tp_min', risk_cfg.get('partial_tp_min_pct', 0.0075)))
                                max_ptp = float(profile.get('partial_tp_max', risk_cfg.get('partial_tp_max_pct', 0.0135)))
                            if min_ptp > max_ptp:
                                min_ptp, max_ptp = max_ptp, min_ptp
                            partial_tp_trigger = min(max_ptp, max(min_ptp, atr_pct_val * micro_k * regime_mult))
                        else:
                            partial_tp_trigger = float(profile.get('partial_tp_trigger', self.config.get('risk', {}).get('partial_tp_trigger_pct', 0.0105)))
                        position['dynamic_partial_tp_trigger'] = partial_tp_trigger

                        # CÔNG THỨC TOÁN HỌC KHÓA HÒA VỐN THÍCH ỨNG ATR (ATR-ADAPTIVE BREAKEVEN TRIGGER):
                        # Kế thừa đầy đủ profile của từng lớp tài sản (0.80% Altcoin, 0.75% Major, 0.65% TradFi)
                        # và luôn kẹp chặt < 85% partial_tp_trigger (trần 0.95%) để không bao giờ đảo ngược cao hơn điểm chốt lời TP1!
                        raw_atr_be = metrics.get('atr_pct')
                        atr_pct_be = float(raw_atr_be) if (raw_atr_be is not None and math.isfinite(float(raw_atr_be)) and float(raw_atr_be) > 0) else 0.012
                        profile_be = float(profile.get('breakeven_trigger', 0.0080))
                        if position.get('be_trigger_override'):
                            breakeven_trigger_pct = float(position['be_trigger_override'])
                        else:
                            breakeven_trigger_pct = min(partial_tp_trigger * 0.85, max(profile_be, min(0.0095, 0.40 * atr_pct_be)))
                        position['trailing_net_breakeven'] = net_breakeven

                        initial_sl = float(position.get('initial_sl', position.get('stop_loss', 0)))
                        if initial_sl == 0: initial_sl = current_sl
                        
                        r_dist = abs(entry_price - initial_sl)
                        if r_dist <= 0: r_dist = entry_price * 0.01

                        current_profit_pct = (current_price - entry_price) / entry_price if direction == 'LONG' else (entry_price - current_price) / entry_price
                        old_sustained = float(position.get('max_sustained_profit_pct') or 0.0)
                        max_sustained_profit_pct = max(old_sustained, current_profit_pct)

                        held_minutes = 0.0
                        pos_timestamp_str = position.get('timestamp')
                        try:
                            if pos_timestamp_str:
                                pos_dt = datetime.fromisoformat(pos_timestamp_str)
                                held_minutes = (datetime.now() - pos_dt).total_seconds() / 60.0
                        except Exception:
                            pass

                        # =========================================================================
                        # DYNAMIC ADAPTIVE STAGING ENGINE: CẮT LỖ GIẢM TẢI ĐA NẤC TỰ ĐỘNG THÍCH ỨNG
                        # (DYNAMIC ADAPTIVE DE-RISKING SCALE-OUT)
                        # =========================================================================
                        atr_val_pct_loss = float(metrics.get('atr_pct') or 0.012)
                        staged_sl_trigger = min(0.0130, max(0.0080, 0.65 * atr_val_pct_loss))
                        current_loss_pct = (entry_price - current_price) / entry_price if direction == 'LONG' else (current_price - entry_price) / entry_price
                        
                        total_sl_stages = self._calc_adaptive_stages(position, current_price)
                        position['sl_stages_total'] = total_sl_stages
                        sl_stage_completed = int(position.get('sl_stage_completed') or 0)
                        
                        # Bảng hệ số khoảng cách nấc kích hoạt theo từng cấp
                        stage_mult_table = {
                            1: [1.0],
                            2: [1.0],
                            3: [1.0, 1.8],
                            4: [1.0, 1.7, 2.4],
                            5: [0.9, 1.5, 2.1, 2.7]
                        }
                        stage_mults = stage_mult_table.get(total_sl_stages, [1.0])
                        
                        # [BAI HOC 68] Lệnh tay: chỉ hỗ trợ SL/TP/Trailing, KHÔNG tự cắt giảm tải
                        # hay xả khẩn cấp 100% theo phán đoán của bot.
                        is_manual_pos = self._is_manual_position(position)
                        if total_sl_stages >= 1 and not position.get('partial_sl_done') and not position.get('partial_tp_done') and not is_manual_pos:
                            next_stage = sl_stage_completed + 1
                            if next_stage <= len(stage_mults):
                                target_threshold = stage_mults[next_stage - 1] * staged_sl_trigger
                                if current_loss_pct >= (target_threshold - 1e-6) and held_minutes >= 1.0:
                                    # =========================================================================
                                    # TELEMETRY GATE ENGINE: ĐO LƯỜNG VOLUME XẢ & TỐC ĐỘ RƠI TẠI NẤC 1
                                    # =========================================================================
                                    rvol = float(metrics.get('rvol') or 1.0)
                                    # ĐỊNH NGHĨA CHUẨN XÁC DUMP KHẨN CẤP:
                                    # 1) Cá mập xả áp đảo với khối lượng lớn rvol >= 1.6x
                                    # HOẶC
                                    # 2) Sập gãy cực nhanh (<= 3 phút) với biên độ sâu >= 1.1 ATR và volume gia tăng rvol >= 1.3x
                                    # Triệt tiêu hoàn toàn lỗi 'or held_minutes <= 15.0' làm 100% vị thế 15m đầu bị cắt oan!
                                    is_whale_dump = (rvol >= 1.6) or (rvol >= 1.3 and current_loss_pct >= 1.1 * atr_val_pct_loss and held_minutes <= 3.0)

                                    if next_stage == 1 and is_whale_dump:
                                        logger.warning(
                                            f"🚨 [TELEMETRY GATE: DUMP KHẨN CẤP] {position['symbol']} ({direction}) chạm Nấc 1 (-{current_loss_pct*100:.2f}%) "
                                            f"với RVol={rvol:.2f} >= 1.6x hoặc gãy sâu ({held_minutes:.1f}m <= 3m, lỗ {current_loss_pct*100:.2f}%). "
                                            f"Đóng 100% vị thế khẩn cấp để ngăn chặn rơi sâu 1.5 ATR!"
                                        )
                                        self._notify_telegram(
                                            f"🚨 **[TELEMETRY GATE: DUMP KHẨN CẤP]**\n"
                                            f"• Cặp: `{position['symbol']}` ({direction})\n"
                                            f"• Lỗ hiện tại: `-{current_loss_pct*100:.2f}%` (Chạm Nấc 1: 0.65 ATR)\n"
                                            f"• Tín hiệu: Volume xả `{rvol:.2f}x` trung bình / Thời gian giữ `{held_minutes:.1f} phút`\n"
                                            f"• Quyết định: **ĐÓNG HẲN 100% VỊ THẾ** bảo vệ an toàn tài khoản!"
                                        )
                                        self._close_position_locked(position, current_price, 'telemetry_emergency_dump')
                                        continue

                                    if 'initial_amount' not in position:
                                        position['initial_amount'] = float(position.get('amount') or 0)
                                    init_amt = float(position['initial_amount'])
                                    curr_amt = float(position.get('amount') or 0)
                                    if next_stage == 1 and total_sl_stages >= 2:
                                        # Mode 7 & Lesson 14/15: Ở Nấc 1, ưu tiên cắt 50% để bảo vệ 45.8% vốn và giảm rủi ro
                                        target_cut_pct = 0.50
                                        candidate_chunk = init_amt * target_cut_pct
                                        est_candidate_notional = candidate_chunk * current_price
                                        est_candidate_rem = (curr_amt - candidate_chunk) * current_price
                                        if est_candidate_notional >= 5.00 and est_candidate_rem >= 5.00:
                                            chunk_amt = candidate_chunk
                                        else:
                                            chunk_amt = init_amt / float(total_sl_stages)
                                    else:
                                        chunk_amt = init_amt / float(total_sl_stages)
                                    chunk_amt = min(curr_amt, chunk_amt)
                                    
                                    est_chunk_notional = chunk_amt * current_price
                                    rem_after_cut = max(0.0, curr_amt - chunk_amt)
                                    est_rem_notional = rem_after_cut * current_price
                                    is_live_fut = (self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures')
                                    
                                    # Kiểm tra an toàn sàn Binance: chunk và phần còn lại (nếu chưa phải nấc chót) phải >= 5.00 USDT
                                    if total_sl_stages == 1 or (is_live_fut and (est_chunk_notional < 5.00 or (next_stage < total_sl_stages and est_rem_notional < 5.00))):
                                        logger.info(
                                            f"Vị thế {position['symbol']} nấc {next_stage}/{total_sl_stages} "
                                            f"có notional ({est_chunk_notional:.2f} USDT) hoặc phần còn lại ({est_rem_notional:.2f} USDT) < 5 USDT sàn; "
                                            f"dừng cắt từng phần và siết SL cứng về 1.0 ATR bảo vệ vốn."
                                        )
                                        position['partial_sl_done'] = True
                                        choke_sl_dist = 1.0 * atr_val_pct_loss * entry_price
                                        proposed_choke_sl = None
                                        # Đệm an toàn thích ứng theo ATR (tối thiểu 0.35%) chống lỗi sàn -2021 Immediately Trigger
                                        safe_choke_buf = min(0.0080, max(0.0035, 0.15 * atr_val_pct_loss))
                                        # [BÀI HỌC 91]: Triệt tiêu bẫy bóp nghẹt 0.35% (The 0.35% Suffocation Trap).
                                        # CHỈ siết SL về 1.0 ATR nếu mức 1.0 ATR vẫn cách giá hiện tại một khoảng an toàn (>= safe_choke_buf).
                                        # Tuyệt đối KHÔNG gán SL = current_price * (1 - 0.0035) khi giá đã sập sâu qua 1.0 ATR!
                                        if direction == 'LONG':
                                            choke_sl_price = entry_price - choke_sl_dist
                                            safe_market_sl = current_price * (1.0 - safe_choke_buf)
                                            if choke_sl_price <= safe_market_sl and choke_sl_price > float(position.get('stop_loss') or 0.0):
                                                proposed_choke_sl = choke_sl_price
                                        else:
                                            choke_sl_price = entry_price + choke_sl_dist
                                            safe_market_sl = current_price * (1.0 + safe_choke_buf)
                                            if choke_sl_price >= safe_market_sl and choke_sl_price < float(position.get('stop_loss') or 999999):
                                                proposed_choke_sl = choke_sl_price
                                        old_sl_id = str(position.get('sl_order_id') or '')
                                        if proposed_choke_sl is not None and curr_amt > 0:
                                            if is_live_fut:
                                                try:
                                                    close_side = 'sell' if direction == 'LONG' else 'buy'
                                                    if direction == 'LONG':
                                                        proposed_choke_sl = min(float(proposed_choke_sl), current_price * (1.0 - safe_choke_buf))
                                                    else:
                                                        proposed_choke_sl = max(float(proposed_choke_sl), current_price * (1.0 + safe_choke_buf))
                                                    new_sl = self.exchange.create_stop_market_order(
                                                        position['symbol'], close_side, curr_amt, float(proposed_choke_sl)
                                                    )
                                                    if isinstance(new_sl, dict) and new_sl.get('error') == 'immediately_triggered':
                                                        logger.warning(
                                                            f"⏳ [CHOKE SL HOÃN DO RÂU GIẬT] Mức SL siết 1.0 ATR {proposed_choke_sl:.6g} cho {position['symbol']} "
                                                            f"quá sát giá thị trường ({current_price:.6g}) gây -2021 Immediately Trigger. "
                                                            f"GIỮ NGUYÊN HARD SL SÀN CŨ ({old_sl_id}) bảo vệ vị thế, chờ giá hồi phục sẽ tự động đặt lại SL 1.0 ATR!"
                                                        )
                                                        position['choke_sl_pending'] = True
                                                        position['choke_sl_target'] = float(proposed_choke_sl)
                                                        self._save_state()
                                                        continue
                                                    new_sl_info = (new_sl or {}).get('info') or {}
                                                    new_sl_id = str((new_sl or {}).get('id') or new_sl_info.get('algoId') or new_sl_info.get('orderId') or '')
                                                    if new_sl_id:
                                                        previous_sl_price = float(position.get('stop_loss') or 0.0)
                                                        position['stop_loss'] = proposed_choke_sl
                                                        position['sl_order_id'] = new_sl_id
                                                        old_cancelled = False
                                                        if old_sl_id and old_sl_id != new_sl_id:
                                                            try:
                                                                self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=False)
                                                                old_cancelled = True
                                                            except Exception:
                                                                pass
                                                        # [P4] Trước đây nhánh thành công không để lại dấu vết nào trong log,
                                                        # nên không thể kiểm toán việc siết SL có thật sự xảy ra hay không.
                                                        tighten_pct = (
                                                            abs(proposed_choke_sl - previous_sl_price) / previous_sl_price
                                                            if previous_sl_price > 0 else 0.0
                                                        )
                                                        cancel_note = f" | đã hủy SL cũ {old_sl_id}" if old_cancelled else ""
                                                        logger.warning(
                                                            f"🛡️ [CHOKE SL 1.0 ATR ĐÃ XÁC NHẬN] {position['symbol']} ({direction}): "
                                                            f"SL {previous_sl_price:.6g} -> {proposed_choke_sl:.6g} (siết {tighten_pct*100:.3f}%), "
                                                            f"KL còn lại {curr_amt:.6g}, SL mới id={new_sl_id}{cancel_note}."
                                                        )
                                                except Exception as e:
                                                    logger.error(f"Lỗi siết SL 1.0 ATR cho {position['symbol']}: {e}")
                                            else:
                                                position['stop_loss'] = proposed_choke_sl
                                        self._save_state()
                                        continue
                                    else:
                                        partial_sl_ok = False
                                        filled_amt = chunk_amt
                                        p_order = None
                                        if is_live_fut:
                                            try:
                                                p_order = self.exchange.close_futures_position(position['symbol'], direction, chunk_amt)
                                                if p_order and (p_order.get('id') or (p_order.get('info') or {}).get('orderId')):
                                                    filled_amt = self._confirmed_filled_amount(p_order, position['symbol'], chunk_amt)
                                                    partial_sl_ok = filled_amt > 0
                                                    if not partial_sl_ok:
                                                        logger.warning("Sàn chưa xác nhận fill Partial SL cho %s; giữ nguyên vị thế.", position['symbol'])
                                                else:
                                                    logger.warning(f"Lệnh cắt giảm tải nấc {next_stage}/{total_sl_stages} cho {position['symbol']} không trả về ID: {p_order}")
                                            except Exception as pe:
                                                logger.error(f"Lỗi gửi lệnh cắt giảm tải nấc {next_stage}/{total_sl_stages} cho {position['symbol']}: {pe}")
                                        else:
                                            partial_sl_ok = True
                                            
                                        if partial_sl_ok:
                                            if 'initial_cost' not in position:
                                                position['initial_cost'] = float(position.get('cost') or 0)
                                            rem_amt = max(0.0, curr_amt - filled_amt)
                                            if curr_amt > 0:
                                                position['entry_fee'] = float(position.get('entry_fee', 0.0) or 0.0) * (rem_amt / curr_amt)
                                            position['amount'] = rem_amt
                                            init_amt_val = float(position.get('initial_amount') or curr_amt)
                                            if init_amt_val > 0:
                                                position['cost'] = float(position.get('initial_cost', position.get('cost', 0.0))) * (rem_amt / init_amt_val)
                                            position['sl_stage_completed'] = next_stage
                                            if next_stage >= total_sl_stages - 1 or rem_amt <= 0:
                                                position['partial_sl_done'] = True
                                            position['partial_sl_price'] = current_price
                                            taker_fee_rate = 0.0005 if is_live_fut else max(0.0, float(self.config.get('trading', {}).get('fee_rate', 0.001)))
                                            # entry_fee đã được phân bổ theo khối lượng còn lại; ở đây chỉ
                                            # trừ phí của fill đóng, không tính lại phí vào một lần nữa.
                                            part_fee = current_price * filled_amt * taker_fee_rate
                                            part_loss = ((current_price - entry_price) * filled_amt if direction == 'LONG' else (entry_price - current_price) * filled_amt) - part_fee
                                            position['partial_sl_pnl'] = float(position.get('partial_sl_pnl', 0.0)) + part_loss
                                            if not is_live_fut:
                                                self.balance += part_loss
                                            try:
                                                part_sl_oid = (
                                                    (p_order or {}).get('id')
                                                    or ((p_order or {}).get('info') or {}).get('orderId')
                                                    or f"partial-sl-{int(time.time() * 1000)}"
                                                )
                                                self.db.save_trade({
                                                    'symbol': position['symbol'],
                                                    'side': ('buy' if direction == 'SHORT' else 'sell'),
                                                    'type': ('market' if self.mode == 'live' else 'limit'),
                                                    'price': current_price,
                                                    'amount': filled_amt,
                                                    'cost': current_price * filled_amt,
                                                    'fee': part_fee,
                                                    'pnl': part_loss,
                                                    'strategy': position.get('strategy', 'unknown'),
                                                    'status': 'closed',
                                                    'order_id': str(part_sl_oid),
                                                    'timestamp': int(time.time() * 1000),
                                                    'mode': self.mode,
                                                })
                                                if self.mode == 'live':
                                                    import threading
                                                    threading.Thread(
                                                        target=self.sync_live_trades_from_exchange,
                                                        name='partial-sl-trade-sync',
                                                        daemon=True,
                                                    ).start()
                                            except Exception as dbe:
                                                logger.debug(f"Không thể ghi DB cho Partial SL {position['symbol']}: {dbe}")

                                            # CHOKE SL: Siết Hard SL của khối lượng còn lại từ 1.5 ATR về 1.0 ATR để đón nhịp rút râu hòa vốn
                                            choke_dist_pct = 1.00 * atr_val_pct_loss
                                            # [P3] Bất biến phòng vệ: SL bảo vệ KHÔNG được nằm trong vùng kích hoạt
                                            # của nấc kế tiếp, nếu không nấc đó vĩnh viễn không chạy được trên cú sập
                                            # thật (GTC/USDT: nấc 2 = 2.340% chỉ cách SL 1.0 ATR 2.394% đúng 0.054%).
                                            # Mặc định TẮT để không mở rộng rủi ro ngoài phạm vi đã duyệt; bật bằng
                                            # risk.choke_escape_next_stage khi mô phỏng chứng minh có lợi.
                                            risk_cfg_choke = self.config.get('risk') if isinstance(self.config.get('risk'), dict) else {}
                                            if bool(risk_cfg_choke.get('choke_escape_next_stage', False)) and \
                                                    (next_stage + 1) <= len(stage_mults):
                                                next_trigger_pct = stage_mults[next_stage] * staged_sl_trigger
                                                min_escape_pct = next_trigger_pct + max(0.0035, 0.20 * atr_val_pct_loss)
                                                if choke_dist_pct < min_escape_pct:
                                                    logger.info(
                                                        f"🛡️ [P3][CHOKE ESCAPE] {position['symbol']}: nấc {next_stage + 1} kích hoạt ở "
                                                        f"{next_trigger_pct*100:.3f}% nhưng SL 1.0 ATR chỉ {choke_dist_pct*100:.3f}% -> nới SL về "
                                                        f"{min_escape_pct*100:.3f}% để nấc kế tiếp còn cửa chạy."
                                                    )
                                                    choke_dist_pct = min_escape_pct
                                            choke_sl_dist = choke_dist_pct * entry_price
                                            target_sl_after_cut = float(position.get('stop_loss') or 0)
                                            # Đệm an toàn thích ứng theo ATR (tối thiểu 0.35%) chống lỗi sàn -2021 Immediately Trigger
                                            safe_choke_buf = min(0.0080, max(0.0035, 0.15 * atr_val_pct_loss))
                                            # [BÀI HỌC 91]: Triệt tiêu bẫy bóp nghẹt 0.35% (The 0.35% Suffocation Trap).
                                            # Khi cắt 50% giảm tải tại Nấc 1, CHỈ siết SL về 1.0 ATR nếu mức 1.0 ATR vẫn cách giá hiện tại một khoảng an toàn (>= safe_choke_buf).
                                            # Nếu giá đã sập sâu gần hoặc vượt 1.0 ATR, BẢO LƯU HARD SL 1.5 ATR BAN ĐẦU để 50% khối lượng còn lại
                                            # có trọn vẹn không gian thở đón 44.3% nhịp rút râu hồi phục về Hòa Vốn (đặc trị trường hợp AGT/USDT và HUMA/USDT)!
                                            if direction == 'LONG':
                                                choke_sl_price = entry_price - choke_sl_dist
                                                safe_market_sl = current_price * (1.0 - safe_choke_buf)
                                                if choke_sl_price <= safe_market_sl and choke_sl_price > target_sl_after_cut:
                                                    target_sl_after_cut = choke_sl_price
                                            else:
                                                choke_sl_price = entry_price + choke_sl_dist
                                                safe_market_sl = current_price * (1.0 + safe_choke_buf)
                                                if choke_sl_price >= safe_market_sl and choke_sl_price < float(position.get('stop_loss') or 999999):
                                                    target_sl_after_cut = choke_sl_price
                                            
                                            # Cập nhật lại Hard SL trên Binance cho khối lượng còn lại
                                            old_sl_id = str(position.get('sl_order_id') or '')
                                            if is_live_fut and target_sl_after_cut > 0 and rem_amt > 0:
                                                try:
                                                    close_side = 'sell' if direction == 'LONG' else 'buy'
                                                    # Kiểm tra an toàn: nếu target_sl_after_cut vi phạm khoảng cách tối thiểu với giá thị trường thì bảo lưu SL cũ
                                                    if direction == 'LONG' and target_sl_after_cut > current_price * (1.0 - safe_choke_buf):
                                                        logger.info(
                                                            "⏳ [CHOKE SL HOÃN] Mức SL siết %.6g cho %s quá sát giá (%.6g); bảo lưu Hard SL sàn cũ (%s).",
                                                            target_sl_after_cut, position['symbol'], current_price, old_sl_id
                                                        )
                                                        target_sl_after_cut = float(position.get('stop_loss') or 0.0)
                                                    elif direction == 'SHORT' and target_sl_after_cut < current_price * (1.0 + safe_choke_buf):
                                                        logger.info(
                                                            "⏳ [CHOKE SL HOÃN] Mức SL siết %.6g cho %s quá sát giá (%.6g); bảo lưu Hard SL sàn cũ (%s).",
                                                            target_sl_after_cut, position['symbol'], current_price, old_sl_id
                                                        )
                                                        target_sl_after_cut = float(position.get('stop_loss') or 0.0)
                                                    new_sl = self.exchange.create_stop_market_order(
                                                        position['symbol'], close_side, rem_amt, float(target_sl_after_cut)
                                                    )
                                                    if isinstance(new_sl, dict) and new_sl.get('error') == 'immediately_triggered':
                                                        logger.warning(
                                                            f"⏳ [CHOKE SL HOÃN DO RÂU GIẬT] Mức SL siết 1.0 ATR {target_sl_after_cut:.6g} cho phần còn lại của {position['symbol']} "
                                                            f"quá sát giá ({current_price:.6g}) gây -2021 Immediately Trigger. "
                                                            f"GIỮ NGUYÊN HARD SL SÀN CŨ ({old_sl_id}) bảo hiểm 100% rủi ro, chờ giá hồi phục sẽ tự động đặt lại SL 1.0 ATR!"
                                                        )
                                                        position['choke_sl_pending'] = True
                                                        position['choke_sl_target'] = float(target_sl_after_cut)
                                                        self._save_state()
                                                        continue
                                                    new_sl_info = (new_sl or {}).get('info') or {}
                                                    new_sl_id = str((new_sl or {}).get('id') or new_sl_info.get('algoId') or new_sl_info.get('orderId') or '')
                                                    if new_sl_id:
                                                        previous_sl_price = float(position.get('stop_loss') or 0.0)
                                                        position['stop_loss'] = target_sl_after_cut
                                                        position['sl_order_id'] = new_sl_id
                                                        old_cancelled = False
                                                        if old_sl_id and old_sl_id != new_sl_id:
                                                            try:
                                                                self.exchange.cancel_order(old_sl_id, position['symbol'], trigger=True, strict=False)
                                                                old_cancelled = True
                                                            except Exception:
                                                                pass
                                                        # [P4] Log nhánh thành công sau khi cắt giảm tải (trước đây im lặng).
                                                        tighten_pct = (
                                                            abs(target_sl_after_cut - previous_sl_price) / previous_sl_price
                                                            if previous_sl_price > 0 else 0.0
                                                        )
                                                        cancel_note = f" | đã hủy SL cũ {old_sl_id}" if old_cancelled else ""
                                                        logger.warning(
                                                            f"🛡️ [CHOKE SL 1.0 ATR ĐÃ XÁC NHẬN SAU CẮT GIẢM TẢI] {position['symbol']} ({direction}): "
                                                            f"SL {previous_sl_price:.6g} -> {target_sl_after_cut:.6g} (siết {tighten_pct*100:.3f}%), "
                                                            f"KL còn lại {rem_amt:.6g}, SL mới id={new_sl_id}{cancel_note}."
                                                        )
                                                    else:
                                                        logger.warning(f"Binance chưa xác nhận SL mới cho phần còn lại của {position['symbol']}; giữ SL cũ {old_sl_id}.")
                                                except Exception as e:
                                                    logger.error(f"Lỗi cập nhật lại SL cho phần còn lại của {position['symbol']}: {e}")
                                            elif not is_live_fut and target_sl_after_cut > 0:
                                                position['stop_loss'] = target_sl_after_cut
                                            
                                            self._save_state()
                                            logger.warning(
                                                f"🛡️ [CẮT LỖ GIẢM TẢI NẤC {next_stage}/{total_sl_stages}] {position['symbol']} ({direction}) đi ngược -{current_loss_pct*100:.2f}%, "
                                                f"đã cắt {filled_amt:.6g} coin để bảo vệ vốn! Thiệt hại nấc này: {part_loss:.4f} USDT. Còn lại {rem_amt:.6g} coin."
                                            )
                                            stage_lbl = "50% (NẤC 1/2)" if (next_stage == 1 and total_sl_stages >= 2) else f"NẤC {next_stage}/{total_sl_stages}"
                                            self._notify_telegram(
                                                f"🛡️ **[CẮT LỖ GIẢM TẢI {stage_lbl}]**\n"
                                                f"Cặp: **{position['symbol']}** ({direction})\n"
                                                f"Vị thế đi ngược hướng -{current_loss_pct*100:.2f}% (ngưỡng kích hoạt: `{(target_threshold*100):.2f}%`).\n"
                                                f"✂️ **Đã chủ động cắt {stage_lbl}:** `{filled_amt:.6g}` coin tại giá `{current_price:.6g}`.\n"
                                                f"📉 **Thiệt hại nấc này:** `{part_loss:.4f} USDT`\n"
                                                f"🛡️ **Khối lượng còn lại ({rem_amt:.6g} coin):** Đã siết Hard SL về 1.0 ATR (`{position['stop_loss']:.6g}`), sẵn sàng đón 44.3% nhịp rút râu hồi phục về Hòa Vốn!"
                                            )

                        # CẤP 2 NÂNG CẤP V3.0: CHỐT LỜI TIỀN TƯƠI 50% (TRUE PARTIAL TAKE PROFIT) KHI LÃI THỰC TẾ >= +1.10%
                        # [BAI HOC 68] Lệnh tay: bot KHÔNG tự chia 50% vị thế của người dùng. Chỉ đặt/
                        # giữ TP sàn và Trailing; quyền chốt lời thuộc về người dùng hoặc lệnh TP đã đặt.
                        if is_manual_pos and current_profit_pct >= (partial_tp_trigger - 1e-6) and not position.get('_manual_partial_tp_noted'):
                            position['_manual_partial_tp_noted'] = True
                            logger.info(
                                "🖐️ [MANUAL POSITION SUPPORT-ONLY] %s đạt +%.2f%% (TP1 %.2f%%) nhưng là lệnh tay: "
                                "không tự chốt 50%%, chỉ giữ TP sàn + Trailing.",
                                position['symbol'], current_profit_pct * 100, partial_tp_trigger * 100,
                            )
                        if (current_profit_pct >= (partial_tp_trigger - 1e-6)
                                and not position.get('partial_tp_done')
                                and not is_manual_pos
                                and not position.get('partial_tp_unavailable')):
                            full_amt = float(position.get('amount') or 0)
                            half_amt = full_amt * 0.5
                            est_notional = half_amt * current_price
                            is_live_fut = (self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures')

                            if is_live_fut and est_notional < 5.0:
                                logger.info(
                                    f"Vị thế {position['symbol']} có 50% notional ({est_notional:.2f} USDT) < 5 USDT tối thiểu sàn; "
                                    f"bỏ qua lệnh đóng 50% và chuyển sang nâng SL bảo vệ lãi."
                                )
                                # Không được đánh dấu partial_tp_done: sàn chưa chốt bất kỳ phần nào.
                                # Cờ riêng chỉ chống spam; BE-sau-TP1 và Free-Roll vẫn phải chờ fill thật.
                                position['partial_tp_unavailable'] = True
                                position['_force_sl_update'] = True
                            else:
                                partial_ok = False
                                filled_amt = half_amt
                                p_order = None
                                if is_live_fut:
                                    try:
                                        p_order = self.exchange.close_futures_position(position['symbol'], direction, half_amt)
                                        if p_order and (p_order.get('id') or (p_order.get('info') or {}).get('orderId')):
                                            filled_amt = self._confirmed_filled_amount(p_order, position['symbol'], half_amt)
                                            partial_ok = filled_amt > 0
                                            if not partial_ok:
                                                logger.warning("Sàn chưa xác nhận fill Partial TP cho %s; không kích hoạt BE/Free-Roll.", position['symbol'])
                                        else:
                                            logger.warning(f"Lệnh chốt lời 50% cho {position['symbol']} không trả về ID: {p_order}")
                                    except Exception as pe:
                                        logger.error(f"Lỗi gửi lệnh chốt lời 50% cho {position['symbol']}: {pe}")
                                else:
                                    partial_ok = True

                                if partial_ok:
                                    if 'initial_amount' not in position:
                                        position['initial_amount'] = full_amt
                                    if 'initial_cost' not in position:
                                        position['initial_cost'] = float(position.get('cost') or 0)
                                    rem_amt = max(0.0, full_amt - filled_amt)
                                    if full_amt > 0:
                                        position['entry_fee'] = float(position.get('entry_fee', 0.0) or 0.0) * (rem_amt / full_amt)
                                    position['amount'] = rem_amt
                                    init_amt_val = float(position.get('initial_amount') or full_amt)
                                    if init_amt_val > 0:
                                        position['cost'] = float(position.get('initial_cost', position.get('cost', 0.0))) * (rem_amt / init_amt_val)
                                    position['partial_tp_done'] = True
                                    position['partial_tp_price'] = current_price
                                    taker_fee_rate_tp = 0.0005 if is_live_fut else max(0.0, float(self.config.get('trading', {}).get('fee_rate', 0.001)))
                                    part_tp_fee = current_price * filled_amt * taker_fee_rate_tp
                                    part_pnl = ((current_price - entry_price) * filled_amt if direction == 'LONG' else (entry_price - current_price) * filled_amt) - part_tp_fee
                                    position['partial_tp_pnl'] = float(position.get('partial_tp_pnl', 0.0) or 0.0) + part_pnl
                                    position['_force_sl_update'] = True

                                    if self.mode != 'live':
                                        self.balance += part_pnl
                                    try:
                                        part_tp_oid = (
                                            (p_order or {}).get('id')
                                            or ((p_order or {}).get('info') or {}).get('orderId')
                                            or f"partial-tp-{int(time.time() * 1000)}"
                                        )
                                        self.db.save_trade({
                                            'symbol': position['symbol'],
                                            'side': ('buy' if direction == 'SHORT' else 'sell'),
                                            'type': ('market' if self.mode == 'live' else 'limit'),
                                            'price': current_price,
                                            'amount': filled_amt,
                                            'cost': current_price * filled_amt,
                                            'fee': part_tp_fee,
                                            'pnl': part_pnl,
                                            'strategy': position.get('strategy', 'unknown'),
                                            'status': 'closed',
                                            'order_id': str(part_tp_oid),
                                            'timestamp': int(time.time() * 1000),
                                            'mode': self.mode,
                                        })
                                        if self.mode == 'live':
                                            import threading
                                            threading.Thread(
                                                target=self.sync_live_trades_from_exchange,
                                                name='partial-tp-trade-sync',
                                                daemon=True,
                                            ).start()
                                    except Exception as dbe:
                                        logger.debug(f"Không thể ghi DB cho Partial TP {position['symbol']}: {dbe}")

                                    old_tp_id = str(position.get('tp_order_id') or '')
                                    rem_notional = rem_amt * current_price
                                    tp_watchdog_activated = False
                                    if is_live_fut and old_tp_id:
                                        try:
                                            self.exchange.cancel_order(old_tp_id, position['symbol'], trigger=True, strict=False)
                                            if position.get('take_profit'):
                                                close_side = 'sell' if direction == 'LONG' else 'buy'
                                                new_tp = self.exchange.create_take_profit_market_order(
                                                    position['symbol'], close_side, rem_amt, float(position['take_profit'])
                                                )
                                                new_tp_info = (new_tp or {}).get('info') or {}
                                                new_tp_id = str((new_tp or {}).get('id') or new_tp_info.get('algoId') or new_tp_info.get('orderId') or '')
                                                if new_tp_id:
                                                    position['tp_order_id'] = new_tp_id
                                                    position.pop('take_profit_order_unverified', None)
                                                else:
                                                    position['tp_order_id'] = None
                                                    position['take_profit_order_unverified'] = True
                                                    tp_watchdog_activated = True
                                                    logger.warning(
                                                        f"Binance không thể nhận lệnh TP mới cho {position['symbol']} (~{rem_notional:.2f} USDT); "
                                                        f"bot tự động chuyển sang chế độ Local RAM Watchdog & Trailing Stop bảo vệ."
                                                    )
                                        except Exception as tpe:
                                            position['tp_order_id'] = None
                                            position['take_profit_order_unverified'] = True
                                            tp_watchdog_activated = True
                                            logger.warning(
                                                f"Không thể đặt lại TP sàn cho phần còn lại của {position['symbol']}: {tpe}. "
                                                f"Bot tự động kích hoạt chế độ Local RAM Watchdog."
                                            )

                                    self._save_state()
                                    logger.info(
                                        f"🎯 [CHỐT LỜI 50% TIỀN TƯƠI] {position['symbol']} ({direction}) tại {current_price:.6g} (+{current_profit_pct*100:.2f}%), "
                                        f"bỏ túi ví +{part_pnl:.4f} USDT! Còn lại {rem_amt:.6g} tiếp tục Trailing gồng sóng."
                                    )
                                    watchdog_note = (
                                        f"\n⚠️ **Tự Động Bảo Vệ Local Watchdog:** Khối lượng còn lại (~{rem_notional:.2f} USDT) dưới quy chuẩn 5 USDT sàn. "
                                        f"Bot đã kích hoạt **Local RAM Watchdog & Trailing Stop** tự động chốt lời khi chạm đích {float(position.get('take_profit') or 0.0):.6g} mà không cần bạn phải thao tác tay!"
                                        if tp_watchdog_activated else ""
                                    )
                                    self._notify_telegram(
                                        f"🎯 **[CHỐT LỜI 50% TIỀN TƯƠI]**\n"
                                        f"Cặp: **{position['symbol']}** ({direction})\n"
                                        f"Đã chốt 50% khối lượng (`{filled_amt:.6g}` coin) tại giá `{current_price:.6g}` (+`{current_profit_pct*100:.2f}%`).\n"
                                        f"💰 **Lợi nhuận bỏ túi ví:** `+{part_pnl:.4f} USDT`\n"
                                        f"🛡️ **50% còn lại ({rem_amt:.6g} coin):** Đang kích hoạt Trailing Stop bám sát đỉnh để gồng trọn siêu sóng x2, x3!{watchdog_note}"
                                    )

                        # =========================================================================
                        # [BÀI HỌC 98 & 99 - CRR SNELL ENVELOPE: BẢO VỆ ĐỈNH SÓNG CHO RUNNER (50% CÒN LẠI)]
                        # =========================================================================
                        # Chỉ kích hoạt sau khi đã chốt Partial TP1 (hoặc khi vị thế < 5 USDT không chia nấc được),
                        # khi lãi >= +1.50% và held >= 3.0m. Nếu CRR xác nhận kiệt sức vật lý g(S) >= C(S),
                        # chủ động chốt lời đỉnh sóng bảo toàn 80%+ đỉnh MFE thay vì để rơi tự do về Trailing Stop!
                        is_runner_active = bool(position.get('partial_tp_done') or position.get('partial_tp_unavailable'))
                        if is_runner_active and not is_manual_pos and current_profit_pct >= 0.0150 and held_minutes >= 3.0:
                            best_peak_pct = max(
                                float(position.get('max_sustained_profit_pct', 0.0) or 0.0),
                                current_profit_pct,
                                (best_price - entry_price) / entry_price if (direction == 'LONG' and entry_price > 0) else (
                                    (entry_price - best_price) / entry_price if (direction == 'SHORT' and entry_price > 0) else current_profit_pct
                                )
                            )
                            is_super_wave_snell = (current_profit_pct >= 0.025) or (best_peak_pct >= 0.0185)
                            wick_for_snell = float(metrics.get('upper_wick_pct' if direction == 'LONG' else 'lower_wick_pct') or 0.0)
                            adverse_rv_snell = float(metrics.get('adverse_rvol') or metrics.get('rvol') or 1.0)
                            if self._crr_snell_optimal_exit_check(
                                current_profit_pct=current_profit_pct,
                                max_profit_pct=best_peak_pct,
                                atr_pct=atr_val_pct_loss,
                                held_minutes=held_minutes,
                                is_super_wave=is_super_wave_snell,
                                exhaustion_wick=wick_for_snell,
                                adverse_rvol=adverse_rv_snell,
                            ):
                                rem_runner_amt = float(position.get('amount') or 0.0)
                                logger.warning(
                                    f"🎯 [CRR SNELL ENVELOPE: CHỐT LỜI TỐI ƯU ĐỈNH SÓNG] {position['symbol']} ({direction}) "
                                    f"đang lãi +{current_profit_pct*100:.2f}% (đỉnh MFE +{best_peak_pct*100:.2f}%), "
                                    f"mô hình CRR xác nhận sóng đạt đỉnh kiệt sức g(S) >= C(S)! "
                                    f"Chủ động chốt lời phần còn lại ({rem_runner_amt:.6g} coin) bảo toàn đỉnh MFE thay vì chờ giá sập ngược về Trailing Stop."
                                )
                                self._notify_telegram(
                                    f"🎯 **[CRR SNELL ENVELOPE: CHỐT LỜI ĐỈNH SÓNG RUNNER]**\n"
                                    f"• Cặp: `{position['symbol']}` ({direction})\n"
                                    f"• Lãi thực tế: `+{current_profit_pct*100:.2f}%` (Đỉnh MFE: `+{best_peak_pct*100:.2f}%`)\n"
                                    f"• Thời gian giữ: `{held_minutes:.1f}m` (Khối lượng runner: `{rem_runner_amt:.6g} coin`)\n"
                                    f"• Tín hiệu: Cây nhị phân CRR 15 bước xác nhận kiệt sức `g(S) >= C(S)`\n"
                                    f"• Hành động: **CHỐT LỜI PHẦN CÒN LẠI TẠI ĐỈNH SÓNG** bảo toàn trọn vẹn thành quả!"
                                )
                                self._close_position_locked(position, current_price, f"🎯 CRR Snell Optimal Peak Exit (+{current_profit_pct*100:.2f}%)")
                                continue

                        choke_enabled = self.config.get('risk', {}).get('choke_trailing_enabled', True)
                        pre_tp_be_enabled = bool(self.config.get('risk', {}).get('pre_tp_breakeven_enabled', False))
                        buffer_be_enabled = bool(self.config.get('risk', {}).get('pre_tp_breakeven_buffer_enabled', True))
                        be_cushion_trig = float(self.config.get('risk', {}).get('be_cushion_trigger_pct', 0.0080))
                        be_hard_trig = float(self.config.get('risk', {}).get('be_hard_lock_trigger_pct', 0.0100))
                        choke_trigger = float(profile.get('choke_trigger', self.config.get('risk', {}).get('choke_trailing_trigger_pct', 0.018)))
                        choke_ratio = float(profile.get('choke_ratio', self.config.get('risk', {}).get('choke_trailing_lock_ratio', 0.70)))

                        if direction == 'LONG':
                            net_be_floor = net_breakeven * (1 + lock_profit_pct)
                            profit_r = (best_price - entry_price) / r_dist
                            profit_pct = (best_price - entry_price) / entry_price if entry_price > 0 else 0
                            atr_val_pct = float(metrics.get('atr_pct') or 0.012)
                            partial_done = bool(position.get('partial_tp_done', False))
                            is_super_wave = (profit_pct >= 0.025) or (max_sustained_profit_pct >= 0.0185)
                            
                            # 3 CẤP ĐỘ BẢO VỆ VỐN & KHÓA LÃI THÔNG MINH V3.0 (KẾ HOẠCH BẢO VỆ ĐỆM KHÓA 2 TẦNG):
                            # Tầng 1: Đệm co hẹp Cushion SL (-0.40% buffer từ giá vào):
                            # Tại +0.80% (be_cushion_trigger_pct), co hẹp SL từ -1.50 ATR về -0.40%, giảm 80% rủi ro
                            # trong khi vẫn chừa không gian thở cho nến retest bình thường (tránh bị văng non 47.4%).
                            is_cushion_ready = (
                                buffer_be_enabled
                                and ((current_profit_pct >= (be_cushion_trig - 1e-6)) or (profit_pct >= be_cushion_trig))
                                and held_minutes >= 1.5
                            )
                            cushion_sl = entry_price * 0.9960 if is_cushion_ready else 0.0

                            # Tầng 2: Khóa cứng Hòa Vốn Hard Breakeven (+0.22% có đệm bù phí Taker):
                            # [BÀI HỌC 85]: Trong 4.5 phút đầu tiên trước khi chạm TP1 (như ON/USDT #2), giữ Tầng 1 Cushion SL (-0.40%)
                            # để vị thế thở qua nhịp giật râu M1 retest, chỉ khóa cứng Hard BE (+0.22%) khi held_minutes >= 4.5
                            # HOẶC đã chốt lời 50% (partial_done) HOẶC lãi đã bứt phá >= +1.50%!
                            is_hard_be_ready = (
                                partial_done
                                or (
                                    (
                                        ((pre_tp_be_enabled or buffer_be_enabled) and ((current_profit_pct >= (be_hard_trig - 1e-6)) or (profit_pct >= be_hard_trig)))
                                        or (pre_tp_be_enabled and not buffer_be_enabled and ((current_profit_pct >= (breakeven_trigger_pct - 1e-6)) or (profit_pct >= breakeven_trigger_pct)))
                                    )
                                    and (held_minutes >= 4.5 or current_profit_pct >= 0.015 or profit_pct >= 0.015)
                                )
                            )
                            is_breakeven_ready = is_hard_be_ready or is_cushion_ready

                            if partial_done and held_minutes < 15.0 and not is_super_wave:
                                # Trong 15p đầu sau khi đã chốt 50% tiền tươi (+1.10%), đặt sàn bảo vệ Runner có đệm bù phí sàn (+0.12%)
                                breakeven_sl = entry_price * 1.0012
                            elif is_hard_be_ready:
                                breakeven_sl = net_be_floor
                            elif is_cushion_ready:
                                breakeven_sl = cushion_sl
                            else:
                                breakeven_sl = 0
                            
                            # Cấp 2: KHÓA LÃI TỪNG PHẦN (Partial Profit Lock) & RUNNER BREATHING FLOOR
                            partial_lock_sl = 0
                            if partial_done:
                                if is_super_wave:
                                    partial_lock_sl = entry_price * 1.0110
                                elif profit_pct >= 0.018 and held_minutes >= 15.0:
                                    partial_lock_sl = entry_price * 1.0068
                                elif held_minutes >= 15.0:
                                    partial_lock_sl = max(net_be_floor, entry_price * 1.0035)
                                else:
                                    partial_lock_sl = entry_price * 1.0012
                            elif is_super_wave:
                                partial_lock_sl = entry_price * 1.0110
                            
                            # Cấp 3: KHÓA LÃI ĐẬM & TRAILING THEO ĐỈNH (High Profit Trailing)
                            is_trailing_ready = is_super_wave and ((profit_pct >= 0.025) or (profit_r >= 1.5))
                            trailing_lock_sl = entry_price * 1.012 if is_trailing_ready else 0
                            dynamic_r_sl = net_be_floor + (profit_r - 0.7) * r_dist if (is_super_wave and profit_r > 1.5) else 0
                            
                            # CHOKE TRAILING STOP V3.0 (Khóa chặt 70% của đỉnh lãi cao nhất khi vượt ngưỡng choke_trigger thích ứng)
                            choke_sl = 0
                            if choke_enabled and profit_pct >= (choke_trigger - 1e-6):
                                choke_lock_pct = profit_pct * choke_ratio
                                choke_sl = entry_price * (1.0 + choke_lock_pct)

                            # Trailing stop candidate:
                            if partial_done and is_super_wave:
                                runner_trail_pct = max(0.0070, min(0.0110, 0.90 * atr_val_pct))
                                candidate_sl = best_price * (1 - runner_trail_pct)
                            elif is_hard_be_ready and (held_minutes >= 15.0 or not partial_done):
                                fast_trail_pct = trail_pct * 0.75 if is_trailing_ready else trail_pct
                                candidate_sl = best_price * (1 - fast_trail_pct)
                            else:
                                candidate_sl = 0
                            
                            proposed_sl = max(current_sl, candidate_sl, breakeven_sl, partial_lock_sl, trailing_lock_sl, dynamic_r_sl, choke_sl)
                            # BẮT BUỘC GIỮ KHOẢNG ĐỆM THỞ TỐI THIỂU 0.22% DƯỚI GIÁ HIỆN TẠI (CHẶN LỖI ĐẶT SL SÁT GIÁ 0.0005% GÂY QUÉT 4 GIÂY)
                            min_buffer_dist = current_price * MIN_STOP_MARKET_BUFFER_PCT
                            if proposed_sl > current_price - min_buffer_dist:
                                proposed_sl = max(current_sl, current_price - min_buffer_dist)
                            if proposed_sl >= current_price:
                                proposed_sl = current_price * 0.9978
                                
                            new_sl = proposed_sl
                            min_valid_floor = entry_price * 1.0012 if (partial_done and held_minutes < 15.0) else net_be_floor
                            can_lock_net_profit = new_sl >= min_valid_floor
                            is_cushion_sl = is_cushion_ready and (new_sl >= entry_price * 0.9959) and (new_sl < min_valid_floor)
                            can_update_sl = can_lock_net_profit or is_cushion_sl
                            step_pct = float(metrics.get('min_step_pct', 0.001))
                            improves_stop = new_sl > current_sl * (1 + step_pct)
                        else:
                            net_be_floor = net_breakeven * (1 - lock_profit_pct)
                            profit_r = (entry_price - best_price) / r_dist
                            profit_pct = (entry_price - best_price) / entry_price if entry_price > 0 else 0
                            atr_val_pct = float(metrics.get('atr_pct') or 0.012)
                            partial_done = bool(position.get('partial_tp_done', False))
                            is_super_wave = (profit_pct >= 0.025) or (max_sustained_profit_pct >= 0.0185)
                            
                            # Tầng 1: Đệm co hẹp Cushion SL (+0.40% buffer từ giá vào):
                            is_cushion_ready = (
                                buffer_be_enabled
                                and ((current_profit_pct >= (be_cushion_trig - 1e-6)) or (profit_pct >= be_cushion_trig))
                                and held_minutes >= 1.5
                            )
                            cushion_sl = entry_price * 1.0040 if is_cushion_ready else float('inf')

                            # Tầng 2: Khóa cứng Hòa Vốn Hard Breakeven (-0.22% có đệm bù phí Taker):
                            # [BÀI HỌC 85]: Giữ Cushion SL (+0.40%) trong 4.5 phút đầu trước TP1 để chống quét hòa vốn non (ON/USDT #2 SHORT),
                            # chỉ khóa cứng Hard BE (-0.22%) khi held_minutes >= 4.5 hoặc đã chốt TP1 hoặc lãi >= +1.50%!
                            is_hard_be_ready = (
                                partial_done
                                or (
                                    (
                                        ((pre_tp_be_enabled or buffer_be_enabled) and ((current_profit_pct >= (be_hard_trig - 1e-6)) or (profit_pct >= be_hard_trig)))
                                        or (pre_tp_be_enabled and not buffer_be_enabled and ((current_profit_pct >= (breakeven_trigger_pct - 1e-6)) or (profit_pct >= breakeven_trigger_pct)))
                                    )
                                    and (held_minutes >= 4.5 or current_profit_pct >= 0.015 or profit_pct >= 0.015)
                                )
                            )
                            is_breakeven_ready = is_hard_be_ready or is_cushion_ready

                            if partial_done and held_minutes < 15.0 and not is_super_wave:
                                breakeven_sl = entry_price * 0.9988
                            elif is_hard_be_ready:
                                breakeven_sl = net_be_floor
                            elif is_cushion_ready:
                                breakeven_sl = cushion_sl
                            else:
                                breakeven_sl = float('inf')
                            
                            # Cấp 2: KHÓA LÃI TỪNG PHẦN (Partial Profit Lock) & RUNNER BREATHING FLOOR
                            partial_lock_sl = float('inf')
                            if partial_done:
                                if is_super_wave:
                                    partial_lock_sl = entry_price * 0.9890
                                elif profit_pct >= 0.018 and held_minutes >= 15.0:
                                    partial_lock_sl = entry_price * 0.9932
                                elif held_minutes >= 15.0:
                                    partial_lock_sl = min(net_be_floor, entry_price * 0.9965)
                                else:
                                    partial_lock_sl = entry_price * 0.9988
                            elif is_super_wave:
                                partial_lock_sl = entry_price * 0.9890
                            
                            # Cấp 3: KHÓA LÃI ĐẬM & TRAILING THEO ĐỈNH (High Profit Trailing)
                            is_trailing_ready = is_super_wave and ((profit_pct >= 0.025) or (profit_r >= 1.5))
                            trailing_lock_sl = entry_price * 0.988 if is_trailing_ready else float('inf')
                            dynamic_r_sl = net_be_floor - (profit_r - 0.7) * r_dist if (is_super_wave and profit_r > 1.5) else float('inf')
                            
                            # CHOKE TRAILING STOP V3.0 (Khóa chặt 70% của đỉnh lãi cao nhất khi vượt ngưỡng choke_trigger thích ứng)
                            choke_sl = float('inf')
                            if choke_enabled and profit_pct >= (choke_trigger - 1e-6):
                                choke_lock_pct = profit_pct * choke_ratio
                                choke_sl = entry_price * (1.0 - choke_lock_pct)

                            # Trailing stop candidate: Runner Micro-Trailing Stop
                            if partial_done and is_super_wave:
                                runner_trail_pct = max(0.0070, min(0.0110, 0.90 * atr_val_pct))
                                candidate_sl = best_price * (1 + runner_trail_pct)
                            elif is_hard_be_ready and (held_minutes >= 15.0 or not partial_done):
                                fast_trail_pct = trail_pct * 0.75 if is_trailing_ready else trail_pct
                                candidate_sl = best_price * (1 + fast_trail_pct)
                            else:
                                candidate_sl = float('inf')
                            
                            proposed_sl = min(current_sl, candidate_sl, breakeven_sl, partial_lock_sl, trailing_lock_sl, dynamic_r_sl, choke_sl)
                            # BẮT BUỘC GIỮ KHOẢNG ĐỆM THỞ TỐI THIỂU 0.22% TRÊN GIÁ HIỆN TẠI (CHẶN LỖI ĐẶT SL SÁT GIÁ 0.0005% GÂY QUÉT 4 GIÂY)
                            min_buffer_dist = current_price * MIN_STOP_MARKET_BUFFER_PCT
                            if proposed_sl < current_price + min_buffer_dist:
                                proposed_sl = min(current_sl, current_price + min_buffer_dist)
                            if proposed_sl <= current_price:
                                proposed_sl = current_price * 1.0022
                                
                            new_sl = proposed_sl
                            max_valid_floor = entry_price * 0.9988 if (partial_done and held_minutes < 15.0) else net_be_floor
                            can_lock_net_profit = new_sl <= max_valid_floor
                            is_cushion_sl = is_cushion_ready and (new_sl <= entry_price * 1.0041) and (new_sl > max_valid_floor)
                            can_update_sl = can_lock_net_profit or is_cushion_sl
                            step_pct = float(metrics.get('min_step_pct', 0.001))
                            improves_stop = new_sl < current_sl * (1 - step_pct)

                        position['trailing_active'] = bool(can_lock_net_profit or is_cushion_sl)
                        position['trailing_status'] = (
                            'active' if can_lock_net_profit else ('cushion_buffer' if is_cushion_sl else 'waiting_net_profit')
                        )
                        # Save initial_sl if not exist
                        if 'initial_sl' not in position:
                            position['initial_sl'] = initial_sl
                        if best_changed:
                            # Persist the favorable excursion so a restart cannot
                            # forget a previously observed peak/trough.
                            self._save_state()

                        if not can_update_sl:
                            continue

                        pass # already_crossed handled safely above

                        if not improves_stop and not position.pop('_force_sl_update', False):
                            continue

                        is_live_futures = (
                            self.mode == 'live'
                            and getattr(self, 'market_type', 'spot') == 'futures'
                        )
                        if not is_live_futures:
                            position['stop_loss'] = new_sl
                            position['trailing_active'] = True
                            position['trailing_status'] = 'active'
                            self._save_state()
                            logger.info(
                                "ADAPTIVE TRAILING UPDATED: %s SL=%.8f gap=%.3f%% ATR=%.3f%% regime=%s netBE=%.8f",
                                position['symbol'], new_sl, trail_pct * 100,
                                (metrics.get('atr_pct') or 0) * 100,
                                position['trailing_regime'], net_breakeven,
                            )
                        elif not position.get('sl_order_id'):
                            position['trailing_active'] = False
                            position['trailing_status'] = 'protection_unavailable'
                            logger.critical(
                                "Không cập nhật adaptive trailing cho %s vì chưa có SL được xác nhận trên Binance.",
                                position['symbol'],
                            )
                            if not position.get('trailing_sl_missing_alerted'):
                                self._notify_telegram(
                                    f"🚨 Vị thế LIVE {position['symbol']} chưa có SL được xác nhận trên Binance; "
                                    "adaptive trailing chưa thể sửa lệnh bảo vệ. Hãy kiểm tra trực tiếp trên sàn."
                                )
                                position['trailing_sl_missing_alerted'] = True
                        else:
                            old_order_id = str(position['sl_order_id'])
                            close_side = 'sell' if direction == 'LONG' else 'buy'
                            try:
                                # Place and acknowledge the replacement first; the
                                # existing exchange stop remains live if this fails.
                                new_order = self.exchange.create_stop_market_order(
                                    position['symbol'], close_side,
                                    position['amount'], new_sl,
                                )
                                new_info = (new_order or {}).get('info') or {}
                                new_order_id = str(
                                    (new_order or {}).get('id')
                                    or new_info.get('algoId')
                                    or new_info.get('orderId')
                                    or ''
                                )
                                if not new_order_id:
                                    logger.error(
                                        "Binance chưa xác nhận SL adaptive mới cho %s; giữ nguyên SL %s tại %.8f.",
                                        position['symbol'], old_order_id, current_sl,
                                    )
                                else:
                                    position['stop_loss'] = new_sl
                                    position['sl_order_id'] = new_order_id
                                    if can_lock_net_profit:
                                        position['breakeven_protection_confirmed'] = True
                                        position['breakeven_protection_source'] = 'adaptive'
                                        if not position.get('_be_alerted'):
                                            self._notify_telegram(
                                                f"🚀 **[KHÓA HÒA VỐN BẢO TOÀN LÃI]**\n"
                                                f"Cặp: **{position['symbol']}** ({direction})\n"
                                                f"🛡️ Đã nâng Stop-Loss sàn lên mức Hòa Vốn + Phí: `{new_sl:.6g}`\n"
                                                f"💰 Vị thế đã an toàn 100%, sẵn sàng gồng trọn siêu sóng!"
                                            )
                                            position['_be_alerted'] = True
                                    elif is_cushion_sl:
                                        position['cushion_protection_confirmed'] = True
                                        if not position.get('_cushion_alerted'):
                                            self._notify_telegram(
                                                f"🛡️ **[CUSHION SL: CO HẸP RỦI RO]**\n"
                                                f"Cặp: **{position['symbol']}** ({direction})\n"
                                                f"🎯 Giá chạm mốc +0.80%! Đã co hẹp SL sàn lên `{new_sl:.6g}` (-0.40% buffer).\n"
                                                f"✨ Giảm 80% rủi ro tối đa trong khi giữ nguyên biên độ thở đón nhịp bứt phá!"
                                            )
                                            position['_cushion_alerted'] = True
                                    position['protection_status'] = 'exchange_stop_verified'
                                    position['trailing_active'] = bool(can_lock_net_profit or is_cushion_sl)
                                    position['trailing_status'] = 'active' if can_lock_net_profit else 'cushion_buffer'
                                    pending_ids = list(dict.fromkeys(
                                        str(order_id)
                                        for order_id in position.get('stale_sl_order_ids', [])
                                        if order_id
                                    ))
                                    if old_order_id != new_order_id:
                                        pending_ids.append(old_order_id)
                                    position['stale_sl_order_ids'] = list(dict.fromkeys(pending_ids))
                                    # Save the acknowledged new stop before canceling
                                    # the old one, preserving recoverability.
                                    self._save_state()
                                    if old_order_id != new_order_id:
                                        try:
                                            self.exchange.cancel_order(
                                                old_order_id, position['symbol'],
                                                trigger=True, strict=True,
                                            )
                                            remaining = self.exchange.get_open_orders(
                                                position['symbol'], trigger=True, strict=True
                                            )
                                            remaining_ids = {
                                                self._conditional_order_id(order)
                                                for order in remaining
                                            }
                                            if old_order_id not in remaining_ids:
                                                pending_ids = [
                                                    order_id for order_id in pending_ids
                                                    if order_id != old_order_id
                                                ]
                                            else:
                                                logger.error(
                                                    "SL trailing cũ %s vẫn mở trên Binance; sẽ thử dọn lại.",
                                                    old_order_id,
                                                )
                                        except Exception as e:
                                            logger.error(
                                                "Đã đặt SL adaptive %s nhưng chưa xác minh hủy SL cũ %s: %s",
                                                new_order_id, old_order_id, e,
                                            )
                                            alerted_ids = position.setdefault(
                                                'trailing_sl_cancel_alerted_ids', []
                                            )
                                            if old_order_id not in alerted_ids:
                                                self._notify_telegram(
                                                    f"⚠️ {position['symbol']}: SL adaptive mới đã đặt; "
                                                    f"chưa xác minh hủy SL cũ {old_order_id}. Tool sẽ thử dọn lại."
                                                )
                                                alerted_ids.append(old_order_id)
                                    position['stale_sl_order_ids'] = list(dict.fromkeys(pending_ids))
                                    self._save_state()
                                    logger.info(
                                        "ADAPTIVE TRAILING UPDATED: %s SL=%.8f gap=%.3f%% ATR=%.3f%% regime=%s netBE=%.8f order=%s",
                                        position['symbol'], new_sl, trail_pct * 100,
                                        (metrics.get('atr_pct') or 0) * 100,
                                        position['trailing_regime'], net_breakeven,
                                        new_order_id,
                                    )
                                    # TELEGRAM NOTIFICATIONS
                                    try:
                                        quote_curr = self.config.get('trading', {}).get('base_currency', 'USDT')
                                        last_notified = position.get('last_notified_sl_price', initial_sl)
                                        sl_step_ratio = abs(new_sl - last_notified) / entry_price if entry_price > 0 else 0
                                        est_sl_pnl = (new_sl - entry_price) * position['amount'] if direction == 'LONG' else (entry_price - new_sl) * position['amount']
                                        
                                        if choke_enabled and profit_pct >= (choke_trigger - 1e-6) and not position.get('notified_choke'):
                                            self._notify_telegram(
                                                f"🚀 **[CHOKE TRAILING - SIẾT ĐỈNH GIA TỐC]**\n"
                                                f"Cặp: **{position['symbol']}** ({direction})\n"
                                                f"Phân khúc: `{profile.get('asset_class', 'STANDARD')}` | Đỉnh lãi: `+{profit_pct*100:.2f}%`\n"
                                                f"🔒 **Dời SL siết chặt {int(choke_ratio*100)}% đỉnh:** `{current_sl:.6g}` ➡️ `{new_sl:.6g}`\n"
                                                f"💎 **Lợi nhuận bảo hiểm tối thiểu:** `+{est_sl_pnl:.4f} {quote_curr}`\n"
                                                f"🚀 Bất chấp râu nến giật ngược, {int(choke_ratio*100)}% khoản lãi to đã nằm chắc trong ví!"
                                            )
                                            position['notified_choke'] = True
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                        elif profit_r >= 2.0 and not position.get('notified_lock2'):
                                            self._notify_telegram(
                                                f"🔥 **[KHÓA LÃI GỒNG VÔ CỰC]**\n"
                                                f"Sóng {position['symbol']} đang bứt phá rất mạnh (>2R)!\n"
                                                f"🔹 **Dời Stop-Loss bảo hiểm:** {current_sl:.6g} ➡️ {new_sl:.6g}\n"
                                                f"💎 **Khóa chặt lợi nhuận tối thiểu:** {est_sl_pnl:+.4f} {quote_curr}\n"
                                                f"🎯 **Mục tiêu TP vẫn giữ nguyên:** {position.get('take_profit', 0):.6g}"
                                            )
                                            position['notified_lock2'] = True
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                        elif not position.get('notified_be') and can_lock_net_profit:
                                            self._queue_breakeven_telegram(position, new_sl, 'adaptive')
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                        elif can_lock_net_profit and est_sl_pnl > 0 and sl_step_ratio >= 0.003:
                                            self._notify_telegram(
                                                f"📈 **[NÂNG MỨC BẢO HIỂM LÃI]**\n"
                                                f"Cặp {position['symbol']} tiếp tục mở rộng đà lãi!\n"
                                                f"🔹 **Nâng Trailing SL:** {current_sl:.6g} ➡️ {new_sl:.6g}\n"
                                                f"💎 **Lợi nhuận được khóa thêm:** {est_sl_pnl:+.4f} {quote_curr}\n"
                                                f"🎯 **Mục tiêu TP:** {position.get('take_profit', 0):.6g}"
                                            )
                                            position['last_notified_sl_price'] = new_sl
                                            self._save_state()
                                    except Exception as te:
                                        logger.debug(f"Lỗi thông báo Telegram trailing: {te}")
                            except Exception as e:
                                logger.error(
                                    "Lỗi đặt adaptive trailing cho %s; giữ nguyên SL hiện tại: %s",
                                    position['symbol'], e,
                                )
                    except Exception as e:
                        logger.error(
                            "Lỗi tính adaptive trailing cho %s: %s",
                            position.get('symbol'), e,
                        )
            except Exception as e:
                logger.error(f"Lỗi kiểm tra position {position.get('symbol')}: {e}")

    def _check_drawdown(self, equity: float):
        """Kiểm tra drawdown và pause nếu vượt ngưỡng. Cập nhật mốc Đỉnh tài khoản qua ngày."""
        try:
            equity = float(equity)
        except (TypeError, ValueError, OverflowError):
            logger.critical("Equity không hợp lệ; khóa mở lệnh mới để bảo vệ tài khoản.")
            return True
        if not math.isfinite(equity) or equity <= 0:
            logger.critical("Equity không hữu hạn hoặc không dương; khóa mở lệnh mới.")
            return True
            
        current_date = datetime.now().date()
        if not hasattr(self, 'last_reset_date'):
            self.last_reset_date = current_date
            
        if current_date > self.last_reset_date:
            logger.info("🌅 Qua ngày mới! Đặt lại mốc Đỉnh Tài Khoản để bắt đầu lại đánh giá Drawdown.")
            self.peak_balance = equity
            self.last_reset_date = current_date
            self._save_state()

        if equity > self.peak_balance:
            self.peak_balance = equity
            self._save_state()

        logger.info(f"DEBUG DRAWDOWN: equity={equity}, peak_balance={self.peak_balance}")
        is_exceeded, drawdown = self.risk_manager.check_drawdown(
            equity, self.peak_balance
        )
        if is_exceeded:
            # Tuyệt đối không hạ đỉnh từ chênh lệch equity/PnL suy đoán. Chỉ sổ
            # TRANSFER thật mới được phép điều chỉnh dòng vốn; nếu không, cầu dao
            # phải giữ nguyên đỉnh để không che giấu khoản lỗ thật.
            logger.warning(
                f"⚠️ DRAWDOWN EXCEEDED! ({drawdown:.2%}). "
                f"Bot tạm dừng giao dịch mới."
            )
            return True
        return False

    def _check_fomo(self, symbol: str, direction: Optional[str] = None, df_15m = None) -> bool:
        """Chống mua/bán đuổi theo hướng tín hiệu: Kiểm tra nến 15m đã đóng xem giá có đi quá xa EMA20 cùng chiều hay nến vừa đóng quá dài (FOMO) không."""
        try:
            df = df_15m if (df_15m is not None and len(df_15m) >= 25) else self.data_collector.fetch_data(symbol, '15m', limit=30)
            if df is None or len(df) < 25:
                return False
            import ta
            
            # Tính EMA20 và ATR
            ema20 = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
            atr = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=14).average_true_range()
            
            # Bỏ qua nến đang chạy (iloc[-1]), xét nến vừa đóng hoàn toàn (iloc[-2]) theo chuẩn Bài học số 4
            prev_open = float(df['open'].iloc[-2])
            prev_close = float(df['close'].iloc[-2])
            prev_ema = float(ema20.iloc[-2])
            prev_atr = float(atr.iloc[-2])
            if not math.isfinite(prev_atr) or prev_atr <= 0:
                return False

            dir_norm = str(direction or '').upper()
            if dir_norm in ('BUY', 'LONG'):
                # Chỉ chặn BUY khi giá đã bay quá xa LÊN TRÊN EMA20 hoặc nến vừa đóng tăng dựng đứng
                fomo_dist = prev_close - prev_ema
                fomo_body = prev_close - prev_open
            elif dir_norm in ('SELL', 'SHORT'):
                # Chỉ chặn SELL khi giá đã sập quá xa XUỐNG DƯỚI EMA20 hoặc nến vừa đóng xả dựng đứng
                fomo_dist = prev_ema - prev_close
                fomo_body = prev_open - prev_close
            else:
                fomo_dist = abs(prev_close - prev_ema)
                fomo_body = abs(prev_close - prev_open)
            
            # [BÀI HỌC 94]: Phân biệt FOMO đu đỉnh nhỏ lẻ vs Bão Volume Cá Mập (Whale Pump Storm / Waterfall Dump / Climax)
            # Khi nến vừa đóng có khối lượng bão (RVol >= 1.8x), nới trần FOMO lên 4.0 ATR và 3.5 ATR
            # để bot cưỡi sóng cùng kẻ có tiền theo Tôn chỉ Tối thượng, không giết nhầm siêu sóng tại Pha 1!
            vol_history = df['volume'].iloc[:-2].tail(20) if len(df) >= 22 else df['volume'].iloc[:-2]
            sma_vol = float(vol_history.mean()) if not vol_history.empty else 0.0
            last_vol = float(df['volume'].iloc[-2]) if len(df) >= 2 else 0.0
            rvol_fomo = (last_vol / sma_vol) if sma_vol > 0 else 1.0
            is_whale_storm = (rvol_fomo >= 1.8)

            dist_mult = 4.0 if is_whale_storm else 2.5
            body_mult = 3.5 if is_whale_storm else 2.0

            # 1. Khoảng cách cùng chiều tới EMA20 không vượt quá ngưỡng ATR cho phép
            if fomo_dist > prev_atr * dist_mult:
                logger.info(f"🚫 [Anti-FOMO] {symbol} ({dir_norm or 'ANY'}) đang cách xa EMA20 (Dist: {fomo_dist:.6f}, ATR: {prev_atr:.6f}, Trần: {dist_mult:.1f}x, RVol: {rvol_fomo:.2f}x).")
                return True
                
            # 2. Thân nến vừa đóng cùng chiều không dài quá ngưỡng ATR cho phép (Spike bất thường)
            if fomo_body > prev_atr * body_mult:
                logger.info(f"🚫 [Anti-FOMO] {symbol} ({dir_norm or 'ANY'}) vừa có nến bứt phá quá mạnh (Body: {fomo_body:.6f}, ATR: {prev_atr:.6f}, Trần: {body_mult:.1f}x, RVol: {rvol_fomo:.2f}x). Đợi hồi.")
                return True
                
            return False
        except Exception as e:
            logger.warning(f"Lỗi kiểm tra FOMO cho {symbol}: {e}")
            return False

    def _detect_base_currency(self):
        """Tu dong nhan dien USDC hoac USDT dua tren so du (neu khong co lenh mo)."""
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures' or self.open_positions:
            return
            
        try:
            bal = self.exchange.exchange.fetch_balance({'type': 'future'}) if getattr(self.exchange, 'exchange', None) else {}
            if isinstance(bal, dict):
                usdt_data = bal.get('USDT') or {}
                usdc_data = bal.get('USDC') or {}
                
                usdt_total = float(usdt_data.get('total', 0) if isinstance(usdt_data, dict) else bal.get('total', {}).get('USDT', 0) if isinstance(bal.get('total'), dict) else 0)
                usdc_total = float(usdc_data.get('total', 0) if isinstance(usdc_data, dict) else bal.get('total', {}).get('USDC', 0) if isinstance(bal.get('total'), dict) else 0)
                
                detected = None
                if usdt_total > usdc_total and usdt_total > 1.0:
                    detected = 'USDT'
                elif usdc_total > usdt_total and usdc_total > 1.0:
                    detected = 'USDC'
                    
                if detected:
                    old_base = self.config.get('trading', {}).get('base_currency')
                    if old_base != detected:
                        logger.info(f"🔄 Tự động chuyển đổi Base Currency: {old_base} -> {detected} (do số dư {detected} lớn hơn)")
                        if 'trading' not in self.config:
                            self.config['trading'] = {}
                        self.config['trading']['base_currency'] = detected
                        
                        # Lưu thẳng vào settings.yaml để lần sau khởi động không bị quên (nhất là khi có lệnh mở)
                        try:
                            import yaml, os
                            settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
                            with open(settings_path, 'r', encoding='utf-8') as sf:
                                st = yaml.safe_load(sf) or {}
                            if 'trading' not in st: st['trading'] = {}
                            st['trading']['base_currency'] = detected
                            with open(settings_path, 'w', encoding='utf-8') as sf:
                                yaml.dump(st, sf, default_flow_style=False, allow_unicode=True)
                        except Exception as e:
                            logger.error(f"Lỗi lưu base_currency vào settings.yaml: {e}")
                        
                        new_bal = bal.get(detected) or {}
                        self.balance = float(new_bal.get('free', bal.get('free', {}).get(detected, 0)) if isinstance(new_bal, dict) else 0)
        except Exception as e:
            logger.debug(f"Lỗi nhận diện base currency: {e}")

    def _sweep_orphan_protection_orders(self) -> int:
        """Quét và hủy các lệnh dừng lỗ / chốt lời mồ côi (reduceOnly / trigger) trên Binance khi không còn vị thế mở."""
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures':
            return 0
        try:
            live = set()
            for p in (self.exchange.get_futures_positions() or []):
                amt = abs(float(p.get('contracts') or (p.get('info') or {}).get('positionAmt') or 0))
                if amt > 0:
                    live.add(str(p.get('symbol') or '').split(':')[0])
            orders = self.exchange.get_open_orders(None, trigger=True, strict=True) or []
        except Exception as e:
            logger.warning("Orphan sweep bỏ qua do lỗi truy vấn: %s", e)
            return 0
        cancelled = 0
        now_ms = time.time() * 1000
        for o in orders:
            sym = str(o.get('symbol') or '').split(':')[0]
            if sym in live:
                continue
            if not (o.get('reduceOnly') or (o.get('info') or {}).get('reduceOnly')):
                continue
            ts = o.get('timestamp')
            if ts and (now_ms - float(ts)) < 60000:  # Tránh race condition với lệnh vừa đặt dưới 60s
                continue
            try:
                self.exchange.cancel_order(str(o['id']), sym, trigger=True, strict=True)
                cancelled += 1
                logger.warning(f"🧹 Đã hủy lệnh bảo vệ mồ côi {o.get('id')} của {sym} (không còn vị thế mở trên Binance).")
            except Exception as e:
                logger.error(f"Không hủy được lệnh mồ côi {o.get('id')} {sym}: {e}")
        return cancelled

    def run_cycle(self):
        # Quét dọn lệnh mồ côi định kỳ mỗi 5 phút
        now_sweep = time.time()
        if (now_sweep - getattr(self, '_last_orphan_sweep_time', 0.0)) >= 300.0:
            self._last_orphan_sweep_time = now_sweep
            self._sweep_orphan_protection_orders()

        """Chạy một chu kỳ phân tích và giao dịch."""
        self._detect_base_currency()
        logger.info(f"\n{'='*60}")
        logger.info(f"🔄 Chu kỳ mới - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        logger.info(f"💰 Balance: {self.balance:.4f} {quote} | "
                    f"Open: {len(self.open_positions)} positions")
        logger.info(f"{'='*60}")

        # [SỔ VỐN] Đồng bộ nạp/rút mỗi giờ (hàm tự throttle bên trong) để tiền nạp/rút giữa chừng
        # được ghi nhận mà không cần khởi động lại bot. Lỗi API chỉ giữ nguyên sổ hiện có.
        try:
            self._sync_net_deposits()
        except Exception as e:
            logger.debug(f"Bo qua dong bo so von trong chu ky: {e}")

        # Reconcile exchange state before evaluating any saved local stop/target.
        if not self.sync_live_positions_with_exchange():
            logger.error("Không đồng bộ được vị thế với Binance; bỏ qua chu kỳ để tránh mở lệnh theo dữ liệu cũ.")
            return
        if self.unreconciled_exchange_positions:
            logger.critical("Có vị thế hoặc lệnh bảo vệ Binance chưa thể đối soát an toàn; tạm khóa lệnh mới.")
            return

        # A dedicated position monitor manages stops independently while this
        # slower cycle analyzes symbols and runs external AI calls.
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures' and not self.live_balance_synced:
            logger.error("Không lấy được số dư Futures mới nhất; tạm khóa lệnh mới nhưng vẫn cho phép thao tác đóng vị thế.")
            return
        
        # Tính equity hiện tại
        status = self.get_status()
        if 'equity' in status and status['equity'] is not None:
            current_equity = status['equity']
        else:
            current_equity = status.get('balance', self.balance) + sum(pos.get('cost', 0) for pos in self.open_positions)
            if 'pnl' in status:
                # [SỔ VỐN] Mốc vốn lấy từ sổ nạp/rút thật của sàn, không phải hằng số khai báo.
                current_equity = self._invested_basis() + status['pnl']
        
        # Kiểm tra drawdown
        if self._check_drawdown(current_equity):
            self._save_state()
            return

        daily_limit = float(self.config.get('risk', {}).get('max_daily_loss_pct', 0.05))
        if daily_limit > 0:
            now = datetime.now()
            day_start_ms = int(now.replace(hour=0, minute=0, second=0, microsecond=0).timestamp() * 1000)
            base_currency = self.config.get('trading', {}).get('base_currency', 'USDT')
            daily_net_pnl = self.db.get_daily_net_pnl(self.mode, day_start_ms, base_currency)
            if daily_net_pnl is None:
                logger.error("Không đọc được Daily PnL từ DB; VETO lệnh mới fail-closed thay vì coi PnL=0.")
                self._save_state()
                return
            if current_equity > 0 and daily_net_pnl <= -(current_equity * daily_limit):
                logger.error(
                    f"Giới hạn lỗ trong ngày đã chạm: {daily_net_pnl:.4f} "
                    f"({daily_net_pnl/current_equity:.2%}); tạm ngưng lệnh mới đến ngày kế tiếp."
                )
                self._save_state()
                return
        
        # KIỂM TRA AI BIAS VÀ DYNAMIC CONFIG TRƯỚC KHI VÀO LỆNH MỚI
        ai_target = 'ALL'
        bias = 'HIGH_RISK'
        self.ai_max_positions = self._configured_max_open_positions()
        self.ai_recommended_max_positions = self.ai_max_positions
        try:
            import yaml
            from pathlib import Path
            
            # Reload dynamic confidence threshold from settings.yaml
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            with open(settings_path, 'r', encoding='utf-8') as sf:
                settings = yaml.safe_load(sf)
                if not isinstance(settings, dict):
                    raise ValueError('settings.yaml không phải mapping hợp lệ')
                ai_settings = settings.get('ai', {})
                if not isinstance(ai_settings, dict):
                    raise ValueError('mục ai trong settings.yaml không hợp lệ')
                new_threshold = float(ai_settings.get('confidence_threshold', 0.12))
                if not math.isfinite(new_threshold) or not 0 <= new_threshold <= 1:
                    raise ValueError('ai.confidence_threshold phải nằm trong [0, 1]')
                if hasattr(self, 'signal_aggregator'):
                    self.signal_aggregator.confidence_threshold = new_threshold

            strat_path = Path(__file__).parent.parent / 'config' / 'strategies.yaml'
            with open(strat_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f)
                if not isinstance(strat, dict):
                    raise ValueError('strategies.yaml không phải mapping hợp lệ')
                ai_bias = strat.get('ai_bias', {})
                if not isinstance(ai_bias, dict):
                    raise ValueError('mục ai_bias trong strategies.yaml không hợp lệ')
                raw_bias = ai_bias.get('direction', 'NONE')
                ai_target = ai_bias.get('target_coin', 'ALL')
                
                # Logic xác nhận bias (chỉ đổi khi giống nhau 2 lần liên tiếp)
                if not hasattr(self, 'last_raw_bias'):
                    self.last_raw_bias = raw_bias
                if not hasattr(self, 'confirmed_bias'):
                    self.confirmed_bias = raw_bias
                    
                if raw_bias == self.last_raw_bias:
                    self.confirmed_bias = raw_bias
                else:
                    logger.info(f"AI Bias đang thay đổi ({self.last_raw_bias} -> {raw_bias}), chờ xác nhận vòng sau.")
                    self.last_raw_bias = raw_bias
                    
                bias = self.confirmed_bias
                self.ai_recommended_max_positions = ai_bias.get(
                    'suggested_max_positions', self.ai_max_positions,
                )
                if not isinstance(ai_target, str) or not ai_target:
                    raise ValueError('ai_bias.target_coin phải là chuỗi không rỗng')
                # AI's slot count is a recommendation. The risk/trading settings
                # remain the hard cap; strong confirmed setups may earn another slot.
                self.ai_max_positions = self._configured_max_open_positions()
                if bias not in ('BULLISH', 'BEARISH', 'NEUTRAL', 'HIGH_RISK', 'NONE'):
                    logger.error("AI bias không hợp lệ (%r); khóa lệnh mới.", bias)
                    bias = 'HIGH_RISK'
                
                if bias == 'NONE':
                    logger.info(" Đang chờ AI Ollama phân tích... Chưa thể vào lệnh mới.")
                    self._save_state()
                    return
                elif bias == 'HIGH_RISK':
                    logger.warning(
                        "[WARNING] AI báo RỦI RO CAO; tạm ngưng mở lệnh mới. "
                        "Bot vẫn tiếp tục quản lý vị thế đang mở."
                    )
                    self._save_state()
                    return

        except Exception as e:
            # If trading policy cannot be read, fail closed for this cycle.
            # The position monitor remains independent and keeps managing any
            # already-open position; this only prevents new entry decisions.
            logger.error(
                "Không đọc được cấu hình AI/bias; khóa lệnh mới trong chu kỳ này: %s",
                e,
            )
            self._save_state()
            return
        
        # 1. TÌM KIẾM & SO SÁNH: Quét toàn bộ thị trường tìm coin tiềm năng
        skip_dynamic_exit_this_cycle = bool(self._skip_dynamic_exit_cycle)
        self._skip_dynamic_exit_cycle = False
        if self.config['trading'].get('dynamic_scanning', True):
            scan_limit = self.config['trading'].get('max_scan_pairs', 5)
            target_pairs = self.scanner.get_potential_pairs(limit=scan_limit)
        else:
            target_pairs = list(self.config['trading']['pairs'])
            
        # Lọc danh sách cặp theo 3 chế độ (Chỉ Cổ phiếu / Cả Hai / Chỉ Crypto)
        tradfi_cfg = self.config.get('tradfi', {})
        tradfi_enabled = bool(tradfi_cfg.get('enabled', False))
        only_tradfi = bool(tradfi_cfg.get('only_tradfi', False))

        if only_tradfi:
            # Chế độ CHỈ CỔ PHIẾU / HÀNG HÓA MỸ: Loại bỏ 100% Crypto
            target_pairs = [
                p for p in target_pairs
                if MarketScanner.is_tradfi_stock(p)
                or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(p))
            ]
        elif not tradfi_enabled:
            # Chế độ THUẦN CRYPTO: Loại bỏ 100% Cổ phiếu & Hàng hóa Mỹ
            target_pairs = [
                p for p in target_pairs
                if not (
                    MarketScanner.is_tradfi_stock(p)
                    or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(p))
                )
            ]

        # Luôn đưa các đồng coin/mã đang mở vị thế vào đầu danh sách quét để không bao giờ bị bỏ sót
        open_symbols = [p.get('symbol') for p in self.open_positions if p.get('symbol')]
        for s in open_symbols:
            clean_s = self._clean_symbol(s)
            matching = [p for p in target_pairs if self._clean_symbol(p) == clean_s]
            if not matching:
                target_pairs.insert(0, s)

        # [BÀI HỌC 87]: Luôn đưa các đồng coin đang trong Ra-đa Rình Short Pha 2 (_fading_short_watchlist)
        # vào đầu danh sách quét để không bao giờ bỏ sót nhịp xả đỉnh cá mập kể cả khi volume tạm thời tụt khỏi Top 50!
        now_ts_scan = time.time()
        if hasattr(self, '_fading_short_watchlist'):
            self._fading_short_watchlist = {
                k: v for k, v in self._fading_short_watchlist.items() if v > now_ts_scan
            }
            for wl_sym in list(self._fading_short_watchlist.keys()):
                clean_wl = self._clean_symbol(wl_sym)
                matching = [p for p in target_pairs if self._clean_symbol(p) == clean_wl]
                if not matching:
                    target_pairs.insert(0, wl_sym)
        
        # 2.1 PHA 1: QUÉT NHANH BẰNG ĐA LUỒNG (MULTI-THREADING)
        candidates = []
        import concurrent.futures
        
        is_global_loss_cooling = time.time() < self._global_loss_cooldown_until
        if is_global_loss_cooling:
            rem_min = (self._global_loss_cooldown_until - time.time()) / 60.0
            logger.info(f"⏸️ Global Cooldown sau khi cắt lỗ đang kích hoạt (còn {rem_min:.1f} phút). Chỉ theo dõi vị thế mở, tạm dừng mở vị thế mới.")

        def process_pair(pair):
            if not self.is_running:
                return None
            clean_pair = self._clean_symbol(pair)
            pair_base = clean_pair.split('/')[0] if '/' in clean_pair else clean_pair
            if ai_target != 'ALL' and ai_target.upper() != pair_base:
                return None

            # Kiểm tra trạng thái phân loại Crypto vs Cổ phiếu vs Hàng hóa TradFi
            is_stock = MarketScanner.is_tradfi_stock(pair)
            is_commodity = hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(pair)
            is_tradfi = is_stock or is_commodity
            if only_tradfi:
                if not is_tradfi:
                    return None
                if is_stock and tradfi_cfg.get('session_filter', True) and not MarketScanner.is_us_market_open():
                    return None
            elif not tradfi_enabled:
                if is_tradfi:
                    return None
            elif is_stock and tradfi_cfg.get('session_filter', True) and not MarketScanner.is_us_market_open():
                return None

            try:
                active_pos = [
                    p for p in self.open_positions
                    if self._clean_symbol(p.get('symbol')) == self._clean_symbol(pair)
                ]
                has_open_pos = len(active_pos) > 0
                
                if has_open_pos:
                    return {'pair': pair, 'score': 100.0, 'is_open': True, 'active_pos': active_pos}

                if is_global_loss_cooling:
                    return None

                cooldown_symbol = self._clean_symbol(pair)
                cooldown_until = max(
                    self._manual_exit_cooldowns.get(cooldown_symbol, 0),
                    self._symbol_cooldowns.get(cooldown_symbol, 0)
                )
                # [BÀI HỌC 78, 82 & 85]: Miễn trừ post-win cooldown cho đồng coin đang trong Ra-đa Rình Short Pha 2 (_fading_short_watchlist)
                # để ngay sau khi chốt lời LONG Pha 1, bot lập tức quét và bắt đỉnh SHORT Pha 2! (Tuyệt đối không miễn trừ nếu vừa đóng lỗ).
                in_p2_short_wl = (
                    hasattr(self, '_fading_short_watchlist')
                    and cooldown_symbol in self._fading_short_watchlist
                    and time.time() < self._fading_short_watchlist.get(cooldown_symbol, 0)
                    and getattr(self, '_symbol_loss_streaks', {}).get(cooldown_symbol, 0) == 0
                )
                if time.time() < cooldown_until and not in_p2_short_wl:
                    return None
                
                configured_max = self._configured_max_open_positions()
                occupied_slots = len(self.open_positions) + len(getattr(self, 'pending_stalking_orders', {}))
                if not getattr(self, 'free_roll_recycling', True):
                    if occupied_slots >= configured_max:
                        return None
                else:
                    free_roll_count = sum(1 for p in getattr(self, 'open_positions', []) if self._is_position_risk_free(p))
                    effective_cap = min(configured_max + free_roll_count, configured_max + 2)
                    at_risk_slots = self._count_at_risk_positions() + len(getattr(self, 'pending_stalking_orders', {}))
                    max_at_risk = self._configured_max_at_risk_positions()
                    if occupied_slots >= effective_cap or at_risk_slots >= max_at_risk:
                        return None
                    
                signals = self._analyze_market(pair, fast_mode=True)
                
                if not signals:
                    return None
                    
                threshold = getattr(self.signal_aggregator, 'confidence_threshold', 0.55)
                # Trong Pha 1 (fast_mode=True chưa chạy AI/JEV), chấm điểm sơ bộ 1 lần duy nhất với log_vetoes=False
                # để lọc chuẩn (gồm cả Bull Trap -0.85 và Chop Shield) nhưng không in đúp log rác trước khi sang Pha 2!
                votes_p1 = self.signal_aggregator._strategy_votes(
                    signals, apply_entry_vetoes=True, log_vetoes=False,
                    market_chop_context=self._get_market_chop_context(),
                )
                if votes_p1:
                    signed_p1_score = self.signal_aggregator.calculate_weighted_score(signals, votes=votes_p1, apply_entry_vetoes=True)
                    raw_p1_score = abs(signed_p1_score)
                    agreeing_p1 = sum(1 for v, _ in votes_p1.values() if v * signed_p1_score > 0)
                    p1_dir = 'BUY' if signed_p1_score > 0 else 'SELL'
                    df_15m_p1 = next(
                        (
                            s.metadata.get('dfs', {}).get('15m')
                            for s in signals
                            if isinstance(getattr(s, 'metadata', None), dict) and isinstance(s.metadata.get('dfs'), dict)
                        ),
                        None,
                    )
                    # [BÀI HỌC 87]: Kiểm tra xem cặp có đang có lệnh bắn tỉa M1 (pending_stalking_orders) không
                    stk_dict = getattr(self, 'pending_stalking_orders', {}) or {}
                    clean_p_sym = self._clean_symbol(pair)
                    active_stk = stk_dict.get(pair) or stk_dict.get(clean_p_sym)
                    is_opp_stalking = False
                    if active_stk:
                        stk_dir = active_stk.get('direction', 'LONG')
                        is_same_dir = (stk_dir == 'LONG' and p1_dir == 'BUY') or (stk_dir == 'SHORT' and p1_dir == 'SELL')
                        if is_same_dir:
                            # Đang có lệnh Limit Maker cùng chiều chờ khớp: không cần đẩy vào Pha 2 đốt GPU
                            return None
                        else:
                            is_opp_stalking = True

                    if agreeing_p1 >= self.signal_aggregator.min_agreeing_strategies and raw_p1_score >= threshold:
                        if not self._check_fomo(pair, direction=p1_dir, df_15m=df_15m_p1):
                            return {'pair': pair, 'score': float(raw_p1_score), 'direction': p1_dir, 'is_opposing_stalking': is_opp_stalking, 'is_open': False, 'active_pos': []}
                    elif agreeing_p1 >= 1:
                        # [BAI HOC 74] CHỐT CHẶN PHA 1 CHỐNG LÃNG PHÍ NGÂN SÁCH GPU PHA 2:
                        # Chỉ cho phép ứng viên 1 chiến thuật lọt vào Pha 2 nếu chiến thuật đó đạt chuẩn Trụ Cột Mạnh
                        # (raw_p1_score >= 0.72 hoặc có Trap cá mập >= 68%), đủ điều kiện để đánh thức JEV Agent LLM.
                        # Loại bỏ sớm các tín hiệu yếu (55% - 65%) chỉ có 1 phiếu để bảo toàn trọn vẹn 45s ngân sách Pha 2.
                        has_p1_anchor = any(
                            (
                                ('trend' in str(getattr(s, 'strategy', '')).lower() and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.75)
                                or ('trap' in str(getattr(s, 'strategy', '')).lower() and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.68)
                                or ('momentum' in str(getattr(s, 'strategy', '')).lower() and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.72)
                                or ('reversion' in str(getattr(s, 'strategy', '')).lower() and float(getattr(s, 'confidence', 0.0) or 0.0) >= 0.72)
                            )
                            for s in signals
                            if getattr(s, 'signal', None) is not None
                            and getattr(s.signal, 'value', '') != 'hold'
                            and ((1.0 if str(getattr(s.signal, 'value', '')).upper() == 'BUY' else -1.0) * signed_p1_score > 0)
                        )
                        if has_p1_anchor or raw_p1_score >= 0.72:
                            discounted_score = min(0.58, raw_p1_score * 0.72)
                            if discounted_score >= threshold * 0.90 and not self._check_fomo(pair, direction=p1_dir, df_15m=df_15m_p1):
                                return {'pair': pair, 'score': float(discounted_score), 'direction': p1_dir, 'is_opposing_stalking': is_opp_stalking, 'is_open': False, 'active_pos': []}
            except Exception as e:
                import traceback
                logger.error(f"Lỗi phân tích đa luồng Pha 1 cho {pair}: {e}")
            return None

        # Chạy đa luồng với 15 workers để tối đa hóa tốc độ tải dữ liệu
        logger.info(f"\n🔍 [MULTI-THREADING] Đang quét {len(target_pairs)} đồng coin cùng lúc...")
        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
            results = list(executor.map(process_pair, target_pairs))
            
        for r in results:
            if r is not None:
                candidates.append(r)
                
        # Sắp xếp ứng viên theo điểm số giảm dần kèm Xoay Vòng Công Bằng (Fair Rotation Engine)
        now_ts = time.time()
        self._phase2_veto_cooldowns = {k: v for k, v in self._phase2_veto_cooldowns.items() if v > now_ts}
        available_candidates = []
        for c in candidates:
            if c.get('is_open'):
                available_candidates.append(c)
                continue
            clean_cand_sym = self._clean_symbol(c['pair'])
            in_cand_p2_wl = (
                hasattr(self, '_fading_short_watchlist')
                and clean_cand_sym in self._fading_short_watchlist
                and now_ts < self._fading_short_watchlist.get(clean_cand_sym, 0)
                and getattr(self, '_symbol_loss_streaks', {}).get(clean_cand_sym, 0) == 0
            )
            cand_cd = max(
                0 if in_cand_p2_wl else self._manual_exit_cooldowns.get(clean_cand_sym, 0),
                0 if in_cand_p2_wl else self._symbol_cooldowns.get(clean_cand_sym, 0),
                self._phase2_veto_cooldowns.get(clean_cand_sym, 0)
            )
            if now_ts >= cand_cd:
                available_candidates.append(c)

        # Không đưa ứng viên còn cooldown trở lại Pha 2 nếu toàn bộ danh sách
        # đang bị khóa; vị thế mở vẫn được quản lý bởi luồng position monitor.
        candidates_to_sort = available_candidates
        if candidates and not candidates_to_sort:
            logger.info(
                "⏳ [FAIR ROTATION COOLDOWN] Bỏ qua Pha 2 chu kỳ này: cả %d ứng viên đều còn cooldown.",
                len(candidates),
            )
        candidates_to_sort.sort(key=lambda x: x['score'], reverse=True)
        # 2.2 PHA 2: Đánh giá sâu và Ra quyết định (Dynamic Full-Scan Pipeline)
        p2_start_ts = time.time()
        p2_time_budget_sec = 45.0  # Dành tối đa 45s cho Pha 2, bảo lưu 15s cho chu kỳ quét 60s
        # [BÀI HỌC 67] Ngân sách Pha 2 THÍCH ỨNG thay vì quét tràn lan rồi mới phát hiện quá giờ.
        # Mỗi lượt phân tích sâu (JEV/Ollama + Quantum + ML) tốn trung bình `ema` giây, nên số lượt
        # tối đa mà KHÔNG vượt ngân sách = (ngân sách - dự phòng) / ema. Trước đây pipeline chạy
        # hết danh sách rồi mới chặn bằng STALE ANALYSIS VETO: vừa đốt GPU vô ích, vừa gắn
        # cooldown 240s lên ứng viên chưa từng được ra quyết định.
        p2_budget_reserve_sec = 5.0
        try:
            p2_ema_analysis_sec = float(getattr(self, '_p2_ema_analysis_sec', 0.0) or 0.0)
        except (TypeError, ValueError, OverflowError):
            p2_ema_analysis_sec = 0.0
        if not (p2_ema_analysis_sec > 0):
            try:
                p2_ema_analysis_sec = float(
                    self.config.get('ai', {}).get('phase2_default_analysis_sec', 6.0) or 6.0
                )
            except (TypeError, ValueError, OverflowError):
                p2_ema_analysis_sec = 6.0
        p2_ema_analysis_sec = max(0.5, min(30.0, p2_ema_analysis_sec))
        usable_budget = max(0.0, p2_time_budget_sec - p2_budget_reserve_sec)
        try:
            allowed_evals = max(1, int(usable_budget / p2_ema_analysis_sec))
        except (TypeError, ValueError, OverflowError, ZeroDivisionError):
            allowed_evals = 1
        # Vị thế ĐANG MỞ phải luôn được xử lý trước (quản lý trailing/SL/TP), phần còn lại theo điểm.
        candidates_to_process = sorted(
            candidates_to_sort,
            key=lambda c: (
                0 if any(
                    self._clean_symbol(p.get('symbol')) == self._clean_symbol(c.get('pair'))
                    for p in self.open_positions
                ) else 1,
                -float(c.get('score') or 0.0),
            ),
        )
        p2_eval_count = 0
        logger.info(
            f"🎯 [DYNAMIC PIPELINE] Bắt đầu đánh giá sâu {len(candidates_to_process)} ứng viên tiềm năng "
            f"(ngân sách {p2_time_budget_sec:.0f}s, EMA phân tích {p2_ema_analysis_sec:.1f}s -> tối đa {allowed_evals} lượt)."
        )
        
        for cand_idx, cand in enumerate(candidates_to_process):
            pair = cand['pair']
            
            # Cầu dao Ngân sách Thời gian (Time Budget Guard) bảo vệ nhịp nến chu kỳ 60s
            if time.time() - p2_start_ts >= p2_time_budget_sec:
                logger.info(f"⏱️ [TIME BUDGET GUARD] Đã sử dụng hết ngân sách {p2_time_budget_sec:.0f}s của Pha 2. Dừng an toàn để bảo vệ nhịp nến chu kỳ.")
                break
            # Làm mới trạng thái vị thế mở theo thời gian thực (chống Race Condition khi M1 Sniper vừa khớp trong lúc chạy Pha 1)
            active_pos = [
                p for p in self.open_positions
                if self._clean_symbol(p.get('symbol')) == self._clean_symbol(pair)
            ]
            has_open_pos = len(active_pos) > 0

            # Bỏ qua đánh giá sâu nếu cặp đang trong thời gian Cooldown vừa đóng lỗ hoặc đang dính veto xoay vòng
            clean_p2_sym = self._clean_symbol(pair)
            in_p2_eval_wl = (
                hasattr(self, '_fading_short_watchlist')
                and clean_p2_sym in self._fading_short_watchlist
                and time.time() < self._fading_short_watchlist.get(clean_p2_sym, 0)
                and getattr(self, '_symbol_loss_streaks', {}).get(clean_p2_sym, 0) == 0
            )
            p2_cd_until = max(
                0 if in_p2_eval_wl else self._manual_exit_cooldowns.get(clean_p2_sym, 0),
                0 if in_p2_eval_wl else self._symbol_cooldowns.get(clean_p2_sym, 0),
                self._phase2_veto_cooldowns.get(clean_p2_sym, 0) if not has_open_pos else 0
            )
            if time.time() < p2_cd_until:
                continue
            
            if not self.is_running:
                break

            # [BÀI HỌC 67] Kiểm tra ngân sách TRƯỚC khi đốt GPU: nếu thời gian còn lại không đủ
            # cho một lượt phân tích nữa thì bỏ qua ứng viên này mà KHÔNG đặt cooldown (nó chưa hề
            # được đánh giá, phải được ưu tiên xét lại ở chu kỳ sau). Cổng thời gian tự hiệu chuẩn
            # theo EMA nên không bao giờ bóp nghẹt việc quét khi JEV trả lời nhanh.
            if not has_open_pos:
                remaining_budget = p2_time_budget_sec - (time.time() - p2_start_ts)
                need_budget = max(1.0, p2_ema_analysis_sec * 0.8)
                if remaining_budget < need_budget:
                    remaining_has_open_after = any(
                        any(
                            self._clean_symbol(p.get('symbol')) == self._clean_symbol(c.get('pair'))
                            for p in self.open_positions
                        )
                        for c in candidates_to_process[cand_idx:]
                    )
                    logger.info(
                        "⏱️ [PHASE2 BUDGET SKIP] Còn %.1fs < cần %.1fs (EMA phân tích %.1fs, đã dùng %d/%d lượt ước tính): "
                        "hoãn %s và các ứng viên sau (không đặt cooldown).",
                        remaining_budget, need_budget, p2_ema_analysis_sec,
                        p2_eval_count, allowed_evals, pair,
                    )
                    if remaining_has_open_after:
                        continue
                    break

            try:
                # Kiểm tra slot & rủi ro danh mục (Hỗ trợ Đa Tầng Vốn & Free-Roll Gia Tăng Lãi)
                configured_max = self._configured_max_open_positions()
                occupied_slots = len(self.open_positions) + len(getattr(self, 'pending_stalking_orders', {}))
                if not has_open_pos:
                    # Kiểm tra xem danh sách ứng viên còn lại có cặp nào đang là vị thế mở cần quản lý không
                    remaining_has_open = any(
                        any(self._clean_symbol(p.get('symbol')) == self._clean_symbol(c['pair']) for p in self.open_positions)
                        for c in candidates_to_process[cand_idx+1:]
                    )
                    if not getattr(self, 'free_roll_recycling', True):
                        if occupied_slots >= configured_max:
                            if not remaining_has_open:
                                logger.info("🛑 [EARLY BREAK] Dừng quét Pha 2: Số vị thế đã chạm trần cấu hình %d.", configured_max)
                                break
                            else:
                                logger.info("⏸️ Bỏ qua đánh giá sâu %s: số vị thế đã chạm trần cấu hình %d.", pair, configured_max)
                                continue
                    else:
                        free_roll_count = sum(1 for p in getattr(self, 'open_positions', []) if self._is_position_risk_free(p))
                        effective_cap = min(configured_max + free_roll_count, configured_max + 2)
                        at_risk_slots = self._count_at_risk_positions() + len(getattr(self, 'pending_stalking_orders', {}))
                        max_at_risk = self._configured_max_at_risk_positions()
                        if occupied_slots >= effective_cap:
                            if not remaining_has_open:
                                logger.info("🛑 [EARLY BREAK] Dừng quét Pha 2: Tổng số vị thế & lệnh rình mồi (%d) đã chạm trần tối đa %d.", occupied_slots, effective_cap)
                                break
                            else:
                                logger.info("⏸️ Bỏ qua đánh giá sâu %s: số vị thế & lệnh rình mồi (%d) đã chạm trần tối đa %d.", pair, occupied_slots, effective_cap)
                                continue
                        if at_risk_slots >= max_at_risk:
                            if not remaining_has_open:
                                logger.info("🛑 [EARLY BREAK] Dừng quét Pha 2: Vòi rủi ro đang đầy (%d/%d vị thế chịu rủi ro).", at_risk_slots, max_at_risk)
                                break
                            else:
                                logger.info("⏸️ Bỏ qua đánh giá sâu %s: vòi rủi ro đang đầy (%d/%d vị thế chịu rủi ro).", pair, at_risk_slots, max_at_risk)
                                continue

                # [BÀI HỌC 87]: Nếu cặp tiền này đang có lệnh bắn tỉa M1 cùng chiều (pending_stalking_orders)
                # và không phải là vị thế mở, bỏ qua phân tích sâu để không đốt 5-10s GPU Ollama / làm nghẽn ngân sách Pha 2!
                clean_pair_p2 = self._clean_symbol(pair)
                stk_dict_p2 = getattr(self, 'pending_stalking_orders', {}) or {}
                active_stk_p2 = stk_dict_p2.get(pair) or stk_dict_p2.get(clean_pair_p2)
                if active_stk_p2 and not has_open_pos:
                    stk_dir_p2 = active_stk_p2.get('direction', 'LONG')
                    cand_dir_p2 = cand.get('direction', '')
                    cand_is_opposing = bool(cand.get('is_opposing_stalking'))
                    if not cand_is_opposing and cand_dir_p2 and ((stk_dir_p2 == 'LONG' and cand_dir_p2 == 'BUY') or (stk_dir_p2 == 'SHORT' and cand_dir_p2 == 'SELL')):
                        logger.info(
                            "⏳ Bỏ qua phân tích sâu %s: Đang có lệnh Limit Maker %s (order %s) chờ khớp trên sàn. Bảo lưu ngân sách Pha 2!",
                            pair, stk_dir_p2, active_stk_p2.get('order_id', '')
                        )
                        continue

                logger.info(f"\n🧠 Phân tích sâu (Pha 2): {pair}...")
                _p2_analysis_started = time.time()
                signals = self._analyze_market(pair, fast_mode=False)
                # [BÀI HỌC 67] Học thời lượng phân tích thật để hiệu chuẩn ngân sách các chu kỳ sau.
                _p2_analysis_sec = max(0.0, time.time() - _p2_analysis_started)
                p2_eval_count += 1
                try:
                    _prev_ema = float(getattr(self, '_p2_ema_analysis_sec', 0.0) or 0.0)
                except (TypeError, ValueError, OverflowError):
                    _prev_ema = 0.0
                self._p2_ema_analysis_sec = (
                    (0.7 * _prev_ema) + (0.3 * _p2_analysis_sec) if _prev_ema > 0 else _p2_analysis_sec
                )

                # Kiểm tra lại lần nữa sau khi _analyze_market (chạy JEV/Ollama mất 5-15s) hoàn tất,
                # đề phòng luồng 10s vừa kích hoạt lệnh M1 Sniper của chính cặp này vào open_positions!
                active_pos = [
                    p for p in self.open_positions
                    if self._clean_symbol(p.get('symbol')) == self._clean_symbol(pair)
                ]
                has_open_pos = len(active_pos) > 0
                if not has_open_pos and (time.time() - p2_start_ts) >= p2_time_budget_sec:
                    logger.warning(
                        "⏱️ [STALE ANALYSIS VETO] %s vượt ngân sách Pha 2 sau khi phân tích; không thực thi trên dữ liệu cũ.",
                        pair,
                    )
                    self._set_phase2_veto_cooldown(pair, 240.0)
                    break
                
                if has_open_pos:
                    pos = active_pos[0]
                    current_dir = pos.get('direction', 'LONG')
                    raw_score = self.signal_aggregator.calculate_weighted_score(signals, apply_entry_vetoes=False) if signals else 0.0

                    ticker = self.exchange.get_ticker(pair)
                    raw_ticker_last = (ticker.get('last') or ticker.get('close')) if ticker else None
                    if raw_ticker_last is not None:
                        try:
                            current_price = float(raw_ticker_last) if (math.isfinite(float(raw_ticker_last)) and float(raw_ticker_last) > 0) else float(pos.get('entry_price', 0))
                        except (TypeError, ValueError):
                            current_price = float(pos.get('entry_price', 0))
                    else:
                        current_price = float(pos.get('entry_price', 0))
                    entry_price = float(pos.get('entry_price') or pos.get('price', 0))
                    
                    pnl_pct = 0.0
                    if entry_price > 0 and current_price > 0:
                        if current_dir == 'LONG':
                            pnl_pct = (current_price - entry_price) / entry_price
                        else:
                            pnl_pct = (entry_price - current_price) / entry_price

                    old_best_p2 = pos.get('trailing_best_price')
                    try:
                        old_best_p2 = float(old_best_p2) if old_best_p2 is not None else None
                    except (TypeError, ValueError, OverflowError):
                        old_best_p2 = None
                    if current_dir == 'LONG':
                        best_p2 = max(entry_price, current_price, old_best_p2 or 0.0)
                        peak_profit_p2 = (best_p2 - entry_price) / entry_price if entry_price > 0 else 0.0
                    else:
                        valid_b2 = [v for v in (entry_price, current_price, old_best_p2) if v is not None and v > 0]
                        best_p2 = min(valid_b2) if valid_b2 else entry_price
                        peak_profit_p2 = (entry_price - best_p2) / entry_price if entry_price > 0 else 0.0
                    pos['trailing_best_price'] = best_p2
                    
                    held_minutes = 0.0
                    pos_timestamp_str = pos.get('timestamp')
                    try:
                        if pos_timestamp_str:
                            pos_dt = datetime.fromisoformat(pos_timestamp_str)
                            held_minutes = (datetime.now() - pos_dt).total_seconds() / 60.0
                    except Exception:
                        pass
                    
                    # 2. Điều kiện đảo chiều từ AI & Chỉ báo kỹ thuật:
                    # Thời gian thở tối thiểu (Grace Period): 15 phút đầu không kích hoạt thoát sớm đảo chiều thông thường,
                    # NHƯNG nếu AI Ensemble phát tín hiệu đảo chiều khẩn cấp (conf >= 0.72) kèm vị thế đang lỗ <= -0.55%
                    # (ví dụ TIA/USDT vừa hết Cold-start báo SELL 76.2%), cho phép phá khóa Grace Period thoát hiểm ngay!
                    in_grace_period = held_minutes < 15.0
                    has_safe_profit = pnl_pct >= 0.0085 or bool(pos.get('trailing_active'))
                    
                    # Đếm số lượng chiến thuật báo đảo chiều mạnh (conf >= 0.65) và kiểm tra AI Ensemble / Trap khẩn cấp
                    opposing_strategies = set()
                    ai_emergency_opposing = False
                    trap_emergency_opposing = False
                    if signals and not has_safe_profit:
                        ma_pos_chk = next(
                            (
                                s.metadata.get('market_analysis')
                                for s in signals
                                if isinstance(getattr(s, 'metadata', None), dict)
                                and isinstance(s.metadata.get('market_analysis'), dict)
                            ),
                            {},
                        ) or {}
                        pos_uwick = float(ma_pos_chk.get('upper_wick_pct') or 0.0)
                        pos_lwick = float(ma_pos_chk.get('lower_wick_pct') or 0.0)
                        pos_dump = float(ma_pos_chk.get('recent_dump_pct') or 0.0)
                        pos_rvol = float(ma_pos_chk.get('candle_vol_ratio') or 1.0)
                        pos_is_waterfall = (
                            (pos_dump >= 0.025 and pos_lwick < 0.30)
                            or (pos_dump >= 0.035 and pos_lwick < 0.40)
                            or (pos_dump >= 0.015 and pos_lwick < 0.25 and pos_rvol >= 1.30)
                        )
                        for s in signals:
                            s_dir = getattr(getattr(s, 'signal', None), 'value', str(getattr(s, 'signal', ''))).lower()
                            s_conf = float(getattr(s, 'confidence', 0.0) or 0.0)
                            s_strat = str(getattr(s, 'strategy', '')).lower()
                            s_meta = getattr(s, 'metadata', None) if isinstance(getattr(s, 'metadata', None), dict) else {}
                            s_tf = str(s_meta.get('timeframe') or '15m').strip().lower()
                            s_type = str(s_meta.get('type') or '').strip().upper()
                            if current_dir == 'LONG' and s_dir == 'sell':
                                if s_strat in ('trap_detector', 'trapdetector'):
                                    valid_sell_trap = (
                                        (s_tf == '15m' and (s_type in ('BULL_TRAP_WICK', 'BUYING_CLIMAX') or pos_uwick >= 0.35))
                                        or (s_tf == '1h' and pos_uwick >= 0.30)
                                    )
                                    if not valid_sell_trap:
                                        continue
                                if s_conf >= 0.65:
                                    opposing_strategies.add(s_strat)
                                if s_strat == 'ai_ensemble' and s_conf >= 0.72:
                                    ai_emergency_opposing = True
                                if s_strat in ('trap_detector', 'trapdetector') and s_conf >= 0.65:
                                    trap_emergency_opposing = True
                            elif current_dir == 'SHORT' and s_dir == 'buy':
                                if s_strat in ('trap_detector', 'trapdetector'):
                                    valid_buy_trap = (not pos_is_waterfall) and (
                                        (s_tf == '15m' and (s_type in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX') or pos_lwick >= 0.35))
                                        or (s_tf == '1h' and pos_lwick >= 0.30)
                                    )
                                    if not valid_buy_trap:
                                        continue
                                if s_conf >= 0.65:
                                    opposing_strategies.add(s_strat)
                                if s_strat == 'ai_ensemble' and s_conf >= 0.72:
                                    ai_emergency_opposing = True
                                if s_strat in ('trap_detector', 'trapdetector') and s_conf >= 0.65:
                                    trap_emergency_opposing = True

                    pos_trap_type = str(pos.get('trap_type') or '')
                    is_trap_trade = any(t in pos_trap_type for t in ('BULL_TRAP', 'BEAR_TRAP', 'BUYING_CLIMAX', 'SELLING_CLIMAX'))
                    reversal_score_threshold = 0.50 if is_trap_trade else 0.35

                    # [BÀI HỌC 93 - PHÁ KHÓA GRACE BẰNG CỘT MỐC CÁ MẬP WHALE ANCHOR]:
                    # Mô hình AI Ensemble bị đóng băng cứng trên khung 4H nên không thể dùng làm cứu hộ độc lập (cắt non 3 lệnh thắng).
                    # BẮT BUỘC có Cột Mốc Cá Mập đối kháng vật lý (Thác đổ WaterfallDump đối kháng LONG, hoặc Bão Volume WhalePumpStorm đối kháng SHORT):
                    ma_grace = next(
                        (
                            s.metadata.get('market_analysis')
                            for s in (signals or [])
                            if isinstance(getattr(s, 'metadata', None), dict)
                            and isinstance(s.metadata.get('market_analysis'), dict)
                        ),
                        {},
                    ) or {}
                    g_uwick = float(ma_grace.get('upper_wick_pct') or 0.0)
                    g_lwick = float(ma_grace.get('lower_wick_pct') or 0.0)
                    g_dump = float(ma_grace.get('recent_dump_pct') or 0.0)
                    g_pump = float(ma_grace.get('recent_pump_pct') or 0.0)
                    g_rvol = float(ma_grace.get('candle_vol_ratio') or 1.0)
                    is_opposing_whale_anchor = False
                    if current_dir == 'LONG':
                        is_opposing_whale_anchor = (
                            (g_dump >= 0.025 and g_lwick < 0.30)
                            or (g_dump >= 0.035 and g_lwick < 0.40)
                            or (g_dump >= 0.015 and g_lwick < 0.25 and g_rvol >= 1.30)
                        )
                    else:
                        is_opposing_whale_anchor = (
                            (g_pump >= 0.025 and g_rvol >= 2.0 and g_uwick < 0.30)
                            or (g_rvol >= 2.5 and g_pump >= 0.015 and g_uwick < 0.30)
                        )

                    is_emergency_ai_reversal = (
                        in_grace_period
                        and held_minutes >= 1.5
                        and pnl_pct <= -0.0030
                        and is_opposing_whale_anchor
                    )

                    is_emergency_trap_reversal = (
                        in_grace_period
                        and held_minutes >= 2.0
                        and pnl_pct <= -0.0035
                        and trap_emergency_opposing
                    )

                    # 1. BẮT BUỘC vị thế phải đang lỗ (pnl_pct < 0.0) thì mới xét đảo chiều. TUYỆT ĐỐI KHÔNG cắt khi lệnh đang xanh!
                    # 2. Phải có ít nhất 2 chiến thuật đối kháng (len(opposing_strategies) >= 2) - trừ phi khẩn cấp trong Grace Period.
                    # 3. Loại bỏ hoàn toàn bẫy raw_score <= -0.55 của 1 mô hình AI Ensemble đơn độc.
                    is_reversed = (not has_safe_profit) and (pnl_pct < 0.0) and (
                        is_emergency_ai_reversal
                        or is_emergency_trap_reversal
                        or (
                            not in_grace_period and (
                                len(opposing_strategies) >= 2 and (
                                    (current_dir == 'LONG' and raw_score <= -reversal_score_threshold) or 
                                    (current_dir == 'SHORT' and raw_score >= reversal_score_threshold)
                                )
                            )
                        )
                    )
                    
                    # Thoát lệnh theo thời gian (Time Decay & Early Invalidation) được quản lý tập trung và an toàn
                    # trong _check_open_positions_locked (có kiểm tra lock, sàn stop-loss và xu hướng EMA).
                    # [BAI HOC 68] LỆNH TAY DO NGƯỜI DÙNG TỰ MỞ: bot TUYỆT ĐỐI không tự đóng theo
                    # phán đoán đảo chiều (AI Ensemble / TrapDetector / điểm tổng hợp). Chỉ hỗ trợ
                    # SL sàn, TP và Trailing. Đây là quyền quyết định của người dùng.
                    if self._is_manual_position(pos):
                        if is_reversed or is_emergency_ai_reversal or is_emergency_trap_reversal:
                            logger.info(
                                "🖐️ [MANUAL POSITION SUPPORT-ONLY] Bỏ qua tín hiệu đảo chiều cho lệnh tay %s (%s, điểm %+.4f). "
                                "Chỉ giữ SL sàn/TP/Trailing, không tự đóng vị thế của người dùng.",
                                pair, current_dir, raw_score,
                            )
                        is_reversed = False
                        is_emergency_ai_reversal = False
                        is_emergency_trap_reversal = False
                    if is_emergency_ai_reversal and not self._is_manual_position(pos):
                        logger.warning(
                            f"🚨 [PHÁ KHÓA GRACE PERIOD - CỨU HỘ CÁ MẬP WHALE ANCHOR] Phát hiện dòng tiền cá mập xả/bơm đối kháng ngược lệnh {pair} ({current_dir}) "
                            f"(Điểm AI: {raw_score:+.4f}, PnL: {pnl_pct*100:+.2f}%, Đã giữ: {held_minutes:.1f}m)! Thoát hiểm ngay lập tức!"
                        )
                        self._close_position(pos, current_price, close_reason=f"🚨 AI Ensemble cứu hộ khẩn cấp trong Grace Period (Điểm: {raw_score:+.4f})")
                    elif is_emergency_trap_reversal and not self._is_manual_position(pos):
                        logger.warning(
                            f"🚨 [PHÁ KHÓA GRACE PERIOD - THOÁT BẪY RÂU KHẨN CẤP] TrapDetector phát hiện Bẫy Râu đảo chiều ngược lệnh {pair} ({current_dir}) "
                            f"(PnL: {pnl_pct*100:+.2f}%, Đã giữ: {held_minutes:.1f}m)! Thoát hiểm bảo toàn vốn ngay lập tức!"
                        )
                        self._close_position(pos, current_price, close_reason=f"🚨 TrapDetector xác nhận Bẫy Râu đảo chiều trong Grace Period (PnL: {pnl_pct*100:+.2f}%)")
                    elif in_grace_period and not has_safe_profit:
                        logger.info(f"   [Thời gian thở Grace Period] Vị thế {pair} ({current_dir}): Đã giữ {held_minutes:.1f}/15.0m, PnL: {pnl_pct*100:+.2f}%, Điểm AI: {raw_score:+.4f}. Đang bảo vệ lệnh khỏi nhiễu nến 1m!")
                    elif is_reversed and skip_dynamic_exit_this_cycle:
                        logger.info("Giữ vị thế %s trong chu kỳ đầu; Điểm AI %+.4f, PnL: %+.2f%%.", pair, raw_score, pnl_pct * 100)
                    elif is_reversed and not self._is_manual_position(pos):
                        logger.warning(f"🛑 [THOÁT SỚM THÔNG MINH] AI báo động đảo chiều (Điểm: {raw_score:+.4f}, Đối kháng: {len(opposing_strategies)}/chiến thuật, Đã giữ: {held_minutes:.1f}m)! Đóng khẩn cấp lệnh {pair} ({current_dir}).")
                        self._close_position(pos, current_price, close_reason=f"AI phát hiện đảo chiều, Thoát sớm bảo toàn vốn (Điểm: {raw_score:+.4f})")
                    else:
                        logger.info(f"   [Giám sát lệnh] Vị thế {pair} ({current_dir}): PnL: {pnl_pct*100:+.2f}%, Điểm AI: {raw_score:+.4f}, Đã giữ: {held_minutes:.0f}m. Tiếp tục theo dõi!")
                    
                    continue

                if not signals:
                    logger.info(f"  ➡️ Không có tín hiệu cho {pair}")
                    if not has_open_pos:
                        self._set_phase2_veto_cooldown(pair, 240.0)
                    continue

                final_signal = self.signal_aggregator.aggregate(
                    signals, market_chop_context=self._get_market_chop_context()
                )

                if final_signal:
                    final_signal.metadata['ai_bias'] = bias
                    logger.info(
                        f" TIN HIEU CUOI: {final_signal.signal.value.upper()} "
                        f"{final_signal.symbol} "
                        f"(confidence: {final_signal.confidence:.2%})"
                    )

                    is_stock_gate = MarketScanner.is_tradfi_stock(final_signal.symbol) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(final_signal.symbol))
                    base_coin_gate = final_signal.symbol.split('/')[0].split(':')[0].strip().upper()
                    is_major_gate = base_coin_gate in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')

                    if not is_stock_gate:
                        # VỚI CRYPTO (MAJOR & ALTCOIN): TUÂN THỦ NGHIÊM NGẶT AI BIAS VĨ MÔ
                        if bias == 'BEARISH' and final_signal.signal.value.upper() == 'BUY':
                            has_trap_wick = isinstance(getattr(final_signal, 'metadata', None), dict) and (
                                final_signal.metadata.get('type') in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX')
                                or (bool(final_signal.metadata.get('is_oversold_bounce')) and float(final_signal.metadata.get('c_lower_wick_pct', 0.0)) >= 0.35)
                                or bool(final_signal.metadata.get('is_momentum_ride'))
                            )
                            if not (has_trap_wick and final_signal.confidence >= 0.80):
                                logger.warning(f"🛡️ VETO AI BIAS: Chặn hoàn toàn lệnh BUY {final_signal.symbol} vì ngược hướng AI bias BEARISH toàn thị trường (Conf: {final_signal.confidence:.2%})! Cấm bắt dao rơi.")
                                if not has_open_pos:
                                    self._set_phase2_veto_cooldown(pair, 240.0)
                                try:
                                    from core.gate_telemetry import record_radar_candidate
                                    record_radar_candidate(
                                        symbol=final_signal.symbol,
                                        side='BUY',
                                        confidence=final_signal.confidence,
                                        score=float((final_signal.metadata or {}).get('weighted_score', 0.0) or 0.0),
                                        strategies_agreed=str(final_signal.strategy),
                                        dynamic_leverage=None,
                                        bottleneck_gate='AI_BIAS_VETO',
                                        bottleneck_reason="Ngược hướng AI Bias BEARISH toàn sàn. Cấm bắt dao rơi",
                                        readiness_pct=72.0
                                    )
                                except Exception:
                                    pass
                                continue
                            else:
                                logger.info(f"⚡ VƯỢT RÀO AI BIAS CÓ KIỂM SOÁT: Cho phép BUY {final_signal.symbol} do phát hiện bẫy gấu rút chân gom hàng (BEAR_TRAP_WICK, Conf: {final_signal.confidence:.2%})!")
                        elif bias == 'BULLISH' and final_signal.signal.value.upper() == 'SELL':
                            has_trap_wick = isinstance(getattr(final_signal, 'metadata', None), dict) and (
                                final_signal.metadata.get('type') in ('BULL_TRAP_WICK', 'BULL_TRAP_BOUNCE', 'BUYING_CLIMAX', 'WATERFALL_BREAKDOWN_SHORT')
                                or bool(final_signal.metadata.get('is_fading_short'))
                                or bool(final_signal.metadata.get('is_waterfall_short'))
                            )
                            
                            if is_major_gate:
                                # Với Coin Top (BTC, ETH, SOL, BNB, XRP): Tuyệt đối không SHORT khi AI Bias toàn sàn là BULLISH
                                if not (has_trap_wick and final_signal.confidence >= 0.80):
                                    logger.warning(f"🛡️ VETO AI BIAS: Chặn lệnh SELL Coin Top {final_signal.symbol} vì ngược hướng AI bias BULLISH toàn thị trường (Conf: {final_signal.confidence:.2%})!")
                                    if not has_open_pos:
                                        self._set_phase2_veto_cooldown(pair, 240.0)
                                    continue
                                else:
                                    logger.info(f"⚡ VƯỢT RÀO AI BIAS CÓ KIỂM SOÁT: Cho phép SELL {final_signal.symbol} do phát hiện bẫy tăng xả hàng (BULL_TRAP_WICK, Conf: {final_signal.confidence:.2%})!")
                            else:
                                # Với Altcoin lẻ: Cho phép SHORT nếu có tín hiệu xả mạnh (>= 75%) hoặc Bull Trap
                                is_strong_alt_sell = final_signal.confidence >= 0.75 or has_trap_wick
                                if not is_strong_alt_sell:
                                    logger.warning(f"🛡️ VETO AI BIAS: Chặn lệnh SELL Altcoin {final_signal.symbol} vì tín hiệu chưa đủ mạnh để ngược AI bias BULLISH (Conf: {final_signal.confidence:.2%} < 75%)!")
                                    if not has_open_pos:
                                        self._set_phase2_veto_cooldown(pair, 240.0)
                                    continue
                                else:
                                    logger.info(f"🎯 CHO PHÉP SHORT ALTCOIN: {final_signal.symbol} có tín hiệu xả mạnh (Conf: {final_signal.confidence:.2%}), cho phép SHORT đón sóng giảm dù BTC đang hồi nhẹ!")
                    else:
                        logger.info(f"🏛️ TRADFI INDEPENDENT GATE: {final_signal.symbol} là Cổ phiếu / Hàng hóa, vận hành độc lập theo phiên Wall Street, không bị ràng buộc bởi Crypto AI Bias ({bias}).")
                        
                    base_cap = self._configured_max_open_positions()
                    stalking_excluding_self = sum(
                        1 for s_sym in getattr(self, 'pending_stalking_orders', {})
                        if self._clean_symbol(s_sym) != self._clean_symbol(final_signal.symbol)
                    )
                    occupied_slots = len(self.open_positions) + stalking_excluding_self
                    if not getattr(self, 'free_roll_recycling', True) and occupied_slots >= base_cap:
                        logger.info(
                            "⏸️ Đã đạt trần vị thế danh nghĩa %s: đang có %d/%d (Gia Tăng Vị Thế Khi Bảo Toàn Vốn: TẮT).",
                            pair, occupied_slots, base_cap
                        )
                        continue

                    dynamic_position_limit = self._dynamic_open_position_limit(final_signal)
                    if occupied_slots >= dynamic_position_limit:
                        logger.info("⏸️ Chưa đủ chất lượng để thêm vị thế %s: đang có %d, giới hạn động %d/%d.", pair, occupied_slots, dynamic_position_limit, base_cap)
                        try:
                            from core.gate_telemetry import record_radar_candidate
                            record_radar_candidate(
                                symbol=final_signal.symbol,
                                side=final_signal.signal.value.upper(),
                                confidence=final_signal.confidence,
                                score=float((final_signal.metadata or {}).get('weighted_score', 0.0) or 0.0),
                                strategies_agreed=str(final_signal.strategy),
                                dynamic_leverage=None,
                                bottleneck_gate='SLOT_CAPACITY',
                                bottleneck_reason=f"Đã đạt giới hạn vị thế ({occupied_slots}/{dynamic_position_limit}). Đang chờ slot trống",
                                readiness_pct=92.0
                            )
                        except Exception:
                            pass
                        continue

                    # Phân bổ ngân sách rủi ro (Risk Budgeting Gate) - Giới hạn số vị thế ĐANG CHỊU RỦI RO (At-Risk Slots)
                    at_risk_slots = self._count_at_risk_positions(exclude_symbol=final_signal.symbol) + stalking_excluding_self
                    max_at_risk = self._configured_max_at_risk_positions()
                    if at_risk_slots >= max_at_risk:
                        logger.info(
                            "🛡️ RISK CAPACITY GATE: Đang có %d/%d vị thế chịu rủi ro, tạm giữ %s trên Ra-đa Lượng Tử chờ vị thế hiện tại Free-Roll.",
                            at_risk_slots, max_at_risk, pair
                        )
                        try:
                            from core.gate_telemetry import record_radar_candidate
                            record_radar_candidate(
                                symbol=final_signal.symbol,
                                side=final_signal.signal.value.upper(),
                                confidence=final_signal.confidence,
                                score=float((final_signal.metadata or {}).get('weighted_score', 0.0) or 0.0),
                                strategies_agreed=str(final_signal.strategy),
                                dynamic_leverage=None,
                                bottleneck_gate='RISK_CAPACITY',
                                bottleneck_reason=f"Đang có {at_risk_slots}/{max_at_risk} vị thế chịu rủi ro. Chờ vị thế cũ hòa vốn / partial TP",
                                readiness_pct=94.0
                            )
                        except Exception:
                            pass
                        continue

                    # Ký quỹ khả dụng tối thiểu (Free Margin Ratio >= 30% NAV)
                    portfolio_equity_sc, _, available_margin_sc = self._portfolio_capacity_snapshot()
                    free_margin_ratio_sc = available_margin_sc / max(1.0, portfolio_equity_sc)
                    if free_margin_ratio_sc < 0.30:
                        logger.info("🛡️ MARGIN CAPACITY GATE: Ký quỹ khả dụng %.2f%% (< 30.0%%), giữ %s trên Ra-đa Lượng Tử.", free_margin_ratio_sc * 100, pair)
                        continue

                    is_warmup_cycle = (getattr(self, 'cycle_count', 0) <= 1)
                    if is_warmup_cycle and not has_open_pos:
                        logger.info(
                            "🛡️ [LUẬT NGẦM WARM-UP - CHU KỲ #1] %s đạt tín hiệu %s (Độ tin cậy: %.2f%%) nhưng bot đang chạy Chu kỳ #1 Warm-up. "
                            "Tạm khóa mở lệnh mới trong 60s đầu để nạp nóng AI VRAM và đồng bộ nến (Sẵn sàng mở lệnh từ Chu kỳ #2)!",
                            final_signal.symbol, final_signal.signal.value.upper(), final_signal.confidence * 100
                        )
                        continue
                        
                    result = self._execute_signal(final_signal)
                    is_already_stalking = isinstance(result, dict) and result.get('status') == 'ALREADY_STALKING'
                    try:
                        from core.gate_telemetry import record_phase2_candidate
                        if is_already_stalking:
                            p2_status = 'STALKING'
                            p2_action = 'WAITING_FILL'
                        elif result:
                            p2_status = 'EXECUTED'
                            p2_action = 'OPEN_ORDER'
                        else:
                            p2_status = 'PRE_TRADE_BLOCKED'
                            p2_action = 'BLOCKED_AT_PRE_TRADE'
                        record_phase2_candidate({
                            'symbol': pair,
                            'status': p2_status,
                            'side': final_signal.signal.value.upper(),
                            'confidence': float(final_signal.confidence),
                            'score': float((final_signal.metadata or {}).get('weighted_score', 0.0) or 0.0),
                            'action': p2_action,
                        })
                    except Exception:
                        pass
                    if result and not is_already_stalking:
                        logger.info(f"✅ Lệnh được thực thi thành công!")
                        self._phase2_veto_cooldowns.pop(self._clean_symbol(pair), None)
                    elif not is_already_stalking:
                        if not has_open_pos:
                            self._set_phase2_veto_cooldown(pair, 240.0)
                else:
                    logger.info(f"  ⏳ Chưa đủ điều kiện giao dịch cho {pair}")
                    try:
                        from core.gate_telemetry import record_phase2_candidate
                        raw_sc = 0.0
                        if signals:
                            raw_sc = self.signal_aggregator.calculate_weighted_score(signals, apply_entry_vetoes=False)
                        record_phase2_candidate({
                            'symbol': pair,
                            'status': 'VETOED_OR_HOLD',
                            'side': 'HOLD',
                            'confidence': 0.0,
                            'score': round(float(raw_sc), 4),
                            'action': 'REJECTED',
                        })
                    except Exception:
                        pass
                    if not has_open_pos:
                        self._set_phase2_veto_cooldown(pair, 240.0)

                    # PHƯƠNG ÁN A+: HỦY LỆNH RÌNH MỒI NẾU PHÁT HIỆN BẪY RÂU VẬT LÝ 15M / ĐẢO CHIỀU ĐỐI KHÁNG
                    if pair in getattr(self, 'pending_stalking_orders', {}):
                        stk_chk = self.pending_stalking_orders[pair]
                        stk_dir = stk_chk.get('direction', 'LONG')
                        opp_dir = 'SELL' if stk_dir == 'LONG' else 'BUY'
                        ma_stk_chk = next(
                            (
                                s.metadata.get('market_analysis')
                                for s in (signals or [])
                                if isinstance(getattr(s, 'metadata', None), dict)
                                and isinstance(s.metadata.get('market_analysis'), dict)
                            ),
                            {},
                        ) or {}
                        stk_uwick = float(ma_stk_chk.get('upper_wick_pct') or 0.0)
                        stk_lwick = float(ma_stk_chk.get('lower_wick_pct') or 0.0)
                        stk_dump = float(ma_stk_chk.get('recent_dump_pct') or 0.0)
                        stk_rvol = float(ma_stk_chk.get('candle_vol_ratio') or 1.0)
                        stk_is_waterfall = (
                            (stk_dump >= 0.025 and stk_lwick < 0.30)
                            or (stk_dump >= 0.035 and stk_lwick < 0.40)
                            or (stk_dump >= 0.015 and stk_lwick < 0.25 and stk_rvol >= 1.30)
                        )
                        has_opp_trap = False
                        for s in (signals or []):
                            if str(getattr(s, 'strategy', '')).lower() not in ('trap_detector', 'trapdetector'):
                                continue
                            if getattr(getattr(s, 'signal', None), 'value', str(getattr(s, 'signal', ''))).upper() != opp_dir:
                                continue
                            if float(getattr(s, 'confidence', 0.0) or 0.0) < 0.60:
                                continue
                            s_meta_stk = getattr(s, 'metadata', None) if isinstance(getattr(s, 'metadata', None), dict) else {}
                            s_tf_stk = str(s_meta_stk.get('timeframe') or '15m').strip().lower()
                            s_type_stk = str(s_meta_stk.get('type') or '').strip().upper()
                            if opp_dir == 'SELL':
                                if (s_tf_stk == '15m' and (s_type_stk in ('BULL_TRAP_WICK', 'BUYING_CLIMAX') or stk_uwick >= 0.35)) or (s_tf_stk == '1h' and stk_uwick >= 0.30):
                                    has_opp_trap = True
                                    break
                            else:
                                if (not stk_is_waterfall) and ((s_tf_stk == '15m' and (s_type_stk in ('BEAR_TRAP_WICK', 'SELLING_CLIMAX') or stk_lwick >= 0.35)) or (s_tf_stk == '1h' and stk_lwick >= 0.30)):
                                    has_opp_trap = True
                                    break
                        if has_opp_trap:
                            logger.warning(
                                f"🛡️ [BẪY RÂU ĐẢO CHIỀU - HỦY LỆNH MAKER] {pair}: TrapDetector phát hiện {opp_dir} đối kháng "
                                f"trong khi đang treo lệnh đón lõng {stk_dir}! HỦY LỆNH MAKER NGAY LẬP TỨC ĐỂ BẢO VỆ VỐN!"
                            )
                            oid = stk_chk.get('order_id')
                            cancel_confirmed = True
                            if self.mode == 'live' and oid:
                                cancel_confirmed = self._cancel_stalking_order(pair, stk_chk, str(oid), time.time())
                            if cancel_confirmed:
                                self.pending_stalking_orders.pop(pair, None)
                            self._save_state()
                            try:
                                from core.gate_telemetry import clear_radar_candidate
                                clear_radar_candidate(pair)
                            except Exception:
                                pass
                            self._notify_telegram(
                                f"🛡️ **[HỦY LỆNH MAKER - PHÁT HIỆN BẪY RÂU]**\n"
                                f"Cặp: **{pair}** ({stk_dir})\n"
                                f"Phát hiện TrapDetector cảnh báo `{opp_dir}` đối kháng.\n"
                                f"🚪 **Đã chủ động hủy lệnh Limit Maker trước khi bị khớp, triệt tiêu nguy cơ đu đỉnh/đáy!**"
                            )
                    if signals:
                        try:
                            from core.gate_telemetry import record_radar_candidate
                            directional_signals = [
                                s for s in signals
                                if getattr(getattr(s, 'signal', None), 'value', '').upper() in ('BUY', 'SELL')
                            ]
                            if directional_signals:
                                try:
                                    # [SỬA LỖI GỐC RỄ] Đây là ĐIỂM HIỂN THỊ RADAR, không phải điểm ra
                                    # quyết định. Trước đây gọi mặc định apply_entry_vetoes=True nên các
                                    # veto (xóa by_strategy, ép trap_detector = -0.85, Chop Shield...)
                                    # bóp méo điểm, khiến radar báo ngược hướng so với tín hiệu thật và
                                    # lệch với điểm đã dùng ở Pha 1/Pha 2.
                                    aggregate_score = float(
                                        self.signal_aggregator.calculate_weighted_score(
                                            signals, apply_entry_vetoes=False
                                        )
                                    )
                                except Exception:
                                    aggregate_score = 0.0
                                aggregate_side = 'BUY' if aggregate_score > 1e-12 else 'SELL' if aggregate_score < -1e-12 else None
                                aligned_signals = [
                                    s for s in directional_signals
                                    if aggregate_side and s.signal.value.upper() == aggregate_side
                                ]
                                if aggregate_side:
                                    s_side = aggregate_side
                                    confidence_signals = aligned_signals
                                else:
                                    s_side = max(
                                        directional_signals,
                                        key=lambda s: float(getattr(s, 'confidence', 0.0) or 0.0),
                                    ).signal.value.upper()
                                    confidence_signals = [
                                        s for s in directional_signals
                                        if s.signal.value.upper() == s_side
                                    ]
                                best_s = max(
                                    confidence_signals,
                                    key=lambda s: float(getattr(s, 'confidence', 0.0) or 0.0),
                                    default=None,
                                )
                                min_strats = max(1, int(self.config.get('ai', {}).get('min_agreeing_strategies', 2)))
                                agreeing_by_strategy = {}
                                for candidate_signal in confidence_signals:
                                    if candidate_signal.signal.value.upper() != s_side:
                                        continue
                                    raw_name = str(getattr(candidate_signal, 'strategy', 'unknown'))
                                    strategy_key = ''.join(ch for ch in raw_name.lower() if ch.isalnum())
                                    agreeing_by_strategy.setdefault(strategy_key, raw_name)
                                num_agree = len(agreeing_by_strategy)
                                strats_summary = ', '.join(list(agreeing_by_strategy.values())[:3])
                                if not strats_summary:
                                    strats_summary = 'không có phiếu cá nhân cùng chiều với weighted score'
                                radar_confidence = float(getattr(best_s, 'confidence', 0.0) or 0.0) if best_s else 0.0
                                pre_llm_veto = next(
                                    (
                                        s.metadata.get('pre_llm_entry_veto')
                                        for s in signals
                                        if isinstance(getattr(s, 'metadata', None), dict)
                                        and isinstance(s.metadata.get('pre_llm_entry_veto'), dict)
                                    ),
                                    None,
                                )
                                unavailable_jev = next(
                                    (
                                        s for s in signals
                                        if str(getattr(s, 'strategy', '')).lower() in ('jev_agent', 'jevagent')
                                        and isinstance(getattr(s, 'metadata', None), dict)
                                        and s.metadata.get('availability_status') not in (None, '', 'ok')
                                    ),
                                    None,
                                )
                                if pre_llm_veto:
                                    gate_name = 'PRE_LLM_STRUCTURAL_VETO'
                                    gate_reason = str(pre_llm_veto.get('reason') or 'JEV MTF bị bỏ qua; không cấp lệnh mới.')[:250]
                                elif unavailable_jev:
                                    gate_name = 'JEV_UNAVAILABLE'
                                    status = unavailable_jev.metadata.get('availability_status', 'unavailable')
                                    gate_reason = f"JEV/Ollama {status}; ứng viên bị fail-closed, không phát lệnh mới."
                                else:
                                    gate_name = 'SIGNAL_AGGREGATOR_VETO'
                                    gate_reason = (
                                        f"SignalAggregator không cấp tín hiệu cuối sau các cổng đồng thuận/veto; "
                                        f"{num_agree} chiến lược cùng chiều, yêu cầu tối thiểu {min_strats}. "
                                        "Xem log Pha 2 để biết cổng cụ thể."
                                    )
                                record_radar_candidate(
                                    symbol=pair,
                                    side=s_side,
                                    confidence=radar_confidence,
                                    score=aggregate_score,
                                    strategies_agreed=f"{num_agree} chiến lược đồng chiều / cần ≥{min_strats} ({strats_summary})",
                                    dynamic_leverage=None,
                                    bottleneck_gate=gate_name,
                                    bottleneck_reason=gate_reason,
                                    readiness_pct=30.0,
                                )
                        except Exception as radar_error:
                            logger.debug("Không ghi được ứng viên bị chặn %s lên Radar: %s", pair, radar_error)
                    
            except Exception as e:
                logger.error(f"Lỗi trong chu kỳ Pha 2 cho {pair}: {e}", exc_info=True)
                
        # Lưu trạng thái
        self._save_state()
        
        # Log performance
        self._log_performance()

    def _log_performance(self):
        """Log hiệu suất hiện tại."""
        initial = self.config['trading']['initial_capital']
        status = self.get_status()
        equity = status.get('equity')
        pnl = status.get('pnl')
        if equity is None or pnl is None:
            logger.warning("Bỏ qua ghi hiệu suất: chưa lấy được equity chính xác từ tài khoản.")
            return
        equity = float(equity)
        pnl = float(pnl)
        available = status.get('available_balance')
        if available is None:
            available = self.balance
        quote = self.config['trading'].get('base_currency', 'USDT')
        # [SỔ VỐN] PnL phiên = equity - mốc vốn thật (tổng nạp/rút ròng dựng từ lịch sử TRANSFER
        # của sàn khi sổ đã đầy đủ, hoặc vốn gốc khai báo + phần nạp đã thấy khi chưa đầy đủ).
        invested_basis = self._invested_basis()
        net_deposits = float(getattr(self, 'net_deposits', 0.0) or 0.0)
        session_net = (equity - invested_basis)
        session_pct = (session_net / invested_basis) * 100 if invested_basis > 0 else 0
        logger.info(f"\n📊 HIỆU SUẤT TÀI KHOẢN:")
        logger.info(f"  💰 Khả dụng: {float(available):.4f} {quote}")
        logger.info(f"  🧾 Equity tài khoản: {equity:.4f} {quote}")
        logger.info(
            f"  🏦 Mốc vốn PnL: {invested_basis:.4f} {quote} "
            f"(nạp/rút ròng từ sàn: {net_deposits:+.4f} {quote}, "
            f"sổ {'ĐẦY ĐỦ' if getattr(self, '_ledger_complete', False) else 'CHƯA đối chiếu'})"
        )
        logger.info(f"  📈 PnL Phiên Hiện Tại: {session_net:+.4f} {quote} ({session_pct:+.2f}%)")
        logger.info(f"  🏛️ PnL Lịch Sử Tích Lũy: {pnl:+.4f} {quote}")
        logger.info(f"  📊 Tổng giao dịch: {self.trade_count}")
        logger.info(f"  📂 Open positions: {len(self.open_positions)}")
        
        # Lưu performance vào database
        try:
            perf = self.db.get_performance_summary(self.mode, quote)
            self.db.save_performance({
                'date': datetime.now().strftime('%Y-%m-%d'),
                # [M10] Tách số liệu theo chế độ để LIVE không ghi đè DEMO
                'mode': self.mode,
                'total_trades': perf.get('total_trades', self.trade_count),
                'winning_trades': perf.get('winning_trades', 0),
                'losing_trades': perf.get('losing_trades', 0),
                # [M7] Dùng đúng định nghĩa PnL của bảng trades (đã trừ phí, chỉ tính lệnh đã đóng)
                # thay vì trộn thêm PnL thả nổi của vị thế đang mở vào cùng một dòng.
                'total_pnl': perf.get('total_pnl', 0.0),
                'win_rate': perf.get('win_rate', 0.0),
                'max_drawdown': (self.peak_balance - equity) / self.peak_balance if self.peak_balance > 0 else 0,
                'balance': equity
            })
        except Exception as e:
            logger.debug(f"Lỗi lưu performance: {e}")

    def prepare_to_start(self) -> Optional[str]:
        """Connect and reconcile before allowing the trading loop to start."""
        if not self.exchange_connected and not self.connect():
            return 'Không kết nối được Binance; bot chưa chạy.'
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            if not self.sync_live_positions_with_exchange():
                return 'Không đối soát được vị thế Binance; bot chưa chạy.'
            if self.unreconciled_exchange_positions:
                if self.pending_protection_cleanup:
                    return 'Còn lệnh SL/TP của vị thế đã đóng chưa xác minh hủy; bot chưa chạy và đã khóa lệnh mới. Hãy kiểm tra Binance.'
                return 'Có vị thế Binance chưa đối soát hoặc thiếu xác nhận stop-loss; bot chưa chạy. Hãy kiểm tra Binance hoặc đóng vị thế trên dashboard.'
            if not self.live_balance_synced:
                logger.warning(
                    "Không lấy được số dư LIVE mới nhất; bot sẽ chỉ quản lý vị thế hiện có và khóa lệnh mới."
                )
            # [SỔ VỐN] Dựng lại/đồng bộ sổ nạp/rút TRƯỚC khi dashboard đọc trạng thái, để mốc vốn
            # PnL không có giai đoạn tạm sai (100 + nạp) ngay sau khi khởi động.
            try:
                self._sync_net_deposits()
                if self.capital_ledger:
                    self._recompute_net_deposits()
                logger.info(
                    "🏦 [SỔ VỐN] Mốc vốn PnL = %.4f (nạp/rút ròng từ sàn; sổ %s)",
                    self._invested_basis(),
                    'ĐẦY ĐỦ' if self._ledger_complete else 'CHƯA đối chiếu đầy đủ',
                )
            except Exception as e:
                logger.warning(f"Không đồng bộ được sổ vốn nạp/rút khi khởi động: {e}")
        return None


    def _quote_value_of_transfer(self, amount: float, asset: str, quote: str):
        """Quy đổi một khoản chuyển tiền về đồng định giá. Trả (value, fx_source).

        [SỬA LỖI GỐC RỄ - SỔ VỐN CHỈ ĐẾM USDT]
        Bản cũ bỏ qua mọi bản ghi có `asset != quote`. Nếu người dùng nạp bằng USDC (hoặc bất kỳ
        tài sản nào khác) thì số tiền đó biến mất khỏi sổ vốn -> mốc vốn thấp hơn thực tế ->
        PnL bị thổi phồng thành lãi ảo. Nay quy đổi:
          1. Trùng đồng định giá -> giữ nguyên;
          2. Stablecoin -> quy 1:1 (lệch giá thực tế < 0,5%);
          3. Tài sản khác -> lấy giá hiện tại của cặp ASSET/QUOTE;
          4. Không quy đổi được -> trả 0 và đánh dấu 'unconverted' để cảnh báo, KHÔNG âm thầm bỏ.
        """
        asset = str(asset or '').upper()
        quote = str(quote or 'USDT').upper()
        if not asset or asset == quote:
            return amount, 'native'
        if asset in STABLECOIN_PAR_ASSETS:
            return amount, 'stablecoin_par'
        try:
            ticker = self.exchange.get_ticker(f'{asset}/{quote}')
            last = float((ticker or {}).get('last') or 0.0)
            if math.isfinite(last) and last > 0:
                return amount * last, 'ticker_at_sync'
        except Exception:
            pass
        return 0.0, 'unconverted'

    def _recompute_net_deposits(self) -> float:
        """Tính lại `net_deposits` = TỔNG sổ vốn (không cộng dồn kiểu +=).

        [SỬA LỖI GỐC RỄ] Bản cũ cộng dồn `self.net_deposits += amount`. Chỉ cần một lần đọc trạng
        thái cũ bị lệch, hoặc một bản ghi bị quét hai lần ở hai máy, là con số sai VĨNH VIỄN và
        không có cách nào tự phát hiện. Tính lại từ sổ thì luôn tự chữa lành.
        """
        total = 0.0
        seen_any = False
        for entry in (self.capital_ledger or []):
            if not isinstance(entry, dict):
                continue
            raw = entry.get('amount_quote', entry.get('amount'))
            try:
                value = float(raw or 0.0)
            except (TypeError, ValueError, OverflowError):
                continue
            if math.isfinite(value):
                total += value
                seen_any = True
        if not seen_any:
            # Sổ rỗng nhưng lại đang giữ một con số nạp/rút -> KHÔNG xoá trắng (sẽ thổi phồng PnL).
            # Giữ nguyên số hiện có và để lần đồng bộ sau dựng lại sổ từ sàn.
            return float(getattr(self, 'net_deposits', 0.0) or 0.0)
        self.net_deposits = round(total, 8)
        return self.net_deposits

    def _invested_basis(self) -> float:
        """Mốc vốn dùng để tính PnL = số tiền THẬT đã bơm vào ví Futures.

        - Sổ vốn đã đối chiếu ĐẦY ĐỦ với sàn (`_ledger_complete`): mốc vốn = tổng nạp/rút ròng
          theo lịch sử TRANSFER. Người dùng KHÔNG cần nhớ đã nạp bao nhiêu lần; cài lại máy khác
          hay tạo API key mới trên cùng tài khoản vẫn tự dựng lại đúng.
        - Chưa đối chiếu được: giữ mô hình cũ (vốn gốc khai báo + phần nạp/rút đã thấy) để bot
          không bao giờ tính PnL trên một mốc vốn bằng 0.
        """
        try:
            initial = float(self.config.get('trading', {}).get('initial_capital') or 0.0)
        except (TypeError, ValueError, OverflowError):
            initial = 0.0
        net_deposits = float(getattr(self, 'net_deposits', 0.0) or 0.0)
        if getattr(self, '_ledger_complete', False):
            return max(0.0, net_deposits)
        return max(0.0, initial + net_deposits)

    def _sanitize_peak_baseline(self, state, stored_peak, equity_hint=None):
        """Đánh giá lại `peak_balance` MỘT LẦN khi nâng mốc kế toán vốn.

        [SỬA LỖI GỐC RỄ - ĐỈNH VỐN GIẢ LÀM SAI CẦU DAO RỦI RO]
        `peak_balance` cũ được sinh ra trong thời kỳ `_auto_adjust_capital()` tự bóp méo
        `initial_capital` theo chênh lệch số dư, nên tồn tại những đỉnh CHƯA TỪNG CÓ THẬT.
        PC2 đang giữ `peak_balance = 113.88161551` trong khi equity thật chỉ 105.20006319
        và tổng nạp/rút thật là 114.597617 — đỉnh đó không tương ứng bất kỳ thời điểm nào.
        Hệ quả đo được:
          1. Web hiển thị drawdown ảo 7.62% dù tài khoản không hề sụt từ đỉnh nào;
          2. Cầu dao Max Drawdown 10% kích hoạt ở equity <= 102.49 — chỉ cần giảm thêm
             2.71 USDT là bot TỰ DỪNG giao dịch, thay vì ngưỡng đúng 94.68 (giảm 10.52 USDT);
          3. `performance.max_drawdown` ghi số sai vào lịch sử hiệu suất.

        Nay: bản ghi CHƯA mang mốc `peak_baseline_version >= 2` được coi là đỉnh không đáng
        tin -> đặt lại bằng equity hiện tại. Chỉ chạy MỘT LẦN: sau khi lưu mốc 2, đỉnh chỉ
        tăng theo equity thực và không bao giờ bị hạ xuống để che giấu thua lỗ.
        """
        try:
            version = int((state or {}).get('peak_baseline_version') or 0)
        except (TypeError, ValueError, OverflowError, AttributeError):
            version = 0
        if version >= PEAK_BASELINE_VERSION:
            return stored_peak

        try:
            hint = float(equity_hint if equity_hint is not None else self.balance)
        except (TypeError, ValueError, OverflowError):
            hint = 0.0
        if not math.isfinite(hint) or hint <= 0:
            try:
                hint = float(self.balance or 0.0)
            except (TypeError, ValueError, OverflowError):
                hint = 0.0

        try:
            peak = float(stored_peak or 0.0)
        except (TypeError, ValueError, OverflowError):
            peak = 0.0

        if hint > 0 and peak > hint + 0.01:
            logger.warning(
                "🩹 [ĐỈNH VỐN] Phát hiện ĐỈNH GIẢ %.8f (cao hơn equity hiện tại %.8f %s) do cơ chế "
                "tự bóp méo vốn gốc trước đây. Đặt lại Đỉnh vốn = %.8f và ghi mốc "
                "peak_baseline_version=%d để không tái diễn. Cầu dao Max Drawdown từ nay tính trên "
                "đỉnh thật.",
                peak, hint, self.config.get('trading', {}).get('base_currency', 'USDT'),
                hint, PEAK_BASELINE_VERSION,
            )
            return hint
        if hint > 0 and peak < hint:
            return hint
        return peak

    def _sync_net_deposits(self, force: bool = False) -> bool:
        """Đồng bộ sổ NẠP/RÚT THẬT của ví Futures từ Binance.

        [SỬA LỖI GỐC RỄ - CHỈ NHÌN THẤY 7 NGÀY]
        Bản cũ luôn hỏi sàn "7 ngày gần nhất", nên mọi khoản nạp cũ hơn vĩnh viễn không vào sổ.
        Nay:
          - Lần đầu (sổ chưa đầy đủ) -> DỰNG LẠI TOÀN BỘ lịch sử, đi ngược từ hiện tại tới đầu ví;
          - Các lần sau -> chỉ quét tăng dần vài ngày gần nhất cho nhẹ API;
          - Luôn khử trùng theo `tranId`, và tính lại tổng từ sổ thay vì cộng dồn.
        """
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures':
            return False
        now = time.time()
        last_checked = float(getattr(self, '_net_deposits_checked_at', 0.0) or 0.0)
        if not force and (now - last_checked) < 3600.0:
            return False
        self._net_deposits_checked_at = now
        quote = str(self.config.get('trading', {}).get('base_currency', 'USDT')).upper()

        last_success = float(getattr(self, '_net_deposits_last_success_at', 0.0) or 0.0)
        # Sau downtime > 6 ngày, truy vấn tăng dần 3 ngày có thể vượt giới hạn
        # 7 ngày của Binance và bỏ sót kỳ nghỉ. Buộc dựng lại thay vì để sổ cũ vĩnh viễn.
        stale_incremental = (now - last_success) > 6 * 86400.0
        rebuild = bool(force) or not getattr(self, '_ledger_complete', False) or stale_incremental
        since_ms = (
            None if rebuild
            else int((now - NET_DEPOSITS_INCREMENTAL_DAYS * 86400) * 1000)
        )
        rows = self.exchange.get_futures_transfer_income(since_ms)
        if rows is None:
            logger.debug("Chưa đọc được lịch sử nạp/rút từ sàn - giữ nguyên sổ vốn hiện có.")
            return False

        # Bảo hiểm: dựng lại mà sàn trả RỖNG trong khi sổ đang có dữ liệu => API bất thường,
        # không được xoá sổ thật của người dùng.
        if rebuild and not rows and self.capital_ledger:
            logger.warning(
                "⚠️ [SỔ VỐN] Sàn trả về 0 giao dịch nạp/rút trong khi sổ đang có %d bản ghi - "
                "giữ nguyên sổ cũ và sẽ thử lại sau.",
                len(self.capital_ledger),
            )
            return False

        seen = {str(t) for t in (getattr(self, '_deposit_tran_ids', []) or [])}
        added = 0
        added_in = 0.0
        added_out = 0.0
        unconverted = []
        oldest_ms = int(getattr(self, '_ledger_coverage_start_ms', 0) or 0)

        for row in rows:
            try:
                if str(row.get('incomeType') or '').upper() != 'TRANSFER':
                    continue
                asset = str(row.get('asset') or '').upper()
                amount = float(row.get('income') or 0.0)
                if not math.isfinite(amount) or abs(amount) <= 0:
                    continue
                tran_id = str(row.get('tranId') or row.get('id') or row.get('time') or '')
                if tran_id and tran_id in seen:
                    continue
                value, fx = self._quote_value_of_transfer(amount, asset, quote)
                if fx == 'unconverted':
                    unconverted.append(f'{amount:+.4f} {asset}')
                try:
                    occurred_ms = int(row.get('time') or 0)
                except (TypeError, ValueError, OverflowError):
                    occurred_ms = 0
                try:
                    occurred = datetime.fromtimestamp(occurred_ms / 1000.0).isoformat()
                except Exception:
                    occurred = datetime.now().isoformat()
                self.capital_ledger.append({
                    'time': occurred,
                    'amount': amount,
                    'asset': asset or quote,
                    'amount_quote': value,
                    'fx': fx,
                    'type': 'deposit' if amount > 0 else 'withdrawal',
                    'source': 'binance_income_transfer',
                    'tran_id': tran_id,
                })
                if occurred_ms:
                    oldest_ms = min(oldest_ms, occurred_ms) if oldest_ms else occurred_ms
                if tran_id:
                    seen.add(tran_id)
                    self._deposit_tran_ids.append(tran_id)
                added += 1
                if amount > 0:
                    added_in += value
                else:
                    added_out += value
                logger.warning(
                    "💵 [SỔ VỐN] %s %+.4f %s (≈ %+.4f %s) từ Binance (tranId=%s)",
                    'NẠP TIỀN' if amount > 0 else 'RÚT TIỀN',
                    amount, asset or quote, value, quote, tran_id or '-',
                )
            except Exception:
                continue

        before = float(getattr(self, 'net_deposits', 0.0) or 0.0)
        total = self._recompute_net_deposits()
        if unconverted:
            logger.warning(
                "⚠️ [SỔ VỐN] Có %d khoản chuyển bằng tài sản chưa quy đổi được sang %s (%s) - "
                "sổ vốn đang thiếu phần này. Hãy kiểm tra thủ công.",
                len(unconverted), quote, ', '.join(unconverted[:5]),
            )

        changed = added > 0 or abs(total - before) > 1e-9
        if rebuild:
            # Chỉ đánh dấu "đầy đủ" khi đã quét thành công toàn bộ lịch sử trong lần này.
            self._ledger_complete = True
            self._ledger_coverage_start_ms = oldest_ms
            logger.warning(
                "🔁 [SỔ VỐN] Đã dựng lại TOÀN BỘ lịch sử nạp/rút từ Binance: %d giao dịch "
                "(kỳ này +%d: nạp %+.4f / rút %+.4f %s) -> net_deposits = %+.4f %s. "
                "Mốc vốn PnL từ nay = số này (không cần nhớ đã nạp bao nhiêu lần).",
                len(self.capital_ledger), added, added_in, added_out, quote, total, quote,
            )
            changed = True

        if changed:
            if len(self.capital_ledger) > 1000 or len(self._deposit_tran_ids) > 1000:
                # Sổ bị cắt -> tổng đang giữ không còn đầy đủ, buộc lần sau dựng lại từ sàn.
                self._ledger_complete = False
            self.capital_ledger = self.capital_ledger[-1000:]
            self._deposit_tran_ids = self._deposit_tran_ids[-1000:]
        self._net_deposits_last_success_at = now
        self._save_state()
        return changed

    def _reconcile_capital_baseline(self):
        """Đối soát vốn gốc với số dư sàn - CHỈ ĐỌC, tuyệt đối không sửa vốn gốc.

        [SỬA LỖI GỐC RỄ - TỰ XOÁ DẤU VẾT THUA LỖ]
        Hàm cũ `_auto_adjust_capital()` coi MỌI chênh lệch > 2 USDT giữa equity và
        (vốn gốc + PnL trong DB) là "nạp/rút tiền", rồi:
          1. Sửa thẳng `initial_capital`. Mỗi lần lỗ vài USDT là vốn gốc bị hạ xuống, PnL
             phiên luôn xấp xỉ 0 và cầu dao Max Drawdown 10% KHÔNG BAO GIỜ kích hoạt;
          2. Ghi đè `config/settings.yaml` bằng yaml.dump trên file mở 'w' (truncate).
             cloud_sync.py đọc lại file mỗi 5 giây nên có thể đọc trúng lúc file cụt ->
             YAML lỗi -> token rỗng -> bot live bị "khoá bản quyền" và DỪNG giữa chừng;
          3. Kéo `peak_balance` xuống bằng equity khi "rút tiền" -> giấu luôn mức sụt giảm
             thực tế khỏi mọi thống kê rủi ro.
        Nay dòng tiền chỉ lấy từ lịch sử TRANSFER của Binance (`_sync_net_deposits`), vốn gốc
        là hằng số do người dùng đặt, phần lệch còn lại chỉ được CẢNH BÁO để người dùng soát.
        """
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures':
            return
        try:
            self._sync_net_deposits()
            bal = self.exchange.get_futures_balance()
            if not isinstance(bal, dict) or bal.get('margin_balance') is None:
                return
            equity = float(bal['margin_balance'])
            if not math.isfinite(equity) or equity <= 0:
                return
            quote = self.config.get('trading', {}).get('base_currency', 'USDT')
            initial = float(self.config['trading']['initial_capital'])
            net_deposits = float(getattr(self, 'net_deposits', 0.0) or 0.0)
            invested = self._invested_basis()
            try:
                realized = float(self.db.get_total_net_pnl('live', quote) or 0.0)
            except Exception:
                realized = 0.0
            unrealized = float(bal.get('unrealized_pnl') or 0.0)
            expected_equity = invested + realized + unrealized
            residual = equity - expected_equity
            tolerance = max(5.0, 0.05 * equity)
            if abs(residual) <= tolerance:
                return
            now_ts = time.time()
            if now_ts - float(getattr(self, '_capital_baseline_warned_at', 0.0) or 0.0) < 6 * 3600.0:
                return
            self._capital_baseline_warned_at = now_ts
            if getattr(self, '_ledger_complete', False):
                # Sổ vốn đã đầy đủ từ sàn -> phần lệch là PnL/phí nằm NGOÀI phạm vi bảng `trades`
                # (lịch sử trước khi DB bắt đầu ghi, funding fee, phí, hoặc lệnh tay). Đây là thông
                # tin giải thích, không phải lỗi cấu hình -> log INFO, không doạ người dùng.
                logger.info(
                    "🧾 [ĐỐI SOÁT VỐN] Equity %.4f %s lệch %+.4f so với (nạp/rút ròng %.4f + "
                    "PnL đã ghi trong DB %+.4f + thả nổi %+.4f). Sổ nạp/rút đã ĐẦY ĐỦ từ sàn nên "
                    "phần lệch này là PnL/phí nằm ngoài phạm vi bảng trades (vd: lịch sử trước khi "
                    "DB bắt đầu ghi, funding fee, lệnh đặt tay). Không cần sửa gì.",
                    equity, quote, residual, invested, realized, unrealized,
                )
                return
            logger.warning(
                "🧾 [ĐỐI SOÁT VỐN GỐC] Equity %.4f %s lệch %+.4f so với dự kiến "
                "(vốn gốc %.4f + nạp/rút %+.4f + PnL đã thực hiện %+.4f + thả nổi %+.4f). "
                "Sổ nạp/rút CHƯA đối chiếu đầy đủ với sàn. Bot KHÔNG tự sửa vốn gốc. "
                "Hãy kiểm tra lịch sử chuyển tiền Futures; nếu chênh lệch do lịch sử giao dịch "
                "chưa vào DB, hãy đồng bộ lại trước khi tin vào chỉ số PnL phiên.",
                equity, quote, residual, initial, net_deposits, realized, unrealized,
            )
        except Exception as e:
            logger.debug(f"Loi doi soat von goc: {e}")

    def start(self, interval_seconds: int = 300, preflight_done: bool = False):
        """
        Khởi chạy bot liên tục.
        
        Args:
            interval_seconds: Thời gian giữa các chu kỳ (mặc định 5 phút)
        """
        import threading
        start_error = None if preflight_done else self.prepare_to_start()
        if start_error:
            logger.error("Không khởi chạy bot: %s", start_error)
            raise RuntimeError(start_error)
        # Tu dong dieu chinh von neu co nap/rut
        if not preflight_done and self.mode == 'live':
            self._reconcile_capital_baseline()

        with self._position_lock:
            if self.is_running:
                raise RuntimeError('Bot đã chạy.')
            self.is_running = True
            self._runner_thread = threading.current_thread()
            self._background_threads = []
            # Restored positions get one analysis cycle before discretionary AI
            # reversal exits can act; their stop-loss/take-profit checks still run.
            self._skip_dynamic_exit_cycle = True
        try:
            self.db.cleanup_old_data(30)
        except Exception:
            pass
        self.start_time = datetime.now()
        try:
            import yaml, os
            # Reload settings.yaml
            settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
            with open(settings_path, 'r', encoding='utf-8') as f:
                new_settings = yaml.safe_load(f)
            active_initial_capital = self.config['trading']['initial_capital']
            self.config.update(new_settings)
            # initial_capital is mode-specific in memory and persisted per mode
            # in bot_state; do not replace it with the shared YAML default.
            self.config['trading']['initial_capital'] = active_initial_capital
                
            # Update aggregator threshold dynamically
            if hasattr(self, 'signal_aggregator'):
                self.signal_aggregator.confidence_threshold = self.config.get('ai', {}).get('confidence_threshold', 0.25)
                logger.info(f"🔄 Đã cập nhật AI Confidence Threshold: {self.signal_aggregator.confidence_threshold}")
                
            strat_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'strategies.yaml')
            with open(strat_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f)
            if 'ai_bias' in strat:
                # Không xóa HIGH_RISK đã lưu khi restart. Nếu chưa từng có phán quyết,
                # NONE giữ cổng đóng cho tới khi macro AI trả kết quả hợp lệ đầu tiên.
                previous_bias = str((strat.get('ai_bias') or {}).get('direction') or 'NONE').upper()
                strat['ai_bias']['direction'] = previous_bias
                logger.info("🛡️ Giữ nguyên AI Bias khi khởi động lại: %s", previous_bias)
            # Không ghi lại strategies.yaml chỉ để reset trạng thái runtime.
        except Exception as e:
            logger.error(f"Loi load config/AI Bias: {e}")
        
        logger.info(f"\n{'🚀'*20}")
        logger.info(f"🤖 TRADE BOT BẮT ĐẦU CHẠY!")
        logger.info(f"📊 Chế độ: {'DEMO' if self.mode == 'demo' else 'LIVE'}")
        quote = self.config.get('trading', {}).get('base_currency', 'USDT')
        logger.info(f"💰 Vốn: {self.balance} {quote}")
        logger.info(f"⏰ Interval: {interval_seconds}s")
        logger.info(f"📋 Pairs: {', '.join(self.config['trading']['pairs'])}")
        logger.info(f"{'🚀'*20}\n")

        if self.mode == 'live':
            resumed_count = len(self.open_positions)
            start_msg = (
                f"▶️ Bot LIVE đã chạy lại và đối soát xong {resumed_count} vị thế đang mở. "
                "Khởi động lại không tự đóng các vị thế này."
            )
            if any(p.get('protection_review_required') or not p.get('sl_order_id') for p in self.open_positions):
                start_msg += " Có vị thế chưa xác nhận SL sàn; hãy kiểm tra Binance trực tiếp."
            self._notify_telegram(start_msg)
         
        # --- BẬT LUỒNG AI CHẠY NGẦM LIÊN TỤC 24/7 ---
        def ai_background_loop():
            import sys, time
            from pathlib import Path
            root_dir = Path(__file__).parent.parent
            if str(root_dir) not in sys.path: sys.path.insert(0, str(root_dir))
            from ai.ollama_agent import OllamaManagerAgent
            
            try:
                llm_agent = OllamaManagerAgent(str(root_dir))
                logger.info("🧠 AI Alpha Generator (Background) đã kích hoạt! Sẽ tự động phân tích và theo dõi tài khoản mỗi 5 phút.")
                while self.is_running:
                    try:
                        llm_agent.analyze_and_tune(bot=self)
                    except Exception as e:
                        logger.error(f"[AI Background] Lỗi khi chạy: {e}")
                    
                    # Cứ 5 phút (300s) AI sẽ theo dõi trạng thái tài khoản và thị trường 1 lần
                    for _ in range(300):
                        if not self.is_running: break
                        time.sleep(1)
            except Exception as e:
                logger.error(f"Lỗi khởi tạo AI Loop: {e}")

        def optimizer_loop():
            import time, os
            if not self.config.get('optimizer', {}).get('enabled', False):
                logger.info("Auto-optimizer đang tắt; chỉ chạy khi được bật rõ ràng trong cấu hình.")
                return
            from core.optimizer import StrategyOptimizer
            config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
            optimizer = StrategyOptimizer(config_path)
            while self.is_running:
                try:
                    now_ts = time.time()
                    if now_ts - self.last_optimized >= 86400: # 24 hours
                        logger.info("⚙️ Đang chạy Bộ Tối ưu hóa Thuật Toán (Auto-Tuning) cho ngày mới...")
                        optimizer.run_optimization()
                        self.last_optimized = now_ts
                        logger.info("✅ Đã cập nhật thông số chiến lược mới nhất!")
                except Exception as e:
                    logger.error(f"[Optimizer] Lỗi: {e}")
                
                for _ in range(3600): # check every hour
                    if not self.is_running: break
                    time.sleep(1)

        import threading
        self._position_monitor_stop.clear()
        monitor_thread = threading.Thread(
            target=self._position_management_loop,
            name='position-management-monitor',
            daemon=True,
        )
        self._position_monitor_thread = monitor_thread
        monitor_thread.start()
        logger.info(
            "🛡️ Luồng quản lý vị thế độc lập đang chạy mỗi %ss; không phụ thuộc chu kỳ quét/AI.",
            self.config.get('risk', {}).get('position_monitor_interval_seconds', 10),
        )
        ai_thread = threading.Thread(target=ai_background_loop, daemon=True)
        ai_thread.start()
        opt_thread = threading.Thread(target=optimizer_loop, daemon=True)
        opt_thread.start()
        self._background_threads = [monitor_thread, ai_thread, opt_thread]
        # ---------------------------------------------
        
        cycle_count = 0
        self.cycle_count = 0
        last_history_sync = 0.0

        # Nạp nóng (Pre-warm) model AI Ollama vào GPU VRAM ngay khi mở bot để triệt tiêu độ trễ
        def _prewarm_ollama():
            try:
                import requests
                ollama_url = getattr(self, 'jev_agent', None) and getattr(self.jev_agent, 'endpoint', 'http://localhost:11434/api/generate') or 'http://localhost:11434/api/generate'
                model_name = self.config.get('ai', {}).get('ollama_model', 'qwen2.5:7b')
                from ai.ollama_runtime import OLLAMA_GPU_LOCK
                with OLLAMA_GPU_LOCK:
                    requests.post(
                        ollama_url,
                        json={"model": model_name, "prompt": "hi", "stream": False, "keep_alive": "30m"},
                        timeout=(5, 30),
                    )
                logger.info("⚡ [PRE-WARM] Đã nạp nóng model AI %s vào GPU VRAM sẵn sàng!", model_name)
            except Exception:
                pass
        threading.Thread(target=_prewarm_ollama, name='ollama-prewarm', daemon=True).start()
        
        while self.is_running:
            try:
                if not self.exchange.check_connection():
                    self.exchange_connected = False
                    if not self.connect():
                        logger.error("Binance vẫn mất kết nối; thử lại sau 60 giây, không phân tích/lệnh mới.")
                        time.sleep(60)
                        continue
                else:
                    self.exchange_connected = True

                if self.mode == 'live' and time.monotonic() - last_history_sync >= 900:
                    history_thread = threading.Thread(
                        target=self.sync_live_trades_from_exchange,
                        name='live-trade-history-sync', daemon=True,
                    )
                    self._background_threads = [t for t in self._background_threads if t is not None and t.is_alive()]
                    self._background_threads.append(history_thread)
                    history_thread.start()
                    last_history_sync = time.monotonic()
                cycle_count += 1
                self.cycle_count = cycle_count
                logger.info(f"\n🔄 === Chu kỳ #{cycle_count} ===")
                if cycle_count == 1:
                    logger.info("🛡️ [LUẬT NGẦM WARM-UP] Kích hoạt Chu kỳ #1: Đang nạp nóng bộ nhớ AI, đồng bộ nến 50 cặp coin và đối soát vị thế...")
                
                self.run_cycle()
                
                # Chờ đến chu kỳ tiếp theo
                logger.info(f"\n⏳ Chờ {interval_seconds}s đến chu kỳ tiếp theo...")
                
                # Sleep có thể bị interrupt
                for i in range(interval_seconds):
                    if not self.is_running:
                        break
                    time.sleep(1)
                    
            except KeyboardInterrupt:
                logger.info("\n⛔ Bot dừng bởi người dùng (Ctrl+C)")
                self.stop()
                break
            except Exception as e:
                logger.error(f"Lỗi trong chu kỳ #{cycle_count}: {e}")
                logger.info("⏳ Chờ 60s trước khi thử lại...")
                time.sleep(60)

        self._runner_thread = None

    def stop(self):
        """Dừng bot an toàn."""
        with self._position_lock:
            self.is_running = False
            self._position_monitor_stop.set()
            # Hủy các lệnh rình mồi Limit Maker còn chờ trên Binance để tránh khớp không người giám sát
            if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                for sym, stk in list(getattr(self, 'pending_stalking_orders', {}).items()):
                    oid = stk.get('order_id')
                    if oid:
                        if self._cancel_stalking_order(sym, stk, str(oid), time.time()):
                            self.pending_stalking_orders.pop(sym, None)
                            logger.info(f"Đã xác nhận hủy lệnh rình mồi {sym} khi dừng bot.")
                        else:
                            logger.error("Chưa xác nhận hủy %s; GIỮ persistent stalking state để không tạo lệnh mồ côi.", sym)
            self._save_state()
            positions_at_stop = [dict(position) for position in self.open_positions]
        
        logger.info(f"\n{'⛔'*20}")
        logger.info(f"🤖 TRADE BOT ĐÃ DỪNG")
        runtime = datetime.now() - self.start_time if self.start_time else "Không rõ"
        if self.start_time:
            runtime = datetime.now() - self.start_time
            logger.info(f"⏱️ Thời gian chạy: {runtime}")
        initial = self.config['trading']['initial_capital']
        status = self.get_status()
        equity = status.get('equity')
        pnl = status.get('pnl')
        available = status.get('available_balance')
        if available is None:
            available = self.balance
        quote = self.config['trading'].get('base_currency', 'USDT')
        equity_text = f"{float(equity):.4f}" if equity is not None else "chưa lấy được"
        pnl_text = f"{float(pnl):+.4f} {quote} ({(float(pnl)/initial)*100:+.2f}%)" if pnl is not None and initial > 0 else "chưa lấy được"
        logger.info(f"💰 Khả dụng cuối: {float(available):.4f} {quote}")
        logger.info(f"🧾 Equity Futures cuối: {equity_text} {quote}")
        logger.info(f"📈 PnL so với vốn gốc: {pnl_text}")
        logger.info(f"📊 Tổng giao dịch: {self.trade_count}")
        logger.info(f"{'⛔'*20}\n")
        
        # Gửi thông báo Telegram khi bot dừng
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if self.mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        stop_msg = (
            f"⛔ **TRADE BOT ĐÃ DỪNG**\n"
            f"🕒 **Thời gian tắt:** {current_time}\n"
            f"🔹 **Chế độ:** {mode_str}\n"
            f"🔹 **Thời gian chạy:** {runtime if self.start_time else 'Không rõ'}\n"
            f"🔹 **Khả dụng cuối:** {float(available):.4f} {quote}\n"
            f"🔹 **Equity Futures:** {equity_text} {quote}\n"
            f"🔹 **PnL so với vốn gốc:** {pnl_text}\n"
            f"🔹 **Vị thế còn mở:** {len(positions_at_stop)} (nút Dừng không tự đóng vị thế)\n"
            f"🔹 **Trạng thái:** Bot đã dừng; vị thế và lệnh bảo vệ trên Binance được giữ nguyên."
        )
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            missing_stop = [
                f"{p.get('direction', 'LONG')} {p.get('symbol')}"
                for p in positions_at_stop if not p.get('sl_order_id')
            ]
            if missing_stop:
                stop_msg += "\n⚠️ Chưa xác nhận SL sàn cho: " + ', '.join(missing_stop) + ". Kiểm tra Binance trực tiếp."
        self._notify_telegram(stop_msg)

    def switch_mode(self, mode: str, api_key: str = None, api_secret: str = None):
        """
        Chuyển đổi giữa chế độ demo và live.
        """
        import threading
        if mode not in ('demo', 'live'):
            raise ValueError("Chế độ chỉ có thể là 'demo' hoặc 'live'.")
        if self.is_running:
            raise RuntimeError("Hãy dừng bot trước khi đổi chế độ để tránh đổi sàn giữa một chu kỳ.")
        current_thread = threading.current_thread()
        active_threads = [
            thread for thread in [self._runner_thread, *self._background_threads]
            if thread is not None and thread is not current_thread and thread.is_alive()
        ]
        if active_threads:
            raise RuntimeError("Các luồng bot cũ vẫn đang kết thúc; hãy đợi chúng dừng hẳn rồi đổi chế độ.")
        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            if not self.sync_live_positions_with_exchange():
                raise RuntimeError("Không đối soát được vị thế Binance; không thể đổi chế độ an toàn.")
            if self.unreconciled_exchange_positions:
                raise RuntimeError("Còn vị thế hoặc lệnh bảo vệ LIVE chưa đối soát; không thể đổi chế độ.")
        if self.open_positions:
            raise RuntimeError("Không thể đổi chế độ khi còn vị thế được tool theo dõi; hãy đóng hoặc đối soát trước.")

        import os
        from pathlib import Path
        live_equity = None
        if mode == 'live':
            from dotenv import load_dotenv
            try:
                _env_f = Path(__file__).resolve().parent.parent / '.env'
                if _env_f.exists():
                    load_dotenv(_env_f)
            except Exception:
                pass
            
            current_key = self.config['exchange'].get('api_key', '') or os.getenv('BINANCE_API_KEY', '')
            current_secret = self.config['exchange'].get('api_secret', '') or os.getenv('BINANCE_API_SECRET', '')
            
            use_key = api_key if api_key else current_key
            use_secret = api_secret if api_secret else current_secret
            
            if not use_key or not use_secret:
                raise ValueError("Cần API key và secret để chuyển sang chế độ live!")
                
            self.config['exchange']['api_key'] = use_key
            self.config['exchange']['api_secret'] = use_secret
            
            logger.warning("⚠️ CẢNH BÁO: Đã chuyển sang LIVE TRADING! Sẽ sử dụng tiền thật.")
            
            self.config['exchange']['api_key'] = use_key
            self.config['exchange']['api_secret'] = use_secret
            # Luôn dùng testnet = false để lấy data thật
            self.config['exchange']['testnet'] = False
        else:
            logger.info("🔄 Đã chuyển sang DEMO (Paper Trading).")
            # Vẫn giữ testnet = False để demo trên dữ liệu thật
            self.config['exchange']['testnet'] = False
        
        mode_initial_capital = (
            self._demo_initial_capital if mode == 'demo' else self._live_initial_capital
        )
        self.config['trading']['initial_capital'] = mode_initial_capital
        if mode == 'demo':
            # Sổ nạp/rút LIVE không được rò sang PnL DEMO. DEMO luôn bắt đầu
            # từ vốn mô phỏng và ledger riêng (thường rỗng).
            self.net_deposits = 0.0
            self.capital_ledger = []
            self._deposit_tran_ids = []
            self._ledger_complete = False
            self._ledger_coverage_start_ms = 0
            self._net_deposits_last_success_at = 0.0
            self.balance = mode_initial_capital
            demo_state = self.db.get_bot_state('demo') if hasattr(self, 'db') and hasattr(self.db, 'get_bot_state') else None
            self.peak_balance = max(float(demo_state.get('peak_balance', 0)) if demo_state else 0, mode_initial_capital)

        self.mode = mode
        active_cds = {
            self._clean_symbol(symbol): expires_at
            for symbol, expires_at in self.db.get_symbol_cooldowns(mode).items()
        }
        self._manual_exit_cooldowns = dict(active_cds)
        self._symbol_cooldowns = dict(active_cds)
        self.config['bot']['mode'] = mode
        
        # Reinitialize exchange (luôn lưu config mới)
        self.exchange = ExchangeConnector(self.config)
        self.order_manager = OrderManager(self.exchange, self.db, self.mode)
        self.scanner.exchange = self.exchange
        self.data_collector.exchange = self.exchange

        self.exchange_connected = self.exchange.connect()
        if not self.exchange_connected:
            raise RuntimeError("Không kết nối được Binance sau khi đổi chế độ.")
        
        # Đồng bộ số dư nếu là live
        if mode == 'live':
            self.live_balance_synced = False
            self._detect_base_currency()
            base_currency = self.config['trading'].get('base_currency', 'USDT')
            try:
                if getattr(self, 'market_type', 'spot') == 'futures':
                    bal = self.exchange.get_futures_balance()
                    free_bal = bal.get(base_currency, {}).get('free', 0) if isinstance(bal.get(base_currency), dict) else bal.get('free', 0)
                    total_bal = bal.get(base_currency, {}).get('total', 0) if isinstance(bal.get(base_currency), dict) else bal.get('total', 0)
                else:
                    bal = self.exchange.get_balance()
                    free_bal = bal.get(base_currency, {}).get('free', 0)
                    total_bal = bal.get(base_currency, {}).get('total', 0)

                free_bal = float(free_bal)
                total_bal = float(total_bal)
                if not math.isfinite(free_bal) or free_bal < 0 or not math.isfinite(total_bal) or total_bal <= 0:
                    raise ValueError("Binance trả số dư không hợp lệ; giữ nguyên vốn đã lưu.")
                
                # self.balance luôn là số dư khả dụng (Free Margin)
                self.balance = free_bal
                self.peak_balance = free_bal
                live_equity = total_bal
                self.live_balance_synced = True
                quote = self.config['trading'].get('base_currency', 'USDT')
                logger.info(f"💰 Đã đồng bộ số dư Live thật: {self.balance} {quote}")
            except Exception as e:
                logger.error(f"Lỗi đồng bộ số dư live: {e}")

        if mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
            if not self.sync_live_positions_with_exchange():
                raise RuntimeError("Không đối soát được vị thế futures Binance; chưa thể chuyển sang live an toàn.")
        
        logger.info(f"✅ Đã cấu hình xong chế độ: {mode.upper()}")
        
        # Gửi thông báo chuyển đổi chế độ
        mode_str = "🟢 THỰC CHIẾN (LIVE)" if mode == "live" else "🟡 THỬ NGHIỆM (DEMO)"
        switch_msg = (
            f"🔄 **CHUYỂN ĐỔI CHẾ ĐỘ THÀNH CÔNG**\n"
            f"🔹 **Chế độ mới:** {mode_str}\n"
            f"🔹 **Thị trường:** {getattr(self, 'market_type', 'spot').upper()}\n"
            f"🔹 **Đòn bẩy:** {getattr(self, 'leverage', 1)}x\n"
            f"🔹 **Số dư khả dụng:** {self.balance:.2f} {self.config['trading'].get('base_currency', 'USDT')}"
        )
        self._notify_telegram(switch_msg)

        self._restore_state()
        if not self.sync_live_positions_with_exchange():
            raise RuntimeError("Không đối soát được vị thế sau khi đổi chế độ; bot vẫn phải giữ trạng thái dừng.")
            
        self._reconcile_capital_baseline()

        if mode == 'live' and live_equity is not None:
            # Load peak_balance from DB for live mode instead of using demo mode's peak
            live_state = self.db.get_bot_state('live') if hasattr(self.db, 'get_bot_state') else None
            db_peak = float(live_state.get('peak_balance', 0)) if live_state else 0
            if db_peak == 1000.0 and live_equity < 500:
                db_peak = live_equity # Ignore leaked demo peak
            # [ĐỈNH VỐN] Đỉnh cũ (chưa có mốc 2) là số giả -> đặt lại theo equity thật.
            db_peak = self._sanitize_peak_baseline(
                live_state or {}, db_peak, equity_hint=live_equity
            )
            self.peak_balance = max(db_peak, live_equity)
            self._save_state()

        # Persist the selected mode, but never persist API credentials or start state.
        try:
            import re
            config_path = Path(self.config_path)
            lines = config_path.read_text(encoding='utf-8').splitlines(keepends=True)
            bot_index = next(
                (i for i, line in enumerate(lines)
                 if line.split('#', 1)[0].strip() == 'bot:'
                 and not line[:len(line) - len(line.lstrip(' \t'))]),
                None,
            )
            if bot_index is None:
                if lines and not lines[-1].endswith(('\n', '\r')):
                    lines[-1] += '\n'
                lines.extend(['bot:\n', f'  mode: {mode}\n'])
            else:
                bot_indent = len(lines[bot_index]) - len(lines[bot_index].lstrip(' \t'))
                section_end = len(lines)
                mode_index = None
                for i in range(bot_index + 1, len(lines)):
                    line = lines[i]
                    stripped = line.strip()
                    if not stripped or stripped.startswith('#'):
                        continue
                    indent = len(line) - len(line.lstrip(' \t'))
                    if indent <= bot_indent:
                        section_end = i
                        break
                    if re.match(r'^[ \t]+mode\s*:', line):
                        mode_index = i
                        break

                if mode_index is not None:
                    line = lines[mode_index]
                    match = re.match(r'^([ \t]+mode\s*:\s*)([^#\r\n]*?)(\s+#.*)?(\r?\n)?$', line)
                    if not match:
                        raise ValueError('Không thể cập nhật bot.mode mà vẫn giữ nguyên định dạng YAML.')
                    lines[mode_index] = f'{match.group(1)}{mode}{match.group(3) or ""}{match.group(4) or ""}'
                else:
                    lines.insert(section_end, f'{" " * (bot_indent + 2)}mode: {mode}\n')

            config_path.write_text(''.join(lines), encoding='utf-8')
        except Exception as e:
            logger.error("Không lưu được chế độ %s cho lần mở tool sau: %s", mode.upper(), e)

        if mode == 'live':
            import threading
            threading.Thread(
                target=self.sync_live_trades_from_exchange,
                name='live-trade-history-sync', daemon=True,
            ).start()

    def sync_live_trades_from_exchange(self):
        if self.mode != 'live' or not self._history_sync_lock.acquire(blocking=False):
            return 0
        try:
            return self._sync_live_trades_from_exchange()
        finally:
            self._history_sync_lock.release()

    def _sync_exchange_trade_history(self):
        return self.sync_live_trades_from_exchange()

    def _sync_live_trades_from_exchange(self):
        """Incrementally sync Binance fills for configured and dynamically traded symbols."""
        if self.mode != 'live':
            return 0
        logger.info("Đang lấy lịch sử giao dịch từ sàn (Live)...")
        base = self.config.get('trading', {}).get('base_currency', 'USDT')
        symbols = set(self.config.get('trading', {}).get('pairs', []))
        symbols.update(self.db.get_trade_symbols('live'))
        symbols.update(p.get('symbol') for p in self.open_positions if p.get('symbol'))

        # Binance's USD-M user-trades endpoint requires a symbol. Include every
        # market this bot has traded, including dynamic-scanner symbols.
        canonical_symbols = set()
        for symbol in symbols:
            clean = str(symbol).split(':')[0]
            parts = clean.split('/')
            if len(parts) > 2 and parts[-1] == base:
                clean = '/'.join(parts[:-1])
                parts = clean.split('/')
            if len(parts) == 1 and clean.endswith(base):
                clean = clean[:-len(base)] + '/' + base
            if len(clean.split('/')) == 2:
                canonical_symbols.add(clean)

        now_ms = int(time.time() * 1000)
        earliest_ms = now_ms - 89 * 24 * 60 * 60 * 1000
        synced = 0
        failures = 0

        # Binance Futures user-trades endpoint requires a symbol.
        # Use Binance's native high-speed income ledger (fapiPrivateGetIncome) to discover
        # 100% of symbols traded on this account across the full 89-day window in 0.5s!
        if getattr(self, 'market_type', 'spot') == 'futures' and not self._history_market_discovery_done:
            discovered = 0
            try:
                income_data = self.exchange.exchange.fapiPrivateGetIncome({'limit': 1000})
                income_symbols = {r.get('symbol') for r in income_data if r.get('symbol')}
                for isym in income_symbols:
                    if isym.endswith(base):
                        clean_pair = isym[:-len(base)] + '/' + base
                        canonical_symbols.add(clean_pair)
                        discovered += 1
                logger.info(f"⚡ [SMART SYNC] Dò tìm tức thì từ sổ cái Binance: tìm thấy {discovered} symbol có lịch sử giao dịch.")
                self._history_market_discovery_done = True
            except Exception as e:
                logger.warning(f"Không thể dò symbol qua fapiPrivateGetIncome: {e}; dùng danh sách symbol hiện có.")
                self._history_market_discovery_done = True

        for symbol in sorted(canonical_symbols):
            ccxt_symbol = self.exchange._get_ccxt_symbol(symbol)
            last_saved = self.db.get_latest_exchange_trade_timestamp('live', symbol)
            cursor_ms = max(earliest_ms, (last_saved - 60_000) if last_saved else earliest_ms)
            try:
                while cursor_ms < now_ms:
                    end_ms = min(cursor_ms + 7 * 24 * 60 * 60 * 1000 - 1, now_ms)
                    next_id = None
                    while True:
                        if next_id is None:
                            page = self.exchange.exchange.fetch_my_trades(
                                ccxt_symbol, since=cursor_ms, limit=1000,
                                params={'endTime': end_ms},
                            )
                        else:
                            page = self.exchange.exchange.fetch_my_trades(
                                ccxt_symbol, limit=1000, params={'fromId': next_id},
                            )
                        if not page:
                            break
                        page.sort(key=lambda t: (t.get('timestamp') or 0, str(t.get('id') or '')))
                        for trade in page:
                            info = trade.get('info') or {}
                            timestamp = trade.get('timestamp') or info.get('time') or info.get('T') or now_ms
                            if int(timestamp) > end_ms:
                                continue
                            fee_info = trade.get('fee') or {}
                            realized = info.get('realizedPnl', trade.get('realizedPnl', 0)) or 0
                            try:
                                realized = float(realized)
                            except (TypeError, ValueError):
                                realized = 0.0
                            self.db.save_trade({
                                'timestamp': int(timestamp),
                                'symbol': (trade.get('symbol') or symbol).split(':')[0],
                                'side': (trade.get('side') or ('buy' if info.get('buyer') else 'sell')).upper(),
                                'type': trade.get('type') or info.get('type') or 'market',
                                'price': trade.get('price') or info.get('price'),
                                'amount': trade.get('amount') or info.get('qty'),
                                'cost': trade.get('cost') or info.get('quoteQty'),
                                'fee': fee_info.get('cost', info.get('commission')),
                                'commission_asset': fee_info.get('currency') or info.get('commissionAsset'),
                                'pnl': realized,
                                'realized_pnl': realized,
                                'strategy': 'Binance Fill',
                                'status': 'closed',
                                'order_id': trade.get('order') or info.get('orderId'),
                                'exchange_trade_id': trade.get('id') or info.get('id'),
                                'client_order_id': info.get('clientOrderId'),
                                'position_side': info.get('positionSide'),
                                'maker': trade.get('takerOrMaker') == 'maker' if trade.get('takerOrMaker') else info.get('maker'),
                                'raw': info,
                                'mode': 'live',
                            })
                            synced += 1
                        if len(page) < 1000 or (page[-1].get('timestamp') or 0) > end_ms:
                            break
                        last_id = page[-1].get('id') or (page[-1].get('info') or {}).get('id')
                        try:
                            next_id = int(last_id) + 1
                        except (TypeError, ValueError):
                            logger.error(f"Không thể phân trang trade ID của {symbol}; cần đồng bộ lại thủ công.")
                            break
                    cursor_ms = end_ms + 1
            except Exception as e:
                failures += 1
                logger.warning(f"Không thể đồng bộ lịch sử {symbol}: {e}")

        logger.info(
            f"✅ Đồng bộ {synced} fills LIVE (tối đa 89 ngày, có khử trùng lặp); "
            f"lỗi {failures}/{len(canonical_symbols)} cặp."
        )
        return synced


    def sync_live_positions_with_exchange(self) -> bool:
        with self._position_lock:
            return self._sync_live_positions_with_exchange_locked()

    def _sync_live_positions_with_exchange_locked(self) -> bool:
        if self.mode != 'live' or getattr(self, 'market_type', 'spot') != 'futures':
            return True
            
        try:
            exchange_positions = self.exchange.get_futures_positions()
            active_exchange_pos = {}
            unresolved_exchange_position = False
            for p in exchange_positions:
                sym = p.get('symbol', '')
                direction = self._exchange_position_direction(p)
                if sym and direction:
                    active_exchange_pos[(self._clean_symbol(sym), direction)] = p
                else:
                    unresolved_exchange_position = True
                    logger.critical("Không xác định được mã/chiều vị thế Binance %s; khóa lệnh mới.", sym or '<unknown>')

            pending_before = list(self.pending_protection_cleanup)
            pending_remaining = []
            cleanup_blocked = False
            for pending_position in pending_before:
                pending_symbol = pending_position.get('symbol')
                pending_direction = pending_position.get('direction', 'LONG')
                pending_key = (self._clean_symbol(pending_symbol), pending_direction)
                if pending_key in active_exchange_pos:
                    # A same-direction position reappeared before the old order
                    # cleanup was verified. Do not cancel protection under it;
                    # require review before allowing another bot entry.
                    pending_remaining.append(pending_position)
                    cleanup_blocked = True
                    logger.critical(
                        "Còn lệnh bảo vệ chờ dọn cho %s trong khi vị thế cùng chiều đã xuất hiện; khóa lệnh mới.",
                        pending_symbol,
                    )
                    continue
                warnings = self._retry_pending_protection_cleanup(
                    pending_position, pending_direction
                )
                if warnings:
                    pending_remaining.append(pending_position)
                    cleanup_blocked = True
                    logger.critical(
                        "Chưa xác minh dọn hết lệnh SL/TP cũ của %s: %s; khóa lệnh mới và sẽ thử lại.",
                        pending_symbol, ', '.join(warnings),
                    )
                else:
                    logger.info(
                        "Đã xác minh hủy hết lệnh bảo vệ còn lại của vị thế %s đã đóng.",
                        pending_symbol,
                    )

            pending_keys = {
                (self._clean_symbol(item.get('symbol')), item.get('direction', 'LONG'))
                for item in pending_remaining
            }
            cleanup_state_changed = pending_remaining != pending_before
                 
            # 1. KHỬ TRÙNG LẶP NỘI BỘ TRƯỚC KHI ĐỐI SOÁT (INTERNAL DEDUPLICATION):
            # Nếu có nhiều bản ghi cùng một cặp và cùng chiều (do race condition khi M1 vừa khớp),
            # ưu tiên giữ lại vị thế có sl_order_id hợp lệ và không phải là 'exchange_reconciled'
            deduped_raw = []
            seen_raw_keys = set()
            sorted_raw = sorted(
                self.open_positions,
                key=lambda item: (
                    1 if item.get('sl_order_id') else 0,
                    0 if str(item.get('strategy', '')) == 'exchange_reconciled' or str(item.get('symbol', '')).endswith(':USDT') else 1
                ),
                reverse=True
            )
            for item in sorted_raw:
                k = (self._clean_symbol(item.get('symbol')), item.get('direction', 'LONG'))
                if k not in seen_raw_keys:
                    seen_raw_keys.add(k)
                    deduped_raw.append(item)
                else:
                    removed = True
                    logger.info("🧹 [DEDUPLICATE] Đã xóa vị thế bóng ma trùng lặp %s (%s, strategy=%s) khỏi bộ nhớ!", item.get('symbol'), item.get('direction'), item.get('strategy'))
            self.open_positions = deduped_raw

            positions_to_keep = []
            removed = False
            matched_exchange_positions = set()
            for p in self.open_positions:
                position_key = (
                    self._clean_symbol(p['symbol']),
                    p.get('direction', 'LONG'),
                )
                if position_key in active_exchange_pos:
                    # Cập nhật số liệu thực tế từ sàn (Entry, PnL, Margin)
                    real_pos = active_exchange_pos[position_key]
                    matched_exchange_positions.add(position_key)
                    if real_pos.get('entryPrice'):
                        p['entry_price'] = float(real_pos['entryPrice'])
                    
                    # Update real amount, pnl and cost if CCXT provides it
                    contracts = real_pos.get('contracts') or real_pos.get('info', {}).get('positionAmt')
                    if contracts:
                        p['amount'] = abs(float(contracts))
                        
                    upnl = real_pos.get('unrealizedPnl') or real_pos.get('info', {}).get('unRealizedProfit')
                    if upnl is not None:
                        p['real_pnl'] = float(upnl)
                        
                    margin = real_pos.get('initialMargin') or real_pos.get('info', {}).get('initialMargin')
                    if margin is not None:
                        p['cost'] = float(margin)
                    
                    positions_to_keep.append(p)
                else:
                    logger.warning(f"Vị thế {p['symbol']} không còn tồn tại trên Binance. Tiến hành đối soát fill để xác định nguyên nhân đóng.")
                    self._handle_externally_closed_position(p)
                    removed = True
                    if position_key not in pending_keys:
                        warnings = self._retry_pending_protection_cleanup(
                            p, p.get('direction', 'LONG')
                        )
                        if warnings:
                            pending_remaining.append(dict(p))
                            pending_keys.add(position_key)
                            cleanup_blocked = True
                            cleanup_state_changed = True
                            logger.critical(
                                "Vị thế %s đã đóng nhưng lệnh bảo vệ chưa dọn xác minh: %s; khóa lệnh mới.",
                                p['symbol'], ', '.join(warnings),
                            )
                        else:
                            logger.info(
                                "Đã xác minh dọn các lệnh SL/TP còn lại của %s sau khi vị thế đóng.",
                                p['symbol'],
                            )
                    else:
                        cleanup_blocked = True

            self.pending_protection_cleanup = pending_remaining
            self.unreconciled_exchange_positions = unresolved_exchange_position or cleanup_blocked
            for position_key, real_pos in active_exchange_pos.items():
                if position_key in matched_exchange_positions:
                    continue

                # KIỂM TRA M1 SNIPER ĐANG RÌNH (PENDING STALKING GUARDIAN):
                clean_sym_ex = position_key[0]
                is_in_stalking = any(
                    self._clean_symbol(stalk_sym) == clean_sym_ex
                    for stalk_sym in getattr(self, 'pending_stalking_orders', {})
                )
                if is_in_stalking:
                    logger.info(
                        "⏳ Vị thế %s vừa khớp trên sàn đang chờ M1 Sniper hoàn tất đặt lệnh Stop-Loss. Tạm hoãn nhận diện reconciled.",
                        real_pos.get('symbol')
                    )
                    continue

                raw_symbol = str(real_pos.get('symbol') or '')
                symbol = raw_symbol.split(':')[0] if ':' in raw_symbol else raw_symbol
                direction = position_key[1]
                info = real_pos.get('info') or {}
                amount = abs(float(real_pos.get('contracts') or info.get('positionAmt') or 0))
                entry_price = float(real_pos.get('entryPrice') or info.get('entryPrice') or 0)
                if not symbol or amount <= 0 or entry_price <= 0:
                    self.unreconciled_exchange_positions = True
                    logger.critical("Không đủ dữ liệu để nhận diện vị thế Binance %s; khóa lệnh mới.", position_key)
                    continue

                try:
                    # [BAI HOC 69] Lệnh tay nay theo ĐÚNG mô hình hiện hành (Kịch bản D) thay vì
                    # hai hằng số cũ 1.5% SL / 4.5% TP còn tồn đọng từ thời "bảo hộ tự động":
                    #   SL = clamp(1.5 x ATR15m đã đóng, 1.5%, 3.5%)  (khi risk.unified_sl_from_atr bật)
                    #   TP = TP1 = clamp(1.30 x ATR15m, 1.30%, 2.20%)  (khi risk.partial_tp_unified_bounds bật)
                    # Vì bot KHÔNG chốt 50% lệnh tay, mức TP1 này là mức chốt lời duy nhất đặt trên sàn;
                    # người dùng vẫn toàn quyền dời/hủy. Tắt 2 công tắc trên -> quay lại profile theo
                    # lớp tài sản và các khoá legacy manual_adopt_*_pct.
                    risk_cfg_adopt = self.config.get('risk') if isinstance(self.config.get('risk'), dict) else {}
                    manual_sl_pct = float(risk_cfg_adopt.get('manual_adopt_stop_loss_pct', 0.015))
                    if not math.isfinite(manual_sl_pct) or not 0 < manual_sl_pct < 0.20:
                        manual_sl_pct = 0.015
                    manual_tp_pct = float(risk_cfg_adopt.get('manual_adopt_take_profit_pct', 0.045))
                    if not math.isfinite(manual_tp_pct) or not 0 < manual_tp_pct < 1.0:
                        manual_tp_pct = 0.045

                    # Đo ATR/ADX từ nến 15m ĐÃ ĐÓNG, dùng chung nguồn với thang giảm tải/trailing
                    adopted_atr_pct = None
                    adopted_regime = 'ranging'
                    if self.auto_adopt_manual_positions:
                        try:
                            adopted_metrics = self._adaptive_trailing_metrics(
                                {'symbol': symbol, 'direction': direction}, entry_price
                            ) or {}
                            raw_adopted_atr = adopted_metrics.get('atr_pct')
                            if raw_adopted_atr is not None:
                                cand_atr = float(raw_adopted_atr)
                                if math.isfinite(cand_atr) and cand_atr > 0:
                                    adopted_atr_pct = cand_atr
                            adopted_regime = str(adopted_metrics.get('regime') or 'ranging')
                        except Exception as atr_err:
                            logger.debug(f"Không đo được ATR15m cho lệnh tay {symbol}: {atr_err}")

                    if self.auto_adopt_manual_positions:
                        # --- Stop-Loss: hợp nhất ATR 15m giống vị thế bot tự mở ---
                        if bool(risk_cfg_adopt.get('unified_sl_from_atr', True)) and adopted_atr_pct:
                            try:
                                unified_mult_adopt = float(risk_cfg_adopt.get('unified_sl_atr_multiplier', 1.5))
                            except (TypeError, ValueError, OverflowError):
                                unified_mult_adopt = 1.5
                            if not math.isfinite(unified_mult_adopt) or unified_mult_adopt <= 0:
                                unified_mult_adopt = 1.5
                            stop_pct = min(0.035, max(0.015, unified_mult_adopt * adopted_atr_pct))
                        else:
                            stop_pct = manual_sl_pct
                        # --- Take-Profit: Kịch bản D (TP1 = 1.30 x ATR) ---
                        if adopted_atr_pct:
                            profile_adopt = self._get_asset_adaptive_trailing_profile(symbol)
                            if adopted_regime == 'trend_favorable':
                                regime_mult_adopt = 1.15
                            elif adopted_regime == 'trend_adverse':
                                regime_mult_adopt = 0.85
                            else:
                                regime_mult_adopt = 1.00
                            try:
                                micro_k_adopt = float(risk_cfg_adopt.get('partial_tp_atr_multiplier', 1.30))
                            except (TypeError, ValueError, OverflowError):
                                micro_k_adopt = 1.30
                            if not math.isfinite(micro_k_adopt) or micro_k_adopt <= 0:
                                micro_k_adopt = 1.30
                            if bool(risk_cfg_adopt.get('partial_tp_unified_bounds', False)):
                                min_tp_adopt = float(risk_cfg_adopt.get('partial_tp_min_pct', 0.0130))
                                max_tp_adopt = float(risk_cfg_adopt.get('partial_tp_max_pct', 0.0220))
                            else:
                                min_tp_adopt = float(profile_adopt.get('partial_tp_min', 0.0075))
                                max_tp_adopt = float(profile_adopt.get('partial_tp_max', 0.0135))
                            if min_tp_adopt > max_tp_adopt:
                                min_tp_adopt, max_tp_adopt = max_tp_adopt, min_tp_adopt
                            take_pct = min(max_tp_adopt, max(min_tp_adopt, adopted_atr_pct * micro_k_adopt * regime_mult_adopt))
                        elif bool(risk_cfg_adopt.get('partial_tp_unified_bounds', False)):
                            # Không đo được ATR: giữ sàn của Kịch bản D thay vì 4.5% cũ
                            take_pct = float(risk_cfg_adopt.get('partial_tp_min_pct', 0.0130))
                        else:
                            take_pct = manual_tp_pct
                    else:
                        stop_pct = float(risk_cfg_adopt.get('stop_loss_pct', 0.04))
                        take_pct = float(risk_cfg_adopt.get('take_profit_pct', 0.08))
                    if not math.isfinite(stop_pct) or not 0 < stop_pct < 1:
                        stop_pct = 0.015 if self.auto_adopt_manual_positions else 0.04
                    if not math.isfinite(take_pct) or not 0 < take_pct < 1:
                        take_pct = 0.045 if self.auto_adopt_manual_positions else 0.08
                    leverage = max(
                        1.0,
                        float(real_pos.get('leverage') or info.get('leverage') or getattr(
                            self, 'leverage', self.config.get('trading', {}).get('leverage', 1)
                        )),
                    )
                    margin = real_pos.get('initialMargin') or info.get('initialMargin')
                    cost = float(margin) if margin not in (None, '') else 0.0
                    if cost <= 0:
                        cost = amount * entry_price / leverage

                    is_adopted = False
                    adopted_sl_id = None
                    adopted_tp_id = None
                    sl_price = entry_price * (1 - stop_pct if direction == 'LONG' else 1 + stop_pct)
                    tp_price = entry_price * (1 + take_pct if direction == 'LONG' else 1 - take_pct)
                    
                    if self.auto_adopt_manual_positions:
                        # 1. Tra cứu xem trên Binance đã có sẵn lệnh Stop-Loss / Take-Profit của cặp này chưa
                        found_sl_id = None
                        found_tp_id = None
                        if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                            try:
                                orders = self.exchange.get_open_orders(symbol, trigger=True, strict=True)
                                target_close_side = 'sell' if direction == 'LONG' else 'buy'
                                for o in orders:
                                    o_info = o.get('info') or {}
                                    raw_types = [
                                        str(o_info.get('orderType') or ''),
                                        str(o_info.get('origType') or ''),
                                        str(o_info.get('type') or ''),
                                        str(o.get('type') or ''),
                                    ]
                                    o_side = str(o.get('side') or o_info.get('side') or '').lower()
                                    if o_side != target_close_side:
                                        continue
                                    is_tp_order = any('TAKE' in t.upper() for t in raw_types)
                                    is_stop_order = (
                                        any('STOP' in t.upper() for t in raw_types)
                                        or float(o.get('stopPrice') or o_info.get('triggerPrice') or o_info.get('stopPrice') or 0) > 0
                                    ) and not is_tp_order
                                    if is_stop_order and not found_sl_id:
                                        found_sl_id = str(o.get('id') or o_info.get('algoId') or o_info.get('orderId') or '')
                                        stop_trigger_p = float(o.get('stopPrice') or o_info.get('triggerPrice') or o_info.get('stopPrice') or 0)
                                        if stop_trigger_p > 0:
                                            sl_price = stop_trigger_p
                                    elif is_tp_order and not found_tp_id:
                                        found_tp_id = str(o.get('id') or o_info.get('algoId') or o_info.get('orderId') or '')
                                        tp_trigger_p = float(o.get('stopPrice') or o_info.get('triggerPrice') or o_info.get('stopPrice') or 0)
                                        if tp_trigger_p > 0:
                                            tp_price = tp_trigger_p
                            except Exception as oe:
                                logger.warning(f"Không thể tra cứu lệnh điều kiện sẵn có của {symbol}: {oe}")
                        
                        # 2. Nếu chưa có SL trên sàn, tự động gửi lệnh STOP_MARKET theo khoảng cách ATR vừa tính
                        if not found_sl_id and self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                            try:
                                # Lấy giá thị trường hiện tại để tránh lỗi -2021 (Immediately Trigger)
                                curr_p = entry_price
                                try:
                                    tk = self.exchange.get_ticker(symbol)
                                    raw_p = float((tk or {}).get('last') or (tk or {}).get('close') or 0)
                                    if raw_p > 0 and math.isfinite(raw_p):
                                        curr_p = raw_p
                                except Exception:
                                    pass

                                # Khoảng cách SL đã tính từ ATR 15m (Kịch bản D), kẹp [1.5%, 3.5%]
                                if direction == 'LONG':
                                    sl_price = entry_price * (1.0 - stop_pct)
                                    if sl_price >= curr_p * 0.998:
                                        sl_price = curr_p * 0.9978
                                else:
                                    sl_price = entry_price * (1.0 + stop_pct)
                                    if sl_price <= curr_p * 1.002:
                                        sl_price = curr_p * 1.0022

                                close_side = 'sell' if direction == 'LONG' else 'buy'
                                new_sl_order = self.exchange.create_stop_market_order(symbol, close_side, amount, sl_price)
                                sl_info = (new_sl_order or {}).get('info') or {}
                                found_sl_id = str((new_sl_order or {}).get('id') or sl_info.get('algoId') or sl_info.get('orderId') or '')
                            except Exception as se:
                                logger.error(f"Lỗi đặt Stop-Loss tự động bảo hiểm cho lệnh tay {symbol}: {se}")

                        # 3. Nếu chưa có TP trên sàn và Notional >= 5.0 USDT, đặt TAKE_PROFIT_MARKET tại TP1 Kịch bản D
                        if not found_tp_id and self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures' and (amount * entry_price) >= 5.0:
                            try:
                                curr_p_tp = entry_price
                                try:
                                    tk_tp = self.exchange.get_ticker(symbol)
                                    raw_p_tp = float((tk_tp or {}).get('last') or (tk_tp or {}).get('close') or 0)
                                    if raw_p_tp > 0 and math.isfinite(raw_p_tp):
                                        curr_p_tp = raw_p_tp
                                except Exception:
                                    pass
                                # [BAI HOC 69] Không đặt TP đã nằm sai phía / sát giá hiện tại: lệnh điều kiện
                                # sẽ kích hoạt ngay (-2021) và biến thành việc ĐÓNG MARKET vị thế của người dùng.
                                tp_already_passed = (
                                    direction == 'LONG' and tp_price <= curr_p_tp * 1.002
                                ) or (
                                    direction == 'SHORT' and tp_price >= curr_p_tp * 0.998
                                )
                                if tp_already_passed:
                                    logger.info(
                                        "⏭️ [MANUAL TP SKIP] %s: giá hiện tại %.6g đã vượt mốc TP1 %.6g; "
                                        "không đặt lại TP để tránh đóng market vị thế của người dùng. "
                                        "Trailing/Choke SL tiếp tục bảo vệ.",
                                        symbol, curr_p_tp, tp_price,
                                    )
                                else:
                                    close_side = 'sell' if direction == 'LONG' else 'buy'
                                    new_tp_order = self.exchange.create_take_profit_market_order(symbol, close_side, amount, tp_price)
                                    tp_info = (new_tp_order or {}).get('info') or {}
                                    found_tp_id = str((new_tp_order or {}).get('id') or tp_info.get('algoId') or tp_info.get('orderId') or '')
                                    if found_tp_id:
                                        logger.info(
                                            "🚀 [MANUAL TP ĐÃ XÁC NHẬN] %s %s: TP1 Kịch bản D tại %.6g (+%.2f%%, ID: %s)",
                                            direction, symbol, tp_price, take_pct * 100, found_tp_id,
                                        )
                            except Exception as tpe:
                                logger.debug(f"Không thể đặt TP tự động cho lệnh tay {symbol}: {tpe}")
                                
                        if found_sl_id:
                            is_adopted = True
                            adopted_sl_id = found_sl_id
                        if found_tp_id:
                            adopted_tp_id = found_tp_id

                    pos_ts = real_pos.get('updateTime') or info.get('updateTime')
                    if pos_ts:
                        try:
                            adopted_time_iso = datetime.fromtimestamp(float(pos_ts) / 1000.0).isoformat()
                        except Exception:
                            adopted_time_iso = datetime.now().isoformat()
                    else:
                        adopted_time_iso = datetime.now().isoformat()

                    # [BAI HOC 69] Nếu trên sàn đã có sẵn SL/TP do người dùng đặt, ưu tiên giữ nguyên
                    # và ghi nhận đúng khoảng cách thực tế (thay vì ghi đè bằng số tính toán).
                    effective_sl_pct = stop_pct
                    if entry_price > 0 and sl_price > 0:
                        try:
                            cand_eff_sl = abs(entry_price - sl_price) / entry_price
                            if math.isfinite(cand_eff_sl) and 0.001 <= cand_eff_sl <= 0.20:
                                effective_sl_pct = cand_eff_sl
                        except (TypeError, ValueError, OverflowError):
                            pass
                    effective_tp_pct = take_pct
                    if entry_price > 0 and tp_price > 0:
                        try:
                            cand_eff_tp = abs(tp_price - entry_price) / entry_price
                            if math.isfinite(cand_eff_tp) and 0.001 <= cand_eff_tp <= 1.0:
                                effective_tp_pct = cand_eff_tp
                        except (TypeError, ValueError, OverflowError):
                            pass

                    tracked = {
                        'symbol': symbol,
                        'direction': direction,
                        'side': 'buy' if direction == 'LONG' else 'sell',
                        'entry_price': entry_price,
                        'amount': amount,
                        'initial_amount': amount,
                        'cost': cost,
                        'initial_cost': cost,
                        'leverage': leverage,
                        'stop_loss': sl_price,
                        'initial_sl': sl_price,
                        'take_profit': tp_price,
                        'atr': (entry_price * adopted_atr_pct) if adopted_atr_pct else None,
                        'atr_pct': adopted_atr_pct,
                        'initial_sl_distance_pct': effective_sl_pct,
                        'total_sl_stages': self._calc_adaptive_stages({'initial_amount': amount, 'entry_price': entry_price}, entry_price),
                        'sl_stage_completed': 0,
                        'order_id': f"manual-adopted-{int(time.time() * 1000)}" if is_adopted else f"exchange-reconciled-{int(time.time() * 1000)}",
                        'strategy': 'manual_adopted' if is_adopted else 'exchange_reconciled',
                        'market_type': 'futures',
                        'entry_fee': 0.0,
                        'sl_order_id': adopted_sl_id,
                        'tp_order_id': adopted_tp_id,
                        'trailing_stop': None,
                        'trailing_best_price': entry_price,
                        'trailing_active': False,
                        'trailing_status': 'exchange_stop' if is_adopted else 'protection_unavailable',
                        'trailing_distance_pct': None,
                        'trailing_atr_pct': None,
                        'trailing_adx': None,
                        'trailing_regime': 'not_calculated',
                        'trailing_net_breakeven': None,
                        'reconciled_from_exchange': not is_adopted,
                        'timestamp': adopted_time_iso,
                    }
                    if is_adopted:
                        tracked['protection_status'] = 'exchange_stop_verified'
                        tracked['manual_adopted'] = True
                        tracked['is_manual_position'] = True

                    positions_to_keep.append(tracked)
                    matched_exchange_positions.add(position_key)
                    removed = True
                    
                    if is_adopted:
                        self._notify_telegram(
                            f"🛡️ **[TỰ ĐỘNG BẢO HỘ & QUẢN LÝ LỆNH TAY]**\n"
                            f"Cặp: **{symbol}** ({direction})\n"
                            f"Khối lượng: `{amount:g}` coin | Giá vào: `{entry_price:.6g}`\n"
                            f"🛡️ **Stop-Loss sàn {effective_sl_pct*100:.2f}%** "
                            f"({('1.5 × ATR15m' if (adopted_atr_pct and abs(stop_pct - manual_sl_pct) > 1e-9) else 'mức an toàn')}) tại: `{sl_price:.6g}` "
                            f"(Order ID: `{adopted_sl_id}`)\n"
                            f"🚀 **Take-Profit sàn {effective_tp_pct*100:.2f}%** (TP1 Kịch bản D = 1.30 × ATR15m) tại: `{tp_price:.6g}` "
                            f"(Order ID: `{adopted_tp_id or 'chưa đặt được - Notional < 5 USDT'}`)\n"
                            f"🖐️ **Nguyên tắc bảo hộ:** Bot CHỈ hỗ trợ bảo vệ vị thế — KHÔNG tự đóng, không chốt 50%, "
                            f"không cắt theo thời gian, không thoát vì AI đảo chiều. Quyền quyết định thoát lệnh thuộc về bạn."
                        )
                        logger.info(
                            "🎯 Đã tiếp quản và kích hoạt bảo hộ tự động cho lệnh tay: %s %s "
                            "(SL ID: %s, SL: %.6g -%.2f%%, TP: %.6g +%.2f%%, ATR15m: %s, regime: %s)",
                            direction, symbol, adopted_sl_id, sl_price, effective_sl_pct * 100,
                            tp_price, effective_tp_pct * 100,
                            f"{adopted_atr_pct*100:.2f}%" if adopted_atr_pct else "không đo được",
                            adopted_regime,
                        )
                    else:
                        self._notify_telegram(
                            f"⚠️ Đã phát hiện vị thế LIVE chưa có trong trạng thái tool: {direction} {symbol}, "
                            f"số lượng {amount:g}. Tool đã đưa vị thế vào dashboard để tránh vào trùng; "
                            "hãy kiểm tra lệnh bảo vệ SL/TP trực tiếp trên Binance."
                        )
                        logger.critical(
                            "Nhận diện vị thế Binance chưa được tool theo dõi: %s %s; cần kiểm tra SL/TP trên sàn.",
                            direction, symbol,
                        )
                except (TypeError, ValueError, OverflowError) as e:
                    self.unreconciled_exchange_positions = True
                    logger.critical("Không thể nhập vị thế Binance %s vào trạng thái tool: %s", position_key, e)
             
            self.open_positions = positions_to_keep

            # A recovered position without its saved stop ID has unknown
            # protection. Do not use synthesized local levels to close it or
            # permit new entries until the position is manually reviewed.
            protection_review = False
            if self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures':
                protection_review = self._verify_live_position_protection(positions_to_keep)
                self.unreconciled_exchange_positions = (
                    self.unreconciled_exchange_positions or protection_review
                )
                if protection_review:
                    logger.critical(
                        "Có vị thế LIVE thiếu ID stop-loss đã xác minh; khóa bot cho tới khi đóng hoặc xử lý thủ công."
                    )

            # Luôn cập nhật số dư thực tế từ sàn
            base_currency = self.config['trading'].get('base_currency', 'USDT')
            bal = self.exchange.get_futures_balance()
            balance_ok = isinstance(bal, dict) and 'free' in bal
            self.live_balance_synced = balance_ok
            if balance_ok:
                if 'total' in bal and not isinstance(bal['total'], dict):
                    # Đã được parse bởi ExchangeConnector
                    self.balance = float(bal.get('free', 0))
                else:
                    # CCXT raw dict
                    asset_bal = bal.get(base_currency, {})
                    if isinstance(asset_bal, dict):
                        self.balance = float(asset_bal.get('free', 0))
                    else:
                        self.balance = float(bal.get('free', 0))
                        
            if removed or cleanup_state_changed:
                self._save_state()
            return True
        except Exception as e:
            logger.error(f"Lỗi đồng bộ open positions từ sàn: {e}")
            return False

    @property
    def auto_adopt_manual_positions(self) -> bool:
        return bool(self.config.get('trading', {}).get('auto_adopt_manual_positions', False))

    @auto_adopt_manual_positions.setter
    def auto_adopt_manual_positions(self, value: bool):
        if 'trading' not in self.config:
            self.config['trading'] = {}
        self.config['trading']['auto_adopt_manual_positions'] = bool(value)

    @property
    def free_roll_recycling(self) -> bool:
        return bool(self.config.get('trading', {}).get('free_roll_recycling', True))

    @free_roll_recycling.setter
    def free_roll_recycling(self, value: bool):
        if 'trading' not in self.config:
            self.config['trading'] = {}
        self.config['trading']['free_roll_recycling'] = bool(value)

    def get_status(self) -> dict:
        """Lấy trạng thái bot và equity Futures từ cùng nguồn Binance."""
        initial = self.config['trading']['initial_capital']
        # [SỔ VỐN] Mốc vốn PnL = tiền thật đã bơm vào ví Futures (tự dựng lại từ sàn).
        invested_basis = self._invested_basis()
        live_futures = self.mode == 'live' and getattr(self, 'market_type', 'spot') == 'futures'
        with self._position_lock:
            local_positions = [dict(position) for position in self.open_positions]
            unreconciled = self.unreconciled_exchange_positions
            pending_cleanup_count = len(self.pending_protection_cleanup)
        position_count = len(local_positions)
        account_snapshot_stale = False
        wallet_balance = None
        available_balance = self.balance
        margin_balance = None
        unrealized_pnl = 0.0
        account_snapshot_time = None
        used_margin = sum(float(pos.get('cost', 0) or 0) for pos in local_positions)

        if live_futures:
            now_monotonic = time.monotonic()
            snapshot_age = (
                now_monotonic - self._futures_account_snapshot_monotonic
                if self._futures_account_snapshot_monotonic is not None else None
            )
            if self._futures_account_snapshot is None or snapshot_age is None or snapshot_age >= 5.0:
                try:
                    account = self.exchange.get_futures_balance()
                    if account and account.get('margin_balance') is not None:
                        self._futures_account_snapshot = {
                            key: account.get(key) for key in (
                                'wallet_balance', 'margin_balance', 'unrealized_pnl',
                                'available_balance', 'initial_margin',
                                'position_initial_margin', 'open_order_initial_margin', 'update_time',
                            )
                        }
                        self._futures_account_snapshot_time = datetime.now()
                        self._futures_account_snapshot_monotonic = time.monotonic()
                        if account.get('available_balance') is not None:
                            self.balance = float(account['available_balance'])
                    try:
                        self._futures_positions_snapshot = self.exchange.get_futures_positions()
                        self._futures_positions_snapshot_time = datetime.now()
                    except Exception as e:
                        logger.warning('Không lấy được PnL Mark từng vị thế Binance: %s', e)
                except Exception as e:
                    logger.warning('Không lấy được snapshot Futures Binance cho dashboard: %s', e)

            snapshot = self._futures_account_snapshot
            if snapshot and snapshot.get('margin_balance') is not None:
                snapshot_age = (
                    now_monotonic - self._futures_account_snapshot_monotonic
                    if self._futures_account_snapshot_monotonic is not None else None
                )
                account_snapshot_stale = snapshot_age is None or snapshot_age >= 10.0
                wallet_balance = snapshot.get('wallet_balance')
                available_balance = snapshot.get('available_balance', self.balance)
                margin_balance = float(snapshot['margin_balance'])
                unrealized_pnl = float(snapshot.get('unrealized_pnl') or 0.0)
                used_margin = float(snapshot.get('initial_margin') or 0.0)
                account_snapshot_time = (
                    self._futures_account_snapshot_time.isoformat()
                    if self._futures_account_snapshot_time else None
                )
                # Binance marginBalance already equals walletBalance + unrealized PnL.
                # Do not add local position cost or PnL to this authoritative equity.
                equity = margin_balance
                quote_currency = self.config.get('trading', {}).get('base_currency', 'USDT')
                total_realized = self.db.get_total_net_pnl(self.mode, quote_currency) if getattr(self, 'db', None) else 0.0
                pnl = total_realized + unrealized_pnl
            else:
                # If exchange balance data is unavailable, do not present a local
                # reconstruction as an authoritative LIVE account value.
                equity = None
                pnl = None
                account_snapshot_stale = True
        else:
            try:
                for pos in local_positions:
                    ticker = self.exchange.get_ticker(pos['symbol'])
                    if ticker:
                        current_price = ticker['last']
                        if pos['direction'] == 'LONG':
                            unrealized_pnl += (current_price - pos['entry_price']) * pos['amount']
                        else:
                            unrealized_pnl += (pos['entry_price'] - current_price) * pos['amount']
            except Exception:
                pass
            equity = self.balance + used_margin + unrealized_pnl
            # [SỔ VỐN] PnL = equity - mốc vốn thật. Không còn phụ thuộc con số người dùng khai báo.
            pnl = equity - invested_basis

        return {
            'mode': self.mode,
            'market_type': getattr(self, 'market_type', 'spot'),
            'exchange_connected': self.exchange_connected,
            'leverage': getattr(self, 'leverage', 1),
            'max_leverage': self._configured_max_leverage(),
            'last_dynamic_leverage': int(getattr(self, 'last_dynamic_leverage', 1)),
            'last_leverage_symbol': getattr(self, 'last_leverage_symbol', None),
            'last_pair_max_leverage': getattr(self, 'last_pair_max_leverage', None),
            'last_leverage_limit_verified': getattr(self, 'last_leverage_limit_verified', None),
            'last_leverage_limit_source': getattr(self, 'last_leverage_limit_source', None),
            'max_open_positions': self._configured_max_open_positions(),
            'min_open_positions': self._configured_min_open_positions(),
            'last_dynamic_position_limit': getattr(self, 'last_dynamic_position_limit', None),
            'last_position_signal_quality': getattr(self, 'last_position_signal_quality', None),
            'last_position_available_margin': getattr(self, 'last_position_available_margin', None),
            'last_position_open_risk': getattr(self, 'last_position_open_risk', None),
            'last_position_risk_budget': getattr(self, 'last_position_risk_budget', None),
            'max_margin_utilization_pct': self._max_margin_utilization(),
            'max_total_open_risk_pct': self._max_total_open_risk(),
            'ai_recommended_max_positions': getattr(self, 'ai_recommended_max_positions', None),
            'is_running': self.is_running,
            'balance': self.balance,
            'available_balance': available_balance,
            'wallet_balance': wallet_balance,
            'margin_balance': margin_balance,
            'equity': equity,
            'used_margin': used_margin,
            'unrealized_pnl': unrealized_pnl,
            'account_snapshot_time': account_snapshot_time,
            'account_snapshot_stale': account_snapshot_stale,
            'unreconciled_exchange_positions': unreconciled,
            'pending_protection_cleanup_count': pending_cleanup_count,
            'initial_capital': initial,
            # [SỔ VỐN] Nạp/rút ròng dựng từ lịch sử TRANSFER của sàn + mốc vốn thực dùng để tính PnL.
            'net_deposits': float(getattr(self, 'net_deposits', 0.0) or 0.0),
            'invested_basis': invested_basis,
            'capital_ledger_complete': bool(getattr(self, '_ledger_complete', False)),
            'capital_ledger_coverage_start_ms': int(getattr(self, '_ledger_coverage_start_ms', 0) or 0),
            'session_pnl': (
                (float(equity) - invested_basis) if equity is not None else None
            ),
            'capital_ledger': list(getattr(self, 'capital_ledger', []) or [])[-20:],
            'pnl': pnl,
            'pnl_pct': (
                (pnl / invested_basis) * 100
                if pnl is not None and invested_basis > 0
                else None
            ),
            'peak_balance': self.peak_balance,
            'drawdown': (self.peak_balance - equity) / self.peak_balance
                if self.peak_balance > 0 and equity is not None else None,
            'open_positions': position_count,
            'pending_stalking_count': len(getattr(self, 'pending_stalking_orders', {})),
            'pending_stalking_orders': list(getattr(self, 'pending_stalking_orders', {}).values()),
            'trade_count': self.trade_count,
            'strategies': [s.name for s in self.strategies],
            'pairs': self.config['trading']['pairs'],
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'tradfi_enabled': bool(self.config.get('tradfi', {}).get('enabled', False)),
            'auto_adopt_manual_positions': self.auto_adopt_manual_positions,
            'free_roll_recycling': self.free_roll_recycling,
            'free_roll_positions_count': sum(1 for p in local_positions if self._is_position_risk_free(p)),
            'at_risk_positions_count': sum(1 for p in local_positions if not self._is_position_risk_free(p)),
            'only_tradfi': bool(self.config.get('tradfi', {}).get('only_tradfi', False)),
            'tradfi_market_open': MarketScanner.is_us_market_open(),
        }

    def get_dashboard_positions(self) -> List[Dict]:
        """Return local position controls with the latest exchange Mark PnL overlay."""
        with self._position_lock:
            # Khử trùng lặp tại nguồn dashboard để không bao giờ hiển thị 2 dòng cho cùng 1 cặp
            deduped_local = []
            seen_k = set()
            sorted_local = sorted(
                self.open_positions,
                key=lambda item: (
                    1 if item.get('sl_order_id') else 0,
                    0 if str(item.get('strategy', '')) == 'exchange_reconciled' or str(item.get('symbol', '')).endswith(':USDT') else 1
                ),
                reverse=True
            )
            for item in sorted_local:
                k = (self._clean_symbol(item.get('symbol')), item.get('direction', 'LONG'))
                if k not in seen_k:
                    seen_k.add(k)
                    deduped_local.append(dict(item))
            positions = deduped_local

        exchange_by_symbol = {}
        for exchange_position in self._futures_positions_snapshot or []:
            exchange_symbol = str(exchange_position.get('symbol') or '').split(':', 1)[0]
            key = exchange_symbol.replace('/', '').upper()
            if key:
                exchange_by_symbol[key] = exchange_position

        for position in positions:
            local_symbol = str(position.get('symbol') or '').split(':', 1)[0]
            key = local_symbol.replace('/', '').upper()
            exchange_position = exchange_by_symbol.get(key)
            if exchange_position:
                for local_key, exchange_key in (
                    ('mark_price', 'markPrice'),
                    ('unrealized_pnl_mark', 'unrealizedPnl'),
                    ('exchange_initial_margin', 'initialMargin'),
                    ('exchange_leverage', 'leverage'),
                ):
                    value = exchange_position.get(exchange_key)
                    if value is not None:
                        position[local_key] = value

            # Normalization of keys for Dashboard and Cloud Sync
            entry_price = float(position.get('entry_price') or 0.0)
            amount = abs(float(position.get('amount') or 0.0))
            leverage = int(position.get('exchange_leverage') or position.get('leverage') or 1)
            direction = str(position.get('direction') or position.get('side') or 'LONG').upper()
            if direction in ('BUY', 'LONG'):
                direction = 'LONG'
            else:
                direction = 'SHORT'
            mark_price = float(position.get('mark_price') or entry_price)

            margin = float(position.get('exchange_initial_margin') or position.get('margin') or position.get('cost') or 0.0)
            if margin <= 0.0 and entry_price > 0 and amount > 0:
                margin = (entry_price * amount) / max(1, leverage)

            upnl_val = position.get('unrealized_pnl_mark')
            if upnl_val is not None:
                upnl = float(upnl_val)
            elif position.get('real_pnl') is not None:
                upnl = float(position['real_pnl'])
            elif entry_price > 0 and amount > 0:
                upnl = (mark_price - entry_price) * amount if direction == 'LONG' else (entry_price - mark_price) * amount
            else:
                upnl = 0.0

            pnl_pct = (upnl / margin * 100.0) if margin > 0.0 else 0.0

            position['margin'] = round(margin, 2)
            position['unrealized_pnl'] = round(upnl, 4)
            position['unrealized_pnl_mark'] = round(upnl, 4)
            position['pnl_pct'] = round(pnl_pct, 2)
            position['leverage'] = leverage
            position['side'] = direction
            position['mark_price'] = mark_price

        return positions

