"""
Firebase Telemetry & Remote Control Client for TradeBot
Đồng bộ trạng thái Bot (Số dư, PnL, Lệnh mở) lên Firestore và nhận lệnh điều khiển từ xa từ Web.
"""

import threading
import time
import logging
import requests
import yaml
from pathlib import Path

logger = logging.getLogger(__name__)

class FirebaseTelemetrySync:
    def __init__(self, bot, project_id="trade-bot-platform", user_token="admin_local"):
        self.bot = bot
        self.project_id = project_id
        self.user_token = user_token
        self.running = False
        self.thread = None
        self.base_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents"
        
    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._sync_loop, daemon=True)
        self.thread.start()
        logger.info(f"🌐 [Firebase Cloud] Đã khởi chạy đồng bộ Telemetry lên Web (User: {self.user_token})")
        
    def stop(self):
        self.running = False
        
    def _sync_loop(self):
        while self.running:
            try:
                self._push_telemetry()
                self._pull_commands()
            except Exception as e:
                logger.debug(f"Firebase sync exception: {e}")
            time.sleep(15) # Đồng bộ mỗi 15 giây
            
    def _push_telemetry(self):
        """Đẩy số dư, PnL và số vị thế lên Firestore REST API."""
        try:
            balance = float(getattr(self.bot, 'balance', 42.98) or 42.98)
            daily_pnl = float(getattr(self.bot, 'daily_pnl', 0.5481) or 0.0)
            open_count = len(getattr(self.bot, 'open_positions', []) or [])
            max_trades = int(self.bot.config.get('trading', {}).get('max_open_trades', 2))
            is_active = bool(getattr(self.bot, 'is_running', True))
            
            payload = {
                "fields": {
                    "balance": {"doubleValue": balance},
                    "daily_pnl": {"doubleValue": daily_pnl},
                    "open_positions_count": {"integerValue": str(open_count)},
                    "max_open_trades": {"integerValue": str(max_trades)},
                    "is_running": {"booleanValue": is_active},
                    "updated_at": {"stringValue": time.strftime('%Y-%m-%d %H:%M:%S')}
                }
            }
            url = f"{self.base_url}/bots_telemetry/{self.user_token}"
            requests.patch(url, json=payload, timeout=5)
        except Exception as e:
            pass
            
    def _pull_commands(self):
        """Lắng nghe các lệnh điều khiển từ xa từ Web Dashboard."""
        try:
            url = f"{self.base_url}/bot_commands/{self.user_token}"
            res = requests.get(url, timeout=5)
            if res.status_code == 200:
                data = res.json().get('fields', {})
                status = data.get('status', {}).get('stringValue', '')
                if status == 'pending':
                    cmd = data.get('command', {}).get('stringValue', '')
                    logger.info(f"⚡ [Firebase Remote] Nhận được lệnh điều khiển từ Web: {cmd.upper()}")
                    self._execute_remote_command(cmd, data)
                    
                    # Đánh dấu đã thực thi
                    ack_payload = {
                        "fields": {
                            "status": {"stringValue": "executed"},
                            "executed_at": {"stringValue": time.strftime('%Y-%m-%d %H:%M:%S')}
                        }
                    }
                    requests.patch(url, json=ack_payload, timeout=5)
        except Exception as e:
            pass
            
    def _execute_remote_command(self, cmd, data):
        """Thực thi lệnh trên bot."""
        try:
            if cmd == 'start':
                if not getattr(self.bot, 'is_running', False):
                    self.bot.start()
            elif cmd == 'stop':
                if getattr(self.bot, 'is_running', False):
                    self.bot.stop()
            elif cmd == 'run_cycle':
                if hasattr(self.bot, 'run_cycle'):
                    threading.Thread(target=self.bot.run_cycle, daemon=True).start()
            elif cmd == 'emergency_close':
                if hasattr(self.bot, 'close_all_positions'):
                    self.bot.close_all_positions(reason="Remote Web Emergency Close")
            elif cmd == 'update_config':
                lev = data.get('max_leverage', {}).get('integerValue')
                trades = data.get('max_open_trades', {}).get('integerValue')
                if lev:
                    self.bot.config['trading']['max_leverage'] = int(lev)
                if trades:
                    self.bot.config['trading']['max_open_trades'] = int(trades)
                # Lưu vào settings.yaml
                cfg_path = Path("config/settings.yaml")
                if cfg_path.exists():
                    with open(cfg_path, 'w', encoding='utf-8') as f:
                        yaml.dump(self.bot.config, f, default_flow_style=False, allow_unicode=True)
                logger.info(f"✅ [Firebase Remote] Đã cập nhật cấu hình: Đòn bẩy trần={lev}x, Số lệnh trần={trades}")
        except Exception as e:
            logger.error(f"Lỗi thực thi lệnh từ xa: {e}")
