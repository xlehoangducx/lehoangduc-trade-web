import logging
import time as _time
from typing import List, Dict

logger = logging.getLogger(__name__)

class MarketScanner:
    """
    Quét toàn bộ thị trường để tìm ra các cặp giao dịch tiềm năng nhất.
    Quy trình: Tìm kiếm -> So sánh -> Chọn lọc danh sách ngắn.
    Hỗ trợ cơ chế kép (Dual-Engine): Crypto & TradFi Stock Perps (Biệt lập hoàn toàn).
    Hỗ trợ 3 chế độ:
    - Thuần Crypto (enabled=False, only_tradfi=False)
    - Cả Hai song song (enabled=True, only_tradfi=False)
    - Chỉ Cổ phiếu Mỹ (only_tradfi=True)
    """
    _insufficient_data_cooldowns: Dict[str, float] = {}

    @classmethod
    def mark_insufficient_data(cls, symbol: str, cooldown_seconds: float = 3600.0):
        """Cách ly tạm thời các hợp đồng mới lên sàn/thiếu nến lịch sử (như PREDICT/USDT) để không chiếm slot Top 50."""
        if not symbol:
            return
        clean = str(symbol).split(':')[0].replace('/', '').strip().upper()
        cls._insufficient_data_cooldowns[clean] = _time.time() + cooldown_seconds

    @classmethod
    def is_insufficient_data_cooled(cls, symbol: str) -> bool:
        if not symbol:
            return False
        clean = str(symbol).split(':')[0].replace('/', '').strip().upper()
        exp = cls._insufficient_data_cooldowns.get(clean, 0.0)
        if exp > 0 and _time.time() < exp:
            return True
        if exp > 0:
            cls._insufficient_data_cooldowns.pop(clean, None)
        return False
    KNOWN_TRADFI_BASES = {
        'AAOI', 'AAPL', 'ACN', 'ADBE', 'AGPU', 'AKAM', 'ALAB', 'ALL', 'AMAT', 'AMC', 'AMD', 'AMZN', 'ANET',
        'ANTHROPIC', 'APLD', 'APP', 'ARM', 'ASML', 'ASTS', 'AVGO', 'AXTI', 'BABA', 'BBX', 'BE', 'BITO',
        'BMNR', 'BNC', 'BOT', 'BRKB', 'BSP', 'BTCDOM', 'BWET', 'BX', 'BYD', 'BZ', 'CAT', 'CBRS', 'CIEN',
        'CL', 'COHR', 'COIN', 'COPPER', 'COST', 'CRCL', 'CRDO', 'CRM', 'CRML', 'CRWD', 'CRWV', 'CSCO',
        'CSOPSAMSUNG2L', 'CSOPSKHYNIX2L', 'CVNA', 'CXMT', 'CYPH', 'DDOG', 'DEFI', 'DELL', 'DIS', 'DJT',
        'DKNG', 'DRAM', 'EBAY', 'EWJ', 'EWT', 'EWY', 'EWZ', 'FLEX', 'FLNC', 'FWDI', 'GDX', 'GEV',
        'GIGADEV', 'GLW', 'GME', 'GOOGL', 'GPRO', 'GS', 'GTLB', 'HANMI', 'HD', 'HIMS', 'HK0625', 'HK0700',
        'HK0992', 'HK1810', 'HOOD', 'HPE', 'HUT', 'HYUNDAI', 'IBM', 'INTC', 'INTW', 'IONQ', 'IREN', 'IWM',
        'JPM', 'KLAC', 'KO', 'KODEX200', 'KORU', 'KSTR', 'KUAISHOU', 'LGELECTRONICS', 'LITE', 'LLY', 'LRCX',
        'LYTE', 'MARA', 'MCD', 'MDB', 'MEITUAN', 'META', 'MINIMAX', 'MOONSHOT', 'MP', 'MRK', 'MRNA', 'MRVL',
        'MSFT', 'MSTR', 'MSTU', 'MU', 'MUU', 'MVLL', 'NATGAS', 'NAVER', 'NBIS', 'NET', 'NFLX', 'NKE', 'NOK',
        'NOW', 'NVDA', 'NVDL', 'NVO', 'OKLO', 'ON', 'ONDS', 'OPENAI', 'ORCL', 'OURA', 'PANW', 'PATH', 'PAYP',
        'PDD', 'PENG', 'PLTR', 'POPMART', 'PYPL', 'QCOM', 'QNTX', 'QQQ', 'RAM', 'RDDT', 'RDW', 'RIVN',
        'RKLB', 'RUM', 'SAMSUNG', 'SAMSUNGEM', 'SECZ', 'SHAZ', 'SHOP', 'SKDD', 'SKHY', 'SKHYNIX', 'SKUU',
        'SMCI', 'SMH', 'SNDK', 'SNOW', 'SNPS', 'SNXX', 'SOFI', 'SONY', 'SOXL', 'SOXS', 'SPCX', 'SPY',
        'SQQQ', 'STRC', 'STXX', 'TBT', 'TEAM', 'TEM', 'TENCENT', 'TER', 'TMF', 'TQQQ', 'TSLA', 'TSLL',
        'TSM', 'TTWO', 'TWST', 'TXN', 'TZA', 'UBER', 'UNH', 'UNITREE', 'URNM', 'USAR', 'USDBRL', 'USDEX',
        'UVXY', 'V', 'VKTX', 'VRT', 'VST', 'WDC', 'WEN', 'WMT', 'XAG', 'XAU', 'XBI', 'XLE', 'XOM',
        'XPD', 'XPT', 'ZCSH', 'ZHIPU', 'ZHONGJI', 'ZM', 'ZS'
    }

    # Danh mục cơ sở Hàng hóa Toàn diện (Precious Metals, Energy, Industrial Metals, Agriculture)
    KNOWN_COMMODITY_BASES = {
        # Kim loại quý (Precious Metals)
        'XAU', 'GOLD', 'PAXG',
        'XAG', 'SILVER',
        'XPT', 'PLATINUM', 'PLAT',
        'XPD', 'PALLADIUM', 'PALL',
        # Năng lượng & Dầu khí (Energy & Petroleum)
        'CL', 'CRUDE', 'OIL', 'WTI',
        'BZ', 'BRENT',
        'NATGAS', 'NG', 'GAS_US',
        # Kim loại công nghiệp (Industrial Metals)
        'COPPER', 'CPR',
        'ALUMINIUM', 'ALU', 'ALI',
        'NICKEL', 'NI',
        'ZINC', 'ZN',
        'LEAD', 'PB',
        'TIN', 'SN',
        'URANIUM', 'URA',
        # Nông sản & Hàng hóa mềm (Agriculture / Soft Commodities)
        'WHEAT', 'CORN', 'SOYBEAN', 'SOY',
        'SUGAR', 'COFFEE', 'COTTON', 'COCOA'
    }

    _default_exchange = None
    _last_markets_reload_ts = 0.0

    def __init__(self, exchange_connector):
        self.exchange = exchange_connector
        MarketScanner._default_exchange = exchange_connector

    @classmethod
    def is_tradfi_stock(cls, symbol: str, exchange=None) -> bool:
        """
        Kiểm tra xem cặp giao dịch có phải là Hợp đồng Cổ phiếu Mỹ / Chỉ số / ETF (TradFi Stock Perp) hay không.
        Tách biệt hoàn toàn với Hàng hóa TradFi (XAU, XAG, CL...) để Hàng hóa giao dịch 24/5 không bị khóa bởi phiên Wall Street.
        """
        if not symbol:
            return False
        clean = symbol.split(':')[0].upper()
        base = clean.split('/')[0] if '/' in clean else clean
        for q in ('USDT', 'USDC', 'BUSD', 'USD'):
            if base.endswith(q) and len(base) > len(q):
                base = base[:-len(q)]
                break

        # 0. Loại trừ ngay lập tức Hàng hóa TradFi (Vàng, Bạc, Dầu...) khỏi nhóm Cổ phiếu Mỹ
        if base in cls.KNOWN_COMMODITY_BASES:
            return False
        
        # 1. ƯU TIÊN KIỂM TRA ĐỘNG TỪ METADATA BINANCE FUTURES (Chuẩn xác 100% theo sàn)
        eff_exchange = exchange or getattr(cls, '_default_exchange', None)
        if eff_exchange and hasattr(eff_exchange, 'exchange'):
            ex = eff_exchange.exchange
            markets = getattr(ex, 'markets', {}) or {}
            markets_by_id = getattr(ex, 'markets_by_id', {}) or {}
            raw_id = clean.replace('/', '').replace(':', '')
            ccxt_sym = symbol if ':' in symbol else (f"{clean}:{clean.split('/')[1]}" if '/' in clean else f"{base}/USDT:USDT")
            
            m = (markets.get(ccxt_sym) or markets.get(clean) or 
                 markets.get(f"{base}/USDT:USDT") or markets.get(f"{base}/USDT") or 
                 markets_by_id.get(raw_id))
            if isinstance(m, list) and m:
                m = m[0]
            if not m and hasattr(ex, 'load_markets'):
                now_ts = _time.time()
                if now_ts - cls._last_markets_reload_ts > 300.0:
                    try:
                        ex.load_markets(reload=True)
                        cls._last_markets_reload_ts = now_ts
                        markets = getattr(ex, 'markets', {}) or {}
                        markets_by_id = getattr(ex, 'markets_by_id', {}) or {}
                        m = (markets.get(ccxt_sym) or markets.get(clean) or 
                             markets.get(f"{base}/USDT:USDT") or markets.get(f"{base}/USDT") or 
                             markets_by_id.get(raw_id))
                        if isinstance(m, list) and m:
                            m = m[0]
                    except Exception:
                        pass
            if m:
                info = m.get('info', {})
                underlying = str(info.get('underlyingType') or '').upper()
                contract = str(info.get('contractType') or '').upper()
                subtypes = [str(s).upper() for s in (info.get('underlyingSubType') or [])]
                if underlying == 'COMMODITY' or 'COMMODITY' in subtypes:
                    return False
                # Nhận diện động mọi loại Cổ phiếu Mỹ (EQUITY), Hồng Kông (HK_EQUITY), Hàn Quốc (KR_EQUITY), Trung Quốc (CN_EQUITY), Forex (FX), Tiền IPO (PREMARKET)
                if underlying in ('EQUITY', 'HK_EQUITY', 'KR_EQUITY', 'CN_EQUITY', 'FX', 'INDEX', 'PREMARKET') or 'TRADFI' in subtypes or contract == 'TRADIFI_PERPETUAL':
                    return True
                if underlying == 'COIN':
                    return False

        # 2. Khớp từ danh mục mã TradFi niêm yết trên Binance nếu không có exchange metadata
        if base in cls.KNOWN_TRADFI_BASES and base not in cls.KNOWN_COMMODITY_BASES:
            return True
        if base.endswith('B') and base[:-1] in cls.KNOWN_TRADFI_BASES and base[:-1] not in cls.KNOWN_COMMODITY_BASES:
            return True
            
        return False

    @classmethod
    def is_tradfi_commodity(cls, symbol: str, exchange=None) -> bool:
        """Kiểm tra xem có phải là hàng hóa TradFi (Vàng XAU, Dầu CL/BZ, Bạc XAG, Đồng COPPER, Gas NATGAS) hay không."""
        if not symbol:
            return False
        clean = symbol.split(':')[0].upper()
        base = clean.split('/')[0] if '/' in clean else clean
        for q in ('USDT', 'USDC', 'BUSD', 'USD'):
            if base.endswith(q) and len(base) > len(q):
                base = base[:-len(q)]
                break
        if base in cls.KNOWN_COMMODITY_BASES:
            return True
        eff_exchange = exchange or getattr(cls, '_default_exchange', None)
        if eff_exchange and hasattr(eff_exchange, 'exchange'):
            ex = eff_exchange.exchange
            markets = getattr(ex, 'markets', {}) or {}
            markets_by_id = getattr(ex, 'markets_by_id', {}) or {}
            raw_id = clean.replace('/', '').replace(':', '')
            ccxt_sym = symbol if ':' in symbol else (f"{clean}:{clean.split('/')[1]}" if '/' in clean else f"{base}/USDT:USDT")
            m = (markets.get(ccxt_sym) or markets.get(clean) or 
                 markets.get(f"{base}/USDT:USDT") or markets.get(f"{base}/USDT") or 
                 markets_by_id.get(raw_id))
            if isinstance(m, list) and m:
                m = m[0]
            if not m and hasattr(ex, 'load_markets'):
                now_ts = _time.time()
                if now_ts - cls._last_markets_reload_ts > 300.0:
                    try:
                        ex.load_markets(reload=True)
                        cls._last_markets_reload_ts = now_ts
                        markets = getattr(ex, 'markets', {}) or {}
                        markets_by_id = getattr(ex, 'markets_by_id', {}) or {}
                        m = (markets.get(ccxt_sym) or markets.get(clean) or 
                             markets.get(f"{base}/USDT:USDT") or markets.get(f"{base}/USDT") or 
                             markets_by_id.get(raw_id))
                        if isinstance(m, list) and m:
                            m = m[0]
                    except Exception:
                        pass
            if m:
                info = m.get('info', {})
                underlying = str(info.get('underlyingType') or '').upper()
                subtypes = [str(s).upper() for s in (info.get('underlyingSubType') or [])]
                if underlying == 'COMMODITY' or 'COMMODITY' in subtypes:
                    return True
        return False

    @staticmethod
    def is_us_market_open() -> bool:
        """
        Kiểm tra xem thị trường chứng khoán Mỹ (NYSE/NASDAQ) có đang mở cửa không.
        Giờ giao dịch chính thức: Thứ Hai đến Thứ Sáu, từ 09:30 đến 16:00 EST (New York).
        (Tương ứng ~20:30 đến 03:00 sáng hôm sau giờ Việt Nam).
        """
        try:
            import zoneinfo
            from datetime import datetime, time
            ny_tz = zoneinfo.ZoneInfo("America/New_York")
            now_ny = datetime.now(ny_tz)
            
            # 0 = Thứ Hai, ..., 4 = Thứ Sáu, 5 = Thứ Bảy, 6 = Chủ Nhật
            if now_ny.weekday() >= 5:
                return False
                
            market_open = time(9, 30)
            market_close = time(16, 0)
            current_time = now_ny.time()
            
            return market_open <= current_time < market_close
        except Exception as e:
            logger.warning("Không thể kiểm tra phiên thị trường Mỹ: %s", e)
            return False

    @staticmethod
    def is_us_weekend() -> bool:
        """
        Kiểm tra xem hiện tại có phải 2 ngày cuối tuần theo giờ New York (Thứ Bảy & Chủ Nhật) không.
        Dùng để chặn quét và mở vị thế Cổ phiếu mới vào cuối tuần do thanh khoản mỏng.
        """
        try:
            import zoneinfo
            from datetime import datetime
            ny_tz = zoneinfo.ZoneInfo("America/New_York")
            now_ny = datetime.now(ny_tz)
            return now_ny.weekday() >= 5
        except Exception as e:
            logger.warning("Không thể kiểm tra ngày cuối tuần Mỹ: %s", e)
            return False

    @staticmethod
    def is_weekend_gap_risk_window(symbol: str = None, exchange = None) -> bool:
        """
        Kiểm tra xem có đang trong khung giờ rủi ro gap giá cuối tuần không:
        - Với Hàng hóa TradFi (XAU, XAG, CL... - giao dịch 24/5 trên CME Globex):
          Chỉ đóng cửa từ 16:00 EST chiều Thứ Sáu đến 18:00 EST tối Chủ Nhật (05:00 sáng Thứ Hai VN).
          Sau 18:00 EST Chủ Nhật, CME Globex đã mở cửa bình thường -> Trả về False!
        - Với Cổ phiếu Mỹ (NVDA, TSLA, AAPL...):
          Từ 15:45 EST chiều Thứ Sáu cho đến 09:30 EST sáng Thứ Hai tuần kế tiếp.
        - Nếu bật weekend_close: Bot tự động chốt vị thế trước giờ đóng cửa.
        - Nếu bật weekend_shield (Hybrid): Bot kích hoạt bảo hiểm hòa vốn (Net Breakeven) cho lệnh đang có lãi.
        """
        try:
            import zoneinfo
            from datetime import datetime, time
            ny_tz = zoneinfo.ZoneInfo("America/New_York")
            now_ny = datetime.now(ny_tz)
            weekday = now_ny.weekday()
            current_time = now_ny.time()

            is_commodity = False
            if symbol:
                clean_sym = str(symbol).split(':')[0].strip().upper()
                clean_base = clean_sym.split('/')[0] if '/' in clean_sym else clean_sym
                is_commodity = MarketScanner.is_tradfi_commodity(clean_sym, exchange) or (clean_base in MarketScanner.KNOWN_COMMODITY_BASES)

            if is_commodity:
                # Thị trường hàng hóa (CME Globex): Nghỉ từ Thứ 6 16:00 EST đến Chủ Nhật 18:00 EST
                if weekday == 4 and current_time >= time(16, 0):
                    return True
                if weekday == 5: # Thứ 7 đóng cửa cả ngày
                    return True
                if weekday == 6 and current_time < time(18, 0): # Chủ Nhật trước 18:00 EST
                    return True
                return False

            # Cổ phiếu & ETF Mỹ (NYSE / NASDAQ): Nghỉ từ Thứ 6 15:45 EST đến Thứ 2 09:30 EST
            # Thứ Bảy (5) hoặc Chủ Nhật (6)
            if weekday in (5, 6):
                return True
            # Thứ Sáu sau 15:45 EST (sắp đóng cửa sàn Mỹ)
            if weekday == 4 and current_time >= time(15, 45):
                return True
            # Thứ Hai trước 09:30 EST (chưa mở cửa)
            if weekday == 0 and current_time < time(9, 30):
                return True
                
            return False
        except Exception as e:
            logger.warning("Không thể kiểm tra khung giờ gap risk cuối tuần: %s", e)
            return False

    def get_potential_pairs(self, limit: int = 10, min_volume: float = 3000000) -> List[str]:
        """
        Quét tất cả các cặp giao dịch, lọc và sắp xếp theo tiềm năng.
        Tiềm năng = Độ biến động (Volatility) + Volume lớn.
        Hỗ trợ phân loại:
        - only_tradfi=True -> Chỉ lấy Cổ phiếu Mỹ, bỏ qua 100% Crypto
        - enabled=True -> Lấy cả Crypto và Cổ phiếu Mỹ song song
        - enabled=False -> Thuần Crypto
        """
        try:
            logger.info("🔍 Đang quét toàn bộ thị trường để tìm cơ hội...")
            market_type = getattr(self.exchange, 'market_type', 'spot')
            tradfi_cfg = getattr(self.exchange, 'config', {}).get('tradfi', {})
            tradfi_enabled = bool(tradfi_cfg.get('enabled', False))
            only_tradfi = bool(tradfi_cfg.get('only_tradfi', False))
            session_filter = bool(tradfi_cfg.get('session_filter', True))
            tradfi_min_vol = float(tradfi_cfg.get('min_volume', 3000000))
            us_market_active = self.is_us_market_open()
            
            try:
                tickers = self.exchange.exchange.fetch_tickers()
            except Exception as e:
                if 'does not support' in str(e) or 'fetchTickers' in str(e):
                    if self.exchange.exchange_id == 'binance' and market_type == 'futures':
                        # Gọi raw API của Binance Futures
                        raw = self.exchange.exchange.fapiPublicGetTicker24hr()
                        tickers = {}
                        for t in raw:
                            base_curr = self.exchange.config.get('trading', {}).get('base_currency', 'USDT')
                            if t['symbol'].endswith(base_curr):
                                s = t['symbol'][:-len(base_curr)] + f'/{base_curr}:{base_curr}'
                                tickers[s] = {
                                    'quoteVolume': float(t['quoteVolume']),
                                    'percentage': float(t['priceChangePercent'])
                                }
                    else:
                        raise e
                else:
                    raise e
            
            potential_pairs = []
            
            for symbol, ticker in tickers.items():
                # Lọc cặp USDT
                base_curr = self.exchange.config.get('trading', {}).get('base_currency', 'USDT')
                if f'/{base_curr}' not in symbol:
                    continue
                # Nếu là futures, ccxt format thường là XXX/USDT:USDT
                if market_type == 'futures' and ':' not in symbol:
                    continue
                    
                # Bỏ qua stable coins & tokens rác & các mã đang bị cách ly do mới niêm yết chưa đủ nến lịch sử
                base_coin = symbol.split('/')[0]
                if base_coin in ['USDC', 'TUSD', 'BUSD', 'FDUSD', 'EUR', 'USDP']:
                    continue
                if 'DOWN' in base_coin or 'UP' in base_coin or 'BEAR' in base_coin or 'BULL' in base_coin:
                    continue
                if self.is_insufficient_data_cooled(symbol):
                    continue

                # Phân lập TradFi Cổ Phiếu vs Crypto
                is_commodity = self.is_tradfi_commodity(symbol, self.exchange)
                is_stock_pure = self.is_tradfi_stock(symbol, self.exchange) and not is_commodity
                is_stock = is_stock_pure or is_commodity
                
                # 1. Chế độ CHỈ CỔ PHIẾU MỸ (ONLY TRADFI):
                if only_tradfi:
                    if not is_stock:
                        # Bỏ qua 100% Crypto
                        continue
                    if self.is_weekend_gap_risk_window(symbol, self.exchange):
                        # Chặn theo lịch riêng của từng tài sản: CME cho hàng hóa, NYSE/NASDAQ cho cổ phiếu.
                        continue
                    # Chỉ áp dụng lọc phiên Wall Street cho Cổ phiếu Mỹ; Hàng hóa giao dịch 24/5 liên tục:
                    if is_stock_pure and session_filter and not us_market_active:
                        # Ngoài giờ Wall Street -> Bỏ qua cổ phiếu
                        continue
                    vol_threshold = tradfi_min_vol

                # 2. Chế độ BẬT CẢ HAI (DUAL) hoặc CHỈ CRYPTO:
                else:
                    if is_stock:
                        if not tradfi_enabled:
                            # Nút TradFi đang TẮT -> Bỏ qua 100% cổ phiếu để đảm bảo bot thuần crypto
                            continue
                        if self.is_weekend_gap_risk_window(symbol, self.exchange):
                            # Lịch gap theo tài sản; hàng hóa được phép quét lại sau khi CME mở cửa.
                            continue
                        # Chỉ áp dụng lọc phiên Wall Street cho Cổ phiếu Mỹ; Hàng hóa giao dịch 24/5 liên tục:
                        if is_stock_pure and session_filter and not us_market_active:
                            # Thị trường Mỹ đang đóng cửa -> Bỏ qua cổ phiếu
                            continue
                        vol_threshold = tradfi_min_vol
                    else:
                        vol_threshold = min_volume

                vol = ticker.get('quoteVolume', 0)
                if vol is None or vol < vol_threshold:
                    continue

                if is_stock:
                    max_change_pct = float(self.exchange.config.get('risk', {}).get('max_24h_change_pct', 12.0))
                else:
                    max_change_pct = float(self.exchange.config.get('risk', {}).get('max_crypto_24h_change_pct', 12.0))
                raw_pct = ticker.get('percentage', 0) or 0
                change_pct = abs(float(raw_pct))
                if change_pct > max_change_pct:
                    continue
                
                potential_pairs.append({
                    'symbol': symbol,
                    'change': change_pct,
                    'volume': vol
                })
            
            # Sắp xếp theo độ biến động và volume
            potential_pairs.sort(key=lambda x: (x['volume'] / 100000000 * 0.6) + (min(x['change'], 8.0) * 0.4), reverse=True)
            
            # Lấy top N
            top_pairs = potential_pairs[:limit]
            
            # Đổi lại format chuẩn (bỏ :USDT) để truyền vào data_collector
            final_symbols = []
            for p in top_pairs:
                sym = p['symbol']
                if ':' in sym:
                    sym = sym.split(':')[0]
                final_symbols.append(sym)
                
            if only_tradfi:
                logger.info(f"✅ [CHẾ ĐỘ CHỈ CỔ PHIẾU] Đã chọn Top {len(final_symbols)} mã tiềm năng: {', '.join(final_symbols)}")
            elif tradfi_enabled:
                logger.info(f"✅ [CƠ CHẾ KÉP CRYPTO + CỔ PHIẾU] Đã chọn Top {len(final_symbols)} mã tiềm năng: {', '.join(final_symbols)}")
            else:
                logger.info(f"✅ [CHẾ ĐỘ THUẦN CRYPTO] Đã chọn Top {len(final_symbols)} coin tiềm năng: {', '.join(final_symbols)}")

            return final_symbols
            
        except Exception as e:
            logger.error(f"Lỗi khi quét thị trường: {e}")
            return []
