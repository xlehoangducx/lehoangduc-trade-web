import logging
import ccxt
import pandas as pd
import time
import sys
from functools import wraps
from typing import Optional, Dict, Any, List

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

logger = logging.getLogger(__name__)

def retry_api_call(max_retries=3, backoff_factor=1.5):
    """Decorator to retry API calls on network, rate limit, or Binance timestamp/recvWindow errors."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except (ccxt.NetworkError, ccxt.RequestTimeout, ccxt.RateLimitExceeded) as e:
                    retries += 1
                    if retries == max_retries:
                        logger.error(f"API failed after {max_retries} retries: {func.__name__} - {e}")
                        raise
                    sleep_time = backoff_factor ** retries
                    logger.warning(f"API error in {func.__name__}: {e}. Retrying in {sleep_time:.2f}s (Attempt {retries}/{max_retries})")
                    time.sleep(sleep_time)
                except Exception as e:
                    err_str = str(e).lower()
                    is_time_desync = (
                        isinstance(e, getattr(ccxt, 'InvalidNonce', Exception)) or
                        "-1021" in str(e) or
                        "timestamp for this request" in err_str or
                        "outside of the recvwindow" in err_str or
                        "ahead of the server's time" in err_str
                    )
                    if is_time_desync and retries < max_retries:
                        retries += 1
                        logger.warning(
                            f"⏱️ Phát hiện lệch giờ API Binance (-1021) trong {func.__name__}: {e}. "
                            f"Đang tự động đồng bộ thời gian với sàn và thử lại (Lần {retries}/{max_retries})..."
                        )
                        connector = args[0] if (args and hasattr(args[0], 'sync_time')) else None
                        if connector:
                            connector.sync_time()
                        elif args and hasattr(args[0], 'exchange') and hasattr(args[0].exchange, 'load_time_difference'):
                            try:
                                args[0].exchange.load_time_difference()
                            except Exception:
                                pass
                        time.sleep(0.5)
                        continue

                    # Don't retry logic errors or insufficient funds
                    logger.error(f"API fatal error in {func.__name__}: {e}")
                    raise
        return wrapper
    return decorator

import os
from pathlib import Path
from dotenv import load_dotenv
try:
    _env_f = Path(__file__).resolve().parent.parent / '.env'
    if _env_f.exists():
        load_dotenv(_env_f)
except Exception:
    pass

class ExchangeConnector:
    """
    Kết nối sàn giao dịch - Hỗ trợ Spot và Futures.
    Supports: Binance Spot, Binance USDT-M Futures, Bybit, OKX
    """
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        
        # Luôn load API keys từ .env
        try:
            _env_f = Path(__file__).resolve().parent.parent / '.env'
            if _env_f.exists():
                load_dotenv(_env_f)
        except Exception:
            pass
        
        # Read config
        exchange_config = config.get('exchange', {})
        self.exchange_id = exchange_config.get('name', 'binance')
        self.api_key = str(os.getenv('BINANCE_API_KEY', exchange_config.get('api_key', '')) or '').strip("'\" \t\r\n")
        self.secret = str(os.getenv('BINANCE_API_SECRET', exchange_config.get('api_secret', '')) or '').strip("'\" \t\r\n")
        self.testnet = exchange_config.get('testnet', True)
        
        # NEW: Market type - spot or futures
        trading_config = config.get('trading', {})
        self.market_type = trading_config.get('market_type', 'futures')  # Default to futures for low capital
        self.default_leverage = trading_config.get('leverage', 5)
        self.margin_type = trading_config.get('margin_type', 'isolated')  # isolated or cross
        self._leverage_tiers_cache = {}
        self._leverage_tiers_cache_ttl = 900
        
        # Initialize exchange
        exchange_class = getattr(ccxt, self.exchange_id)
        self.exchange = exchange_class({
            'apiKey': self.api_key,
            'secret': self.secret,
            'enableRateLimit': True,
            'timeout': exchange_config.get('timeout', 30000),
            'options': {
                'defaultType': 'future' if self.market_type == 'futures' else self.market_type,
                'adjustForTimeDifference': exchange_config.get('adjust_for_time_difference', True)
                if self.exchange_id == 'binance' else False,
                'recvWindow': 60000,  # 60s tolerance (Binance max) to eliminate network lag and clock drift errors
                'fetchOpenOrders': {'warnWithoutSymbol': False},
            }
        })
        
        # Increase connection pool to support multi-thread parallel scanner (up to 45 concurrent MTF requests)
        import requests
        from requests.adapters import HTTPAdapter
        import logging
        logging.getLogger("urllib3").setLevel(logging.ERROR)
        logging.getLogger("urllib3.connectionpool").setLevel(logging.ERROR)
        session = requests.Session()
        adapter = HTTPAdapter(pool_connections=100, pool_maxsize=100)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        self.exchange.session = session
        
        if self.testnet:
            self.exchange.set_sandbox_mode(True)
            logger.info(f'ExchangeConnector: {self.exchange_id} Testnet ({self.market_type.upper()})')
        else:
            logger.info(f'ExchangeConnector: {self.exchange_id} LIVE ({self.market_type.upper()})')
    
    def sync_time(self) -> bool:
        """
        Tự động đo và bù trừ sai lệch thời gian (timeDifference) với Binance.
        Triệt tiêu 100% lỗi Binance API code -1021 ('Timestamp for this request...').
        Đồng thời cố gắng kích hoạt đồng bộ Windows clock ở nền nếu có thể.
        """
        try:
            if getattr(self.exchange, 'options', {}).get('adjustForTimeDifference', False) and hasattr(self.exchange, 'load_time_difference'):
                diff = self.exchange.load_time_difference()
                logger.info(f"⏱️ Đã đồng bộ sai lệch thời gian với Binance (Offset: {diff}ms)")
            else:
                self.exchange.fetch_time()
            self._try_resync_system_clock()
            return True
        except Exception as e:
            logger.warning(f"⚠️ Không thể đồng bộ sai lệch thời gian sàn: {e}")
            return False

    def _try_resync_system_clock(self):
        """Kích hoạt đồng bộ nhẹ đồng hồ Windows ở nền (non-blocking)."""
        import platform
        if platform.system() == 'Windows':
            try:
                import subprocess
                subprocess.Popen(
                    ['w32tm', '/resync', '/nowait'],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
                )
            except Exception:
                pass

    def sign_tradfi_agreement_if_needed(self) -> bool:
        """Tự động ký thỏa thuận TradFi-Perps (Stock/ETF perps) với Binance qua API khi cần."""
        if self.exchange_id != 'binance' or getattr(self, 'testnet', False):
            return False
        try:
            import requests, hmac, hashlib
            server_time = int(self.exchange.fetch_time())
            url = 'https://fapi.binance.com/fapi/v1/stock/contract'
            params = f'timestamp={server_time}&recvWindow=60000'
            sig = hmac.new(self.secret.encode('utf-8'), params.encode('utf-8'), hashlib.sha256).hexdigest()
            headers = {'X-MBX-APIKEY': self.api_key}
            r = requests.post(f'{url}?{params}&signature={sig}', headers=headers, timeout=10)
            if r.status_code == 200 or 'SUCCESS' in r.text:
                logger.info("📝 [TỰ ĐỘNG KÝ THỎA THUẬN] Đã tự động ký hợp đồng TradFi-Perps thành công với Binance!")
                return True
            else:
                logger.debug(f"Thử ký TradFi-Perps trả về: {r.status_code} - {r.text}")
                return False
        except Exception as e:
            logger.debug(f"Lỗi tự động ký thỏa thuận TradFi-Perps: {e}")
            return False

    def connect(self) -> bool:
        try:
            # Đồng bộ thời gian trước khi gọi bất kỳ API nào
            self.sync_time()
            self.exchange.load_markets()
            # Set leverage for futures pairs if in futures mode
            if self.market_type == 'futures':
                max_lev = self.config.get('trading', {}).get('max_leverage', self.default_leverage)
                logger.info(f'Futures mode: Leverage mac dinh={self.default_leverage}x (Tran dong Web={max_lev}x), Margin={self.margin_type}')
                # Tự động ký thỏa thuận TradFi-Perps để đảm bảo không bao giờ bị lỗi -4411
                if self.exchange_id == 'binance':
                    self.sign_tradfi_agreement_if_needed()
            return True
        except Exception as e:
            logger.error(f'Connection error: {e}')
            return False

    def check_connection(self) -> bool:
        """Kiểm tra kết nối và làm mới sai lệch thời gian định kỳ."""
        return self.sync_time()
    
    def _get_ccxt_symbol(self, symbol: str) -> str:
        """Chuyển đổi symbol cho phù hợp với yêu cầu của sàn (VD: Binance Futures cần thêm :USDT)."""
        if self.market_type == 'futures' and self.exchange_id == 'binance':
            if ':' not in symbol:
                base, quote = symbol.split('/')
                return f"{symbol}:{quote}"
        return symbol

    def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set leverage for a futures symbol."""
        if self.market_type != 'futures':
            logger.warning('set_leverage only works in futures mode')
            return False
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            self.exchange.set_leverage(leverage, ccxt_symbol)
            logger.info(f'Leverage set to {leverage}x for {symbol}')
            return True
        except Exception as e:
            logger.error(f'Error setting leverage for {symbol}: {e}')
            return False
    
    def set_margin_type(self, symbol: str, margin_type: str = 'isolated') -> bool:
        """Set margin type: 'isolated' or 'cross'."""
        if self.market_type != 'futures':
            return False
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            self.exchange.set_margin_mode(margin_type, ccxt_symbol)
            logger.info(f'Margin type set to {margin_type} for {symbol}')
            return True
        except ccxt.MarginModeAlreadySet:
            return True  # Already set, no problem
        except Exception as e:
            logger.error(f'Error setting margin type: {e}')
            return False
    
    def setup_futures_pair(self, symbol: str, leverage: int = None) -> bool:
        """Setup a futures pair with leverage and margin type."""
        lev = leverage or self.default_leverage
        margin_ok = self.set_margin_type(symbol, self.margin_type)
        leverage_ok = self.set_leverage(symbol, lev)
        return margin_ok and leverage_ok

    def get_max_leverage(self, symbol: str, notional: float = 0) -> Dict[str, Any]:
        """Return the verified leverage cap for a symbol at the requested notional.

        Binance leverage brackets are account-specific and vary with position
        notional. Cache the bracket response, then select the matching tier for
        each requested notional. Public market limits are used only when CCXT
        exposes an explicit leverage maximum.
        """
        ccxt_symbol = self._get_ccxt_symbol(symbol)
        market_max = None
        try:
            market = self.exchange.market(ccxt_symbol)
            market_max = market.get('limits', {}).get('leverage', {}).get('max')
            market_max = int(float(market_max)) if market_max is not None else None
            if market_max is not None and market_max < 1:
                market_max = None
        except Exception:
            market_max = None

        now = time.monotonic()
        cached = self._leverage_tiers_cache.get(ccxt_symbol)
        if cached is None or now - cached['time'] >= cached.get('ttl', self._leverage_tiers_cache_ttl):
            tiers = []
            lookup_error = None
            fetch_tiers = getattr(self.exchange, 'fetch_leverage_tiers', None)
            if self.market_type == 'futures' and callable(fetch_tiers):
                try:
                    # Binance returns every contract bracket when `symbol` is
                    # omitted. Reuse that one account-scoped response for all
                    # symbols instead of requesting it again for each pair.
                    response = fetch_tiers() or {}
                    for returned_symbol, returned_tiers in response.items():
                        if returned_tiers:
                            self._leverage_tiers_cache[returned_symbol] = {
                                'time': now,
                                'ttl': self._leverage_tiers_cache_ttl,
                                'tiers': returned_tiers,
                                'error': None,
                            }
                    tiers = response.get(ccxt_symbol) or []
                    if not tiers:
                        tiers = next(
                            (value for value in response.values()
                             if value and value[0].get('symbol') == ccxt_symbol),
                            [],
                        )
                    tiers = [
                        tier for tier in tiers
                        if isinstance(tier, dict)
                        and float(tier.get('maxLeverage') or 0) >= 1
                    ]
                    if not tiers:
                        lookup_error = 'Binance did not return leverage tiers for this symbol'
                except Exception as e:
                    lookup_error = str(e)
            else:
                lookup_error = 'Exchange does not provide futures leverage tiers'

            ttl = self._leverage_tiers_cache_ttl if tiers else 30
            cached = {
                'time': now,
                'ttl': ttl,
                'tiers': tiers,
                'error': lookup_error,
            }
            self._leverage_tiers_cache[ccxt_symbol] = cached
            if lookup_error and not market_max:
                logger.warning('Cannot verify maximum leverage for %s: %s', symbol, lookup_error)

        tiers = cached['tiers']
        requested_notional = max(0.0, float(notional or 0))
        if tiers:
            ordered = sorted(
                tiers,
                key=lambda tier: float(tier.get('minNotional') or 0),
            )
            selected_tier = ordered[0] if requested_notional < float(ordered[0].get('minNotional') or 0) else ordered[-1]
            for tier in ordered:
                floor = float(tier.get('minNotional') or 0)
                cap = float(tier.get('maxNotional') or 0)
                if requested_notional >= floor and (cap <= 0 or requested_notional <= cap):
                    selected_tier = tier
                    break
            pair_max = int(float(selected_tier['maxLeverage']))
            if market_max is not None:
                pair_max = min(pair_max, market_max)
            return {
                'max_leverage': max(1, pair_max),
                'verified': True,
                'source': 'account_leverage_brackets',
                'notional': requested_notional,
                'error': None,
            }

        if market_max is not None:
            return {
                'max_leverage': market_max,
                'verified': True,
                'source': 'market_limits',
                'notional': requested_notional,
                'error': cached['error'],
            }

        return {
            'max_leverage': None,
            'verified': False,
            'source': 'unavailable',
            'notional': requested_notional,
            'error': cached['error'],
        }
    
    @retry_api_call()
    def get_balance(self) -> Dict[str, Any]:
        """Lấy số dư tài khoản."""
        try:
            balance = self.exchange.fetch_balance()
            return balance
        except Exception as e:
            logger.error(f"Lỗi lấy số dư: {str(e)}")
            return {}

    @retry_api_call()
    def get_ticker(self, symbol: str) -> Dict[str, Any]:
        """Lấy giá hiện tại của một mã."""
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            ticker = self.exchange.fetch_ticker(ccxt_symbol)
            return ticker
        except Exception as e:
            logger.error(f"Lỗi lấy giá {symbol}: {str(e)}")
            return {}

    @retry_api_call()
    def get_live_prices(self, symbols: List[str]) -> Dict[str, float]:
        """Lấy giá hiện tại cho nhiều cặp."""
        prices = {}
        for symbol in symbols:
            try:
                ccxt_sym = self._get_ccxt_symbol(symbol)
                ticker = self.exchange.fetch_ticker(ccxt_sym)
                if ticker and 'last' in ticker:
                    prices[symbol] = ticker['last']
            except Exception as e:
                logger.debug("Lỗi lấy giá đơn lẻ %s: %s", symbol, e)
        return prices

    @retry_api_call()
    def get_ohlcv(self, symbol: str, timeframe: str, limit: int = 500) -> pd.DataFrame:
        """Lấy dữ liệu nến (OHLCV)."""
        ohlcv = self.exchange.fetch_ohlcv(self._get_ccxt_symbol(symbol), timeframe, limit=limit)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)
        return df

    def _format_precision(self, symbol: str, amount: float, price: Optional[float] = None, reduce_only: bool = False):
        """
        Format amount và price theo quy chuẩn precision của sàn.
        Tránh lỗi LOT_SIZE, PRICE_FILTER, MIN_NOTIONAL từ Binance.
        reduce_only: True khi là lệnh đóng vị thế / cắt lỗ / chốt lời.
        Binance Futures chính thức MIỄN TRỪ bộ lọc MIN_NOTIONAL cho các lệnh reduceOnly.
        """
        try:
            symbol = self._get_ccxt_symbol(symbol)
            # Format amount theo stepSize của sàn
            amount = float(self.exchange.amount_to_precision(symbol, amount))
            
            # Format price theo tickSize của sàn
            if price is not None:
                price = float(self.exchange.price_to_precision(symbol, price))
            
            # Kiểm tra min notional (giá trị tối thiểu của lệnh mở mới)
            # Các lệnh reduce_only (cắt lỗ, chốt lời, đóng vị thế) được Binance Futures miễn trừ
            if not reduce_only:
                market = self.exchange.market(symbol)
                min_cost = market.get('limits', {}).get('cost', {}).get('min', 0)
                if min_cost and price and (amount * price) < min_cost:
                    logger.warning(f"Giá trị lệnh {amount * price:.2f} < min notional {min_cost}. Bỏ qua.")
                    return 0.0, price
            
            market = self.exchange.market(symbol)
            min_amount = market.get('limits', {}).get('amount', {}).get('min', 0)
            if min_amount and amount < min_amount:
                logger.warning(f"Số lượng {amount} < min amount {min_amount}. Bỏ qua.")
                return 0.0, price
                
            return amount, price
        except Exception as e:
            logger.warning(f"Không thể format precision cho {symbol}: {e}. Dùng giá trị gốc.")
            return amount, price
    @retry_api_call()
    def create_buy_order(self, symbol: str, amount: float, price: Optional[float] = None, order_type: str = 'limit', reduce_only: bool = False) -> Dict[str, Any]:
        """Tạo lệnh mua."""
        try:
            # Format precision theo quy chuẩn sàn
            amount, price = self._format_precision(symbol, amount, price, reduce_only=reduce_only)
            if amount <= 0:
                logger.warning(f"Amount sau format = 0, bỏ qua lệnh mua {symbol}")
                return {}
            
            if order_type == 'limit':
                if price is None:
                    raise ValueError("Lệnh limit cần có giá.")
                order = self.exchange.create_limit_buy_order(symbol, amount, price)
            elif order_type == 'market':
                order = self.exchange.create_market_buy_order(symbol, amount)
            else:
                raise ValueError(f"Loại lệnh không được hỗ trợ: {order_type}")
            
            logger.info(f"Đã tạo lệnh mua {order_type} {symbol}: {amount} @ {price if price else 'MARKET'}")
            return order
        except ccxt.InsufficientFunds as e:
            logger.error(f"Không đủ tiền mua {symbol}: {str(e)}")
            return {}
        except ccxt.InvalidOrder as e:
            logger.error(f"Lệnh mua không hợp lệ {symbol}: {str(e)}")
            return {}
        except Exception as e:
            logger.error(f"Lỗi tạo lệnh mua {symbol}: {str(e)}")
            return {}

    @retry_api_call()
    def create_sell_order(self, symbol: str, amount: float, price: Optional[float] = None, order_type: str = 'limit', reduce_only: bool = False) -> Dict[str, Any]:
        """Tạo lệnh bán."""
        try:
            # Format precision theo quy chuẩn sàn
            amount, price = self._format_precision(symbol, amount, price, reduce_only=reduce_only)
            if amount <= 0:
                logger.warning(f"Amount sau format = 0, bỏ qua lệnh bán {symbol}")
                return {}
            
            if order_type == 'limit':
                if price is None:
                    raise ValueError("Lệnh limit cần có giá.")
                order = self.exchange.create_limit_sell_order(symbol, amount, price)
            elif order_type == 'market':
                order = self.exchange.create_market_sell_order(symbol, amount)
            else:
                raise ValueError(f"Loại lệnh không được hỗ trợ: {order_type}")
            
            logger.info(f"Đã tạo lệnh bán {order_type} {symbol}: {amount} @ {price if price else 'MARKET'}")
            return order
        except ccxt.InsufficientFunds as e:
            logger.error(f"Không đủ coin bán {symbol}: {str(e)}")
            return {}
        except ccxt.InvalidOrder as e:
            logger.error(f"Lệnh bán không hợp lệ {symbol}: {str(e)}")
            return {}
        except Exception as e:
            logger.error(f"Lỗi tạo lệnh bán {symbol}: {str(e)}")
            return {}

    @retry_api_call()
    def cancel_order(
        self, order_id: str, symbol: str, trigger: bool = False, strict: bool = False
    ) -> Dict[str, Any]:
        """Hủy một lệnh."""
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            params = {'trigger': True} if trigger else {}
            result = self.exchange.cancel_order(order_id, ccxt_symbol, params=params)
            logger.info(f"Đã hủy lệnh {order_id} cho {symbol}")
            return result
        except Exception as e:
            logger.error(f"Lỗi hủy lệnh {order_id} {symbol}: {str(e)}")
            if strict:
                raise
            return {}

    @retry_api_call()
    def get_open_orders(
        self, symbol: Optional[str] = None, trigger: bool = False, strict: bool = False
    ) -> List[Dict[str, Any]]:
        """Lấy danh sách các lệnh đang mở."""
        try:
            if symbol:
                ccxt_symbol = self._get_ccxt_symbol(symbol)
            else:
                ccxt_symbol = None
                if hasattr(self.exchange, 'options') and isinstance(self.exchange.options, dict):
                    self.exchange.options.setdefault('fetchOpenOrders', {})['warnWithoutSymbol'] = False
            params = {'trigger': True} if trigger else {}
            orders = self.exchange.fetch_open_orders(ccxt_symbol, params=params)
            return orders
        except Exception as e:
            logger.error(f"Lỗi lấy lệnh mở: {str(e)}")
            if strict:
                raise
            return []

    @retry_api_call()
    def get_order_status(self, order_id: str, symbol: str) -> Dict[str, Any]:
        """Lấy trạng thái của một lệnh."""
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            order = self.exchange.fetch_order(order_id, ccxt_symbol)
            return order
        except Exception as e:
            logger.error(f"Lỗi lấy trạng thái lệnh {order_id}: {str(e)}")
            return {}

    def get_futures_positions(self, symbol: str = None) -> List[Dict]:
        """Get open futures positions."""
        if self.market_type != 'futures':
            return []
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol) if symbol else None
            positions = self.exchange.fetch_positions([ccxt_symbol] if ccxt_symbol else None)
            # `contracts` is normally positive for both directions, while the
            # raw one-way Binance position amount is signed. Preserve either form.
            active = []
            for position in positions:
                info = position.get('info') or {}
                amount = abs(float(position.get('contracts') or 0))
                if amount <= 0:
                    amount = abs(float(info.get('positionAmt') or 0))
                if abs(float(amount or 0)) > 0:
                    active.append(position)
            return active
        except Exception as e:
            logger.error(f'Error fetching futures positions: {e}')
            raise
    
    def get_futures_balance(self) -> Dict[str, Any]:
        """Get futures account balance with margin info."""
        try:
            balance = self.exchange.fetch_balance()
            base_currency = self.config.get('trading', {}).get('base_currency', 'USDT')
            if self.market_type == 'futures':
                info = balance.get('info') or {}
                asset_info = next(
                    (asset for asset in (info.get('assets') or []) if asset.get('asset') == base_currency),
                    {},
                )

                def amount(value, fallback=None):
                    try:
                        return float(value)
                    except (TypeError, ValueError):
                        return fallback

                unified_total = amount((balance.get('total') or {}).get(base_currency))
                unified_free = amount((balance.get('free') or {}).get(base_currency))
                unified_used = amount((balance.get('used') or {}).get(base_currency))
                wallet_balance = amount(asset_info.get('walletBalance'))
                margin_balance = amount(asset_info.get('marginBalance'), unified_total)
                unrealized_pnl = amount(
                    asset_info.get('unrealizedProfit'),
                    (margin_balance - wallet_balance)
                    if margin_balance is not None and wallet_balance is not None
                    else 0.0,
                )
                available_balance = amount(asset_info.get('availableBalance'), unified_free)
                initial_margin = amount(asset_info.get('initialMargin'), unified_used)

                return {
                    # Binance's Futures marginBalance already includes unrealized PnL.
                    # Keep wallet, available, and margin values distinct so callers
                    # never reconstruct equity by adding the same PnL twice.
                    'total': margin_balance if margin_balance is not None else (unified_total or 0.0),
                    'free': available_balance if available_balance is not None else (unified_free or 0.0),
                    'used': initial_margin if initial_margin is not None else (unified_used or 0.0),
                    'wallet_balance': wallet_balance,
                    'margin_balance': margin_balance if margin_balance is not None else unified_total,
                    'unrealized_pnl': unrealized_pnl,
                    'available_balance': available_balance if available_balance is not None else unified_free,
                    'initial_margin': initial_margin if initial_margin is not None else unified_used,
                    'position_initial_margin': amount(asset_info.get('positionInitialMargin')),
                    'open_order_initial_margin': amount(asset_info.get('openOrderInitialMargin')),
                    'update_time': asset_info.get('updateTime') or info.get('updateTime'),
                    'info': info,
                }
            return balance
        except Exception as e:
            logger.error(f'Error fetching balance: {e}')
            return {}

    def create_stop_market_order(self, symbol: str, side: str, amount: float, stop_price: float) -> dict:
        try:
            amount, stop_price = self._format_precision(symbol, amount, stop_price, reduce_only=True)
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            params = {'stopPrice': stop_price, 'reduceOnly': True}
            return self.exchange.create_order(ccxt_symbol, 'STOP_MARKET', side, amount, None, params)
        except Exception as e:
            err_msg = str(e)
            if "-2021" in err_msg or "Order would immediately trigger" in err_msg:
                logger.warning(f"Lệnh STOP_MARKET cho {symbol} ({side} {amount} @ {stop_price}) không thể đặt vì giá thị trường đã vượt qua mức kích hoạt (-2021 Immediately Trigger).")
                return {'error': 'immediately_triggered', 'code': -2021, 'stop_price': stop_price}
            logger.error(f"Error creating stop market order: {e}")
            return {}

    def create_take_profit_market_order(self, symbol: str, side: str, amount: float, tp_price: float) -> dict:
        try:
            amount, tp_price = self._format_precision(symbol, amount, tp_price, reduce_only=True)
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            params = {'stopPrice': tp_price, 'reduceOnly': True}
            return self.exchange.create_order(ccxt_symbol, 'TAKE_PROFIT_MARKET', side, amount, None, params)
        except Exception as e:
            logger.error(f"Error creating take profit order: {e}")
            return {}
    
    def create_futures_order(self, symbol: str, side: str, amount: float, 
                              price: float = None, order_type: str = 'market',
                              reduce_only: bool = False, post_only: bool = False) -> Dict:
        """Create a futures order (long or short).
        side: 'buy' (open long / close short) or 'sell' (open short / close long)
        post_only: True to ensure Maker execution (GTX - Good Till Crossing)
        """
        try:
            amount, price = self._format_precision(symbol, amount, price, reduce_only=reduce_only)
            if amount <= 0:
                return {}
            
            params = {}
            if reduce_only:
                params['reduceOnly'] = True
            
            if post_only or order_type in ('maker', 'post_only'):
                params['timeInForce'] = 'GTX'
                order_type = 'limit'
            
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            if order_type == 'market':
                if side == 'buy':
                    order = self.exchange.create_market_buy_order(ccxt_symbol, amount, params=params)
                else:
                    order = self.exchange.create_market_sell_order(ccxt_symbol, amount, params=params)
            elif order_type == 'limit':
                if price is None:
                    raise ValueError('Limit order requires price')
                if side == 'buy':
                    order = self.exchange.create_limit_buy_order(ccxt_symbol, amount, price, params=params)
                else:
                    order = self.exchange.create_limit_sell_order(ccxt_symbol, amount, price, params=params)
            else:
                raise ValueError(f'Unsupported order type: {order_type}')
            
            order_tag = ' [POST-ONLY MAKER]' if post_only or params.get('timeInForce') == 'GTX' else ''
            logger.info(f'Futures {side.upper()} {order_type} {symbol}: {amount} @ {price or "MARKET"}{order_tag}')
            return order
        except ccxt.InsufficientFunds as e:
            logger.error(f'Insufficient funds: {e}')
            return {}
        except ccxt.InvalidOrder as e:
            err_str = str(e).lower()
            if "-4411" in str(e) or "tradfi-perps agreement" in err_str:
                logger.warning(f"📝 Phát hiện lỗi thỏa thuận TradFi-Perps (-4411) cho {symbol}. Đang tự động ký thỏa thuận và thử đặt lệnh lại...")
                if self.sign_tradfi_agreement_if_needed():
                    time.sleep(1.0)
                    try:
                        if order_type == 'market':
                            if side == 'buy':
                                return self.exchange.create_market_buy_order(ccxt_symbol, amount, params=params)
                            else:
                                return self.exchange.create_market_sell_order(ccxt_symbol, amount, params=params)
                        elif order_type == 'limit':
                            if side == 'buy':
                                return self.exchange.create_limit_buy_order(ccxt_symbol, amount, price, params=params)
                            else:
                                return self.exchange.create_limit_sell_order(ccxt_symbol, amount, price, params=params)
                    except Exception as retry_err:
                        logger.error(f"Lỗi đặt lệnh lại sau khi ký TradFi cho {symbol}: {retry_err}")
            logger.error(f'Invalid order: {e}')
            return {}
        except Exception as e:
            err_str = str(e).lower()
            if "-4411" in str(e) or "tradfi-perps agreement" in err_str:
                logger.warning(f"📝 Phát hiện lỗi thỏa thuận TradFi-Perps (-4411) cho {symbol}. Đang tự động ký thỏa thuận và thử đặt lệnh lại...")
                if self.sign_tradfi_agreement_if_needed():
                    time.sleep(1.0)
                    try:
                        if order_type == 'market':
                            if side == 'buy':
                                return self.exchange.create_market_buy_order(ccxt_symbol, amount, params=params)
                            else:
                                return self.exchange.create_market_sell_order(ccxt_symbol, amount, params=params)
                        elif order_type == 'limit':
                            if side == 'buy':
                                return self.exchange.create_limit_buy_order(ccxt_symbol, amount, price, params=params)
                            else:
                                return self.exchange.create_limit_sell_order(ccxt_symbol, amount, price, params=params)
                    except Exception as retry_err:
                        logger.error(f"Lỗi đặt lệnh lại sau khi ký TradFi cho {symbol}: {retry_err}")
            logger.error(f'Error creating futures order: {e}')
            return {}
    
    def close_futures_position(self, symbol: str, side: str, amount: float) -> Dict:
        """Close a futures position.
        If position is LONG, we SELL to close. If SHORT, we BUY to close.
        """
        close_side = 'sell' if side.upper() in ('BUY', 'LONG') else 'buy'
        return self.create_futures_order(symbol, close_side, amount, 
                                         order_type='market', reduce_only=True)

    def get_funding_rate(self, symbol: str) -> Optional[Dict]:
        """Lấy Funding Rate hiện tại cho cặp Binance Futures."""
        if getattr(self, 'market_type', 'spot') != 'futures':
            return None
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            return self.exchange.fetch_funding_rate(ccxt_symbol)
        except Exception as e:
            logger.debug(f"Không thể lấy funding rate cho {symbol}: {e}")
            return None

    def get_open_interest(self, symbol: str) -> Optional[Dict]:
        """Lấy Open Interest (OI) hiện tại cho cặp Binance Futures."""
        if getattr(self, 'market_type', 'spot') != 'futures':
            return None
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            return self.exchange.fetch_open_interest(ccxt_symbol)
        except Exception as e:
            logger.debug(f"Không thể lấy open interest cho {symbol}: {e}")
            return None

    def get_order_book(self, symbol: str, limit: int = 20) -> Optional[Dict]:
        """Lấy độ sâu sổ lệnh (Order Book Depth) cho cặp giao dịch."""
        try:
            ccxt_symbol = self._get_ccxt_symbol(symbol)
            return self.exchange.fetch_order_book(ccxt_symbol, limit=limit)
        except Exception as e:
            logger.debug(f"Không thể lấy sổ lệnh cho {symbol}: {e}")
            return None
