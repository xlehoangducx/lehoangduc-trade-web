"""
Cloud Sync Service - Đồng bộ hai chiều giữa Bot PC và Nền tảng Web Cloudflare / Firebase
- Bắn dữ liệu telemetry thời gian thực (số dư, PnL, vị thế mở, tỷ lệ thắng) lên Firebase Firestore
- Tiếp nhận và thực thi các lệnh điều khiển từ xa (Bật, Dừng, Đổi đòn bẩy, Đóng lệnh khẩn cấp) gửi từ Web
"""

import time
import json
import logging
from datetime import datetime
from pathlib import Path
import requests
import yaml

logger = logging.getLogger("cloud_sync")

def to_firestore_value(val):
    if isinstance(val, bool):
        return {"booleanValue": val}
    elif isinstance(val, int):
        return {"integerValue": str(val)}
    elif isinstance(val, float):
        return {"doubleValue": float(val)}
    elif isinstance(val, str):
        return {"stringValue": val}
    elif isinstance(val, list):
        return {"arrayValue": {"values": [to_firestore_value(x) for x in val]}}
    elif isinstance(val, dict):
        return {"mapValue": {"fields": {k: to_firestore_value(v) for k, v in val.items()}}}
    elif val is None:
        return {"nullValue": None}
    else:
        return {"stringValue": str(val)}

def to_firestore_doc(data_dict):
    return {"fields": {k: to_firestore_value(v) for k, v in data_dict.items()}}

def from_firestore_value(val):
    if not isinstance(val, dict):
        return None
    if "stringValue" in val:
        return val["stringValue"]
    elif "integerValue" in val:
        return int(val["integerValue"])
    elif "doubleValue" in val:
        return float(val["doubleValue"])
    elif "booleanValue" in val:
        return bool(val["booleanValue"])
    elif "mapValue" in val:
        return {k: from_firestore_value(v) for k, v in val["mapValue"].get("fields", {}).items()}
    elif "arrayValue" in val:
        return [from_firestore_value(x) for x in val["arrayValue"].get("values", [])]
    elif "nullValue" in val:
        return None
    return None

def from_firestore_doc(doc):
    fields = doc.get("fields", {})
    return {k: from_firestore_value(v) for k, v in fields.items()}


class CloudSyncWorker:
    def __init__(self, root_dir=None, api_port=5000):
        self.root_dir = Path(root_dir) if root_dir else Path(__file__).parent
        self.api_port = api_port
        self.api_base = f"http://127.0.0.1:{api_port}/api"
        self.settings = self._load_settings() or {}

        cloud_cfg = self.settings.get("cloud", {})
        self.enabled = cloud_cfg.get("enabled", True)
        self.user_tokens = self._parse_tokens(cloud_cfg.get("user_token", ""))
        self.user_token = self.user_tokens[0] if self.user_tokens else ""
        self.project_id = cloud_cfg.get("project_id", "trade-bot-platform")
        self.sync_interval = cloud_cfg.get("sync_interval_seconds", 5)
        # Đếm số chu kỳ LIÊN TIẾP đọc settings THÀNH CÔNG nhưng không có token.
        # Chỉ khi vượt ngưỡng này mới được phép dừng bot (xem verify_license).
        self._empty_token_cycles = 0
        
        self.base_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents"
        self.last_command_id = None

    def _parse_tokens(self, val):
        if isinstance(val, list):
            return [str(t).strip() for t in val if str(t).strip()]
        elif isinstance(val, str):
            return [t.strip() for t in val.split(",") if t.strip()]
        return []

    def _load_settings(self, attempts: int = 3):
        """Đọc config/settings.yaml. Trả None khi KHÔNG ĐỌC ĐƯỢC (khác với file rỗng {}).

        [SỬA LỖI GỐC RỄ - TỰ SÁT BẢN QUYỀN]
        Trước đây hàm này trả {} cho cả hai trường hợp "file rỗng" và "đọc/parse lỗi".
        `run_loop()` nạp lại settings mỗi 5 giây và gán thẳng `self.user_tokens` từ kết quả,
        nên CHỈ CẦN MỘT LẦN đọc lỗi tạm thời (file đang được dashboard ghi dở, antivirus khoá
        file, user đang sửa tay YAML) là token bị xoá sạch -> `verify_license()` rơi vào nhánh
        "Chưa cấu hình token" -> `_enforce_stop_if_running()` DỪNG BOT LIVE đang gồng lệnh thật.

        Nay: file không tồn tại -> {} (không cấu hình); đọc/parse lỗi -> None (KHÔNG BIẾT),
        kèm 3 lần thử ngắn để nuốt các lỗi khoá file nhất thời. run_loop sẽ giữ nguyên cấu
        hình tốt gần nhất và bỏ qua chu kỳ thay vì zeroing token.
        """
        settings_path = self.root_dir / "config" / "settings.yaml"
        if not settings_path.exists():
            return {}
        last_error = None
        for attempt in range(1, max(1, attempts) + 1):
            try:
                with open(settings_path, "r", encoding="utf-8") as f:
                    loaded = yaml.safe_load(f)
                if loaded is None:
                    return {}
                if not isinstance(loaded, dict):
                    raise ValueError(
                        f"settings.yaml phải là mapping, nhận được {type(loaded).__name__}"
                    )
                return loaded
            except Exception as e:
                last_error = e
                if attempt < max(1, attempts):
                    time.sleep(0.2)
        logger.error(
            "Lỗi đọc settings.yaml (%s lần) - GIỮ NGUYÊN cấu hình đã nạp trước đó: %s",
            max(1, attempts), last_error,
        )
        return None

    def push_telemetry(self):
        """Gửi số dư, PnL, vị thế mở lên Firestore bots_telemetry/{user_token}"""
        if not self.user_tokens:
            return False

        try:
            # 1. Lấy dữ liệu từ local bot Flask API
            status = {}
            try:
                r_status = requests.get(f"{self.api_base}/status", timeout=3)
                if r_status.status_code == 200:
                    status = r_status.json()
                    self.last_status = status
            except Exception:
                pass
            if not status and hasattr(self, 'last_status'):
                status = self.last_status
            if not status:
                return False

            perf = {}
            try:
                r_perf = requests.get(f"{self.api_base}/performance", timeout=3)
                if r_perf.status_code == 200:
                    perf = r_perf.json()
                    self.last_perf = perf
            except Exception:
                pass
            if not perf and hasattr(self, 'last_perf'):
                perf = self.last_perf

            positions = None
            positions_stale = False
            try:
                r_pos = requests.get(f"{self.api_base}/positions", timeout=3)
                if r_pos.status_code == 200:
                    # [] là trạng thái PHẲNG THẬT, không phải dữ liệu thiếu.
                    positions = r_pos.json()
                    if not isinstance(positions, list):
                        raise ValueError('positions response is not a list')
                    self.last_positions = positions
                    self.last_positions_at = time.time()
            except Exception:
                pass
            if positions is None:
                cache_age = time.time() - float(getattr(self, 'last_positions_at', 0.0) or 0.0)
                if hasattr(self, 'last_positions') and cache_age <= 15.0:
                    positions = self.last_positions
                    positions_stale = True
                else:
                    # Không có dữ liệu tươi: công bố unknown/stale thay vì hồi sinh vị thế đã đóng.
                    positions = []
                    positions_stale = True

            balance = float(status.get("balance", status.get("available_balance", 0.0)))
            equity = float(status.get("equity") or status.get("margin_balance") or balance)
            available_balance = float(status.get("available_balance") or balance)
            wallet_balance = float(status.get("wallet_balance") or balance)
            used_margin = float(status.get("used_margin") or 0.0)
            daily_pnl = float(perf.get("today_pnl", 0.0))
            total_pnl = float(perf.get("total_pnl", 0.0))
            win_rate = float(perf.get("win_rate", 0.0) or 0.0)
            total_trades = int(perf.get("total_trades") or perf.get("closed_trade_count", 0))
            total_fees = float(perf.get("total_fees") or perf.get("total_fee", 0.0))
            is_running = bool(status.get("is_running", False))
            max_leverage = int(status.get("max_leverage") or status.get("leverage") or 10)
            max_open_trades = int(status.get("max_open_positions") or status.get("ai_recommended_max_positions") or 2)
            mode = str(status.get("mode", "live")).upper()
            market_type = str(status.get("market_type", "futures")).upper()

            # [SỔ VỐN 28/10/2026] PnL TOÀN BỘ TÀI KHOẢN = equity - tổng nạp/rút thật từ sàn.
            # Khác `total_pnl` (chỉ là realized PnL của các lệnh đã ghi trong DB): con số này
            # còn bao gồm funding fee và lịch sử giao dịch trước khi DB bắt đầu ghi. Web cần
            # hiển thị cả hai để người dùng không thắc mắc vì sao hai nơi lệch nhau.
            try:
                session_pnl = (
                    round(float(status.get("session_pnl")), 4)
                    if status.get("session_pnl") is not None else None
                )
            except (TypeError, ValueError, OverflowError):
                session_pnl = None
            try:
                invested_basis = (
                    round(float(status.get("invested_basis")), 4)
                    if status.get("invested_basis") is not None else None
                )
            except (TypeError, ValueError, OverflowError):
                invested_basis = None

            telemetry_data = {
                "user_token": self.user_token,
                "balance": balance,
                "equity": round(equity, 2),
                "available_balance": round(available_balance, 2),
                "wallet_balance": round(wallet_balance, 2),
                "used_margin": round(used_margin, 2),
                "daily_pnl": round(daily_pnl, 4),
                "today_pnl": round(daily_pnl, 4),
                "total_pnl": round(total_pnl, 4),
                "session_pnl": session_pnl,
                "invested_basis": invested_basis,
                "total_fees": round(total_fees, 4),
                "total_trades": total_trades,
                "win_rate": round(win_rate, 1),
                "max_leverage": max_leverage,
                "max_open_trades": max_open_trades,
                "mode": mode,
                "market_type": market_type,
                "open_positions_count": len(positions),
                "account_snapshot_stale": bool(positions_stale or status.get('account_snapshot_stale', False)),
                "is_running": is_running,
                "exchange_connected": bool(status.get("exchange_connected", False)),
                "tradfi_enabled": bool(status.get("tradfi_enabled", False)),
                "only_tradfi": bool(status.get("only_tradfi", False)),
                "tradfi_market_open": bool(status.get("tradfi_market_open", False)),
                "auto_adopt_manual_positions": bool(status.get("auto_adopt_manual_positions", False)),
                "free_roll_recycling": bool(status.get("free_roll_recycling", True)),
                "free_roll_positions_count": int(status.get("free_roll_positions_count", 0)),
                "at_risk_positions_count": int(status.get("at_risk_positions_count", 0)),
                "updated_at": datetime.now().strftime("%H:%M:%S %d/%m"),
                "positions": [],
                "radar_candidates": []
            }

            try:
                if status.get("radar_candidates"):
                    telemetry_data["radar_candidates"] = status.get("radar_candidates")
                else:
                    from core.gate_telemetry import get_top_radar_candidates
                    telemetry_data["radar_candidates"] = get_top_radar_candidates(limit=6)
            except Exception:
                telemetry_data["radar_candidates"] = []

            total_unrealized = 0.0
            seen_telemetry_keys = set()
            deduped_push_positions = []
            for p in positions:
                sym_raw = str(p.get("symbol", ""))
                clean_sym = sym_raw.split(':')[0].replace('/', '').upper()
                side = str(p.get("direction") or p.get("side") or "LONG").upper()
                side = "LONG" if side in ("BUY", "LONG") else "SHORT"
                t_key = (clean_sym, side)
                if t_key in seen_telemetry_keys:
                    continue
                seen_telemetry_keys.add(t_key)
                deduped_push_positions.append(p)
            positions = deduped_push_positions
            telemetry_data['open_positions_count'] = len(positions)

            for p in positions:
                side = str(p.get("direction") or p.get("side") or "LONG").upper()
                if side in ("BUY", "LONG"):
                    side = "LONG"
                else:
                    side = "SHORT"
                entry_p = float(p.get("entry_price") or 0.0)
                mark_p = float(p.get("mark_price") or entry_p)
                lev = int(p.get("exchange_leverage") or p.get("leverage") or 1)
                amt = abs(float(p.get("amount") or 0.0))

                margin = float(p.get("margin") or p.get("exchange_initial_margin") or p.get("cost") or 0.0)
                if margin <= 0.0 and entry_p > 0 and amt > 0:
                    margin = (entry_p * amt) / max(1, lev)

                upnl_val = p.get("unrealized_pnl")
                if upnl_val is None:
                    upnl_val = p.get("unrealized_pnl_mark")
                if upnl_val is None and p.get("real_pnl") is not None:
                    upnl_val = p.get("real_pnl")

                if upnl_val is not None:
                    upnl = float(upnl_val)
                elif entry_p > 0 and amt > 0:
                    upnl = (mark_p - entry_p) * amt if side == "LONG" else (entry_p - mark_p) * amt
                else:
                    upnl = 0.0

                total_unrealized += upnl

                pnl_pct = float(p.get("pnl_pct") or 0.0)
                if pnl_pct == 0.0 and margin > 0.0:
                    pnl_pct = round((upnl / margin * 100.0), 2)

                # Dịch trạng thái trailing sang tiếng Việt chuẩn theo đúng thứ tự ưu tiên từ cao xuống thấp
                raw_trailing = str(p.get("trailing_status") or "")
                if raw_trailing == "active" or p.get("trailing_active"):
                    trailing_label = "Đang bám đỉnh (Trailing)"
                elif p.get("breakeven_activated") or p.get("breakeven_protection_confirmed"):
                    trailing_label = "Đã khóa Hòa Vốn"
                elif p.get("time_sl_compressed_35m"):
                    trailing_label = "Đã siết SL 35m (-0.55%)"
                elif p.get("time_sl_compressed_25m"):
                    trailing_label = "Đã siết SL 25m (-1.0%)"
                elif p.get("time_sl_compressed_15m") or p.get("time_sl_compressed"):
                    trailing_label = "Đã siết SL 15m (-1.8%)"
                elif raw_trailing == "waiting_net_profit":
                    trailing_label = "Chờ mốc khóa lãi"
                elif raw_trailing == "protection_unavailable":
                    trailing_label = "Cần SL sàn"
                else:
                    trailing_label = "Bảo vệ vốn an toàn"

                telemetry_data["positions"].append({
                    "symbol": str(p.get("symbol", "")),
                    "side": side,
                    "leverage": lev,
                    "amount": amt,
                    "entry_price": entry_p,
                    "mark_price": mark_p,
                    "margin": round(margin, 2),
                    "unrealized_pnl": round(upnl, 4),
                    "pnl_pct": round(pnl_pct, 2),
                    "stop_loss": float(p.get("stop_loss") or 0.0),
                    "take_profit": float(p.get("take_profit") or 0.0),
                    "trailing_status": trailing_label,
                    "trailing_active": bool(p.get("trailing_active", False)),
                    "time_sl_compressed": bool(
                        p.get("time_sl_compressed_15m")
                        or p.get("time_sl_compressed_25m")
                        or p.get("time_sl_compressed_35m")
                    )
                })

            telemetry_data["unrealized_pnl"] = round(total_unrealized, 4)

            any_success = False
            for token in self.user_tokens:
                telemetry_data["user_token"] = token
                patch_url = f"{self.base_url}/bots_telemetry/{token}"
                doc_body = to_firestore_doc(telemetry_data)
                try:
                    res = requests.patch(patch_url, json=doc_body, timeout=5)
                    if res.status_code == 200:
                        any_success = True
                        try:
                            user_url = f"{self.base_url}/users/{token}?updateMask.fieldPaths=livePnl&updateMask.fieldPaths=totalPnl&updateMask.fieldPaths=assignedBalance"
                            user_body = to_firestore_doc({
                                "livePnl": daily_pnl,
                                "totalPnl": total_pnl,
                                "assignedBalance": balance
                            })
                            requests.patch(user_url, json=user_body, timeout=4)
                        except Exception:
                            pass
                except Exception as te:
                    logger.debug(f"Lỗi gửi telemetry cho token {token[:6]}...: {te}")

            return any_success

        except Exception as e:
            logger.debug(f"Lỗi push telemetry: {e}")
            return False

    def verify_license(self):
        """Kiểm tra bản quyền từ xa của Super Admin Lê Hoàng Đức."""
        if not self.user_tokens:
            # [SỬA LỖI GỐC RỄ] Trước đây thiếu token là dừng bot NGAY LẬP TỨC. Kết hợp với lỗi
            # đọc settings tạm thời ở _load_settings(), một lần antivirus khoá file cũng đủ
            # giết bot live đang gồng vị thế. Nay chỉ dừng khi tình trạng "không có token" được
            # xác nhận bền vững: >= 3 chu kỳ LIÊN TIẾP đọc cấu hình THÀNH CÔNG mà vẫn rỗng.
            empty_cycles = int(getattr(self, '_empty_token_cycles', 0) or 0)
            if empty_cycles >= 3:
                self._enforce_stop_if_running("Chưa cấu hình User Token bản quyền TradeMatrix!")
                return False, "Chưa cấu hình token"
            logger.warning(
                "⚠️ [CLOUD SYNC] Chưa thấy User Token (xác nhận %d/3 chu kỳ) - tạm KHÔNG dừng bot.",
                empty_cycles,
            )
            return False, "Chưa cấu hình token (đang xác nhận)"

        for token in self.user_tokens:
            try:
                # `users/{uid}` có thể bị Firestore Rules chặn REST (403), trong khi
                # `bot_commands/{uid}` là kênh license được Web đồng bộ chính thức.
                # Đọc kênh này trước để không từ chối oan token đã approved.
                cmd_url = f"{self.base_url}/bot_commands/{token}"
                cmd_res = requests.get(cmd_url, timeout=4)
                if cmd_res.status_code == 200:
                    cmd_doc = from_firestore_doc(cmd_res.json())
                    license_status = str(cmd_doc.get("license_status", "")).lower()
                    if license_status == "approved":
                        return True, "Đã cấp quyền"
                    if license_status in ("revoked", "blocked"):
                        return False, "Quyền đã bị thu hồi/khóa"
            except Exception as e:
                logger.debug("Lỗi đọc bot_commands license cho token đã ẩn: %s", e)

            try:
                user_url = f"{self.base_url}/users/{token}"
                res = requests.get(user_url, timeout=4)
                if res.status_code == 200:
                    user_doc = from_firestore_doc(res.json())
                    status = str(user_doc.get("status", "pending")).lower()
                    role = str(user_doc.get("role", "user")).lower()
                    if role == "admin" or status == "approved":
                        return True, "Đã cấp quyền"
            except Exception as e:
                logger.debug("Lỗi kiểm tra users license cho token đã ẩn: %s", e)

        # Không có token nào approved / không xác minh được dịch vụ: fail-closed.
        return False, "Không xác minh được quyền sử dụng hợp lệ"

    def _enforce_stop_if_running(self, reason):
        try:
            r_status = requests.get(f"{self.api_base}/status", timeout=2)
            if r_status.status_code == 200 and r_status.json().get("is_running"):
                logger.warning(f"⛔ [KHÓA BẢN QUYỀN]: {reason}. Tiến hành dừng bot!")
                requests.post(f"{self.api_base}/stop", json={}, timeout=3)
        except Exception:
            pass

    def poll_and_execute_commands(self):
        """Lắng nghe lệnh điều khiển từ xa từ Firestore bot_commands/{token}"""
        if not self.user_tokens:
            return

        for token in self.user_tokens:
            try:
                cmd_url = f"{self.base_url}/bot_commands/{token}"
                res = requests.get(cmd_url, timeout=4)
                if res.status_code != 200:
                    continue

                cmd_doc = from_firestore_doc(res.json())
                command = cmd_doc.get("command")
                status = cmd_doc.get("status")
                license_status = str(cmd_doc.get("license_status", "")).lower()

                if license_status in ("revoked", "blocked"):
                    self._enforce_stop_if_running("Quyền sử dụng bot đã bị Admin thu hồi/khóa từ xa!")
                    continue

                if status != "pending" or not command:
                    continue

                command_id = str(
                    cmd_doc.get('command_id') or cmd_doc.get('id')
                    or f"{command}:{cmd_doc.get('created_at') or cmd_doc.get('updated_at') or ''}"
                )
                if command_id == self.last_command_id:
                    continue
                # Claim trước side effect: nếu ACK sau đó lỗi, lệnh không còn pending
                # và không bị đóng/config lặp ở chu kỳ tiếp theo.
                claim_body = to_firestore_doc({'status': 'executing', 'command_id': command_id})
                claim_res = requests.patch(cmd_url, json=claim_body, timeout=4)
                if claim_res.status_code != 200:
                    continue
                self.last_command_id = command_id
                logger.info(f"⚡ Nhận lệnh từ xa cho [{token[:6]}...]: [{command.upper()}]")

                success = False
                msg = ""

                if command == "status_update":
                    success = True
                    msg = f"Đã cập nhật trạng thái bản quyền: {license_status.upper()}"

                elif command == "start":
                    # Kiểm tra bản quyền trước khi cho start
                    if license_status in ("revoked", "blocked"):
                        success = False
                        msg = "Từ chối khởi động: Tài khoản đã bị khóa bởi Admin."
                    else:
                        licensed, reason = self.verify_license()
                        if not licensed:
                            success = False
                            msg = f"Từ chối khởi động: {reason}"
                        else:
                            r = requests.post(f"{self.api_base}/start", json={}, timeout=5)
                            success = r.status_code == 200
                            msg = r.text

                elif command == "stop":
                    r = requests.post(f"{self.api_base}/stop", json={}, timeout=5)
                    success = r.status_code == 200
                    msg = r.text

                elif command == "run_cycle":
                    licensed, reason = self.verify_license()
                    if not licensed:
                        success = False
                        msg = f"Từ chối thực thi: {reason}"
                    else:
                        r = requests.post(f"{self.api_base}/run_cycle", json={}, timeout=5)
                        success = r.status_code == 200
                        msg = r.text

                elif command == "update_config":
                    responses = []
                    if "max_leverage" in cmd_doc:
                        responses.append(requests.post(f"{self.api_base}/leverage", json={"max_leverage": cmd_doc["max_leverage"]}, timeout=5))
                    if "max_open_trades" in cmd_doc:
                        responses.append(requests.post(f"{self.api_base}/positions_limit", json={"max_open_trades": cmd_doc["max_open_trades"]}, timeout=5))
                    if "auto_adopt_manual_positions" in cmd_doc:
                        responses.append(requests.post(f"{self.api_base}/manual_adopt/toggle", json={"enabled": bool(cmd_doc["auto_adopt_manual_positions"])}, timeout=5))
                    if "free_roll_recycling" in cmd_doc:
                        responses.append(requests.post(f"{self.api_base}/free_roll_recycling/toggle", json={"enabled": bool(cmd_doc["free_roll_recycling"])}, timeout=5))
                    if "tradfi_enabled" in cmd_doc or "only_tradfi" in cmd_doc:
                        payload = {}
                        if "tradfi_enabled" in cmd_doc:
                            payload["enabled"] = bool(cmd_doc["tradfi_enabled"])
                        if "only_tradfi" in cmd_doc:
                            payload["only_tradfi"] = bool(cmd_doc["only_tradfi"])
                        responses.append(requests.post(f"{self.api_base}/tradfi/toggle", json=payload, timeout=5))
                    success = bool(responses) and all(r.status_code == 200 for r in responses)
                    msg = " | ".join(r.text[:160] for r in responses) if responses else "Không có trường cấu hình hợp lệ"
                    time.sleep(0.5)
                    self.push_telemetry()

                elif command in ("toggle_manual_adopt", "set_manual_adopt"):
                    enabled = bool(cmd_doc.get("enabled", False))
                    try:
                        r = requests.post(f"{self.api_base}/manual_adopt/toggle", json={"enabled": enabled}, timeout=5)
                        success = r.status_code == 200
                        msg = r.text
                        time.sleep(0.5)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                elif command in ("toggle_free_roll_recycling", "set_free_roll_recycling"):
                    enabled = bool(cmd_doc.get("enabled", True))
                    try:
                        r = requests.post(f"{self.api_base}/free_roll_recycling/toggle", json={"enabled": enabled}, timeout=5)
                        success = r.status_code == 200
                        msg = r.text
                        time.sleep(0.5)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                elif command == "toggle_tradfi":
                    payload = {}
                    if "enabled" in cmd_doc:
                        payload["enabled"] = bool(cmd_doc["enabled"])
                    if "only_tradfi" in cmd_doc:
                        payload["only_tradfi"] = bool(cmd_doc["only_tradfi"])
                    try:
                        r = requests.post(f"{self.api_base}/tradfi/toggle", json=payload, timeout=5)
                        success = r.status_code == 200
                        msg = r.text
                        time.sleep(0.5)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                elif command == "close_position":
                    symbol = cmd_doc.get("symbol")
                    direction = cmd_doc.get("direction")
                    try:
                        payload = {"symbol": symbol}
                        if direction:
                            payload["direction"] = direction
                        r = requests.post(f"{self.api_base}/positions/close", json=payload, timeout=5)
                        success = r.status_code == 200
                        msg = r.text
                        time.sleep(0.5)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                elif command == "emergency_close":
                    # Đóng toàn bộ các lệnh đang mở
                    try:
                        r_pos = requests.get(f"{self.api_base}/positions", timeout=3)
                        if r_pos.status_code == 200:
                            positions = r_pos.json()
                            for p in positions:
                                requests.post(f"{self.api_base}/positions/close", json={"symbol": p.get("symbol")}, timeout=5)
                        success = True
                        msg = "Đã gửi lệnh đóng toàn bộ vị thế"
                        time.sleep(0.5)
                        self.push_telemetry()
                    except Exception as ce:
                        msg = str(ce)

                # Xác nhận hoàn tất lệnh
                ack_body = to_firestore_doc({
                    "command": command,
                    "status": "completed" if success else "failed",
                    "result_message": str(msg),
                    "executed_at": datetime.now().strftime("%H:%M:%S %d/%m")
                })
                requests.patch(cmd_url, json=ack_body, timeout=4)
                logger.info(f"✅ Hoàn tất thi hành lệnh [{command.upper()}] cho [{token[:6]}...]")

            except Exception as e:
                logger.debug(f"Lỗi kiểm tra lệnh từ xa cho token {token[:6]}: {e}")

    def run_loop(self):
        """Vòng lặp chạy nền độc lập."""
        import socket
        import os
        current_host = socket.gethostname()
        if "DESKTOP-14H1SF7" in current_host and not os.getenv("FORCE_DEV_CLOUD_SYNC"):
            logger.info("🛡️ [DEV MACHINE DETECTED] Máy PC1 (%s) là môi trường Dev. Tự động vô hiệu hóa Cloud Sync để bảo vệ máy Live PC2 24/24 độc quyền đẩy dữ liệu lên Web.", current_host)
            return

        logger.info("🌐 Cloud Sync Service khởi động (%d token, không in secrets).", len(self.user_tokens or []))
        while True:
            # Tự động nạp lại config nếu user đổi token trên giao diện web local
            # [SỬA LỖI GỐC RỄ] Chỉ thay cấu hình khi đọc THÀNH CÔNG. Nếu file đang bị khoá/ghi dở,
            # giữ nguyên token + settings tốt gần nhất và bỏ qua chu kỳ, tuyệt đối không zeroing token.
            reloaded = self._load_settings()
            if reloaded is None:
                logger.warning(
                    "⚠️ [CLOUD SYNC] Bỏ qua chu kỳ này: không đọc được settings.yaml. "
                    "Giữ nguyên %d user token đã nạp.", len(self.user_tokens or [])
                )
                time.sleep(self.sync_interval)
                continue
            self.settings = reloaded
            cloud_cfg = self.settings.get("cloud", {})
            self.enabled = bool(cloud_cfg.get("enabled", True))
            if not self.enabled:
                # Tắt cloud phải dừng cả telemetry, license polling và remote commands.
                time.sleep(self.sync_interval)
                continue
            self.user_tokens = self._parse_tokens(cloud_cfg.get("user_token", ""))
            self.user_token = self.user_tokens[0] if self.user_tokens else ""

            if self.user_tokens:
                self._empty_token_cycles = 0
                licensed, reason = self.verify_license()
                if licensed:
                    self.push_telemetry()
                    self.poll_and_execute_commands()
            else:
                self._empty_token_cycles = int(getattr(self, '_empty_token_cycles', 0) or 0) + 1
                self.verify_license()
            time.sleep(self.sync_interval)

def start_cloud_sync_thread(root_dir=None, api_port=5000):
    import threading
    worker = CloudSyncWorker(root_dir=root_dir, api_port=api_port)
    t = threading.Thread(target=worker.run_loop, daemon=True, name="CloudSyncWorker")
    t.start()
    return worker

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    worker = CloudSyncWorker()
    worker.run_loop()

