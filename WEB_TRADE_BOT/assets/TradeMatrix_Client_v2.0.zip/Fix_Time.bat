@echo off
color 0A
title DONG BO THOI GIAN CHO BINANCE API - TRADEMATRIX

echo =======================================================
echo     AUTO FIX: DONG BO THOI GIAN CHO BINANCE API
echo =======================================================
echo.

echo [1/4] Dang khoi dong lai dich vu Windows Time (w32time)...
net stop w32time
net start w32time

echo.
echo [2/4] Dang dang ky lai dich vu w32tm...
w32tm /unregister
w32tm /register
net start w32time

echo.
echo [3/4] Dang cau hinh NTP Server chuan Quoc te (Google / Windows Time)...
w32tm /config /manualpeerlist:"time.google.com,0x1 time.windows.com,0x1 pool.ntp.org,0x1" /syncfromflags:manual /reliable:YES /update

echo.
echo [4/4] Dang dong bo cuong buc thoi gian thuc...
w32tm /resync /force

echo.
echo =======================================================
echo [HOAN TAT] DA DONG BO XONG!
echo Neu co dong bao loi "Access is denied" o tren,
echo hay bam chuot phai vao file nay va chon "Run as administrator".
echo =======================================================
echo.
pause
