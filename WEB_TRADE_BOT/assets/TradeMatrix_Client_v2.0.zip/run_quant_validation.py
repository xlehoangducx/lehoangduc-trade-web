"""
CLI Runner for Institutional Quant Strategy Validation (v2.0).
Executes the 4-Tier Institutional Verification Suite on TradeMatrix historical data.
"""

import sys
import os
from datetime import datetime

# Đảm bảo UTF-8 chống lỗi font trên mọi phiên bản Windows CMD / PowerShell
if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, 'reconfigure'):
    try:
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

from ai.quant_validation_engine import QuantValidationEngine


def print_suite_report(report: dict, section_title: str):
    t1 = report.get("tier_1_bar_by_bar_metrics", {})
    t2 = report.get("tier_2_in_sample_permutation", {})
    t3 = report.get("tier_3_walk_forward_analysis", {})
    t4 = report.get("tier_4_walk_forward_monte_carlo_permutation", {})
    rating = report.get("overall_system_rating", {})

    print("\n" + "=" * 80)
    print(f"  📊 {section_title}")
    print("=" * 80)

    print("\n--- 1. HIỆU SUẤT TRONG MẪU THEO TỪNG THANH NẾN (BAR-BY-BAR METRICS) ---")
    print(f"  • Tổng số thanh nến kiểm tra (Total Bars)   : {t1.get('total_bars_evaluated', 0):,} bars (15m)")
    print(f"  • Lợi nhuận trung bình mỗi thanh (Mean Bar)  : {t1.get('mean_bar_return_pct', 0):+.4f}% / bar")
    print(f"  • Annualized Bar Sharpe Ratio                : {t1.get('annualized_bar_sharpe', 0):.2f}")
    print(f"  • Annualized Bar Sortino Ratio               : {t1.get('annualized_bar_sortino', 0):.2f}")
    print(f"  • Maximum Adverse Excursion (MAE trung bình) : {t1.get('avg_mae_pct', 0):.2f}% (Mức âm tối đa khi giữ lệnh)")
    print(f"  • Maximum Favorable Excursion (MFE trung bình): {t1.get('avg_mfe_pct', 0):.2f}% (Mức đỉnh lãi trung bình)")
    print(f"  • Ulcer Index (Chỉ số đo áp lực sụt giảm)    : {t1.get('ulcer_index', 0):.2f}")

    print("\n--- 2. KIỂM ĐỊNH HOÁN VỊ MONTE CARLO TRONG MẪU (IN-SAMPLE PERMUTATION TEST) ---")
    print(f"  • Số vòng lặp xáo trộn (Permutations)        : {t2.get('num_permutations', 0):,} lần")
    print(f"  • Empirical p-value (PnL)                    : {t2.get('p_value_pnl', 1.0):.4f}")
    print(f"  • Empirical p-value (Profit Factor)          : {t2.get('p_value_pf', 1.0):.4f}")
    null_pnl = t2.get("null_distribution_pnl", {})
    print(f"  • Null Distribution H0 (PnL ngẫu nhiên)      : Median={null_pnl.get('median', 0):.2f}$, P95={null_pnl.get('p95', 0):.2f}$")
    print(f"  • Kết luận Ý Nghĩa Thống Kê (Verdict)        : {t2.get('verdict')}")

    print("\n--- 3. KIỂM TRA BƯỚC ĐI TIẾP (WALK-FORWARD ROLLING ANALYSIS - WFO) ---")
    print(f"  • Số chu kỳ Rolling Windows                  : {t3.get('num_windows', 0)} chu kỳ")
    print(f"  • Walk-Forward Efficiency Ratio (WFE)        : {t3.get('walk_forward_efficiency_ratio', 0):.2f}")
    print(f"  • Độ nhất quán Out-of-Sample (OOS Consistency): {t3.get('oos_consistency_pct', 0):.1f}% chu kỳ dương")
    print(f"  • Tổng PnL Out-of-Sample (Dữ liệu chưa thấy): {t3.get('total_oos_pnl', 0):+.4f} USDT")
    print(f"  • Đánh giá Tính Bền Vững (WF Verdict)        : {t3.get('verdict')}")

    print("\n--- 4. WALK-FORWARD MONTE CARLO PERMUTATION (SEQUENCE RISK & TAIL RISK) ---")
    dd_pct = t4.get("max_drawdown_percentiles", {})
    print(f"  • 95% Value-at-Risk (95% VaR Max DD)         : {dd_pct.get('p95_var', 0):.2f}%")
    print(f"  • Conditional VaR (Expected Shortfall 95%)   : {dd_pct.get('cvar_95_expected_shortfall', 0):.2f}%")
    print(f"  • Worst-case Drawdown trong 1,000 kịch bản   : {dd_pct.get('worst_case', 0):.2f}%")
    print(f"  • Xác suất sụt giảm vượt 10% (P(DD > 10%))   : {t4.get('prob_drawdown_exceeding_10pct', 0):.1f}%")

    print("\n" + "=" * 80)
    print(f"  🏆 XẾP HẠNG THUẬT TOÁN: {rating.get('institutional_grade', 'N/A')}")
    print(f"  Điểm Độ Bền (Robustness Score): {rating.get('robustness_score', 0)} / 100")
    print(f"  Lời Nhận Định: {rating.get('summary_verdict')}")
    print("=" * 80 + "\n")


def main():
    print("=" * 80)
    print("  🏆 TRADEMATRIX INSTITUTIONAL QUANT VALIDATION SUITE (v2.0)")
    print("  Kiểm định Định lượng Cấp Quỹ: Triệt tiêu Overfitting & Data Mining Bias")
    print("=" * 80)

    import argparse
    parser = argparse.ArgumentParser(description="Institutional Quant Validation Suite")
    parser.add_argument('--db', type=str, default=None, help="Đường dẫn tới file SQLite trade_bot.db")
    args, _ = parser.parse_known_args()

    local_db = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "trade_bot.db"))
    lan_pc2_db = r"\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\data\trade_bot.db"

    if args.db and os.path.exists(args.db):
        target_db = args.db
        source_label = f"🎯 Chỉ định thủ công ({args.db})"
    elif os.path.exists(lan_pc2_db):
        target_db = lan_pc2_db
        source_label = "🖥️ PC2 Live Daemon Database (qua mạng LAN)"
    elif os.path.exists(local_db) and os.path.getsize(local_db) > 10000:
        target_db = local_db
        source_label = "📁 Cơ sở dữ liệu Cục bộ (data/trade_bot.db)"
    else:
        target_db = local_db
        source_label = "📁 Cơ sở dữ liệu Cục bộ (data/trade_bot.db)"

    print(f"\n📂 Nguồn dữ liệu kiểm định: {source_label}")
    print(f"📍 Đường dẫn: {target_db}\n")

    engine = QuantValidationEngine(db_path=target_db)

    # Đợt 1: Đánh giá giai đoạn Tháng 11 (V2.0 Hiện Tại)
    report_nov = engine.run_full_validation_suite(
        start_date=datetime(2026, 11, 1),
        filter_label="Giai đoạn Tháng 11 (01/11 -> 04/11 - Bản V2.0 Hiện Tại)"
    )
    if report_nov.get("status") != "error":
        print_suite_report(report_nov, "KẾT QUẢ KIỂM ĐỊNH THÁNG 11 (V2.0 LIVE DAEMON)")

    # Đợt 2: Đánh giá toàn bộ lịch sử (05/10 -> 04/11)
    report_all = engine.run_full_validation_suite(
        filter_label="Toàn bộ Lịch sử 1 Tháng (05/10 -> 04/11)"
    )
    if report_all.get("status") != "error":
        print_suite_report(report_all, "KẾT QUẢ KIỂM ĐỊNH TOÀN BỘ LỊCH SỬ (1 THÁNG)")


if __name__ == "__main__":
    main()
