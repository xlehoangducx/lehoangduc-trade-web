@echo off
chcp 65001 >nul
title TRADEMATRIX DAILY VERIFICATION AUDITOR
cd /d "%~dp0"

echo ================================================================================
echo  TRADEMATRIX AUTOMATED VERIFICATION AUDIT (CHUYEN GIA KIEM TOAN TU DONG)
echo ================================================================================
echo.

if exist "venv\Scripts\python.exe" (
    "venv\Scripts\python.exe" tools\daily_auditor.py
) else (
    python tools\daily_auditor.py
)

echo.
pause
