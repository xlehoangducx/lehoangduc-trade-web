import logging
import math
from typing import Tuple, List, Dict, Any
from core.scanner import MarketScanner

logger = logging.getLogger(__name__)

class RiskManager:
    """
    Quản lý rủi ro: Kích thước lệnh, cắt lỗ, chốt lời, drawdown.
    (Risk management: Position sizing, SL/TP, drawdown)
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        risk_cfg = self.config.get("risk", self.config)
        self.max_risk_per_trade = float(risk_cfg.get("max_risk_per_trade", 0.0060))
        if self.max_risk_per_trade > 0.010:
            self.max_risk_per_trade = 0.0060 # Khống chế trần 0.60% equity
        self.max_drawdown = risk_cfg.get("max_drawdown", risk_cfg.get("max_drawdown_pct", 0.15)) # 15% drawdown tối đa
        self.max_open_positions = risk_cfg.get("max_open_positions", risk_cfg.get("max_open_trades", 3))
        self.max_margin_utilization_pct = risk_cfg.get("max_margin_utilization_pct", 0.50)
        self.trailing_stop_pct = risk_cfg.get("trailing_stop_pct", 0.02)
        
    def can_trade(
        self,
        signal: Any,
        balance: float,
        open_positions: List[Dict],
        account_equity: float = None,
    ) -> Tuple[bool, str]:
        """
        Kiểm tra xem có được phép giao dịch không dựa trên các quy tắc rủi ro.
        (Check if trading is allowed based on risk rules)
        """
        if not math.isfinite(float(balance)) or balance <= 0:
            return False, "Insufficient balance"

        direction = getattr(getattr(signal, 'signal', None), 'value', None)
        if direction not in ('buy', 'sell'):
            return False, "Signal is not actionable"

        price = getattr(signal, 'price', None)
        if price is None or not math.isfinite(float(price)) or float(price) <= 0:
            return False, "Invalid signal price"

        risk_pct = float(self.max_risk_per_trade)
        if not math.isfinite(risk_pct) or not 0 < risk_pct <= 0.05:
            return False, "max_risk_per_trade must be between 0 and 5%"
            
        if len(open_positions) >= self.max_open_positions:
            return False, f"Max open positions ({self.max_open_positions}) reached"
            
        # `balance` is free margin in LIVE and uncommitted cash in DEMO. Add
        # already-used margin back when measuring the portfolio-wide limit.
        total_exposure = sum(
            float(pos.get('exchange_initial_margin') or pos.get('cost') or 0.0)
            for pos in open_positions
        )
        try:
            equity = float(account_equity) if account_equity is not None else float(balance) + total_exposure
        except (TypeError, ValueError, OverflowError):
            equity = float(balance) + total_exposure
        if not math.isfinite(equity) or equity <= 0:
            return False, "Invalid account equity"

        try:
            margin_limit = float(self.max_margin_utilization_pct)
            if margin_limit > 1:
                margin_limit /= 100.0
        except (TypeError, ValueError, OverflowError):
            margin_limit = 0.50
        if not math.isfinite(margin_limit) or not 0.05 <= margin_limit <= 0.90:
            margin_limit = 0.50
        if total_exposure >= (equity * margin_limit):
            return False, (
                f"Total margin ({total_exposure:.2f}) exceeds safe limit "
                f"({margin_limit:.0%} of equity)"
            )
            
        symbol = getattr(signal, 'symbol', '') or ''
        clean_sym = symbol.split(':')[0].strip().upper()
        base_coin = clean_sym.split('/')[0] if '/' in clean_sym else clean_sym
        is_tier1 = base_coin in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
        is_stock = MarketScanner.is_tradfi_stock(symbol)
        tradfi_cfg = self.config.get('tradfi', {})

        # Nếu đang ở chế độ CHỈ CỔ PHIẾU MỸ -> Khóa toàn bộ lệnh Crypto
        if tradfi_cfg.get('only_tradfi', False) and not is_stock:
            return False, "Chế độ 'Chỉ Cổ Phiếu Mỹ' đang bật (Tạm dừng giao dịch Crypto)"

        # QUẢN TRỊ RỦI RO RIÊNG BIỆT CHO CỔ PHIẾU MỸ (TRADFI STOCK PERPS):
        if is_stock:
            if not tradfi_cfg.get('enabled', False):
                return False, "Chế độ giao dịch cổ phiếu (TradFi) đang TẮT"
            if MarketScanner.is_us_weekend():
                return False, "Cuối tuần (Thứ 7 & CN): Tạm dừng mở vị thế mới Cổ phiếu Mỹ để tránh thanh khoản mỏng"
            if tradfi_cfg.get('session_filter', True) and not MarketScanner.is_us_market_open():
                return False, "Thị trường cổ phiếu Mỹ đang ngoài phiên giao dịch (09:30 - 16:00 EST)"

            max_stock_trades = int(tradfi_cfg.get('max_open_trades', 1))
            current_stock_trades = sum(
                1 for pos in open_positions if MarketScanner.is_tradfi_stock(pos.get('symbol', ''))
            )
            if current_stock_trades >= max_stock_trades:
                return False, f"Đã đạt số vị thế cổ phiếu tối đa ({max_stock_trades})"

            max_stock_margin_ratio = float(tradfi_cfg.get('max_margin_ratio', 0.25))
            current_stock_exposure = sum(
                float(pos.get('exchange_initial_margin') or pos.get('cost') or 0.0)
                for pos in open_positions if MarketScanner.is_tradfi_stock(pos.get('symbol', ''))
            )
            if current_stock_exposure >= (equity * max_stock_margin_ratio):
                return False, (
                    f"Ký quỹ cổ phiếu ({current_stock_exposure:.2f}) vượt giới hạn an toàn "
                    f"({max_stock_margin_ratio:.0%} vốn)"
                )

        # Chặn rủi ro tương quan cùng chiều cho Crypto Altcoins (Portfolio Correlation Cap):
        # Tránh việc mở nhiều vị thế Altcoin cùng chiều (Short hoặc Long) đồng thời.
        # Hoàn toàn miễn trừ và không tính gộp các vị thế Cổ phiếu Mỹ (TradFi Stock).
        elif not is_tier1 and open_positions:
            same_dir_altcoins = 0
            for pos in open_positions:
                pos_sym = pos.get('symbol', '')
                if MarketScanner.is_tradfi_stock(pos_sym):
                    continue  # Bỏ qua cổ phiếu, không tính vào tương quan Altcoin
                pos_dir = (pos.get('direction') or pos.get('side', '')).lower()
                clean_pos_sym = pos_sym.split(':')[0].strip().upper()
                pos_base = clean_pos_sym.split('/')[0] if '/' in clean_pos_sym else clean_pos_sym
                is_pos_tier1 = pos_base in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')
                is_same_dir = (direction in ('buy', 'long') and pos_dir in ('buy', 'long')) or \
                              (direction in ('sell', 'short') and pos_dir in ('sell', 'short'))
                if not is_pos_tier1 and is_same_dir:
                    same_dir_altcoins += 1
            if same_dir_altcoins >= 1:
                return False, f"Đã có 1 vị thế Altcoin cùng chiều ({direction.upper()}), chặn mở thêm để kiểm soát rủi ro tương quan"
        
        return True, "Trade allowed"
        
    def calculate_position_size(self, balance: float, entry_price: float, stop_loss_price: float) -> float:
        """
        Tính toán quy mô vị thế (số lượng coin/token) dựa trên rủi ro cho phép.
        (Calculate position size based on allowed risk)
        """
        if entry_price <= 0 or stop_loss_price <= 0 or entry_price == stop_loss_price:
            logger.warning("Invalid prices for position sizing")
            return 0.0
            
        risk_amount = balance * self.max_risk_per_trade
        # Khoảng cách cắt lỗ tuyệt đối
        price_risk = abs(entry_price - stop_loss_price)
        
        # Số lượng = Số tiền rủi ro / Rủi ro trên mỗi đơn vị
        position_size = risk_amount / price_risk
        
        return position_size
        
    def check_stop_loss(self, position: Dict, current_price: float) -> bool:
        """
        Kiểm tra xem giá hiện tại đã chạm mức cắt lỗ chưa.
        (Check if current price hit stop loss)
        """
        sl_price = position.get('stop_loss')
        direction = position.get('direction') or position.get('side', '').upper()
        
        if not sl_price:
            return False
            
        if direction in ('BUY', 'LONG') and current_price <= sl_price:
            return True
        elif direction in ('SELL', 'SHORT') and current_price >= sl_price:
            return True
            
        return False
        
    def check_take_profit(self, position: Dict, current_price: float) -> bool:
        """
        Kiểm tra xem giá hiện tại đã chạm mức chốt lời chưa.
        (Check if current price hit take profit)
        """
        tp_price = position.get('take_profit')
        direction = position.get('direction') or position.get('side', '').upper()
        
        if not tp_price:
            return False
            
        if direction in ('BUY', 'LONG') and current_price >= tp_price:
            return True
        elif direction in ('SELL', 'SHORT') and current_price <= tp_price:
            return True
            
        return False
        
    def update_trailing_stop(self, position: Dict, current_price: float) -> float:
        """
        Cập nhật mức cắt lỗ trượt (trailing stop).
        (Update trailing stop level)
        """
        current_sl = position.get('stop_loss', 0.0)
        direction = position.get('direction') or position.get('side', '').upper()
        
        if direction in ('BUY', 'LONG'):
            # Tính SL mới dựa trên giá hiện tại
            new_sl = current_price * (1 - self.trailing_stop_pct)
            # Chỉ cập nhật nếu SL mới cao hơn SL cũ (dịch lên)
            if new_sl > current_sl:
                return new_sl
        elif direction in ('SELL', 'SHORT'):
            new_sl = current_price * (1 + self.trailing_stop_pct)
            # Chỉ cập nhật nếu SL mới thấp hơn SL cũ (dịch xuống) hoặc chưa có SL (0.0)
            if current_sl == 0.0 or new_sl < current_sl:
                return new_sl
                
        return current_sl
        
    def check_drawdown(self, current_balance: float, peak_balance: float) -> Tuple[bool, float]:
        """
        Kiểm tra mức sụt giảm tài khoản (drawdown).
        Trả về (True/False tạm dừng giao dịch, tỷ lệ drawdown hiện tại).
        (Check account drawdown)
        """
        if peak_balance <= 0:
            return False, 0.0
            
        drawdown_pct = (peak_balance - current_balance) / peak_balance
        
        if drawdown_pct >= self.max_drawdown:
            logger.warning(f"Max drawdown reached! Current DD: {drawdown_pct*100:.2f}%")
            return True, drawdown_pct
            
        return False, drawdown_pct

    def should_take_profit_or_reinvest(self, pnl: float, balance: float) -> str:
        """
        Quản lý lợi nhuận thông minh.
        (Smart profit management based on total return)
        
        - Lợi nhuận < 20% vốn ban đầu: reinvest (tái đầu tư toàn bộ)
        - Lợi nhuận 20% - 50%: take_profit (rút 30% lợi nhuận)
        - Lợi nhuận > 50%: take_profit (rút 50% lợi nhuận)
        Lưu ý: hàm chỉ trả về action state, bot cần thực hiện logic rút tiền ở ngoài.
        """
        if pnl <= 0:
            return 'reinvest'
            
        initial_capital = balance - pnl
        
        if initial_capital <= 0:
            return 'reinvest'
            
        profit_pct = pnl / initial_capital
        
        if profit_pct < 0.20:
            return 'reinvest'
        elif 0.20 <= profit_pct <= 0.50:
            return 'partial' # Gợi ý rút 30%
        else:
            return 'take_profit' # Gợi ý rút 50%
