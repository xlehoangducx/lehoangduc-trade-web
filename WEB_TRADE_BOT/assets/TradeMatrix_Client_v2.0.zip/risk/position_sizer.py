import logging

logger = logging.getLogger(__name__)

class PositionSizer:
    """
    Tính toán quy mô lệnh theo nhiều phương pháp khác nhau.
    (Calculate position sizes using various methods)
    """
    
    def __init__(self, min_size: float = 0.001, max_size_pct: float = 0.5):
        self.min_size = min_size
        self.max_size_pct = max_size_pct # Không quá 50% vốn cho một lệnh
        
    def _apply_limits(self, size: float, balance: float, entry_price: float) -> float:
        """
        Giới hạn quy mô lệnh trong khoảng min/max.
        (Cap position size by min/max limits)
        """
        # Quy mô tối đa tính bằng số coin/token
        max_size = (balance * self.max_size_pct) / entry_price
        
        if max_size < self.min_size:
            logger.warning(f"Calculated max_size {max_size} is less than min_size {self.min_size}. Returning 0.0 to avoid bankruptcy.")
            return 0.0
            
        # Đảm bảo size nằm trong khoảng min_size và max_size
        final_size = max(self.min_size, min(size, max_size))
        return final_size

    def kelly_size(self, win_rate: float, avg_win: float, avg_loss: float) -> float:
        """
        Tính tỷ lệ rủi ro theo công thức Kelly Criterion.
        (Kelly Criterion calculation for risk percentage)
        
        f* = W - [(1 - W) / R]
        W: Tỷ lệ thắng (win rate)
        R: Tỷ lệ rủi ro/phần thưởng (Reward/Risk ratio = avg_win / avg_loss)
        """
        if avg_loss <= 0 or win_rate <= 0:
            return 0.0
            
        reward_risk_ratio = avg_win / avg_loss
        
        kelly_pct = win_rate - ((1 - win_rate) / reward_risk_ratio)
        
        # Thường dùng Half-Kelly để giảm rủi ro
        half_kelly = kelly_pct / 2
        
        # Chỉ rủi ro tối đa 5% theo Kelly
        return max(0.0, min(half_kelly, 0.05))
        
    def fixed_fractional(self, balance: float, risk_pct: float) -> float:
        """
        Sử dụng một tỷ lệ phần trăm vốn cố định. Trả về số TIỀN sẽ dùng (not size in crypto).
        Để quy ra size cần chia cho giá ở hàm ngoài.
        (Fixed fractional sizing)
        """
        return balance * risk_pct
        
    def atr_based(self, balance: float, atr: float, entry_price: float, risk_pct: float) -> float:
        """
        Tính kích thước lệnh dựa trên độ biến động ATR.
        (ATR-based sizing)
        """
        if atr <= 0 or entry_price <= 0:
            return 0.0
            
        risk_amount = balance * risk_pct
        
        # Thông thường cắt lỗ đặt cách 2 * ATR
        stop_loss_distance = 2 * atr
        
        size = risk_amount / stop_loss_distance
        
        return self._apply_limits(size, balance, entry_price)

    def calculate(self, method: str, **kwargs) -> float:
        """
        Tính toán quy mô lệnh dựa trên phương pháp được chọn.
        (Calculate size based on selected method)
        """
        balance = kwargs.get('balance', 0.0)
        entry_price = kwargs.get('entry_price', 0.0)
        
        if balance <= 0 or entry_price <= 0:
            return 0.0
            
        size = 0.0
        
        if method == 'kelly':
            risk_pct = self.kelly_size(
                kwargs.get('win_rate', 0.5),
                kwargs.get('avg_win', 2.0),
                kwargs.get('avg_loss', 1.0)
            )
            # Giả sử RR là 1:1 cho việc tính SL cơ bản
            risk_amount = balance * risk_pct
            # Tính size đơn giản dựa trên 5% stoploss giả định
            sl_dist = entry_price * 0.05
            size = risk_amount / sl_dist if sl_dist > 0 else 0
            
        elif method == 'fixed':
            risk_amount = self.fixed_fractional(balance, kwargs.get('risk_pct', 0.02))
            # Cần một khoảng SL để tính toán
            sl_price = kwargs.get('stop_loss', entry_price * 0.95)
            sl_dist = abs(entry_price - sl_price)
            size = risk_amount / sl_dist if sl_dist > 0 else 0
            
        elif method == 'atr':
            size = self.atr_based(
                balance,
                kwargs.get('atr', 0.0),
                entry_price,
                kwargs.get('risk_pct', 0.02)
            )
        else:
            logger.warning(f"Unknown sizing method: {method}")
            return 0.0
            
        return self._apply_limits(size, balance, entry_price)
