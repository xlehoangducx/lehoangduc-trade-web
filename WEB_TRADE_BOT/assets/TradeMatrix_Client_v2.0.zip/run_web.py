"""
TRADE BOT - Web Launcher
Khởi chạy web dashboard và bot engine.
Double-click START.bat hoặc chạy: python run_web.py
"""

import os
os.environ["PYTHONWARNINGS"] = "ignore"
import warnings
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', message='.*delayed.*')
warnings.filterwarnings('ignore', message='.*sklearn.*')

import logging
import threading
import sys
import os
from pathlib import Path

# Đảm bảo terminal console hiển thị chuẩn UTF-8 và Emoji
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

# Setup paths
ROOT_DIR = Path(__file__).parent
sys.path.insert(0, str(ROOT_DIR))

from dotenv import load_dotenv
load_dotenv(ROOT_DIR / ".env", override=True)

# Setup logging
log_dir = ROOT_DIR / "logs"
log_dir.mkdir(exist_ok=True)

from datetime import datetime
log_file = log_dir / f"bot_{datetime.now().strftime('%Y%m%d')}.log"

EMOJI_TO_TEXT = {
    '🤖': '[BOT]', '🌐': '[WEB]', '🚀': '[RUN]', '💰': '[TIEN]',
    '⏱️': '[TIME]', '⏱': '[TIME]', '✅': '[OK]', '🔄': '[SYNC]',
    '🔍': '[SCAN]', '🛡️': '[DEF]', '🛡': '[DEF]', '🛑': '[STOP]',
    '📌': '[NOTE]', '📊': '[STAT]', '🧠': '[AI]', '⚠️': '[WARN]',
    '🎯': '[MUC-TIEU]', '💡': '[GOI-Y]', '🚫': '[CHAN]', '🏆': '[THANG]',
    '❌': '[THUA]', '⚪': '[HOA]', '⚡': '[CHU-Y]', '⏳': '[CHO]',
    '🔹': '-', '▶️': '[CHAY]', '⛔': '[DUNG]',
    '✂️': '[CAT]', '✂': '[CAT]', '🚪': '[THOAT]', '👉': '->',
}

def setup_windows_console():
    """Tự động chuyển console Windows sang UTF-8 và font Consolas để hiển thị tiếng Việt có dấu chuẩn đẹp."""
    if sys.platform != 'win32':
        return
    try:
        import ctypes
        from ctypes import wintypes
        ctypes.windll.kernel32.SetConsoleOutputCP(65001)
        ctypes.windll.kernel32.SetConsoleCP(65001)

        class COORD(ctypes.Structure):
            _fields_ = [('X', ctypes.c_short), ('Y', ctypes.c_short)]

        class CONSOLE_FONT_INFOEX(ctypes.Structure):
            _fields_ = [
                ('cbSize', wintypes.ULONG),
                ('nFont', wintypes.DWORD),
                ('dwFontSize', COORD),
                ('FontFamily', wintypes.UINT),
                ('FontWeight', wintypes.UINT),
                ('FaceName', wintypes.WCHAR * 32)
            ]

        handle = ctypes.windll.kernel32.GetStdHandle(-11)
        font = CONSOLE_FONT_INFOEX()
        font.cbSize = ctypes.sizeof(CONSOLE_FONT_INFOEX)
        font.FaceName = 'Consolas'
        font.dwFontSize.X = 0
        font.dwFontSize.Y = 16
        font.FontFamily = 54
        font.FontWeight = 400
        ctypes.windll.kernel32.SetCurrentConsoleFontEx(handle, False, ctypes.byref(font))
    except Exception:
        pass

setup_windows_console()

class ConsoleStreamFormatter(logging.Formatter):
    """Bộ định dạng riêng cho Windows Console CMD: chuyển Emoji thành text tag sạch để tránh lỗi ?? và giữ trọn vẹn 100% tiếng Việt có dấu."""
    def format(self, record):
        s = super().format(record)
        for emoji, text in EMOJI_TO_TEXT.items():
            if emoji in s:
                s = s.replace(emoji, text)
        return s

file_handler = logging.FileHandler(str(log_file), encoding='utf-8')
file_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s'))

console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(ConsoleStreamFormatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s'))

root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)
root_logger.handlers = [] # Xóa các handler cũ nếu có
root_logger.addHandler(file_handler)
root_logger.addHandler(console_handler)

# Tat spam access log cua werkzeug va urllib3 de man hinh CMD chi chua thong tin trade quan trong
logging.getLogger('werkzeug').setLevel(logging.WARNING)
logging.getLogger('urllib3').setLevel(logging.ERROR)
logging.getLogger('urllib3.connectionpool').setLevel(logging.ERROR)

logger = logging.getLogger(__name__)

def main():
    """Khởi chạy web dashboard."""
    try:
        from core.bot import TradeBot
        from dashboard.app import create_app
        
        logger.info("🤖 Khởi tạo Trade Bot...")
        bot = TradeBot()
        
        logger.info("🌐 Khởi tạo Web Dashboard...")
        app = create_app(bot)
        
        # Kết nối sàn
        connected = bot.connect()
        if not connected:
            logger.warning("⚠️ Không kết nối được sàn. Bot sẽ chạy ở chế độ offline/demo.")
        
        host = bot.config.get('dashboard', {}).get('host', '127.0.0.1')
        port = bot.config.get('dashboard', {}).get('port', 5000)
        
        logger.info(f"🚀 Dashboard: http://{host}:{port}")
        logger.info("📌 Nhấn Ctrl+C để dừng bot")
        
        # Khởi chạy dịch vụ đồng bộ Cloud Sync (Firebase Telemetry & Điều khiển từ xa)
        try:
            from cloud_sync import start_cloud_sync_thread
            start_cloud_sync_thread(root_dir=ROOT_DIR, api_port=port)
            logger.info("☁️ Cloud Telemetry Sync đã sẵn sàng kết nối https://lehoangduc.pages.dev")
        except Exception as e:
            logger.warning(f"⚠️ Không thể khởi chạy Cloud Sync: {e}")

        # Chạy Flask server
        app.run(
            host=host,
            port=port,
            debug=False,
            use_reloader=False
        )
        
    except KeyboardInterrupt:
        logger.info("⛔ Bot đã dừng bởi người dùng.")
    except Exception as e:
        logger.error(f"❌ Lỗi khởi chạy: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()
