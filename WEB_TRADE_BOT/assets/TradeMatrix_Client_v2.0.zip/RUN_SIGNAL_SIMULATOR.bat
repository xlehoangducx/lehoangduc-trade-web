@echo off
chcp 65001 >nul
title TradeMatrix - True Signal Replay Simulator

echo ===============================================================================
echo   TRADEMATRIX TRUE SIGNAL REPLAY SIMULATOR
echo   Tự động quét nhật ký thực chiến mới nhất và mô phỏng qua SignalAggregator
echo ===============================================================================
echo.

python tools\true_signal_simulator.py %1

echo.
echo ===============================================================================
echo   Mô phỏng hoàn tất!
echo ===============================================================================
pause
