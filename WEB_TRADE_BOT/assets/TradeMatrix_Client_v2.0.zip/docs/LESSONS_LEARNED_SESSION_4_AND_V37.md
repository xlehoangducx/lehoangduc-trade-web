# TRADEMATRIX QUANT ECOSYSTEM — TỔNG KẾT BÀI HỌC VẬN HÀNH & NÂNG CẤP V3.7 MASTER (PHIÊN 14/11/2026)
> **Bản đúc kết tri thức định lượng SSOT (Single Source of Truth) toàn diện.**
> *Dành riêng cho mọi phiên làm việc mới trên Antigravity IDE: Kế thừa 100% logic đã tối ưu, bảo toàn các bất biến chuẩn Quỹ và TUYỆT ĐỐI KHÔNG lặp lại các lỗi đã được giải quyết.*

---

## 🏛️ I. TỔNG QUAN TIẾN TRÌNH LÀM VIỆC (CHRONOLOGICAL TIMELINE)

```mermaid
flowchart TD
    P1["🔬 GIAI ĐOẠN 1: Pháp y 14 lệnh thua lịch sử & Khởi tạo KB10"] --> P2["🛠️ GIAI ĐOẠN 2: Đối soát mô phỏng 10 kịch bản & Rào chắn Dead Zone"]
    P2 --> P3["⚡ GIAI ĐOẠN 3: Ca bệnh thực chiến CAP/USDT (20:20) dính SL 11s"]
    P3 --> P3_SOL["Phát hiện 4 Lỗ hổng: CLOB Paradox, Sàn SL Altcoin, M1 Structural Anchor, Mất Agreement Ratio"]
    P3_SOL --> V37["🚀 GIAI ĐOẠN 4: Triển khai Kiến trúc V3.7 Master Unified (commit aa60ea7)"]
    V37 --> P4["🔬 GIAI ĐOẠN 5: Pháp y Phiên 4 (Session 790d) & Ca bệnh ETH (21:52)"]
    P4 --> P4_SOL["Triển khai 4 Bản vá Phiên 4: Sàn min_alt_sl 2.0%, Metadata Xung lực, Mở rộng Unanimous Macro Sell"]
    P4_SOL --> LIVE["🎯 GIAI ĐOẠN 6: CHỨNG THỰC LIVE PC2 — Lệnh ZEC/USDT SHORT chốt lãi 2 tầng (+0.4145$)"]
    LIVE --> FIN["📊 GIAI ĐOẠN 7: AI Trust Score bứt phá 75%, Hard Gate 11/11 Passed, 0 tệp rác"]
```

1. **Giai đoạn 1 (Pháp y 14 lệnh thua lịch sử & Khởi tạo KB10):** Phân tích 14 lệnh thua lịch sử, thiết lập Ma trận Song Não (Dual-Brain KB10), cân bằng đối xứng cả 2 chiều LONG và SHORT.
2. **Giai đoạn 2 (Đối soát mô phỏng 10 kịch bản):** Kiểm tra 513 chu kỳ lịch sử qua 10 kịch bản, thêm rào chắn TradFi Dead Zone Gate (00:00 - 08:00 AM VN khi sàn cơ sở đóng cửa).
3. **Giai đoạn 3 (Sự cố thực chiến `CAP/USDT` lúc 20:20):** Lệnh BUY `CAP/USDT` khớp tại `0.11393`, bị quét SL $1.50\%$ tại giây 11 ở `0.11220` (lỗ $-0.313\$$) trước khi bay vọt xà $+11.4\%$ lên `0.1270`.
4. **Giai đoạn 4 (Triển khai Kiến trúc V3.7 Master Unified):** Giải quyết dứt điểm 4 lỗ hổng của `CAP/USDT`: CLOB Execution Paradox, Fibo 0.382 impulse pullback, Expansion-aware ATR, M1 Structural Anchor, và khôi phục `agreement_ratio`.
5. **Giai đoạn 5 (Pháp y Phiên 4 & Ca bệnh `ETH/USDT` lúc 21:52):** Phát hiện ETH sập thác đổ nhưng bị Veto do TrapDetector báo râu dưới gom hàng và code kẹp cứng chỉ bãi bỏ bẫy râu cho Altcoin. Mở rộng `c4_unanimous_macro_sell` cho cả 3 lớp tài sản, bổ sung sàn `min_alt_sl = 2.0%` cho bão xung lực.
6. **Giai đoạn 6 (Chứng thực Live trên PC2):** Lệnh thực chiến **`ZEC/USDT SHORT`** (ID 5879-5881) khớp Maker 0.02% tại đỉnh `886.13`, vượt qua Grace Period 3m, chốt lời 2 tầng: TP1 tại `866.74` và Snell Peak Exit tại `868.35`, thu hoạch **`+0.4145 USDT` (+2.01% giá sàn)**, nâng tổng Equity lên **`103.42 USDT`**.
7. **Giai đoạn 7 (Kiểm toán & Nâng hạng độ tin cậy):** AI Trust Score chính thức tăng từ **$68\% \rightarrow \mathbf{75\%}$** (Vượt ngưỡng $\ge 70\%$).

---

## 🚨 II. TỔNG HỢP 6 LỖI THUẬT TOÁN & LOGIC NGẦM ĐÃ ĐƯỢC TRIỆT TIÊU

### 🔴 1. Bẫy Stop-Loss Tĩnh 1.50% Trên Altcoin Bão Xung Lực (`CAP/USDT`)
- **Vị trí:** [`core/bot.py`, Dòng 3180 - 3220](file:///d:/TRADE/core/bot.py#L3180-L3220).
- **Cơ chế lỗi:** Altcoin trong các pha bão volume (`is_momentum_ride` hoặc sóng đẩy $\ge 2.5\%$) có độ giãn spread sổ lệnh (CLOB) và râu nến M1 tự nhiên từ $1.0\% - 1.8\%$. Khung SL $1.50\%$ khiến $82\%$ lệnh bị quét văng trúng đáy ở 10-20 giây đầu tiên.
- **Hậu quả:** Ca bệnh `CAP/USDT` mất đứt $-0.313\$$ tiền oan và bỏ lỡ khoản lãi $+1.14\$$ của siêu sóng $+11.4\%$.
- **Giải pháp dứt điểm:** Nâng sàn an toàn **`min_alt_sl = 2.0%`** cho Altcoin khi có bão xung lực hoặc sóng đẩy $\ge 2.5\%$, nâng hệ số thích ứng lên $1.50 \times \text{ATR}_{15M}$. Kết hợp công thức định cỡ cố định rủi ro:
  $$\text{Notional} = \frac{\text{Risk Budget}}{\text{Stop-Loss \%}}$$
  Khi SL tăng từ $1.5\% \rightarrow 2.0\%$, vị thế tự động co nhỏ lại, số tiền lỗ tối đa bằng USDT **hoàn toàn không tăng** (giữ cố định ở $\approx 0.30 - 0.35\text{ USDT}$).

---

### 🔴 2. Lỗi Nghịch Lý Khớp Lệnh CLOB (CLOB Execution Paradox)
- **Vị trí:** [`core/bot.py`, Dòng 3870 - 3935](file:///d:/TRADE/core/bot.py#L3870-L3935).
- **Cơ chế lỗi:** Kiểm tra vi cấu trúc nến M1 sau khi đã đặt lệnh rình thay vì kiểm tra trước khi đặt lệnh. Nếu nến M1 vừa đóng là nến đặc xuyên thủng đáy gom hàng (Breakdown tiếp diễn), bot vẫn đặt lệnh rình Limit Maker đón dao rơi.
- **Giải pháp dứt điểm:** Đưa toàn bộ bộ lọc vi cấu trúc M1 (`m1_close < climax_low and m1_l_wick < 0.25`) lên trước khi tính toán entry và đặt lệnh đón retest Fibo 0.382. Nếu nến M1 vi phạm $\rightarrow$ `return None` hủy an toàn ngay lập tức.

---

### 🔴 3. Lỗi Mất `agreement_ratio` Khi Refactor Hàm Tính Confidence
- **Vị trí:** [`ai/signal_aggregator.py`, Dòng 2960 - 2985](file:///d:/TRADE/ai/signal_aggregator.py#L2960-L2985).
- **Cơ chế lỗi:** Khi tối ưu hóa hàm `_compute_confidence()`, biến `agreement_ratio` không được trả về trong dictionary kết quả, khiến tầng Execution không đọc được tỷ lệ đồng thuận thực sự của các chiến thuật.
- **Giải pháp dứt điểm:** Khôi phục biến `agreement_ratio = agreement_count / total_valid_strategies` và trả về đầy đủ trong dictionary metadata.

---

### 🔴 4. Điểm Mù Tài Sản Major Crypto Trong `is_fake_altcoin_bear_trap` (`ETH/USDT`)
- **Vị trí:** [`ai/signal_aggregator.py`, Dòng 818 - 828](file:///d:/TRADE/ai/signal_aggregator.py#L818-L828).
- **Cơ chế lỗi:** Biến `is_fake_altcoin_bear_trap` có điều kiện kẹp cứng `and is_crypto_altcoin`. Với Major Crypto (`ETH, BTC, SOL`), biểu thức luôn trả về `False`. Lúc 21:52:28 tối nay, `ETH/USDT` sập dốc mạnh (AI SELL 74.6%, JEV 4H SELL 85%, Trend SELL 78%), nhưng vì nến có râu dưới 47% nên TrapDetector báo Bear Trap BUY, pop SELL vote của TrendFollowing và Veto SHORT, bỏ lỡ cú sập từ `1893` về `1845`.
- **Giải pháp dứt điểm:** Tách nhánh `c4_unanimous_macro_sell` (AI $\le -0.55$ và JEV $\le -0.20$) ra khỏi điều kiện `is_crypto_altcoin`, cho phép áp dụng trên **toàn bộ 3 lớp tài sản**. Khi vĩ mô đồng thuận bán tháo, râu dưới nhỏ không được làm vô hiệu hóa tín hiệu SHORT của số đông.

---

### 🔴 5. Thiếu Truyền Metadata Xung Lực Tại Các Nhánh Smart Inversion
- **Vị trí:** [`ai/signal_aggregator.py`, Dòng 3261, 3310, 3778](file:///d:/TRADE/ai/signal_aggregator.py#L3261).
- **Cơ chế lỗi:** Các nhánh `MOMENTUM_RIDE_INVERSION_I1`, `Whale Pump Storm`, `SMART_UPTREND_INVERSION_BUY_I1` không truyền `c_recent_pump_pct` và `c_recent_dump_pct` vào metadata của `final_signal`. Tầng Execution đọc `recent_impulse_pct_sl` bị fallback về 0.
- **Giải pháp dứt điểm:** Gán tường minh `final_signal.metadata['c_recent_pump_pct'] = float(c_recent_pump)` và `float(c_recent_dump)` tại $100\%$ các nhánh đảo chiều.

---

### 🔴 6. Race Condition API Binance `-2011 Unknown order sent` Khi Hủy Lệnh Rình Mồi
- **Vị trí:** [`core/exchange.py:555-565`](file:///d:/TRADE/core/exchange.py#L555-L565) và [`core/bot.py:7663-7665`](file:///d:/TRADE/core/bot.py#L7663-L7665).
- **Cơ chế lỗi:** Khi lệnh Limit Maker đón retest đã khớp trên sàn Binance (thành vị thế mở), hàm dọn dẹp `_cancel_stalking_order` gửi lệnh `cancel_order(order_id)`. Binance trả về mã lỗi `-2011: Unknown order sent` vì lệnh đã không còn trên sổ lệnh. Bộ bọc `@retry_api_call` ghi log `API fatal error`, làm bẩn nhật ký vận hành dù bot vẫn nhận diện đúng lệnh đã khớp và mở vị thế thành công.
- **Giải pháp dứt điểm:** Trong `core/exchange.py` và `core/bot.py`, bắt ngoại lệ `-2011` và nhận diện đây là trạng thái lệnh đã khớp hoặc đã đóng trước đó, ghi nhận log `[INFO]` thay vì `[ERROR]`, trả về `{}` an toàn.

---

## 🔬 III. ĐỐI SOÁT MÔ PHỎNG LŨY KẾ 513 CHU KỲ (RULE 0.3 INVARIANTS)

Đã chạy kiểm chứng độc lập trên 3 cỗ máy mô phỏng chuẩn Quỹ trên toàn bộ 513 chu kỳ lịch sử:
1. **False Exits (Thoát nhầm / mất lệnh thắng):** $= 0$ (**ĐẠT 100%**).
2. **Tỷ lệ Thắng (Win Rate):** Cải thiện từ $47.2\% \rightarrow 47.6\%$ trên lịch sử thô (và đạt $50.5\%$ trong Replay thực tế).
3. **Hiệu ứng Lan tỏa (Ripple Effect):**
   - **Major Crypto (`BTC, ETH, SOL`):** PnL $+0.8365\text{ USDT}$ được bảo toàn $100\%$, mở khóa thêm khả năng bắt trọn nhịp xả vĩ mô như ETH.
   - **TradFi Stocks/ETFs:** Giữ nguyên hiệu suất thắng $70.0\%$.
   - **Crypto Altcoins:** Cắt giảm thua lỗ, Net PnL tăng thêm **$+1.3061\text{ USDT}$** (từ $-17.62\$$ lên $-16.31\$$).
   - **Toàn hệ thống:** Net PnL Delta tăng **$+1.3061\text{ USDT}$** đến **$+2.8129\text{ USDT}$**.

---

## 🏛️ IV. BẢN ĐỒ KIẾN TRÚC V3.7 MASTER UNIFIED & QUY CHUẨN THỰC THI

### 1. Ma Trận Stop-Loss Thích Ứng Động 3 Lớp Tài Sản:
* **Major Crypto (`BTC, ETH, SOL`):** $[1.0\%, 1.8\%]$ (Bám sát ATR, tối ưu R:R).
* **TradFi Cổ Phiếu / ETF:** $[1.0\%, 1.8\%]$ (ngoài giờ mở phiên), $[1.8\%, 3.5\%]$ (ETF đòn bẩy 3x), $[2.0\%, 3.5\%]$ (giờ mở phiên Mỹ).
* **Altcoin:** $[1.5\%, 3.5\%]$ bình thường, và sàn **$\ge 2.0\%$** cho bão volume xung lực.

### 2. Hệ Thống Chốt Lời 2 Tầng (Dual-Tier Harvest Engine):
* **Tầng 1 (Chốt 50% TP1):** Đạt $+2.0\%$ đến $+3.0\%$ biến động giá sàn ($+14\%$ đến $+21\%$ Margin 7x) $\rightarrow$ Khớp chốt 50% tiền tươi, dời SL 50% còn lại lên **Hòa Vốn Dương $+0.22\%$** (Free-Roll rủi ro $= 0$).
* **Tầng 2 (Gồng siêu sóng Trailing Stop & Snell Envelope):** 50% còn lại gồng theo đỉnh MFE, bảo vệ $80\%+$ đỉnh sóng khi có tín hiệu kiệt sức vật lý ở đỉnh ($+5.0\%$ đến $+12.0\%+$ biến động giá sàn).

### 3. Công Thức Định Cỡ Cố Định Rủi Ro & Cơ Chế Lãi Kép Bất Biến Quy Mô:
* **Công thức phân bổ vốn:**
  $$\text{Khối lượng vào lệnh (Notional USDT)} = \frac{\text{Risk Budget}}{\text{Stop-Loss \%}}$$
* **Nguyên tắc bảo vệ:** Khi SL tăng từ $1.5\% \rightarrow 2.0\%$, Notional tự động co nhỏ lại $\rightarrow$ Mức tiền mất tối đa (Max Loss USDT) **hoàn toàn giữ nguyên** ở mức $\text{Risk Budget} \approx 0.30 - 0.35\text{ USDT}$ (hoặc $0.60\%$ NAV khi vốn lớn).
* **Khống chế trần rủi ro:** Altcoin tối đa $20\%$ NAV, giữ Free Margin $\ge 30\%$, At-Risk Slots khống chế nghiêm ngặt không mở thêm vị thế khi lệnh cũ chưa Free-Roll.

### 4. Cỗ Máy Trạng Thái Khép Kín Khắc Phục Lỗi Sàn -2011 (Naked Position Protection):
* **Cơ chế:** Khi Binance trả về mã `-2011` *(Unknown order)* trong `get_order_status` hoặc `cancel_order`:
  * Không bao giờ coi là lỗi nghiêm trọng làm treo luồng.
  * Lập tức gọi `_matching_exchange_positions`:
    * Nếu phát hiện sàn **ĐÃ KHỚP vị thế**: Lập tức kích hoạt SL/TP bảo vệ, không để vị thế bị mồ côi (Zero Naked Position Invariant).
    * Nếu sàn **KHÔNG CÓ vị thế**: Lệnh đã rời sổ lệnh an toàn, giải phóng hàng đợi tracking ngay lập tức, cấm kẹt luồng retry vô tận.

---

## 🔬 V. ĐỐI SOÁT KIỂM TOÁN ĐỘC LẬP CÁC PHIÊN LIÊN TIẾP (PHIÊN 5, 6, 7 & 8)
1. **Phiên 5:** Bóc tách 6 điểm sơ hở (CAP SL 1.5%, ETH bear trap, -2011 cancel error, metadata xung lực, log đá nhau cosmetic, đo lường ATR).
2. **Phiên 6:** Triển khai bản vá State Machine khép kín cho `cancel_order` và `unknown_terminal`, đối soát vị thế mở tức thì bảo vệ vị thế không bị mồ côi.
3. **Phiên 7:** Rà soát toàn diện chu trình 6 tầng (Scanner $\rightarrow$ Multi-Strategy $\rightarrow$ Aggregator $\rightarrow$ Sniper Stalking $\rightarrow$ Position Manager $\rightarrow$ DB Sync), xác nhận 11/11 Hard Gate Passed, 0 lỗi AST, không có deadlock hay xung đột giữa các tầng.
4. **Phiên 8 & Kiểm Toán Toàn Diện:**
   - **Anti-Volatility Crush Guard (`[V4.1 ANTI-VOLATILITY CRUSH]`):** Liên kết ATR vĩ mô khung 1H vào ATR thực tế 15M trong `core/bot.py`. Nếu 1H ATR $\ge 3.0\%$, biên độ ATR 15M tính SL được bảo hiểm tối thiểu bằng $50\%$ ATR 1H, triệt tiêu nguy cơ SL bị bóp nghẹt khi nến 15M nén biên độ.
   - **Đồng bộ Metadata Xung Lực Toàn Phần:** Bổ sung `c_recent_pump_pct` và `c_recent_dump_pct` vào Metadata của 4 nhánh Inversion phụ (Opening Bell, Dump Storm, I2, Order Flow absorption) trong `ai/signal_aggregator.py`.
   - **Sàn SL Altcoin 2.0% Trong Fallback:** Bổ sung kiểm tra `is_momentum_or_impulse` trong `_compute_confidence` fallback bounding, bảo đảm SL $\ge 2.0\%$ khi có xung lực.
   - **Quy Tắc Vận Hành Bất Biến (Disk vs RAM Invariant):** Python chỉ nạp module một lần vào RAM lúc khởi động. Sau khi đồng bộ mã nguồn qua mạng LAN sang PC2, **bắt buộc phải chạy `RESTART.bat` trên PC2** để nạp mới bytecode vào RAM trước khi theo dõi live.
   - **Mô phỏng đối soát:** Chạy lại 514 chu kỳ trên `cross_asset_and_sl_simulation.py` (tăng +1.3061 USDT, Win Rate 47.7%, False Exits = 0) và 569 vị thế trên `full_spectrum_impact_simulator.py` (Win Rate 51.8%, EV > 0).

---

## 🧭 VI. HƯỚNG DẪN MỞ MÀN CHO MỌI PHIÊN CHAT MỚI
Khi người dùng mở một phiên chat mới trên Antigravity IDE, chỉ cần gõ một trong các câu lệnh ngắn sau:
* **Giám sát hằng ngày:** `"Chạy kiểm toán ngày PC2"` (hoặc `"audit"`).
* **Tiếp tục phát triển:** `"Kế thừa V3.7 Master và các bài học trong docs/LESSONS_LEARNED_SESSION_4_AND_V37.md để tiếp tục tác chiến."`
* **Pháp y tín hiệu:** `"Pháp y lệnh [Tên Coin] và chạy simulator đối soát."`

---

## 🛡️ VII. GIẢI MÃ NGHỊCH LÝ "MÔ PHỎNG THÌ ĐẸP NHƯNG PHẢI MẤT 8-9 PHIÊN ĐỂ NHẶT SẠN"
> **BÀI HỌC CỐT LÕI TỐI CAO:** Tại sao một bản mô phỏng được ca ngợi là "chuẩn Quỹ và toàn diện" vẫn khiến người dùng phải mở tới 8-9 phiên liên tiếp để lôi ra hàng loạt lỗi ngầm?

### 1. Bản Chất 4 Điểm Mù Của Bộ Mô Phỏng (Simulation Blind Spots):
1. **Điểm Mù 1: Thiên Kiến Đường Dẫn Lý Tưởng (Happy Path Bias):**
   - Mô phỏng thường chỉ chạy qua các nhánh chính mà dữ liệu lịch sử kích hoạt nhiều nhất (nhánh I1, Whale Pump).
   - Nhưng thực tế codebase có tới hơn 20 nhánh phụ (`Opening Bell Inversion`, `Waterfall Dump Storm`, `I2 Inversion`, `Order Flow Absorption`). Các nhánh phụ này chưa từng được kiểm thử truyền metadata, dẫn đến việc thiếu `c_recent_pump_pct` / `c_recent_dump_pct` làm tầng Execution tính sai SL.
2. **Điểm Mù 2: Mô Phỏng Nến Tĩnh vs Hiện Tượng Nén Biến Động Thực Tế (Candle Compression):**
   - Bộ mô phỏng tính ATR 15M bình thường. Nhưng trên sàn Live, có những lúc nến 15M bị nén rất hẹp (Doji) ngay sau một cú giật nến 1H dữ dội $\ge 3.0\%$.
   - Nếu chỉ đọc nến 15M đơn lẻ, SL bị bóp nghẹt xuống $1.2\% - 1.5\%$, khiến lệnh Altcoin bị quét râu 11s (ca bệnh `CAP/USDT`).
3. **Điểm Mù 3: Bỏ Quên Khối Mã Fallback (Fallback Code Path Blindspot):**
   - Trong mô phỏng, dữ liệu luôn lý tưởng nên code không bao giờ rơi vào nhánh `fallback`.
   - Nhưng ngoài thực tế, khi API chập chờn hoặc thiếu tham số, hàm `_compute_confidence` fallback kích hoạt một khối code cũ kẹp cứng SL, vô hiệu hóa toàn bộ logic sàn SL $2.0\%$.
4. **Điểm Mù 4: Vòng Đời Tiến Trình HĐH (Process Lifecycle Blindness):**
   - Bộ mô phỏng là script chạy xong tắt, luôn đọc code mới nhất trên đĩa cứng.
   - Nhưng Daemon PC2 là tiến trình chạy dài ngày (Long-running process), giữ nguyên module cũ trong RAM từ 23:13 hôm trước. Deploy code mới lên đĩa nhưng không restart thì code mới vẫn là số 0!

---

### 2. Bốn Bất Biến Triệt Tiêu Điểm Mù Cho Mọi Phiên Tương Lai (The 4 Anti-Blindspot Invariants):
1. **Bất Biến 1: Quét Ngang 100% Nhánh Rẽ (Exhaustive Branch Coverage Invariant):**
   - Khi thêm metadata hoặc sửa logic tham số, **TUYỆT ĐỐI CẤM chỉ sửa ở nhánh chính**.
   - BẮT BUỘC dùng grep / AST quét sạch toàn bộ các nhánh rẽ tương tự trong `ai/signal_aggregator.py` và `core/bot.py`, bảo đảm 100% các điểm return/dispatch đều cập nhật đồng nhất.
2. **Bất Biến 2: Đồng Bộ Rào Chắn Tại Khối Fallback (Fallback Parity Invariant):**
   - Bất kỳ khối mã fallback nào cũng phải thừa hưởng $100\%$ các rào chắn cứng của luồng chính (Sàn SL Altcoin $\ge 2.0\%$, trần rủi ro, ATR floor).
3. **Bất Biến 3: Bảo Hiểm Đa Khung Thời Gian (Anti-Compression MTF Floor):**
   - Tuyệt đối không bao giờ tính SL chỉ dựa trên một khung thời gian 15M đơn lẻ. Bắt buộc neo sàn tối thiểu $50\%$ theo ATR khung 1H vĩ mô (`h1_floor_atr = h1_atr * 0.50`).
4. **Bất Biến 4: Kiểm Toán Tiến Trình RAM Bắt Buộc (RAM vs Disk Daemon Audit):**
   - Trước khi báo cáo kết quả kiểm toán hoặc tuyên bố bản vá có hiệu lực, AI bắt buộc phải kiểm tra thời gian khởi động của tiến trình Python PC2 (`StartTime` vs `ModifiedTime`).
   - Nếu `StartTime < ModifiedTime`, BẮT BUỘC phát cảnh báo đỏ yêu cầu người dùng chạy `RESTART.bat`. CẤM tuyên bố an toàn khi code mới chưa nạp vào RAM!
