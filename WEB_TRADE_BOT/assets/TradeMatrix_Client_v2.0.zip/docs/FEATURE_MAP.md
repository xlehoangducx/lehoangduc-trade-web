# BẢN ĐỒ TÍNH NĂNG & KIẾN TRÚC HỆ THỐNG TRADEMATRIX MASTER QUANT
> **Tài liệu tham chiếu toàn diện về cấu trúc mã nguồn, luồng dữ liệu, giao diện Web và các quy tắc vận hành.**

---

## 🗺️ 1. CẤU TRÚC THƯ MỤC & PHÂN LOẠI MÃ NGUỒN CHUẨN SSOT

```
D:\TRADE
├── 🧠 ai/                           # BỘ NÃO ĐỊNH LƯỢNG & ĐA KHUNG THỜI GIAN
│   ├── signal_aggregator.py         # Bộ tổng hợp tín hiệu, Veto Engine, Smart Inversion & Consensus
│   ├── order_flow_analyzer.py       # Phân tích dòng lệnh Taker CVD, tường thanh khoản 100-level & Smart Inversion
│   ├── jev_agent.py                 # Tác tử AI Đa Khung Thời Gian (Ollama 7B qwen2.5:7b)
│   ├── ml_model.py                  # Mô hình Directional Predictor (XGBoost / Ensemble 15M)
│   ├── feature_engine.py            # Trích xuất đặc trưng kỹ thuật số hóa
│   ├── market_regime.py             # Phân loại trạng thái thị trường (Trending vs. Choppy & Decoupling)
│   ├── quantum_path_simulator.py    # Mô phỏng đường đi Monte Carlo & Tính toán kỳ vọng toán học EV
│   ├── quant_validation_engine.py   # Động cơ kiểm định định lượng OOS Walk-Forward & Bootstrap
│   ├── ollama_agent.py              # Phân tích Bias vĩ mô bằng LLM cục bộ
│   ├── ollama_runtime.py            # Quản trị tiến trình Ollama ngầm
│   └── news_sentiment.py            # Phân tích tâm lý thị trường & Tin tức vĩ mô
│
├── ⚙️ core/                          # ĐỘNG CƠ THỰC THI & QUẢN TRỊ VỊ THẾ
│   ├── bot.py                       # Vòng lặp chính, Quản lý vị thế, Tam Tầng SL V3.0, Telemetry Gate
│   ├── exchange.py                  # Kết nối CCXT Binance Futures (REST API & WebSocket Streams)
│   ├── binance_ws.py                # Luồng WebSocket thời gian thực (Mark Price, BookTicker, Depth20)
│   ├── scanner.py                   # Quét Radar 50+ cặp tiền tệ & Ma trận 10 ngành TradFi (238 mã)
│   ├── data_collector.py            # Thu thập và lưu đệm dữ liệu OHLCV đa khung thời gian
│   ├── gate_telemetry.py            # Quản trị Radar và ghi nhận sự kiện Telemetry Gate Mode 7
│   ├── optimizer.py                 # Tự động tối ưu hóa trọng số chiến lược theo hiệu suất
│   └── telegram_notifier.py         # Kênh thông báo bất đồng bộ tức thời qua Telegram Bot
│
├── 🛡️ risk/                          # QUẢN TRỊ RỦI RO & PHÂN BỔ VỐN
│   └── risk_manager.py              # Cầu dao Max Drawdown, Mutual Exclusion 4 Rào chắn TradFi, Tương quan
│
├── 📈 strategies/                    # CHIẾN LƯỢC KỸ THUẬT NỀN TẢNG
│   ├── base_strategy.py             # Lớp cơ sở TradeSignal & Signal Enum
│   ├── trend_following.py           # Bám theo xu hướng EMA / ADX
│   ├── trap_detector.py             # Nhận diện bẫy giá cá mập (Pinbar râu vật lý >= 35%)
│   ├── momentum_breakout.py         # Đón sóng bùng nổ thanh khoản và phá vỡ cản
│   ├── mean_reversion.py            # Đón nhịp hồi phục khi RSI/Bollinger quá bán/quá mua
│   ├── hft_scalping.py              # Chiến lược lướt sóng ngắn hạn
│   └── smart_dca.py                 # Chiến lược phân bổ vốn thông minh
│
├── 🗄️ database/                      # CƠ SỞ DỮ LIỆU ĐỊNH LƯỢNG SQLITE WAL
│   └── db_manager.py                # Quản lý bảng trades, signals, bot_state, symbol_cooldowns
│
├── 🌐 dashboard/                     # GIAO DIỆN TERMINAL & REST API NỘI BỘ
│   ├── app.py                       # Flask Server (Port 5000) tiếp nhận lệnh điều khiển từ xa
│   └── templates/ & static/         # Giao diện giám sát cục bộ
│
├── ☁️ cloud_sync.py                  # CẦU NỐI ĐIỀU KHIỂN TỪ XA VỚI CLOUDFLARE WEB
│   # Lắng nghe Firestore bot_commands/{uid} và đẩy Telemetry thời gian thực
│
├── 📚 docs/                          # TÀI LIỆU VẬN HÀNH, PLAYBOOK & BẢNG ĐIỂM CHUẨN SSOT
│   ├── QUANT_WORKFLOW_PLAYBOOK.md   # [SSOT] Cẩm nang vận hành, phát triển & đối soát định lượng chuẩn quỹ 7 bước
│   ├── AI_TRUST_SCORECARD.md        # Bảng theo dõi và chấm điểm chỉ số tin cậy AI qua từng phiên
│   ├── FEATURE_MAP.md               # Bản đồ tính năng và sơ đồ kiến trúc hệ thống
│   ├── BINANCE_EXCHANGE_ERROR_CATALOG.md # Danh mục 13 mã lỗi Binance và 238 mã cổ phiếu TradFi
│   ├── BANG_QUAN_LY_VON_VA_DON_BAY.md # Quy chuẩn quản lý vốn và đòn bẩy đa tầng
│   └── DAILY_PLAYBOOK.md            # Cẩm nang tác chiến hằng ngày cho người dùng
│
├── 🧪 tools/                         # BỘ CÔNG CỤ TỰ KIỂM CHỨNG & RÀO CHẮN CỨNG
│   ├── daily_auditor.py             # [OPS] Tự động kiểm toán PC2, tính PnL và chấm Rubric 100
│   ├── true_signal_simulator.py     # [QUANT] Replay nến và đối soát tín hiệu thực tế từ log
│   ├── full_spectrum_impact_simulator.py # [QUANT] Mô phỏng 4 kịch bản đối chứng toàn diện (KB1-KB4)
│   ├── hybrid_dual_brain_simulator.py    # [QUANT] Mô phỏng 10 kịch bản Hybrid Dual-Brain Đa Lớp Tài Sản
│   ├── clean_workspace.py           # [CLEANUP] Tự động dọn sạch rác, script tạm thời trên PC1 và PC2
│   └── hard_constraints_gate.py     # [DEV] Linter quét 11 Rào chắn cứng & AST SymTable trước khi deploy
│
└── 📜 deploy_web_client.py          # TRẠM ĐÓNG GÓI, ĐỐI SOÁT SHA-256 LAN & ĐẨY CLOUDFLARE PAGES
```

---

## 🏛️ 2. MA TRẬN 3 LỚP TÀI SẢN (THREE-TIER ASSET MATRIX)

Hệ thống phân định rạch ròi 3 lớp tài sản với cơ chế quản trị rủi ro hoàn toàn khác nhau:

| Tiêu Chí | Lớp 1: Major Crypto | Lớp 2: TradFi (Cổ Phiếu Mỹ) | Lớp 3: Crypto Altcoins |
| :--- | :--- | :--- | :--- |
| **Mã đại diện** | `BTC/USDT`, `ETH/USDT`, `SOL/USDT` | `NVDA`, `TSLA`, `MRVL`, `TQQQ`, `XAU` | `MOVR`, `WAL`, `SKYAI`, `PEPE`... |
| **Khung giờ GD** | 24/7 liên tục | Phiên Wall Street (21:30 - 04:00 VN) | 24/7 liên tục |
| **Đòn bẩy tối đa** | Lên tới 10x - 20x | **Khống chế cứng $\le 4x$** | Thích ứng 3x - 10x |
| **Trần Ký Quỹ** | Linh hoạt theo vốn | **Tối đa 20% NAV** | Thích ứng theo Slot ($50 - $100: 2 lệnh) |
| **Đặc tính ATR** | Thấp & Trung bình (0.4% - 0.9%) | Bước giá cổ phiếu, rủi ro nhảy Gap | **Biến động cực cao (1.5% - 4.5%)** |
| **Cơ chế Stop-Loss** | Chuẩn 1.0 - 1.5 ATR | SL ngắn bám sát, cấm nới rộng | Cần vùng đệm chống Stop-Hunt râu nến |
| **Khiên bảo vệ** | Không bị Weekend Shield chặn | **Weekend Shield đóng trước thứ 7** | Cooldown 180m khi đóng lỗ |

---

## 🌐 3. BẢN ĐỒ GIAO DIỆN WEB DASHBOARD & REST API

Địa chỉ triển khai: `https://lehoangduc.pages.dev/dashboard` (kết nối với Local Port 5000 qua Cloud Sync).

### A. Các Nút Bấm Điều Khiển Trên Web:
1. **Nút `BẬT BOT` (`btnStartBot`):** Gửi command `start` -> Kiểm tra bản quyền -> Khởi chạy vòng lặp giao dịch.
2. **Nút `TẠM DỪNG` (`btnStopBot`):** Gửi command `stop` -> Dừng vòng lặp quét, giữ nguyên các lệnh và bảo vệ Binance.
3. **Nút `QUÉT 1 CHU KỲ` (`btnTriggerCycle`):** Gửi command `run_cycle` -> Chạy 1 vòng quét 50+ cặp ngay lập tức.
4. **Nút `ĐÓNG TOÀN BỘ` (`btnEmergencyClose`):** Gửi command `emergency_close` -> Đóng Market toàn bộ các vị thế đang mở.
5. **Nút `x Đóng` trên từng dòng vị thế:** Gửi command `close_position` kèm `{symbol, direction}` -> Đóng Market vị thế chỉ định.

### B. Các Endpoint REST API Trong [`dashboard/app.py`](file:///d:/TRADE/dashboard/app.py):
- `GET /api/status`: Lấy số dư, trạng thái bot, PnL ngày, radar candidates.
- `GET /api/positions`: Lấy danh sách vị thế đang mở từ RAM/Binance.
- `POST /api/positions/close`: Tiếp nhận đóng vị thế thủ công Market.

---

## 🛡️ 4. HỆ THỐNG KIỂM TOÁN TỰ ĐỘNG, PLAYBOOK & BẢNG ĐIỂM TIN CẬY
- **Cẩm nang vận hành & đối soát định lượng chuẩn quỹ 7 bước:** [`docs/QUANT_WORKFLOW_PLAYBOOK.md`](file:///d:/TRADE/docs/QUANT_WORKFLOW_PLAYBOOK.md) (SSOT hướng dẫn quy trình đối soát 578 lệnh, giải phẫu 4 vấn đề vi mô và bảng phòng trừ 7 lỗi AI).
- **Bảng theo dõi chỉ số tin cậy AI:** [`docs/AI_TRUST_SCORECARD.md`](file:///d:/TRADE/docs/AI_TRUST_SCORECARD.md) (Chấm điểm định lượng sau mỗi phiên chat, theo dõi tiến độ nâng cao độ tin cậy đến ngưỡng an tâm tuyệt đối $\ge 95\%$).
- **Bộ 11 Rào chắn cứng bằng code:** [`tools/hard_constraints_gate.py`](file:///d:/TRADE/tools/hard_constraints_gate.py) (Tự động quét regex và AST chống NameError trước mọi lần build/deploy).
- **Kiểm toán viên thực chiến hằng ngày:** [`tools/daily_auditor.py`](file:///d:/TRADE/tools/daily_auditor.py) (Kiểm tra kết nối LAN, đọc database và quét lỗi runtime log thời gian thực).

- `POST /api/start` & `POST /api/stop`: Khởi động và dừng bot an toàn (Idempotent).
- `POST /api/run_cycle`: Kích hoạt chu kỳ phân tích thủ công.
