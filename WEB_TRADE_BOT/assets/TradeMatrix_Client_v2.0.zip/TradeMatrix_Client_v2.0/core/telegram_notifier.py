import requests
import logging
import time

logger = logging.getLogger(__name__)

def send_telegram_message(token: str, chat_id: str, msg: str) -> bool:
    token = str(token or '').strip("'\" \t\r\n")
    chat_id = str(chat_id or '').strip("'\" \t\r\n")
    if not token or not chat_id:
        return False
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = {"chat_id": chat_id, "text": msg}
    for attempt in range(3):
        try:
            response = requests.post(url, data=data, timeout=8)
            result = response.json()
            if response.ok and result.get('ok') is True:
                return True
            logger.warning("Telegram API rejected message (HTTP %s): %s", response.status_code, result.get('description', 'unknown error'))
            if response.status_code < 500 and response.status_code != 429:
                return False
            retry_after = (result.get('parameters') or {}).get('retry_after', 0)
            time.sleep(min(float(retry_after or (2 ** attempt)), 10))
        except (requests.RequestException, ValueError) as e:
            logger.warning("Telegram send attempt %s failed: %s", attempt + 1, e)
            if attempt < 2:
                time.sleep(2 ** attempt)
    return False
