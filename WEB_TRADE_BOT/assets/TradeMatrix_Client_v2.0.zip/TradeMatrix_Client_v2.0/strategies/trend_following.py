import pandas as pd
import ta
import numpy as np
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal

class TrendFollowingStrategy(BaseStrategy):
    """
    Chiến lược giao dịch theo xu hướng (Trend Following).
    Sử dụng sự giao cắt của các đường trung bình động (EMA), kết hợp với RSI, Volume và ADX.
    """
    def __init__(self, name: str = "TrendFollowing", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'ema_fast': 9,
                    'ema_mid': 21,
                    'ema_slow': 55,
                    'rsi_period': 14,
                    'rsi_overbought': 65,
                    'rsi_oversold': 30,
                    'adx_period': 14,
                    'adx_threshold': 25,
                    'vol_sma_period': 20,
                    'vol_ratio': 1.5,
                    'atr_period': 14,
                    'atr_multiplier_sl': 1.5,
                    'atr_multiplier_tp': 3.0
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Tính toán các chỉ báo kỹ thuật cần thiết cho chiến lược: EMA, RSI, ADX, Volume SMA, ATR.
        """
        if df is None or len(df) < self.params.get('ema_slow', 55):
            return df
            
        df = df.copy()
        
        # Tính toán EMA
        df['ema_fast'] = ta.trend.EMAIndicator(df['close'], window=self.params.get('ema_fast', 9)).ema_indicator()
        df['ema_mid'] = ta.trend.EMAIndicator(df['close'], window=self.params.get('ema_mid', 21)).ema_indicator()
        df['ema_slow'] = ta.trend.EMAIndicator(df['close'], window=self.params.get('ema_slow', 55)).ema_indicator()
        
        # Tính toán RSI
        df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=self.params.get('rsi_period', 14)).rsi()
        
        # Tính toán ADX
        df['adx'] = ta.trend.ADXIndicator(df['high'], df['low'], df['close'], window=self.params.get('adx_period', 14)).adx()
            
        # Tính toán Volume SMA
        df['vol_sma'] = df['volume'].rolling(window=self.params.get('vol_sma_period', 20)).mean()
        
        # Tính toán ATR cho Stop Loss và Take Profit động
        df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=self.params.get('atr_period', 14)).average_true_range()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        """
        Phân tích dữ liệu và tạo tín hiệu giao dịch.
        BUY: EMA9 cắt lên EMA21, EMA21 > EMA55, RSI < 65, Volume > VolSMA * 1.5, ADX > 25.
        SELL: EMA9 cắt xuống EMA21, hoặc RSI > 70, hoặc giá dưới EMA55.
        """
        df = self.get_indicators(df)
        
        if df is None or df.empty or len(df) < 55 or 'atr' not in df.columns or 'ema_slow' not in df.columns or df['atr'].isna().iloc[-2] or df['ema_slow'].isna().iloc[-2]:
            return None
            
        current = df.iloc[-2]
        previous = df.iloc[-3]
        
        price = df.iloc[-1]['close']
        atr = current['atr']
        
        # Điều kiện MUA (LONG)
        ema_up = current['ema_fast'] > current['ema_mid'] and current['ema_mid'] > current['ema_slow']
        rsi_buy_ok = (100 - self.params.get('rsi_overbought', 65)) < current['rsi'] < self.params.get('rsi_overbought', 65)
        trend_strong = current['adx'] > self.params.get('adx_threshold', 25)
        vol_ok = current['volume'] > current['vol_sma'] * self.params.get('vol_ratio', 1.5)
        
        # Điều kiện BÁN (SHORT)
        ema_down = current['ema_fast'] < current['ema_mid'] and current['ema_mid'] < current['ema_slow']
        # Trong sóng xả dốc đứng (ADX > 25), cho phép RSI giảm sâu tới 20 để bắt trọn sóng giảm
        min_rsi_sell = 20 if trend_strong else self.params.get('rsi_oversold', 30)
        rsi_sell_ok = min_rsi_sell < current['rsi'] < (100 - self.params.get('rsi_oversold', 30))
        
        # Kiểm tra khoảng cách tới EMA21 (Pullback filter):
        ema_mid_val = float(current['ema_mid'])
        near_ema_long = (price >= ema_mid_val * 0.985) and ((price - ema_mid_val) / ema_mid_val <= 0.025)
        max_dist_short = 0.040 if trend_strong else 0.025
        near_ema_short = (price <= ema_mid_val * 1.015) and ((ema_mid_val - price) / ema_mid_val <= max_dist_short)

        if ema_up and rsi_buy_ok and trend_strong and vol_ok and near_ema_long:
            stop_loss = price - (atr * self.params.get('atr_multiplier_sl', 1.5))
            take_profit = price + (atr * self.params.get('atr_multiplier_tp', 3.0))
            
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=0.8,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'rsi': current['rsi'], 'adx': current['adx'], 'atr': atr, 'volume': current['volume']}
            )
            
        elif ema_down and rsi_sell_ok and trend_strong and vol_ok and near_ema_short:
            stop_loss = price + (atr * self.params.get('atr_multiplier_sl', 1.5))
            take_profit = price - (atr * self.params.get('atr_multiplier_tp', 3.0))
            
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=0.8,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'rsi': current['rsi'], 'adx': current['adx'], 'atr': atr, 'volume': current['volume']}
            )
            
        return TradeSignal(
            signal=Signal.HOLD,
            symbol=symbol,
            confidence=0.0,
            strategy=self.name,
            price=price
        )
