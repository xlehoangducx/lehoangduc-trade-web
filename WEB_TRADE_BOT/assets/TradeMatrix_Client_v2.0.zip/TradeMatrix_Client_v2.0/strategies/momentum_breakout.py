import numpy as np
import pandas as pd
from typing import Optional
from .base_strategy import BaseStrategy, TradeSignal, Signal

class MomentumBreakoutStrategy(BaseStrategy):
    """
    Chiến thuật Momentum & Breakout.
    Phát hiện các cú sập (Breakdown) hoặc bứt phá (Breakout) mạnh mẽ với khối lượng lớn.
    Giúp bot không bỏ lỡ các đợt bão (như cú sập BTC) khi RSI đã quá bán.
    """
    def __init__(self, name: str = "MomentumBreakout", config: dict = None):
        if config is None:
            config = {
                'params': {
                    'bb_period': 20,
                    'bb_std': 2.0,
                    'adx_threshold': 25,
                    'vol_multiplier': 1.5,
                    'atr_multiplier_sl': 1.5,
                    'atr_multiplier_tp': 3.0
                }
            }
        super().__init__(name, config)

    def get_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        import ta
        if df is None or len(df) < max(self.params.get('bb_period', 20), 20):
            return df
            
        df = df.copy()
        
        # Bollinger Bands
        bb = ta.volatility.BollingerBands(
            df['close'], 
            window=self.params.get('bb_period', 20), 
            window_dev=self.params.get('bb_std', 2.0)
        )
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_upper'] = bb.bollinger_hband()
        
        # Volume SMA
        df['vol_sma'] = df['volume'].rolling(window=self.params.get('bb_period', 20)).mean()
        
        # ATR
        df['atr'] = ta.volatility.AverageTrueRange(
            df['high'], df['low'], df['close'], window=14
        ).average_true_range()
        
        # ADX
        adx_indicator = ta.trend.ADXIndicator(
            df['high'], df['low'], df['close'], window=14
        )
        df['adx'] = adx_indicator.adx()
        
        return df

    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[TradeSignal]:
        df = self.get_indicators(df)
        if (
            df is None
            or len(df) < 50
            or 'atr' not in df.columns
            or 'vol_sma' not in df.columns
            or 'bb_lower' not in df.columns
            or pd.isna(df['atr'].iloc[-2])
            or pd.isna(df['vol_sma'].iloc[-2])
        ):
            return None
            
        # Kiểm tra Breakout & Volume trên nến ĐÃ ĐÓNG CỬA HOÀN CHỈNH (iloc[-2]) so với nến trước đó (iloc[-3])
        current = df.iloc[-2]
        previous = df.iloc[-3]
        
        price = float(df.iloc[-1]['close'])
        atr = float(current['atr'])
        
        # Điều kiện Động lượng (Momentum) & Thanh khoản
        strong_momentum = current['adx'] > self.params.get('adx_threshold', 25)
        high_volume = current['volume'] > current['vol_sma'] * self.params.get('vol_multiplier', 1.5)
        
        # 1. BREAKDOWN (Sập mạnh xuyên thủng dải Bollinger dưới) -> BÁN (SHORT)
        # Bỏ qua RSI oversold, ưu tiên xung lực mạnh
        is_breakdown = (
            current['close'] < current['bb_lower'] and
            previous['close'] >= previous['bb_lower'] and
            strong_momentum and high_volume
        )
        
        # 2. BREAKOUT (Bơm mạnh xuyên thủng dải Bollinger trên) -> MUA (LONG)
        is_breakout = (
            current['close'] > current['bb_upper'] and
            previous['close'] <= previous['bb_upper'] and
            strong_momentum and high_volume
        )
        
        if is_breakdown:
            stop_loss = price + atr * self.params.get('atr_multiplier_sl', 1.5)
            take_profit = price - atr * self.params.get('atr_multiplier_tp', 3.0)
            return TradeSignal(
                signal=Signal.SELL,
                symbol=symbol,
                confidence=0.90,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'BREAKDOWN', 'adx': current['adx']}
            )
            
        elif is_breakout:
            stop_loss = price - atr * self.params.get('atr_multiplier_sl', 1.5)
            take_profit = price + atr * self.params.get('atr_multiplier_tp', 3.0)
            return TradeSignal(
                signal=Signal.BUY,
                symbol=symbol,
                confidence=0.90,
                strategy=self.name,
                price=price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                metadata={'type': 'BREAKOUT', 'adx': current['adx']}
            )
            
        return None
