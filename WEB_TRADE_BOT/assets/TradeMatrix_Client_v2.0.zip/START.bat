@echo off
reg add "HKCU\Console" /f /v "FaceName" /t REG_SZ /d "Consolas" >nul 2>&1
reg add "HKCU\Console" /f /v "CodePage" /t REG_DWORD /d 65001 >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "FaceName" /t REG_SZ /d "Consolas" >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "FontFamily" /t REG_DWORD /d 54 >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "FontSize" /t REG_DWORD /d 1048576 >nul 2>&1
reg add "HKCU\Console\TRADE BOT" /f /v "CodePage" /t REG_DWORD /d 65001 >nul 2>&1
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONWARNINGS=ignore
title TRADEMATRIX QUANT CLIENT v2.0

cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" (
    echo [ERROR] Chua cai dat. Chay install.bat truoc.
    pause
    exit /b 1
)

if not exist "data" mkdir data
if not exist "data\historical" mkdir data\historical
if not exist "data\models" mkdir data\models
if not exist "logs" mkdir logs

w32tm /resync /nowait >nul 2>&1

echo.
echo  ======================================================
echo   TRADEMATRIX QUANT CLIENT v2.0 - Starting...
echo   Web Terminal: http://127.0.0.1:5000
echo   He thong giao dich tu dong Binance Futures
echo  ======================================================
echo.

echo [1/2] Kiem tra va giai phong Port 5000 (chong xung dot tien trinh treo)...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }" >nul 2>&1
timeout /t 1 /nobreak >nul

echo [2/2] Mo man hinh cho va khoi chay Trade Bot...
start "" "%~dp0loading.html"

:run_bot
"venv\Scripts\python.exe" -X utf8 run_web.py
if errorlevel 1 (
    echo.
    echo [WARNING] Trade Bot vua dung bat thuong. Thu khoi dong lai sau 10 giay...
    timeout /t 10 /nobreak >nul
    goto run_bot
)

pause
