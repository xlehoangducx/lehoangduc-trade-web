from flask import Flask, render_template, jsonify, request, Response
import logging
import json
import math
import os
import shutil
import threading
import csv
import io
import ipaddress
from datetime import datetime
from urllib.parse import urlparse

try:
    import yaml
except Exception:  # pragma: no cover - yaml là dependency bắt buộc
    yaml = None

logger = logging.getLogger(__name__)

# Thread lock cho thread-safe access
_bot_lock = threading.Lock()
_bot_thread = None
# Khóa chống chạy 2 chu kỳ phân tích song song (loop chính + /api/run_cycle)
_cycle_lock = threading.Lock()


def _as_finite_float(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _is_trusted_local_origin(origin: str) -> bool:
    """Origin có phải máy nội bộ (localhost hoặc IP LAN) hay không.

    Dùng cho CORS: chỉ cho phép chính máy này / mạng LAN nội bộ, chặn mọi website internet.
    """
    if not origin:
        return False
    try:
        host = (urlparse(origin).hostname or '').strip().lower()
    except Exception:
        return False
    if not host:
        return False
    if host in ('localhost', '::1', '127.0.0.1'):
        return True
    if host.endswith('.local'):
        return True
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return False
    return bool(addr.is_loopback or addr.is_private)


def _read_settings_for_write(settings_path):
    """Đọc settings.yaml cho thao tác GHI. Trả (dict, thông điệp lỗi).

    [SỬA LỖI GỐC RỄ - XOÁ SẠCH CẤU HÌNH]
    Trước đây /api/cloud_token đọc file và nuốt MỌI ngoại lệ thành {} rồi ghi đè bằng
    yaml.dump. Chỉ một lần đọc lỗi (file đang bị ghi dở hoặc antivirus khoá) là TOÀN BỘ
    settings.yaml (risk, trading, ai, exchange, quantum_gate, tradfi...) bị xoá sạch,
    chỉ còn lại đúng nhánh cloud. Hậu quả: sau lần khởi động kế tiếp bot chạy bằng
    cấu hình mặc định (risk 0.6%?, max_open_positions mặc định...) và mất hết tinh chỉnh.
    Nay: đọc lỗi thì TỪ CHỐI GHI, tuyệt đối không ghi đè mù.
    """
    try:
        with open(settings_path, 'r', encoding='utf-8') as f:
            loaded = yaml.safe_load(f) if yaml else None
    except FileNotFoundError:
        return {}, None
    except Exception as e:
        return None, (
            'Không đọc được settings.yaml nên TỪ CHỐI ghi để tránh xoá sạch cấu hình: '
            f'{e}'
        )
    if loaded is None:
        return {}, None
    if not isinstance(loaded, dict):
        return None, 'settings.yaml không phải mapping hợp lệ; từ chối ghi để bảo vệ cấu hình.'
    return loaded, None


def _atomic_write_settings(settings_path, settings):
    """Ghi settings.yaml NGUYÊN TỬ (tmp + os.replace) và giữ bản .bak.

    [SỬA LỖI GỐC RỄ - FILE CỤT]
    Trước đây mở file ở chế độ 'w' (truncate) rồi dump thẳng. Trong khoảng thời gian đói I/O,
    cloud_sync.py đọc lại file mỗi 5 giây và có thể đọc đúng lúc file rỗng/cụt -> YAML lỗi
    -> token bị coi như rỗng -> bot live bị "khoá bản quyền" và DỪNG. Nay ghi ra file tạm
    cùng thư mục rồi os.replace (nguyên tử trên cùng ổ đĩa), độc giả chỉ thấy bản cũ hoặc
    bản mới hoàn chỉnh, không bao giờ thấy bản cụt.
    """
    tmp_path = settings_path.with_name(settings_path.name + '.tmp')
    backup_path = settings_path.with_name(settings_path.name + '.bak')
    payload = yaml.dump(settings, default_flow_style=False, allow_unicode=True, sort_keys=False)
    if not payload or not payload.strip():
        raise ValueError('Nội dung settings rỗng; huỷ ghi để bảo vệ cấu hình.')
    with open(tmp_path, 'w', encoding='utf-8') as f:
        f.write(payload)
        f.flush()
        os.fsync(f.fileno())
    try:
        if settings_path.exists():
            shutil.copy2(settings_path, backup_path)
    except Exception as e:
        logger.warning('Không tạo được bản sao lưu settings.yaml: %s', e)
    os.replace(tmp_path, settings_path)
    return backup_path


def _closed_position_outcomes(trades, mode, quote_asset, market_type='futures'):
    """Count completed position cycles, not individual exchange fills."""
    outcomes = {'wins': 0, 'losses': 0, 'breakeven': 0}
    completed_order_ids = set()

    def record(net_pnl):
        if net_pnl > 1e-8:
            outcomes['wins'] += 1
        elif net_pnl < -1e-8:
            outcomes['losses'] += 1
        else:
            outcomes['breakeven'] += 1

    if mode == 'live':
        fills = [trade for trade in trades if trade.get('exchange_trade_id') is not None]
        fills.sort(key=lambda trade: (
            _as_finite_float(trade.get('timestamp')),
            _as_finite_float(trade.get('id')),
        ))
        positions = {}
        for trade in fills:
            symbol = str(trade.get('symbol') or '')
            side = str(trade.get('side') or '').strip().lower()
            position_side = str(trade.get('position_side') or 'BOTH').strip().upper()
            quantity = abs(_as_finite_float(trade.get('amount')))
            if not symbol or side not in ('buy', 'sell') or quantity <= 0:
                continue

            # Represent BOTH positions as signed quantity. In hedge mode,
            # LONG and SHORT each use positive quantity in their own direction.
            direction = 1.0 if side == 'buy' else -1.0
            if position_side == 'SHORT':
                direction *= -1.0
            delta = direction * quantity
            key = (symbol, position_side)
            state = positions.get(key)
            gross_pnl = _as_finite_float(
                trade.get('realized_pnl') if trade.get('realized_pnl') is not None
                else trade.get('pnl')
            )
            fee = _as_finite_float(trade.get('fee'))
            fee_asset = str(trade.get('commission_asset') or quote_asset).upper()
            quote_fee = fee if fee_asset == str(quote_asset).upper() else 0.0
            is_spot = str(market_type or '').lower() == 'spot'
            price = _as_finite_float(trade.get('price'))
            if is_spot:
                gross_pnl = 0.0

            if state is None or abs(state['quantity']) <= 1e-12:
                # A nonzero realized PnL with no observed opening fill means
                # the local history starts mid-position; don't guess its result.
                if (is_spot and delta < 0) or (not is_spot and abs(gross_pnl) > 1e-8):
                    continue
                positions[key] = {
                    'quantity': delta,
                    'gross_pnl': gross_pnl,
                    'fee': quote_fee,
                    'cost': price * quantity if is_spot else 0.0,
                }
                continue

            current = state['quantity']
            if current * delta > 0:
                state['quantity'] = current + delta
                state['gross_pnl'] += gross_pnl
                state['fee'] += quote_fee
                if is_spot:
                    state['cost'] += price * quantity
                continue

            # The fill reduces or closes the current position. Assign its fee
            # to the closed size; if it reverses direction, the remainder opens
            # a new cycle and carries its proportional entry fee.
            closed_quantity = min(abs(current), abs(delta))
            close_ratio = closed_quantity / quantity
            if is_spot:
                average_entry = state['cost'] / abs(current) if abs(current) > 0 else 0.0
                state['gross_pnl'] += (price - average_entry) * closed_quantity
                state['cost'] = max(0.0, state['cost'] - average_entry * closed_quantity)
            else:
                state['gross_pnl'] += gross_pnl
            state['fee'] += quote_fee * close_ratio
            remaining_quantity = abs(delta) - closed_quantity
            new_quantity = current + delta
            if abs(new_quantity) <= 1e-12:
                record(state['gross_pnl'] - state['fee'])
                if trade.get('order_id') is not None:
                    completed_order_ids.add(str(trade.get('order_id')))
                if remaining_quantity > 1e-12:
                    positions[key] = {
                        'quantity': math.copysign(remaining_quantity, delta),
                        'gross_pnl': 0.0,
                        'fee': quote_fee * (1.0 - close_ratio),
                        'cost': price * remaining_quantity if is_spot else 0.0,
                    }
                else:
                    positions.pop(key, None)
            else:
                state['quantity'] = new_quantity

    # Demo close summaries, and live closes without a matching exchange fill,
    # already store net position PnL. Matching live summaries are filtered by
    # get_trades because the fill replay above accounts for those orders.
    for trade in trades:
        if (trade.get('exchange_trade_id') is None
                and str(trade.get('status') or '').lower() == 'closed'
                and trade.get('pnl') is not None):
            if (mode == 'live' and trade.get('order_id') is not None
                    and str(trade.get('order_id')) in completed_order_ids):
                continue
            record(_as_finite_float(trade.get('pnl')))

    outcomes['closed_trade_count'] = sum(outcomes.values())
    return outcomes


def create_app(bot=None):
    app = Flask(__name__)
    app.bot = bot
    
    @app.after_request
    def add_cors_headers(response):
        # [SỬA LỖI GỐC RỄ - CORS MỞ TOANG TOÀN BỘ API NỘI BỘ]
        # Trước đây trả `Access-Control-Allow-Origin: *` cho MỌI route, kể cả POST
        # /api/stop, /api/start, /api/run_cycle, /api/cloud_token, /api/set_balance,
        # lại còn bật `Access-Control-Allow-Private-Network: true`. Nghĩa là BẤT KỲ
        # website nào người dùng mở cũng đọc được /api/config, /api/status, lấy user
        # token, đổi API key hoặc dừng bot đang gồng lệnh thật (CSRF + lộ dữ liệu).
        # Nay chỉ cấp CORS cho origin cùng máy / LAN nội bộ. Request same-origin của
        # chính dashboard không cần header này nên không bị ảnh hưởng.
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS, PUT, DELETE'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
        origin = request.headers.get('Origin', '')
        if origin and _is_trusted_local_origin(origin):
            response.headers['Access-Control-Allow-Origin'] = origin
            response.headers['Vary'] = 'Origin'
            response.headers['Access-Control-Allow-Private-Network'] = 'true'
        return response

    @app.route('/')
    def index():
        return render_template('index.html')
    
    @app.route('/api/status')
    def api_status():
        if app.bot:
            st = app.bot.get_status()
            try:
                from core.gate_telemetry import get_top_radar_candidates
                st['radar_candidates'] = get_top_radar_candidates(limit=6)
            except Exception:
                st['radar_candidates'] = []
            return jsonify(st)
        return jsonify({'error': 'Bot not initialized'})

    @app.route('/api/radar')
    def api_radar():
        try:
            from core.gate_telemetry import get_top_radar_candidates
            return jsonify(get_top_radar_candidates(limit=6))
        except Exception as e:
            return jsonify({'error': str(e), 'candidates': []})
    
    @app.route('/api/trades')
    def api_trades():
        if app.bot and app.bot.db:
            limit = max(1, min(request.args.get('limit', 100, type=int), 500))
            offset = max(0, min(request.args.get('offset', 0, type=int), 1_000_000))
            trades = app.bot.db.get_trades(mode=app.bot.mode, limit=limit, offset=offset)
            return jsonify(trades)
        return jsonify([])

    @app.route('/api/trades/export.csv')
    def api_trades_export():
        if not app.bot or not app.bot.db:
            return jsonify({'error': 'Bot not initialized'}), 503
        stream = io.StringIO(newline='')
        writer = csv.writer(stream)
        columns = [
            'timestamp', 'symbol', 'side', 'type', 'status', 'price', 'amount', 'cost',
            'fee', 'commission_asset', 'realized_pnl', 'order_id', 'exchange_trade_id',
            'client_order_id', 'position_side', 'maker', 'strategy', 'raw_json',
        ]
        writer.writerow(columns)
        offset = 0
        while True:
            page = app.bot.db.get_trades(mode=app.bot.mode, limit=1000, offset=offset)
            if not page:
                break
            for trade in page:
                writer.writerow([trade.get(column) for column in columns])
            offset += len(page)
            if len(page) < 1000:
                break
        return Response(
            '\ufeff' + stream.getvalue(),
            mimetype='text/csv; charset=utf-8',
            headers={'Content-Disposition': f'attachment; filename=trade-history-{app.bot.mode}.csv'},
        )
    
    @app.route('/api/trades/sync', methods=['POST'])
    def api_trades_sync():
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot chưa khởi tạo'}), 503
        try:
            synced = 0
            if hasattr(app.bot, '_sync_exchange_trade_history'):
                app.bot._history_market_discovery_done = False
                res = app.bot._sync_exchange_trade_history()
                synced = int(res or 0)
            return jsonify({
                'success': True,
                'synced': synced,
                'message': f'Đã đồng bộ thành công từ Binance API ({synced} fills mới)'
            })
        except Exception as e:
            logger.error(f'Lỗi đồng bộ giao dịch Binance: {e}')
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/performance')
    def api_performance():
        if app.bot and app.bot.db:
            try:
                trades = []
                offset = 0
                while True:
                    page = app.bot.db.get_trades(mode=app.bot.mode, limit=1000, offset=offset)
                    if not page:
                        break
                    trades.extend(page)
                    offset += len(page)
                    if len(page) < 1000:
                        break

                # A local order summary and its later Binance fill rows describe
                # the same order. Count the exchange fills once they are present.
                fill_order_ids = {
                    str(t.get('order_id')) for t in trades
                    if t.get('exchange_trade_id') is not None and t.get('order_id') is not None
                }
                if app.bot.mode == 'live' and fill_order_ids:
                    trades = [
                        t for t in trades
                        if not (
                            t.get('exchange_trade_id') is None
                            and t.get('order_id') is not None
                            and str(t.get('order_id')) in fill_order_ids
                        )
                    ]

                quote = app.bot.config.get('trading', {}).get('base_currency', 'USDT')
                fees_by_asset = {}
                for trade in trades:
                    if trade.get('fee'):
                        asset = trade.get('commission_asset') or quote
                        fees_by_asset[asset] = fees_by_asset.get(asset, 0.0) + float(trade['fee'])
                position_outcomes = _closed_position_outcomes(
                    trades, app.bot.mode, quote,
                    getattr(app.bot, 'market_type', 'futures'),
                )

                now_dt = datetime.now()
                today_start_dt = datetime(now_dt.year, now_dt.month, now_dt.day, 0, 0, 0)
                today_start_ms = int(today_start_dt.timestamp() * 1000)

                total_pnl = 0.0
                today_pnl = 0.0
                today_trades_count = 0
                today_fees = 0.0

                for trade in trades:
                    trade_ts = int(trade.get('timestamp') or 0)
                    fee = float(trade.get('fee') or 0) if (trade.get('commission_asset') or quote) == quote else 0.0
                    if trade.get('realized_pnl') is not None:
                        row_pnl = float(trade['realized_pnl']) - fee
                    elif trade.get('status') == 'open':
                        row_pnl = -fee
                    else:
                        # Local simulated/summary closing rows already store net PnL.
                        row_pnl = float(trade.get('pnl') or 0)
                    total_pnl += row_pnl

                    if trade_ts >= today_start_ms:
                        today_pnl += row_pnl
                        today_fees += fee
                        today_trades_count += 1

                return jsonify({
                    'winning_trades': position_outcomes['wins'],
                    'losing_trades': position_outcomes['losses'],
                    'breakeven_trades': position_outcomes['breakeven'],
                    'closed_trade_count': position_outcomes['closed_trade_count'],
                    'total_trades': position_outcomes['closed_trade_count'],
                    'win_rate': (
                        100.0 * position_outcomes['wins']
                        / (position_outcomes['wins'] + position_outcomes['losses'])
                        if position_outcomes['wins'] + position_outcomes['losses'] else None
                    ),
                    'quote_asset': quote,
                    'total_pnl': total_pnl,
                    'total_fees': fees_by_asset.get(quote, 0.0),
                    'fees_by_asset': fees_by_asset,
                    'today_pnl': today_pnl,
                    'today_trades_count': today_trades_count,
                    'today_fees': today_fees,
                })
            except Exception as e:
                logger.error(f'Performance calc error: {e}')
        return jsonify({
            'winning_trades': 0, 'losing_trades': 0, 'breakeven_trades': 0,
            'closed_trade_count': 0, 'win_rate': None, 'total_pnl': 0,
            'total_fees': 0, 'today_pnl': 0, 'today_trades_count': 0, 'today_fees': 0,
        })
    
    @app.route('/api/daily_pnl')
    def api_daily_pnl():
        if app.bot and app.bot.db:
            days = request.args.get('days', 30, type=int)
            days = max(1, min(days, 365))  # Validate range
            quote = app.bot.config.get('trading', {}).get('base_currency', 'USDT')
            return jsonify(app.bot.db.get_daily_pnl(days=days, mode=app.bot.mode, quote_currency=quote))
        return jsonify([])
    
    @app.route('/api/positions')
    def api_positions():
        if app.bot:
            return jsonify(app.bot.get_dashboard_positions())
        return jsonify([])

    @app.route('/api/positions/close', methods=['POST'])
    def api_close_position():
        """Close one displayed position at market and notify the user."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        data = request.get_json(silent=True) or {}
        symbol = data.get('symbol')
        direction = data.get('direction')
        if not isinstance(symbol, str) or not symbol.strip():
            return jsonify({'success': False, 'error': 'Thiếu mã giao dịch.'}), 400
        if direction is not None and (not isinstance(direction, str) or direction.upper().strip() not in ('LONG', 'SHORT')):
            return jsonify({'success': False, 'error': 'Chiều vị thế không hợp lệ.'}), 400
        result = app.bot.close_position_manually(symbol.strip(), direction)
        return jsonify(result), (200 if result.get('success') else 409)
    
    @app.route('/api/market')
    def api_market():
        if app.bot and app.bot.exchange:
            pairs = set(app.bot.config.get('trading', {}).get('pairs', ['BTC/USDT', 'ETH/USDT']))
            with app.bot._position_lock:
                pairs.update(pos['symbol'] for pos in app.bot.open_positions)
            prices = app.bot.exchange.get_live_prices(list(pairs))
            return jsonify(prices)
        return jsonify({})
    
    # ===== BOT CONTROL ENDPOINTS =====
    
    @app.route('/api/start', methods=['POST'])
    def api_start():
        """Khởi chạy bot trading trong background thread."""
        global _bot_thread
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'})
        
        
        if app.bot.is_running or (_bot_thread and _bot_thread.is_alive()):
            return jsonify({'success': False, 'error': 'Bot đang chạy hoặc chu kỳ cũ chưa kết thúc'})
        
        try:
            data = request.json or {}
            interval = int(data.get('interval', 60))
            if not 1 <= interval <= 86400:
                return jsonify({'success': False, 'error': 'Interval phải từ 1 đến 86400 giây'}), 400

            start_error = app.bot.prepare_to_start()
            if start_error:
                return jsonify({'success': False, 'error': start_error}), 409

            # Preflight License Check từ Cloud Firestore
            try:
                import yaml
                from pathlib import Path
                settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
                with open(settings_path, 'r', encoding='utf-8') as sf:
                    cfg = yaml.safe_load(sf) or {}
                raw_tokens = cfg.get('cloud', {}).get('user_token', '')
                if isinstance(raw_tokens, list):
                    cloud_tokens = [str(t).strip() for t in raw_tokens if str(t).strip()]
                elif isinstance(raw_tokens, str):
                    cloud_tokens = [t.strip() for t in raw_tokens.split(',') if t.strip()]
                else:
                    cloud_tokens = []
                if not cloud_tokens:
                    return jsonify({
                        'success': False,
                        'error': 'Bản quyền chưa kích hoạt! Vui lòng nhập User Token hợp lệ từ web TradeMatrix.'
                    }), 403

                import requests
                proj = cfg.get('cloud', {}).get('project_id', 'trade-bot-platform')
                license_approved = False
                license_revoked = False
                for cloud_token in cloud_tokens:
                    cmd_r = requests.get(f"https://firestore.googleapis.com/v1/projects/{proj}/databases/(default)/documents/bot_commands/{cloud_token}", timeout=4)
                    if cmd_r.status_code == 200:
                        cmd_fields = cmd_r.json().get('fields', {})
                        cmd_license = cmd_fields.get('license_status', {}).get('stringValue', '').lower()
                        if cmd_license == 'approved':
                            license_approved = True
                            break
                        if cmd_license in ('revoked', 'blocked'):
                            license_revoked = True
                            break
                    check_r = requests.get(f"https://firestore.googleapis.com/v1/projects/{proj}/databases/(default)/documents/users/{cloud_token}", timeout=4)
                    if check_r.status_code == 200:
                        u_fields = check_r.json().get('fields', {})
                        u_status = u_fields.get('status', {}).get('stringValue', 'pending')
                        u_role = u_fields.get('role', {}).get('stringValue', 'user')
                        if u_role == 'admin' or u_status == 'approved':
                            license_approved = True
                            break
                if license_revoked:
                    return jsonify({'success': False, 'error': 'Quyền sử dụng token đã bị thu hồi/khóa.'}), 403
                if not license_approved:
                    return jsonify({
                        'success': False,
                        'error': 'Không xác minh được token TradeMatrix được phê duyệt; từ chối khởi động fail-closed.'
                    }), 403
            except Exception as ce:
                logger.error(f"Preflight license check exception: {ce}")
                return jsonify({'success': False, 'error': 'Không kiểm tra được bản quyền; từ chối khởi động fail-closed.'}), 503
            
            def run_bot():
                try:
                    app.bot.start(interval_seconds=interval, preflight_done=True)
                except Exception as e:
                    logger.error(f"Bot thread error: {e}")
            
            _bot_thread = threading.Thread(target=run_bot, daemon=True)
            _bot_thread.start()
            
            return jsonify({'success': True, 'message': f'Bot đã bắt đầu chạy (interval: {interval}s)'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
    
    @app.route('/api/stop', methods=['POST'])
    def api_stop():
        """Dừng bot trading an toàn."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'})
        
        if not app.bot.is_running:
            return jsonify({'success': False, 'error': 'Bot chưa chạy'})
        
        try:
            app.bot.stop()
            return jsonify({
                'success': True,
                'message': 'Bot đã dừng; vị thế LIVE không bị tự đóng và lệnh bảo vệ Binance vẫn được giữ nếu đã đặt thành công.',
            })
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
    
    @app.route('/api/pause', methods=['POST'])
    def api_pause():
        """Tạm dừng bot (dừng nhưng giữ trạng thái)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'})
        
        try:
            app.bot.stop()
            return jsonify({
                'success': True,
                'message': 'Bot đã dừng; vị thế LIVE không bị tự đóng và lệnh bảo vệ Binance được giữ nguyên nếu đã đặt thành công.',
            })
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
    
    @app.route('/api/run_cycle', methods=['POST'])
    def api_run_cycle():
        """Chạy 1 chu kỳ phân tích thủ công (không cần start liên tục)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'})

        # [SỬA LỖI GỐC RỄ - CHẠY CHU KỲ SONG SONG]
        # Trước đây endpoint này gọi thẳng app.bot.run_cycle() không có bất kỳ khóa nào.
        # - Nếu bot đang chạy loop 60s, một cú POST (kể cả từ trang web khác nhờ CORS '*')
        #   sẽ chạy chu kỳ THỨ HAI song song: cả hai cùng thấy slot trống, cùng mở lệnh
        #   cho cùng cặp -> nhân đôi vị thế, vượt hạn mức rủi ro/đòn bẩy.
        # - Nếu bấm 2 lần liên tiếp, hai chu kỳ chồng nhau cũng gây hiệu ứng tương tự.
        # Nay: từ chối khi bot đang chạy, và chỉ cho phép 1 chu kỳ thủ công tại một thời điểm.
        if getattr(app.bot, 'is_running', False) or (_bot_thread and _bot_thread.is_alive()):
            return jsonify({
                'success': False,
                'error': 'Bot đang chạy loop tự động; chu kỳ đã được xử lý tự động, không chạy chồng.',
            }), 409

        if not _cycle_lock.acquire(blocking=False):
            return jsonify({
                'success': False,
                'error': 'Đang có một chu kỳ thủ công chạy dở; chờ chu kỳ đó kết thúc.',
            }), 409

        try:
            app.bot.run_cycle()
            return jsonify({'success': True, 'message': 'Đã chạy xong 1 chu kỳ'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
        finally:
            _cycle_lock.release()
    
    @app.route('/api/set_balance', methods=['POST'])
    def api_set_balance():
        """Set demo balance - nhập số tiền muốn thử nghiệm."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'})
        if app.bot.mode != 'demo':
            return jsonify({'success': False, 'error': 'Only in DEMO mode'})
        try:
            if app.bot.is_running:
                return jsonify({'success': False, 'error': 'Dừng bot trước khi đổi vốn DEMO.'}), 409
            if app.bot.open_positions:
                return jsonify({'success': False, 'error': 'Đóng các vị thế DEMO trước khi đổi vốn.'}), 409
            data = request.json or {}
            new_balance = float(data.get('balance', 0))
            if not math.isfinite(new_balance) or new_balance < 1:
                return jsonify({'success': False, 'error': 'Min $1'})
            if new_balance > 1000000:
                return jsonify({'success': False, 'error': 'Max $1,000,000'})
            if app.bot.db.get_trades(mode='demo', limit=1):
                return jsonify({
                    'success': False,
                    'error': 'Xóa lịch sử DEMO trước khi đặt lại vốn để không trộn hai mốc vốn.'
                }), 409
            app.bot.balance = new_balance
            app.bot.peak_balance = new_balance
            app.bot.config['trading']['initial_capital'] = new_balance
            app.bot._demo_initial_capital = new_balance
            app.bot.trade_count = 0
            app.bot._save_state()
            return jsonify({'success': True, 'balance': new_balance})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})

    @app.route('/api/clear_history', methods=['POST'])
    def api_clear_history():
        """Reset toàn bộ nhật ký và lịch sử trong chế độ hiện tại."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'})
        
        mode = app.bot.mode
        try:
            if app.bot.is_running:
                return jsonify({
                    'success': False,
                    'error': 'Dừng bot trước khi xóa lịch sử để tránh ghi trạng thái mới đồng thời.'
                }), 409
            if mode == 'live':
                app.bot.sync_live_positions_with_exchange()
                if app.bot.open_positions:
                    return jsonify({
                        'success': False,
                        'error': 'Không thể xóa lịch sử khi còn vị thế LIVE đang mở; hãy đóng hoặc đối soát vị thế trước.'
                    }), 409
            elif app.bot.open_positions:
                return jsonify({
                    'success': False,
                    'error': 'Không thể xóa lịch sử khi còn vị thế DEMO đang mở; hãy đóng vị thế trước.'
                }), 409

            # Xóa lịch sử trong sqlite cho mode hiện tại; lỗi DB không được trả success giả.
            if not app.bot.db.clear_history(mode):
                return jsonify({'success': False, 'error': 'Không xóa được lịch sử trong database; không có dữ liệu nào được xác nhận xóa.'}), 500
            
            # Reset biến bộ nhớ
            if mode == 'demo':
                app.bot.open_positions = []
            app.bot.trade_count = 0
            
            # Nếu là live thì lấy số dư thật, nếu demo thì lấy initial capital
            if mode == 'demo':
                app.bot.balance = app.bot.config['trading']['initial_capital']
            else:
                if getattr(app.bot, 'market_type', 'spot') == 'futures':
                    bal = app.bot.exchange.get_futures_balance()
                    app.bot.balance = float(bal.get('free', 0))
                else:
                    bal = app.bot.exchange.get_balance()
                    base_currency = app.bot.config['trading'].get('base_currency', 'USDT')
                    app.bot.balance = bal.get(base_currency, {}).get('free', 0)
                    
            app.bot.peak_balance = app.bot.balance
            app.bot._save_state()
            
            mode_str = "LIVE" if mode == 'live' else "Demo"
            return jsonify({'success': True, 'message': f'Đã xóa trắng lịch sử {mode_str}!'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})

    @app.route('/api/optimize', methods=['POST'])
    def api_optimize():
        """Chạy bộ optimizer ở local background."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'})
            
        def run_opt():
            try:
                import sys
                from pathlib import Path
                root_dir = Path(__file__).parent.parent
                if str(root_dir) not in sys.path:
                    sys.path.insert(0, str(root_dir))
                
                # Gọi Ollama LLM Manager để tư duy trước
                try:
                    from ai.ollama_agent import OllamaManagerAgent
                    llm_agent = OllamaManagerAgent(str(root_dir))
                    result = llm_agent.analyze_and_tune()
                    if result and 'error' not in result:
                        logger.info("LLM Agent đã hoàn tất phiên giám sát.")
                    else:
                        logger.warning(f"LLM Agent lỗi hoặc không kết nối: {result.get('error')}. Chuyển sang AI Toán học truyền thống...")
                except ImportError:
                    logger.warning("Không tìm thấy OllamaManagerAgent.")
                
                # Sau đó chạy Optimizer Toán học
                from core.optimizer import StrategyOptimizer
                opt = StrategyOptimizer(str(root_dir / 'config' / 'settings.yaml'))
                opt.run_optimization()
                
                # Nạp lại config mới cho bot đang chạy
                app.bot.strategy_config = app.bot._load_config(str(root_dir / "config" / "strategies.yaml"))
                logger.info("Đã nạp lại cấu hình trực tiếp vào Bot đang chạy.")
                
            except Exception as e:
                logger.error(f"Optimizer error: {e}")
                
        threading.Thread(target=run_opt, daemon=True).start()
        return jsonify({'success': True, 'message': 'Đã khởi động tiến trình AI Local (Ollama + Math Optimizer) ở chạy ngầm!'})
        
    @app.route('/api/ollama/status')
    def api_ollama_status():
        """Kiểm tra trạng thái Ollama và lấy danh sách model."""
        import requests
        try:
            res = requests.get('http://localhost:11434/api/tags', timeout=2)
            if res.status_code == 200:
                models = [m['name'] for m in res.json().get('models', [])]
                # Đọc model đang chọn trong settings
                import yaml
                from pathlib import Path
                settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
                current_model = 'llama3'
                try:
                    with open(settings_path, 'r', encoding='utf-8') as f:
                        settings = yaml.safe_load(f)
                        current_model = settings.get('ai', {}).get('ollama_model', 'llama3')
                except Exception: pass
                
                return jsonify({'running': True, 'models': models, 'current': current_model})
        except Exception:
            pass
        return jsonify({'running': False, 'models': []})
        
    @app.route('/api/ollama/set_model', methods=['POST'])
    def api_ollama_set_model():
        """Lưu model được chọn vào config."""
        data = request.json
        model_name = data.get('model')
        if model_name:
            import yaml
            from pathlib import Path
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            try:
                with open(settings_path, 'r', encoding='utf-8') as f:
                    settings = yaml.safe_load(f)
                
                if 'ai' not in settings: settings['ai'] = {}
                settings['ai']['ollama_model'] = model_name
                
                with open(settings_path, 'w', encoding='utf-8') as f:
                    yaml.dump(settings, f, default_flow_style=False, allow_unicode=True)
                return jsonify({'success': True})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)})
        return jsonify({'success': False})

    @app.route('/api/ai_status')
    def api_ai_status():
        """Trạng thái AI Brain hiện tại."""
        import yaml
        from pathlib import Path
        result = {'bias': 'NEUTRAL', 'reasoning': 'Chưa phân tích', 'target': 'ALL', 'last_updated': '--'}
        try:
            strat_path = Path(__file__).parent.parent / 'config' / 'strategies.yaml'
            with open(strat_path, 'r', encoding='utf-8') as f:
                strat = yaml.safe_load(f)
                ai_bias = strat.get('ai_bias', {})
                if ai_bias:
                    result['bias'] = ai_bias.get('direction', 'NEUTRAL')
                    result['reasoning'] = ai_bias.get('reasoning', 'Chưa phân tích')
                    result['target'] = ai_bias.get('target_coin', 'ALL')
                    result['last_updated'] = ai_bias.get('last_updated', '--')
        except Exception as e:
            logger.debug(f'AI status: {e}')
        
        # Check Ollama connection
        import requests
        try:
            res = requests.get('http://localhost:11434/api/tags', timeout=2)
            result['ollama_online'] = res.status_code == 200
        except Exception:
            result['ollama_online'] = False
        
        return jsonify(result)

    @app.route('/api/equity_curve')
    def api_equity_curve():
        """Return a reliable account curve for LIVE and trade history for DEMO."""
        if app.bot and app.bot.db:
            try:
                if app.bot.mode == 'live' and getattr(app.bot, 'market_type', 'spot') == 'futures':
                    status = app.bot.get_status()
                    equity = status.get('equity')
                    if equity is None:
                        return jsonify([])
                    initial = float(
                        status.get('invested_basis')
                        or status.get('initial_capital')
                        or app.bot.config['trading']['initial_capital']
                    )
                    return jsonify([
                        {'label': 'Mốc vốn PnL', 'balance': initial},
                        {'label': 'Binance hiện tại', 'balance': float(equity)},
                    ])

                trades = app.bot.db.get_trades(mode=app.bot.mode, limit=500)
                closed_trades = [t for t in trades if t.get('status') == 'closed' and t.get('pnl') is not None]
                closed_trades.reverse()  # oldest first
                
                initial = app.bot.config['trading']['initial_capital']
                curve = [{'label': 'Bắt đầu', 'balance': initial}]
                running = initial
                for t in closed_trades:
                    pnl = float(t.get('pnl', 0))
                    running += pnl
                    quote = app.bot.config.get('trading', {}).get('base_currency', 'USDT')
                    sym = (t.get('symbol', '') or '').removesuffix('/' + quote)
                    time_str = ''
                    if t.get('timestamp'):
                        from datetime import datetime
                        try:
                            ts = int(t['timestamp'])
                            if ts > 1e12: ts = ts // 1000
                            time_str = datetime.fromtimestamp(ts).strftime('%H:%M')
                        except Exception: pass
                    curve.append({'label': f'{sym} {time_str}', 'balance': round(running, 2)})
                return jsonify(curve)
            except Exception as e:
                logger.error(f'Equity curve error: {e}')
        return jsonify([])

    @app.route('/api/switch_mode', methods=['POST'])
    def switch_mode():
        data = request.json
        mode = data.get('mode', 'demo')
        if app.bot:
            try:
                if mode == 'live':
                    app.bot.switch_mode(mode, data.get('api_key'), data.get('api_secret'))
                else:
                    app.bot.switch_mode('demo')
                return jsonify({'success': True, 'mode': mode})
            except RuntimeError as e:
                return jsonify({'success': False, 'error': str(e)}), 409
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)})
        return jsonify({'success': False, 'error': 'Bot not initialized'})
    
    @app.route('/api/sentiment')
    def api_sentiment():
        """Lấy AI sentiment analysis từ các nguồn miễn phí."""
        try:
            from ai.news_sentiment import NewsSentimentAnalyzer
            analyzer = NewsSentimentAnalyzer()
            
            result = {}
            
            # Fear & Greed Index
            result['fear_greed'] = analyzer.get_fear_greed_index()
            
            # Composite sentiment for primary pair
            symbol = 'BTC'
            if app.bot and app.bot.config.get('trading', {}).get('pairs'):
                symbol = app.bot.config['trading']['pairs'][0].split('/')[0]
            result['composite'] = analyzer.get_composite_sentiment(symbol)
            
            # Market overview
            coin_map = {'BTC': 'bitcoin', 'ETH': 'ethereum'}
            result['market'] = analyzer.get_market_overview(coin_map.get(symbol, 'bitcoin'))
            
            # Market regime detection
            try:
                from ai.market_regime import MarketRegimeDetector
                detector = MarketRegimeDetector()
                if app.bot and app.bot.data_collector:
                    pair = app.bot.config['trading']['pairs'][0]
                    df = app.bot.data_collector.get_cached_data(pair, '1h')
                    if df is not None and len(df) > 100:
                        reg_obj = detector.detect_regime(df)
                        result['regime'] = reg_obj.value if hasattr(reg_obj, 'value') else str(reg_obj)
            except Exception as e:
                logger.debug(f"Regime detection not available: {e}")
            
            # Thêm TradFi Macro vĩ mô Wall Street (S&P 500, Nasdaq, DXY, Vàng)
            try:
                result['tradfi_macro'] = analyzer.get_tradfi_macro()
            except Exception as te:
                logger.debug(f"TradFi macro not available: {te}")
            
            return jsonify(result)
        except ImportError:
            return jsonify({'error': 'AI modules not available yet'})
        except Exception as e:
            return jsonify({'error': str(e)})
    
    @app.route('/api/logs')
    def api_logs():
        """Lấy log gần nhất cho real-time viewer."""
        import os
        from pathlib import Path
        
        lines = request.args.get('lines', 30, type=int)
        lines = max(1, min(lines, 200))
        
        try:
            root_dir = Path(__file__).parent.parent
            log_dir = root_dir / 'logs'
            
            # Tìm file log mới nhất
            log_files = sorted(log_dir.glob('bot_*.log'), reverse=True)
            if not log_files:
                return jsonify({'logs': ['No log files found']})
            
            latest_log = log_files[0]
            with open(latest_log, 'r', encoding='utf-8', errors='replace') as f:
                # Bo qua access log cua werkzeug de Live Console tren web chi hien thi log trade
                filtered = [line.strip() for line in f if line.strip() and 'werkzeug:' not in line]
                recent = filtered[-lines:] if len(filtered) > lines else filtered
                return jsonify({'logs': recent})
        except Exception as e:
            return jsonify({'logs': [f'Error reading logs: {e}']})
    
    @app.route('/api/keys', methods=['GET', 'POST', 'DELETE'])
    def api_keys():
        import os
        import yaml
        from dotenv import load_dotenv, set_key
        
        env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
        settings_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
        
        # Load settings to get Telegram config
        try:
            with open(settings_path, 'r', encoding='utf-8') as f:
                settings = yaml.safe_load(f) or {}
        except Exception:
            settings = {}
            
        if request.method == 'GET':
            load_dotenv(env_path)
            api_key = os.getenv('BINANCE_API_KEY', '')
            masked = api_key[:4] + '***' + api_key[-4:] if len(api_key) > 8 else ''
            
            load_dotenv(env_path)
            tele_token = os.getenv('TELEGRAM_BOT_TOKEN', '')
            tele_chat = os.getenv('TELEGRAM_CHAT_ID', '')
            tele_masked = tele_token[:4] + '***' + tele_token[-4:] if len(tele_token) > 8 else ''
            
            return jsonify({
                'has_key': bool(api_key), 
                'masked_key': masked,
                'tele_token': tele_masked,
                'tele_chat': tele_chat
            })
            
        elif request.method == 'POST':
            data = request.json or {}
            key = data.get('api_key')
            secret = data.get('api_secret')
            tele_token = data.get('tele_token')
            tele_chat = data.get('tele_chat')
            
            if not os.path.exists(env_path):
                open(env_path, 'w').close()
                
            if key and secret:
                set_key(env_path, 'BINANCE_API_KEY', key)
                set_key(env_path, 'BINANCE_API_SECRET', secret)
                
            # Keep Telegram credentials in .env, not in settings.yaml.
            if tele_token or tele_chat:
                if tele_token == "DELETE":
                    set_key(env_path, 'TELEGRAM_BOT_TOKEN', '')
                elif tele_token:
                    set_key(env_path, 'TELEGRAM_BOT_TOKEN', tele_token)
                    
                if tele_chat == "DELETE":
                    set_key(env_path, 'TELEGRAM_CHAT_ID', '')
                elif tele_chat:
                    set_key(env_path, 'TELEGRAM_CHAT_ID', str(tele_chat))
                
                # Cập nhật bot trong memory
                if app.bot:
                    load_dotenv(env_path, override=True)
                
            load_dotenv(env_path, override=True)
            return jsonify({'success': True, 'msg': 'Đã lưu cấu hình thành công! (Telegram có hiệu lực ngay lập tức)'})
            
        elif request.method == 'DELETE':
            if os.path.exists(env_path):
                set_key(env_path, 'BINANCE_API_KEY', '')
                set_key(env_path, 'BINANCE_API_SECRET', '')
            return jsonify({'success': True, 'msg': 'Đã xóa Binance API Key thành công!'})

    @app.route('/api/telegram/test', methods=['POST'])
    def api_telegram_test():
        import os
        from dotenv import load_dotenv
        load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'), override=True)
        token = os.getenv('TELEGRAM_BOT_TOKEN', '')
        chat_id = os.getenv('TELEGRAM_CHAT_ID', '')
        if not token or not chat_id:
            return jsonify({'success': False, 'error': 'Chưa cấu hình Telegram bot token và chat ID.'}), 400
        from core.telegram_notifier import send_telegram_message
        if not send_telegram_message(token, chat_id, '✅ TRADE BOT: kiểm tra kết nối Telegram thành công.'):
            return jsonify({'success': False, 'error': 'Telegram không nhận tin nhắn; kiểm tra token, chat ID và quyền gửi tin.'}), 502
        return jsonify({'success': True, 'message': 'Đã gửi tin nhắn kiểm tra đến Telegram.'})

    @app.route('/api/cloud_token', methods=['GET', 'POST', 'DELETE'])
    def api_cloud_token():
        from pathlib import Path
        settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'

        if request.method == 'GET':
            settings, read_error = _read_settings_for_write(settings_path)
            if read_error:
                return jsonify({'success': False, 'error': read_error}), 500
            user_token = str(settings.get('cloud', {}).get('user_token', '') or '').strip()
            masked = (user_token[:6] + '...' + user_token[-4:]) if len(user_token) > 10 else user_token
            return jsonify({
                'has_token': bool(user_token),
                'user_token': user_token,
                'masked_token': masked
            })

        # POST/DELETE đều GHI file: bắt buộc phải đọc được bản hiện tại trước đã.
        settings, read_error = _read_settings_for_write(settings_path)
        if read_error:
            logger.error('❌ [CLOUD TOKEN] %s', read_error)
            return jsonify({'success': False, 'error': read_error}), 500

        is_post = request.method == 'POST'
        if is_post:
            data = request.json or {}
            token = str(data.get('user_token', '') or '').strip()
            if 'cloud' not in settings or not isinstance(settings.get('cloud'), dict):
                settings['cloud'] = {}
            settings['cloud']['user_token'] = token
            settings['cloud']['enabled'] = bool(token)
            success_msg = 'Đã lưu User Token thành công! Dữ liệu sẽ tự động đồng bộ lên Web TradeMatrix.'
        else:
            if isinstance(settings.get('cloud'), dict):
                settings['cloud']['user_token'] = ''
            success_msg = 'Đã ngắt kết nối đồng bộ Web!'

        try:
            _atomic_write_settings(settings_path, settings)
        except Exception as e:
            logger.error('❌ [CLOUD TOKEN] Ghi settings.yaml thất bại: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

        # Đọc lại để xác nhận file vẫn hợp lệ và đúng nội dung vừa ghi
        verified, verify_error = _read_settings_for_write(settings_path)
        if verify_error or not isinstance(verified, dict):
            return jsonify({
                'success': False,
                'error': f'File cấu hình không đọc lại được sau khi ghi ({verify_error}). '
                         f'Bản sao lưu: config/settings.yaml.bak',
            }), 500
        if 'risk' not in verified or 'trading' not in verified:
            logger.error('❌ [CLOUD TOKEN] settings.yaml sau khi ghi THIẾU nhánh gốc (risk/trading) - trả lỗi.')
            return jsonify({
                'success': False,
                'error': 'Cấu hình sau khi ghi thiếu nhánh gốc; đã giữ bản .bak để khôi phục.',
            }), 500

        if app.bot and isinstance(getattr(app.bot, 'config', None), dict):
            bot_cloud = app.bot.config.setdefault('cloud', {})
            if isinstance(bot_cloud, dict):
                bot_cloud['user_token'] = settings.get('cloud', {}).get('user_token', '')
                bot_cloud['enabled'] = settings.get('cloud', {}).get('enabled', False)

        return jsonify({'success': True, 'msg': success_msg})

    @app.route('/api/config')
    def api_config():
        """Lấy cấu hình hiện tại (không bao gồm secrets)."""
        if app.bot:
            config = dict(app.bot.config)
            # Ẩn API keys
            if 'exchange' in config:
                config['exchange'] = dict(config['exchange'])
                config['exchange']['api_key'] = '***' if config['exchange'].get('api_key') else ''
                config['exchange']['api_secret'] = '***' if config['exchange'].get('api_secret') else ''
            return jsonify(config)
        return jsonify({})

    @app.route('/api/leverage', methods=['POST'])
    def api_set_max_leverage():
        """Set and persist the dynamic leverage ceiling for demo and live."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            raw_value = float(data.get('max_leverage'))
            if not raw_value.is_integer() or not 1 <= raw_value <= 150:
                return jsonify({
                    'success': False,
                    'error': 'Giới hạn đòn bẩy phải là số nguyên từ 1x đến 150x.',
                }), 400
            max_leverage = int(raw_value)

            from pathlib import Path
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            lines = settings_path.read_bytes().decode('utf-8').splitlines(keepends=True)
            trading_start = next(
                (i for i, line in enumerate(lines) if line.strip() == 'trading:'),
                None,
            )
            if trading_start is None:
                return jsonify({'success': False, 'error': 'Không tìm thấy phần trading trong settings.yaml.'}), 500
            trading_end = len(lines)
            for i in range(trading_start + 1, len(lines)):
                stripped = lines[i].strip()
                if stripped and not stripped.startswith('#') and not lines[i][0].isspace():
                    trading_end = i
                    break

            leverage_line = next(
                (i for i in range(trading_start + 1, trading_end)
                 if lines[i].lstrip().startswith('max_leverage:')),
                None,
            )
            if leverage_line is not None:
                current_line = lines[leverage_line]
                indent = current_line[:len(current_line) - len(current_line.lstrip())]
                newline = '\r\n' if current_line.endswith('\r\n') else ('\n' if current_line.endswith('\n') else '')
                comment = f"  #{current_line.split('#', 1)[1].rstrip()}" if '#' in current_line else ''
                lines[leverage_line] = f'{indent}max_leverage: {max_leverage}{comment}{newline}'
            else:
                insert_at = trading_end
                while insert_at > trading_start + 1 and not lines[insert_at - 1].strip():
                    insert_at -= 1
                newline = next(
                    ('\r\n' if line.endswith('\r\n') else '\n' for line in lines[trading_start:trading_end] if line.endswith(('\r\n', '\n'))),
                    '\n',
                )
                lines.insert(insert_at, f'  max_leverage: {max_leverage}{newline}')
            settings_path.write_bytes(''.join(lines).encode('utf-8'))

            app.bot.config.setdefault('trading', {})['max_leverage'] = max_leverage
            return jsonify({
                'success': True,
                'max_leverage': max_leverage,
                'message': f'Đã lưu trần đòn bẩy động: {max_leverage}x (áp dụng cho lệnh mới ở DEMO và LIVE).',
            })
        except (TypeError, ValueError, OverflowError):
            return jsonify({'success': False, 'error': 'Giá trị đòn bẩy không hợp lệ.'}), 400
        except Exception as e:
            logger.error('Could not save max leverage: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/positions_limit', methods=['POST'])
    def api_set_positions_limit():
        """Set and persist the dynamic position limits (min and max) for demo and live."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            raw_min = float(data.get('min_open_trades', 1))
            raw_max = float(data.get('max_open_trades', 5))
            
            min_trades = max(1, min(20, int(raw_min)))
            max_trades = max(min_trades, min(20, int(raw_max)))

            from pathlib import Path
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            settings, load_error = _read_settings_for_write(settings_path)
            if load_error:
                return jsonify({'success': False, 'error': load_error}), 500
            settings.setdefault('trading', {})['max_open_trades'] = max_trades
            settings['trading']['min_open_trades'] = min_trades
            current_risk_cap = int(settings.setdefault('risk', {}).get('max_open_positions', 10) or 10)
            settings['risk']['max_open_positions'] = max(current_risk_cap, max_trades)
            _atomic_write_settings(settings_path, settings)

            app.bot.config.setdefault('trading', {})['max_open_trades'] = max_trades
            app.bot.config['trading']['min_open_trades'] = min_trades
            app.bot.config.setdefault('risk', {})['max_open_positions'] = settings['risk']['max_open_positions']

            return jsonify({
                'success': True,
                'min_open_trades': min_trades,
                'max_open_trades': max_trades,
                'message': f'Đã lưu giới hạn vị thế tự điều phối: {min_trades} đến {max_trades} lệnh (áp dụng cho DEMO & LIVE).',
            })
        except (TypeError, ValueError, OverflowError):
            return jsonify({'success': False, 'error': 'Giá trị vị thế không hợp lệ.'}), 400
        except Exception as e:
            logger.error('Could not save positions limit: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/tradfi/toggle', methods=['POST'])
    def api_tradfi_toggle():
        """Bật / Tắt chế độ giao dịch Hợp đồng Cổ phiếu Mỹ (TradFi Stock Perps).
        Hỗ trợ 3 chế độ:
        1. Chỉ Crypto: enabled=False, only_tradfi=False
        2. Cả Hai (Crypto + Cổ phiếu): enabled=True, only_tradfi=False
        3. Chỉ Cổ phiếu: enabled=True, only_tradfi=True
        """
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            current_tradfi = app.bot.config.get('tradfi', {})
            
            has_enabled = 'enabled' in data
            has_only = 'only_tradfi' in data
            
            enabled = bool(data.get('enabled')) if has_enabled else bool(current_tradfi.get('enabled', False))
            only_tradfi = bool(data.get('only_tradfi')) if has_only else bool(current_tradfi.get('only_tradfi', False))
            
            # Ràng buộc trạng thái UI:
            if only_tradfi:
                enabled = True
            elif has_enabled and not enabled:
                only_tradfi = False

            from pathlib import Path
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            lines = settings_path.read_bytes().decode('utf-8').splitlines(keepends=True)
            tradfi_start = next(
                (i for i, line in enumerate(lines) if line.strip() == 'tradfi:'),
                None,
            )
            if tradfi_start is not None:
                tradfi_end = len(lines)
                for i in range(tradfi_start + 1, len(lines)):
                    stripped = lines[i].strip()
                    if stripped and not stripped.startswith('#') and not lines[i][0].isspace():
                        tradfi_end = i
                        break

                def update_or_insert_tradfi(key, val_bool):
                    nonlocal lines, tradfi_end
                    line_idx = next(
                        (i for i in range(tradfi_start + 1, tradfi_end)
                         if lines[i].lstrip().startswith(f'{key}:')),
                        None,
                    )
                    val_str = 'true' if val_bool else 'false'
                    if line_idx is not None:
                        current_line = lines[line_idx]
                        indent = current_line[:len(current_line) - len(current_line.lstrip())]
                        newline = '\r\n' if current_line.endswith('\r\n') else '\n'
                        comment = f"  #{current_line.split('#', 1)[1].rstrip()}" if '#' in current_line else ''
                        lines[line_idx] = f'{indent}{key}: {val_str}{comment}{newline}'
                    else:
                        newline = '\n'
                        lines.insert(tradfi_start + 1, f'  {key}: {val_str}{newline}')
                        tradfi_end += 1

                update_or_insert_tradfi('enabled', enabled)
                update_or_insert_tradfi('only_tradfi', only_tradfi)
                settings_path.write_bytes(''.join(lines).encode('utf-8'))

            app.bot.config.setdefault('tradfi', {})['enabled'] = enabled
            app.bot.config['tradfi']['only_tradfi'] = only_tradfi

            if only_tradfi:
                mode_desc = "CHỈ CỔ PHIẾU MỸ (TẮT CRYPTO)"
            elif enabled:
                mode_desc = "CẢ HAI (CRYPTO + CỔ PHIẾU MỸ)"
            else:
                mode_desc = "CHỈ CRYPTO (TẮT CỔ PHIẾU)"

            logger.info("Chế độ TradFi Stock Perps đã cập nhật: %s", mode_desc)
            return jsonify({
                'success': True,
                'enabled': enabled,
                'only_tradfi': only_tradfi,
                'mode_desc': mode_desc,
                'message': f"Đã chuyển sang chế độ: {mode_desc}."
            })
        except Exception as e:
            logger.error('Could not toggle TradFi: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/manual_adopt/toggle', methods=['POST'])
    def api_manual_adopt_toggle():
        """Bật / Tắt chế độ Tự động bảo hộ và quản lý lệnh tay (Auto-Adopt Manual Positions)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            current_val = getattr(app.bot, 'auto_adopt_manual_positions', False)
            enabled = bool(data.get('enabled')) if 'enabled' in data else not current_val
            app.bot.auto_adopt_manual_positions = enabled
            
            from pathlib import Path
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            lines = settings_path.read_bytes().decode('utf-8').splitlines(keepends=True)
            trading_start = next((i for i, line in enumerate(lines) if line.strip() == 'trading:'), None)
            if trading_start is not None:
                trading_end = len(lines)
                for i in range(trading_start + 1, len(lines)):
                    stripped = lines[i].strip()
                    if stripped and not stripped.startswith('#') and not lines[i][0].isspace():
                        trading_end = i
                        break
                key = 'auto_adopt_manual_positions'
                val_str = 'true' if enabled else 'false'
                line_idx = next((i for i in range(trading_start + 1, trading_end) if lines[i].lstrip().startswith(f'{key}:')), None)
                if line_idx is not None:
                    current_line = lines[line_idx]
                    indent = current_line[:len(current_line) - len(current_line.lstrip())]
                    newline = '\r\n' if current_line.endswith('\r\n') else '\n'
                    comment = f"  #{current_line.split('#', 1)[1].rstrip()}" if '#' in current_line else ''
                    lines[line_idx] = f'{indent}{key}: {val_str}{comment}{newline}'
                else:
                    newline = '\n'
                    lines.insert(trading_start + 1, f'  {key}: {val_str}{newline}')
                settings_path.write_bytes(''.join(lines).encode('utf-8'))
            
            logger.info("Chế độ Tự Động Bảo Hộ & Quản Lý Lệnh Tay đã cập nhật: %s", "BẬT" if enabled else "TẮT")
            return jsonify({
                'success': True,
                'auto_adopt_manual_positions': enabled,
                'message': f"Đã {'BẬT' if enabled else 'TẮT'} chế độ Tự Động Bảo Hộ Lệnh Tay."
            })
        except Exception as e:
            logger.error('Could not toggle manual adopt: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/free_roll_recycling/toggle', methods=['POST'])
    def api_free_roll_recycling_toggle():
        """Bật / Tắt chế độ Gia Tăng Vị Thế Khi Bảo Toàn Vốn (Free-Roll Slot Recycling)."""
        if not app.bot:
            return jsonify({'success': False, 'error': 'Bot not initialized'}), 503
        try:
            data = request.get_json(silent=True) or {}
            current_val = getattr(app.bot, 'free_roll_recycling', True)
            enabled = bool(data.get('enabled')) if 'enabled' in data else not current_val
            app.bot.free_roll_recycling = enabled
            
            from pathlib import Path
            settings_path = Path(__file__).parent.parent / 'config' / 'settings.yaml'
            lines = settings_path.read_bytes().decode('utf-8').splitlines(keepends=True)
            trading_start = next((i for i, line in enumerate(lines) if line.strip() == 'trading:'), None)
            if trading_start is not None:
                trading_end = len(lines)
                for i in range(trading_start + 1, len(lines)):
                    stripped = lines[i].strip()
                    if stripped and not stripped.startswith('#') and not lines[i][0].isspace():
                        trading_end = i
                        break
                
                key = 'free_roll_recycling'
                val_str = 'true' if enabled else 'false'
                line_idx = next(
                    (i for i in range(trading_start + 1, trading_end) if lines[i].lstrip().startswith(f'{key}:')),
                    None
                )
                if line_idx is not None:
                    current_line = lines[line_idx]
                    indent = current_line[:len(current_line) - len(current_line.lstrip())]
                    newline = '\r\n' if current_line.endswith('\r\n') else '\n'
                    comment = f"  #{current_line.split('#', 1)[1].rstrip()}" if '#' in current_line else ''
                    lines[line_idx] = f'{indent}{key}: {val_str}{comment}{newline}'
                else:
                    newline = '\n'
                    lines.insert(trading_start + 1, f'  {key}: {val_str}{newline}')
                settings_path.write_bytes(''.join(lines).encode('utf-8'))
            
            logger.info("Chế độ Gia Tăng Vị Thế Khi Bảo Toàn Vốn đã cập nhật: %s", "BẬT" if enabled else "TẮT")
            return jsonify({
                'success': True,
                'free_roll_recycling': enabled,
                'message': f"Đã {'BẬT' if enabled else 'TẮT'} chế độ Gia Tăng Vị Thế Khi Bảo Toàn Vốn."
            })
        except Exception as e:
            logger.error('Could not toggle free roll recycling: %s', e)
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/health')
    def health():
        """Health check endpoint."""
        return jsonify({
            'status': 'ok',
            'bot_running': app.bot.is_running if app.bot else False,
            'market_type': app.bot.config.get('trading', {}).get('market_type', 'spot') if app.bot else 'unknown',
            'timestamp': datetime.now().isoformat()
        })
    
    return app

