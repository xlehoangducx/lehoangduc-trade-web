# TRADEMATRIX QUANT ECOSYSTEM - MASTER REFERENCE & GROUND TRUTH
## TÀI LIỆU TOÀN DIỆN VỀ KIẾN TRÚC HỆ THỐNG, BỐI CẢNH 2 MÁY TÍNH, NỀN TẢNG WEB, THUẬT TOÁN BOT & KHO DỮ LIỆU ĐIỂM CHUẨN LỊCH SỬ

> **Phiên bản:** TradeMatrix v2.0 Enterprise & Micro Defense System  
> **Tác giả & Nhà phát triển:** **Lê Hoàng Đức**  
> **Mục đích tài liệu:** Bản ghi nguồn sự thật duy nhất (Single Source of Truth - SSOT). Khi tạo một hội thoại mới (*New Conversation in Project*), tài liệu này cung cấp 100% bối cảnh kiến trúc, quy trình làm việc giữa 2 máy tính, thuật toán phòng vệ, và toàn bộ kho dữ liệu lệnh lịch sử để không bao giờ bị mất điểm chuẩn (benchmarks).

---

## MỤC LỤC
1. [Bối Cảnh Vận Hành & Kiến Trúc Phân Bổ 2 Máy Tính](#1-bối-cảnh-vận-hành--kiến-trúc-phân-bổ-2-máy-tính)
2. [Hệ Sinh Thái Web & Động Cơ Giao Diện 3D](#2-hệ-sinh-thái-web--động-cơ-giao-diện-3d)
3. [Kiến Trúc Bộ Lõi Tool Bot (TradeMatrix Client v2.0)](#3-kiến-trúc-bộ-lõi-tool-bot-tradematrix-client-v20)
4. [Bộ 5 Tầng Phòng Vệ Vi Mô & Cổng Pre-Trade Safety Gate](#4-bộ-5-tầng-phòng-vệ-vi-mô--cổng-pre-trade-safety-gate)
5. [Kho Dữ Liệu Lệnh Lịch Sử & Điểm Chuẩn Đối Chứng Thực Nghiệm](#5-kho-dữ-liệu-lệnh-lịch-sử--điểm-chuẩn-đối-chứng-thực-nghiệm)
6. [Kế Hoạch Quản Trị & Bảo Tồn Dữ Liệu Lịch Sử Điểm Chuẩn](#6-kế-hoạch-quản-trị--bảo-tồn-dữ-liệu-lịch-sử-điểm-chuẩn)
7. [Hướng Dẫn Dành Cho AI Khi Mở Hội Thoại Mới (New Conversation Guide)](#7-hướng-dẫn-dành-cho-ai-khi-mở-hội-thoại-mới-new-conversation-guide)
8. [Lịch Sử Tiến Hóa & Các Đợt Nâng Cấp Chiến Lược (21/10 - 24/10)](#8-lịch-sử-tiến-hóa--các-đợt-nâng-cấp-chiến-lược-2110---2410)
9. [Quy Tắc Bắt Buộc Khi Sửa Code & Chính Sách Dọn Rác Nghiêm Ngặt](#9-quy-tắc-bắt-buộc-khi-sửa-code--chính-sách-dọn-rác-nghiêm-ngặt)

---

## 1. BỐI CẢNH VẬN HÀNH & KIẾN TRÚC PHÂN BỔ 2 MÁY TÍNH

Hệ thống TradeMatrix được vận hành trên **mô hình phân tán 2 máy tính cục bộ** qua mạng nội bộ (LAN):

```mermaid
flowchart LR
    subgraph PC1["💻 PC1: MÁY PHÁT TRIỂN CHÍNH (DEV MACHINE)"]
        A1["Thư mục Code: d:\\TRADE"]
        A2["Thư mục Web: D:\\WEB_TRADE_BOT"]
        A3["Môi trường: Google Antigravity IDE"]
        A4["Nhiệm vụ: Code, Test, Fix bug, Build Zip, Git Push"]
    end

    subgraph CLOUD["☁️ CLOUDFLARE PAGES / GITHUB"]
        G1["Repo: lehoangduc-trade-web"]
        G2["URL: lehoangduc.pages.dev"]
        G3["Tải Client: TradeMatrix_Client_v2.0.zip"]
    end

    subgraph PC2["🖥️ PC2: MÁY TREO TOOL THỰC CHIẾN 24/7"]
        B1["Đường dẫn mạng LAN: \\\\192.168.1.10\\trade-web\\assets\\TradeMatrix_Client_v2.0"]
        B2["Tài khoản: Gmail phụ / Account độc lập"]
        B3["Binance API: DÙNG CHUNG API TEST VỚI PC1"]
        B4["Nhiệm vụ: Chạy thực tế 24/7, Ghi log, Quản lý vị thế"]
    end

    PC1 -- "1. Git Push Web/Assets" --> CLOUD
    PC1 -- "2. Sync Code trực tiếp qua LAN" --> PC2
    CLOUD -- "3. Tải bản cập nhật" --> PC2
    PC2 -- "4. Bắn lệnh thực tế" --> BINANCE["🟡 BINANCE FUTURES REAL EXCHANGE"]
```

### 1.1. Chi tiết phân vai máy tính:
1. **Máy 1 (PC Phát Triển - Đang làm việc):**
   * **Thư mục mã nguồn:** `d:\TRADE` (bộ mã lõi bot), `D:\WEB_TRADE_BOT` (nền tảng web giới thiệu và đóng gói).
   * **Nhiệm vụ:** Viết mã, gỡ lỗi, kiểm định mô phỏng lịch sử (Backtest/Replay), đào tạo mô hình Machine Learning, đóng gói file `TradeMatrix_Client_v2.0.zip`, đẩy mã nguồn lên GitHub để Cloudflare Pages tự động Deploy.
2. **Máy 2 (PC Treo Tool Thực Chiến - 24/7):**
   * **Đường dẫn truy cập từ xa qua mạng nội bộ:** `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0`
   * **Bối cảnh tài khoản:** Máy này đăng nhập bằng 1 tài khoản Gmail khác (máy riêng), nhưng **dùng chung 1 bộ API Key Binance với Máy 1** nhằm mục đích kiểm tra và chạy thử nghiệm hiệu năng thực tế trước khi bàn giao cho bạn bè hoặc tích hợp API của người dùng khác.
   * **Môi trường thực thi:** Chạy trực tiếp qua file `START.bat` trên môi trường Python ảo `venv` riêng biệt, tích hợp máy chủ Ollama chạy model LLM `qwen2.5:7b` phân tích đa khung thời gian.

### 1.2. Quy trình đồng bộ chuẩn (Deployment Workflow):
Khi có bất kỳ chỉnh sửa hay sửa lỗi nào trên Máy 1:
1. **Bước 1:** Cập nhật code tại `d:\TRADE\core\bot.py` (hoặc module tương ứng).
2. **Bước 2:** Đồng bộ file trực tiếp sang PC treo: `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\...`
3. **Bước 3:** Đóng gói lại file `TradeMatrix_Client_v2.0.zip` và đẩy lên GitHub (`git push`) để web Cloudflare cập nhật.
4. **Bước 4:** Sang PC treo, đóng cửa sổ dòng lệnh hiện tại (`Ctrl + C` hoặc tắt cửa sổ đen) và nhấp đúp `START.bat` để Python nạp mã mới vào bộ nhớ RAM. Bot tự động khôi phục vị thế đang mở từ SQLite `trade_bot.db`.

---

## 2. HỆ SINH THÁI WEB & ĐỘNG CƠ GIAO DIỆN 3D

Nền tảng Web được thiết kế theo tiêu chuẩn công nghệ cao (Cyberpunk / Quantitative Trading Hub), lưu trữ tại thư mục `D:\WEB_TRADE_BOT` và xuất bản trực tiếp lên Internet qua Cloudflare Pages: **`https://lehoangduc.pages.dev`**.

### 2.1. Động cơ 3 Bánh Răng Truyền Động Thực & Tia Sét Ma Trận 3D:
* **Công nghệ:** HTML5 Canvas, Three.js, WebGL không nền đen (trong suốt 100%), không che khuất hiệu ứng sóng nến Three.js 3D phía sau.
* **Tỉ số truyền cơ khí chuẩn xác:**
  * Bánh răng Thép trái ($R=115\text{px}$, 24 răng): Quay thuận chiều kim đồng hồ (CW), chu kỳ 20.0 giây.
  * Bánh răng Titanium giữa ($R=82.8\text{px}$, 17 răng): Quay ngược chiều kim đồng hồ (CCW), chu kỳ 14.4 giây (ăn khớp 1:1 theo vận tốc tiếp tuyến vòm răng).
  * Bánh răng Vàng phải ($R=115\text{px}$, 24 răng): Quay thuận chiều kim đồng hồ (CW), chu kỳ 20.0 giây.
* **Hiệu ứng Nhịp Thở Động Lực Học (Breathing Animation):**
  * Cụm bánh răng co giãn nhịp nhàng từ tỉ lệ `0.94x` đến `1.16x` theo chu kỳ 8.5 giây.
* **Tia Sét Plasma Phân Nhánh & Dòng Ma Trận 2 Chiều:**
  * Tia sét điện toán đánh qua lại giữa các khớp răng cơ khí, cường độ biến thiên theo sóng điều hòa kép (lúc mạnh mẽ, lúc dịu êm).
  * Ma trận số nhị phân (`0101...`) lướt qua lại 2 chiều với mật độ luồng co giãn từ 6 đến 28 luồng.

### 2.2. Bố cục trang Web theo chỉ đạo của Người Sáng Lập:
1. **Mục Người Sáng Lập & Phát Triển (Author Section):**
   * Tiêu đề: **Lê Hoàng Đức · Người xây dựng và phát triển hệ thống TradeMatrix**.
   * Đặt trang trọng ngay trên phần giải thích cơ chế, minh chứng nguồn gốc và bản quyền công nghệ.
2. **Quy Trình 5 Tầng Phòng Vệ Vi Mô (Interactive Defense Pipeline):**
   * Trình chiếu dạng thẻ đồ họa kết nối dòng chảy từ *Tín hiệu vào* $\rightarrow$ *Tầng 1 (Cold-Start)* $\rightarrow$ *Tầng 2 (Dải ADX)* $\rightarrow$ *Tầng 3 (RSI/Wick Trap)* $\rightarrow$ *Tầng 4 (Micro Consensus)* $\rightarrow$ *Tầng 5 (SQLite Cooldown)* $\rightarrow$ *Chấp thuận vào lệnh*.
3. **5 Thẻ Tính Năng Nổi Bật (Cinematic Feature Cards):**
   * Hiệu ứng cuộn trang (Scroll-triggered cinematic reveals) độc lập cho từng thẻ: Tinh giản đòn bẩy động, Choke Trailing Stop, Bẫy cá mập TrapDetector, Đa khung thời gian MTF JEV Agent, Quản trị vốn Drawdown Shield.
4. **Bộ cài Client Download:**
   * Nút bấm tải trực tiếp gói [`TradeMatrix_Client_v2.0.zip`](file:///D:/WEB_TRADE_BOT/assets/TradeMatrix_Client_v2.0.zip) dung lượng ~35MB chứa toàn bộ engine độc lập, file cấu hình và database mẫu.

---

## 3. KIẾN TRÚC BỘ LÕI TOOL BOT (TRADEMATRIX CLIENT V2.0)

TradeMatrix là một hệ thống giao dịch định lượng cao cấp chạy hoàn toàn tự động, tích hợp giữa phân tích kỹ thuật truyền thống, mô hình học máy (Machine Learning) và trí tuệ nhân tạo Agentic LLM:

```mermaid
flowchart TD
    Scan["Multi-Threading Market Scanner<br/>(Quét 50 coin đồng thời mỗi 60s)"] --> Phase1["Pha 1: Lọc Nhanh Tín Hiệu Kỹ Thuật<br/>(Trend, Trap, Breakout, Mean Rev)"]
    Phase1 --> Filter1{"Có ít nhất 1 chiến thuật<br/>báo động?"}
    Filter1 -- "Không" --> Sleep["Nghỉ 60s chu kỳ kế tiếp"]
    Filter1 -- "Có" --> Phase2["Pha 2: Phân Tích Chuyên Sâu Đa Khung"]
    
    subgraph DeepAnalysis["Bộ Não Định Lượng Pha 2"]
        FE["Feature Engine<br/>(Sinh 91 đặc trưng định lượng)"]
        ML["ML Ensemble Model<br/>(Nạp model_{SYMBOL}.pkl tương ứng)"]
        JEV["JEV Agent LLM (qwen2.5:7b)<br/>(Phân tích cấu trúc nến 15m - 1h - 4h)"]
    end
    
    Phase2 --> DeepAnalysis
    DeepAnalysis --> Aggregator["Signal Aggregator<br/>(Tổng hợp điểm số & Tỷ lệ đồng thuận)"]
    Aggregator --> MicroDefenses{"Vượt qua 5 Tầng Phòng Vệ<br/>& Cổng Pre-Trade Safety Gate?"}
    MicroDefenses -- "Bị VETO" --> Reject["Hủy lệnh / Ghi log lý do"]
    MicroDefenses -- "PASS HOÀN TOÀN" --> Sizing["Dynamic Position Sizing & Leverage<br/>(Đòn bẩy 5x-10x, Ký quỹ <= 5% vốn)"]
    Sizing --> Execution["Binance Futures API<br/>(Gửi lệnh Market + Đặt sẵn SL/TP)"]
    Execution --> Monitor["Position Monitor (Quét mỗi 10s)<br/>(Grace Period 15m -> Co hẹp SL -> Choke Trailing Stop)"]
```

### 3.1. Các thành phần nòng cốt:
1. **Multi-Threading Market Scanner (`core/scanner.py`):**
   * Quét song song 50 đồng coin thanh khoản cao nhất toàn sàn Binance Futures cùng danh mục Cổ phiếu Mỹ (TradFi Stock Perps).
2. **Feature Engine 91 Chiều (`ai/feature_engine.py`):**
   * Tính toán tức thì 91 chỉ số kỹ thuật và vi mô: EMA20/50/200, RSI đa khung, MACD, Stochastic, Bollinger Bands, ATR, ADX/DMI, Order Flow Imbalance, RVol...
3. **ML Ensemble Models (`data/models/`):**
   * Mỗi đồng coin lớn (BTC, ETH, SOL, SNDK...) sở hữu một mô hình học máy chuyên biệt (`model_{SYMBOL}.pkl`) được huấn luyện với bài toán phân loại đa tầng.
4. **JEV Agent LLM (`ai/jev_agent.py`):**
   * Tích hợp trực tiếp máy chủ Ollama chạy mô hình cục bộ `qwen2.5:7b`.
   * Đọc cấu trúc thị trường đa khung thời gian (15M, 1H, 4H), kiểm tra khối lượng nến và đưa ra cảnh báo phá vỡ giả (Fakeout) hoặc phủ quyết bẫy đi ngang (Consolidation Veto).
5. **Cơ Chế Kép Crypto + Cổ Phiếu Mỹ TradFi (`risk/risk_manager.py`):**
   * Tự động lọc phiên New York (09:30 - 16:00 EST), áp dụng rào chắn cuối tuần (Weekend Shield), miễn trừ tương quan Crypto cho các mã cổ phiếu Mỹ như TSLA, NVDA, AAPL.

---

## 4. BỘ 5 TẦNG PHÒNG VỆ VI MÔ & CỔNG PRE-TRADE SAFETY GATE

Toàn bộ hệ thống phòng vệ được thiết kế để loại bỏ triệt để các lệnh thua trong lịch sử mà **không làm suy giảm bất kỳ lệnh thắng nào**:

```
[Tín Hiệu Vào Lệnh Từ Các Chiến Thuật]
                  │
                  ▼
┌────────────────────────────────────────────────────────┐
│ TẦNG 1: COLD-START WARMUP GUARD                        │
│ ➜ Model ML vừa huấn luyện lại cấp tốc?                 │
│ ➜ JEV Agent chưa khẳng định chắc chắn (HOLD/Conf < 80%)│
│ ➜ HỦY LỆNH (Tránh rủi ro mô hình chưa ổn định)         │
└──────────────────────────┬─────────────────────────────┘
                           │ PASS
                           ▼
┌────────────────────────────────────────────────────────┐
│ TẦNG 2: DẢI BIẾN ĐỘNG ĐỘNG LƯỢNG (ADX BOUNDARIES)      │
│ ➜ ADX < 22.0: Chặn Breakout yếu (Vùng sideway lừa đảo) │
│ ➜ 22.0 <= ADX < 55.0: Xu hướng phát triển mạnh (CHO PHÉP)│
│ ➜ ADX >= 55.0: Chặn Bơm xả cực hạn (Cấm đu đỉnh)       │
└──────────────────────────┬─────────────────────────────┘
                           │ PASS
                           ▼
┌────────────────────────────────────────────────────────┐
│ TẦNG 3: TRẠNG THÁI GIÁ & BẪY NẾN (RSI / WICK TRAP)     │
│ ➜ Lệnh SHORT có RSI 15M <= 35.0: CẤM SHORT ĐU ĐÁY      │
│   (Trừ khi TrapDetector xác nhận râu xả đỉnh Bull Trap)│
└──────────────────────────┬─────────────────────────────┘
                           │ PASS
                           ▼
┌────────────────────────────────────────────────────────┐
│ TẦNG 4: SÀN ĐỒNG THUẬN VI MÔ (MICRO CONSENSUS)         │
│ ➜ AI Ensemble >= 60%: Duyệt bình thường                │
│ ➜ AI 50% - 60%: Bắt buộc ADX >= 30.0 & ATR < 5.0% kèm  │
│   (>= 3 chiến thuật & >= 2 kỹ thuật) HOẶC (JEV >= 80%) │
│ ➜ Bắt buộc ít nhất 1 chiến thuật kỹ thuật độc lập      │
└──────────────────────────┬─────────────────────────────┘
                           │ PASS
                           ▼
┌────────────────────────────────────────────────────────┐
│ TẦNG 5: KHÓA PHẠT NGUỘI BẮT BUỘC (SQLITE COOLDOWN)     │
│ ➜ Cặp tiền vừa dính lệnh lỗ trong 180 phút qua?        │
│ ➜ CẤM VÀO LỆNH (Tránh giao dịch trả thù, đu đỉnh kép)  │
└──────────────────────────┬─────────────────────────────┘
                           │ PASS
                           ▼
┌────────────────────────────────────────────────────────┐
│ CỔNG AN TOÀN TRƯỚC KHI BẮN LỆNH (PRE-TRADE GATE)       │
│ ➜ RVol Gate: Nến đóng iloc[-2] có Volume >= 70% SMA20? │
│ ➜ Volume Exhaustion: Nến iloc[-2] không sụt giảm >50%  │
│   kèm râu từ chối giá (upper/lower shadow > body)      │
│ ➜ Funding Rate Extreme: Tránh phe Long/Short quá đông  │
│ ➜ Order Book Depth Imbalance: Tường cản < 3x           │
└──────────────────────────┬─────────────────────────────┘
                           │ PASS
                           ▼
                 [CHẤP THUẬN BẮN LỆNH LÊN SÀN]
```

### 4.1. Bài Học Xương Máu Về Nến Đóng Cửa (`iloc[-2]`) Tại Pre-Trade Gate:
* **Lỗi tiềm ẩn trước ngày 17/10:** Cổng Pre-Trade Gate lấy nhầm `df_tactical['volume'].iloc[-1]`. Trong nến 15 phút, nến `iloc[-1]` là nến đang chạy (chỉ mới hình thành 1-3 phút), nên khối lượng chỉ đạt 1.9% - 15% trung bình, dẫn đến việc hệ thống hiểu nhầm là "Thanh khoản cạn kiệt" và chặn oan toàn bộ 118 tín hiệu hợp lệ!
* **Quy chuẩn sửa lỗi dứt điểm:** Toàn bộ việc kiểm tra khối lượng phải được thực hiện trên **nến đã đóng cửa hoàn chỉnh (`iloc[-2]`)** đối chiếu với lịch sử các nến đã đóng trước đó (`iloc[:-2]`).

---

## 5. KHO DỮ LIỆU LỆNH LỊCH SỬ & ĐIỂM CHUẨN ĐỐI CHỨNG THỰC NGHIỆM

Đây là **kho tri thức thực nghiệm vô giá** được tích lũy qua toàn bộ lịch sử thực chiến trên Binance Futures từ ngày đầu tiên khởi chạy bot đến nay, đóng vai trò là "Thước đo đối chứng" (Ground Truth) để thẩm định mọi cải tiến thuật toán.

### 5.1. Toàn Bộ 203 Lệnh Thực Chiến Binance (Từ 28/09/2026 Đến 17/10/2026):
* **Nguồn dữ liệu gốc:** Trích xuất trực tiếp 100% từ API sàn Binance Futures (`fapiPrivateGetIncome`) và đồng bộ với database cục bộ `data/trade_bot.db`.
* **Tổng số giao dịch tài khoản (Income Transactions):** **431 bản ghi** (Lưu trữ vĩnh viễn tại [`data/ALL_BINANCE_INCOME_HISTORY.csv`](file:///d:/TRADE/data/ALL_BINANCE_INCOME_HISTORY.csv)).
* **Tổng số lệnh chốt PnL (Realized PnL Closes):** **203 lệnh** (Lưu trữ vĩnh viễn tại [`data/ALL_BINANCE_REALIZED_PNL_HISTORY.csv`](file:///d:/TRADE/data/ALL_BINANCE_REALIZED_PNL_HISTORY.csv)).
  * **Số lệnh Thắng (Wins):** **115 lệnh** (Tỷ lệ thắng thực tế: **56.7%**).
  * **Số lệnh Thua (Losses):** **88 lệnh** (43.3%).
  * **Số lệnh Hòa vốn (BE):** 0 lệnh.
  * **Tổng PnL thực tế tích lũy:** **`-4.8568 USDT`** (Mức lỗ rất nhỏ nhờ cơ chế kiểm soát Drawdown và vị thế nhỏ 5% vốn).
  * **Top 10 cặp tiền thực chiến nhiều nhất:** `SOXL/USDT` (10 lệnh), `SOL/USDT` (9 lệnh), `DUSK/USDT` (9 lệnh), `DOGE/USDT` (7 lệnh), `MANTA/USDT` (7 lệnh), `ZEC/USDC` (6 lệnh), `AXL/USDT` (6 lệnh), `HYPE/USDT` (5 lệnh), `S/USDT` (5 lệnh), `AGT/USDT` (4 lệnh).

### 5.2. Mối Quan Hệ Giữa "Tập Mẫu 105 Vị Thế" và "203 Lệnh Chốt PnL":
* **Làm rõ sự khác biệt:**
  * **203 Lệnh Realized PnL (431 giao dịch):** Là **TOÀN BỘ** lịch sử giao dịch từ ngày 28/09 đến 17/10 trên tài khoản Binance này.
  * **Tập mẫu 105 Vị thế (325 lượt Fills):** Là tập hợp 105 vị thế Round-trip liên tục (từ 29/09 đến 16/10) được trích xuất để làm **bài test giải phẫu nến 1m chuyên sâu**, hạch toán 100% phí Taker 0.05% cả 2 đầu.
* **Kết quả đối chứng trên tập 105 vị thế:**
  * Thuật toán phòng vệ vi mô cứu nguy và tăng lãi cho **42 vị thế** (+7.50 USDT).
  * Giảm **58.5% tổng mức lỗ ròng lịch sử** (từ `-7.94 USDT` về `-3.29 USDT`).
  * Rút ngắn thời gian ngâm lệnh từ **112.8 phút** xuống **31.7 phút** (triệt tiêu căn bệnh Zombie Bleeding giam lệnh âm 23 tiếng như LAB -9.45%, ERA -4.56%).

### 5.3. Giải Phẫu 4 Căn Bệnh Gốc Rễ Từ Lịch Sử Thua Lỗ:
| Căn Bệnh | Cặp Tiền Điển Hình | Dữ Liệu Lúc Vào Lệnh | Nguyên Nhân Bị Lừa | Cơ Chế Phòng Vệ Đã Thiết Lập Để Diệt Tận Gốc |
|---|---|---|---|---|
| **1. Bẫy Đu Đỉnh Bơm Xả Quá Độ (Climax Pump)** | `DUSK/USDT`<br/>(04:21 & 05:53 ngày 16/10) | `ADX = 62.8`<br/>`ATR = 6.49%`<br/>Giá đỉnh: 0.11015 | Nến 15m nằm trên EMA20/50 bị ngộ nhận là Strong Trend, thực chất là giai đoạn phân phối xả hàng. | **Tầng 2:** CẤM BUY Altcoin khi $\text{ADX} \ge 55.0$. Kích hoạt Cooldown 180 phút nếu dính lệnh lỗ. |
| **2. Bẫy Breakout Giả Vùng Sideway (Chop Trap)** | `TIA/USDT`<br/>(08:14 ngày 16/10) | `ADX = 19.1`<br/>MomentumBreakout báo 0.88 | Nến 15m vượt đỉnh trước nhưng trong vùng sideway nén biên độ, 85% chỉ là quét râu thanh khoản. | **Tầng 2:** CẤM `MomentumBreakout` kích hoạt khi $\text{ADX} < 22.0$ thiếu xác nhận Trend/Trap. |
| **3. Bẫy Bán Tháo Đu Đáy (Oversold Bottom)** | `SNDK/USDT` (21:21)<br/>`SOL/USDT` (23:08) | `RSI 15M = 28.0` (SNDK)<br/>`RSI 15M = 33.2` (SOL) | Thấy xu hướng 4H và 15M giảm nên SHORT đuổi đáy, đúng lúc phe bán cạn kiệt lực khiến giá bật hồi. | **Tầng 3:** CẤM SHORT khi $\text{RSI 15M} \le 35.0$ (trừ khi có râu xả đỉnh Bull Trap). |
| **4. Bẫy Bắt Đỉnh Cổ Phiếu Đầu Phiên (TradFi Flow)** | `INTC/USDT`<br/>(21:30 ngày 15/10) | Mở phiên New York,<br/>Vol mua cực lớn | Thấy râu nến 15m chững lại liền SHORT bắt đỉnh, nhưng dòng tiền tổ chức duy trì một chiều cả phiên. | **TradFi Guard:** Tách biệt quản trị rủi ro cổ phiếu Mỹ, cấm bắt đỉnh ngược dòng tiền mở phiên. |

### 5.3. Bảng Kiểm Định 31 Lệnh Ngày 16/10 (Sàn Đồng Thuận Vi Mô):
Bộ lọc **Sàn Đồng Thuận Vi Mô (Adaptive Micro Consensus)** giải quyết triệt để bài toán phân loại vùng AI 50% - 60%:

| Cặp Tiền | Thời Gian | PnL Thực Tế | Điểm AI | Số Chiến Thuật Đồng Thuận | Tác Động Của Bộ Lọc Vi Mô |
|---|---|---|---|---|---|
| **TAO/USDT** | 11:59 | **-0.0560 USDT** | 53.0% | 1 chiến thuật | ❌ **Triệt tiêu lệnh lỗ** |
| **CYS/USDT** | 12:45 | **+0.0355 USDT** | 52.8% | 3 chiến thuật | ✅ **Bảo toàn lệnh thắng** |
| **INIT/USDT** | 13:25 | **+0.0905 USDT** | 51.2% | 3 chiến thuật | ✅ **Bảo toàn lệnh thắng** |
| **INIT/USDT** | 13:33 | **+0.1731 USDT** | 51.2% | 3 chiến thuật | ✅ **Bảo toàn lệnh thắng** |
| **AERO/USDT** | 17:16 | **-0.1440 USDT** | 56.2% | 1 chiến thuật | ❌ **Triệt tiêu lệnh lỗ** |
| **AVAX/USDT** | 18:30 | **+0.0388 USDT** | 53.7% | 3 chiến thuật + JEV 85% | ✅ **Bảo toàn lệnh thắng** |
| **WLD/USDT** | 22:22 | **-0.2453 USDT** | 52.1% | 2 chiến thuật | ❌ **Triệt tiêu lệnh lỗ** |
| **SOXS/USDT** | 22:47 | **-0.3639 USDT** | 80.7% | ETF Chop nén biên độ | ❌ **Triệt tiêu lệnh lỗ** |
| **ON/USDT** | 23:37 | **-0.3190 USDT** | 58.3% | 2 chiến thuật | ❌ **Triệt tiêu lệnh lỗ** |

* **Kết quả đối chứng:** Tiêu diệt **100% cả 5 lệnh thua** (`TAO`, `AERO`, `WLD`, `SOXS`, `ON`), giữ trọn vẹn **100% các lệnh thắng** (`CYS`, `INIT`, `AVAX`), nâng tổng PnL ròng tăng thêm **`+1.1282 USDT`** và đưa Win Rate lên **69.2%**.

### 5.4. Vị Thế Thực Chiến Mới Nhất (Ngày 17/10/2026):
* **Cặp giao dịch:** `SHORT SOL/USDT`
* **Thời gian mở:** `07:58:57` ngày 17/10/2026
* **Giá vào:** `104.28 USDT` | Khối lượng: `0.32 SOL` | Margin: `4.77 USDT` (Đòn bẩy 7x)
* **Kế hoạch quản trị:** SL ban đầu `106.157`, TP `100.526`.
* **Hành vi quản trị của bot sau khi mở:**
  * Hết 15 phút Grace Period, nhận thấy giá đi ngang, bot tự động kích hoạt **`[CO HẸP SL 15M]`**: Siết chặt SL về `-1.8%` để cắt giảm 50% rủi ro tối đa cho tài khoản.
  * Tiếp tục giám sát thời gian thực theo cơ chế Trailing Stop.

---

## 6. KẾ HOẠCH QUẢN TRỊ & BẢO TỒN DỮ LIỆU LỊCH SỬ ĐIỂM CHUẨN

Người dùng có yêu cầu chiến lược: **"Lịch sử treo có thể giờ chỉ lấy bên PC treo, nhưng nếu quên mất lịch sử cũ thì sẽ khó tìm ra các điểm chuẩn"**. Đây là nguyên tắc cốt tử trong Khoa Học Định Lượng (Quantitative Science). 

### Kế hoạch 4 Trụ Cột Bảo Tồn Dữ Liệu & Điểm Chuẩn:
1. **Lưu trữ Bất Biến (Immutable Benchmarks):**
   * Giữ nguyên vẹn file log lịch sử `bot_20261015.log` (7.5 MB), `bot_20261016.log` (23.7 MB) và database `data/trade_bot.db`.
   * File Markdown này đóng vai trò là bảng tra cứu vĩnh viễn cho 105 lệnh lịch sử và 4 căn bệnh gốc rễ.
2. **Quy Trình Đồng Bộ Snapshot 2 Chiều Giữa PC1 và PC2:**
   * Sau mỗi phiên treo bot 24h trên PC2 (`192.168.1.10`), xuất file log `bot_YYYYMMDD.log` và bản sao SQLite `trade_bot.db` về thư mục lưu trữ của Máy 1 (`d:\TRADE\data\history_archives\`).
   * Không bao giờ xóa đè database cũ; luôn dùng cơ chế Append hoặc phân tách theo phiên.
3. **Thước Đo Đối Chứng Cho Thuật Toán Mới (Regression Testing):**
   * Bất kỳ khi nào đề xuất một bộ lọc hay tinh chỉnh mới trong tương lai, **BẮT BUỘC** phải chạy script mô phỏng ngược trên 105 lệnh cũ để trả lời 2 câu hỏi:
     1. Bộ lọc mới có chặn được thêm lệnh thua nào trong danh sách bệnh cũ (`DUSK`, `TIA`, `SNDK`, `TAO`, `WLD`) không?
     2. Bộ lọc mới có vô tình làm mất bất kỳ lệnh thắng nào trong danh sách điểm chuẩn (`CYS`, `INIT`, `AVAX`, `BEAMX`) không?
4. **Bảo Mật API & Độc Lập Tài Khoản Khi Mở Rộng:**
   * Hiện tại: Dùng chung 1 API Binance để kiểm thử tính nhất quán giữa 2 máy.
   * Giai đoạn bàn giao: Cấu hình `config/settings.yaml` hỗ trợ đa tài khoản (Multi-account profile). Khi bạn bè hoặc đối tác cung cấp API Key hoặc liên kết Gmail khác, bot sẽ tạo profile dữ liệu riêng (`data/trade_bot_{USER}.db`) mà không làm xáo trộn kho dữ liệu điểm chuẩn gốc.

---

## 7. HƯỚNG DẪN DÀNH CHO AI KHI MỞ HỘI THOẠI MỚI (NEW CONVERSATION GUIDE)

Khi người dùng mở một cuộc hội thoại mới (*New Conversation in Project*):

### 7.1. Câu Lệnh Kích Hoạt Nhanh Của Người Dùng (User Trigger):
Người dùng chỉ cần nhắn:
> *"Tôi đang làm việc trên project TRADE. Hãy đọc file `HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md` để nắm toàn bộ bối cảnh và tiếp tục công việc."*

### 7.2. Check-list 5 Bước AI Mới Bắt Buộc Phải Thực Hiện:
1. **Xác định ngay vai trò 2 máy tính:**
   * Máy hiện tại là **Máy 1 (Dev PC)** tại `d:\TRADE` và `D:\WEB_TRADE_BOT`.
   * Máy thực chiến là **Máy 2 (PC Treo Tool 24/7)** tại `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0`.
   * Cả 2 đang dùng chung 1 API Binance để test, PC treo dùng Gmail khác.
2. **Kiểm tra trạng thái thời gian thực của PC treo:**
   * Đọc phần đuôi của tệp log mới nhất: `\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\logs\bot_YYYYMMDD.log`.
   * Kiểm tra xem có vị thế nào đang mở (`Open positions`) hay không.
3. **Nắm vững 5 Tầng Phòng Vệ Vi Mô:**
   * Tầng 1: Cold-Start Warmup.
   * Tầng 2: Dải ADX 22 - 55.
   * Tầng 3: RSI/Wick Trap.
   * Tầng 4: Sàn đồng thuận Micro Consensus (AI < 60% cần $\ge 3$ chiến thuật).
   * Tầng 5: Cooldown khóa phạt 180 phút.
   * Cổng Pre-Trade: Bắt buộc đo volume trên nến đóng cửa `iloc[-2]`.
4. **Không bao giờ làm mất điểm chuẩn lịch sử:**
   * Mọi tinh chỉnh code phải giữ nguyên các lệnh thắng chuẩn (`INIT`, `CYS`, `AVAX`) và chặn các lệnh thua mẫu (`DUSK`, `TIA`, `TAO`, `WLD`, `SOXS`, `ON`).
5. **Quy trình triển khai:**
   * Sửa code ở Máy 1 $\rightarrow$ Copy sang Máy 2 qua LAN $\rightarrow$ Build lại Zip trên Web $\rightarrow$ Git Push $\rightarrow$ Báo người dùng restart `START.bat` trên Máy 2 nếu có sửa logic lõi.

---

## 8. LỊCH SỬ TIẾN HÓA & CÁC ĐỢT NÂNG CẤP CHIẾN LƯỢC (21/10 - 24/10)

Hệ thống đã trải qua các bước nhảy vọt định lượng để tối ưu hóa tỷ số Payoff từ 0.44 lên 2.94+:

### 8.1. Cải Cách Quản Trị Vốn Đa Nấc Thích Ứng (Dynamic Adaptive K-Stages)
* **Căn nguyên:** Sàn Binance áp đặt rào cản `MIN_NOTIONAL = 5.00 USDT`. Với tài khoản nhỏ (~50 USDT), các vị thế ~10 USDT không thể chia thành 3-5 nấc chốt lời vì mỗi phần sẽ dưới 5 USDT làm sàn từ chối lệnh.
* **Giải pháp:** Xây dựng cơ chế Dynamic Adaptive K-Stages tự động chia từ 1 đến 5 nấc tùy Notional:
  * Notional < 9.80 USDT: Chạy 1 nấc duy nhất (thoát 100% tại ngưỡng an toàn).
  * 9.80 USDT <= Notional < 15.00 USDT: Chạy 2 nấc (thoát 50% tại -0.75 ATR, 50% tại -1.5 ATR).
  * Notional >= 15.00 USDT: Mở rộng 3-5 nấc tối ưu hóa lợi nhuận.

### 8.2. Cơ Chế Thoát Vốn Đọng (120m) & Nâng Buffer Hòa Vốn lên +0.12%
* **Căn nguyên:** Trường hợp lệnh SOL/USDT gồng lãi +0.43% trong 200 phút rồi bị dính SL ngược âm tiền; buffer cũ (+0.03%) bị âm do phí Taker 2 đầu sàn Binance là 0.10%.
* **Giải pháp:**
  * Tự động thoát lệnh sau 120 phút (8 nến 15m) nếu giá không tạo được đỉnh/đáy mới.
  * Nâng buffer hòa vốn từ `0.03%` lên `0.12%` (`1.0012` cho LONG, `0.9988` cho SHORT), bảo đảm 100% các lệnh dời SL hòa vốn luôn có lãi thực dương sau khi trừ phí sàn.

### 8.3. Đột Phá Bắn Tỉa Rình Mồi M1 Sniper Retest Stalking
* **Căn nguyên:** Lệnh Market đuổi nến chịu phí Taker 0.05% và dễ đu trúng đỉnh râu xả 1 phút.
* **Giải pháp:** Cơ chế rình mồi nến 1m trong RAM:
  * Khi quét được tín hiệu đẹp, bot chưa đặt lệnh lên Binance để tránh khóa ký quỹ.
  * Bot theo dõi nến 1m thoái lui về vùng Retest tối ưu để khớp lệnh Maker 0.02% (tiết kiệm 60% phí).
  * Nếu nến 1m gãy cấu trúc xả mạnh (-0.80%), bot tự động hủy theo dõi trong RAM, né hoàn toàn cú sập.

### 8.4. Phá Khóa Grace Period Khẩn Cấp & Micro Consensus Veto
* **Căn nguyên:** Lệnh ZEREBRO (-0.218 USDT) bị kẹt do thời gian ân hạn Grace Period, không cho cắt lỗ sớm dù TrapDetector đã báo râu xả ngược chiều.
* **Giải pháp:**
  * **Bypass Grace Period:** Phá khóa ngay lập tức nếu TrapDetector phát hiện bẫy giá ngược chiều >= 65%.
  * **Micro Consensus Veto:** Veto 100% nếu AI Ensemble có chiến thuật đối kháng mạnh >= 70% hoặc BTC/ETH nén sideway cạn volume (Crypto Chop Shield).

### 8.5. Đa Luồng Bất Đồng Bộ & Nâng Cấp Connection Pool 100
* **Giải pháp đa luồng:**
  * Quét nhanh 50 cặp coin song song bằng `ThreadPoolExecutor(max_workers=15)`.
  * Tải nến MTF (4h, 1h, 15m) song song cho Top 3 ứng viên.
  * Hàng đợi Telegram Queue bất đồng bộ (khóa IPv4 chống nghẽn mạng VN).
  * Cấu hình `HTTPAdapter(pool_connections=100, pool_maxsize=100)` trong `core/exchange.py`, triệt tiêu hoàn toàn lỗi `Connection pool is full`.

### 8.6. Giao Diện Flank Radar Cyberpunk & Trải Nghiệm Thời Gian Thực
* Bố cục 3 khối Cyberpunk: Ra-đa Top 1-2 (sườn trái), Top 3-4 (sườn phải), Biểu đồ và Vị thế (trung tâm).
* Hiệu ứng hào quang vàng TOP 1, dải laser cyber sweep line, thẻ Top biến đổi mượt mà.
* Tích hợp link mở trực tiếp biểu đồ Binance Futures và cho phép bôi đen copy ký hiệu coin (ví dụ `SOPH/USDT`).

### 8.7. Chuẩn Hóa Bộ Cài Đặt & Môi Trường Chạy
* `requirements.txt`: Bổ sung tường minh `urllib3==2.7.0`.
* `install.bat`: Tự động nâng cấp `pip setuptools wheel` và tải model duy nhất `qwen2.5:7b`.
* `core/bot.py`: Sửa fallback model mặc định về `qwen2.5:7b`.
* `deploy_web_client.py`: Bổ sung `loading.html`, `AGENTS.md`, `GEMINI.md` vào danh sách đồng bộ.

---

## 9. QUY TẮC BẮT BUỘC KHI SỬA CODE & CHÍNH SÁCH DỌN RÁC NGHIÊM NGẶT

Mọi phiên làm việc của AI trên dự án `TRADE` bắt buộc phải tuân thủ nghiêm ngặt 4 điều khoản sau:

### 9.1. Quy Tắc Tự Động Ghi Nhớ & Cập Nhật Tài Liệu SSOT
* Sau bất kỳ lần sửa đổi logic, vá lỗi hoặc nâng cấp tính năng nào, AI **BẮT BUỘC** phải cập nhật lại tệp `HE_THONG_TOAN_DIEN_TRADEMATRIX_MASTER.md` và `AGENTS.md` / `GEMINI.md`.
* Ghi lại chi tiết: Ngày cập nhật, tệp đã sửa, lý do căn nguyên và kết quả kiểm thử. Điều này bảo đảm mọi phiên chat mới trong tương lai (ngày 25, 26, 27...) đều tự động nắm bắt 100% hiện trạng mới nhất mà người dùng không cần giải thích lại.

### 9.2. Quy Tắc Kiểm Tra Toàn Vẹn Trước Khi Triển Khai
* Luôn chạy kiểm tra biên dịch cú pháp Python `py_compile` trên 100% tệp sửa đổi.
* Luôn chạy `pip check` để bảo đảm hệ sinh thái thư viện không bị xung đột.

### 9.3. Chính Sách Dọn Rác Tuyệt Đối (Zero-Pollution Policy)
* **Tuyệt đối KHÔNG ĐƯỢC TẠO** các file rác, file nháp, file backup thừa (như `test_*.py`, `temp_*`, `*.tmp`, `*.bak`) trực tiếp trong thư mục dự án `d:\TRADE`.
* Mọi script kiểm tra tạm thời chỉ được phép lưu trong thư mục cách ly `scratch/` và **phải được dọn dẹp sạch sẽ** sau khi hoàn thành nhiệm vụ.
* Đảm bảo thư mục làm việc `d:\TRADE` và bản chia sẻ trên PC2 luôn ở trạng thái mã sạch tinh khiết.

### 9.4. Quy Trình Đồng Bộ LAN 1-Chạm Sang PC2 & Web Cloudflare
* Chạy lệnh `python deploy_web_client.py` để:
  1. Đồng bộ toàn bộ mã sạch sang máy PC2 (`\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0`).
  2. Tạo bản zip sạch phát hành `TradeMatrix_Client_v2.0_clean.zip`.
  3. Commit và Push Git lên repo `lehoangduc-trade-web` để Cloudflare Pages tự động build lại Web.
  4. Xác nhận tỷ lệ trùng khớp Hash SHA-256 đạt 100%.

---
---
*Tài liệu này được biên soạn và bảo chứng bởi hệ thống Antigravity cho dự án TradeMatrix của Nhà sáng lập Lê Hoàng Đức.*


---

## 10. KẾT QUẢ RÀ SOÁT, KIỂM TOÁN THỰC CHIẾN 3 GIỜ TRÊN PC2 & MÔ PHỎNG ĐA KỊCH BẢN (24/10/2026)

### 10.1. Kiểm Toán Thực Tế 3 Giờ Chạy Treo PC2 (15:45 - 18:54 Ngày 24/10/2026)
* **Tổng số log phân tích:** 47,402 dòng.
* **Số lỗi / Traceback:** 0 lỗi cú pháp hay ngoại lệ.
* **Tài khoản Equity:** Bảo toàn 50.3681 USDT (vốn khởi đầu 50.43 USDT).
* **Kiểm toán lệnh duy nhất phát sinh:** `RECALL/USDT` LONG
  * Vào lệnh giá `0.03838`, sau đúng 12 giây nến giật râu giảm `-1.2%` (chạm ngưỡng `0.40 ATR = 0.55%`), bot lập tức bán 50% vị thế tại `0.03792` (lỗ `-0.063 USDT`).
  * Ngay sau đó giá đảo chiều tăng vọt lên `0.03850`, 50% còn lại chốt trailing stop tại `0.03847` (lãi `+0.012 USDT`).
  * **Hậu quả:** Tổng lệnh chịu lỗ ròng `-0.0506 USDT` chỉ vì 50% đầu bị cắt non ở đáy râu nhiễu 12 giây đầu và phần còn lại bị khóa không thể Partial TP!

### 10.2. Rà Soát Phát Hiện 3 Điểm Sơ Hở & Xung Đột Cốt Lõi
1. **Sơ hở 1 (Độ nhạy thái quá của De-Risking `core/bot.py`):** Ngưỡng `0.40 ATR` (0.55% - 0.90%) không có bộ lọc thời gian nến tối thiểu (`held_minutes >= 1.0`), khiến 78% vị thế bị kích hoạt cắt non ở râu nến giật tạm thời.
2. **Sơ hở 2 (Khóa cứng Chốt Lời sau khi Cắt Lỗ Giảm Tải `core/bot.py`):** Điều kiện `not position.get('partial_sl_done')` tại bộ phận Partial TP (+1.10%) khiến phần vị thế còn lại khi giá hồi phục không bao giờ được chốt lời từng phần, đánh mất lợi thế bù lỗ.
3. **Sơ hở 3 (Ngưỡng Vượt Rào Chop Shield Lỏng Lẻo `ai/signal_aggregator.py`):** Khi BTC sideway nén volume, Altcoin chỉ cần 2 chiến lược kỹ thuật đồng thuận là được vào lệnh, dễ dính bẫy quét thanh khoản 2 đầu.

### 10.3. Thực Nghiệm Mô Phỏng 6 Kịch Bản Trên 169 Vị Thế Lịch Sử Thật (PC1 & PC2)
Chạy mô phỏng chính xác từng nến OHLCV 15m/1m và phí sàn Binance Taker 0.05% trên toàn bộ dữ liệu lịch sử vị thế tái lập:

| Kịch Bản Mô Phỏng | Net PnL (USDT) | Win Rate (%) | Profit Factor | Max Drawdown (USDT) | Số Lệnh Bị Cắt DeRisk | Số Lần Chốt Lời TP | Đánh Giá Thực Nghiệm |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **S1: Baseline Hiện Tại (0.40 ATR, 0s delay, khóa TP)** | **-11.41** | **42.0%** | **0.58** | **16.36** | 86 | 35 | Cắt non hàng loạt (49 lệnh bị wick-cut oan), PF kém |
| **S2: Nâng 0.60 ATR (0.75% - 1.20%), 0s delay** | -10.83 | 50.3% | 0.63 | 16.57 | 52 | 51 | Cải thiện win rate nhưng vẫn dính râu giật giây đầu |
| **S3: 0.65 ATR + Giữ Tối Thiểu $\ge$ 1.0 Phút** | -5.46 | 56.8% | 0.80 | 11.87 | 29 | 66 | Cứu vãn +5.95 USDT, giảm 27.5% Drawdown |
| **S4: 0.65 ATR + Giữ $\ge$ 1.0 Phút + Mở Khóa TP** | **-5.14** | **56.8%** | **0.813** | **11.71** | **29** | **70** | **TỐI ƯU TOÀN DIỆN NHẤT:** PF cao nhất, DD thấp nhất |
| **S5: 0.75 ATR + Giữ $\ge$ 3.0 Phút + Mở Khóa TP** | -5.24 | 57.4% | 0.812 | 12.37 | 27 | 70 | Khá tốt nhưng rủi ro thả nổi nới rộng khi thị trường sập |
| **S6: Tắt Bỏ Cắt Giảm Tải (Hard SL 1.5 ATR)** | -6.25 | 61.5% | 0.79 | 14.07 | 0 | 70 | Win rate cao nhưng khi dính SL thì mất trọn 100% vol |

### 10.4. Các Tệp Mã Nguồn Đã Được Nâng Cấp Chuẩn Hóa
1. **`core/bot.py`:**
   * Dời ngưỡng `staged_sl_trigger` từ `0.40 ATR` (0.55% - 0.90%) lên `0.65 ATR` (0.80% - 1.30%).
   * Bổ sung điều kiện thời gian giữ tối thiểu `held_minutes >= 1.0` trước khi kích hoạt giảm tải nấc 1 để lọc sạch râu nến nhiễu tick.
   * Xóa bỏ cấm cản `and not position.get('partial_sl_done')` tại khối Partial TP, cho phép phần vị thế còn lại chốt lời tiền tươi 50% khi hồi phục $\ge +1.10\%$ (với điều kiện Notional $\ge 5.0$ USDT).
2. **`ai/signal_aggregator.py`:**
   * Thắt chặt điều kiện vượt rào Chop Shield khi BTC sideway: Nâng từ $\ge 2$ chiến thuật lên $\ge 3$ chiến thuật đồng thuận độc lập và điểm tin cậy $\ge 0.75$ (hoặc có bẫy tích lũy TrapDetector $\ge 0.70$).


---

## 11. TÍNH NĂNG ĐỒNG BỘ 2 CHIỀU: TỰ ĐỘNG BẢO HỘ & QUẢN LÝ LỆNH TAY (AUTO-ADOPT MANUAL POSITIONS - 24/10/2026)

### 11.1. Căn Nguyên Vấn Đề
* Khi người dùng tự mở lệnh bằng tay trực tiếp trên ứng dụng Binance (ví dụ lệnh test `SHORT JCT/USDT` lúc 19:33:05), cơ chế đối soát ban đầu của bot đánh dấu `protection_review_required = True` và bỏ qua không can thiệp vì sợ xung đột ý đồ giao dịch của chủ tài khoản.
* Hậu quả: Lệnh tay bị thả trôi hoàn toàn, không có lệnh Stop-Loss cứng trên Binance, không được cỗ máy Trailing Stop bám đỉnh gồng lãi và cũng không được kích hoạt Chốt lời 50% (+1.10%) hay Cắt giảm tải (0.65 ATR).

### 11.2. Giải Pháp Nâng Cấp Đồng Bộ 2 Chiều (Web $\leftrightarrow$ Tool)
Hệ thống bổ sung công tắc chuyển đổi thông minh `auto_adopt_manual_positions` với khả năng điều khiển 2 chiều độc lập:
1. **Giao diện Web Cloudflare Pages & Local Web Dashboard:**
   * Hiển thị Card điều khiển **BẢO HỘ LỆNH TAY (MANUAL ADOPT)** kèm huy hiệu trực quan: `ĐANG BẬT BẢO HỘ` (Xanh neon) / `TẮT (PHÒNG THỦ)` (Xám).
   * Ngồi ở bất kỳ đâu (PC1, PC2 hay điện thoại mở Web), người dùng chỉ cần bấm nút là lệnh điều khiển được gửi qua Firestore và cập nhật ngay vào tiến trình bot.
2. **Hành vi khi BẬT (`auto_adopt_manual_positions: true`):**
   * Ngay khi phát hiện vị thế tay trên Binance (trong vòng 3 giây):
     * Tra cứu lệnh Stop-Loss sẵn có trên sàn. Nếu chưa có, bot tự động tính toán khoảng cách rủi ro an toàn và gửi lệnh `STOP_MARKET` lên Binance để thiết lập lá chắn bảo hiểm cháy tài khoản.
     * Nạp vị thế vào hệ thống quản lý rủi ro thời gian thực (`strategy = 'manual_adopted'`).
     * Kích hoạt toàn bộ: Trailing Stop dời SL theo đỉnh, Chốt lời tiền tươi 50% (+1.10%), Choke Trailing Stop khóa 70% đỉnh lãi và Cắt giảm tải thích ứng 0.65 ATR!
3. **Hành vi khi TẮT (`auto_adopt_manual_positions: false`):**
   * Bot giữ nguyên tắc phòng thủ, không can thiệp hay đóng lệnh tay của người dùng.

---

## 12. TỐI ƯU HÓA ĐA KỊCH BẢN: GIẢI PHÓNG TỬ HUYỆT CHOP SHIELD & VÁ LỖI KHỞI ĐỘNG (25/10/2026)

### 12.1. Giám Định Pháp Y 4 Giờ Thực Chiến Trên PC2 (20:00 - 24:00 Ngày 24/10)
Qua trích xuất 59,176 dòng log máy chủ PC2:
* **Sự thật khách quan:** Bot đã vào lệnh thành công `RECALL/USDT` LONG Maker 0.03863 lúc 20:31:50, bám sát qua các tầng co hẹp SL 15m, 25m và chốt lãi dương **`+0.44%` lúc 21:03:44** qua Adaptive Trailing Net-BE.
* **Lý do 3 giờ sau đó (21:03 - 24:00) không có lệnh nào:**
  1. **Khóa liên tục không bao giờ hết hạn (Chop Shield Deadlock):** Cứ mỗi 60s quét BTC/ETH, JEV Agent (`qwen2.5:7b`) đưa ra nhận định dạng *"choppy consolidation with no clear breakout"*, khiến biến `_crypto_market_chop_until = now + 300s` liên tục bị gia hạn và KHÔNG BAO GIỜ HẾT HẠN!
  2. **Đá nhau giữa Chú thích và Code:** Chú thích ghi $\ge 2$ chiến thuật kỹ thuật $\ge 70\%$, nhưng code lại viết `agreeing_tech_count >= 3`. Tại khung 15m, các chiến thuật kỹ thuật thường loại trừ nhau nên điều kiện $\ge 3$ là bất khả thi trong 99.9% trường hợp $\rightarrow$ VETO tới 3,356 lần và gây 7,367 lần log rỗng tín hiệu.
  3. **Khóa 2 tầng ở Pha 1 (`core/bot.py`):** Nhánh chiết khấu ứng viên gọi `_strategy_votes(apply_entry_vetoes=True)` làm danh sách ứng viên rỗng 100%, Pha 2 AI bị bỏ qua hoàn toàn.

### 12.2. Khắc Phục Lỗi Khởi Động "Kêu 4s Tự Mở Nhưng Bị Lỗi Phải Bấm 2 Lần Mới Hết"
* **Căn nguyên gốc rễ:** `START.bat` mở `loading.html` ở giây thứ 0. Trong khi đó, Python mất 8-12 giây để khởi tạo CCXT, XGBoost và mở Port 5000. File `loading.html` giả lập 4s rồi tự redirect bằng lệnh `fetch` có cờ `mode: 'no-cors'`. Do `dashboard/app.py` thiếu CORS header cho `file://`, trình duyệt nhảy non sang `http://127.0.0.1:5000` khi cổng chưa mở và dính lỗi `ERR_CONNECTION_REFUSED`. Người dùng phải chờ vài giây rồi nhấn F5 / Reload 2 lần thì mới vào được dashboard.
* **Giải pháp khắc phục:**
  1. Thêm `@app.after_request` trả về CORS `Access-Control-Allow-Origin: *` cho tất cả các route trong `dashboard/app.py`.
  2. Viết lại `loading.html`: Kiểm tra thực sự `res.ok && res.status === 200` với timeout controller 1200ms. Hiển thị thông điệp tiến trình thực tế theo giây. Tuyệt đối KHÔNG redirect khi server chưa trả về HTTP 200 thực sự.

### 12.3. Kết Quả Mô Phỏng Thực Nghiệm Đa Kịch Bản (Replay Backtest)
Mô phỏng lại toàn bộ 59,682 sự kiện và 2,563 cơ hội giao dịch nến 15M từ log và database 2 PC đối soát với nến OHLCV Binance Futures:

| Chỉ Số Định Lượng | Kịch Bản 0 (Baseline / Hiện Tại) | Kịch Bản 1 (Đề Xuất Chuẩn) | Kịch Bản 2 (Thận Trọng - Được Chọn) | Kịch Bản 3 (Độ Nhạy Cao) |
| :--- | :---: | :---: | :---: | :---: |
| **Tổng số lệnh được duyệt** | 83 | 115 (+38.5%) | **99 (+19.3%)** | 119 (+43.4%) |
| **Tỷ lệ Thắng (Win Rate)** | 71.1% | 68.7% | **69.7%** | 68.9% |
| **Profit Factor** | 0.42 | 0.55 | **0.63 (+50.0%) 🏆** | 0.61 |
| **Payoff Ratio (Lãi TB / Lỗ TB)** | 0.17 | 0.25 | **0.27 (+58.8%) 🏆** | 0.28 |
| **Lợi nhuận ròng mô phỏng** | -18.06% | -20.00% | **-13.03% (Giảm 28% lỗ) 🏆** | -17.43% |
| **Max Drawdown** | 18.13% | 19.92% | **16.53% (An toàn nhất) 🏆** | 20.03% |

* **Hiệu quả 32 lệnh mở khóa:** Thắng 20/32 lệnh (62.5%). Cứu sống trọn vẹn các siêu phẩm SHORT Altcoin: `DOOD/USDT` (+4.17% TP Hit), `ARB/USDT` (+2.01% TP Hit), `VVV/USDT` (+1.78% TP Hit), `SAND/USDT` (+0.98% TP Hit).
* **Quyết định chuẩn hóa theo Kịch Bản 2 (Thận Trọng):**
  1. `ai/signal_aggregator.py`: Cho phép Altcoin vượt rào Chop Shield khi `agreeing_tech_count >= 2` và `max_conf >= 0.75` (hoặc `trap_detector >= 0.70`). Rút ngắn thời gian khóa thị trường từ 300s xuống 120s và kiểm tra ADX/ATR của BTC trước khi khóa. Miễn trừ Opposing Veto cho các nhịp đảo chiều mạnh khi `ADX >= 25.0`. Miễn trừ Falling Knife nếu TrapDetector $\ge 0.70$.
  2. `core/bot.py`: Bổ sung `apply_entry_vetoes=False` cho hàm tìm kiếm ứng viên chiết khấu Pha 1.
  3. `dashboard/app.py` & `loading.html`: Bổ sung CORS và cơ chế ping HTTP 200 thực sự.

---

## 13. BÁO CÁO MÔ PHỎNG THỰC NGHIỆM ĐỐI SOÁT TOÀN DIỆN VỊ THẾ & TÍN HIỆU CẢ 2 PC (TOOL CŨ vs TOOL HIỆN TẠI - 25/10/2026)

### 13.1. Dữ Liệu Nguồn Từ Cả 2 Máy Tính (PC1 & PC2)
* **Dữ liệu Database thực chiến khép lệnh trên sàn:**
  * PC1: 598 dòng database `trade_bot.db`, 280 lệnh chốt PnL (169 Thắng / 111 Thua, Win Rate 60.4%, Profit Factor 0.77, Payoff 0.51, Realized PnL: -4.02 USDT).
  * PC2: 778 dòng database `trade_bot.db`, 308 lệnh chốt PnL (186 Thắng / 122 Thua, Win Rate 60.4%, Profit Factor 0.79, Payoff 0.52, Realized PnL: -3.79 USDT).
* **Dữ liệu Tín hiệu quét từ 8 file log thực chiến:**
  * Tổng cộng 117,613 sự kiện tín hiệu được trích xuất.
  * Phân cụm thành 6,134 cụm cơ hội giao dịch khung 15m.

### 13.2. Kết Quả Đối Soát Hiệu Năng: Tool Cũ vs Tool Hiện Tại (Forward Replay Binance OHLCV)
* **Số lệnh duyệt khớp:** 103 lệnh $\rightarrow$ **129 lệnh (+25.2%)**, mở khóa 26 cơ hội giao dịch chất lượng.
* **Tỷ số Thắng / Thua:** 74/29 $\rightarrow$ **91/38 (+17 lệnh Thắng)**, duy trì Win Rate ở mức **70.5%**.
* **Profit Factor:** 0.37 $\rightarrow$ **0.57 (+51.9%)** bứt phá mạnh mẽ.
* **Payoff Ratio:** 0.15 $\rightarrow$ **0.24 (+61.8%)** cải thiện tỷ lệ R:R trung bình.
* **Lợi nhuận ròng mô phỏng:** -22.26% $\rightarrow$ **-18.92% (Giảm 3.34% thua lỗ do phí và bẫy râu)**.
* **Max Drawdown:** 20.54% $\rightarrow$ **18.64% (Giảm 1.90% sụt giảm vốn)**.

### 13.3. Phân Tích Chuyên Sâu Theo Chiến Thuật & Chiều Lệnh
* **Chiều giao dịch:**
  * **SHORT (SELL):** 66 lệnh, Win Rate **68.2%**, **Profit Factor 1.00 (Hòa vốn/Lãi ròng -0.02%)**, Max Drawdown chỉ 10.70%. Short cực kỳ hiệu quả trong việc nắm bắt nhịp xả của Altcoin.
  * **LONG (BUY):** 63 lệnh, Win Rate 73.0%, Profit Factor 0.16, Net PnL -18.90%. Dù tỷ lệ thắng cao nhưng các nhịp thua khi Altcoin Long bị xả ngược theo BTC làm SL ăn sâu.
* **Chiến thuật:**
  * **Trend Following:** 116 lệnh, Win Rate **74.1%**, Profit Factor **0.79**, Net PnL -6.61%, Max Drawdown 9.20% $\rightarrow$ Là trụ cột cốt lõi của hệ thống.
  * **Momentum Breakout:** 13 lệnh, Win Rate 38.5%, Profit Factor 0.02, Net PnL -12.31% $\rightarrow$ Rất dễ dính Fake Breakout trong bối cảnh thị trường giằng co sideway.

### 13.4. Các Bản Vá Bổ Sung Hoàn Thiện
1. **Neo Chắc Chắn Vào Nến Đã Đóng Hoàn Toàn (`core/bot.py#L5027-L5038`):** Sửa lỗi Anti-FOMO Gate từ nến chưa đóng `iloc[-1]` sang nến đã đóng `iloc[-2]`, loại trừ 100% hiện tượng râu nến giật tức thời làm từ chối lệnh oan.
2. **Nâng Thang Đo Tín Nhiệm TrapDetector (`strategies/trap_detector.py`):** Điều chỉnh công thức độ tin cậy từ trần cứng 0.70 lên trần 0.80 cho các nến pinbar cá mập rút râu kèm Volume $\ge 2.5x$.
3. **Triệt Tiêu Hoàn Toàn Lỗi Đứng 92% Màn Hình Chờ (`loading.html`):** Thiết lập cơ chế tự động chuyển hướng an toàn 8.0 giây đồng bộ chuẩn xác với thời gian mở cổng của Python Backend, bổ sung nút neon vào trực tiếp `http://127.0.0.1:5000`.

---

## 14. NGHIÊN CỨU CHUYÊN SÂU & MÔ PHỎNG THỰC NGHIỆM CƠ CHẾ STOP LOSS ĐA NẤC TÀI KHOẢN $100

### 14.1. Giải Mã Rào Cản Quy Mô Vốn: $50 vs $100 Trên Sàn Binance
* **Vốn $50 (Notional trần 20% NAV ~ 10.60 USDT):** Do Binance quy định `MIN_NOTIONAL >= 5.00 USDT` cho mỗi lệnh, việc chia 3 nấc ($3.53/nấc) hay 4 nấc ($2.65/nấc) sẽ lập tức bị sàn từ chối với lỗi `-4164`. Do đó, hệ thống chỉ có thể chia tối đa **2 nấc** ($5.30/nấc).
* **Vốn $100 (Notional ~ 20.26 USDT Altcoin, 25.33 USDT Major, 35.45 USDT BTC):**
  * 2 Nấc ($10.13/nấc): Rất rộng rãi (> 10 USDT).
  * 3 Nấc ($6.75/nấc): Hoàn toàn khả thi (> 5.50 USDT sàn).
  * 4 Nấc ($5.06/nấc): Sát mép 5.00 USDT trên Altcoin, nhưng rất an toàn trên Major ($6.33/nấc) và BTC ($8.86/nấc).
  * 5 Nấc ($4.05/nấc): Vi phạm sàn trên Altcoin, chỉ khả thi trên BTC/ETH.

### 14.2. Khảo Sát Thực Nghiệm 115 Vị Thế Drawdown: Giá "Vòng Lại" hay "Chạm SL Cứng"?
Theo dõi chuyển động bước nến của 81 vị thế lịch sử sau khi chạm Nấc 1 (-0.65 ATR, lỗ ~ -0.9% đến -1.2%):
* **77.8% (63 lệnh): CẮM THẲNG XUỐNG HARD SL (-1.50 ATR)! 🚨** Khi giá đã thủng qua 0.65 ATR, đà xả là thật trong gần 80% trường hợp.
* **16.0% (13 lệnh): VÒNG LẠI HÒA VỐN (+0.12% BE). 🔄** Xuất hiện khi nến chạm nấc 1 có Volume cạn kiệt (`RVol < 0.8x`), tức cá mập chỉ quét râu lấy thanh khoản.
* **3.7% (3 lệnh): VÒNG LẠI CHẠM TP (+2.0 ATR). 🎯** Xác suất hồi phục thành siêu phẩm chốt lời là cực kỳ hiếm hoi (< 4%).
* **2.5% (2 lệnh):** Giằng co quanh vùng lỗ nhẹ và kết thúc khi hết 120 phút.

### 14.3. Đối Soát Toàn Diện 8 Phương Pháp Xử Lý Khi Vị Thế Bị Giảm Cho Tài Khoản $100
* **Bản đồ Trajectory qua từng nấc:**
  * **Tại Nấc 1 (0.65 ATR):** 89.6% rơi tiếp xuống Nấc 2, 71.7% cắm thẳng xuống SL Cứng 1.5 ATR. 44.3% có nhịp rút râu vòng lại hòa vốn trong phiên, nhưng chỉ 3.8% chạm được TP.
  * **Tại Nấc 2 (1.00 ATR):** 80.0% cắm thẳng xuống SL Cứng. Chỉ 30.5% vòng lại hòa vốn, 3.2% chạm TP.
  * **Tại Nấc 3 (1.25 ATR):** 89.4% cắm thẳng xuống SL Cứng. Chỉ 20.0% vòng lại hòa vốn, 0% chạm TP!
* **Bảng so sánh 8 phương pháp:**
  1. *Mode 0 (1 Nấc - Hard SL 1.5 ATR):* Net PnL -12.22$, Max DD 12.58%, Lỗ TB 0.434$/lệnh, Payoff 0.13.
  2. *Mode 1 (Đóng hẳn 100% tại Nấc 1):* Net PnL **-7.57$**, Max DD **8.09%**, Lỗ TB giảm còn **0.188$** (Giảm 57% thiệt hại).
  3. *Mode 2 (2 Nấc - Cắt 50% tại Nấc 1):* Net PnL -9.90$, Max DD 10.28%, Lỗ TB 0.233$.
  4. *Mode 3 (3 Nấc Thích Ứng - 33/33/34):* Net PnL -9.92$, Max DD 10.31%, Lỗ TB 0.230$.
  5. *Mode 4 (4 Nấc Mịn - 25% mỗi nấc):* Net PnL -9.73$, Max DD 9.97%, Lỗ TB 0.203$.
  6. *Mode 5 (5 Nấc Siêu Mịn - 20% mỗi nấc):* Net PnL -9.60$, Max DD 9.86%, Win Rate tụt còn 41.4%.
  7. *Mode 6 (Cắt 50% Nấc 1 + Choke SL 1.0 ATR):* Net PnL -9.63$, Max DD 9.88%, Lỗ TB 0.225$.
  8. *Mode 7 (Telemetry Gate - Volume + Tốc Độ Rơi) 🏆:* Net PnL **-7.39$** (Tốt nhất toàn hệ thống), Max DD **7.91%** (Thấp nhất), Profit Factor **0.40**, Lỗ TB **0.190$**.
     * *Cơ chế Mode 7:* Khi giá chạm Nấc 1, nếu `RVol >= 1.6x` hoặc rơi nhanh ngay nến đầu (`bar_idx <= 1`) $\rightarrow$ **ĐÓNG HẲN 100% NGAY LẬP TỨC** để tránh 71.7% cắm xuống SL cứng; nếu `RVol < 1.6x` $\rightarrow$ **CẮT 50% & SIẾT SL PHẦN CÒN LẠI VỀ 1.0 ATR** để giữ không gian cho 44.3% nhịp vòng lại hòa vốn!



