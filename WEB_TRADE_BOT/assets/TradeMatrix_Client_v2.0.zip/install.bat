@echo off
setlocal enabledelayedexpansion
title TRADEMATRIX CLIENT v2.0 - Installer
cd /d "%~dp0"

echo.
echo  ======================================================
echo   TRADEMATRIX CLIENT v2.0 - CAI DAT TU DONG
echo   Kiem tra va tu dong cau hinh Python 3.14 & Moi truong
echo  ======================================================
echo.

set "PY_CMD="

:: 1. Kiem tra xem co lenh py -3.14 san trong he thong hay khong
py -3.14 -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) and sys.maxsize > 2**32 else 1)" >nul 2>&1
if !errorlevel! equ 0 (
    set "PY_CMD=py -3.14"
    goto :python_found
)

:: 2. Kiem tra xem lenh python hien tai co phai 3.14 64-bit hay khong
where python >nul 2>&1
if !errorlevel! equ 0 (
    python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) and sys.maxsize > 2**32 else 1)" >nul 2>&1
    if !errorlevel! equ 0 (
        set "PY_CMD=python"
        goto :python_found
    )
)

:: 3. Kiem tra thu muc AppData / Programs mac dinh cua Python 3.14
if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" (
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) and sys.maxsize > 2**32 else 1)" >nul 2>&1
    if !errorlevel! equ 0 (
        set "PY_CMD=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
        goto :python_found
    )
)
if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" (
    "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) and sys.maxsize > 2**32 else 1)" >nul 2>&1
    if !errorlevel! equ 0 (
        set "PY_CMD=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
        goto :python_found
    )
)

:: 4. Neu he thong chua co Python 3.14 -> TU DONG TAI VA CAI DAT PYTHON 3.14.7 CHINH THUC
echo [THONG BAO] He thong chua co san Python 3.14 64-bit (Chuan khop Bytecode .pyc).
echo [TU DONG] Dang tu dong tai bo cai Python 3.14.7 64-bit chinh thuc tu python.org...
echo Vui long cho trong giay lat (tien trinh chay ngam hoan toan tu dong)...
echo.

set "PY_INSTALLER=%TEMP%\python-3.14.7-amd64.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('https://www.python.org/ftp/python/3.14.7/python-3.14.7-amd64.exe', '%PY_INSTALLER%')"

if exist "%PY_INSTALLER%" (
    echo [DANG CAI DAT] Dang tien hanh cai dat Python 3.14 (Add to PATH)...
    start /wait "" "%PY_INSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0 SimpleInstall=1
    del /f /q "%PY_INSTALLER%" >nul 2>&1
) else (
    echo [THU LAI] Dang thu cai dat Python 3.14 qua trinh quan ly goi winget...
    winget install --id Python.Python.3.14 -e --silent --accept-package-agreements --accept-source-agreements >nul 2>&1
)

:: Nhan lai bien moi truong PATH vua duoc them
for /f "tokens=*" %%P in ('powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('Path', 'User') + ';' + [Environment]::GetEnvironmentVariable('Path', 'Machine')"') do set "PATH=%%P;!PATH!"

:: Kiem tra lai sau khi tu dong cai dat
py -3.14 -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) and sys.maxsize > 2**32 else 1)" >nul 2>&1
if !errorlevel! equ 0 (
    set "PY_CMD=py -3.14"
    goto :python_found
)

where python >nul 2>&1
if !errorlevel! equ 0 (
    python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) and sys.maxsize > 2**32 else 1)" >nul 2>&1
    if !errorlevel! equ 0 (
        set "PY_CMD=python"
        goto :python_found
    )
)

if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" (
    set "PY_CMD=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    goto :python_found
)
if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" (
    set "PY_CMD=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
    goto :python_found
)

echo.
echo [ERROR] Chua the tu dong kich hoat Python 3.14.
echo Hay tai bo cai Python 3.14 tai: https://www.python.org/ftp/python/3.14.7/python-3.14.7-amd64.exe
echo (Luu y: Nho tich chon vao o 'Add Python to PATH' khi cai)
pause
exit /b 1

:python_found
echo [OK] Da xac nhan Python 3.14 64-bit hop le:
%PY_CMD% --version
echo.

if not exist "venv\Scripts\python.exe" (
    echo Dang tao virtual environment voi Python 3.14...
    %PY_CMD% -m venv venv
    if !errorlevel! neq 0 (
        echo [ERROR] Khong tao duoc venv. Kiem tra quyen ghi thu muc.
        pause
        exit /b 1
    )
) else (
    "venv\Scripts\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) and sys.maxsize > 2**32 else 1)" >nul 2>&1
    if !errorlevel! neq 0 (
        echo [CAP NHAT] Virtual environment cu khong phai Python 3.14. Dang tu dong tao lai...
        rmdir /s /q venv >nul 2>&1
        %PY_CMD% -m venv venv
    ) else (
        echo [OK] Tim thay virtual environment Python 3.14 san co.
    )
)

echo.
echo Dang nang cap pip, setuptools va wheel...
"venv\Scripts\python.exe" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 (
    echo [ERROR] Nang cap pip that bai. Kiem tra Internet va thu chay lai.
    pause
    exit /b 1
)

echo.
echo Dang cai dat thu vien tu requirements.txt...
"venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Cai thu vien that bai. Bot chua san sang chay.
    pause
    exit /b 1
)

echo.
echo Dang kiem tra cac goi Python...
"venv\Scripts\python.exe" -m pip check
if errorlevel 1 (
    echo [ERROR] Phat hien xung dot goi Python. Kiem tra log pip o phia tren.
    pause
    exit /b 1
)

if not exist "data" mkdir data
if not exist "data\historical" mkdir "data\historical"
if not exist "data\models" mkdir "data\models"
if not exist "logs" mkdir logs

if not exist ".env" (
    echo [WARNING] Chua co file .env. Dang tao file .env mau...
    (
        echo BINANCE_API_KEY=
        echo BINANCE_API_SECRET=
        echo TELEGRAM_BOT_TOKEN=
        echo TELEGRAM_CHAT_ID=
    ) > .env
    echo [INFO] Hay mo file .env de dien API key truoc khi bat LIVE.
) else (
    echo [OK] Tim thay file cau hinh .env.
)

echo.
echo =======================================================
echo KIEM TRA OLLAMA VA QUAN LY MODEL AI CHUAN CHO BOT
echo =======================================================
where ollama >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Chua cai dat Ollama.
    echo Hay cai Ollama tai https://ollama.com/download/windows roi chay lai install.bat.
    goto :ollama_done
)

echo [INFO] Dang kiem tra thu vien model trong Ollama...

REM 1. TU DONG XOA CAC MODEL CU / KHONG DUNG DE GIAI PHONG O DIA VA TRANH LON XON
for %%M in (qwen3:14b qwen2.5:14b deepseek-r1:14b llama3.2:3b llama3:latest) do (
    ollama list | findstr /i "%%M" >nul 2>&1
    if not errorlevel 1 (
        echo [XOA] Phat hien model %%M khong dung. Dang xoa de nhe o dia...
        ollama rm %%M
        echo [OK] Da xoa model %%M thanh cong!
    )
)

REM 2. KIEM TRA VA TAI MODEL CHINH DUY NHAT: qwen2.5:7b [Diem ngot chuan nhat cho card GTX 1060 6GB]
ollama list | findstr /i "qwen2.5:7b" >nul 2>&1
if errorlevel 1 (
    echo [TAI VE] Chua co model chinh qwen2.5:7b [4.7 GB]. Dang tu dong tai ve...
    ollama pull qwen2.5:7b
    if errorlevel 1 (
        echo [WARNING] Khong tai duoc qwen2.5:7b. Kiem tra ket noi Internet va thu lai.
    ) else (
        echo [OK] Da tai thanh cong model duy nhat qwen2.5:7b.
    )
) else (
    echo [OK] Model chuan duy nhat qwen2.5:7b [4.7 GB] da co san va san sang su dung.
)

:ollama_done

echo.
echo  =====================
echo  CAI DAT GOI PYTHON HOAN TAT
echo  =====================
echo  Chay START.bat de mo dashboard.
echo  Can may tinh co Internet va khong vao che do Sleep de treo lien tuc.
echo  Sau khi mo dashboard, mac dinh hay kiem tra DEMO truoc.
echo  Khong chuyen LIVE neu chua chu dong chap nhan giao dich bang tien that.
echo.
pause
exit /b 0
