"""
TRADEMATRIX WORKSPACE CLEANUP PROTOCOL
Tuân thủ Hiến pháp: Tự động dọn sạch rác, script kiểm thử tạm thời trên PC1 và PC2 khi Chấm Điểm.
Giữ không gian làm việc tinh gọn 100%, chống nhầm lẫn giữa code bot và script test.
Hỗ trợ cờ --dry-run để xem trước danh sách tệp sắp dọn dẹp.
"""
import os
import shutil
import glob
import sys
import argparse

sys.stdout.reconfigure(encoding='utf-8')

PC1_ROOT = r'd:\TRADE'
DIST_ROOT = r'D:\TradeMatrix_Client_v2.0'
PC2_ROOT = r'\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0'

OBSOLETE_REL_PATHS = (
    'core/firebase_telemetry.py',
    'core/order_manager.py',
    'risk/position_sizer.py',
    'sync_telemetry_loop.py',
)

def purge_workspace(verbose=True, dry_run=False):
    cleaned = []
    
    # 1. Clean scratch folder on PC1
    scratch_dir = os.path.join(PC1_ROOT, 'scratch')
    if os.path.exists(scratch_dir):
        for item in os.listdir(scratch_dir):
            p = os.path.join(scratch_dir, item)
            try:
                if not dry_run:
                    if os.path.isdir(p):
                        shutil.rmtree(p)
                    else:
                        os.remove(p)
                tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                cleaned.append(f"{tag}PC1 Scratch: {item}")
            except Exception:
                pass
                
    # 2. Clean temporary/junk files & 0-byte stray .db files in PC1, DIST, and PC2
    junk_patterns = ('.bak', '.bak_v4', '.tmp', '.dump', '.log.bak')
    for label, base_root in (('PC1', PC1_ROOT), ('DIST', DIST_ROOT), ('PC2', PC2_ROOT)):
        if not os.path.exists(base_root):
            continue
        for rel_obs in OBSOLETE_REL_PATHS:
            obs_path = os.path.join(base_root, *rel_obs.split('/'))
            if os.path.exists(obs_path):
                try:
                    if not dry_run:
                        os.remove(obs_path)
                    tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                    cleaned.append(f"{tag}{label} Obsolete Module: {rel_obs}")
                except Exception:
                    pass
        for root, dirs, files in os.walk(base_root):
            if 'venv' in root or '.git' in root or 'logs' in root:
                continue
            for f in files:
                p = os.path.join(root, f)
                rel_p = os.path.relpath(p, base_root).replace('\\', '/')
                is_zero_byte_db = (
                    f.endswith(('.db', '.sqlite', '.sqlite3'))
                    and rel_p != 'data/trade_bot.db'
                    and os.path.getsize(p) == 0
                )
                is_corrupt_model = (
                    rel_p.startswith('data/models/')
                    and f.endswith('.pkl')
                    and ('?' in f or not f.isascii())
                )
                if f == '=' or any(f.endswith(pat) for pat in junk_patterns) or is_zero_byte_db or is_corrupt_model:
                    if label in ('DIST', 'PC2') and rel_p.startswith('data/') and not (is_zero_byte_db or is_corrupt_model):
                        continue
                    try:
                        if not dry_run:
                            os.remove(p)
                        tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                        cleaned.append(f"{tag}{label} Junk: {rel_p}")
                    except Exception:
                        pass

        if label == 'PC2':
            pc2_scratch = os.path.join(base_root, 'scratch')
            if os.path.exists(pc2_scratch):
                try:
                    if not dry_run:
                        shutil.rmtree(pc2_scratch)
                    tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                    cleaned.append(f"{tag}PC2 Scratch folder")
                except Exception:
                    pass

    if verbose:
        mode_str = "[DRY-RUN XEM TRƯỚC]" if dry_run else "[WORKSPACE CLEANUP ĐÃ XÓA]"
        print(f"🧹 {mode_str} Tổng cộng: {len(cleaned)} tệp rác / script tạm thời:")
        for item in cleaned[:20]:
            print(f"   - {item}")
        if len(cleaned) > 20:
            print(f"   ... và {len(cleaned) - 20} tệp khác.")
        if len(cleaned) == 0:
            print("   ✅ Không gian làm việc đã sạch sẽ 100%, không có file rác!")

    return len(cleaned)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="TradeMatrix Workspace Cleanup Protocol")
    parser.add_argument('--dry-run', action='store_true', help='Chỉ xem trước danh sách tệp sẽ dọn dẹp, không xóa thật')
    args = parser.parse_args()
    purge_workspace(verbose=True, dry_run=args.dry_run)
