"""
TRADEMATRIX WORKSPACE CLEANUP PROTOCOL
Tuân thủ Hiến pháp: Tự động dọn sạch rác, script kiểm thử tạm thời trên PC1 và PC2 khi Chấm Điểm.
Giữ không gian làm việc tinh gọn 100%, chống nhầm lẫn giữa code bot và script test.
"""
import os
import shutil
import glob
import sys

sys.stdout.reconfigure(encoding='utf-8')

PC1_ROOT = r'd:\TRADE'
PC2_ROOT = r'\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0'

def purge_workspace(verbose=True):
    cleaned = []
    
    # 1. Clean scratch folder on PC1
    scratch_dir = os.path.join(PC1_ROOT, 'scratch')
    if os.path.exists(scratch_dir):
        for item in os.listdir(scratch_dir):
            p = os.path.join(scratch_dir, item)
            try:
                if os.path.isdir(p):
                    shutil.rmtree(p)
                else:
                    os.remove(p)
                cleaned.append(f"PC1 Scratch: {item}")
            except Exception as e:
                pass
                
    # 2. Clean temporary/junk files in PC1 root and subdirectories
    for root, dirs, files in os.walk(PC1_ROOT):
        if 'venv' in root or '.git' in root or 'logs' in root:
            continue
        for f in files:
            p = os.path.join(root, f)
            # Match junk patterns
            if f == '=' or f.endswith('.bak') or f.endswith('.bak_v4') or f.endswith('.tmp') or f.endswith('.dump') or f.endswith('.log.bak'):
                try:
                    os.remove(p)
                    cleaned.append(f"PC1 Root/Sub: {os.path.relpath(p, PC1_ROOT)}")
                except:
                    pass

    # 3. Clean PC2 junk/backup files
    if os.path.exists(PC2_ROOT):
        for root, dirs, files in os.walk(PC2_ROOT):
            if 'venv' in root or '.git' in root or 'logs' in root or 'data' in root:
                continue
            for f in files:
                p = os.path.join(root, f)
                if f.endswith('.bak') or f.endswith('.tmp') or f == '=':
                    try:
                        os.remove(p)
                        cleaned.append(f"PC2 Junk: {os.path.relpath(p, PC2_ROOT)}")
                    except:
                        pass
        # Clean scratch on PC2 if someone created it
        pc2_scratch = os.path.join(PC2_ROOT, 'scratch')
        if os.path.exists(pc2_scratch):
            try:
                shutil.rmtree(pc2_scratch)
                cleaned.append("PC2 Scratch folder")
            except:
                pass

    if verbose:
        print(f"🧹 [WORKSPACE CLEANUP] Đã dọn sạch {len(cleaned)} tệp rác / script tạm thời:")
        for item in cleaned[:20]:
            print(f"   - {item}")
        if len(cleaned) > 20:
            print(f"   ... và {len(cleaned) - 20} tệp khác.")
        if len(cleaned) == 0:
            print("   ✅ Không gian làm việc đã sạch sẽ 100%, không có file rác!")

    return len(cleaned)

if __name__ == '__main__':
    purge_workspace(verbose=True)
