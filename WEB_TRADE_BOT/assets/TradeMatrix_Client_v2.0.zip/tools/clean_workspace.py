"""
TRADEMATRIX WORKSPACE CLEANUP PROTOCOL
Tuân thủ Hiến pháp: Tự động dọn sạch rác, script kiểm thử tạm thời trên PC1 và PC2 khi Chấm Điểm.
Giữ không gian làm việc tinh gọn 100%, chống nhầm lẫn giữa code bot và script test.
Hỗ trợ cờ --dry-run để xem trước danh sách tệp sắp dọn dẹp.
"""
import os
import shutil
import glob
import sys
import argparse

sys.stdout.reconfigure(encoding='utf-8')

PC1_ROOT = r'd:\TRADE'
PC2_ROOT = r'\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0'

def purge_workspace(verbose=True, dry_run=False):
    cleaned = []
    
    # 1. Clean scratch folder on PC1
    scratch_dir = os.path.join(PC1_ROOT, 'scratch')
    if os.path.exists(scratch_dir):
        for item in os.listdir(scratch_dir):
            p = os.path.join(scratch_dir, item)
            try:
                if not dry_run:
                    if os.path.isdir(p):
                        shutil.rmtree(p)
                    else:
                        os.remove(p)
                tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                cleaned.append(f"{tag}PC1 Scratch: {item}")
            except Exception as e:
                pass
                
    # 2. Clean temporary/junk files in PC1 root and subdirectories
    junk_patterns = ('.bak', '.bak_v4', '.tmp', '.dump', '.log.bak')
    for root, dirs, files in os.walk(PC1_ROOT):
        if 'venv' in root or '.git' in root or 'logs' in root:
            continue
        for f in files:
            p = os.path.join(root, f)
            # Match junk patterns
            if f == '=' or any(f.endswith(pat) for pat in junk_patterns):
                try:
                    if not dry_run:
                        os.remove(p)
                    tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                    cleaned.append(f"{tag}PC1 Root/Sub: {os.path.relpath(p, PC1_ROOT)}")
                except:
                    pass

    # 3. Clean PC2 junk/backup files
    if os.path.exists(PC2_ROOT):
        for root, dirs, files in os.walk(PC2_ROOT):
            if 'venv' in root or '.git' in root or 'logs' in root or 'data' in root:
                continue
            for f in files:
                p = os.path.join(root, f)
                if f == '=' or any(f.endswith(pat) for pat in junk_patterns):
                    try:
                        if not dry_run:
                            os.remove(p)
                        tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                        cleaned.append(f"{tag}PC2 Junk: {os.path.relpath(p, PC2_ROOT)}")
                    except:
                        pass
        # Clean scratch on PC2 if someone created it
        pc2_scratch = os.path.join(PC2_ROOT, 'scratch')
        if os.path.exists(pc2_scratch):
            try:
                if not dry_run:
                    shutil.rmtree(pc2_scratch)
                tag = "[DRY-RUN Sẽ xóa] " if dry_run else ""
                cleaned.append(f"{tag}PC2 Scratch folder")
            except:
                pass

    if verbose:
        mode_str = "[DRY-RUN XEM TRƯỚC]" if dry_run else "[WORKSPACE CLEANUP ĐÃ XÓA]"
        print(f"🧹 {mode_str} Tổng cộng: {len(cleaned)} tệp rác / script tạm thời:")
        for item in cleaned[:20]:
            print(f"   - {item}")
        if len(cleaned) > 20:
            print(f"   ... và {len(cleaned) - 20} tệp khác.")
        if len(cleaned) == 0:
            print("   ✅ Không gian làm việc đã sạch sẽ 100%, không có file rác!")

    return len(cleaned)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="TradeMatrix Workspace Cleanup Protocol")
    parser.add_argument('--dry-run', action='store_true', help='Chỉ xem trước danh sách tệp sẽ dọn dẹp, không xóa thật')
    args = parser.parse_args()
    purge_workspace(verbose=True, dry_run=args.dry_run)
