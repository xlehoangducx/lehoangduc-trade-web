"""
TRADEMATRIX FULL-SPECTRUM IMPACT SIMULATOR (CỖ MÁY ĐỐI CHỨNG ĐA LỚP TÀI SẢN)
Bóc tách toàn bộ lịch sử vị thế Round-trip từ trade_bot.db (lọc chuẩn 'Binance Fill' và trừ đủ phí Maker/Taker)
theo Ma trận 3 Lớp Tài Sản (Major Crypto, TradFi Cổ Phiếu Mỹ, Crypto Altcoins).
"""

import os
import sys
import sqlite3
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

ROOT_DIR = Path(__file__).parent.parent
PC2_DB = Path(r"\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\data\trade_bot.db")
LOCAL_DB = ROOT_DIR / "data" / "trade_bot.db"

def run_full_spectrum_simulation():
    print("=" * 88)
    print("🔬 TRADEMATRIX FULL-SPECTRUM IMPACT SIMULATOR — ĐỐI CHỨNG 3 LỚP TÀI SẢN (ROUND-TRIP NET PNL)")
    print("=" * 88)

    db_path = PC2_DB if PC2_DB.exists() else LOCAL_DB
    if not db_path.exists():
        print("❌ Không tìm thấy database trade_bot.db.")
        return

    conn = sqlite3.connect(str(db_path))
    cur = conn.cursor()

    cur.execute("""
        SELECT id, timestamp, symbol, side, price, amount, realized_pnl, fee, close_reason
        FROM trades
        WHERE strategy = 'Binance Fill'
        ORDER BY timestamp ASC, id ASC
    """)
    rows = cur.fetchall()
    conn.close()

    if not rows:
        print("Không có dữ liệu giao dịch để phân tích.")
        return

    # Gom các fill thành các vị thế Round-trip chuẩn (bao gồm cả phí mở và phí đóng)
    open_track = {}
    closed_positions = []

    for r in rows:
        tid, ts, sym, side, price, amount, rpnl, fee, reason = r
        rpnl = float(rpnl or 0.0)
        fee = float(fee or 0.0)
        amount = float(amount or 0.0)

        if abs(rpnl) < 1e-8:
            if sym not in open_track:
                open_track[sym] = {'open_fees': fee}
            else:
                open_track[sym]['open_fees'] += fee
        else:
            open_fee = open_track.pop(sym, {}).get('open_fees', 0.0)
            net_pnl = rpnl - fee - open_fee
            if closed_positions and closed_positions[-1]['symbol'] == sym and abs(ts - closed_positions[-1]['last_ts']) <= 300_000:
                closed_positions[-1]['net_pnl'] += net_pnl
                closed_positions[-1]['gross_pnl'] += rpnl
                closed_positions[-1]['fees'] += (fee + open_fee)
                closed_positions[-1]['last_ts'] = ts
            else:
                closed_positions.append({
                    'symbol': sym,
                    'gross_pnl': rpnl,
                    'fees': fee + open_fee,
                    'net_pnl': net_pnl,
                    'last_ts': ts,
                })

    # [BÀI HỌC 110 - SSOT 3 LỚP TÀI SẢN]: Đồng bộ 100% với MarketScanner
    try:
        from core.scanner import MarketScanner
        is_tradfi_fn = lambda s: MarketScanner.is_tradfi_stock(s) or (hasattr(MarketScanner, 'is_tradfi_commodity') and MarketScanner.is_tradfi_commodity(s))
    except Exception:
        is_tradfi_fn = lambda s: s.split('/')[0].upper() in {'NVDA', 'TSLA', 'AAPL', 'MSFT', 'AMZN', 'GOOGL', 'META', 'AMD', 'INTC', 'MRVL', 'TQQQ', 'PLTR', 'COIN'}
    tier1_crypto = {'BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'XRP/USDT'}

    stats = {
        'total': {'wins': 0, 'losses': 0, 'win_pnl': 0.0, 'loss_pnl': 0.0, 'fees': 0.0},
        'tier1': {'wins': 0, 'losses': 0, 'win_pnl': 0.0, 'loss_pnl': 0.0, 'fees': 0.0},
        'tradfi': {'wins': 0, 'losses': 0, 'win_pnl': 0.0, 'loss_pnl': 0.0, 'fees': 0.0},
        'altcoins': {'wins': 0, 'losses': 0, 'win_pnl': 0.0, 'loss_pnl': 0.0, 'fees': 0.0},
    }

    for pos in closed_positions:
        sym = pos['symbol']
        pnl = pos['net_pnl']
        fees = pos['fees']
        if sym in tier1_crypto or sym.split('/')[0].upper() in {'BTC', 'ETH', 'SOL', 'BNB', 'XRP'}:
            cat = 'tier1'
        elif is_tradfi_fn(sym):
            cat = 'tradfi'
        else:
            cat = 'altcoins'

        stats['total']['fees'] += fees
        stats[cat]['fees'] += fees
        if pnl > 0:
            stats['total']['wins'] += 1
            stats['total']['win_pnl'] += pnl
            stats[cat]['wins'] += 1
            stats[cat]['win_pnl'] += pnl
        else:
            stats['total']['losses'] += 1
            stats['total']['loss_pnl'] += abs(pnl)
            stats[cat]['losses'] += 1
            stats[cat]['loss_pnl'] += abs(pnl)

    print("\n📊 1. HIỆU SUẤT VỊ THẾ LỊCH SỬ (ROUND-TRIP ĐÃ TRỪ ĐỦ PHÍ) THEO 3 LỚP TÀI SẢN:")
    print("-" * 88)
    print(f"{'Lớp Tài Sản':<24} | {'Vị thế':<6} | {'Thắng/Thua':<12} | {'Win Rate':<9} | {'Tổng Lãi (+)':<12} | {'Tổng Lỗ (-)':<12} | {'Net PnL':<10}")
    print("-" * 88)

    for cat_name, label in [('tradfi', 'TradFi Cổ Phiếu Mỹ'), ('tier1', 'Major Crypto (Tier-1)'), ('altcoins', 'Crypto Altcoins'), ('total', 'TOÀN BỘ DANH MỤC')]:
        d = stats[cat_name]
        total_c = d['wins'] + d['losses']
        wr = (d['wins'] / total_c * 100) if total_c > 0 else 0.0
        net = d['win_pnl'] - d['loss_pnl']
        print(f"{label:<24} | {total_c:<6} | {d['wins']:>3}W / {d['losses']:<3}L | {wr:6.1f}%   | {d['win_pnl']:+9.4f}$   | {-d['loss_pnl']:+9.4f}$   | {net:+8.4f}$")
    print("-" * 88)

if __name__ == '__main__':
    run_full_spectrum_simulation()
