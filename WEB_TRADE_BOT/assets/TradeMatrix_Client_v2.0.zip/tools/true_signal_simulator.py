# -*- coding: utf-8 -*-
"""
TRADEMATRIX TRUE SIGNAL REPLAY SIMULATOR
Công cụ mô phỏng & tái lập dữ liệu tín hiệu thực chiến từ nhật ký (bot_*.log).
Trích xuất toàn bộ các cụm tín hiệu (Strategies, AI Ensemble, JEV Agent, Market Meta)
và chạy trực tiếp qua bộ lọc SignalAggregator hiện tại để kiểm chứng tính nhất quán.
"""

import os
import sys
import re
import glob
from datetime import datetime
from typing import List, Dict, Any, Optional

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from ai.signal_aggregator import SignalAggregator, Signal, TradeSignal

def parse_and_simulate_log(log_path: str, max_clusters: int = 100):
    print("=" * 80)
    print(f"📊 TRADEMATRIX TRUE SIGNAL REPLAY ENGINE")
    print(f"📁 Tệp nhật ký đang quét: {log_path}")
    print("=" * 80)
    
    if not os.path.exists(log_path):
        print(f"❌ Không tìm thấy tệp log: {log_path}")
        return

    aggregator = SignalAggregator()
    
    # Regular expressions for signals
    re_strat = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}).*?📊 \[(\w+)\] ([A-Z0-9/]+) (\w+): (BUY|SELL) \(confidence: ([\d.]+)%\)')
    re_ai = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}).*?🧠 \[AI Ensemble\] ([A-Z0-9/]+): (BUY|SELL) \(confidence: ([\d.]+)%\)')
    re_jev = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}).*?\[JEV Agent - [^\]]+\] ([A-Z0-9/]+) -> (BUY|SELL|HOLD) \(([\d.]+)\) - ([^|]+)(?:\| Risk: (.*))?')
    re_agg = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}).*?Aggregated score for ([A-Z0-9/]+): ([+-]?[\d.]+)')
    re_final = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}).*?TIN HIEU CUOI: (BUY|SELL) ([A-Z0-9/]+) \(confidence: ([\d.]+)%\)')
    re_meta = re.compile(r'Dynamic leverage ([A-Z0-9/]+):.*?ADX=([\d.]+), ATR=([\d.]+)%')
    
    clusters = []
    curr_cluster = None
    
    with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            m_strat = re_strat.search(line)
            if m_strat:
                ts, strat, sym, tf, dir_str, conf = m_strat.groups()
                if not curr_cluster or curr_cluster['symbol'] != sym:
                    if curr_cluster and curr_cluster.get('signals'):
                        clusters.append(curr_cluster)
                    curr_cluster = {'symbol': sym, 'timestamp': ts, 'signals': [], 'hist_final': None, 'meta': {}}
                
                sig_enum = Signal.BUY if dir_str == 'BUY' else Signal.SELL
                curr_cluster['signals'].append(
                    TradeSignal(sig_enum, sym, float(conf)/100.0, strat, 1.0, metadata={'timeframe': tf})
                )
                continue
                
            m_ai = re_ai.search(line)
            if m_ai:
                ts, sym, dir_str, conf = m_ai.groups()
                if curr_cluster and curr_cluster['symbol'] == sym:
                    sig_enum = Signal.BUY if dir_str == 'BUY' else Signal.SELL
                    curr_cluster['signals'].append(
                        TradeSignal(sig_enum, sym, float(conf)/100.0, 'ai_ensemble', 1.0, metadata={'timeframe': '15m'})
                    )
                continue
                
            m_jev = re_jev.search(line)
            if m_jev:
                ts, sym, dir_str, conf, reason, risk = m_jev.groups()
                if curr_cluster and curr_cluster['symbol'] == sym:
                    sig_enum = Signal.BUY if dir_str == 'BUY' else (Signal.SELL if dir_str == 'SELL' else Signal.HOLD)
                    curr_cluster['signals'].append(
                        TradeSignal(sig_enum, sym, float(conf), 'jev_agent', 1.0, metadata={
                            'timeframe': '1h', 'reason': reason.strip(), 'risk_factors': risk.strip() if risk else 'none'
                        })
                    )
                continue
                
            m_meta = re_meta.search(line)
            if m_meta:
                sym, adx, atr = m_meta.groups()
                if curr_cluster and curr_cluster['symbol'] == sym:
                    curr_cluster['meta']['adx'] = float(adx)
                    curr_cluster['meta']['atr_pct'] = float(atr)
                continue
                
            m_final = re_final.search(line)
            if m_final:
                ts, dir_str, sym, conf = m_final.groups()
                if curr_cluster and curr_cluster['symbol'] == sym:
                    curr_cluster['hist_final'] = (dir_str, float(conf)/100.0)
                continue
                
            m_agg = re_agg.search(line)
            if m_agg:
                ts, sym, score = m_agg.groups()
                if curr_cluster and curr_cluster['symbol'] == sym:
                    curr_cluster['hist_score'] = float(score)
                    clusters.append(curr_cluster)
                    curr_cluster = None
                    if len(clusters) >= max_clusters:
                        break
                continue

    if curr_cluster and curr_cluster.get('signals'):
        clusters.append(curr_cluster)

    print(f"✅ Đã trích xuất thành công: {len(clusters)} cụm tín hiệu thực tế.")
    
    diff_count = 0
    new_trades = 0
    blocked_trades = 0
    same_trades = 0
    
    print("\n" + "-" * 80)
    print("KẾT QUẢ ĐỐI CHỨNG GIỮA QUYẾT ĐỊNH LỊCH SỬ VÀ MÃ NGUỒN HIỆN TẠI:")
    print("-" * 80)
    
    eval_slice = clusters[:max_clusters]
    for cl in eval_slice:
        sym = cl['symbol']
        sigs = cl['signals']
        hist_final = cl.get('hist_final')
        
        if cl.get('meta'):
            for s in sigs:
                s.metadata['market_analysis'] = cl['meta']
                
        res = aggregator.aggregate(sigs)
        curr_res = (res.signal.value.upper(), res.confidence) if res and res.signal != Signal.HOLD else None
        
        if hist_final != curr_res:
            diff_count += 1
            if hist_final is None and curr_res is not None:
                new_trades += 1
                status = f"⚡ MỞ LỆNH MỚI: {curr_res[0]} {curr_res[1]:.1%}"
            elif hist_final is not None and curr_res is None:
                blocked_trades += 1
                status = f"🛡️ CHẶN LỆNH CŨ: (Lịch sử: {hist_final[0]} {hist_final[1]:.1%})"
            else:
                status = f"🔄 ĐẢO HƯỚNG/ĐIỂM: Cũ={hist_final} -> Mới={curr_res}"
        else:
            same_trades += 1
            status = f"✅ ĐỒNG NHẤT 100%: {curr_res}"
            
        print(f"[{cl['timestamp']}] {sym:12s} | Chiến thuật: {len(sigs):2d} | {status}")

    print("\n" + "=" * 80)
    print(f"📊 BẢNG TỔNG KẾT ĐỐI CHỨNG THỰC NGHIỆM:")
    print(f"  • Tổng số cụm tín hiệu đánh giá : {len(eval_slice)}")
    print(f"  • Quyết định đồng nhất 100%    : {same_trades} ({same_trades/len(eval_slice)*100:.1f}%)" if eval_slice else "0")
    print(f"  • Số lượng quyết định thay đổi : {diff_count}")
    print(f"    - Mở lệnh hợp lệ mới        : {new_trades}")
    print(f"    - Chặn lệnh xấu / rủi ro    : {blocked_trades}")
    print("=" * 80)

def find_latest_log():
    # Look for logs in local project or PC2
    candidates = [
        os.path.join(PROJECT_ROOT, 'logs', 'bot_*.log'),
        r'\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\logs\bot_*.log'
    ]
    all_files = []
    for pattern in candidates:
        all_files.extend(glob.glob(pattern))
    if not all_files:
        return None
    all_files.sort(key=os.path.getmtime, reverse=True)
    return all_files[0]

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    log_arg = sys.argv[1] if len(sys.argv) > 1 else None
    if not log_arg:
        log_arg = find_latest_log()
    
    if not log_arg or not os.path.exists(log_arg):
        print(f"❌ Không tìm thấy tệp nhật ký nào. Hãy truyền đường dẫn log: python true_signal_simulator.py <path_to_log>")
        sys.exit(1)
        
    parse_and_simulate_log(log_arg, max_clusters=50)
