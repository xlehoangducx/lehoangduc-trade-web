"""
TRADEMATRIX HARD CONSTRAINTS GATE (RÀO CHẮN CỨNG BẰNG CODE)
Tự động quét toàn bộ mã nguồn để phát hiện và ngăn chặn vĩnh viễn các lỗi logic ngầm
đã từng gây thiệt hại trong quá khứ trước khi cho phép đóng gói hoặc deploy sang PC2.
"""

import ast
import os
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

ROOT_DIR = Path(__file__).parent.parent

class CodeConstraintAuditor:
    def __init__(self, root_dir):
        self.root_dir = Path(root_dir)
        self.violations = []

    def check_all(self):
        self.violations = []
        self._check_purged_time_exits()
        self._check_jev_pop_in_aggregator()
        self._check_sl_clamping()
        self._check_api_stop_idempotency()
        self._check_license_cache_in_loop()
        return self.violations

    def _check_purged_time_exits(self):
        """RÀO CHẮN 1: Cấm tái kích hoạt các cơ chế thoát lệnh theo thời gian mù quáng (DOA 15/25/35m, idle_120m)."""
        cfg_path = self.root_dir / 'config' / 'settings.yaml'
        if cfg_path.exists():
            content = cfg_path.read_text(encoding='utf-8')
            for bad_key in ['doa_15m: true', 'doa_25m: true', 'doa_35m: true', 'idle_120m: true', 'ladder_sl: true']:
                if bad_key in content:
                    self.violations.append(f"[RÀO CHẮN 1 - PURGED ANTI-PATTERN] Phát hiện bật cờ nguy hiểm trong settings.yaml: '{bad_key}'")

    def _check_jev_pop_in_aggregator(self):
        """RÀO CHẮN 2: Cấm xóa sổ JEV Agent trong signal_aggregator.py khi JEV đang báo trend mạnh."""
        agg_path = self.root_dir / 'ai' / 'signal_aggregator.py'
        if agg_path.exists():
            content = agg_path.read_text(encoding='utf-8')
            # Kiểm tra xem có còn đoạn pop jev_agent mà không được che chắn bởi JEV MTF TREND SHIELD không
            if "by_strategy.pop('jev_agent', None)" in content:
                # Phải có khiên JEV MTF TREND SHIELD bảo vệ
                if "JEV MTF TREND SHIELD" not in content or "jev_vote >= 0.70" not in content:
                    self.violations.append("[RÀO CHẮN 2 - FATAL SEMANTIC BUG] Phát hiện 'pop(jev_agent)' không có khiên JEV MTF TREND SHIELD bảo vệ!")

    def _check_sl_clamping(self):
        """RÀO CHẮN 3: Cấm kẹp trần SL cứng 1.5% đối với các coin có ATR 15m cao trong core/bot.py."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            content = bot_path.read_text(encoding='utf-8')
            # Nếu còn đoạn min(0.015, max(0.010, 1.0 * effective_15m_atr_pct))
            bad_pattern = "min(0.015, max(0.010, 1.0 * effective_15m_atr_pct))"
            if bad_pattern in content:
                self.violations.append("[RÀO CHẮN 3 - SL SUFFOCATION] Phát hiện SL kẹp trần cứng 1.5% gây bóp nghẹt vị thế coin biến động lớn!")

    def _check_api_stop_idempotency(self):
        """RÀO CHẮN 4: Endpoint /api/stop và /api/pause không bao giờ được trả về error 'Bot chưa chạy'."""
        app_path = self.root_dir / 'dashboard' / 'app.py'
        if app_path.exists():
            content = app_path.read_text(encoding='utf-8')
            if "'error': 'Bot chưa chạy'" in content or '"error": "Bot chưa chạy"' in content:
                self.violations.append("[RÀO CHẮN 4 - WEB REMOTE ERROR] Endpoint dừng bot trả về lỗi 'Bot chưa chạy' làm Web báo đỏ!")

    def _check_license_cache_in_loop(self):
        """RÀO CHẮN 5: Cấm gửi request verify_license lên Firestore mỗi giây trong cloud_sync.py."""
        sync_path = self.root_dir / 'cloud_sync.py'
        if sync_path.exists():
            content = sync_path.read_text(encoding='utf-8')
            if "_last_license_check_time" not in content:
                self.violations.append("[RÀO CHẮN 5 - NETWORK BOTTLENECK] cloud_sync.py thiếu bộ đệm cache bản quyền 60s, gây nghẽn mạng điều khiển!")

def run_gate():
    print("=" * 70)
    print("🛡️  TRADEMATRIX HARD CONSTRAINTS GATE - KIỂM TOÁN RÀO CHẮN CỨNG")
    print("=" * 70)
    auditor = CodeConstraintAuditor(ROOT_DIR)
    violations = auditor.check_all()

    if not violations:
        print("✅ [PASSED 100%] Toàn bộ 5 Rào chắn cứng bảo toàn! Không có lỗi lặp lại.")
        print("=" * 70)
        return 0
    else:
        print(f"❌ [BUILD REJECTED] Phát hiện {len(violations)} vi phạm rào chắn cứng:")
        for i, v in enumerate(violations, 1):
            print(f"  {i}. {v}")
        print("=" * 70)
        print("🛑 Lập trình viên / AI phải sửa triệt để các vi phạm trên trước khi deploy!")
        return 1

if __name__ == '__main__':
    sys.exit(run_gate())
