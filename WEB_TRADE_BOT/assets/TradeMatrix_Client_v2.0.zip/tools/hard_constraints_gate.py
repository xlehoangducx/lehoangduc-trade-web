"""
TRADEMATRIX HARD CONSTRAINTS GATE (RÀO CHẮN CỨNG BẰNG CODE)
Tự động quét toàn bộ mã nguồn để phát hiện và ngăn chặn vĩnh viễn các lỗi logic ngầm
đã từng gây thiệt hại trong quá khứ trước khi cho phép đóng gói hoặc deploy sang PC2.
"""

import ast
import os
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

ROOT_DIR = Path(__file__).parent.parent

class CodeConstraintAuditor:
    def __init__(self, root_dir):
        self.root_dir = Path(root_dir)
        self.violations = []

    def check_all(self):
        self.violations = []
        self._check_purged_time_exits()
        self._check_jev_pop_in_aggregator()
        self._check_sl_clamping()
        self._check_api_stop_idempotency()
        self._check_license_cache_in_loop()
        self._check_macro_trend_veto_override()
        self._check_altcoin_sl_ceiling()
        self._check_cushion_sl_timing()
        self._check_ast_runtime_variable_sanity()
        return self.violations

    def _check_purged_time_exits(self):
        """RÀO CHẮN 1: Cấm tái kích hoạt các cơ chế thoát lệnh theo thời gian mù quáng (DOA 15/25/35m, idle_120m)."""
        cfg_path = self.root_dir / 'config' / 'settings.yaml'
        if cfg_path.exists():
            content = cfg_path.read_text(encoding='utf-8')
            for bad_key in ['doa_15m: true', 'doa_25m: true', 'doa_35m: true', 'idle_120m: true', 'ladder_sl: true']:
                if bad_key in content:
                    self.violations.append(f"[RÀO CHẮN 1 - PURGED ANTI-PATTERN] Phát hiện bật cờ nguy hiểm trong settings.yaml: '{bad_key}'")

    def _check_jev_pop_in_aggregator(self):
        """RÀO CHẮN 2: Cấm xóa sổ JEV Agent trong signal_aggregator.py khi JEV đang báo trend mạnh."""
        agg_path = self.root_dir / 'ai' / 'signal_aggregator.py'
        if agg_path.exists():
            content = agg_path.read_text(encoding='utf-8')
            if "by_strategy.pop('jev_agent', None)" in content:
                if "JEV MTF TREND SHIELD" not in content or "jev_vote >= 0.70" not in content:
                    self.violations.append("[RÀO CHẮN 2 - FATAL SEMANTIC BUG] Phát hiện 'pop(jev_agent)' không có khiên JEV MTF TREND SHIELD bảo vệ!")

    def _check_sl_clamping(self):
        """RÀO CHẮN 3: Bảo đảm Stop-Loss luôn nằm trong khung an toàn định lượng [1.0%, 3.5%], không thả trôi quá trần."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            content = bot_path.read_text(encoding='utf-8')
            if "clamped_sl_dist = " not in content:
                self.violations.append("[RÀO CHẮN 3 - SL SAFETY] Thiếu kẹp trần an toàn clamped_sl_dist trong core/bot.py!")

    def _check_api_stop_idempotency(self):
        """RÀO CHẮN 4: Endpoint /api/stop và /api/pause không bao giờ được trả về error 'Bot chưa chạy'."""
        app_path = self.root_dir / 'dashboard' / 'app.py'
        if app_path.exists():
            content = app_path.read_text(encoding='utf-8')
            if "'error': 'Bot chưa chạy'" in content or '"error": "Bot chưa chạy"' in content:
                self.violations.append("[RÀO CHẮN 4 - WEB REMOTE ERROR] Endpoint dừng bot trả về lỗi 'Bot chưa chạy' làm Web báo đỏ!")

    def _check_license_cache_in_loop(self):
        """RÀO CHẮN 5: Cấm gửi request verify_license lên Firestore mỗi giây trong cloud_sync.py."""
        sync_path = self.root_dir / 'cloud_sync.py'
        if sync_path.exists():
            content = sync_path.read_text(encoding='utf-8')
            if "_last_license_check_time" not in content:
                self.violations.append("[RÀO CHẮN 5 - NETWORK BOTTLENECK] cloud_sync.py thiếu bộ đệm cache bản quyền 60s, gây nghẽn mạng điều khiển!")

    def _check_macro_trend_veto_override(self):
        """RÀO CHẮN 6: Cấm dùng râu nến giả hoặc thỏa hiệp chỉ báo trễ pha để cướp quyền Short ngược Uptrend mạnh."""
        agg_path = self.root_dir / 'ai' / 'signal_aggregator.py'
        if agg_path.exists():
            content = agg_path.read_text(encoding='utf-8')
            if "macro_bull_dominant and not is_whale_waterfall_breakdown" not in content:
                self.violations.append("[RÀO CHẮN 6 - MTF TREND VETO] Thiếu chốt chặn cấm bypass [VETO MTF STRONG UPTREND] trong signal_aggregator.py!")

    def _check_altcoin_sl_ceiling(self):
        """RÀO CHẮN 7: Altcoin biến động mạnh phải có biên độ Stop-Loss thích ứng ATR lên đến 3.5%, cấm bóp nghẹt ở 1.5%."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            content = bot_path.read_text(encoding='utf-8')
            if "alt_sl_cap = min(0.035," not in content:
                self.violations.append("[RÀO CHẮN 7 - ALTCOIN SL ADAPTIVE] Thiếu cơ chế trần SL thích ứng ATR 3.5% cho Altcoin trong core/bot.py!")

    def _check_cushion_sl_timing(self):
        """RÀO CHẮN 8: Cushion SL phải được bảo vệ bởi bộ lọc thời gian held_minutes >= 3.0, cấm giật SL non làm mất siêu sóng."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            content = bot_path.read_text(encoding='utf-8')
            if "held_minutes >= 3.0" not in content:
                self.violations.append("[RÀO CHẮN 8 - CUSHION SL TIMING] Thiếu bộ lọc thời gian held_minutes >= 3.0 cho Cushion SL trong core/bot.py!")

    def _check_ast_runtime_variable_sanity(self):
        """RÀO CHẮN 9: Kiểm tra cú pháp AST và tính toàn vẹn biến trong các hàm trọng yếu (Chống NameError)."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            try:
                tree = ast.parse(bot_path.read_text(encoding='utf-8'), filename=str(bot_path))
                raw_code = bot_path.read_text(encoding='utf-8')
                if "is_altcoin_loss = (not is_tradfi_pair) and (not is_major_pair)" in raw_code:
                    idx_assign = raw_code.find("is_tradfi_pair = MarketScanner.is_tradfi_stock")
                    idx_loss = raw_code.find("is_altcoin_loss = (not is_tradfi_pair)")
                    if idx_assign == -1 or idx_loss == -1 or idx_assign > idx_loss:
                        self.violations.append("[RÀO CHẮN 9 - AST NAME RESOLUTION] Lỗi chưa định nghĩa is_tradfi_pair trước khi dùng trong _check_open_positions_locked!")
                if "adx_15m_curr = unified_adx" in raw_code:
                    self.violations.append("[RÀO CHẮN 9 - AST NAME RESOLUTION] Lỗi dùng biến undefined 'unified_adx' trong _pre_trade_safety_gate!")
            except Exception as e_ast:
                self.violations.append(f"[RÀO CHẮN 9 - AST SYNTAX ERROR] Không thể parse AST core/bot.py: {e_ast}")

def run_gate():
    print("=" * 70)
    print("🛡️  TRADEMATRIX HARD CONSTRAINTS GATE - KIỂM TOÁN RÀO CHẮN CỨNG")
    print("=" * 70)
    auditor = CodeConstraintAuditor(ROOT_DIR)
    violations = auditor.check_all()

    if not violations:
        print("✅ [PASSED 100%] Toàn bộ 9 Rào chắn cứng bảo toàn! Không có lỗi lặp lại.")
        print("=" * 70)
        return 0
    else:
        print(f"❌ [BUILD REJECTED] Phát hiện {len(violations)} vi phạm rào chắn cứng:")
        for i, v in enumerate(violations, 1):
            print(f"  {i}. {v}")
        print("=" * 70)
        print("🛑 Lập trình viên / AI phải sửa triệt để các vi phạm trên trước khi deploy!")
        return 1

if __name__ == '__main__':
    sys.exit(run_gate())
