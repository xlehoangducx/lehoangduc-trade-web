"""
TRADEMATRIX HARD CONSTRAINTS GATE (RÀO CHẮN CỨNG BẰNG CODE)
Tự động quét toàn bộ mã nguồn để phát hiện và ngăn chặn vĩnh viễn các lỗi logic ngầm
đã từng gây thiệt hại trong quá khứ trước khi cho phép đóng gói hoặc deploy sang PC2.
"""

import ast
import os
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

ROOT_DIR = Path(__file__).parent.parent

class CodeConstraintAuditor:
    def __init__(self, root_dir):
        self.root_dir = Path(root_dir)
        self.violations = []

    def check_all(self):
        self.violations = []
        self._check_purged_time_exits()
        self._check_jev_pop_in_aggregator()
        self._check_sl_clamping()
        self._check_api_stop_idempotency()
        self._check_license_cache_in_loop()
        self._check_macro_trend_veto_override()
        self._check_altcoin_sl_ceiling()
        self._check_cushion_sl_timing()
        self._check_ast_runtime_variable_sanity()
        self._check_kb5_ssot_alignment()
        return self.violations

    def _check_purged_time_exits(self):
        """RÀO CHẮN 1: Cấm tái kích hoạt các cơ chế thoát lệnh theo thời gian mù quáng (DOA 15/25/35m, idle_120m)."""
        cfg_path = self.root_dir / 'config' / 'settings.yaml'
        if cfg_path.exists():
            try:
                import yaml
                data = yaml.safe_load(cfg_path.read_text(encoding='utf-8')) or {}
                risk_cfg = data.get('risk', {})
                trading_cfg = data.get('trading', {})
                for bad in ['doa_15m', 'doa_25m', 'doa_35m', 'idle_120m', 'ladder_sl']:
                    if risk_cfg.get(bad) is True or trading_cfg.get(bad) is True or data.get(bad) is True:
                        self.violations.append(f"[RÀO CHẮN 1 - PURGED ANTI-PATTERN] Phát hiện bật cờ nguy hiểm trong settings.yaml: '{bad}: true'")
            except Exception as e_cfg:
                self.violations.append(f"[RÀO CHẮN 1 - YAML PARSE ERROR] Không thể đọc settings.yaml: {e_cfg}")

    def _check_jev_pop_in_aggregator(self):
        """RÀO CHẮN 2: Cấm xóa sổ JEV Agent trong signal_aggregator.py khi JEV đang báo trend mạnh."""
        agg_path = self.root_dir / 'ai' / 'signal_aggregator.py'
        if agg_path.exists():
            content = agg_path.read_text(encoding='utf-8')
            if "by_strategy.pop('jev_agent', None)" in content:
                if "JEV MTF TREND SHIELD" not in content or "jev_vote >= 0.70" not in content:
                    self.violations.append("[RÀO CHẮN 2 - FATAL SEMANTIC BUG] Phát hiện 'pop(jev_agent)' không có khiên JEV MTF TREND SHIELD bảo vệ!")

    def _check_sl_clamping(self):
        """RÀO CHẮN 3: Bảo đảm Stop-Loss luôn nằm trong khung an toàn định lượng [1.0%, 3.5%], không thả trôi quá trần."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            content = bot_path.read_text(encoding='utf-8')
            if "clamped_sl_dist = " not in content:
                self.violations.append("[RÀO CHẮN 3 - SL SAFETY] Thiếu kẹp trần an toàn clamped_sl_dist trong core/bot.py!")

    def _check_api_stop_idempotency(self):
        """RÀO CHẮN 4: Endpoint /api/stop và /api/pause không bao giờ được trả về error 'Bot chưa chạy'."""
        app_path = self.root_dir / 'dashboard' / 'app.py'
        if app_path.exists():
            content = app_path.read_text(encoding='utf-8')
            if "'error': 'Bot chưa chạy'" in content or '"error": "Bot chưa chạy"' in content:
                self.violations.append("[RÀO CHẮN 4 - WEB REMOTE ERROR] Endpoint dừng bot trả về lỗi 'Bot chưa chạy' làm Web báo đỏ!")

    def _check_license_cache_in_loop(self):
        """RÀO CHẮN 5: Cấm gửi request verify_license lên Firestore mỗi giây trong cloud_sync.py."""
        sync_path = self.root_dir / 'cloud_sync.py'
        if sync_path.exists():
            content = sync_path.read_text(encoding='utf-8')
            if "_last_license_check_time" not in content:
                self.violations.append("[RÀO CHẮN 5 - NETWORK BOTTLENECK] cloud_sync.py thiếu bộ đệm cache bản quyền 60s, gây nghẽn mạng điều khiển!")

    def _check_macro_trend_veto_override(self):
        """RÀO CHẮN 6: Cấm dùng râu nến giả hoặc thỏa hiệp chỉ báo trễ pha để cướp quyền Short ngược Uptrend mạnh."""
        agg_path = self.root_dir / 'ai' / 'signal_aggregator.py'
        if agg_path.exists():
            content = agg_path.read_text(encoding='utf-8')
            if "macro_bull_dominant and not is_whale_waterfall_breakdown" not in content:
                self.violations.append("[RÀO CHẮN 6 - MTF TREND VETO] Thiếu chốt chặn cấm bypass [VETO MTF STRONG UPTREND] trong signal_aggregator.py!")

    def _check_altcoin_sl_ceiling(self):
        """RÀO CHẮN 7: Altcoin biến động mạnh phải có biên độ Stop-Loss thích ứng ATR lên đến 3.5%, cấm bóp nghẹt ở 1.5%."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            content = bot_path.read_text(encoding='utf-8')
            if "alt_sl_cap = min(0.035," not in content:
                self.violations.append("[RÀO CHẮN 7 - ALTCOIN SL ADAPTIVE] Thiếu cơ chế trần SL thích ứng ATR 3.5% cho Altcoin trong core/bot.py!")

    def _check_cushion_sl_timing(self):
        """RÀO CHẮN 8: Cushion SL phải được bảo vệ bởi bộ lọc thời gian held_minutes >= 3.0, cấm giật SL non làm mất siêu sóng."""
        bot_path = self.root_dir / 'core' / 'bot.py'
        if bot_path.exists():
            content = bot_path.read_text(encoding='utf-8')
            if "held_minutes >= 3.0" not in content:
                self.violations.append("[RÀO CHẮN 8 - CUSHION SL TIMING] Thiếu bộ lọc thời gian held_minutes >= 3.0 cho Cushion SL trong core/bot.py!")

    def _check_ast_runtime_variable_sanity(self):
        """RÀO CHẮN 9: Kiểm tra cú pháp AST, tính toàn vẹn biến toàn diện bằng SymTable và chống UnboundLocalError."""
        import symtable, builtins
        files_to_audit = [
            self.root_dir / 'core' / 'bot.py',
            self.root_dir / 'core' / 'exchange.py',
            self.root_dir / 'ai' / 'signal_aggregator.py',
            self.root_dir / 'ai' / 'market_regime.py',
            self.root_dir / 'ai' / 'order_flow_analyzer.py',
            self.root_dir / 'ai' / 'jev_agent.py',
            self.root_dir / 'strategies' / 'trap_detector.py'
        ]

        builtin_symbols = set(dir(builtins))
        builtin_symbols.update(['__file__', '__name__', '__doc__', '__package__', '__path__'])

        for fpath in files_to_audit:
            if not fpath.exists():
                continue
            try:
                src = fpath.read_text(encoding='utf-8')
                mod_table = symtable.symtable(src, str(fpath), 'exec')
                mod_symbols = set(mod_table.get_identifiers())

                def check_table(t, scope_stack):
                    current_name = t.get_name()
                    for sym in t.get_symbols():
                        if sym.is_global():
                            name = sym.get_name()
                            if name not in mod_symbols and name not in builtin_symbols:
                                self.violations.append(
                                    f"[RÀO CHẮN 9 - SYMTABLE NAME RESOLUTION] Lỗi biến chưa định nghĩa '{name}' tại {fpath.name} -> {scope_stack} -> {current_name}!"
                                )
                    for child in t.get_children():
                        check_table(child, f'{scope_stack} -> {current_name}')

                check_table(mod_table, 'module')

                # Kiểm tra nâng cao AST chống UnboundLocalError (biến local load trước dòng gán đầu tiên trong cùng một scope)
                tree = ast.parse(src, filename=str(fpath))
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        args = set(a.arg for a in node.args.args)
                        if node.args.vararg: args.add(node.args.vararg.arg)
                        if node.args.kwarg: args.add(node.args.kwarg.arg)
                        for a in node.args.kwonlyargs: args.add(a.arg)

                        declared_globals = set()
                        for n in ast.walk(node):
                            if isinstance(n, (ast.Global, ast.Nonlocal)):
                                declared_globals.update(n.names)

                        assigned_vars = {}
                        class AssignCollector(ast.NodeVisitor):
                            def visit_FunctionDef(self, n): pass
                            def visit_AsyncFunctionDef(self, n): pass
                            def visit_Lambda(self, n): pass
                            def visit_ListComp(self, n): pass
                            def visit_SetComp(self, n): pass
                            def visit_DictComp(self, n): pass
                            def visit_GeneratorExp(self, n): pass

                            def visit_Assign(self, n):
                                for tgt in n.targets:
                                    for sub in ast.walk(tgt):
                                        if isinstance(sub, ast.Name) and isinstance(sub.ctx, ast.Store):
                                            assigned_vars[sub.id] = min(assigned_vars.get(sub.id, sub.lineno), sub.lineno)
                                self.generic_visit(n)

                            def visit_AugAssign(self, n):
                                if isinstance(n.target, ast.Name):
                                    assigned_vars[n.target.id] = min(assigned_vars.get(n.target.id, n.target.lineno), n.target.lineno)
                                self.generic_visit(n)

                            def visit_AnnAssign(self, n):
                                if isinstance(n.target, ast.Name):
                                    assigned_vars[n.target.id] = min(assigned_vars.get(n.target.id, n.target.lineno), n.target.lineno)
                                self.generic_visit(n)

                            def visit_For(self, n):
                                for sub in ast.walk(n.target):
                                    if isinstance(sub, ast.Name) and isinstance(sub.ctx, ast.Store):
                                        assigned_vars[sub.id] = min(assigned_vars.get(sub.id, sub.lineno), sub.lineno)
                                self.generic_visit(n)

                        collector = AssignCollector()
                        for stmt in node.body:
                            collector.visit(stmt)

                        self_ref = self
                        class LoadCollector(ast.NodeVisitor):
                            def visit_FunctionDef(self, n): pass
                            def visit_AsyncFunctionDef(self, n): pass
                            def visit_Lambda(self, n): pass
                            def visit_ListComp(self, n): pass
                            def visit_SetComp(self, n): pass
                            def visit_DictComp(self, n): pass
                            def visit_GeneratorExp(self, n): pass

                            def visit_Name(self, n):
                                if isinstance(n.ctx, ast.Load):
                                    var = n.id
                                    if var not in declared_globals and var not in args and var in assigned_vars:
                                        if n.lineno < assigned_vars[var]:
                                            self_ref.violations.append(
                                                f"[RÀO CHẮN 9 - UNBOUND LOCAL ERROR] Biến '{var}' được truy cập tại dòng {n.lineno} trước khi được gán lần đầu tại dòng {assigned_vars[var]} trong {fpath.name} -> {node.name}!"
                                            )

                        loader = LoadCollector()
                        for stmt in node.body:
                            loader.visit(stmt)

            except Exception as e_sym:
                self.violations.append(f"[RÀO CHẮN 9 - SYMTABLE/AST PARSE ERROR] Lỗi phân tích {fpath.name}: {e_sym}")

    def _check_kb5_ssot_alignment(self):
        """RÀO CHẮN 10: Bảo đảm Ma trận KB5 đồng bộ xuyên suốt giữa core/bot.py và ai/signal_aggregator.py."""
        agg_path = self.root_dir / 'ai' / 'signal_aggregator.py'
        bot_path = self.root_dir / 'core' / 'bot.py'
        if agg_path.exists():
            agg_txt = agg_path.read_text(encoding='utf-8')
            if "orig_jev_vote" not in agg_txt or "MOMENTUM_RIDE_INVERSION_I1" not in agg_txt:
                self.violations.append("[RÀO CHẮN 10 - KB5 SSOT] Thiếu chuẩn Ma trận KB5 (orig_jev_vote / MOMENTUM_RIDE_INVERSION_I1) trong ai/signal_aggregator.py!")
            if "abs(vote) >= 0.15" not in agg_txt:
                self.violations.append("[RÀO CHẮN 10 - KB5 SSOT] Thiếu bộ lọc chống pha loãng tự triệt tiêu đa khung (abs(vote) >= 0.15) trong ai/signal_aggregator.py!")
        if bot_path.exists():
            bot_txt = bot_path.read_text(encoding='utf-8')
            if "dynamic_threshold = min(0.85, base_threshold + 0.15)" in bot_txt:
                self.violations.append("[RÀO CHẮN 10 - KB5 SSOT] Phát hiện cộng +0.15 vào dynamic_threshold trong HIGH_VOLATILITY làm mù AI Ensemble trong core/bot.py!")

def run_gate():
    print("=" * 70)
    print("🛡️  TRADEMATRIX HARD CONSTRAINTS GATE - KIỂM TOÁN RÀO CHẮN CỨNG")
    print("=" * 70)
    auditor = CodeConstraintAuditor(ROOT_DIR)
    violations = auditor.check_all()

    if not violations:
        print("✅ [PASSED 100%] Toàn bộ 10/10 Rào chắn cứng bảo toàn! Không có lỗi lặp lại.")
        print("=" * 70)
        return 0
    else:
        print(f"❌ [BUILD REJECTED] Phát hiện {len(violations)} vi phạm rào chắn cứng:")
        for i, v in enumerate(violations, 1):
            print(f"  {i}. {v}")
        print("=" * 70)
        print("🛑 Lập trình viên / AI phải sửa triệt để các vi phạm trên trước khi deploy!")
        return 1

if __name__ == '__main__':
    sys.exit(run_gate())
