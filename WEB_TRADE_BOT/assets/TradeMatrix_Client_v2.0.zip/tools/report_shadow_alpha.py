"""
TRADEMATRIX QUANT ECOSYSTEM - SHADOW PATHFINDER MULTI-LAYER & DUAL-DIRECTION ALPHA ANALYZER
===========================================================================================
SSOT Playbook: docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md
Công cụ định lượng kiểm toán dữ liệu từ cơ chế Tìm Đường Thực Chiến Song Hành:
1. Tự động Backfill & Làm giàu Dấu Vân Tay Đa Tầng (4-Layer Pathway Fingerprint) từ log Pha 2 & nến 5M Binance.
2. Phân rã theo Đường Đi Qua Các Tầng: [T1: Chiến thuật gốc] -> [T2: DNA Nến 15M & RVol] -> [T3: AI & JEV 4H] -> [T4: Cổng Chặn] -> [3 Lớp Tài Sản].
3. Chấm điểm song hành 60 phút cho CẢ 2 CHIỀU: Chiều Thuận (DIRECT) và Chiều Lật Ngược (INVERTED) ở cả mốc 1:1 và 1:2.
4. Đối chiếu Bộ 5 Tiêu Chuẩn Cứng (5-Gate Alpha Promotion Protocol: N >= 15, Win Rate >= 75%, SL <= 20%, Net PnL > +5$)
   và chỉ định chính xác Vị Trí Cấy Ghép (SLOT A, SLOT B1, SLOT B2) trên Bản Đồ 8 Tầng.
"""

import os
import re
import sys
import glob
import json
import sqlite3
import datetime
import urllib.request
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Any, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _fetch_5m_klines(sym: str) -> Tuple[str, List[Tuple[int, float, float, float, float]]]:
    url = f"https://fapi.binance.com/fapi/v1/klines?symbol={sym}&interval=5m&limit=400"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return sym, [(int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4])) for k in data]
    except Exception:
        return sym, []


def _sim_dual_60m(kl: List[Tuple[int, float, float, float, float]], ts_ms: int,
                  entry_px: float, sl_dist_pct: float, tp1_dist_pct: float) -> Tuple[float, float, str, str, str, str]:
    fwd = [k for k in kl if ts_ms <= k[0] <= ts_ms + 3600 * 1000]
    max_up_pct, max_dn_pct = 0.0, 0.0
    l_12, l_11, s_12, s_11 = "TIMEOUT_60M", "TIMEOUT_60M", "TIMEOUT_60M", "TIMEOUT_60M"
    for _, _, h, l, _ in fwd:
        up = (h - entry_px) / entry_px * 100.0 if entry_px > 0 else 0.0
        dn = (entry_px - l) / entry_px * 100.0 if entry_px > 0 else 0.0
        if up > max_up_pct:
            max_up_pct = up
        if dn > max_dn_pct:
            max_dn_pct = dn
        if l_12 == "TIMEOUT_60M":
            if dn >= sl_dist_pct:
                l_12 = "SL_HIT"
            elif up >= tp1_dist_pct:
                l_12 = "TP1_HIT"
        if l_11 == "TIMEOUT_60M":
            if dn >= sl_dist_pct:
                l_11 = "SL_HIT"
            elif up >= sl_dist_pct:
                l_11 = "TP1_HIT"
        if s_12 == "TIMEOUT_60M":
            if up >= sl_dist_pct:
                s_12 = "SL_HIT"
            elif dn >= tp1_dist_pct:
                s_12 = "TP1_HIT"
        if s_11 == "TIMEOUT_60M":
            if up >= sl_dist_pct:
                s_11 = "SL_HIT"
            elif dn >= sl_dist_pct:
                s_11 = "TP1_HIT"
    return max_up_pct, max_dn_pct, l_12, l_11, s_12, s_11


def _parse_phase2_logs(log_dirs: List[Path]) -> List[Dict[str, Any]]:
    p2_blocks: List[Dict[str, Any]] = []
    seen_files = set()
    log_files = []
    for d in log_dirs:
        if d.exists():
            for p in sorted(d.glob("bot_*.log")):
                if p.name not in seen_files:
                    seen_files.add(p.name)
                    log_files.append(p)

    curr_block = None
    last_ts_ms = 0
    for path in log_files:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    m_ts = re.match(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),(\d{3})", line)
                    if m_ts:
                        dt = datetime.datetime.strptime(m_ts.group(1), "%Y-%m-%d %H:%M:%S")
                        last_ts_ms = int(dt.timestamp() * 1000) + int(m_ts.group(2))
                    if "Phân tích sâu (Pha 2):" in line:
                        m_sym = re.search(r"Phân tích sâu \(Pha 2\):\s*([A-Z0-9/]+)\.\.\.", line)
                        if m_sym:
                            sym = m_sym.group(1).replace("/", "")
                            curr_block = {
                                "ts_ms": last_ts_ms,
                                "symbol": sym,
                                "strategies": {},
                                "ai_vote": None,
                                "jev_vote": None,
                                "fast_skip": None,
                                "market_analysis": {},
                                "gate_logs": [],
                            }
                            p2_blocks.append(curr_block)
                    elif curr_block is not None:
                        m_strat = re.search(
                            r"📊 \[([a-z_]+)\]\s+[A-Z0-9/]+\s+\w+:\s+(BUY|SELL)\s+\(confidence:\s+([\d\.]+)%\)",
                            line,
                        )
                        if m_strat:
                            curr_block["strategies"][m_strat.group(1)] = (
                                m_strat.group(2),
                                float(m_strat.group(3)) / 100.0,
                            )
                        m_ai = re.search(
                            r"🧠 \[AI Ensemble\]\s+[A-Z0-9/]+:\s+(BUY|SELL|HOLD)\s+\(confidence:\s+([\d\.]+)%\)",
                            line,
                        )
                        if m_ai:
                            curr_block["ai_vote"] = (m_ai.group(1), float(m_ai.group(2)) / 100.0)
                        m_ma = re.search(
                            r"\[MarketAnalysis\]\s+[A-Z0-9/]+:\s+Regime=([^,]+),\s*ADX=([\d\.]+),\s*ATR=([\d\.]+)%,\s*RSI=([\d\.]+),\s*RVol=([\d\.]+)x,\s*U_Wick=([\d\.]+)%,\s*L_Wick=([\d\.]+)%,\s*Pump=([\d\.]+)%,\s*Dump=([\d\.]+)%",
                            line,
                        )
                        if not m_ma:
                            m_ma = re.search(
                                r"\[TẦNG 1 - PHÂN TÍCH NẾN 15M\]\s+[A-Z0-9/]+:\s+Trạng thái=([^,]+),\s*Lực Trend\(ADX\)=([\d\.]+),\s*Co giãn\(ATR\)=([\d\.]+)%,\s*Quá mua/bán\(RSI\)=([\d\.]+),\s*Bội số Vol\(RVol\)=([\d\.]+)x,\s*Râu trên=([\d\.]+)%,\s*Râu dưới=([\d\.]+)%,\s*Tăng=([\d\.]+)%,\s*Giảm=([\d\.]+)%",
                                line,
                            )
                        if m_ma:
                            uw = float(m_ma.group(6))
                            lw = float(m_ma.group(7))
                            curr_block["market_analysis"] = {
                                "regime": m_ma.group(1).strip(),
                                "adx": float(m_ma.group(2)),
                                "atr_pct": float(m_ma.group(3)),
                                "rsi": float(m_ma.group(4)),
                                "rvol": float(m_ma.group(5)),
                                "u_wick_pct": uw,
                                "l_wick_pct": lw,
                                "body_pct": round(max(0.0, 100.0 - uw - lw), 2),
                                "pump_pct": float(m_ma.group(8)),
                                "dump_pct": float(m_ma.group(9)),
                            }
                        m_jev = re.search(
                            r"⚡ \[(?:JEV Agent MTF|TẦNG 3 - XU HƯỚNG LỚN 4H)\]\s+[A-Z0-9/]+:\s+(BUY|SELL|HOLD)\s+\((?:confidence|Độ tự tin):\s+([\d\.]+)%\)",
                            line,
                        )
                        if m_jev:
                            curr_block["jev_vote"] = (m_jev.group(1), float(m_jev.group(2)) / 100.0)
                        if "[FAST-SKIP PRE-LLM]" in line:
                            curr_block["fast_skip"] = line.split("[FAST-SKIP PRE-LLM]")[-1].strip()
                        elif "[TẦNG 1 - LỌC NHANH TRƯỚC AI]" in line:
                            curr_block["fast_skip"] = line.split("[TẦNG 1 - LỌC NHANH TRƯỚC AI]")[-1].strip()
                        if "ai.signal_aggregator:" in line:
                            curr_block["gate_logs"].append(line.split("ai.signal_aggregator:")[-1].strip())
        except Exception:
            pass
    return p2_blocks


def ensure_backfilled_multi_layer_data(conn: sqlite3.Connection, log_dirs: List[Path]) -> int:
    """Tự động làm giàu dữ liệu đa tầng & chấm điểm 2 chiều cho các mẫu lịch sử thiếu details_json."""
    c = conn.cursor()
    c.execute(
        "SELECT id, timestamp, symbol, direction, asset_class, station_blocked, block_reason, "
        "entry_price, sl_price, tp1_price, rvol, ai_confidence, max_mfe, max_mae, outcome, "
        "duration_seconds, details_json FROM shadow_pathfinder_logs ORDER BY id"
    )
    rows = c.fetchall()
    needs_backfill = []
    for r in rows:
        det_str = r[16]
        try:
            det = json.loads(det_str) if det_str else {}
        except Exception:
            det = {}
        if "dual_eval_60m" not in det or "layer4_exact_veto_gate" not in det:
            needs_backfill.append((r, det))

    if not needs_backfill:
        return 0

    print(f"🔄 Đang đồng bộ Dấu Vân Tay Đa Tầng & Chấm Điểm 2 Chiều (LONG/SHORT) cho {len(needs_backfill)} mẫu lịch sử...")
    p2_blocks = _parse_phase2_logs(log_dirs)
    syms = list(set(r[0][2] for r in needs_backfill))
    klines_map: Dict[str, List] = {}
    with ThreadPoolExecutor(max_workers=20) as ex:
        for sym, kl in ex.map(_fetch_5m_klines, syms):
            klines_map[sym] = kl

    updated = 0
    for row, det in needs_backfill:
        cid, cts, csym, cdir, casset, cstat, creason, cent, csl, ctp, crvol, caiconf, cmfe, cmae, coutc, cdur, _ = row
        best_b = None
        for b in p2_blocks:
            if b["symbol"] == csym and -10000 <= (cts - b["ts_ms"]) <= 60000:
                best_b = b

        default_sl_pct = 1.0 if casset == "TRADFI" else (1.2 if casset == "MAJOR" else 2.0)
        raw_sl_pct = (abs(cent - csl) / cent * 100.0) if cent > 0 else default_sl_pct
        sl_dist_pct = raw_sl_pct if 0.3 <= raw_sl_pct <= 10.0 else default_sl_pct
        raw_tp_pct = (abs(ctp - cent) / cent * 100.0) if cent > 0 else (2.0 * sl_dist_pct)
        tp1_dist_pct = raw_tp_pct if 0.5 <= raw_tp_pct <= 25.0 else (2.0 * sl_dist_pct)

        new_dir = cdir
        new_sl = csl
        new_tp = ctp
        new_rvol = crvol
        new_reason = creason

        if best_b:
            strats = best_b["strategies"]
            tech_dict = {}
            for k, (sv, sc) in sorted(strats.items()):
                tech_dict[k] = {"signal": sv, "confidence": round(sc, 4), "type": k.upper()}
            if tech_dict and cid <= 274 and cstat == "STATION_2_AGGREGATOR_SCORE":
                best_tk = max(tech_dict.items(), key=lambda x: x[1]["confidence"])
                true_tech_dir = "LONG" if best_tk[1]["signal"] == "BUY" else "SHORT"
                if true_tech_dir != cdir:
                    det["legacy_pre_fix11_logged_dir"] = cdir
                    new_dir = true_tech_dir
                    new_sl = cent * (1.0 - sl_dist_pct / 100.0) if new_dir == "LONG" else cent * (1.0 + sl_dist_pct / 100.0)
                    new_tp = cent * (1.0 + tp1_dist_pct / 100.0) if new_dir == "LONG" else cent * (1.0 - tp1_dist_pct / 100.0)

            tech_pathway_key = "+".join(f"{k}:{v['signal']}" for k, v in sorted(tech_dict.items())) or f"unknown:{new_dir}"
            av_str = best_b["ai_vote"][0] if best_b["ai_vote"] else "NONE"
            av_conf = round(best_b["ai_vote"][1], 4) if best_b["ai_vote"] else 0.0
            jv_str = best_b["jev_vote"][0] if best_b["jev_vote"] else "SKIP"
            jv_conf = round(best_b["jev_vote"][1], 4) if best_b["jev_vote"] else 0.0
            ma = best_b["market_analysis"]
            if ma.get("rvol"):
                new_rvol = float(ma["rvol"])

            gl = " | ".join(best_b["gate_logs"])
            exact_gate = cstat
            rec_slot = "NONE"
            if cstat == "STATION_2_AGGREGATOR_SCORE":
                if best_b["fast_skip"]:
                    fs = best_b["fast_skip"]
                    if "Twin-Wick" in fs:
                        exact_gate = "T2_FAST_SKIP_TWIN_WICK"
                    elif "Volume" in fs or "RVol" in fs:
                        exact_gate = "T2_FAST_SKIP_LOW_RVOL"
                    elif "Sideway" in fs or "ranging" in fs.lower() or "ADX" in fs:
                        exact_gate = "T2_FAST_SKIP_RANGING"
                    elif "Ngược" in fs or "ngược" in fs or "trend" in fs.lower():
                        exact_gate = "T2_FAST_SKIP_COUNTER_TREND"
                    else:
                        exact_gate = "T2_FAST_SKIP_OTHER"
                    rec_slot = "SLOT_A"
                    new_reason = f"{exact_gate}: {fs[:140]}"
                elif "VETO_AI_BIAS" in str(creason):
                    exact_gate = f"T4_{creason}"
                    rec_slot = "SLOT_B1"
                else:
                    if "need 2 agreeing strategies, got 1" in gl:
                        if jv_str in ("BUY", "SELL"):
                            exact_gate = "T3_JEV_SHIELD_NEED_2_STRATS"
                        else:
                            exact_gate = "T3_NEED_2_STRATS_GOT_1"
                    elif "below threshold" in gl:
                        exact_gate = "T3_SCORE_BELOW_0.80"
                    else:
                        exact_gate = "T3_AGGREGATOR_VETO"
                    rec_slot = "SLOT_B1_OR_B2"
                    new_reason = f"{exact_gate} (Tech={tech_pathway_key}, AI={av_str}, JEV={jv_str})"

            det["layer1_tech_strategies"] = tech_dict
            det["tech_pathway_key"] = tech_pathway_key
            det["primary_setup_type"] = (
                "BUYING_CLIMAX"
                if "trap_detector" in tech_dict
                else ("TREND_FOLLOWING" if "trend_following" in tech_dict else "OTHER")
            )
            det["layer2_candle_dna"] = ma
            det["layer3_consensus_dna"] = {
                "ai_vote": av_str,
                "ai_conf": av_conf,
                "jev_vote": jv_str,
                "jev_conf": jv_conf,
            }
            det["layer4_exact_veto_gate"] = exact_gate
            det["recommended_slot"] = rec_slot
        else:
            det.setdefault("tech_pathway_key", f"station_veto:{new_dir}")
            det.setdefault("layer4_exact_veto_gate", cstat)
            det.setdefault("recommended_slot", "NONE")

        kl = klines_map.get(csym, [])
        if kl:
            m_up, m_dn, l_12, l_11, s_12, s_11 = _sim_dual_60m(kl, cts, cent, sl_dist_pct, tp1_dist_pct)
            dir_12 = l_12 if new_dir == "LONG" else s_12
            dir_11 = l_11 if new_dir == "LONG" else s_11
            inv_12 = s_12 if new_dir == "LONG" else l_12
            inv_11 = s_11 if new_dir == "LONG" else l_11
            new_mfe = round(m_up if new_dir == "LONG" else m_dn, 4)
            new_mae = round(-m_dn if new_dir == "LONG" else -m_up, 4)
            new_outc = dir_12 if dir_12 != "TIMEOUT_60M" or coutc == "TIMEOUT_60M" else coutc
        else:
            m_up = cmfe if new_dir == "LONG" else abs(cmae)
            m_dn = abs(cmae) if new_dir == "LONG" else cmfe
            dir_12 = coutc
            dir_11 = coutc
            inv_12 = "TP1_HIT" if coutc == "SL_HIT" and max(m_up, m_dn) >= tp1_dist_pct else "TIMEOUT_60M"
            inv_11 = "TP1_HIT" if coutc == "SL_HIT" else "TIMEOUT_60M"
            l_12 = dir_12 if new_dir == "LONG" else inv_12
            l_11 = dir_11 if new_dir == "LONG" else inv_11
            s_12 = inv_12 if new_dir == "LONG" else dir_12
            s_11 = inv_11 if new_dir == "LONG" else dir_11
            new_mfe, new_mae, new_outc = cmfe, cmae, coutc

        det["dual_eval_60m"] = {
            "max_up_pct_60m": round(m_up, 4),
            "max_down_pct_60m": round(m_dn, 4),
            "sl_dist_pct": round(sl_dist_pct, 4),
            "tp1_dist_pct": round(tp1_dist_pct, 4),
            "long_1to2": l_12,
            "long_1to1": l_11,
            "short_1to2": s_12,
            "short_1to1": s_11,
            "direct_1to2": dir_12,
            "direct_1to1": dir_11,
            "inverted_1to2": inv_12,
            "inverted_1to1": inv_11,
        }

        c.execute(
            """
            UPDATE shadow_pathfinder_logs
            SET direction = ?, sl_price = ?, tp1_price = ?, rvol = ?, block_reason = ?,
                max_mfe = ?, max_mae = ?, outcome = ?, details_json = ?
            WHERE id = ?
            """,
            (
                new_dir,
                new_sl,
                new_tp,
                new_rvol,
                new_reason,
                new_mfe,
                new_mae,
                new_outc,
                json.dumps(det, ensure_ascii=False),
                cid,
            ),
        )
        updated += 1

    conn.commit()
    return updated


def analyze_shadow_alpha(db_path: str = None):
    pc2_db = Path(r"\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\data\trade_bot.db")
    pc1_db = Path(__file__).parent.parent / "data" / "trade_bot.db"
    log_dirs = [
        Path(r"\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\logs"),
        Path(__file__).parent.parent / "logs",
    ]

    if db_path is None:
        if pc1_db.exists():
            db_path = str(pc1_db)
            print(f"📁 Đang đọc Database cục bộ PC1 (Offline): {db_path}")
        elif pc2_db.exists():
            db_path = str(pc2_db)
            print(f"📡 Đang đọc Readonly Database PC2: {db_path}")

    if not os.path.exists(db_path):
        print(f"❌ Không tìm thấy database tại {db_path}")
        return

    _is_pc2_smb = str(db_path).startswith("\\\\") or ("192.168.1.10" in str(db_path))
    if _is_pc2_smb:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=15.0)
        conn.execute("PRAGMA query_only=ON;")
    else:
        conn = sqlite3.connect(db_path, timeout=30.0)
    cursor = conn.cursor()

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='shadow_pathfinder_logs';")
    if not cursor.fetchone():
        print("ℹ️ Bảng 'shadow_pathfinder_logs' chưa có dữ liệu.")
        conn.close()
        return

    backfilled = 0 if _is_pc2_smb else ensure_backfilled_multi_layer_data(conn, log_dirs)
    if backfilled > 0:
        print(f"✅ Đã backfill thành công {backfilled} mẫu lịch sử với Dấu Vân Tay 4 Tầng & Chấm Điểm 2 Chiều!")

    cursor.execute("SELECT count(*) FROM shadow_pathfinder_logs;")
    total_records = cursor.fetchone()[0]

    print("=" * 108)
    print(f"🧭 BÁO CÁO ĐỊNH LƯỢNG SHADOW PATHFINDER ĐA TẦNG & 2 CHIỀU (TỔNG CỘNG: {total_records} MẪU)")
    print("📘 SSOT Playbook: docs/SHADOW_PATHFINDER_ALPHA_INTEGRATION_PLAYBOOK.md")
    print("=" * 108)

    if total_records == 0:
        conn.close()
        return

    # 1. Thống kê tổng quan Outcome chiều gốc
    cursor.execute("""
    SELECT outcome, count(*), round(avg(max_mfe), 2), round(avg(max_mae), 2), round(avg(duration_seconds), 0)
    FROM shadow_pathfinder_logs
    GROUP BY outcome;
    """)
    outcome_rows = cursor.fetchall()
    print("\n📊 1. PHÂN PHỐI KẾT CỤC TOÀN CỤC CHIỀU GỐC (DIRECT OUTCOMES & SHIELDING VALIDATION):")
    print(f"{'Kết Cục':<15} | {'Số Lượng':<10} | {'Tỷ Lệ (%)':<10} | {'MFE TB (%)':<12} | {'MAE TB (%)':<12} | {'Thời Gian TB':<14}")
    print("-" * 85)
    shield_cnt = 0
    for outc, cnt, avg_mfe, avg_mae, avg_dur in outcome_rows:
        pct = (cnt / total_records) * 100.0
        if outc in ("SL_HIT", "TIMEOUT_60M"):
            shield_cnt += cnt
        print(f"{outc:<15} | {cnt:<10} | {pct:>8.1f}% | {avg_mfe or 0.0:>10.2f}% | {avg_mae or 0.0:>10.2f}% | {avg_dur or 0:>12.0f}s")
    print(f"🛡️ TỶ LỆ CỨU THUA TOÀN CỤC (SL_HIT + TIMEOUT_60M): {shield_cnt}/{total_records} ({shield_cnt/total_records*100:.2f}%)")

    # Đọc toàn bộ bản ghi để phân rã theo 4 Tầng & 2 Chiều
    cursor.execute(
        "SELECT id, timestamp, symbol, direction, asset_class, station_blocked, block_reason, "
        "entry_price, sl_price, tp1_price, rvol, ai_confidence, max_mfe, max_mae, outcome, "
        "duration_seconds, details_json FROM shadow_pathfinder_logs ORDER BY id"
    )
    all_rows = cursor.fetchall()
    parsed_records = []
    gate_stats = defaultdict(lambda: {"n": 0, "dir_tp": 0, "dir_sl": 0, "inv_tp": 0, "inv_sl": 0, "slot": "NONE"})
    pathway_groups = defaultdict(list)

    for r in all_rows:
        cid, cts, csym, cdir, casset, cstat, creason, cent, csl, ctp, crvol, caiconf, cmfe, cmae, coutc, cdur, cdet_str = r
        try:
            det = json.loads(cdet_str) if cdet_str else {}
        except Exception:
            det = {}
        tech_key = det.get("tech_pathway_key", f"unknown:{cdir}")
        dna = det.get("layer2_candle_dna", {}) or {}
        cons = det.get("layer3_consensus_dna", {}) or {}
        gate = det.get("layer4_exact_veto_gate", cstat)
        slot = det.get("recommended_slot", "NONE")
        dual = det.get("dual_eval_60m", {}) or {}

        dir_12 = dual.get("direct_1to2", coutc)
        dir_11 = dual.get("direct_1to1", coutc)
        inv_12 = dual.get("inverted_1to2", "TIMEOUT_60M")
        inv_11 = dual.get("inverted_1to1", "TIMEOUT_60M")
        l_12 = dual.get("long_1to2", dir_12 if cdir == "LONG" else inv_12)
        l_11 = dual.get("long_1to1", dir_11 if cdir == "LONG" else inv_11)
        s_12 = dual.get("short_1to2", inv_12 if cdir == "LONG" else dir_12)
        s_11 = dual.get("short_1to1", inv_11 if cdir == "LONG" else dir_11)
        m_up = float(dual.get("max_up_pct_60m", cmfe if cdir == "LONG" else abs(cmae)))
        m_dn = float(dual.get("max_down_pct_60m", abs(cmae) if cdir == "LONG" else cmfe))

        gs = gate_stats[gate]
        gs["n"] += 1
        gs["slot"] = slot
        if dir_12 == "TP1_HIT":
            gs["dir_tp"] += 1
        elif dir_12 == "SL_HIT":
            gs["dir_sl"] += 1
        if inv_12 == "TP1_HIT":
            gs["inv_tp"] += 1
        elif inv_12 == "SL_HIT":
            gs["inv_sl"] += 1

        rec = {
            "id": cid,
            "symbol": csym,
            "dir": cdir,
            "asset": casset,
            "station": cstat,
            "tech_key": tech_key,
            "ai_vote": cons.get("ai_vote", "NONE"),
            "jev_vote": cons.get("jev_vote", "SKIP"),
            "gate": gate,
            "slot": slot,
            "rvol": float(dna.get("rvol") or crvol or 1.0),
            "adx": float(dna.get("adx") or 0.0),
            "u_wick": float(dna.get("u_wick_pct") or 0.0),
            "l_wick": float(dna.get("l_wick_pct") or 0.0),
            "rsi": float(dna.get("rsi") or 50.0),
            "pump": float(dna.get("pump_pct") or 0.0),
            "dump": float(dna.get("dump_pct") or 0.0),
            "regime": str(dna.get("regime") or ""),
            "l_12": l_12,
            "l_11": l_11,
            "s_12": s_12,
            "s_11": s_11,
            "dir_12": dir_12,
            "dir_11": dir_11,
            "inv_12": inv_12,
            "inv_11": inv_11,
            "m_up": m_up,
            "m_dn": m_dn,
        }
        parsed_records.append(rec)
        pathway_groups[(casset, tech_key, rec["ai_vote"], rec["jev_vote"], gate)].append(rec)

    # 2. Bảng Phân Tích Theo Cổng Chặn Chính Xác (Layer 4 Exact Veto Gate)
    print("\n🛑 2. PHÂN TÍCH THEO CỔNG RÀO CHẮN CHÍNH XÁC (LAYER 4 EXACT VETO GATE & SLOT MAP):")
    print(f"{'Cổng Rào Chắn (Exact Veto Gate)':<34} | {'Slot Cấy':<14} | {'Tổng':<5} | {'Thuận TP/SL':<13} | {'LậtNgược TP/SL':<15} | {'Đánh Giá Phòng Thủ'}")
    print("-" * 108)
    for gate, st in sorted(gate_stats.items(), key=lambda x: x[1]["n"], reverse=True):
        d_str = f"{st['dir_tp']} TP / {st['dir_sl']} SL"
        i_str = f"{st['inv_tp']} TP / {st['inv_sl']} SL"
        shield_pct = ((st["n"] - st["dir_tp"]) / st["n"] * 100.0) if st["n"] > 0 else 0.0
        print(f"{gate:<34} | {st['slot']:<14} | {st['n']:<5} | {d_str:<13} | {i_str:<15} | 🛡️ Chặn đúng {shield_pct:.1f}%")

    # 3. Bảng Phân Rã Đường Đi Đa Tầng (Multi-Layer Pathways: Direct vs Inverted)
    print("\n🧬 3. PHÂN RÃ ĐƯỜNG ĐI QUA CÁC TẦNG & ĐỐI CHIẾU 2 CHIỀU (LONG vs SHORT - TOP CỤM N >= 4):")
    print(f"{'Lớp':<7} | {'Tầng 1: Chiến Thuật Kỹ Thuật':<34} | {'AI':<4} | {'JEV':<4} | {'Tầng 4: Cổng Chặn':<27} | {'N':<3} | {'LONG TP(2%/4%)/SL':<17} | {'SHORT TP(2%/4%)/SL':<18}")
    print("-" * 128)
    for (asset, t_key, ai_v, jev_v, gate), items in sorted(pathway_groups.items(), key=lambda x: len(x[1]), reverse=True):
        n = len(items)
        if n < 4:
            continue
        l_tp11 = sum(1 for x in items if x["l_11"] == "TP1_HIT")
        l_tp12 = sum(1 for x in items if x["l_12"] == "TP1_HIT")
        l_sl = sum(1 for x in items if x["l_12"] == "SL_HIT")
        s_tp11 = sum(1 for x in items if x["s_11"] == "TP1_HIT")
        s_tp12 = sum(1 for x in items if x["s_12"] == "TP1_HIT")
        s_sl = sum(1 for x in items if x["s_12"] == "SL_HIT")
        l_summary = f"{l_tp11}({l_tp12})TP / {l_sl}SL"
        s_summary = f"{s_tp11}({s_tp12})TP / {s_sl}SL"
        print(f"{asset:<7} | {t_key[:34]:<34} | {ai_v:<4} | {jev_v:<4} | {gate[:27]:<27} | {n:<3} | {l_summary:<17} | {s_summary:<18}")

    # 4. Kiểm Định Bộ 5 Tiêu Chuẩn Cứng (5-Gate Alpha Promotion Protocol) & Watchlist Cụm Đạo Quân
    print("\n" + "=" * 108)
    print("🏆 4. KIỂM ĐỊNH BỘ 5 TIÊU CHUẨN CỨNG (5-GATE ALPHA PROMOTION PROTOCOL) & BẢN ĐỒ CẤY GHÉP 8 TẦNG:")
    print("=" * 108)

    # Định nghĩa các cụm đường đi + bộ lọc DNA Nến 15M đang được tầm soát
    candidate_clusters = [
        {
            "name": "CỤM ALPHA #1 [SHORT UNLOCK - Kiệt Sức Râu Đỉnh Cực Đại]",
            "asset": "ALTCOIN",
            "pathway_desc": "T1: trap_detector=SELL + T2: AI=SELL + T3: JEV 4H=BUY -> Gate: T3_JEV_SHIELD_NEED_2_STRATS",
            "candle_filter_desc": "U_Wick >= 65% AND RSI < 65 AND RVol >= 1.33x",
            "target_dir": "SHORT",
            "mode": "DIRECT (Mở khóa Thuận Chiều Trap+AI)",
            "slot": "SLOT B1 (ai/signal_aggregator.py - Tầng 3 Consensus Unlock)",
            "filter_fn": lambda x: (
                x["asset"] == "ALTCOIN"
                and "trap_detector:SELL" in x["tech_key"]
                and x["ai_vote"] == "SELL"
                and x["jev_vote"] == "BUY"
                and x["u_wick"] >= 65.0
                and x["rsi"] < 65.0
                and x["rvol"] >= 1.33
            ),
        },
        {
            "name": "CỤM ALPHA #2 [LONG INVERSION - Sóng Bơm Parabolic 4H (3C-KB10)]",
            "asset": "ALTCOIN",
            "pathway_desc": "T1: trap_detector=SELL + T2: AI=SELL + T3: JEV 4H=BUY -> Gate: T3_JEV_SHIELD_NEED_2_STRATS",
            "candle_filter_desc": "RSI >= 65 AND 1.10x <= RVol <= 3.50x AND Clean 4-Gate (F1: ADX>=18|LW>=40%, F2: !2xSellDist, F3: Pump>=1.5%|UW<60%, F4: !(Pump>=9.5%&Dump<3.5%))",
            "target_dir": "LONG",
            "mode": "INVERTED (Lật Ngược từ SHORT sang LONG theo JEV 4H + M1 Sniper Dual-Mode & Tam Tầng V4.1)",
            "slot": "SLOT B2 (ai/signal_aggregator.py - Tầng 3 Smart Inversion Engine [ĐÃ CẤY 3C-KB10])",
            "filter_fn": lambda x: (
                x["asset"] == "ALTCOIN"
                and "trap_detector:SELL" in x["tech_key"]
                and x["ai_vote"] == "SELL"
                and x["jev_vote"] == "BUY"
                and x["rsi"] >= 65.0
                and 1.10 <= x["rvol"] <= 3.50
                and not (0.0 < x["adx"] < 18.0 and x["l_wick"] < 40.0 and x["dump"] < 4.0)
                and not ("mean_reversion:SELL" in x["tech_key"] and "BUY" not in x["tech_key"] and x["u_wick"] >= 50.0 and x["rvol"] <= 2.20)
                and not (x["pump"] < 1.50 and x["u_wick"] >= 60.0 and x["l_wick"] < 18.0)
                and not (x["pump"] >= 9.50 and (x["dump"] < 3.50 or x["l_wick"] < 5.0))
            ),
        },
        {
            "name": "CỤM ALPHA #3 [LONG FAST-SKIP EXEMPTION - Đà Tăng Thuận Xu Hướng]",
            "asset": "ALTCOIN",
            "pathway_desc": "T1: trend_following=BUY + T2: AI=SELL -> Gate: T2_FAST_SKIP_COUNTER_TREND",
            "candle_filter_desc": "RSI >= 56 AND Pump >= 0.50% AND RVol >= 0.85x",
            "target_dir": "LONG",
            "mode": "DIRECT (Miễn trừ Fast-Skip để gọi JEV 4H xác nhận)",
            "slot": "SLOT A (core/bot.py - Tầng 2 Fast-Skip Exemption Anchor)",
            "filter_fn": lambda x: (
                x["asset"] == "ALTCOIN"
                and x["tech_key"] == "trend_following:BUY"
                and x["ai_vote"] == "SELL"
                and x["gate"] == "T2_FAST_SKIP_COUNTER_TREND"
                and x["rsi"] >= 56.0
                and x["pump"] >= 0.50
                and x["rvol"] >= 0.80
            ),
        },
    ]

    any_ready = False
    for cl in candidate_clusters:
        matched = [x for x in parsed_records if cl["filter_fn"](x)]
        n = len(matched)
        t_dir = cl["target_dir"]
        if t_dir == "LONG":
            tp_11 = sum(1 for x in matched if x["l_11"] == "TP1_HIT")
            tp_12 = sum(1 for x in matched if x["l_12"] == "TP1_HIT")
            sl_cnt = sum(1 for x in matched if x["l_11"] == "SL_HIT")
            opp_sl = sum(1 for x in matched if x["s_11"] == "SL_HIT")
            avg_fav = (sum(x["m_up"] for x in matched) / n) if n > 0 else 0.0
            avg_adv = (sum(x["m_dn"] for x in matched) / n) if n > 0 else 0.0
        else:
            tp_11 = sum(1 for x in matched if x["s_11"] == "TP1_HIT")
            tp_12 = sum(1 for x in matched if x["s_12"] == "TP1_HIT")
            sl_cnt = sum(1 for x in matched if x["s_11"] == "SL_HIT")
            opp_sl = sum(1 for x in matched if x["l_11"] == "SL_HIT")
            avg_fav = (sum(x["m_dn"] for x in matched) / n) if n > 0 else 0.0
            avg_adv = (sum(x["m_up"] for x in matched) / n) if n > 0 else 0.0

        win_rate = (tp_11 / n * 100.0) if n > 0 else 0.0
        sl_rate = (sl_cnt / n * 100.0) if n > 0 else 0.0
        est_net_pnl = (tp_11 * 1.15) - (sl_cnt * 1.00)
        is_qualified = (n >= 15 and win_rate >= 75.0 and sl_rate <= 20.0 and est_net_pnl > 5.0)
        if is_qualified:
            any_ready = True
            status_badge = "✅ ĐỦ ĐIỀU KIỆN CẤY VÀO TOOL (QUALIFIED 5/5 GATES)"
        else:
            status_badge = f"⏳ WATCHLIST ĐANG TÍCH LŨY ({n}/15 mẫu — Cần thêm {max(0, 15 - n)} mẫu)"

        print(f"\n🔹 {cl['name']} [{cl['asset']}]")
        print(f"   • Đường đi các tầng : {cl['pathway_desc']}")
        print(f"   • Bộ lọc DNA Nến 15M: {cl['candle_filter_desc']}")
        print(f"   • Chiều & Cơ chế    : Đánh {t_dir} — {cl['mode']} (Nếu đánh ngược lại: {opp_sl}/{n} dính SL)")
        print(f"   • Vị trí cấy cố định: {cl['slot']}")
        print(
            f"   • Kết quả kiểm định : N={n}/15 | Chạm TP(2%/4%): {tp_11}({tp_12})/{n} (Win Rate={win_rate:.1f}%) | "
            f"Chạm SL: {sl_cnt}/{n} ({sl_rate:.1f}%) | Biên độ Thuận/Ngược TB: +{avg_fav:.2f}% / -{avg_adv:.2f}%"
        )
        print(f"   • Phán quyết Chuẩn  : {status_badge}")

    print("\n" + "-" * 108)
    if not any_ready:
        print("🛡️ KẾT LUẬN HIỆN TẠI: Chưa có cụm nào chạm mốc N >= 15 mẫu. Giữ nguyên 100% rào chắn hiện tại, tiếp tục thu thập mẫu tự động!")
    else:
        print("🚀 KẾT LUẬN HIỆN TẠI: Đã có cụm đạt đủ N >= 15 & Win Rate >= 75%! Thực hiện Bước 4 trong Playbook (Simulator False Exits = 0/219) trước khi cấy vào Slot!")
    print("=" * 108)

    conn.close()


if __name__ == "__main__":
    target_db = sys.argv[1] if len(sys.argv) > 1 else None
    analyze_shadow_alpha(target_db)
