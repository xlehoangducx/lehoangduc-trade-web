"""
TRADEMATRIX EXHAUSTIVE 10-AXIS AUTOMATED AUDITOR (OFFLINE — ZERO BINANCE REST)
==============================================================================
Quet toan bo kho code (~90 file Python, YAML, HTML, 10+ Vu Khi) trong 1 luot
duy nhat (~2-4 giay) moi khi them tin hieu/vu khi moi, nang cap, hoac fix loi.

10 TRUC KIEM TOAN BAT BIEN:
  [AXIS 1]  AST Syntax toan kho code (90+ file .py)
  [AXIS 2]  Cross-Class self.* & getattr/hasattr an loi (Core 9 classes)
  [AXIS 3]  External Method Contracts (MarketScanner / self.exchange / self.db) + hasattr trap
  [AXIS 4]  Binance REST IP Ban Circuit Breaker coverage (Anti-BOM #2/#24/#29)
  [AXIS 5]  Unreachable code, duplicate dict keys & Stop-Market -2021/algoId audit
  [AXIS 6]  Cross-Layer 8-Station Metadata & protection_status SSOT (Anti-BOM #6/#17/#20)
  [AXIS 7]  Purged Anti-Patterns (Rule 0.1) & SQLite query_only/timeout safety (BOM #8)
  [AXIS 8]  YAML Config validity & MarketScanner 3-Asset-Class / ETF vectors (BOM #28)
  [AXIS 9]  Dashboard HTML fetch() <-> Flask routes & deploy_web_client.py manifest (BOM #9)
  [AXIS 10] Weapon Arsenal (VK1..VK10+), Direction Safety, IP Ban Runtime & Regression Gates

Su dung:
  python tools/exhaustive_10axis_audit.py
  python tools/exhaustive_10axis_audit.py --live-log 22:10:19
  python tools/exhaustive_10axis_audit.py --verbose
"""

import argparse
import ast
import json
import os
import re
import sqlite3
import sys
import time
from collections import defaultdict
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

EXCLUDE_DIRS = {"venv", ".git", "__pycache__", "node_modules", "data", "logs", "models", "scratch", ".venv"}


def iter_py_files(include_tools: bool = True):
    for root, dirs, files in os.walk(ROOT):
        skip = set(EXCLUDE_DIRS)
        if not include_tools:
            skip.add("tools")
        dirs[:] = sorted(d for d in dirs if d not in skip)
        for fn in sorted(files):
            if fn.endswith(".py"):
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, ROOT).replace("\\", "/")
                yield p, rel


def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


class AuditReport:
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.results = []  # (axis_no, title, passed, errors, warnings, notes)

    def add(self, axis_no: int, title: str, errors: list, warnings: list = None, notes: list = None):
        warnings = warnings or []
        notes = notes or []
        passed = len(errors) == 0
        self.results.append((axis_no, title, passed, errors, warnings, notes))
        icon = "PASS" if passed else "FAIL"
        print(f"\n[AXIS {axis_no:02d}] {title} -> {icon} (err={len(errors)}, warn={len(warnings)})")
        for n in notes:
            print(f"    info: {n}")
        for e in errors[:25]:
            print(f"    [ERR]  {e}")
        if len(errors) > 25:
            print(f"    ... +{len(errors) - 25} more errors")
        if self.verbose or not passed:
            for w in warnings[:15]:
                print(f"    [WARN] {w}")
        elif warnings:
            print(f"    [WARN] {len(warnings)} advisory warning(s) (run with --verbose to inspect)")

    def summary(self) -> int:
        passed_cnt = sum(1 for r in self.results if r[2])
        total_cnt = len(self.results)
        total_err = sum(len(r[3]) for r in self.results)
        total_warn = sum(len(r[4]) for r in self.results)
        print("\n" + "=" * 72)
        print(
            f"10-AXIS AUDIT SUMMARY: {passed_cnt}/{total_cnt} AXES PASSED | "
            f"Critical Errors={total_err} | Advisory Warnings={total_warn}"
        )
        print("=" * 72)
        return 0 if total_err == 0 else 1


# ---------------------------------------------------------------------------
# AXIS 1: Full-Repo AST Syntax Check
# ---------------------------------------------------------------------------
def run_axis_1(report: AuditReport):
    errors = []
    parsed_cache = {}
    count = 0
    for p, rel in iter_py_files(include_tools=True):
        count += 1
        src = read_text(p)
        try:
            tree = ast.parse(src, filename=p)
            parsed_cache[rel] = (p, src, tree)
        except SyntaxError as e:
            errors.append(f"{rel}:{e.lineno}: SyntaxError: {e.msg}")
        except Exception as e:
            errors.append(f"{rel}: AST parse error: {e}")
    report.add(1, "Full-Repo AST Syntax Check", errors, notes=[f"Checked {count} Python files"])
    return parsed_cache


# ---------------------------------------------------------------------------
# AXIS 2: Cross-Class self.* & Silent getattr/hasattr Attribute Integrity
# ---------------------------------------------------------------------------
def _analyze_class_self_attrs(tree: ast.AST, class_name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            defined = set()
            # Collect class-level constants & annotations defined directly in class body
            for stmt in node.body:
                if isinstance(stmt, ast.Assign):
                    for t in stmt.targets:
                        if isinstance(t, ast.Name):
                            defined.add(t.id)
                elif isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                    defined.add(stmt.target.id)
            reads = defaultdict(list)
            for sub in ast.walk(node):
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    defined.add(sub.name)
                elif isinstance(sub, ast.Assign):
                    for t in sub.targets:
                        if isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id == "self":
                            defined.add(t.attr)
                        elif isinstance(t, (ast.Tuple, ast.List)):
                            for elt in t.elts:
                                if isinstance(elt, ast.Attribute) and isinstance(elt.value, ast.Name) and elt.value.id == "self":
                                    defined.add(elt.attr)
                elif isinstance(sub, (ast.AnnAssign, ast.AugAssign)):
                    t = sub.target
                    if isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id == "self":
                        defined.add(t.attr)
                elif isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name) and sub.func.id == "setattr":
                    if (
                        len(sub.args) >= 2
                        and isinstance(sub.args[0], ast.Name)
                        and sub.args[0].id == "self"
                        and isinstance(sub.args[1], ast.Constant)
                        and isinstance(sub.args[1].value, str)
                    ):
                        defined.add(sub.args[1].value)

            for sub in ast.walk(node):
                if isinstance(sub, ast.Attribute) and isinstance(sub.value, ast.Name) and sub.value.id == "self":
                    if isinstance(sub.ctx, ast.Load) and sub.attr not in defined:
                        reads[sub.attr].append(sub.lineno)
                elif isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name) and sub.func.id in ("getattr", "hasattr"):
                    if (
                        len(sub.args) >= 2
                        and isinstance(sub.args[0], ast.Name)
                        and sub.args[0].id == "self"
                        and isinstance(sub.args[1], ast.Constant)
                        and isinstance(sub.args[1].value, str)
                    ):
                        attr = sub.args[1].value
                        if attr not in defined:
                            reads[f"({sub.func.id}) {attr}"].append(sub.lineno)
            return defined, reads
    return set(), {}


def run_axis_2(report: AuditReport, parsed_cache: dict):
    errors = []
    warnings = []
    # Intentional external/injected optional attributes that may be read safely via getattr
    allowed_optional = {
        ("SignalAggregator", "(getattr) config"),
        ("SignalAggregator", "(hasattr) config"),
        ("SignalAggregator", "(getattr) enable_live_order_flow"),
        ("ExchangeConnector", "(getattr) ws_manager"),
        ("QuantumPathSimulator", "(getattr) config"),
    }
    targets = [
        ("core/bot.py", "TradingBot"),
        ("ai/signal_aggregator.py", "SignalAggregator"),
        ("core/exchange.py", "ExchangeConnector"),
        ("ai/jev_agent.py", "JevAgent"),
        ("ai/order_flow_analyzer.py", "OrderFlowAnalyzer"),
        ("ai/quantum_path_simulator.py", "QuantumPathSimulator"),
        ("risk/risk_manager.py", "RiskManager"),
        ("core/shadow_pathfinder.py", "ShadowPathfinder"),
        ("core/data_collector.py", "DataCollector"),
    ]
    checked = 0
    for rel, cls_name in targets:
        if rel not in parsed_cache:
            continue
        checked += 1
        _, _, tree = parsed_cache[rel]
        _, missing = _analyze_class_self_attrs(tree, cls_name)
        for attr, lns in sorted(missing.items()):
            if (cls_name, attr) in allowed_optional:
                continue
            if attr.startswith("("):
                warnings.append(f"{rel} [{cls_name}] silent {attr} never assigned on self (lines={lns[:5]})")
            else:
                errors.append(f"{rel} [{cls_name}] unassigned self.{attr} (lines={lns[:5]})")
    report.add(2, "Cross-Class self.* & getattr/hasattr Integrity", errors, warnings, notes=[f"Audited {checked} core classes"])


# ---------------------------------------------------------------------------
# AXIS 3: External Method Contracts (Catches BOM #28 hasattr Ghost Bugs!)
# ---------------------------------------------------------------------------
def run_axis_3(report: AuditReport, parsed_cache: dict):
    errors = []
    warnings = []
    from core.scanner import MarketScanner
    from core.exchange import ExchangeConnector
    from database.db_manager import DatabaseManager
    from ai.order_flow_analyzer import OrderFlowAnalyzer

    ms_attrs = set(dir(MarketScanner))
    ex_attrs = set(dir(ExchangeConnector)) | {
        "exchange", "api_key", "secret", "testnet", "market_type",
        "default_leverage", "margin_type", "config", "exchange_id", "ws_manager",
    }
    db_attrs = set(dir(DatabaseManager)) | {"db_path", "conn"}
    ofa_attrs = set(dir(OrderFlowAnalyzer)) | {"exchange", "config", "cache"}

    for rel, (_, _, tree) in parsed_cache.items():
        if rel.startswith("tools/"):
            continue
        for node in ast.walk(tree):
            # Direct MarketScanner.attr
            if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "MarketScanner":
                if node.attr not in ms_attrs:
                    errors.append(f"{rel}:{node.lineno} missing MarketScanner.{node.attr}")
            # hasattr(MarketScanner, 'attr') / getattr(MarketScanner, 'attr') — BOM #28 killer!
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in ("hasattr", "getattr"):
                if (
                    len(node.args) >= 2
                    and isinstance(node.args[0], ast.Name)
                    and node.args[0].id == "MarketScanner"
                    and isinstance(node.args[1], ast.Constant)
                    and isinstance(node.args[1].value, str)
                ):
                    attr = node.args[1].value
                    if attr not in ms_attrs:
                        errors.append(f"{rel}:{node.lineno} GHOST {node.func.id}(MarketScanner, '{attr}') — method does NOT exist!")
            # self.exchange.attr / self.db.attr / self._shared_ofa.attr
            elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Attribute):
                if isinstance(node.value.value, ast.Name) and node.value.value.id == "self":
                    obj_name = node.value.attr
                    # Inside core/exchange.py, self.exchange is the underlying ccxt.binance instance
                    if obj_name == "exchange" and rel != "core/exchange.py" and not node.attr.startswith("_") and node.attr not in ex_attrs:
                        errors.append(f"{rel}:{node.lineno} missing self.exchange.{node.attr}")
                    elif obj_name == "db" and rel != "database/db_manager.py" and not node.attr.startswith("_") and node.attr not in db_attrs:
                        errors.append(f"{rel}:{node.lineno} missing self.db.{node.attr}")
                    elif obj_name == "_shared_ofa" and not node.attr.startswith("_") and node.attr not in ofa_attrs:
                        errors.append(f"{rel}:{node.lineno} missing self._shared_ofa.{node.attr}")
    report.add(3, "External Method Contracts & Ghost hasattr Detector (Anti-BOM #28)", errors, warnings)


# ---------------------------------------------------------------------------
# AXIS 4: Binance REST IP Ban Circuit Breaker Coverage (Anti-BOM #2/#24/#29)
# ---------------------------------------------------------------------------
def run_axis_4(report: AuditReport, parsed_cache: dict):
    errors = []
    warnings = []
    binance_http_files = []
    for rel, (_, src, _) in parsed_cache.items():
        if rel.startswith("tools/"):
            continue
        lines = src.splitlines()
        hits = []
        for idx, line in enumerate(lines, 1):
            st = line.strip()
            if st.startswith("#"):
                continue
            if "fapi.binance.com" in line or "api.binance.com" in line:
                # Ignore pure websocket wss:// references
                if "wss://" in line:
                    continue
                hits.append(idx)
        if hits:
            binance_http_files.append((rel, hits))
            has_breaker = (
                "get_ip_ban_remaining_seconds" in src
                or "_extract_and_activate_ip_ban" in src
                or rel == "core/exchange.py"
            )
            if not has_breaker:
                errors.append(
                    f"{rel} calls Binance REST directly (lines={hits[:5]}) WITHOUT IP Ban Circuit Breaker!"
                )
    report.add(
        4,
        "Binance REST IP Ban Circuit Breaker Coverage (Anti-BOM #2/#24/#29)",
        errors,
        warnings,
        notes=[f"Binance REST callers verified: {[f[0] for f in binance_http_files]}"],
    )


# ---------------------------------------------------------------------------
# AXIS 5: Unreachable Code, Duplicate Dict Keys & Stop-Market -2021/algoId
# ---------------------------------------------------------------------------
def run_axis_5(report: AuditReport, parsed_cache: dict):
    errors = []
    warnings = []
    sl_sites = 0
    for rel, (_, src, tree) in parsed_cache.items():
        if rel.startswith("tools/"):
            continue
        # 5a. Unreachable statements after return/raise/break/continue
        for node in ast.walk(tree):
            for body_attr in ("body", "orelse", "finalbody"):
                stmts = getattr(node, body_attr, None)
                if isinstance(stmts, list):
                    for idx, st in enumerate(stmts[:-1]):
                        if isinstance(st, (ast.Return, ast.Raise, ast.Break, ast.Continue)):
                            nxt = stmts[idx + 1]
                            errors.append(f"{rel}:{nxt.lineno} unreachable statement after {type(st).__name__} at L{st.lineno}")
                            break
            # 5b. Duplicate literal keys inside dict
            if isinstance(node, ast.Dict):
                seen_k = {}
                for k in node.keys:
                    if isinstance(k, ast.Constant) and isinstance(k.value, (str, int, float)):
                        if k.value in seen_k:
                            warnings.append(f"{rel}:{k.lineno} duplicate dict key {k.value!r} (first at L{seen_k[k.value]})")
                        else:
                            seen_k[k.value] = k.lineno

        # 5c. Stop-Market calls in core/bot.py must handle -2021 & algoId
        if rel == "core/bot.py":
            ls = src.splitlines()
            for idx, line in enumerate(ls, 1):
                if "create_stop_market_order(" in line and not line.strip().startswith("#"):
                    sl_sites += 1
                    ctx = "\n".join(ls[max(0, idx - 3):min(len(ls), idx + 55)])
                    has_algo = any(k in ctx for k in ("algoId", "orderId", "_conditional_order_id"))
                    if not has_algo:
                        errors.append(f"core/bot.py:{idx} create_stop_market_order missing algoId/orderId extraction")
    report.add(
        5,
        "Unreachable Code, Duplicate Dict Keys & Stop-Market algoId",
        errors,
        warnings,
        notes=[f"Verified {sl_sites} create_stop_market_order() sites in core/bot.py"],
    )


# ---------------------------------------------------------------------------
# AXIS 6: Cross-Layer 8-Station Metadata & protection_status SSOT (BOM #6/#17/#20)
# ---------------------------------------------------------------------------
def run_axis_6(report: AuditReport, parsed_cache: dict):
    errors = []
    warnings = []

    # 6a. Anti-BOM #6: Never compare protection_status == 'exchange_stop' alone without 'exchange_stop_verified'
    for rel, (_, src, _) in parsed_cache.items():
        if rel.startswith("tools/"):
            continue
        for idx, line in enumerate(src.splitlines(), 1):
            if re.search(r"protection_status.*==\s*['\"]exchange_stop['\"]", line):
                if "exchange_stop_verified" not in line:
                    errors.append(f"{rel}:{idx} BOM #6 regression: compares protection_status == 'exchange_stop' without 'exchange_stop_verified'")

    # 6b. Critical cross-layer signal flags must exist in BOTH producer (signal_aggregator) and consumer (bot / quantum / arsenal)
    agg_src = parsed_cache.get("ai/signal_aggregator.py", (None, "", None))[1]
    bot_src = parsed_cache.get("core/bot.py", (None, "", None))[1]
    q_src = parsed_cache.get("ai/quantum_path_simulator.py", (None, "", None))[1]
    w_src = parsed_cache.get("core/vietnamese_weapon_arsenal.py", (None, "", None))[1]

    required_contracts = [
        ("is_vk9_climax_wick_short", agg_src, bot_src, "signal_aggregator -> bot"),
        ("is_vk10_tradfi_bottom_long", agg_src, bot_src, "signal_aggregator -> bot"),
        ("is_vk9_climax_wick_short", agg_src, q_src, "signal_aggregator -> quantum"),
        ("is_vk10_tradfi_bottom_long", agg_src, q_src, "signal_aggregator -> quantum"),
        ("is_vk9_climax_wick_short", agg_src, w_src, "signal_aggregator -> weapon_arsenal"),
        ("is_vk10_tradfi_bottom_long", agg_src, w_src, "signal_aggregator -> weapon_arsenal"),
        ("sigma_total_pct", q_src, bot_src, "quantum -> bot"),
        ("weapon_id", agg_src, w_src, "signal_aggregator -> weapon_arsenal"),
    ]
    for key, prod_s, cons_s, flow in required_contracts:
        if key not in prod_s:
            errors.append(f"Metadata contract broken ({flow}): '{key}' missing in producer")
        if key not in cons_s:
            errors.append(f"Metadata contract broken ({flow}): '{key}' missing in consumer")

    # 6c. Anti-BOM #26: Ensure leftover `or is_tradfi_opening_pump` never creeps back into Branch 2 SHORT
    if re.search(r"is_tradfi_opening_dump\s+or\s+is_tradfi_opening_pump", agg_src):
        errors.append("ai/signal_aggregator.py: BOM #26 regression — 'is_tradfi_opening_dump or is_tradfi_opening_pump' found!")

    # 6d. Anti-BOM #27: Ensure VK10 uses is_stock (not is_tradfi) for Opening Bell exclusion
    m_vk10 = re.search(r"is_vk10_opening_bell[^\n]+", agg_src)
    if m_vk10 and "is_tradfi" in m_vk10.group(0) and "is_stock" not in m_vk10.group(0):
        errors.append(f"ai/signal_aggregator.py: BOM #27 regression — VK10 Opening Bell blocks Commodities via is_tradfi: {m_vk10.group(0)[:100]}")

    # 6e. Anti-BOM #44/#45/#46/#47/#51/#56/#57: Lock V6.1 tuning, BTC deadlock, zombie ladder & Free-Roll invariants
    if "v61_tp_ladder" in bot_src:
        errors.append("core/bot.py: BOM #47 regression — zombie v61_tp_ladder still present!")
    if "v61_tp1_pct" not in bot_src or "_v61_cush_ov" not in bot_src or "_v61_breath_mult" not in bot_src:
        errors.append("core/bot.py: BOM #44/#45 regression — v61_tp1_pct / _v61_cush_ov / _v61_breath_mult not wired!")
    if "_v61_flat_be_trig" not in bot_src:
        errors.append("core/bot.py: BOM #46 regression — _v61_flat_be_trig missing (old 0.95% flat BE override)!")
    if re.search(r"be_trigger_pct'\]\s*=\s*0\.008(?![0-9])", agg_src):
        errors.append("ai/signal_aggregator.py: BOM #56 regression — sub-0.85% be_trigger_pct=0.008 found!")
    if "btc_macro_down and not btc_macro_up" not in agg_src:
        errors.append("ai/signal_aggregator.py: BOM #51 regression — BTC 2-way deadlock guard missing!")
    rm_src = parsed_cache.get("risk/risk_manager.py", (None, "", None))[1]
    if "v61_tp1_take_pct" not in rm_src:
        errors.append("risk/risk_manager.py: BOM #57 regression — Free-Roll 0% take guard missing!")
    # 6f. Anti-BOM #59/#60/#61/#62/#65/#66/#67/#68: Leverage cap, BTC 1H macro sync, >=0.85% BE, 3-asset pullback, ChoCH & Shock Rescue
    if "BOM #59 FIX" not in bot_src or "BOM #60 FIX" not in bot_src or "BOM #62 FIX" not in bot_src:
        errors.append("core/bot.py: BOM #59/#60/#62 regression — missing V6.1 leverage cap / 1H BTC macro sync / 3-asset pullback cap!")
    if "BOM #65 FIX" not in bot_src or "BOM #67 FIX" not in bot_src:
        errors.append("core/bot.py: BOM #65/#67 regression — missing Shock Rescue Auction Cycle guard or ChoCH V6.1 sync!")
    if re.search(r'"breakeven_trigger"\s*:\s*0\.00[5678][0-4]?\b', bot_src):
        errors.append("core/bot.py: BOM #61 regression — sub-0.85% breakeven_trigger found in trailing profile!")
    if re.search(r"protection_status'\)\s*==\s*'exchange_stop_verified'", bot_src):
        errors.append("core/bot.py: BOM #68 regression — protection_status == 'exchange_stop_verified' missing 'exchange_stop'!")
    # 6g. Anti-BOM #69/#70/#71: Shadow bulk price feed (0 REST), Climax SL max + Shadow, Scanner IP Ban guard
    sc_src = parsed_cache.get("core/scanner.py", (None, "", None))[1]
    sh_src = parsed_cache.get("core/shadow_pathfinder.py", (None, "", None))[1]
    if "feed_bulk_prices" not in bot_src or "def feed_bulk_prices" not in sh_src or "last_all_ticker_prices" not in sc_src:
        errors.append("BOM #69 regression — Shadow bulk price feed (0 REST) missing!")
    if "_v61_climax_sl_max" not in bot_src:
        errors.append("core/bot.py: BOM #70 regression — _v61_climax_sl_max missing in Climax Retest!")
    if "get_ip_ban_remaining_seconds" not in sc_src:
        errors.append("core/scanner.py: BOM #71 regression — IP Ban guard missing before fetch_tickers()!")
    # 6h. Anti-BOM #72/#73/#74/#75: Server-side 5-Gate Promotion Guard, Shadow 240m Dual-Window + 100% weapon_id, ATR_15M Fee-Floor, Capital Ledger Wash Tagging
    qe_src = parsed_cache.get("core/quant_evolution_engine.py", (None, "", None))[1]
    if "5-GATE SERVER GUARD" not in qe_src or "verified_lab" not in qe_src:
        errors.append("core/quant_evolution_engine.py: BOM #72 regression — Server-side 5-Gate LAB promotion guard missing!")
    if "dual_eval_240m" not in sh_src or "capture_60m_snapshot" not in sh_src or "shadow_auto_classified" not in sh_src:
        errors.append("core/shadow_pathfinder.py: BOM #73 regression — 240m dual-window or 100% auto weapon_id missing!")
    if "FEE_FLOOR_LOW_ATR_15M" not in bot_src:
        errors.append("core/bot.py: BOM #74 regression — Safe 15M ATR Fee-Floor Gate missing!")
    if "_annotate_capital_ledger_wash_transfers" not in bot_src:
        errors.append("core/bot.py: BOM #75 regression — Non-destructive wash-transfer reconciliation missing!")
    # 6i. Anti-BOM #76/#77/#78/#79/#80/#81/#82: E_wick/Ratchet >=0.65% & ETF3x, 0% CRR/Trailing decouple, M1 15s cache, BTC Dump15m guard, no 0-or-50, no tp_ladder_enabled
    if "_eff_ewick_peak_l" not in bot_src or "_eff_ewick_peak_s" not in bot_src or "_already_profit_locked" not in bot_src:
        errors.append("core/bot.py: BOM #76 regression — E_wick/Ratchet >=0.65%/ETF3x guard or profit_locked status missing!")
    if "_is_zero_take_escalating" not in bot_src:
        errors.append("core/bot.py: BOM #77 regression — _is_zero_take_escalating CRR/Trailing decouple missing!")
    if "def _get_cached_m1_df" not in bot_src:
        errors.append("core/bot.py: BOM #78 regression — _get_cached_m1_df REST 1m cache missing!")
    if "BOM #79 FIX" not in agg_src:
        errors.append("ai/signal_aggregator.py: BOM #79 regression — BTC 15M base-building neutral guard missing!")
    if re.search(r"int\(position\.get\('v61_tp1_take_pct',\s*50\)\)\s+or\s+50", bot_src):
        errors.append("core/bot.py: BOM #80 regression — falsy `0 or 50` on v61_tp1_take_pct still present!")
    if "tp_ladder_enabled" in qe_src:
        errors.append("core/quant_evolution_engine.py: BOM #81 regression — dead legacy tp_ladder_enabled still present!")
    if "+{pnl_pct*100:+.2f}%" in bot_src:
        errors.append("core/bot.py: BOM #82 regression — double plus sign `++` in ChoCH log!")
    wa_src = parsed_cache.get("core/vietnamese_weapon_arsenal.py", (None, "", None))[1]
    if "BOM #83 FIX" not in wa_src or "WHERE close_reason IS NOT NULL" in wa_src:
        errors.append("core/vietnamese_weapon_arsenal.py: BOM #83 regression — live fills with NULL close_reason dropped!")
    if "def _eval_adaptive_oos" not in qe_src or "def audit_and_optimize_existing_weapons" not in qe_src or "GATE_INV" not in qe_src:
        errors.append("core/quant_evolution_engine.py: BOM #84 regression — 3-Axis Auto-Evolution / Existing Weapon Optimizer missing!")
    if "2WAY_BOTH" not in qe_src or "subsumed_labs" not in qe_src or "veto_gate=_dyn_veto_gate" not in agg_src:
        errors.append("BOM #85 regression — 2-Way (BOTH) auto-pairing, Auto-Subsumption tab, or GATE_INV live veto_gate wiring missing!")
    if (
        "BOM #86A FIX" not in qe_src
        or "BOM #86D FIX" not in qe_src
        or "dyn_vk_matched.get('_resolved_side')" not in agg_src
        or "'OVERSOLD_BOUNCE'" not in bot_src
        or "'TREND_MOMENTUM'" not in bot_src
    ):
        errors.append("BOM #86 regression — Dynamic weapon dedup reactivation, M1 reversal archetype detection, or _resolved_side sync missing!")
    if (
        "blocked_direction: str = \"\"" not in qe_src
        or "BOM #87 CRITICAL-1 FIX" not in qe_src
        or "elif final_signal.metadata.get('is_dynamic_weapon'):" not in agg_src
        or "position['max_sustained_profit_pct'] = max_sustained_profit_pct" not in bot_src
        or "mfe_best_changed" not in bot_src
        or "BOM #89 FIX" not in (parsed_cache.get("core/exchange.py", (None, "", None))[1])
        or "_canonical_tradfi_base" not in (parsed_cache.get("core/scanner.py", (None, "", None))[1])
        or "synthesize_dynamic_weapon_tree" not in qe_src
    ):
        errors.append("BOM #87-93 regression — VK11 blocked_direction guard, SL/TP restore, max_sustained_profit_pct, 418 IP-ban fix, or TradFi *B normalization missing!")
    if (
        "_tech_buys_pre" not in agg_src
        or "_is_gate_inv_2" not in agg_src
        or "preferred_weapon_id" not in qe_src
        or "_dyn_priority" not in qe_src
    ):
        errors.append("BOM #94 regression — raw tech blocked_direction, explicit-DNA COMBO invert, or dynamic weapon priority sort missing!")
    if "by_strategy['trap_detector'].signal" in agg_src or 'by_strategy["trap_detector"].signal' in agg_src:
        errors.append("ai/signal_aggregator.py: BOM #94A regression — by_strategy['trap_detector'].signal accesses .signal on a list!")

    # 6j. Anti-BOM #95-#100: Preemption tuple fix, ML thread-safe cache, JEV 15M wicks, VK11 extreme-AI guard, Quantum archetypes/TradFi exact set, WS ALGO_UPDATE, TradFi Dead Zone
    ws_src = parsed_cache.get("core/binance_ws.py", (None, "", None))[1]
    jev_src = parsed_cache.get("ai/jev_agent.py", (None, "", None))[1]
    mr_src = parsed_cache.get("ai/market_regime.py", (None, "", None))[1]
    if "def _build_preempt_tuple" not in bot_src or "_find_preemptable_stalking_order(exclude_symbol=signal.symbol, min_confidence=sig_conf, reason=" in bot_src:
        errors.append("core/bot.py: BOM #95A regression — Deferred Preemption signature/unpack bug!")
    if "_ml_model_cache" not in bot_src or "self.ml_predictor.load_model(" in bot_src:
        errors.append("core/bot.py: BOM #95B regression — unsynchronized shared self.ml_predictor across 8 threads!")
    if "LIVE FORMING CANDLES" not in jev_src or "trend_15m_label" not in jev_src:
        errors.append("ai/jev_agent.py: BOM #95C regression — 15M wicks/trend label or live forming candles missing!")
    if "is_extreme_ai_conflict_ctx" not in agg_src or "preferred_weapon_id=str(dyn_slot_a_exempt_sig" in agg_src:
        errors.append("ai/signal_aggregator.py: BOM #95D regression — VK11 extreme AI conflict guard or preferred_weapon_id bug!")
    if "OVERSOLD_BOUNCE" not in q_src or "TREND_MOMENTUM" not in q_src or "_TRADFI_EXACT_BASES" not in q_src:
        errors.append("ai/quantum_path_simulator.py: BOM #95F regression — quantum_archetype mismatch or _is_tradfi prefix collision!")
    if "order_data.setdefault('X', 'FILLED'" in ws_src:
        errors.append("core/binance_ws.py: BOM #95G regression — ALGO_UPDATE setdefault('X', 'FILLED') no-op bug!")
    if "bf_pnl" not in wa_src or "get_last_veto_info" not in agg_src or "choke_sl_applied" not in bot_src:
        errors.append("BOM #95H/#96/#97 regression — arsenal 2x PnL dedup, aggregator veto telemetry, or choke_sl_applied latch missing!")
    if "(0 <= vn_hour < 8)" in mr_src:
        errors.append("ai/market_regime.py: BOM #99 regression — VN hour overlap blocks US Power Hour in is_tradfi_dead_zone()!")
    ol_src = parsed_cache.get("ai/ollama_agent.py", (None, "", None))[1]
    if '"num_ctx": 2048' not in jev_src or '"num_ctx": 2048' not in ol_src or '"deferred_phase2"' not in ol_src:
        errors.append("ai/jev_agent.py & ai/ollama_agent.py: BOM #109A/B/C + #115A + #116B regression — num_ctx=2048 parity or Phase 2 GPU yield guard missing!")

    # 6k. Anti-BOM #110A..D: Phase 2 exit cleanup, watchlist lock, Free-Roll correlation basis, peak/initial_sl/drawdown/SL buffer, Shadow tp_side_ok + ETF3x floor, Cloud per-token IDs, pre-OrderFlow PAUSED guard
    rm_src_6 = open(os.path.join(ROOT, "risk", "risk_manager.py"), "r", encoding="utf-8").read()
    sp_src_6 = open(os.path.join(ROOT, "core", "shadow_pathfinder.py"), "r", encoding="utf-8").read()
    cs_src_6 = open(os.path.join(ROOT, "cloud_sync.py"), "r", encoding="utf-8").read()
    if "ollama_phase2_exit" not in bot_src or "_watchlist_lock" not in bot_src:
        errors.append("core/bot.py: BOM #110A regression — Phase 2 exit cleanup or _watchlist_lock missing!")
    if "base_max_open_positions" not in rm_src_6 or "has_stop_id_or_demo" not in rm_src_6:
        errors.append("risk/risk_manager.py: BOM #110C regression — Free-Roll correlation cap basis or sl_order_id check missing!")
    if (
        "v61_peak_equity" not in bot_src
        or "'initial_sl': sl_price" not in bot_src
        or "released_margin" not in bot_src
        or "db_pnl_ok" not in bot_src
        or "_has_verified_exch_sl" not in bot_src
    ):
        errors.append("core/bot.py: BOM #110C regression — v61_peak_equity, initial_sl, Demo released_margin, db_pnl_ok, or _has_verified_exch_sl missing!")
    if "tp_side_ok" not in sp_src_6 or "min_sl_floor" not in sp_src_6:
        errors.append("core/shadow_pathfinder.py: BOM #110D regression — tp_side_ok or ETF 3x 1.8% floor missing!")
    if "last_command_ids" not in cs_src_6:
        errors.append("cloud_sync.py: BOM #110D regression — per-token last_command_ids missing!")
    if "WEAPON_PAUSED_LIFECYCLE" not in agg_src:
        errors.append("ai/signal_aggregator.py: BOM #110B regression — WEAPON_PAUSED_LIFECYCLE pre-OrderFlow guard missing!")

    report.add(6, "Cross-Layer 8-Station Metadata & BOM #6/#17/#20/#26/#27/#44-110 Contracts", errors, warnings)


# ---------------------------------------------------------------------------
# AXIS 7: Purged Anti-Patterns (Rule 0.1) & SQLite Safety (BOM #8 / Invariant #15)
# ---------------------------------------------------------------------------
def run_axis_7(report: AuditReport, parsed_cache: dict):
    errors = []
    warnings = []
    bot_src = parsed_cache.get("core/bot.py", (None, "", None))[1]
    purged = [
        "doa_15m", "doa_25m", "doa_35m", "idle_120m",
        "is_mfe_ratchet_breached", "time_based_exits",
    ]
    for pat in purged:
        for idx, line in enumerate(bot_src.splitlines(), 1):
            st = line.strip()
            if st.startswith("#"):
                continue
            if pat in line:
                errors.append(f"core/bot.py:{idx} PURGED ANTI-PATTERN '{pat}' is active!")

    # Check timeout_sec specifically for sniper stalking (allow jev_read_timeout_seconds / request timeout)
    for idx, line in enumerate(bot_src.splitlines(), 1):
        st = line.strip()
        if st.startswith("#"):
            continue
        if re.search(r"\btimeout_sec\b", line):
            errors.append(f"core/bot.py:{idx} PURGED Zero-Timer violation 'timeout_sec'!")

    # SQLite concurrency check across read-only UI/analytics modules
    ro_modules = {"dashboard/app.py", "core/vietnamese_weapon_arsenal.py", "core/quant_evolution_engine.py", "ai/quant_validation_engine.py"}
    sqlite_sites = 0
    for rel, (_, src, _) in parsed_cache.items():
        if rel.startswith("tools/"):
            continue
        ls = src.splitlines()
        for idx, line in enumerate(ls, 1):
            if "sqlite3.connect(" in line and not line.strip().startswith("#"):
                sqlite_sites += 1
                ctx = " ".join(ls[max(0, idx - 1):min(len(ls), idx + 6)])
                if "timeout" not in ctx:
                    warnings.append(f"{rel}:{idx} sqlite3.connect() missing timeout=")
                if rel in ro_modules and ("query_only" not in ctx and "mode=ro" not in ctx):
                    errors.append(f"{rel}:{idx} read-only UI/analytics module missing PRAGMA query_only=ON or mode=ro!")

    report.add(
        7,
        "Purged Anti-Patterns (Rule 0.1) & SQLite Read-Only Concurrency",
        errors,
        warnings,
        notes=[f"Verified {sqlite_sites} sqlite3.connect() sites across production code"],
    )


# ---------------------------------------------------------------------------
# AXIS 8: YAML Configs & MarketScanner 3-Asset-Class / ETF Vectors
# ---------------------------------------------------------------------------
def run_axis_8(report: AuditReport):
    errors = []
    warnings = []
    import yaml
    from core.scanner import MarketScanner

    for yfn in ("config/settings.yaml", "config/strategies.yaml", "config/pairs.yaml"):
        yp = os.path.join(ROOT, yfn)
        if not os.path.exists(yp):
            errors.append(f"Missing required config: {yfn}")
            continue
        try:
            data = yaml.safe_load(read_text(yp))
            if not isinstance(data, dict):
                errors.append(f"{yfn}: top-level YAML is not a dict")
        except Exception as e:
            errors.append(f"{yfn}: YAML parse error: {e}")

    # Verify MarketScanner.is_leveraged_etf & asset classification vectors
    etf_vectors = [
        ("SOXL/USDT", True), ("SOXS/USDT", True), ("TQQQ/USDT", True), ("SQQQ/USDT", True),
        ("NVDL/USDT", True), ("TSLL/USDT", True), ("MSTU/USDT", True), ("SOXLB/USDT", True),
        ("NVDA/USDT", False), ("MSTR/USDT", False), ("CL/USDT", False), ("XAU/USDT", False),
        ("BTC/USDT", False), ("STEEM/USDT", False),
    ]
    for sym, expected in etf_vectors:
        got = MarketScanner.is_leveraged_etf(sym)
        if got != expected:
            errors.append(f"MarketScanner.is_leveraged_etf({sym!r})={got}, expected {expected}")

    # Verify Commodity vs Stock separation (BOM #27 invariant)
    for sym in ("CL/USDT", "BZ/USDT", "XAU/USDT", "XAG/USDT"):
        if not MarketScanner.is_tradfi_symbol(sym):
            errors.append(f"MarketScanner.is_tradfi_symbol({sym!r}) returned False!")
        if not MarketScanner.is_tradfi_commodity(sym):
            errors.append(f"MarketScanner.is_tradfi_commodity({sym!r}) returned False!")
        if MarketScanner.is_tradfi_stock(sym):
            errors.append(f"MarketScanner.is_tradfi_stock({sym!r}) returned True for Commodity!")

    report.add(8, "YAML Config Integrity & MarketScanner 3-Asset/ETF Vectors", errors, warnings, notes=[f"Verified 3 YAMLs + {len(etf_vectors)} ETF vectors"])


# ---------------------------------------------------------------------------
# AXIS 9: Dashboard HTML <-> Backend Routes & deploy_web_client.py Manifest
# ---------------------------------------------------------------------------
def run_axis_9(report: AuditReport, parsed_cache: dict):
    errors = []
    warnings = []
    app_src = parsed_cache.get("dashboard/app.py", (None, "", None))[1]
    routes = set(re.findall(r"@app\.route\(['\"]([^'\"]+)['\"]", app_src))
    tpl_checked = 0
    for tpl in ("dashboard/templates/index.html", "dashboard/templates/pipeline_map.html"):
        tp = os.path.join(ROOT, tpl)
        if not os.path.exists(tp):
            errors.append(f"Missing template: {tpl}")
            continue
        tpl_checked += 1
        html = read_text(tp)
        fetches = sorted(set(re.findall(r"fetch\(\s*['\"`](/api/[^'\"`?]+)", html)))
        for ep in fetches:
            prefix = ep.split("${")[0]
            if ep not in routes and not any(r.startswith(prefix) for r in routes):
                errors.append(f"{tpl}: fetch('{ep}') has NO matching route in dashboard/app.py")

    # Anti-BOM #9: deploy_web_client.py must include critical custom files
    dep_path = os.path.join(ROOT, "deploy_web_client.py")
    if os.path.exists(dep_path):
        dep_src = read_text(dep_path)
        for req_f in ("core/vietnamese_weapon_arsenal.py", "core/quant_evolution_engine.py", "dashboard/templates/pipeline_map.html"):
            if req_f not in dep_src:
                errors.append(f"deploy_web_client.py: BOM #9 regression — missing '{req_f}' in manifest!")

    report.add(
        9,
        "Dashboard HTML <-> Flask Routes & Deploy Manifest (Anti-BOM #9)",
        errors,
        warnings,
        notes=[f"Checked {tpl_checked} templates against {len(routes)} Flask routes"],
    )


# ---------------------------------------------------------------------------
# AXIS 10: Weapon Arsenal (VK1..VK10+), Runtime IP Ban & Quantum Sanity
# ---------------------------------------------------------------------------
def run_axis_10(report: AuditReport):
    errors = []
    warnings = []
    from core.vietnamese_weapon_arsenal import (
        WEAPON_ARSENAL_CATALOG,
        classify_signal_weapon,
    )
    from ai.news_sentiment import NewsSentimentAnalyzer
    from ai.order_flow_analyzer import OrderFlowAnalyzer
    from ai.quantum_path_simulator import QuantumPathSimulator
    import core.exchange as ex_mod

    # 10a. Weapon Arsenal catalog & direct/opposite direction safety
    if len(WEAPON_ARSENAL_CATALOG) < 10:
        errors.append(f"Expected >= 10 weapons in WEAPON_ARSENAL_CATALOG, found {len(WEAPON_ARSENAL_CATALOG)}")
    for wid, w in WEAPON_ARSENAL_CATALOG.items():
        d = "LONG" if w["side"] == "LONG" else ("SHORT" if w["side"] == "SHORT" else "LONG")
        c = classify_signal_weapon(meta={"weapon_id": wid}, direction=d)
        if c["id"] != wid:
            errors.append(f"Weapon {wid} ({d}) misclassified as {c['id']}")
        if w["side"] in ("LONG", "SHORT"):
            opp = "SHORT" if w["side"] == "LONG" else "LONG"
            c_opp = classify_signal_weapon(meta={"weapon_id": wid}, direction=opp)
            if c_opp["side"] not in ("BOTH", opp):
                errors.append(f"Weapon {wid} direction leak when flipped to {opp}: got {c_opp['id']} ({c_opp['side']})")

    # 10b. Runtime IP Ban Circuit Breaker test (0 HTTP — purely in-memory!)
    orig_until = ex_mod._IP_BANNED_UNTIL_TS
    try:
        ex_mod._IP_BANNED_UNTIL_TS = time.time() + 60.0
        nsa = NewsSentimentAnalyzer()
        res_nsa = nsa.get_binance_derivatives_data("BTC/USDT")
        if res_nsa.get("available") is not False:
            errors.append("BOM #29 regression: NewsSentimentAnalyzer did NOT abort during active IP ban!")

        ofa = OrderFlowAnalyzer()
        res_ofa_delta = ofa.get_order_flow_delta("BTC/USDT")
        res_ofa_ob = ofa.get_aggregated_order_book("BTC/USDT")
        if res_ofa_delta.get("available") is True or res_ofa_ob.get("available") is True:
            errors.append("BOM #24 regression: OrderFlowAnalyzer did NOT abort during active IP ban!")
    finally:
        ex_mod._IP_BANNED_UNTIL_TS = orig_until

    # 10c. QuantumPathSimulator TradFi low-vol drift sanity (BOM #19 — matches live CL/USDT VK10 vector)
    # Note: atr_pct in QuantumPathSimulator.simulate() is in PERCENT units (e.g., 0.52 = 0.52%)
    qps = QuantumPathSimulator()
    sim_res = qps.simulate(
        symbol="CL/USDT",
        side="BUY",
        entry_price=81.62,
        stop_loss=80.80,
        take_profit=83.09,
        atr_pct=0.52,
        adx=20.4,
        score=0.85,
        regime="ranging",
        metadata={
            "is_vk10_tradfi_bottom_long": True,
            "weapon_id": "VK10",
            "c_lower_wick_ratio": 0.712,
            "c_vol_ratio": 1.16,
            "c_rsi": 40.8,
        },
    )
    if not isinstance(sim_res, dict) or "p_win" not in sim_res or "sigma_total_pct" not in sim_res or "pass_gate" not in sim_res:
        errors.append(f"QuantumPathSimulator.simulate returned invalid payload: {list(sim_res.keys()) if isinstance(sim_res, dict) else type(sim_res)}")
    elif not sim_res.get("pass_gate"):
        errors.append(f"BOM #19 regression: QuantumPathSimulator rejected valid TradFi VK10 CL/USDT vector: {sim_res.get('veto_reasons')}")

    # 10d. V6.1 Quant Evolution Engine contracts (Auto-Lab 20 Lenses, 4-Asset Bounds, TP Merge >= $6.5, Bayes Half-Life)
    from core.quant_evolution_engine import (
        CONSTITUTION_BOUNDS,
        DEFAULT_POSITION_TUNING,
        auto_merge_tp_ladder,
        bayes_shrunk_win_rate,
        compute_shadow_bayes_breathing_advisor,
        run_auto_dna_lab_discovery_and_optimizer,
    )
    for ac_k, b_v in CONSTITUTION_BOUNDS.items():
        if b_v["be_min"] < 0.85:
            errors.append(f"V6.1 Constitution violation: {ac_k} be_min={b_v['be_min']} < 0.85%!")
    if CONSTITUTION_BOUNDS["TRADFI_ETF_3X"]["max_lev"] > 2.0:
        errors.append("V6.1 Constitution violation: TRADFI_ETF_3X max_lev > 2x!")
    # Auto-merge TP ladder safety across $25 -> $20,000
    stages_5 = DEFAULT_POSITION_TUNING["classes"]["ALTCOIN"]["tp_stages"]
    for test_not in (12.0, 20.0, 40.6, 81.2, 400.0):
        merged = auto_merge_tp_ladder(stages_5, test_not, min_slice_usd=6.5)
        if not merged:
            errors.append(f"V6.1 auto_merge_tp_ladder returned empty for notional=${test_not}")
        elif len(merged) >= 2 and any(m["est_usd"] < 6.49 for m in merged):
            errors.append(f"V6.1 MIN_NOTIONAL violation at ${test_not}: {merged}")
    # Dual-Memory Bayes Half-Life sanity (1m restart vs 24h outage)
    p_1m = bayes_shrunk_win_rate(6.0, 6.0, 4.0)
    p_24h = bayes_shrunk_win_rate(6.0 * (0.5 ** 4), 6.0 * (0.5 ** 4), 4.0)
    if not (65.0 <= p_1m <= 80.0 and 50.0 <= p_24h <= 56.0):
        errors.append(f"V6.1 Dual-Memory Bayes sanity failed: p_1m={p_1m}%, p_24h={p_24h}%")
    adv_v61 = compute_shadow_bayes_breathing_advisor(db_path=os.path.join(ROOT, "data", "trade_bot.db"))
    if set((adv_v61.get("advisor_by_class") or {}).keys()) != set(CONSTITUTION_BOUNDS.keys()):
        errors.append("V6.1 Advisor missing one of 4 asset subclasses!")
    lab_v61 = run_auto_dna_lab_discovery_and_optimizer(db_path=os.path.join(ROOT, "data", "trade_bot.db"))
    if not isinstance(lab_v61.get("rejected_labs"), list) or not isinstance(lab_v61.get("active_labs"), list):
        errors.append("V6.1 Auto LAB Optimizer returned invalid payload!")

    # 10e. BOM #101A..F + BOM #102A..G Regression Locks (Zero-arg MLPredictor, 3-Asset Weapon DNA SL Shield, Per-Weapon M1, Quet SL res_sl_rate & Zero-Leakage OOS, PAUSED Failsafe)
    import inspect
    from ai.ml_model import MLPredictor as _MLPredChk
    _ml_sig = inspect.signature(_MLPredChk.__init__)
    _ml_params = [p for k, p in _ml_sig.parameters.items() if k != "self"]
    _bot_src_10 = open(os.path.join(ROOT, "core", "bot.py"), "r", encoding="utf-8").read()
    _agg_src_10 = open(os.path.join(ROOT, "ai", "signal_aggregator.py"), "r", encoding="utf-8").read()
    _qee_src_10 = open(os.path.join(ROOT, "core", "quant_evolution_engine.py"), "r", encoding="utf-8").read()
    if len(_ml_params) == 0 and re.search(r"\bMLPredictor\s*\([^)\s]", _bot_src_10):
        errors.append("BOM #101A regression: core/bot.py calls MLPredictor(...) with arguments while MLPredictor.__init__(self) takes 0 args!")
    if "BOM101_WEAPON_DNA_" not in _agg_src_10 or "WEAPON_PAUSED_LIFECYCLE" not in _agg_src_10 or "VK5_MAJOR_VBOTTOM_GUARD" not in _agg_src_10 or "VK7_MAJOR_STOPHUNT_GUARD" not in _agg_src_10:
        errors.append("BOM #101B/F/#102G regression: ai/signal_aggregator.py missing 3-asset weapon DNA SL shields or PAUSED failsafe!")
    if "BOM #102F" not in _bot_src_10 or "_is_vk9_fast_clx" not in _bot_src_10 or "atr_pct * 0.22" not in _bot_src_10:
        errors.append("BOM #102F/BOM #111B regression: core/bot.py missing per-weapon M1 calibration (VK9/VK10 0.18*ATR vs VK4/6/7 0.22*ATR [0.12-0.35%])!")
    if "BOM #101D FIX" not in _bot_src_10 or "not bool(meta.get('is_waterfall_short'))" not in _bot_src_10:
        errors.append("BOM #101D regression: core/bot.py missing Momentum/Climax separation in Tru Cot 1!")
    if "BOM #101F FIX" not in _bot_src_10:
        errors.append("BOM #101F regression: core/bot.py missing PAUSED weapon auto-cancel in M1 stalking monitor!")
    if "res_sl_rate" not in _qee_src_10 or "BOM #103K" not in _qee_src_10 or "BOM #102D" not in _qee_src_10:
        errors.append("BOM #102A..D/#103K regression: core/quant_evolution_engine.py missing Quet SL res_sl_rate / Zero-Leakage IS / VK8 BOTH wick normalization!")

    # 10f. BOM #103A..M Regression Locks (ATR dead-zone, BEAR_TRAP->VK3, OrderFlow non-hijack, COMBO SLOT_A, Pre-Fill M1 skip, Stage6 BE/Choke/M1-count, UI position_tuning_panel)
    _ars_src_10 = open(os.path.join(ROOT, "core", "vietnamese_weapon_arsenal.py"), "r", encoding="utf-8").read()
    _shd_src_10 = open(os.path.join(ROOT, "core", "shadow_pathfinder.py"), "r", encoding="utf-8").read()
    _pm_src_10 = open(os.path.join(ROOT, "dashboard", "templates", "pipeline_map.html"), "r", encoding="utf-8").read()
    if "_dna_atr >= 0.08" not in _agg_src_10 or "tactical_atr_pct" not in _agg_src_10:
        errors.append("BOM #103A regression: ai/signal_aggregator.py missing 15M tactical_atr_pct priority & >=0.08 ATR unit fix!")
    if "'BEAR_TRAP' not in trap_type" not in _ars_src_10:
        errors.append("BOM #103B regression: core/vietnamese_weapon_arsenal.py missing BEAR_TRAP guard on VK4!")
    if "_is_dyn_of = bool(final_signal.metadata.get('is_dynamic_weapon'))" not in _agg_src_10:
        errors.append("BOM #103C regression: ai/signal_aggregator.py Order Flow Confirmed can hijack dynamic weapons!")
    if "closed_is_post_entry" not in _bot_src_10 or "and (not can_lock_net_profit)" not in _bot_src_10 or "_last_m1_guard_min" not in _bot_src_10:
        errors.append("BOM #103H/I regression: core/bot.py missing pre-order M1 guard, CRR post-entry check, or Hard BE lock priority!")
    if "SHUTDOWN_FLUSH" not in _shd_src_10:
        errors.append("BOM #103L regression: core/shadow_pathfinder.py missing SHUTDOWN_FLUSH 60m snapshot guard!")
    if "position_tuning_panel" not in _pm_src_10 or "((latestData || {}).position_tuning || {})" in _pm_src_10:
        errors.append("BOM #103M regression: pipeline_map.html still references undefined latestData.position_tuning!")
    # 10g. BOM #104 Anti-Dead-Code & V6.4 C5 TP/SL Lock (Zero v61_single_tp_mode / 25% / 100% dead UI options, SL_ATR_BASE_REFERENCE, Lock 80%, Choke 75%)
    if "v61_single_tp_mode" in _bot_src_10 or "KB14-D" in _bot_src_10 or "PF 1.24" in _pm_src_10 or 'option value="25"' in _pm_src_10 or 'option value="100"' in _pm_src_10:
        errors.append("BOM #104 regression: dead TP/SL code (v61_single_tp_mode / KB14-D / PF 1.24 / 25% / 100% option) still present!")
    if "SL_ATR_BASE_REFERENCE" not in _qee_src_10 or "SL_ATR_BASE_REFERENCE" not in _bot_src_10 or "_en_tp_pcts[0] * 0.80" not in _bot_src_10:
        errors.append("BOM #104 regression: missing SL_ATR_BASE_REFERENCE or 80%xTP1 escalating lock!")
    # 10h. BOM #105A..F Cross-Tier Locks (v61_runner_hard_tp_pct separate from Quantum Gate TP, rem_est_notional >= 5.2, risk_manager None-safe int)
    _rm_src_10 = open(os.path.join(ROOT, "risk", "risk_manager.py"), "r", encoding="utf-8").read()
    if "v61_runner_hard_tp_pct" not in _bot_src_10 or "rem_est_notional < 5.2" not in _bot_src_10:
        errors.append("BOM #105B/D regression: core/bot.py missing v61_runner_hard_tp_pct separation or rem_est_notional >= 5.2 guard!")
    if "pos.get('v61_tp1_take_pct') is None" not in _rm_src_10:
        errors.append("BOM #105A regression: risk/risk_manager.py unsafe int(pos.get('v61_tp1_take_pct', 50)) can crash on None!")

    # 10i. BOM #111A..D Regression Locks (VK3 PAUSED, M1 0.22*ATR, Hurst+FPT+RMT+WilsonKelly, UTC Simulator + LAB M1 Replay)
    _lc_10i = load_weapon_lifecycle() if "load_weapon_lifecycle" in globals() else json.load(open(os.path.join(ROOT, "config", "weapon_lifecycle.json"), "r", encoding="utf-8"))
    if (_lc_10i.get("states") or {}).get("VK3_LONG_SAN_RU_GOM_DAY") != "PAUSED":
        errors.append("BOM #111A regression: VK3_LONG_SAN_RU_GOM_DAY must be PAUSED in config/weapon_lifecycle.json!")
    if "0.0012" not in _bot_src_10 or "0.0035" not in _bot_src_10 or "get_weapon_wilson_kelly_multiplier" not in _bot_src_10:
        errors.append("BOM #111B/C regression: core/bot.py missing 0.22*ATR [0.12-0.35%] or get_weapon_wilson_kelly_multiplier!")
    _qps_src_10 = open(os.path.join(ROOT, "ai", "quantum_path_simulator.py"), "r", encoding="utf-8").read()
    for _tok in ("_compute_hurst_rs", "_compute_empirical_fpt", "compute_crypto_rmt_coherence", "mp_excess"):
        if _tok not in _qps_src_10:
            errors.append(f"BOM #111C regression: ai/quantum_path_simulator.py missing {_tok}!")
    if "wilson_lower_bound" not in _rm_src_10 or "get_weapon_wilson_kelly_multiplier" not in _rm_src_10:
        errors.append("BOM #111C regression: risk/risk_manager.py missing wilson_lower_bound or get_weapon_wilson_kelly_multiplier!")
    _sim_src_10 = open(os.path.join(ROOT, "tools", "full_historical_signal_and_position_simulator.py"), "r", encoding="utf-8").read()
    if "timezone.utc" not in _sim_src_10 or "PRAGMA query_only" not in _sim_src_10:
        errors.append("BOM #111D regression: tools/full_historical_signal_and_position_simulator.py missing timezone.utc or PRAGMA query_only!")
    if "_eval_lab_m1_sniper_replay" not in _qee_src_10 or "rescued_by_m1" not in _qee_src_10:
        errors.append("BOM #111D regression: core/quant_evolution_engine.py missing _eval_lab_m1_sniper_replay or rescued_by_m1!")

    # 10j. BOM #112A..F Regression Locks (LAB M1 Fill-First + promote m1_rescued, RiskManager JSON/signals attrib, M1 0.35% ceiling, TP2..TP5 enabled)
    if "BOM #112A FIX" not in _qee_src_10 or "BOM #112F FIX" not in _qee_src_10:
        errors.append("BOM #112A/F regression: core/quant_evolution_engine.py missing Fill-First M1 guard or promote_lab m1_rescued check!")
    if "BOM #112B FIX" not in _rm_src_10:
        errors.append("BOM #112B regression: risk/risk_manager.py missing BOM #112B live order_id/raw_json/signals attribution!")
    if "BOM #112C FIX" not in _bot_src_10 or "min(0.0060," in _bot_src_10:
        errors.append("BOM #112C regression: core/bot.py still has old min(0.0060,) pullback override or missing BOM #112C FIX!")
    try:
        _pt_10j = json.load(open(os.path.join(ROOT, "config", "position_tuning.json"), "r", encoding="utf-8"))
        for _cls_10j in ("ALTCOIN", "MAJOR", "TRADFI_1X", "TRADFI_ETF_3X"):
            _stages_10j = ((_pt_10j.get("classes") or {}).get(_cls_10j) or {}).get("tp_stages") or []
            if len(_stages_10j) < 5 or not bool(_stages_10j[0].get("enabled", False)):
                errors.append(f"BOM #112D/#113D regression: config/position_tuning.json {_cls_10j} missing 5 TP stages or TP1 disabled!")
    except Exception as _pt_err_10j:
        errors.append(f"BOM #112D regression: failed reading config/position_tuning.json ({_pt_err_10j})")

    # 10k. BOM #113A..D + #115A + #116B Regression Locks (num_ctx=2048 synced across Jev/Ollama/Prewarm, Hallucination Guard, VK12 Bayes 80%, OrderFlow Dyn Shield)
    _jev_src_10 = open(os.path.join(ROOT, "ai", "jev_agent.py"), "r", encoding="utf-8").read()
    _oll_src_10 = open(os.path.join(ROOT, "ai", "ollama_agent.py"), "r", encoding="utf-8").read()
    if '"num_ctx": 2048' not in _jev_src_10 or '"num_ctx": 2048' not in _oll_src_10 or '"num_ctx": 2048' not in _bot_src_10:
        errors.append("BOM #115A/#116B regression: num_ctx=2048 must be synchronized across ai/jev_agent.py, ai/ollama_agent.py, and core/bot.py!")
    if '"num_ctx": 1536' in _jev_src_10 or '"num_ctx": 1536' in _oll_src_10 or '"num_ctx": 1536' in _bot_src_10:
        errors.append("BOM #113A regression: old truncating num_ctx=1536 still present!")
    if "JEV HALLUCINATION GUARD" not in _jev_src_10 or "prompt_eval_count" not in _jev_src_10:
        errors.append("BOM #113A regression: ai/jev_agent.py missing JEV HALLUCINATION GUARD or prompt_eval_count telemetry!")
    if "BOM #113B FIX" not in _qee_src_10:
        errors.append("BOM #113B regression: core/quant_evolution_engine.py missing verified_server_stats M1 rescued fix!")
    if float(((_lc_10i.get("dynamic_weapons") or {}).get("VK12_SHORT_DONG_9620") or {}).get("verified_server_stats", {}).get("win_rate", 100.0)) < 70.0:
        errors.append("BOM #113B regression: VK12_SHORT_DONG_9620 verified_server_stats win_rate < 70%!")
    if "BOM #113C FIX" not in _agg_src_10 or "Hurst=" not in _bot_src_10:
        errors.append("BOM #113C regression: ai/signal_aggregator.py missing dynamic weapon OrderFlow guard or core/bot.py missing Hurst PASS log!")

    # 10l. BOM #114A..C + #115A..F + #116B Regression Locks (Static KV Prefix + num_ctx=2048, Stale AI Bias TTL, Ghost Attr Removal, Pre-LLM GPU Guards, Lock/Single-Class Fixes)
    _tf_src_10 = open(os.path.join(ROOT, "strategies", "trend_following.py"), "r", encoding="utf-8").read()
    _sc_src_10 = open(os.path.join(ROOT, "core", "scanner.py"), "r", encoding="utf-8").read()
    _ml_src_10 = open(os.path.join(ROOT, "ai", "ml_model.py"), "r", encoding="utf-8").read()
    if "prompt_tok=%d/2048" not in _jev_src_10 or "BOM #114B FIX" not in _tf_src_10 or "BOM #114C" not in _bot_src_10:
        errors.append("BOM #114/#115/#116B regression: missing prompt_tok=%d/2048, TrendFollowing Altcoin 1.25x floor, or Cycle #1 AI defer 45s!")

    # 10m. BOM #115A..F Regression Locks
    _jev_prompt_pos = _jev_src_10.find('prompt = f"""')
    _jev_rule_pos = _jev_src_10.find("DECISION RULES:", _jev_prompt_pos)
    _jev_data_pos = _jev_src_10.find("LIVE MTF DATA FOR {symbol}", _jev_prompt_pos)
    if (
        "BOM #115A FIX" not in _jev_src_10
        or _jev_prompt_pos <= 0
        or _jev_rule_pos <= _jev_prompt_pos
        or _jev_data_pos <= _jev_rule_pos
        or "{symbol}" in _jev_src_10[_jev_prompt_pos:_jev_data_pos]
    ):
        errors.append("BOM #115A regression: ai/jev_agent.py missing static KV prefix cache layout (DECISION RULES must precede {symbol})!")
    if "[OLLAMA MACRO PERF]" not in _oll_src_10:
        errors.append("BOM #115A regression: ai/ollama_agent.py missing [OLLAMA MACRO PERF] timing/token telemetry!")
    if (
        "BOM #115B" not in _bot_src_10
        or "getattr(self, 'ai_bias'" in _bot_src_10
        or "getattr(self, 'aggregator'" in _bot_src_10
        or "BOM #115D FIX" not in _bot_src_10
        or "def _record_pipeline_veto_step" not in _bot_src_10
        or "def _record_ai_bias_veto_telemetry" not in _bot_src_10
    ):
        errors.append("BOM #115B/C/D/F regression: core/bot.py missing stale bias TTL, ghost attr fixes, Pre-LLM Fast-Skip guards, or post-T3 VETO trace helpers!")
    if "_markets_reload_lock" not in _sc_src_10 or "len(probs) < 2" not in _ml_src_10:
        errors.append("BOM #115E/F regression: core/scanner.py missing _markets_reload_lock or ai/ml_model.py missing len(probs) < 2 guard!")

    # 10n. BOM #116A..F Regression Locks
    _dep_src_10 = open(os.path.join(ROOT, "deploy_web_client.py"), "r", encoding="utf-8").read()
    _db_src_10 = open(os.path.join(ROOT, "database", "db_manager.py"), "r", encoding="utf-8").read()
    _qve_src_10 = open(os.path.join(ROOT, "ai", "quant_validation_engine.py"), "r", encoding="utf-8").read()
    if (
        ('if __name__ == "__main__":' not in _dep_src_10 and "if __name__ == '__main__':" not in _dep_src_10)
        or "lab_registry.json" not in _dep_src_10
        or "weapon_lifecycle.json" not in _dep_src_10
        or "position_tuning.json" not in _dep_src_10
    ):
        errors.append("BOM #116F regression: deploy_web_client.py missing __main__ guard or runtime JSON preservation!")
    if (
        "id_map" not in _qee_src_10
        or "def hard_delete_dynamic_weapon" not in _qee_src_10
        or "def compact_dynamic_weapon_codes" not in _qee_src_10
        or ".replace(old_code, new_code)" in _qee_src_10
    ):
        errors.append("BOM #116A regression: core/quant_evolution_engine.py missing permanent LAB id_map, hard_delete/compact VK, or still mutates with replace(old_code, new_code)!")
    _bot_stop_m = re.search(r"    def stop\(self\):.*?(?=\n    def |\Z)", _bot_src_10, re.S)
    _bot_stop_blk = _bot_stop_m.group(0) if _bot_stop_m else ""
    _stop_outside_ws = bool("_ws_to_stop.stop()" in _bot_stop_blk and "\n        if _ws_to_stop is not None:\n            try:\n                _ws_to_stop.stop()" in _bot_stop_blk)
    if (
        "min_margin_floor" not in _bot_src_10
        or "base_max_open_positions=configured_max" not in _bot_src_10
        or not _stop_outside_ws
    ):
        errors.append("BOM #116C regression: core/bot.py missing min_margin_floor, preemption base_max_open_positions=configured_max, or stop() ws_manager outside _position_lock!")
    _reg_m = re.search(r"def get_shadow_dual_window_regime\(.*?(?=\ndef |\Z)", _ars_src_10, re.S)
    _reg_blk = _reg_m.group(0) if _reg_m else ""
    if "generic_strats" not in _ars_src_10 or ("finally:" not in _reg_blk or "conn.close()" not in _reg_blk):
        errors.append("BOM #116D regression: core/vietnamese_weapon_arsenal.py missing generic_strats filter or finally: conn.close()!")
    _get_conn_m = re.search(r"    def _get_connection\(self\):.*?(?=\n    def |\Z)", _db_src_10, re.S)
    _get_conn_blk = _get_conn_m.group(0) if _get_conn_m else ""
    if "journal_mode=WAL" in _get_conn_blk:
        errors.append("BOM #116E regression: database/db_manager.py still executes PRAGMA journal_mode=WAL inside _get_connection()!")
    if "entry_side" not in _qve_src_10:
        errors.append("BOM #116E regression: ai/quant_validation_engine.py missing entry_side attribution support!")

    # 10o. BOM #117A..E Regression Locks
    if (
        "if not skip_llm_reason and not is_symbol_open:" not in _bot_src_10
        or "is_fee_scratch_be" not in _bot_src_10
        or "entry_price * 1.0016" not in _bot_src_10
        or "entry_price * 0.9984" not in _bot_src_10
    ):
        errors.append("BOM #117A/B/C regression: core/bot.py missing is_symbol_open JEV audit guard, is_fee_scratch_be breakeven shield, or +0.16% MFE ratchet buffer!")
    if "ABS(realized_pnl) > 1e-12" not in _db_src_10:
        errors.append("BOM #117D regression: database/db_manager.py get_performance_summary still counts entry fills (realized_pnl == 0) as losing trades!")
    if "dual_m1_verified" not in _qee_src_10 or "_m1_rescue_ready" not in _qee_src_10:
        errors.append("BOM #117E regression: core/quant_evolution_engine.py missing dual_m1_verified or _m1_rescue_ready!")

    report.add(
        10,
        "Weapon Arsenal (VK1..VK10+), IP Ban Runtime & Quantum Regression",
        errors,
        warnings,
        notes=[f"Verified {len(WEAPON_ARSENAL_CATALOG)} weapons + 0-HTTP IP ban guards"],
    )


# ---------------------------------------------------------------------------
# OPTIONAL: Live PC1 Log & Read-Only SQLite Health Snapshot
# ---------------------------------------------------------------------------
def run_live_log_check(since_hhmmss: str):
    today = datetime.now().strftime("%Y%m%d")
    date_prefix = datetime.now().strftime("%Y-%m-%d")
    log_path = os.path.join(ROOT, "logs", f"bot_{today}.log")
    print("\n" + "=" * 72)
    print(f"LIVE LOG SNAPSHOT ({log_path}) SINCE {date_prefix} {since_hhmmss}")
    print("=" * 72)
    if not os.path.exists(log_path):
        print(f"  [WARN] Log file not found: {log_path}")
        return
    cutoff = f"{date_prefix} {since_hhmmss}"
    lines = []
    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if line[:19] >= cutoff and re.match(r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", line):
                lines.append(line.rstrip("\r\n"))
            elif lines and not re.match(r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", line):
                lines.append(line.rstrip("\r\n"))

    err_tokens = (
        "[ERROR]", "[CRITICAL]", "Traceback", "NameError", "UnboundLocalError",
        "AttributeError", "KeyError", "TypeError", " 418 ", "code\":-1003",
        "code\":-1021", "code\":-2021", "code\":-2011", "code\":-2019", "code\":-4164",
    )
    errs = [l for l in lines if any(t in l for t in err_tokens)]
    print(f"  Total lines={len(lines)} | Real Errors={len(errs)}")
    for e in errs[:10]:
        print(f"    [ERR] {e[:180]}")

    db_path = os.path.join(ROOT, "data", "trade_bot.db")
    if os.path.exists(db_path):
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=5.0)
        con.execute("PRAGMA query_only = ON;")
        st = con.execute("SELECT mode, balance, substr(open_positions_json, 1, 180) FROM bot_state ORDER BY id DESC LIMIT 1").fetchone()
        tr = con.execute("SELECT id, symbol, side, price, realized_pnl FROM trades ORDER BY id DESC LIMIT 3").fetchall()
        con.close()
        print(f"  DB bot_state : {st}")
        print(f"  DB last 3 tr : {tr}")


def main():
    parser = argparse.ArgumentParser(description="TradeMatrix Exhaustive 10-Axis Automated Auditor (Offline)")
    parser.add_argument("--verbose", action="store_true", help="Hien thi chi tiet ca canh bao advisory")
    parser.add_argument("--live-log", metavar="HH:MM:SS", default=None, help="Tuy chon: quet log Live hom nay tu moc gio HH:MM:SS")
    args = parser.parse_args()

    t0 = time.perf_counter()
    print("=" * 72)
    print("TRADEMATRIX EXHAUSTIVE 10-AXIS AUTOMATED AUDIT (100% OFFLINE)")
    print("=" * 72)

    report = AuditReport(verbose=args.verbose)
    parsed_cache = run_axis_1(report)
    run_axis_2(report, parsed_cache)
    run_axis_3(report, parsed_cache)
    run_axis_4(report, parsed_cache)
    run_axis_5(report, parsed_cache)
    run_axis_6(report, parsed_cache)
    run_axis_7(report, parsed_cache)
    run_axis_8(report)
    run_axis_9(report, parsed_cache)
    run_axis_10(report)

    if args.live_log:
        run_live_log_check(args.live_log)

    rc = report.summary()
    print(f"Completed in {time.perf_counter() - t0:.2f}s (0 Binance REST calls).")
    sys.exit(rc)


if __name__ == "__main__":
    main()
