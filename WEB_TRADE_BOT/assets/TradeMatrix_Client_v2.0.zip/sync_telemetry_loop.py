"""
Background Telemetry Pusher
Đồng bộ trực tiếp số dư, vị thế mở thực tế từ Binance và DB sang Firestore
Giúp giao diện Web https://lehoangduc.pages.dev luôn cập nhật theo thời gian thực
"""

import time
import json
import sqlite3
import os
import requests
from datetime import datetime
from dotenv import load_dotenv
import sys

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

load_dotenv('d:/TRADE/.env')
import ccxt

try:
    import yaml
except Exception:  # pragma: no cover - yaml là dependency bắt buộc của bot
    yaml = None


def _load_settings(root_dir):
    """Đọc config/settings.yaml chỉ để HIỂN THỊ (trần vị thế, vốn gốc...).

    Trả {} khi không đọc được. Tuyệt đối không ghi ngược file từ tiến trình này.
    """
    path = os.path.join(root_dir, 'config', 'settings.yaml')
    if yaml is None or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            loaded = yaml.safe_load(fh)
        return loaded if isinstance(loaded, dict) else {}
    except Exception as e:
        print(f"⚠️ Không đọc được settings.yaml cho telemetry: {e}")
        return {}


def _parse_state_timestamp(value):
    """Đổi `bot_state.last_check` (ISO string / epoch giây / epoch mili-giây) sang epoch giây."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        ts = float(value)
        return ts / 1000.0 if ts > 1e11 else ts
    text = str(value).strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text).timestamp()
    except Exception:
        pass
    try:
        ts = float(text)
    except Exception:
        return None
    return ts / 1000.0 if ts > 1e11 else ts


def _display_max_open_trades(settings, equity):
    """Bản sao thu gọn của Bot._configured_max_open_positions() cho mục đích HIỂN THỊ.

    Tôn trọng thiết lập người dùng (`trading.max_open_trades`) và trần rủi ro
    (`risk.max_open_positions`) thay vì hardcode 3 như trước.
    """
    trading_cfg = settings.get('trading') or {}
    risk_cfg = settings.get('risk') or {}
    try:
        eq = float(equity) if equity is not None else 0.0
    except (TypeError, ValueError, OverflowError):
        eq = 0.0
    if eq < 100.0:
        cap = 3
    elif eq < 300.0:
        cap = 4
    elif eq < 1000.0:
        cap = 5
    elif eq < 5000.0:
        cap = 6
    elif eq < 20000.0:
        cap = 8
    else:
        cap = 10
    trading_limit = trading_cfg.get('max_open_trades', None)
    if trading_limit is not None:
        try:
            cap = max(1, min(20, int(trading_limit)))
        except (TypeError, ValueError, OverflowError):
            pass
    try:
        risk_cap = max(1, min(100, int(risk_cfg.get('max_open_positions', 10))))
    except (TypeError, ValueError, OverflowError):
        risk_cap = 10
    return min(risk_cap, cap)


def run_sync_service():
    local_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'trade_bot.db')
    lan_db = r'\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\data\trade_bot.db'
    db_path = local_db if os.path.exists(local_db) else lan_db
    tokens = ['VSBQm3jGflRA4RhCpJBXaro6hGG3', '97ONdLPdVhQ7i9FnCSWRrbIdmvd2']
    project_id = 'trade-bot-platform'

    ex = None
    try:
        ex = ccxt.binance({
            'apiKey': os.getenv('BINANCE_API_KEY'),
            'secret': os.getenv('BINANCE_API_SECRET'),
            'options': {'defaultType': 'future', 'adjustForTimeDifference': True}
        })
        ex.load_time_difference()
    except Exception as e:
        print(f"Lỗi khởi tạo CCXT Binance: {e}")

    def to_fv(val):
        if isinstance(val, bool): return {'booleanValue': val}
        elif isinstance(val, int): return {'integerValue': str(val)}
        elif isinstance(val, float): return {'doubleValue': float(val)}
        elif isinstance(val, str): return {'stringValue': val}
        elif isinstance(val, list): return {'arrayValue': {'values': [to_fv(x) for x in val]}}
        elif isinstance(val, dict): return {'mapValue': {'fields': {k: to_fv(v) for k, v in val.items()}}}
        elif val is None: return {'nullValue': None}
        return {'stringValue': str(val)}

    def to_fdoc(data_dict):
        return {"fields": {k: to_fv(v) for k, v in data_dict.items()}}

    print("🚀 Telemetry Sync Daemon đã bắt đầu chạy...")
    root_dir = os.path.dirname(os.path.abspath(__file__))
    last_known_balance = None
    status_cache = {'checked_at': 0.0, 'running': None}

    while True:
        try:
            # 0. Cấu hình chỉ để hiển thị (trần vị thế, vốn gốc) - nạp lại mỗi chu kỳ
            settings = _load_settings(root_dir)

            # 1. Đọc dữ liệu bot_state từ database SQLite
            # [M13 - SỐ DƯ BỊA & ĐỌC NHẦM CHẾ ĐỘ]
            # Trước đây `balance = 93.37` được gán cứng rồi ghi đè nếu đọc được DB. Chỉ cần
            # một lần DB bận/khoá file (LAN chập chờn) là web hiển thị số dư 93.37 USDT
            # KHÔNG có thật, trong khi tài khoản thực tế khác hẳn -> người dùng ra quyết
            # định sai. Ngoài ra câu SQL không lọc `mode`, nên bản ghi DEMO có thể bị đẩy
            # lên web như số dư LIVE.
            # Nay: chỉ lấy bản ghi mode='live'; không đọc được thì dùng số dư thật từ
            # Binance; nếu cả hai đều chưa có thì GIỮ NGUYÊN số dư tốt gần nhất đã biết,
            # không bao giờ bịa số.
            state = {}
            raw_positions = []
            if os.path.exists(db_path):
                try:
                    conn = sqlite3.connect(db_path, timeout=3)
                    cur = conn.cursor()
                    columns = {r[1] for r in cur.execute("PRAGMA table_info(bot_state)")}
                    wanted = [
                        col for col in (
                            'balance', 'open_positions_json', 'last_check',
                            'initial_capital', 'peak_balance', 'extra_json',
                        ) if col in columns
                    ]
                    if wanted:
                        mode_filter = " WHERE mode = 'live'" if 'mode' in columns else ''
                        cur.execute(
                            f"SELECT {', '.join(wanted)} FROM bot_state"
                            f"{mode_filter} ORDER BY id DESC LIMIT 1"
                        )
                        row = cur.fetchone()
                        if row:
                            state = dict(zip(wanted, row))
                    conn.close()
                except Exception:
                    pass

            if state.get('open_positions_json'):
                try:
                    raw_positions = json.loads(state['open_positions_json']) or []
                except (TypeError, ValueError):
                    raw_positions = []

            # 1b. Sổ vốn nạp/rút do bot ghi trong extra_json (H6)
            net_deposits = None
            ledger_complete = False
            if state.get('extra_json'):
                try:
                    extra_state = json.loads(state['extra_json'])
                except (TypeError, ValueError):
                    extra_state = None
                if isinstance(extra_state, dict) and extra_state.get('net_deposits') is not None:
                    try:
                        net_deposits = float(extra_state['net_deposits'])
                    except (TypeError, ValueError, OverflowError):
                        net_deposits = None
                if isinstance(extra_state, dict):
                    # [SỔ VỐN] Sổ đã đối chiếu đầy đủ với sàn thì mốc vốn PnL chính là tổng nạp/rút.
                    ledger_complete = bool(extra_state.get('ledger_complete'))

            # 2. Lấy dữ liệu vị thế thực tế trực tiếp từ Binance Futures
            exchange_pos = {}
            position_risk_ok = False
            positions_stale = False
            exchange_connected = False
            exchange_free = None
            exchange_equity = None
            if ex:
                try:
                    p_risks = ex.fapiPrivateV2GetPositionRisk()
                    position_risk_ok = True
                    exchange_connected = True
                    for p in p_risks:
                        amt = float(p.get('positionAmt') or 0.0)
                        if amt != 0:
                            sym = p['symbol'].replace('/', '').replace(':USDT', '')
                            exchange_pos[sym] = p
                except Exception:
                    pass
                try:
                    account = ex.fapiPrivateV2GetAccount()
                    exchange_connected = True
                    if account.get('availableBalance') is not None:
                        exchange_free = float(account['availableBalance'])
                    if account.get('totalMarginBalance') is not None:
                        exchange_equity = float(account['totalMarginBalance'])
                    elif account.get('totalWalletBalance') is not None:
                        exchange_equity = float(account['totalWalletBalance']) + float(
                            account.get('totalUnrealizedProfit') or 0.0
                        )
                except Exception:
                    exchange_free = None
                    exchange_equity = None

            # 2b. Chốt số dư: Binance -> DB live -> số dư tốt gần nhất (không bịa)
            db_balance = None
            if state.get('balance') is not None:
                try:
                    db_balance = float(state['balance'])
                except (TypeError, ValueError, OverflowError):
                    db_balance = None
            balance = None
            balance_source = None
            if exchange_free is not None and exchange_equity is not None and exchange_equity > 0:
                balance = exchange_free
                balance_source = 'binance'
            elif db_balance is not None:
                balance = db_balance
                balance_source = 'bot_state'
            elif last_known_balance is not None:
                balance = last_known_balance
                balance_source = 'last_known'
            if balance is None:
                print("⚠️ Chưa có số dư nào (Binance và DB đều chưa sẵn sàng) - bỏ qua chu kỳ telemetry.")
                time.sleep(3.5)
                continue
            last_known_balance = balance

            # 3. Tổng hợp telemetry chi tiết
            positions_data = []
            # Ưu tiên các vị thế thực tế từ sàn Binance nếu có
            if position_risk_ok and exchange_pos:
                for sym, ex_p in exchange_pos.items():
                    amt = float(ex_p.get('positionAmt') or 0.0)
                    side = "LONG" if amt > 0 else "SHORT"
                    entry_p = float(ex_p.get('entryPrice') or 0.0)
                    mark_p = float(ex_p.get('markPrice') or entry_p)
                    margin = float(ex_p.get('isolatedMargin') or 0.0)
                    lev = int(ex_p.get('leverage') or 1)
                    if margin <= 0 and entry_p > 0 and amt != 0:
                        margin = (entry_p * abs(amt)) / max(1, lev)
                    upnl = float(ex_p.get('unRealizedProfit') or 0.0)
                    pnl_pct = round((upnl / margin * 100.0), 2) if margin > 0 else 0.0

                    # Tìm thêm stop_loss & trailing từ raw_positions nếu có
                    matching_raw = next(
                        (
                            r for r in raw_positions
                            if str(r.get('symbol') or '').split(':')[0].replace('/', '').upper() == sym.upper()
                        ),
                        {},
                    )
                    sl = float(matching_raw.get('stop_loss') or 0.0)
                    tp = float(matching_raw.get('take_profit') or 0.0)
                    if matching_raw.get('time_be_locked_60m'):
                        trailing_status = 'Khóa hòa vốn 60m'
                    elif matching_raw.get('time_sl_compressed_35m'):
                        trailing_status = 'Đã siết SL 35m'
                    elif matching_raw.get('time_sl_compressed_25m'):
                        trailing_status = 'Đã siết SL 25m'
                    elif matching_raw.get('time_sl_compressed_15m'):
                        trailing_status = 'Đã siết SL 15m'
                    else:
                        trailing_status = matching_raw.get('trailing_status') or 'Bảo vệ vốn'

                    positions_data.append({
                        "symbol": matching_raw.get('symbol') or f"{sym[:-4]}/{sym[-4:]}",
                        "side": side,
                        "leverage": lev,
                        "amount": abs(amt),
                        "entry_price": entry_p,
                        "mark_price": mark_p,
                        "margin": round(margin, 2),
                        "unrealized_pnl": round(upnl, 4),
                        "pnl_pct": pnl_pct,
                        "stop_loss": sl,
                        "take_profit": tp,
                        "trailing_status": trailing_status,
                        "trailing_active": bool(matching_raw.get('trailing_active', False)),
                        "time_sl_compressed": bool(matching_raw.get('time_sl_compressed_15m', False))
                    })
            elif not position_risk_ok:
                # Không phân biệt được "flat thật" với "API lỗi": công bố stale/unknown,
                # không hồi sinh vị thế cũ và không dùng trailing_best_price làm mark price.
                positions_stale = True

            # Đọc performance thực tế từ local API nếu có
            perf = {}
            try:
                r_perf = requests.get("http://127.0.0.1:5000/api/performance", timeout=2)
                if r_perf.status_code == 200:
                    perf = r_perf.json()
                    cached_perf = perf
            except Exception:
                pass
            if not perf and "cached_perf" in locals() and cached_perf:
                perf = cached_perf

            today_pnl = float(perf.get("today_pnl", 0.0))
            total_pnl = float(perf.get("total_pnl", 0.0))
            win_rate = float(perf.get("win_rate", 0.0) or 0.0)
            total_trades = int(perf.get("total_trades") or perf.get("closed_trade_count", 0))
            total_unrealized = sum(p["unrealized_pnl"] for p in positions_data)

            # [M13 - TRẠNG THÁI GIẢ] Trước đây `is_running`/`exchange_connected` luôn là True
            # và `max_open_trades` luôn là 3, nên web báo ONLINE + 3 slot kể cả khi bot đã
            # dừng, mất kết nối sàn, hoặc người dùng đã đặt trần 2 lệnh.
            # Nay: trạng thái chạy lấy từ API nội bộ (hoặc độ tươi của last_check),
            # kết nối lấy từ kết quả gọi sàn thật, trần lệnh lấy từ settings.yaml.
            now_ts = time.time()
            if now_ts - status_cache['checked_at'] >= 30.0:
                status_cache['checked_at'] = now_ts
                try:
                    # `/health` là endpoint duy nhất trả `bot_running` (xem dashboard/app.py).
                    r_status = requests.get("http://127.0.0.1:5000/health", timeout=2)
                    if r_status.status_code == 200:
                        payload = r_status.json()
                        if 'bot_running' in payload:
                            status_cache['running'] = bool(payload.get('bot_running'))
                        else:
                            status_cache['running'] = None
                    else:
                        status_cache['running'] = None
                except Exception:
                    status_cache['running'] = None
            is_running = status_cache['running']
            if is_running is None:
                last_check_ts = _parse_state_timestamp(state.get('last_check'))
                is_running = bool(last_check_ts and (now_ts - last_check_ts) <= 600.0)

            max_open_trades = _display_max_open_trades(
                settings,
                exchange_equity if exchange_equity is not None else balance,
            )

            # [SỔ VỐN] PnL phiên = equity - mốc vốn thật.
            # Mốc vốn = tổng nạp/rút ròng dựng từ lịch sử TRANSFER của sàn khi sổ đã đầy đủ
            # (`ledger_complete`), ngược lại giữ mô hình cũ (vốn gốc khai báo + phần nạp đã thấy).
            try:
                initial_capital = float((settings.get('trading') or {}).get('initial_capital'))
            except (TypeError, ValueError, OverflowError):
                initial_capital = None
            invested_basis = None
            session_pnl = None
            if net_deposits is not None:
                if ledger_complete:
                    invested_basis = max(0.0, net_deposits)
                elif initial_capital is not None:
                    invested_basis = max(0.0, initial_capital + net_deposits)
                if invested_basis is not None and exchange_equity is not None:
                    session_pnl = round(exchange_equity - invested_basis, 4)

            telemetry_data = {
                "balance": round(balance, 4),
                "daily_pnl": round(today_pnl, 4),
                "today_pnl": round(today_pnl, 4),
                "total_pnl": round(total_pnl, 4),
                "unrealized_pnl": round(total_unrealized, 4),
                "win_rate": round(win_rate, 1),
                "total_trades": total_trades,
                "open_positions_count": len(positions_data),
                "account_snapshot_stale": positions_stale,
                "max_open_trades": max_open_trades,
                "is_running": is_running,
                "exchange_connected": exchange_connected,
                "balance_source": balance_source,
                "equity": round(exchange_equity, 4) if exchange_equity is not None else None,
                "net_deposits": round(net_deposits, 4) if net_deposits is not None else None,
                "invested_basis": round(invested_basis, 4) if invested_basis is not None else None,
                "session_pnl": session_pnl,
                "updated_at": datetime.now().strftime("%H:%M:%S %d/%m"),
                "positions": positions_data
            }

            doc_body = to_fdoc(telemetry_data)

            for token in tokens:
                patch_url = f"https://firestore.googleapis.com/v1/projects/{project_id}/databases/(default)/documents/bots_telemetry/{token}"
                try:
                    requests.patch(patch_url, json=doc_body, timeout=4)
                except Exception:
                    pass

        except Exception as e:
            # Không nuốt lỗi im lặng: chu kỳ lỗi trước đây làm daemon "chết lặng" mà
            # không ai biết web đang đứng ở số liệu cũ.
            print(f"⚠️ Lỗi chu kỳ telemetry: {e}")

        time.sleep(3.5)

if __name__ == "__main__":
    run_sync_service()
