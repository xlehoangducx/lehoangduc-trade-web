"""
Background Telemetry Pusher
Đồng bộ trực tiếp số dư, vị thế mở thực tế từ Binance và DB sang Firestore
Giúp giao diện Web https://lehoangduc.pages.dev luôn cập nhật theo thời gian thực
"""

import time
import json
import sqlite3
import os
import requests
from datetime import datetime
from dotenv import load_dotenv
import sys

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

load_dotenv('d:/TRADE/.env')
import ccxt

def run_sync_service():
    db_path = r'\\192.168.1.10\trade-web\assets\TradeMatrix_Client_v2.0\data\trade_bot.db'
    tokens = ['VSBQm3jGflRA4RhCpJBXaro6hGG3', '97ONdLPdVhQ7i9FnCSWRrbIdmvd2']
    project_id = 'trade-bot-platform'

    ex = None
    try:
        ex = ccxt.binance({
            'apiKey': os.getenv('BINANCE_API_KEY'),
            'secret': os.getenv('BINANCE_API_SECRET'),
            'options': {'defaultType': 'future', 'adjustForTimeDifference': True}
        })
        ex.load_time_difference()
    except Exception as e:
        print(f"Lỗi khởi tạo CCXT Binance: {e}")

    def to_fv(val):
        if isinstance(val, bool): return {'booleanValue': val}
        elif isinstance(val, int): return {'integerValue': str(val)}
        elif isinstance(val, float): return {'doubleValue': float(val)}
        elif isinstance(val, str): return {'stringValue': val}
        elif isinstance(val, list): return {'arrayValue': {'values': [to_fv(x) for x in val]}}
        elif isinstance(val, dict): return {'mapValue': {'fields': {k: to_fv(v) for k, v in val.items()}}}
        elif val is None: return {'nullValue': None}
        return {'stringValue': str(val)}

    def to_fdoc(data_dict):
        return {"fields": {k: to_fv(v) for k, v in data_dict.items()}}

    print("🚀 Telemetry Sync Daemon đã bắt đầu chạy...")

    while True:
        try:
            # 1. Đọc dữ liệu bot_state từ database SQLite
            balance = 93.37
            raw_positions = []
            if os.path.exists(db_path):
                try:
                    conn = sqlite3.connect(db_path, timeout=3)
                    c = conn.cursor()
                    c.execute("SELECT balance, open_positions_json FROM bot_state ORDER BY id DESC LIMIT 1;")
                    row = c.fetchone()
                    conn.close()
                    if row:
                        balance = float(row[0])
                        raw_positions = json.loads(row[1]) if row[1] else []
                except Exception:
                    pass

            # 2. Lấy dữ liệu vị thế thực tế trực tiếp từ Binance Futures
            exchange_pos = {}
            if ex:
                try:
                    p_risks = ex.fapiPrivateV2GetPositionRisk()
                    for p in p_risks:
                        amt = float(p.get('positionAmt') or 0.0)
                        if amt != 0:
                            sym = p['symbol'].replace('/', '').replace(':USDT', '')
                            exchange_pos[sym] = p
                except Exception:
                    pass

            # 3. Tổng hợp telemetry chi tiết
            positions_data = []
            # Ưu tiên các vị thế thực tế từ sàn Binance nếu có
            if exchange_pos:
                for sym, ex_p in exchange_pos.items():
                    amt = float(ex_p.get('positionAmt') or 0.0)
                    side = "LONG" if amt > 0 else "SHORT"
                    entry_p = float(ex_p.get('entryPrice') or 0.0)
                    mark_p = float(ex_p.get('markPrice') or entry_p)
                    margin = float(ex_p.get('isolatedMargin') or 0.0)
                    lev = int(ex_p.get('leverage') or 1)
                    if margin <= 0 and entry_p > 0 and amt != 0:
                        margin = (entry_p * abs(amt)) / max(1, lev)
                    upnl = float(ex_p.get('unRealizedProfit') or 0.0)
                    pnl_pct = round((upnl / margin * 100.0), 2) if margin > 0 else 0.0

                    # Tìm thêm stop_loss & trailing từ raw_positions nếu có
                    matching_raw = next(
                        (
                            r for r in raw_positions
                            if str(r.get('symbol') or '').split(':')[0].replace('/', '').upper() == sym.upper()
                        ),
                        {},
                    )
                    sl = float(matching_raw.get('stop_loss') or 0.0)
                    tp = float(matching_raw.get('take_profit') or 0.0)
                    if matching_raw.get('time_be_locked_60m'):
                        trailing_status = 'Khóa hòa vốn 60m'
                    elif matching_raw.get('time_sl_compressed_35m'):
                        trailing_status = 'Đã siết SL 35m'
                    elif matching_raw.get('time_sl_compressed_25m'):
                        trailing_status = 'Đã siết SL 25m'
                    elif matching_raw.get('time_sl_compressed_15m'):
                        trailing_status = 'Đã siết SL 15m'
                    else:
                        trailing_status = matching_raw.get('trailing_status') or 'Bảo vệ vốn'

                    positions_data.append({
                        "symbol": matching_raw.get('symbol') or f"{sym[:-4]}/{sym[-4:]}",
                        "side": side,
                        "leverage": lev,
                        "amount": abs(amt),
                        "entry_price": entry_p,
                        "mark_price": mark_p,
                        "margin": round(margin, 2),
                        "unrealized_pnl": round(upnl, 4),
                        "pnl_pct": pnl_pct,
                        "stop_loss": sl,
                        "take_profit": tp,
                        "trailing_status": trailing_status,
                        "trailing_active": bool(matching_raw.get('trailing_active', False)),
                        "time_sl_compressed": bool(matching_raw.get('time_sl_compressed_15m', False))
                    })
            elif raw_positions:
                for p in raw_positions:
                    dir_str = (p.get('direction') or ('LONG' if p.get('side') == 'buy' else 'SHORT')).upper()
                    entry_p = float(p.get('entry_price') or 0.0)
                    mark_p = float(p.get('trailing_best_price') or entry_p)
                    lev = int(p.get('leverage') or 1)
                    amt = abs(float(p.get('amount') or 0.0))
                    margin = float(p.get('cost') or ((entry_p * amt) / lev))
                    upnl = float(p.get('real_pnl') or 0.0)
                    pnl_pct = round((upnl / margin * 100.0), 2) if margin > 0 else 0.0

                    positions_data.append({
                        "symbol": p.get('symbol', ''),
                        "side": dir_str,
                        "leverage": lev,
                        "amount": amt,
                        "entry_price": entry_p,
                        "mark_price": mark_p,
                        "margin": round(margin, 2),
                        "unrealized_pnl": round(upnl, 4),
                        "pnl_pct": pnl_pct,
                        "stop_loss": float(p.get('stop_loss') or 0.0),
                        "take_profit": float(p.get('take_profit') or 0.0),
                        "trailing_status": str(p.get('trailing_status') or ''),
                        "trailing_active": bool(p.get('trailing_active', False)),
                        "time_sl_compressed": bool(p.get('time_sl_compressed_15m', False))
                    })

            # Đọc performance thực tế từ local API nếu có
            perf = {}
            try:
                r_perf = requests.get("http://127.0.0.1:5000/api/performance", timeout=2)
                if r_perf.status_code == 200:
                    perf = r_perf.json()
                    cached_perf = perf
            except Exception:
                pass
            if not perf and "cached_perf" in locals() and cached_perf:
                perf = cached_perf

            today_pnl = float(perf.get("today_pnl", 0.0))
            total_pnl = float(perf.get("total_pnl", 0.0))
            win_rate = float(perf.get("win_rate", 0.0) or 0.0)
            total_trades = int(perf.get("total_trades") or perf.get("closed_trade_count", 0))
            total_unrealized = sum(p["unrealized_pnl"] for p in positions_data)

            telemetry_data = {
                "balance": balance,
                "daily_pnl": round(today_pnl, 4),
                "today_pnl": round(today_pnl, 4),
                "total_pnl": round(total_pnl, 4),
                "unrealized_pnl": round(total_unrealized, 4),
                "win_rate": round(win_rate, 1),
                "total_trades": total_trades,
                "open_positions_count": len(positions_data),
                "max_open_trades": 3,
                "is_running": True,
                "exchange_connected": True,
                "updated_at": datetime.now().strftime("%H:%M:%S %d/%m"),
                "positions": positions_data
            }

            doc_body = to_fdoc(telemetry_data)

            for token in tokens:
                patch_url = f"https://firestore.googleapis.com/v1/projects/{project_id}/databases/(default)/documents/bots_telemetry/{token}"
                try:
                    requests.patch(patch_url, json=doc_body, timeout=4)
                except Exception:
                    pass

        except Exception as e:
            pass

        time.sleep(3.5)

if __name__ == "__main__":
    run_sync_service()
